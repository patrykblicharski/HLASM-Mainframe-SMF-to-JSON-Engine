> Licensed Materials - Property of IBM
>
> 5650-ZOS
>
> © Copyright IBM Corp. 2020, 2024

See **https://www.ibm.com/docs/en/SSLTBW_3.1.0/pdf/e0zf100_v3r1.pdf** for details.
