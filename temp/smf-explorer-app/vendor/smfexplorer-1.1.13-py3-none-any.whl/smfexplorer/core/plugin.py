# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
import importlib
import importlib.util
import logging
import pkgutil
import typing
from abc import ABC, abstractmethod
from collections import deque
from enum import Enum, auto
from typing import Dict, List, Optional, Protocol, Tuple, TypeVar

import packaging.version

import smfexplorer.fields
from smfexplorer._version import __version__
from smfexplorer.error import PluginError

LOG = logging.getLogger(__name__)

INITIAL_PLUGIN_SUPPORT_VERSION: packaging.version.Version = packaging.version.Version(
    "0.9.0.a2"
)
CURRENT_VERSION = packaging.version.Version(__version__)


class PluginTypes(Enum):
    FIELD_DEFINITIONS = auto()
    POST_PROCESSORS = auto()
    SAMPLE_DEFINITIONS = auto()
    UTIL_DEFINITIONS = auto()


@typing.runtime_checkable
class Plugin(Protocol):

    # @classmethod
    # def _available_extensions(cls):
    #     types = set()
    #     for entry in dir(cls):
    #         if entry.endswith("_plugin_type"):
    #             types.add(getattr(cls, entry))
    #     return list(types)

    # ------------------------ General Plugin Information ------------------------ #

    _manager: "PluginManager"

    @staticmethod
    def name() -> str: ...

    @staticmethod
    def required_plugins() -> List[str]:
        return ["base"]

    @staticmethod
    def minimum_supported_smfexplorer_version() -> Optional[packaging.version.Version]:
        return INITIAL_PLUGIN_SUPPORT_VERSION

    # -------------- Plugin initialization - Run from Plugin Manager ------------- #

    def initialize(self): ...

    def post_initialize(self): ...


@typing.runtime_checkable
class FieldPlugin(Protocol):

    # __plugin_type = PluginTypes.FIELD_DEFINITIONS

    @staticmethod
    def get_field_definitions() -> List[Tuple[str, str]]:
        return []

    @staticmethod
    def get_provided_smf_types() -> List[str]: ...


@typing.runtime_checkable
class SamplesPlugin(Protocol):

    # __plugin_type = PluginTypes.SAMPLE_DEFINITIONS

    @staticmethod
    def register_samples() -> None: ...


@typing.runtime_checkable
class PostProcessorPlugin(Protocol):

    # __plugin_type = PluginTypes.POST_PROCESSORS

    @staticmethod
    def register_post_processors() -> None: ...


class PluginManager:

    __loaded = False

    def __init__(self) -> None:
        self._plugins: Dict[str, Plugin] = {}
        self._module_prefix: str = None
        self._plugin_load_order: List[str] = []
        self._provided_fields_definitions: Dict[str, Plugin] = {}

    def __find_plugins(self) -> List[pkgutil.ModuleInfo]:
        import smfexplorer.plugin as smfexplorer_plugin_module

        plugin_modules = list(pkgutil.iter_modules(smfexplorer_plugin_module.__path__))

        LOG.debug(
            "Found %d potential plugins: %s",
            len(plugin_modules),
            ",".join([p.name for p in plugin_modules]),
        )

        self._module_prefix = smfexplorer_plugin_module.__name__

        return plugin_modules

    def __load_plugin(self, name: str) -> "Plugin":

        LOG.debug("Trying to load plugin module %s", name)

        spec = importlib.util.find_spec(f"{self._module_prefix}.{name}")

        if not spec:
            raise PluginError(f"Could not create module spec for plugin {name}", name)

        plugin_module = importlib.import_module("." + name, self._module_prefix)

        if not hasattr(plugin_module, "_get_smfexplorer_plugin_class"):
            LOG.warning(
                "Module %s is not a plugin. Missing '_get_smfexplorer_plugin_class'",
                name,
            )
            return

        plugin_class = plugin_module._get_smfexplorer_plugin_class()
        plugin: Plugin = plugin_class()
        plugin._manager = self

        LOG.debug(
            "Loaded plugin '%s' from module '%s.%s'",
            plugin.name(),
            self._module_prefix,
            name,
        )

        self._plugins[name] = plugin

    def __validate_plugins(self):

        plugins_to_remove = set()

        for name, plugin in self._plugins.items():

            # ------------------------------- Version Check ------------------------------ #
            minimum_version = plugin.minimum_supported_smfexplorer_version()
            if minimum_version and minimum_version > CURRENT_VERSION:
                plugins_to_remove.add(name)
                LOG.warning(
                    "Plugin '%s' will be removed: Requires newer version of SMF Explorer (%s > %s)",
                    name,
                    minimum_version,
                    CURRENT_VERSION,
                )
                continue

            LOG.debug(
                "Plugin '%s' requires '%s' as the minimum version of SMF Explorer",
                name,
                minimum_version,
            )

        # Remove invalid plugins
        [self._plugins.pop(n) for n in plugins_to_remove]

    def __resolve_plugin_order(self):

        LOG.debug("Resolving plugin order")
        resolve_list = deque(self._plugins.keys())

        while resolve_list:
            plugin = self._plugins[resolve_list.pop()]

            for req_plugin in plugin.required_plugins():
                if not req_plugin in self._plugins:
                    LOG.warning(
                        "Plugin '%s' will be removed: Missing dependency '%s'",
                        plugin.name(),
                        req_plugin,
                    )
                    self._plugins.pop(plugin.name())
                    break

                if not all(
                    n in self._plugin_load_order for n in plugin.required_plugins()
                ):
                    resolve_list.appendleft(plugin.name())
                    break
            else:
                self._plugin_load_order.append(plugin.name())

    def _load_plugins(self):
        if PluginManager.__loaded:
            raise RuntimeError("Plugins where already loaded")

        plugin_infos = self.__find_plugins()

        for module_info in plugin_infos:
            self.__load_plugin(module_info.name)

        self.__validate_plugins()

        self.__resolve_plugin_order()

        LOG.debug("Loaded the following plugins: %s", self._plugin_load_order)

        # ---------------------------- Running plugin load --------------------------- #

        for plugin_name in self._plugin_load_order:
            plugin = self._plugins[plugin_name]
            plugin.initialize()

        for plugin_name in self._plugin_load_order:
            plugin: Plugin = self._plugins[plugin_name]

            # extensions = sorted(plugin._available_extensions(),
            #                     key=lambda k: k.value)

            if isinstance(plugin, FieldPlugin):
                LOG.debug("Plugin '%s' is a FieldPlugin", plugin.name())

                field_defs = plugin.get_provided_smf_types()

                for definition in field_defs:
                    if definition in self._provided_fields_definitions:
                        raise PluginError(
                            f"The field definition for {definition} was allready provided by the plugin '{self._provided_fields_definitions[definition].name()}'. Uninstall one of the plugins or report this as a bug to the plugin developer.",
                            plugin.name(),
                        )
                    LOG.debug(
                        "Registered field definition '%s' from plugin '%s'",
                        definition,
                        plugin.name(),
                    )
                    self._provided_fields_definitions[definition] = plugin

            if isinstance(plugin, PostProcessorPlugin):
                LOG.debug("Plugin '%s' is a PostProcessorPlugin", plugin.name())
                plugin.register_post_processors()

            if isinstance(plugin, SamplesPlugin):
                LOG.debug("Plugin '%s' is a SamplesPlugin", plugin.name())
                plugin.register_samples()

        PluginManager.__loaded = True

    def _run_post_init(self) -> None:
        for plugin_name in self._plugin_load_order:
            plugin = self._plugins[plugin_name]
            plugin.post_initialize()


# PluginType = TypeVar("PluginType", Plugin, FieldPlugin, SamplesPlugin,
#                     PostProcessorPlugin)
