# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""This module proviedes the post processing functionality of SMF Explorer."""
from enum import Enum
from typing import Callable, List, Set, Union

import pandas as pd

import smfexplorer.core.field as field
import smfexplorer.error as error


class PostProcessorType(Enum):
    """Enumeration of possible post processor types.

    Types
    ------
    MAP
        Post processor that applies a Transformation to every field.
    FILTER
        Post processor that filters out results that match a specific condition.
    FRAME
        Post processor that applies a Transformation to an entire result.
    """

    MAP = 1
    FILTER = 2
    FRAME = 3


class PostProcessor:
    """`PostProcessor` holds all the information that is required for a post processing step."""

    def __init__(
        self,
        processor_type: PostProcessorType,
        callback: Callable[
            [Union[pd.DataFrame, pd.Series]], Union[bool, pd.DataFrame, pd.Series]
        ],
        required_fields: List = None,
    ):
        self.processor_type = processor_type
        self.callback = callback
        self.required_fields: Set[field.Field] = (
            set(required_fields) if required_fields else set()
        )

    def __repr__(self):
        return f"<PostProcessor:{self.processor_type}:{self.callback}>"

    def apply(self, df: pd.DataFrame) -> pd.DataFrame:
        """Apply PostProcessor to dataframe

        Parameters
        ----------
        df : pd.DataFrame
            DataFrame to apply PostProcessor to

        Returns
        -------
        pd.DataFrame
            Resulting DataFrame
        """
        if self.processor_type == PostProcessorType.FILTER:
            df = df[self.callback]
            return df.reset_index(drop=True)

        if self.processor_type == PostProcessorType.MAP:
            df = df.apply(self.callback, axis=1)
            return df

        if self.processor_type == PostProcessorType.FRAME:
            return self.callback(df)

        raise error.RequestError(
            f"The specified processor type {self.processor_type} is not unknown"
        )
