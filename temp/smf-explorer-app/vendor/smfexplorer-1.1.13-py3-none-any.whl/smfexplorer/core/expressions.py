# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""This module provides parts of the expression language for SMF Explorer."""
from __future__ import annotations

from enum import Enum
from typing import Tuple

from smfexplorer import error
from smfexplorer.core import field as _field


class WhereExpressionType(Enum):
    """Type of `WhereExpression`"""

    OPERAND = 0
    EQ = 1
    NQ = 2
    GT = 3
    LT = 4
    GTE = 5
    LTE = 6
    LIKE = 7
    NLIKE = 8
    BETWEEN = 9
    NOT = 10
    AND = 11
    OR = 12


class WhereExpressionReturnType(Enum):
    """Return type of `WhereExpression`"""

    LOGICAL = 0
    VALUE = 1


class WhereExpression:
    """Expression used in the `Request.where(exp)` method"""

    def __init__(
        self,
        operation: WhereExpressionType,
        return_type: WhereExpressionReturnType,
        operands=(),
    ):
        self.operation = operation
        self.return_type = return_type
        self.operands: Tuple = operands

    def __eq__(self, other) -> WhereExpression:
        if type(other) is str:
            return LIKE(self, other)
        else:
            return EQ(self, other)

    def __ne__(self, other) -> WhereExpression:
        if type(other) is str:
            return NLIKE(self, other)
        else:
            return NQ(self, other)

    def __gt__(self, other) -> WhereExpression:
        return GT(self, other)

    def __lt__(self, other) -> WhereExpression:
        return LT(self, other)

    def __ge__(self, other) -> WhereExpression:
        return GTE(self, other)

    def __le__(self, other) -> WhereExpression:
        return LTE(self, other)

    def __and__(self, other) -> WhereExpression:
        return AND(self, other)

    def __or__(self, other) -> WhereExpression:
        return OR(self, other)

    def __bool__(self) -> bool:

        # If all operands are fields and the operation is comparison, compare field objects.
        operands_are_fields = all(
            type(operand) == WhereExpression
            and type(operand.operands[0]).__name__ == "Field"
            for operand in self.operands
        )
        if operands_are_fields and len(self.operands) == 2:
            field_1 = self.operands[0].operands[0]
            field_2 = self.operands[1].operands[0]
            if self.operation == WhereExpressionType.EQ:
                if (field_1.record is None) ^ (field_2.record is None):
                    return False
                return (
                    (field_1.record == None and field_2.record == None)
                    or (
                        field_1.record.smf_type == field_2.record.smf_type
                        and field_1.record.smf_subtype == field_2.record.smf_subtype
                    )
                    and field_1.name == field_2.name
                    and field_1._origin == field_2._origin
                )
            elif self.operation == WhereExpressionType.NQ:
                return not (
                    field_1.name == field_2.name and field_1._origin == field_2._origin
                )

        # Default bool value of all objects without __len__ is True.
        return True

    def __hash__(self):
        key = f"{self.operation}" + "".join([f"{hash(op)}" for op in self.operands])
        return hash(key)


def _op_eval(exp, expected_type: WhereExpressionReturnType) -> WhereExpression:
    tmp = exp
    result = None
    if isinstance(tmp, WhereExpression):
        result = tmp
    elif isinstance(tmp, bool):
        result = WhereExpression(
            WhereExpressionType.OPERAND, WhereExpressionReturnType.LOGICAL, (tmp,)
        )
    else:
        result = WhereExpression(
            WhereExpressionType.OPERAND, WhereExpressionReturnType.VALUE, (tmp,)
        )
    if result.return_type != expected_type:
        raise error.ExpressionError(
            f"Where Expression with wrong type. Expected {expected_type} but received {result.return_type}"
        )
    return result


# pylint: disable=invalid-name


def EQ(exp1, exp2) -> WhereExpression:
    """Create an Expression that checks for equality of `exp1` and `exp2`.

    Parameters
    ----------
    exp1 : any including WhereExpression and Field
        First expression
    exp2 : any including WhereExpression and Field
        Second expression

    Returns
    -------
    WhereExpression
        Resulting expression

    Notes
    -----
    The types of `exp1` and `exp2` should be the same.
    """
    return WhereExpression(
        WhereExpressionType.EQ,
        WhereExpressionReturnType.LOGICAL,
        (
            _op_eval(exp1, WhereExpressionReturnType.VALUE),
            _op_eval(exp2, WhereExpressionReturnType.VALUE),
        ),
    )


def NQ(exp1, exp2) -> WhereExpression:
    """Create an Expression that checks for inequality of `exp1` and `exp2`.

    Parameters
    ----------
    exp1 : any including WhereExpression and Field
        First expression
    exp2 : any including WhereExpression and Field
        Second expression

    Returns
    -------
    WhereExpression
        Resulting expression

    Notes
    -----
    The types of `exp1` and `exp2` should be the same.
    """
    return WhereExpression(
        WhereExpressionType.NQ,
        WhereExpressionReturnType.LOGICAL,
        (
            _op_eval(exp1, WhereExpressionReturnType.VALUE),
            _op_eval(exp2, WhereExpressionReturnType.VALUE),
        ),
    )


def GT(exp1, exp2) -> WhereExpression:
    """Create an Expression that checks if `exp1` is greater then `exp2`.

    Parameters
    ----------
    exp1 : any including WhereExpression and Field
        First expression
    exp2 : any including WhereExpression and Field
        Second expression

    Returns
    -------
    WhereExpression
        Resulting expression

    Notes
    -----
    The types of `exp1` and `exp2` should be the same.
    """
    return WhereExpression(
        WhereExpressionType.GT,
        WhereExpressionReturnType.LOGICAL,
        (
            _op_eval(exp1, WhereExpressionReturnType.VALUE),
            _op_eval(exp2, WhereExpressionReturnType.VALUE),
        ),
    )


def LT(exp1, exp2) -> WhereExpression:
    """Create an Expression that checks if `exp1` is less then `exp2`.

    Parameters
    ----------
    exp1 : any including WhereExpression and Field
        First expression
    exp2 : any including WhereExpression and Field
        Second expression

    Returns
    -------
    WhereExpression
        Resulting expression

    Notes
    -----
    The types of `exp1` and `exp2` should be the same.
    """
    return WhereExpression(
        WhereExpressionType.LT,
        WhereExpressionReturnType.LOGICAL,
        (
            _op_eval(exp1, WhereExpressionReturnType.VALUE),
            _op_eval(exp2, WhereExpressionReturnType.VALUE),
        ),
    )


def GTE(exp1, exp2) -> WhereExpression:
    """Create an Expression that checks if `exp1` is greater then or equal to `exp2`.

    Parameters
    ----------
    exp1 : any including WhereExpression and Field
        First expression
    exp2 : any including WhereExpression and Field
        Second expression

    Returns
    -------
    WhereExpression
        Resulting expression

    Notes
    -----
    The types of `exp1` and `exp2` should be the same.
    """
    return WhereExpression(
        WhereExpressionType.GTE,
        WhereExpressionReturnType.LOGICAL,
        (
            _op_eval(exp1, WhereExpressionReturnType.VALUE),
            _op_eval(exp2, WhereExpressionReturnType.VALUE),
        ),
    )


def LTE(exp1, exp2) -> WhereExpression:
    """Create an Expression that checks if `exp1` is less then or equal to `exp2`.

    Parameters
    ----------
    exp1 : any including WhereExpression and Field
        First expression
    exp2 : any including WhereExpression and Field
        Second expression

    Returns
    -------
    WhereExpression
        Resulting expression

    Notes
    -----
    The types of `exp1` and `exp2` should be the same.
    """
    return WhereExpression(
        WhereExpressionType.LTE,
        WhereExpressionReturnType.LOGICAL,
        (
            _op_eval(exp1, WhereExpressionReturnType.VALUE),
            _op_eval(exp2, WhereExpressionReturnType.VALUE),
        ),
    )


def LIKE(exp, match_str: str) -> WhereExpression:
    """Create an Expression that string compares `exp` to `match_str`.

    Parameters
    ----------
    exp : any including WhereExpression and Field
        Expression to compare.
    match_str : str
        Matching string. May contain '%' as a wildcard character.

    Returns
    -------
    WhereExpression
        Resulting expression
    """
    return WhereExpression(
        WhereExpressionType.LIKE,
        WhereExpressionReturnType.LOGICAL,
        (_op_eval(exp, WhereExpressionReturnType.VALUE), match_str),
    )


def NLIKE(exp, match_str: str) -> WhereExpression:
    """Create an Expression that string not-compares `exp` to `match_str`.

    Parameters
    ----------
    exp : any including WhereExpression and Field
        Expression to compare.
    match_str : str
        Matching string. May contain '%' as a wildcard character.

    Returns
    -------
    WhereExpression
        Resulting expression
    """
    return WhereExpression(
        WhereExpressionType.NLIKE,
        WhereExpressionReturnType.LOGICAL,
        (_op_eval(exp, WhereExpressionReturnType.VALUE), match_str),
    )


def BETWEEN(exp, exp_low, exp_high) -> WhereExpression:
    """Expression that checks if `exp` lies between `exp_low` and `exp_high`.

    Parameters
    ----------
    exp : any including WhereExpression and Field
        Expression to check
    exp_low : any including WhereExpression and Field
        Lower bound of accepted range
    exp_high : any including WhereExpression and Field
        Upper bound of accepted range

    Returns
    -------
    WhereExpression
        Resulting Expression
    """
    return WhereExpression(
        WhereExpressionType.BETWEEN,
        WhereExpressionReturnType.LOGICAL,
        (
            _op_eval(exp, WhereExpressionReturnType.VALUE),
            _op_eval(exp_low, WhereExpressionReturnType.VALUE),
            _op_eval(exp_high, WhereExpressionReturnType.VALUE),
        ),
    )


def NOT(exp) -> WhereExpression:
    """Expression that negates an other expression

    Parameters
    ----------
    exp : any including WhereExpression and Field
        Expression to negate

    Returns
    -------
    WhereExpression
        Resulting Expression

    Raises
    ------
    Exception
        When `exp` is a LIKE ore NLIKE expression.
    """
    op = _op_eval(exp, WhereExpressionReturnType.LOGICAL)

    if (
        op.operation == WhereExpressionType.NLIKE
        or op.operation == WhereExpressionType.LIKE
    ):
        raise error.ExpressionError(
            "Negating a LIKE ore NLIKE expression is not possible. Please Switch from LIKE to NLIKE or vice versa"
        )

    return WhereExpression(
        WhereExpressionType.NOT, WhereExpressionReturnType.LOGICAL, (op,)
    )


def AND(exp1, exp2, *exps) -> WhereExpression:
    """Expression for a logical and condition. Allows to concatenate a arbitrary number of expressions.

    Parameters
    ----------
    exp1 : WhereExpression or bool
        First Expression
    exp2 : WhereExpression or bool
        Second Expression

    *exps: WhereExpression
        Additional expressions

    Returns
    -------
    WhereExpression
        Resulting expression
    """
    operands = (_op_eval(exp1, WhereExpressionReturnType.LOGICAL),)
    operands += (_op_eval(exp2, WhereExpressionReturnType.LOGICAL),)

    for exp in exps:
        operands += (_op_eval(exp, WhereExpressionReturnType.LOGICAL),)

    return WhereExpression(
        WhereExpressionType.AND, WhereExpressionReturnType.LOGICAL, operands
    )


def OR(exp1, exp2, *exps) -> WhereExpression:
    """Expression for a logical or condition. Allows to concatenate a arbitrary number of expressions.

    Parameters
    ----------
    exp1 : WhereExpression or bool
        First Expression
    exp2 : WhereExpression or bool
        Second Expression

    *exps: WhereExpression
        Additional expressions

    Returns
    -------
    WhereExpression
        Resulting expression
    """
    operands = (_op_eval(exp1, WhereExpressionReturnType.LOGICAL),)
    operands += (_op_eval(exp2, WhereExpressionReturnType.LOGICAL),)

    for exp in exps:
        operands += (_op_eval(exp, WhereExpressionReturnType.LOGICAL),)

    return WhereExpression(
        WhereExpressionType.OR, WhereExpressionReturnType.LOGICAL, operands
    )


# Sorting
class SortCondition(Enum):
    """Sorting condition for `SortExpression`"""

    ASC = 0
    DESC = 1


class SortExpression:
    """A `SortExpression` holds the information on how a fetched result should be sorted.
    It can be given to the ``Request.sort(*exps)`` method.
    """

    def __init__(self, field: _field.Field, condition: SortCondition):
        self.condition: SortCondition = condition
        self.field = field


def ASC(field) -> SortExpression:
    """Expression for sorting a field in ascending order.

    Parameters
    ----------
    field : Field
        Field to use for sorting

    Returns
    -------
    SortExpression
        Resulting expression
    """
    return SortExpression(field, SortCondition.ASC)


def DESC(field) -> SortExpression:
    """Expression for sorting a field in descending order.

    Parameters
    ----------
    field : Field
        Field to use for sorting

    Returns
    -------
    SortExpression
        Resulting expression
    """
    return SortExpression(field, SortCondition.DESC)
