# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""This module provides the resolver for `PostProcessors`"""
import logging
from typing import Callable, Dict, Optional, Tuple, Union

from smfexplorer.core.field import Field, Record, RecordMap
from smfexplorer.core.post_processor import PostProcessor

LOG = logging.getLogger(__name__)


class PostResolver:
    """The `PostResolver` manages `PostProcessor`s that can be resolved by a predefined name"""

    def __init__(self):
        """Create new `PostResolver`"""
        super().__init__()

        self._post_processor_map: Dict[str, Callable[..., Optional[PostProcessor]]] = {}
        self._post_processor_mode_map: Dict[
            str, Dict[str, Callable[..., Optional[PostProcessor]]]
        ] = {}

        self._post_processor_cache: Dict[
            Tuple[str, str, Optional[Union[Field, Record, RecordMap]]]
        ] = {}

    def clear_cache(self):
        """Clear the post-processor cache"""
        self._post_processor_cache.clear()

    def register(self, name: str, *modes: str):
        """Decorator to register a new `PostProcessor`.

        The decorated function needs to return a `PostProcessor` and may be given a `Field`, `RecordMap` or `Record` if it is used in the underlieing field Mappings.

        Parameters
        ----------
        name : str
            Name of the `PostProcessor`
        """

        def decorator(func):
            LOG.debug("Register new post processor %s", name)
            if modes:
                for mode in modes:
                    if not mode in self._post_processor_mode_map:
                        self._post_processor_mode_map[mode] = {}
                    self._post_processor_mode_map[mode][name] = func
            else:
                self._post_processor_map[name] = func

            return func

        return decorator

    def resolve(
        self, name: str, mode: str = None
    ) -> Callable[..., Optional[PostProcessor]]:
        """Resolves a `PostProcessor` by the name and mode it was registered with.

        Functions creating `PostProcessors` may be registered with the `register`() classmethod.

        Parameters
        ----------
        name : str
            Name the `PostProcessor` was registered with
        mode : str
            The environment mode that is used to resolve the `PostProcessor`

        Returns
        -------
        func
            Function that will return a `PostProcessor`
        None
            if no `PostProcessor` was found
        """
        LOG.debug("Searching for post processor %s in %s", name, self)

        if name in self._post_processor_map:
            return self._post_processor_map[name]
        elif (
            mode in self._post_processor_mode_map
            and name in self._post_processor_mode_map[mode]
        ):
            return self._post_processor_mode_map[mode][name]
        else:
            return None

    def create(
        self,
        name: str,
        obj: Optional[Union[Field, Record, RecordMap]] = None,
        mode: Optional[str] = None,
    ) -> Optional[PostProcessor]:
        """Resolves and creates a `PostProcessor`.

        Post-processors will be cached for better performance.

        If there is no Post-processor for the name and mode None is returned.

        Parameters
        ----------
        name : str
            Name the `PostProcessor` was registered with
        obj : Field, Record or RecordMap, optional
            The object needed to create the `PostProcessor`, by default None
        mode : str
            The mode to use to resolve the `PostProcessor`, by default None

        Returns
        -------
        PostProcessor
            The `PostProcessor` registered with `name`
        """
        if (name, mode, obj) in self._post_processor_cache:
            return self._post_processor_cache[(name, mode, obj)]

        func = self.resolve(name, mode)
        post = None
        if func:
            if obj is not None:
                post = func(obj)
            else:
                post = func()
            self._post_processor_cache[(name, mode, obj)] = post
        return post
