# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""The executor module implements the algorithms that execute any request"""
import logging
from typing import Any, Callable, Dict, List, Set

import numpy as np
import pandas as pd
import pandas.api.types as pd_types

import smfexplorer.core.request as se_request
import smfexplorer.core.request_graph as se_reqgraph
from smfexplorer import error, resolvers
from smfexplorer.core import expressions as se_expressions
from smfexplorer.core import field as se_field
from smfexplorer.core import post_processor as se_post_processor

_LOG = logging.getLogger(__name__)

MEMORY_OPTIMIZATION_LEVEL = 3


def run(request: "se_request.Request", dry_run: bool = False) -> pd.DataFrame:
    """Run the `request` using its `Context` and `Environment`.

    Args
    ----
        request (Request): The `Request` to run

    Returns
    -------
        pd.DataFrame: The resulting DataFrame
    """
    if isinstance(request, se_request.FieldRequest):
        return run_field_request(request, dry_run)
    elif isinstance(request, se_request.QueryRequest):
        return run_query_request(request, dry_run)
    else:
        raise error.RequestError("Unknown request type.", request=request)


def run_field_request(
    request: "se_request.FieldRequest", dry_run: bool = False
) -> pd.DataFrame:
    """Execute 'FieldRequest'"""
    _LOG.debug("Run FieldRequest %s", request)

    _LOG.debug("Calling Environment pre_hook")
    request.context.environment._pre_hook(request)

    collect_post_processors(request)

    _LOG.debug("Calling Environment pre_fetch_hook")
    request.context.environment._pre_fetch_hook(request)

    queries = request.context.environment.parser.parse(request)

    if dry_run:
        return queries
    data_frames = []
    for query in queries:
        try:
            result = request.context.environment.connector.query(query)
            data_frames.append(result)
        except error.EmptyDataSetError:
            continue

    if not data_frames:
        raise error.EmptyDataSetError(connector=request.context.environment.connector)

    data_frame = pd.concat(data_frames, ignore_index=True, copy=False)

    data_frame = optimize_memory_footprint(data_frame, MEMORY_OPTIMIZATION_LEVEL)

    _LOG.debug(
        "Fetched dataframe with the columns %s and %d entries",
        list(data_frame.columns),
        len(data_frame),
    )
    data_frame = execute_post_process(data_frame, request)
    data_frame = request.context.environment._post_hook(data_frame, request)
    data_frame = cleanup_dataframe(data_frame, request)
    return data_frame


def run_query_request(
    request: "se_request.QueryRequest", dry_run: bool = False
) -> pd.DataFrame:
    """Execute `QueryRequest`"""
    _LOG.debug("Run QueryRequest %s", request)

    queries = request.context.environment.parser.query(request)

    if dry_run:
        return queries

    data_frames = []
    for query in queries:
        try:
            result = request.context.environment.connector.query(query)
            data_frames.append(result)
        except error.EmptyDataSetError:
            continue

    if not data_frames:
        _LOG.debug("All datasets returned from %s are empty", request)
        raise error.EmptyDataSetError(connector=request.context.environment.connector)

    data_frame = pd.concat(data_frames, ignore_index=True, copy=False)
    return optimize_memory_footprint(data_frame, MEMORY_OPTIMIZATION_LEVEL)


def collect_post_processors(request: "se_request.FieldRequest") -> None:
    """Resolve all post-processors and required fields and add them to the request.

    The order of post-processors is topological but is prioritizing field
    post-processors over map/record post-processors.
    """

    traversed_nodes: Set[se_reqgraph.RGNode] = set()
    post_processors: Dict[se_reqgraph.RGNode, List[se_post_processor.PostProcessor]] = (
        {}
    )

    # TODO: Switch to post object instead of post and post_param

    # Collection Phase - Collect all post-processors and required fields
    while True:
        current_traversed_nodes: Set[se_reqgraph.RGNode] = set()
        fields_to_add: Set[se_field.Field] = set()

        for node in se_reqgraph.traverse(request._graph.root_node):
            if node in traversed_nodes:
                continue

            current_traversed_nodes.add(node)

            value = node.value
            if value.post is None:
                continue

            if isinstance(value.post, list):
                post = value.post
            else:
                post = [value.post]

            post_procs = []
            for name in post:
                post_proc = resolvers.POST_RESOLVER.create(
                    name, value, request.context.environment.mode()
                )
                if post_proc is not None:
                    fields_to_add.update(post_proc.required_fields)
                    post_procs.append(post_proc)
            post_processors[node] = post_procs

        request.add_fields(fields_to_add, show_fields=False)

        if len(current_traversed_nodes) == 0:
            break
        else:
            traversed_nodes.update(current_traversed_nodes)

    # Apply Phase - Add post-processors in reveres topological order.

    field_post_processors: List[se_post_processor.PostProcessor] = []
    map_post_processors: List[se_post_processor.PostProcessor] = []

    for node in se_reqgraph.traverse(request._graph.root_node):
        value = node.value
        if value.post is None:
            continue

        if node.node_type == se_reqgraph.RGNodeType.FIELD:
            field_post_processors += post_processors[node]
        else:
            map_post_processors += post_processors[node]

    request.post_processors += field_post_processors + map_post_processors


def execute_post_process(result: pd.DataFrame, request: "se_request.FieldRequest"):
    """Execute post-processors in the correct order."""
    _LOG.debug("Running post processing for request %s", request)

    for proc in request.post_processors:
        _LOG.debug("Running post processor %s", proc)
        if proc:
            result = proc.apply(result)

    return result


def cleanup_dataframe(
    df: pd.DataFrame, request: "se_request.FieldRequest"
) -> pd.DataFrame:
    """Remove columns form DataFrame that were not requested."""

    fields_to_remove = find_fields_to_remove(request)
    _LOG.debug("Fields to be removed after post processing: %s", fields_to_remove)

    # Order and remove column
    columns_to_display = find_fields_to_extract(
        df.columns, fields_to_remove, request.requested_fields
    )
    _LOG.debug("Columns being displayed in result: %s", columns_to_display)
    df = df[columns_to_display]
    df.reset_index(inplace=True, drop=True)
    return df


def find_fields_to_remove(request: "se_request.FieldRequest"):
    """Create a set of fields that where not requested by the user."""
    all_field_names = [f.name for f in request._graph.get_all_fields()]
    fields_to_remove = set(all_field_names)
    fields_to_remove.difference_update([f.name for f in request.requested_fields])
    return fields_to_remove


def find_fields_to_extract(result_columns, fields_to_remove, requested_fields):
    """Create a set if fields that will be included in the df for the user."""
    columns = set(result_columns)
    columns.difference_update(fields_to_remove)
    columns.difference_update([f.name for f in requested_fields])
    columns_to_display = [f.name for f in requested_fields] + list(columns)
    return columns_to_display


# ---------------------------------------------------------------------------- #
#                                   Utilities                                  #
# ---------------------------------------------------------------------------- #


def generic_sorter(
    dataframe: pd.DataFrame, sorting_expression: List[se_expressions.SortExpression]
) -> pd.DataFrame:
    """Apply `sorting_expressions` to `dataframe` using pandas sorting capabilities.

    This will be used for all expressions the Environment is not able to sort.
    The `sorting_expressions` are applied with decreasing importance.

    Parameters
    ----------
    dataframe : pd.DataFrame
        _description_
    sorting_expression : List[se_expressions.SortExpression]
        _description_

    Returns
    -------
    pd.DataFrame
        _description_
    """

    _LOG.debug("Using generic sort")
    if not sorting_expression:
        _LOG.debug("No sort expressions in request")
        return dataframe

    columns = [exp.field.name for exp in sorting_expression]
    ascending = [
        exp.condition == se_expressions.SortCondition.ASC for exp in sorting_expression
    ]

    _LOG.debug("Columns sorted by generic sort %s with order %s", columns, ascending)

    dataframe.sort_values(by=columns, axis=0, ascending=ascending, inplace=True)
    dataframe.reset_index(drop=True, inplace=True)
    return dataframe


class _OperandStore:
    """Temporary store for operands used in `_resolve_generic_where_operand`.

    When a operand in a where expression is an arbitrary value not supported by other
    syntax, this store can be used to create a temporary dictionary of values.

    The `register_operand()` method inserts a value at the next available index.
    The index can then later be used to create `pandas.query` expression.
    """

    def __init__(self) -> None:
        self.index = 0
        self.operands: Dict[int, Any] = {}

    def register_operand(self, value: Any) -> int:
        """Register new operator value returning the next available index."""
        self.index += 1
        self.operands[self.index] = value
        return self.index


def _resolve_generic_where_operand(
    expression: se_expressions.WhereExpression, operand_store: _OperandStore = None
):
    value = expression.operands[0]
    if isinstance(value, se_field.Field):
        return f"`{value.name}`"
    if callable(value):
        value = value()
    if isinstance(value, str):
        return f"'{value}'"
    if isinstance(value, bool):
        return "True" if value else "False"
    if operand_store:
        return f"@STORE[{operand_store.register_operand(value)}]"
    return f"{value}"


def _resolve_generic_regex_parser(pattern: str) -> str:
    return pattern.replace(
        "%",
        r".*",
    ).replace("$", r"\$")


_GENERIC_WHERE_CALLABLE: Callable[
    [se_expressions.WhereExpression, "_GENERIC_WHERE_CALLABLE", _OperandStore], str
]

_GENERIC_WHERE_SWITCHER: Dict[
    se_expressions.WhereExpressionType, "_GENERIC_WHERE_CALLABLE"
] = {
    se_expressions.WhereExpressionType.OPERAND: lambda e, r, o: _resolve_generic_where_operand(
        e, o
    ),
    se_expressions.WhereExpressionType.EQ: lambda e, r, o: f"({r(e.operands[0],r,o)} == {r(e.operands[1],r,o)})",
    se_expressions.WhereExpressionType.NQ: lambda e, r, o: f"({r(e.operands[0],r,o)} != {r(e.operands[1],r,o)})",
    se_expressions.WhereExpressionType.GTE: lambda e, r, o: f"({r(e.operands[0],r,o)} >= {r(e.operands[1],r,o)})",
    se_expressions.WhereExpressionType.GT: lambda e, r, o: f"({r(e.operands[0],r,o)} > {r(e.operands[1],r,o)})",
    se_expressions.WhereExpressionType.LTE: lambda e, r, o: f"({r(e.operands[0],r,o)} <= {r(e.operands[1],r,o)})",
    se_expressions.WhereExpressionType.LT: lambda e, r, o: f"({r(e.operands[0],r,o)} < {r(e.operands[1],r,o)})",
    se_expressions.WhereExpressionType.LIKE: lambda e, r, o: f"({r(e.operands[0],r,o)}.str.fullmatch('{_resolve_generic_regex_parser(e.operands[1])}'))",
    se_expressions.WhereExpressionType.NLIKE: lambda e, r, o: f"(not {r(e.operands[0],r,o)}.str.fullmatch('{_resolve_generic_regex_parser(e.operands[1])}'))",
    se_expressions.WhereExpressionType.BETWEEN: lambda e, r, o: f"(({r(e.operands[0],r,o)} >= {r(e.operands[1],r,o)}) and ({r(e.operands[0],r,o)} <= {r(e.operands[2],r,o)}))",
    se_expressions.WhereExpressionType.NOT: lambda e, r, o: f"(not {r(e.operands[0],r,o)})",
    se_expressions.WhereExpressionType.AND: lambda e, r, o: f'({" and ".join([r(op,r,o) for op in e.operands])})',
    se_expressions.WhereExpressionType.OR: lambda e, r, o: f'({" or ".join([r(op,r,o) for op in e.operands])})',
}


def _resolve_generic_where_expression(
    expression: se_expressions.WhereExpression,
    resolver: "_GENERIC_WHERE_CALLABLE" = None,
    operand_store: _OperandStore = None,
) -> str:

    resolver = resolver or _resolve_generic_where_expression
    return _GENERIC_WHERE_SWITCHER.get(expression.operation, lambda: "")(
        expression, resolver, operand_store
    )


def generic_where_resolver(
    dataframe: pd.DataFrame, where_expressions: List[se_expressions.WhereExpression]
) -> pd.DataFrame:
    """Apply `where_expressions` to `dataframe` using `pandas.query()`.

    This will be used for all expressions the Environment is not able to resolve.
    All expression in `where_expressions` are logically AND connected.

    Parameters
    ----------
    dataframe : pd.DataFrame
        The DataFrame to filter.
    where_expressions : List[se_expressions.WhereExpression]
        List of expressions to apply.

    Returns
    -------
    pd.DataFrame
        Filtered DataFrame
    """

    operand_store: _OperandStore = _OperandStore()

    query_expression = " and ".join(
        [
            _resolve_generic_where_expression(e, operand_store=operand_store)
            for e in where_expressions
        ]
    )

    if query_expression:
        # The STORE variable needs to be kept for usage in the query_expression
        STORE = operand_store.operands  # pylint: disable=unused-variable,invalid-name
        dataframe.query(query_expression, engine="python", inplace=True)

    return dataframe


def optimize_memory_footprint(dataframe: pd.DataFrame, level: int) -> pd.DataFrame:
    """Optimize the memory usage of the dataframe.

    Converts the columns into most optimal datatypes.
    Assumes that the dataframe represents SMF data , so every 'object' in column is
    inherently string.

    Parameters
    ----------
    dataframe : pd.DataFrame
        Input dataframe
    level : int
        Level of optimization, ranges from 0 (no optimization) to 3 (maximum optimization)

    Returns
    -------
    pd.DataFrame
        Optimized dataframe

    Raises
    ------
    TypeError
        Memory optimization level must be an integer.
    """

    if level <= 0:
        return dataframe

    for col in dataframe.columns:
        dtype = dataframe[col].dtype

        if dtype == "string" and level >= 3:
            dataframe[col] = dataframe[col].str.strip()

        elif pd_types.is_numeric_dtype(dtype):
            max_value = dataframe[col].max()
            min_value = dataframe[col].min()
            if (
                not (pd.isna(min_value) or pd.isna(max_value))
                and pd_types.is_integer_dtype(dtype)
                and level >= 2
            ):
                if min_value >= 0:
                    if max_value < 255:
                        dataframe[col] = dataframe[col].astype("UInt8")
                    elif max_value < 65535:
                        dataframe[col] = dataframe[col].astype("UInt16")
                    elif max_value < 4294967295:
                        dataframe[col] = dataframe[col].astype("UInt32")
                    else:
                        dataframe[col] = dataframe[col].astype("UInt64")
                else:
                    if (
                        min_value > np.iinfo(np.int8).min
                        and max_value < np.iinfo(np.int8).max
                    ):
                        dataframe[col] = dataframe[col].astype("Int8")
                    elif (
                        min_value > np.iinfo(np.int16).min
                        and max_value < np.iinfo(np.int16).max
                    ):
                        dataframe[col] = dataframe[col].astype("Int16")
                    elif (
                        min_value > np.iinfo(np.int32).min
                        and max_value < np.iinfo(np.int32).max
                    ):
                        dataframe[col] = dataframe[col].astype("Int32")
                    else:
                        dataframe[col] = dataframe[col].astype("Int64")
            elif pd_types.is_float_dtype(dtype):
                dataframe[col] = dataframe[col].astype(np.float32)
    return dataframe
