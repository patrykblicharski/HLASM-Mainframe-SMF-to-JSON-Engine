# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Implementation for the Context object.

A `Context` connects requests, dataset names and environments.
"""
import logging
import warnings
from typing import AnyStr, Dict, List

import pandas as pd

import smfexplorer.core.environment as se_environment  # pylint: disable=unused-import
import smfexplorer.core.field as se_field  # pylint: disable=unused-import
import smfexplorer.core.request as se_request
import smfexplorer.core.samples as se_samples
import smfexplorer.resolvers
from smfexplorer import error

_LOG = logging.getLogger(__name__)

# ---------------------------------------------------------------------------- #
#                                    Context                                   #
# ---------------------------------------------------------------------------- #


class Context:
    """Context base class.

    Holds dataset related information and manages the lifecycle of requests.
    """

    @property
    def environment(self) -> "se_environment.Environment":
        """The environment used by this Context."""
        return self._environment

    @property
    def connector(self) -> "se_environment.Connector":
        """The Connector used by the Context."""
        warnings.warn(
            "The connector property is deprecated and will be removed in a future update",
            FutureWarning,
        )

        return self._environment.connector

    @property
    def parser(self) -> "se_environment.Parser":
        """The Parser used by the Context."""
        warnings.warn(
            "The parser property is deprecated and will be removed in a future update",
            FutureWarning,
        )
        return self._environment.parser

    def __init__(
        self, dataset_names: List[AnyStr], environment: "se_environment.Environment"
    ):
        self._dataset_names = dataset_names

        self._environment = environment

        self._samples_resolver = se_samples.SamplesResolver(
            smfexplorer.resolvers.SAMPLES, self
        )

        self._memory_optimization_level = 3

        self._supported_records: List[pd.DataFrame] = None
        self._dataset_descriptions: Dict[Dict] = None

    def get_dataset_description(self) -> Dict[str, Dict]:
        """Fetch a `Dict` of `Dict` objects containing metadata of the associated SMF dumps
           Each `Dict` object corresponds to a data set
        Raises:
            SmfExplorerError: If no dataset names are defined

        Returns
        -------
        Dictionary of Dictionary objects, each object contains the metadata for a dataset
        str
            Dict key: dataset name
        Dict
            Describes the metadata of the dataset in the form of a python dictionary.
            Dictionary items:
                creation_date: datetime.date
                    The creation date of the dataset
                count: int
                    Total number of records in the dataset
                system_ids: list
                    List of the system IDs having records in the dataset
                estimated_size_in_bytes:
                    Approximated byte-size of the raw dataset
                first_time_in_buffer: datetime.datetime
                    The earliest timestamp when the record of the SMF data was
                    moved into the SMF buffer
                last_time_in_buffer: datetime.datetime
                    The latest timestamp when the record of the SMF data was moved
                    into the SMF buffer
                earliest_start: datetime.datetime
                    The earliest timestamp when the measurement interval started
                    for the SMF data. Available for the records of those vendors
                    that are explicitly providing this information.
                    Otherwise NaT (non-datetime) value.
                lastest_start: datetime.datetime
                    The latest timestamp when the measurement interval started
                    for the SMF data. Available for the records of those vendors that are
                    explicitly providing this information.
                    Otherwise NaT (non-datetime) value.
                earliest_end: datetime.datetime
                    The earliest timestamp when the measurement ended for the SMF
                    data (based on the information of start and duration). Available for the
                    records of those vendors that are explicitly providing this information.
                    Otherwise NaT (non-datetime) value.
                lastest_end: datetime.datetime
                    The latest timestamp when the measurement ended for the SMF
                    data (based on the information of start and duration). Available for the
                    records of those vendors that are explicitly providing this information.
                    Otherwise NaT (non-datetime) value.
                type_info: DataFrame
                    List of (type-subtype) groups, together with metadata for each group
                    A subtype of `0` means that the type has no subtype.
                    == ==== ======= =====
                    type subtype count system IDs   estimated_size_in_bytes ...
                    == ==== ======= ===== ============ ======================= ...
                    0  2    0       2     [SysA]       12345                   ...
                    1  70   1       300   [SysA, SysB] 1234567                 ...
                    2  99   2       1200  [SysC]       4567                    ...
                    == ==== ======= ===== ============ ======================= ...

                        ... first_time_in_buffer last_time_in_buffer ...
                        ... ============================ =========================== ...
                        ... 2020-10-12 11:02:33.010      2020-10-13 11:59:33.010     ...
                        ... 2020-10-11 09:09:43.213      2020-11-13 11:59:33.010     ...
                        ... 2020-09-12 17:29:06.011      2020-12-13 11:59:33.010     ...
                        ... ============================ =========================== ...

                        ... earliest_start      lastest_start       earliest_end            lastest_end
                        ... =================== =================== ======================= =======================
                        ... 2020-10-12 19:14:33 2020-10-13 11:44:33 2020-10-12 19:29:33.000 2020-10-13 11:59:32.999
                        ...                 NaT 2020-10-13 11:44:33 2020-10-12 19:29:33.000 2020-10-13 11:59:32.999
                        ...                 NaT                 NaT                     NaT                     NaT
                        ... =================== =================== ======================= =======================
        """
        if not self._dataset_names:
            raise error.SmfExplorerError("Context has no dataset names defined")
        if not self._dataset_descriptions:
            results = {}
            for dataset_name in self._dataset_names:
                dataset_desc = self.environment.get_dataset_description(dataset_name)
                results[dataset_name] = dataset_desc
            self._dataset_descriptions = results
        return self._dataset_descriptions

    def get_available_records(self) -> pd.DataFrame:
        """Fetch the available records types and subtypes for the associated SMF dumps.

        Raises:
            SmfExplorerError: If no dataset names are defined

        Returns
        -------
        DataFrame
            List of type/subtypes and amount contained in the contexts datasets as
            pandas DataFrame.
            `Subtype` `0` means that the type has no subtype.
            The list is sorted by type and subtype.

                type    subtype     count
            0   2       0           2
            1   70      1           300
            2   99      2           1200
        """

        if not self._dataset_names:
            raise error.SmfExplorerError("Context has no dataset names defined")
        if self._supported_records is None:
            results = []
            for ds_name in self.dataset_names:
                results.append(self.environment.get_available_records(ds_name))

            self._supported_records = (
                pd.concat(results, ignore_index=True)
                .groupby(["type", "subtype"], as_index=False)
                .sum()
            )

            self._supported_records.reset_index(inplace=True, drop=True)
        return self._supported_records

    def get_available_types(self) -> pd.DataFrame:
        """Fetch the available record types for the associated SMF dumps.

        Raises:
            SmfExplorerError: If dataset names are not defined

        Returns
        -------
        DataFrame
            List of type and amount contained in the dataset as pandas DataFrame.
            The list is sorted by type.

                type    count
            0   2       2
            1   70      300
            2   99      1200
        """
        df = self.get_available_records()
        df = df.groupby(["type"], as_index=False).sum()[["type", "count"]]
        df.reset_index(inplace=True, drop=True)
        return df

    def get_available_subtypes(self, type_: int) -> pd.DataFrame:
        """Fetch the available record subtypes for `type_` in the associated SMF dumps.

        Args:
            type_ (int): The record type to fetch subtypes for

        Raises:
            SmfExplorerError: If dataset names are not defined

        Returns
        -------
        DataFrame
            List of subtype and amount contained in the dataset for `type_` as pandas
            DataFrame.
            `Subtype`  `0` means that the type has no subtype.
            The list is sorted by subtype.

                subtype count
            0   1       2
            1   12      300
            2   13      1200
        """
        df = self.get_available_records()

        df = df[df["type"] == type_]
        df.reset_index(inplace=True, drop=True)

        return df[["subtype", "count"]]

    def request(self, fields: List["se_field.Field"]) -> "se_request.FieldRequest":
        """Start a new `Request`.

        Parameters
        ----------
        fields : list of `Field`
            A list of fields to fetch.

        Returns
        -------
        Request
            A new `FieldRequest` object.

        Examples
        --------
        Requesting a list of fields.

        >>> ctx.request([COMMON.timestamp, SMF99S1.cp_util, SMF99S1.ziip_util])
        """
        _LOG.debug("New FieldRequest with fields: %s", fields)
        return se_request.FieldRequest(fields, self)

    def query(self, query: str) -> "se_request.QueryRequest":
        """Start a new `QueryRequest` by using a query.

        The kind of query depends on the context smfexplorer is running in.
        Currently only SQL is supported.

        Parameters
        ----------
        sql : str
            query to execute

        Returns
        -------
        Request
            A new `QueryRequest` object.

        Examples
        --------
        Requesting data using SQL(Only supported by the SQLContext).

        >>> ctx.query("SELECT * FROM SMF_09901")
        """
        _LOG.debug("New QueryRequest with query <<%s>>", query)
        return se_request.QueryRequest(query, self)

    @property
    def samples(self) -> "se_samples.SamplesResolver":
        """This object holds all registered samples.

        A user might add custom samples using the `register_sample()` classmethod or
        load predefined samples by importing a corresponding module.

        Examples
        --------
        Importing and using a sample for SMF 99 Subtype 1 data.

        >>> import smfexplorer.samples.smf_99_1
        >>> ctx.samples.cp_service().run()
            timestamp  cp_sys  cp_imp1  cp_imp2  cp_imp3  cp_imp4
        0   2019-11-05 13:37:00.550   33677        0        0        0        0
        1   2019-11-05 13:37:10.550   56554   326383        0        0        0
        2   2019-11-05 13:37:20.550   22760  1379976    15062        0        0

        """
        return self._samples_resolver

    @property
    def dataset_names(self) -> List[str]:
        """Name of the dataset currently associated with the context"""
        return self._dataset_names

    @dataset_names.setter
    def dataset_names(self, dataset_names: List[str]):
        self._dataset_names = dataset_names
        self._supported_records = None

    def check(self):
        """Run check on all dataset names defined for this context.

        Throws an exception as soon as an error is encountered.
        """
        if self.dataset_names is None:
            return

        for ds_name in self.dataset_names:
            if not self.environment.check_dataset_unsafe(ds_name):
                raise error.ConnectorError(
                    f"Unable to find dataset '{ds_name}'",
                    connector=self.environment.connector,
                    reason=error.ConnectorErrorReason.DATASET_NOT_FOUND,
                )
