# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""ART(Abstract request tree) is the mechanism to resolve requests using fields"""
import copy
import enum
import typing
from collections import deque
from typing import Deque, Iterable, List, Set, Union

import smfexplorer.error as error
from smfexplorer.core.field import Field, Record, RecordMap


class RGNodeType(enum.Enum):
    FIELD = 1
    MAP = 2
    RECORD = 3


class RGNode:
    def __init__(
        self,
        node_type: RGNodeType,
        parent: "RGNode" = None,
        field: Field = None,
        record: Record = None,
        record_map: RecordMap = None,
    ):
        self.node_type = node_type
        self.children: typing.Dict[RGNode, RGNode] = dict()
        self.parents: typing.Dict[RGNode, RGNode] = dict()
        self.parent = parent
        if parent:
            self.parents[parent] = parent
        self.field: Field = field
        self.record: Record = record
        self.record_map: RecordMap = record_map

    def __eq__(self, value):
        if self.node_type == value.node_type:
            if self.node_type == RGNodeType.FIELD:
                return self.field == value.field
            if self.node_type == RGNodeType.RECORD:
                return self.record == value.record
            if self.node_type == RGNodeType.MAP:
                return self.record_map == value.record_map
        return False

    def __hash__(self):
        return hash((self.node_type, self.record, self.record_map, self.field))

    def __str__(self, level=0):
        ret = "\t" * level + repr(self) + "\n"
        for child in self.children:
            ret += child.__str__(level + 1)
        return ret

    def __repr__(self):
        if self.node_type == RGNodeType.FIELD:
            info = f"""{self.field.name}{f"({','.join(f.name for f in self.field._ref) if isinstance(self.field._ref, Iterable) else self.field._ref.name})" if self.field.virtual else ''}"""
        elif self.node_type == RGNodeType.MAP:
            info = self.record_map.origin
        elif self.node_type == RGNodeType.RECORD:
            info = f"{self.record.smf_type}_{self.record.smf_subtype}"
        return f"<RGNode:{self.node_type}:{info}>"

    def __deepcopy__(self, memo):
        dup = RGNode(self.node_type)

        dup.parent = copy.deepcopy(self.parent, memo)
        dup.parents = copy.deepcopy(self.parents, memo)
        dup.children = copy.deepcopy(self.children, memo)

        dup.field = self.field
        dup.record = self.record
        dup.record_map = self.record_map

        return dup

    def deep_eq(self, value: "RGNode") -> bool:
        if self == value:
            if self.parent != value.parent:
                return False
            for child in self.children:
                if child not in value.children:
                    return False
            for child in value.children:
                if child not in self.children:
                    return False

            for child in self.children:
                if not child.deep_eq(value.children[child]):
                    return False

        return True

    def get_all_children_of_type(self, node_type: RGNodeType):
        result = list()
        for child in self.children:
            if child.node_type == node_type:
                result.insert(0, child)
            result = child.get_all_children_of_type(node_type) + result

        return result

    @property
    def name(self) -> str:
        if self.node_type == RGNodeType.FIELD:
            return self.field.name
        elif self.node_type == RGNodeType.MAP:
            return self.record_map.name
        elif self.node_type == RGNodeType.RECORD:
            return self.record.name

    @property
    def value(self) -> Union[Field, Record, RecordMap]:
        if self.node_type == RGNodeType.FIELD:
            return self.field
        elif self.node_type == RGNodeType.MAP:
            return self.record_map
        elif self.node_type == RGNodeType.RECORD:
            return self.record


class RequestGraph:
    def __init__(self, root_node: RGNode = None):
        self.root_node: RGNode = root_node
        self.nodes: typing.Dict[RGNode, RGNode] = dict()

    def __eq__(self, value):
        if self.root_node and value.root_node and self.nodes == value.nodes:
            return self.root_node.deep_eq(value.root_node)
        return False

    def get_all_nodes_of_type(self, node_type: RGNodeType):
        if self.root_node:
            return self.root_node.get_all_children_of_type(node_type)
        else:
            return list()

    def get_all_fields_ordered(self):
        return [n.field for n in self.get_all_nodes_of_type(RGNodeType.FIELD)]

    def get_all_fields(self):
        result = list()
        for node in self.nodes:
            if node.node_type == RGNodeType.FIELD:
                result.append(node.field)

        return result


def resolve_record_node(record: Record) -> RGNode:
    return RGNode(RGNodeType.RECORD, record=record)


def resolve_record_map_node(record_map: RecordMap) -> RGNode:
    node = RGNode(RGNodeType.MAP, record_map=record_map)
    if record_map.parent:
        parent_node = resolve_record_map_node(record_map.parent)
    else:
        parent_node = resolve_record_node(record_map.record)

    parent_node.children[node] = node
    node.parent = parent_node

    return node


def resolve_field_node(field: Field) -> RGNode:
    node = RGNode(RGNodeType.FIELD, field=field)
    # if field.virtual:
    if field._ref is not None:
        if isinstance(field._ref, list):
            for ref in field._ref:
                parent = resolve_field_node(ref)
                parent.children[node] = node
                node.parent = parent
                node.parents[parent] = parent
        else:
            parent = resolve_field_node(field._ref)
            parent.children[node] = node
            node.parent = parent
            node.parents[parent] = parent

    if node.parents:
        return node

    if field.record_map:
        parent_node = resolve_record_map_node(field.record_map)
    elif field.record:
        parent_node = resolve_record_node(field.record)
    else:
        parent_node = RGNode(RGNodeType.RECORD, record=None)

    parent_node.children[node] = node
    node.parent = parent_node

    return node


def insert_node_into_tree(
    tree: RequestGraph, node: RGNode, prev: RGNode = None
) -> RGNode:
    if node.node_type == RGNodeType.RECORD:
        if tree.root_node and tree.root_node.record:
            if tree.root_node.record == node.record or not node.record:
                tree.root_node.children[prev] = prev
                return tree.root_node
            else:
                raise error.RGError(
                    f"Tried to add record {node.record} while record {tree.root_node.record} is already present"
                )
        if tree.root_node:
            tree.root_node.record = node.record
            tree.root_node.children[prev] = prev
            return tree.root_node
        tree.root_node = node
        return node
    elif node in tree.nodes.keys():
        existing_node = tree.nodes[node]
        if prev:
            existing_node.children[prev] = prev
        return existing_node
    else:
        if node.node_type == RGNodeType.FIELD and node.field.virtual:
            for parent in list(node.parents):
                parent_node = insert_node_into_tree(tree, parent, node)
                if node.parent == parent:
                    node.parent = parent_node
                del node.parents[parent]
                node.parents[parent_node] = parent_node
        else:
            parent_node = insert_node_into_tree(tree, node.parent, node)
            node.parent = parent_node
        tree.nodes[node] = node
        return node


def traverse(start_node: RGNode, types: List[RGNodeType] = None) -> List[RGNode]:
    """Iterator to traverse over a graph, starting from a given start_node.

    The nodes yielded by the returned generator are in topological order.

    Parameters
    ----------
    start_node : RGNode
        Start node of the graph.
    types : List[RGNodeType], optional
        List of RGNode types that generator returns, by default None

    Yields
    -------
    Generator[RGNode, None, None]
        Graph node generator.
    """

    stack: Deque[RGNode] = deque()
    visited: Set[RGNode] = set()

    def dfs(node: RGNode):
        if node not in visited:

            for child in node.children:
                dfs(child)

            if (types and node.node_type in types) or not types:
                stack.appendleft(node)
            visited.add(node)

    dfs(start_node)

    return list(stack)
