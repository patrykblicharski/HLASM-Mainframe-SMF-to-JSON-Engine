# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Module hold Request type"""
import copy
import functools
import logging
import uuid
import warnings
from abc import ABC
from datetime import datetime
from typing import Callable, Dict, Iterable, List, Set, Tuple

import pandas as pd
from numpy import record

import smfexplorer.core.context
import smfexplorer.core.request_graph as reqgraph
from smfexplorer.core import executor
from smfexplorer.core.expressions import SortExpression, WhereExpression
from smfexplorer.core.field import Field, Record
from smfexplorer.core.post_processor import PostProcessor, PostProcessorType
from smfexplorer.error import RequestError, wrap_exception

LOG = logging.getLogger(__name__)


def _immutable(deep_copy=True):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(self, *args, immutable=True, **kwargs):
            instance = self
            if immutable:
                instance = copy.deepcopy(instance) if deep_copy else copy.copy(instance)
            return func(instance, *args, **kwargs)

        return wrapper

    return decorator


class Request(ABC):
    """Request base class"""

    def __init__(
        self, context: "smfexplorer.core.context.Context" = None, _id=None, _subid=0
    ):
        super().__init__()
        self.context = context
        #  Request have a unique id and a subid that is increased on every immutable transformation
        self._id = _id if _id else uuid.uuid4()
        self._subid = _subid

    @wrap_exception(LOG, "Exception during request execution")
    def run(self, dry_run: bool = False) -> pd.DataFrame:
        """Execute a `Request`

        Parameters
        ----------
        dry_run : bool
            Makes run return the generated queries and prevents fetching, by default False

        Returns
        -------
        data_frame: Dataframe
            A pandas dataframe holding the result.

        Raises
        ------
        Exception
            No connection found.
        """

        result = executor.run(self, dry_run=dry_run)
        if dry_run:
            dataset_names = []
            queries = []
            for query in result:
                dataset_names.append(query.dataset_name)
                queries.append(query.raw)
            result = pd.DataFrame({"Dataset Name": dataset_names, "Query": queries})

        return result

    @wrap_exception(LOG, "Exception during request execution")
    def exec(self) -> pd.DataFrame:
        """Execute a `Request` (Deprecated use run() instead)

        Returns
        -------
        data_frame: Dataframe
            A pandas dataframe holding the result.

        Raises
        ------
        Exception
            No connection found.
        """
        warnings.warn(
            "The exec Function is deprecated. Please use the run Function",
            FutureWarning,
        )
        return self.run()

    def __deepcopy__(self, memo):
        return Request(self.context, _id=self._id, _subid=self._subid + 1)

    def __repr__(self):
        return f"<{self.__class__.__name__}:{self._id}:{self._subid}>"


class FieldRequest(Request):
    """Request to fetch data using the fields syntax"""

    def __init__(
        self,
        fields: List[Field],
        context=None,
        _id=None,
        _subid=0,
        start_time=None,
        end_time=None,
        system_name=None,
    ):
        super().__init__(context, _id=_id, _subid=_subid)
        self.where_expressions: List[WhereExpression] = []
        self.sort_expressions: List[SortExpression] = []
        self.post_processors: List[PostProcessor] = []

        self._field_post_procs: Dict[Field, PostProcessor] = []

        self.requested_fields: List[Field] = list()
        self.fields: Set[Field] = set()

        self._graph: reqgraph.RequestGraph = reqgraph.RequestGraph()

        self.add_fields(fields)
        self.limit_option = None
        self.start_time = start_time
        self.end_time = end_time
        self.system_name = system_name

    def __deepcopy__(self, memo):
        dup = FieldRequest(
            [], context=self.context, _id=self._id, _subid=self._subid + 1
        )
        dup.requested_fields = copy.copy(self.requested_fields)
        dup.where_expressions = copy.copy(self.where_expressions)
        dup.sort_expressions = copy.copy(self.sort_expressions)
        dup.post_processors = copy.deepcopy(self.post_processors, memo)

        dup._graph = copy.deepcopy(self._graph, memo)
        dup._field_post_procs = copy.copy(self._field_post_procs)

        dup.fields = copy.copy(self.fields)
        dup.requested_fields = copy.copy(self.requested_fields)
        dup.limit_option = self.limit_option

        dup.system_name = self.system_name
        dup.end_time = self.end_time
        dup.start_time = self.start_time

        return dup

    @wrap_exception(LOG, "Exception while adding a field")
    def add_field(self, field: Field, show_field=True):
        """Add a field to the request.

        Parameters
        ----------
        field : Field
            The `Field` to add
        show_field : bool, optional
            if `False` the field will be fetched but not shown in result, by default True.

            Setting `show_field` to False is mainly used internally
        """
        field_node = reqgraph.resolve_field_node(field)

        if show_field and field not in self.requested_fields:
            self.requested_fields.append(field)

        if field in self.fields:
            return

        reqgraph.insert_node_into_tree(self._graph, field_node)

        self.fields.add(field)

    def add_fields(self, fields: Iterable[Field], show_fields=True):
        """Add a `list` of fields to a request.

        Parameters
        ----------
        fields : List[Field]
            Fields to add
        show_fields : bool, optional
            if `False` the fields will be fetched but not shown in result, by default True
        """
        for field in fields:
            self.add_field(field, show_fields)

    # Pre Phase Methods
    @_immutable()
    @wrap_exception(LOG, "Exception while adding where expression")
    def where(self, *expressions: WhereExpression) -> "FieldRequest":
        """Add where expressions

        Parameters
        ----------
        expressions: WhereExpression
            Any number of where expressiond that should be applied. Each where
            expression is connected with the AND operator.

        Returns
        -------
        Request
            Reconfigured `Request`.

        Raises
        ------
        Exception
            Exception is thrown when the request is in sql mode.

        Notes
        -----
        Multiple calls to ``where()`` will AND connect the expressions.

        This function is a pre processing step which changes a request before it is executed.
        Users should try to use ``where()`` instead of ``filter()`` if possible.
        Doing so improves performance and reduces the amount of data transferred.
        """
        self.where_expressions.extend(expressions)
        return self

    @_immutable()
    @wrap_exception(LOG, "Exception while adding sort statement")
    def sort(self, *conditions: SortExpression) -> "FieldRequest":
        """Add a sort condition to the `Request`.

        Parameters
        ----------
        *conditions: list of SortExpression
            All sort conditions ordered by priority

        Returns
        -------
        Request
            Reconfigured `Request`.

        Raises
        ------
        Exception
            Thrown when used in sql mode or virtual field was used.

        Notes
        -----
        Sort can be called multiple times which will concatenate the lists of expressions.
        """
        for condition in conditions:
            self.sort_expressions.append(condition)
            self.add_field(condition.field, show_field=False)
        return self

    @_immutable()
    def in_time(
        self, start_time: datetime = None, end_time: datetime = None
    ) -> "Request":
        self.start_time = start_time
        self.end_time = end_time
        return self

    @_immutable()
    def of_system(self, system_name: str) -> "Request":
        self.system_name = system_name
        return self

    @_immutable()
    def limit(self, limit: int) -> "Request":
        """Limit the amount of entries in the resulting data frame.

        Parameters
        ----------
        limit: int
            Number if entries to fetch.

        Returns
        -------
        Request
            Reconfigured `Request`
        """
        if limit <= 0:
            raise ValueError("Invalid limit. Limit must be positive")

        self.limit_option = limit
        return self

    @_immutable()
    @wrap_exception(LOG, "Exception while specifying record")
    def from_record(self, record: Record) -> "FieldRequest":
        """Set the `Record` to fetch from.
        This might be necessary when only Fields are requested that don't have a Specific Record.

        Parameters
        ----------
        record: Record
            `Record` to use for the `Request`.

        Returns
        -------
        Request
            Reconfigured `Request`
        """
        reqgraph.insert_node_into_tree(
            self._graph, reqgraph.resolve_record_node(record)
        )
        return self

    # Post Phase Methods
    @_immutable()
    def filter(self, callback: Callable[[pd.Series], bool]) -> "Request":
        """Filter results with callback.

        Parameters
        ----------
        callback: Callback[[pd.Series], bool]
            The callback to use for filter decision. Gets each entry as pandas `Series`.
            When `callback` returns `False` the entry is removed from the result.

        Returns
        -------
        Request
            Reconfigured `Request`
        """
        if not callback:
            raise TypeError("Argument callback is None")

        return self.add_post_processor(
            PostProcessor(PostProcessorType.FILTER, callback)
        )

    @_immutable()
    def map(self, callback: Callable[[pd.Series], pd.Series]) -> "Request":
        """Map results with callback. Allows operation on every entry in the result.

        Parameters
        ----------
        callback: Callback[[pd.Series], bool]
            The callback to use for the transformation. Gets each entry as pandas `Series`.
            Should return a pandas `Series` with any modifications wanted.

        Returns
        -------
        Request
            Reconfigured `Request`
        """
        if not callback:
            raise TypeError("Argument callback is None")

        return self.add_post_processor(PostProcessor(PostProcessorType.MAP, callback))

    @_immutable()
    @wrap_exception(LOG, "Exception while adding post processor")
    def add_post_processor(self, post_processor: PostProcessor) -> "Request":
        """Add a custom `PostProcessor` to the request.

        Parameters
        ----------
        post_processor: PostProcessor
            `PostProcessor` to add.

        Returns
        -------
        Request
            Reconfigured `Request`
        """
        if not post_processor:
            raise TypeError("Argument post_processor is None")

        self.post_processors.append(post_processor)
        self.add_fields(post_processor.required_fields, show_fields=False)
        return self

    @_immutable()
    @wrap_exception(LOG, "Exception during request execution")
    def run(
        self,
        *,
        dry_run: bool = False,
        display: List[Field] = None,
        indices: bool = False,
    ) -> pd.DataFrame:
        """Run the `FieldRequest`

        Parameters
        ----------
        display : list of `Field`, optional
            Additional fields to fetch with this execution, by default None
        dry_run : bool, optional
            Makes run return the generated queries and prevents fetching, by default False
        indices: bool, optional
            Add all record and section indices to the request, by default False

        Returns
        -------
        data_frame: Dataframe
            A pandas dataframe holding the result.
        """
        if display:
            self.add_fields(display)

        if indices:
            self.add_fields(self.indices)

        if not self._graph.root_node.record:
            raise RequestError(
                "No Record defined. All requested fields are ambiguous. Specify the record with from_record().",
                request=self,
            )

        return super().run(dry_run=dry_run)

    @_immutable()
    @wrap_exception(LOG, "Exception during request execution")
    def exec(self, *, display: List[Field] = None) -> pd.DataFrame:
        """Execute the `FieldRequest`

        Parameters
        ----------
        display : list of `Field`, optional
            Additional fields to fetch with this execution, by default None

        Returns
        -------
        data_frame: Dataframe
            A pandas dataframe holding the result.
        """

        warnings.warn(
            "The exec Function is deprecated. Please use the run Function",
            FutureWarning,
        )

        return self.run(display=display)

    def graph(self, fields: bool = True):
        """Create a graphviz Digraph representing the request.

        This only works if graphviz is installed.

        If the `fields` argument is false, only the record and record_map nodes of
        the request graph are printed. This can improve readability on large requests.

        Edges between map_nodes and their parents are marked with their cardinality (`1:1` or `1:n`).

        Legend:
            Tripple-Octagon: Record node. The root of the request graph.
            Double-Octagon: Record Map node.
            Ellipse: Field that is virtual or has children.
            Note: List of all remaining fields (In one node for readability).

        Args:
            fields (bool, optional): Specify if fields should be included. Defaults to True.

        Returns:
            [type]: [description]
        """
        try:
            from graphviz import Digraph
        except ImportError:
            warnings.warn("Graphviz is not installed. Cannot create graphs.")
            return None

        import textwrap

        dot = Digraph()
        dot.attr(rankdir="LR")

        simple_fields: Dict[str, List[str]] = {}

        for node in reqgraph.traverse(
            self._graph.root_node,
            types=(
                None
                if fields
                else [reqgraph.RGNodeType.RECORD, reqgraph.RGNodeType.MAP]
            ),
        ):
            if node.node_type == reqgraph.RGNodeType.RECORD:
                dot.node(
                    node.name,
                    label=f"{node.record.name}",
                    shape="tripleoctagon",
                    root="true",
                )
            elif node.node_type == reqgraph.RGNodeType.MAP:
                node_hash = node.name
                dot.node(
                    node_hash,
                    label=f"{node.record_map.name}",
                    shape="octagon" if node.record_map.is_compound else "doubleoctagon",
                )
                if node.parent:
                    dot.edge(
                        node.parent.name,
                        node_hash,
                        label=(
                            "1:N"
                            if (
                                node.record_map.is_multiple
                                or node.record_map.is_compound
                            )
                            else "1:1"
                        ),
                    )

            elif node.node_type == reqgraph.RGNodeType.FIELD:
                node_hash = node.name

                if (
                    not node.children
                    and node.parent.node_type != reqgraph.RGNodeType.FIELD
                ):
                    parent_hash = node.parent.name
                    if parent_hash not in simple_fields:
                        simple_fields[parent_hash] = []
                    simple_fields[parent_hash].append(node.field.name)
                else:
                    dot.node(
                        node_hash,
                        label=f"{node.field.name}",
                        color="deepskyblue" if node.field.virtual else None,
                    )
                    if node.parents:
                        for parent in node.parents.values():
                            dot.edge(parent.name, node_hash)
                    elif node.parent:
                        dot.edge(node.parent.name, node_hash)

        for parent_hash, field_names in simple_fields.items():
            node_hash = parent_hash + "####"
            dot.node(
                node_hash, label=textwrap.fill(", ".join(field_names)), shape="note"
            )
            dot.edge(parent_hash, node_hash)

        return dot

    @property
    def indices(self) -> List[Field]:
        """List of all record and map index fields for the request"""

        return (
            [self._graph.root_node.record.index] if self._graph.root_node.record else []
        ) + [
            e.record_map.index
            for e in reqgraph.traverse(
                self._graph.root_node, types=[reqgraph.RGNodeType.MAP]
            )
        ]


class QueryRequest(Request):
    def __init__(self, query: str, context=None, _id=None, _subid=0):
        super().__init__(context, _id=_id, _subid=_subid)
        self.query = query
