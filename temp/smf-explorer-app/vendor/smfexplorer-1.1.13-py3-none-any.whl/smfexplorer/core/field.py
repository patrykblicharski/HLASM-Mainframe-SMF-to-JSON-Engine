# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Module defines classes for Basic SMF constructs."""

import copy as _copy
import dataclasses as _dataclasses
import enum as _enum
import typing as _t

import pandas as pd

import smfexplorer.core.expressions as expressions


class FieldType(_enum.Enum):
    """Enumeration to specify available SMF field types"""

    UNDEFINED = ("object", "undefined", None)

    # Number Types
    FLOAT = ("Float32", "number", "double")
    INTEGER = ("Int64", "integer", "int64")
    UNSIGNED = ("UInt64", "integer", "uint64")

    # String Types
    STRING = ("string", "string", None)
    DATE = ("object", "string", "date")
    TIME = ("object", "string", "time")
    TIMEDELTA = ("timedelta64[ns]", "string", "timedelta")
    DATETIME = ("datetime64[ns]", "string", "date-time")

    def __init__(self, pandas_type: str, origin_type: str, origin_format: str) -> None:
        super().__init__()
        self.pandas_type: str = pandas_type
        self.origin_type: str = origin_type
        self.origin_format: str = origin_format


@_dataclasses.dataclass(frozen=True, eq=False, repr=False)
class Record:
    """`Record` holds information about a SMF record."""

    smf_type: int
    smf_subtype: int
    spec: str
    post: _t.Union[str, _t.Iterable[str]]

    fields: _t.Set["Field"] = _dataclasses.field(init=False, default_factory=set)
    maps: _t.Set["RecordMap"] = _dataclasses.field(init=False, default_factory=set)
    _index_field: "Field" = None

    def __post_init__(self):
        object.__setattr__(self, "__doc__", self.spec)
        object.__setattr__(
            self,
            "_index_field",
            Field(
                name=f"smf{self.smf_type:03d}{self.smf_subtype:02d}_index",
                origin=None,
                type=FieldType.UNSIGNED,
                record=self,
                pseudo_field=PseudoField.RECORD_INDEX,
            ),
        )

        # TODO: Check usage
        # self.base_key = Field(f"base_key_{self.name}"[:30], "BASE_KEY", self)

    # @property
    # def table_name(self):
    #     return f"SMF_{self.smf_type:03}{self.smf_subtype:02}"

    # @property
    # def name(self):

    @property
    def name(self):
        if not self.smf_type:
            return "COMMON"
        if self.smf_subtype:
            return f"SMF{self.smf_type:03}S{self.smf_subtype:02}"
        else:
            return f"SMF{self.smf_type:03}"

    @property
    def index(self) -> "Field":
        """Numeric index of the record starting at 1.

        Each original record has exactly one record index.
        This allows to distinguish records, when there are multiple entries for one record in the resulting dataset.
        """
        return self._index_field

    def __eq__(self, other):
        if other.__class__ is self.__class__:
            return (
                self.smf_type == other.smf_type
                and self.smf_subtype == other.smf_subtype
            )
        return False

    def __hash__(self):
        return hash((self.smf_type, self.smf_subtype))

    def __repr__(self):
        return f"<Record:{self.smf_type}-{self.smf_subtype}>"

    # def __deepcopy__(self, memo):
    #     return self


# @_dataclasses.dataclass(frozen=True, eq=False, repr=False)
# class DGMapInfo:
#     dg_name: str
#     dg_is_map: bool


@_dataclasses.dataclass(frozen=True, eq=False, repr=False)
class RecordMap:
    """`RecordMap` holds information about a SMF record map."""

    origin: str
    record: Record
    parent: "RecordMap"
    is_multiple: bool

    spec: str
    post: _t.Union[str, _t.Iterable[str]]
    # dg_info: DGMapInfo
    record_mapping: bool

    fields: _t.Set["Field"] = _dataclasses.field(init=False, default_factory=set)

    _index_field: "Field" = None
    is_compound: bool = False

    def __post_init__(self):
        if self.record is not None:
            self.record.maps.add(self)
        object.__setattr__(self, "__doc__", self.spec)

        object.__setattr__(
            self,
            "_index_field",
            Field(
                name=f"smf{self.record.smf_type:03d}{self.record.smf_subtype:02d}_{self.origin.lower()}_index",
                type=FieldType.UNSIGNED,
                record=self.record,
                record_map=self,
                pseudo_field=PseudoField.MAP_INDEX,
            ),
        )

        # self.row_index = Field(f"row_index_{name}"[:30], "ROW_INDEX", record,
        #                       self)

    # def qualifier(self) -> str:
    #     if self.parent:
    #         return self.parent.qualifier(
    #         ) + "." + f"smf{self.record.smf_type}Subtype{self.record.smf_subtype}{re.sub(r'_([a-z])', lambda pat: pat.group(1).upper(),'_' + self.dg_name.lower())}"
    #     else:
    #         return f"smf{self.record.smf_type}Subtype{self.record.smf_subtype}{re.sub(r'_([a-z])', lambda pat: pat.group(1).upper(), '_' + self.dg_name.lower())}"

    @property
    def name(self) -> str:
        return self.origin

    @property
    def index(self) -> "Field":
        """Numeric index of the record map starting at 1.

        Each entry in a record map has a locally unique index per record.
        This allows to distinguish record maps, when there are multiple entries for one record map in the resulting dataset.
        """
        return self._index_field

    def __eq__(self, other):
        if self.__class__ is other.__class__:
            return self.origin == other.origin and self.record == other.record
        return False

    def __hash__(self):
        return hash((self.origin, self.record))

    def __repr__(self):
        return f"<RecordMap:{self.origin}:{self.record!r}>"

    # def __deepcopy__(self, memo):
    #     return self


@_dataclasses.dataclass(frozen=True, eq=False, repr=False)
class DGFieldInfo:
    dg_name: str = None


class PseudoField(_enum.Enum):
    ABSTRACT_FIELD = _enum.auto()
    HEADER_FLG = _enum.auto()
    HEADER_RTY = _enum.auto()
    HEADER_TIME = _enum.auto()
    HEADER_DATE = _enum.auto()
    HEADER_SID = _enum.auto()
    HEADER_WID = _enum.auto()
    HEADER_STP = _enum.auto()
    RECORD_INDEX = _enum.auto()
    MAP_INDEX = _enum.auto()
    DATASET_INDEX = _enum.auto()
    ARRAY_FIELD = _enum.auto()


class Field:
    """`Field` holds information about a SMF field or a virtual field."""

    def __init__(
        self,
        name: str = None,
        origin: str = None,
        type: FieldType = FieldType.UNDEFINED,
        record: Record = None,
        record_map: RecordMap = None,
        post: _t.Union[str, _t.Callable[[pd.DataFrame], pd.Series]] = None,
        post_param: _t.Any = None,
        virtual: bool = False,
        ref: _t.Union["Field", _t.Iterable["Field"]] = None,
        pseudo_field: PseudoField = None,
        array_index: int = None,
    ) -> None:
        self._name = name
        self._origin = origin
        self._type = type
        self._record = record
        self._record_map = record_map
        self._post = post
        self._post_param = post_param
        self._virtual = virtual
        self._ref = ref
        self._pseudo_field = pseudo_field
        self._array_index = array_index

        self._raw: "Field" = None
        self._array_field_cache: _t.Optional[_t.Dict[int, "Field"]] = None

        if self._pseudo_field not in [PseudoField.RECORD_INDEX, PseudoField.MAP_INDEX]:
            if self._record_map is not None:
                self._record_map.fields.add(self)
            elif self._record is not None:
                self._record.fields.add(self)

    @property
    def name(self):
        return self._name

    @property
    def origin(self):
        return self._origin

    @property
    def type(self):
        return self._type

    @property
    def record(self):
        return self._record

    @property
    def record_map(self):
        return self._record_map

    @property
    def virtual(self):
        return self._virtual

    @property
    def post(self):
        return self._post

    def __eq__(self, other):
        if type(other) is str:
            return expressions.LIKE(self, other)
        else:
            return expressions.EQ(self, other)

    def __ne__(self, other) -> expressions.WhereExpression:
        if type(other) is str:
            return expressions.NLIKE(self, other)
        else:
            return expressions.NQ(self, other)

    def __gt__(self, other) -> expressions.WhereExpression:
        return expressions.GT(self, other)

    def __lt__(self, other) -> expressions.WhereExpression:
        return expressions.LT(self, other)

    def __ge__(self, other) -> expressions.WhereExpression:
        return expressions.GTE(self, other)

    def __le__(self, other) -> expressions.WhereExpression:
        return expressions.LTE(self, other)

    def __hash__(self):
        return hash((self._name, self._origin, self._raw))

    def __repr__(self):
        return f"<Field:{self._name}:{self._origin}{':(V)' if self._virtual else ''}:{self._record_map!r}>"

    def __str__(self):
        return self._name

    # def __call__(self):
    #     return self._name

    @_t.overload
    def __getitem__(self, key: int) -> "Field": ...

    @_t.overload
    def __getitem__(self, key: slice) -> _t.List["Field"]: ...

    def __getitem__(
        self, key: _t.Union[int, slice]
    ) -> _t.Union["Field", _t.List["Field"]]:

        if self._pseudo_field != PseudoField.ARRAY_FIELD:
            raise IndexError(f"The field '{self._name}' is not an array field")

        if isinstance(key, slice):
            return [self[index] for index in range(*key.indices(len(self)))]

        if not isinstance(key, int):
            raise TypeError(
                f"Array field indices must be integers, not {type(key).__name__}"
            )

        if key < 0:
            key = len(self) + key

        if key >= self._array_index or key < 0:
            raise IndexError(f"The field '{self._name}' has no index '{key}'")

        if self._array_field_cache is None:
            self._array_field_cache = {}

        if key not in self._array_field_cache:
            self._array_field_cache[key] = Field(
                name=f"{self._name}[{key}]",
                origin=self._origin,
                post=self._post,
                post_param=self._post_param,
                virtual=False,
                ref=self,
                type=self._type,
                record=self._record,
                record_map=self._record_map,
                array_index=key,
            )

        return self._array_field_cache[key]

    def __len__(self):
        if self._pseudo_field == PseudoField.ARRAY_FIELD:
            return self._array_index
        return 0

    @property
    def raw(self) -> "Field":
        """Returns a definition of the field without post-processors.

        If the field is virtual and is based on another field, `raw` returns the base field.

        This will not work for virtual fields with multiple parents.
        The field itself will be returned in such cases.
        """
        if self._raw is None:
            if self._virtual:
                if isinstance(self._ref, Field):
                    self._raw = self._ref
                else:
                    self._raw = self
            else:
                raw_field = _copy.copy(self)
                raw_field._name = self._name + "_raw"
                raw_field._post = None
                self._raw = raw_field
        return self._raw
