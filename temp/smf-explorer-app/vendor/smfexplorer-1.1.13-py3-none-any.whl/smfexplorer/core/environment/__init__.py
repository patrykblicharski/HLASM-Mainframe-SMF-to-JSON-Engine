# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""The environment module implements all backend specific code.

The `Query`, `Connector`, `Parser` and `Environment` base classes define the interface
used to implement specific backends to fetch data.
"""
import abc
from typing import Dict, Iterable, List, Union

import pandas as pd

from smfexplorer import error, util
from smfexplorer.core import context, request


class Query(abc.ABC):
    """A `Query` holds information for a `Connector` to execute request."""

    def __init__(self, dataset_name: str):
        self._dataset_name = dataset_name

    @property
    def dataset_name(self) -> str:
        """Name of the dataset used for this `Query`."""
        return self._dataset_name

    @property
    @abc.abstractmethod
    def raw(self) -> str:
        """Return raw representation of the query."""


class Connector(abc.ABC):
    """A `Connector` manages the connection to a backend and executes `Query`s."""

    @abc.abstractmethod
    def query(self, query: Query) -> pd.DataFrame:
        """Execute a `Query`.

        Parameters
        ----------
        query : Query
            The `Query` to execute.

        Returns
        -------
        dataframe: pandas.Dataframe
            Resulting raw dataframe.
        """

    @abc.abstractmethod
    def check_dataset_unsafe(self, dataset_name: str) -> bool:
        """Check if the current dataset is available.

        Raises an exception when the check fails with more information on the reason.

        Parameters
        ----------
        dataset_name : str
            Name of the dataset to check.

        Returns
        -------
        bool
            Result of check.
        """

    def check_dataset(self, dataset_name: str) -> bool:
        """Check if the current dataset is available.

        Returns false if any error occurs.
        Use `check_dataset_unsafe` to get an exception with potentially more
        information.

        Parameters
        ----------
        dataset_name : str
            Name of the dataset to check.

        Returns
        -------
        bool
            Result of check.
        """
        try:
            return self.check_dataset_unsafe(dataset_name)
        except error.SmfExplorerError:
            return False

    @abc.abstractmethod
    def fetch_dataset_description(self, dataset_name: str) -> pd.DataFrame:
        """Fetch a `Dict` containing metadata of the `dataset_name`

        Parameters
        ----------
        dataset_name : str
            Name of the Dataset to fetch information for.

        Returns
        -------
        Dict
            Describes the metadata of the dataset in the form of a python dictionary.
            Dictionary items:
                creation_date: datetime.date
                    The creation date of the dataset
                count: int
                    Total number of records in the dataset
                system_ids: list
                    List of the system IDs having records in the dataset
                estimated_size_in_bytes:
                    Approximated byte-size of the raw dataset
                first_time_in_buffer: datetime.datetime
                    The earliest timestamp when the record of the SMF data was
                    moved into the SMF buffer
                last_time_in_buffer: datetime.datetime
                    The latest timestamp when the record of the SMF data was moved
                    into the SMF buffer
                earliest_start: datetime.datetime
                    The earliest timestamp when the measurement interval started
                    for the SMF data. Available for the records of those vendors
                    that are explicitly providing this information.
                    Otherwise NaT (non-datetime) value.
                lastest_start: datetime.datetime
                    The latest timestamp when the measurement interval started
                    for the SMF data. Available for the records of those vendors that are
                    explicitly providing this information.
                    Otherwise NaT (non-datetime) value.
                earliest_end: datetime.datetime
                    The earliest timestamp when the measurement ended for the SMF
                    data (based on the information of start and duration). Available for the
                    records of those vendors that are explicitly providing this information.
                    Otherwise NaT (non-datetime) value.
                lastest_end: datetime.datetime
                    The latest timestamp when the measurement ended for the SMF
                    data (based on the information of start and duration). Available for the
                    records of those vendors that are explicitly providing this information.
                    Otherwise NaT (non-datetime) value.
                type_info: DataFrame
                    List of (type-subtype) groups, together with metadata for each group
                    A subtype of `0` means that the type has no subtype.
                    == ==== ======= =====
                       type subtype count system IDs   estimated_size_in_bytes ...
                    == ==== ======= ===== ============ ======================= ...
                    0  2    0       2     [SysA]       12345                   ...
                    1  70   1       300   [SysA, SysB] 1234567                 ...
                    2  99   2       1200  [SysC]       4567                    ...
                    == ==== ======= ===== ============ ======================= ...

                        ... first_time_in_buffer last_time_in_buffer ...
                        ... ============================ =========================== ...
                        ... 2020-10-12 11:02:33.010      2020-10-13 11:59:33.010     ...
                        ... 2020-10-11 09:09:43.213      2020-11-13 11:59:33.010     ...
                        ... 2020-09-12 17:29:06.011      2020-12-13 11:59:33.010     ...
                        ... ============================ =========================== ...

                        ... earliest_start      lastest_start       earliest_end            lastest_end
                        ... =================== =================== ======================= =======================
                        ... 2020-10-12 19:14:33 2020-10-13 11:44:33 2020-10-12 19:29:33.000 2020-10-13 11:59:32.999
                        ...                 NaT 2020-10-13 11:44:33 2020-10-12 19:29:33.000 2020-10-13 11:59:32.999
                        ...                 NaT                 NaT                     NaT                     NaT
                        ... =================== =================== ======================= =======================
        """

    @abc.abstractmethod
    def fetch_dataset_smftypes(self, dataset_name: str) -> pd.DataFrame:
        """Fetch a `DataFrame` of available SMF types in `dataset_name`.

        Parameters
        ----------
        dataset_name : str
            Name of the Dataset to fetch information for.

        Returns
        -------
        DataFrame
            List of type/subtypes and amount contained in the dataset as pandas
            DataFrame.
            A subtype of `0` means that the type has no subtype.
            The list is sorted by type and subtype.

            == ==== ======= =====
               type subtype count
            == ==== ======= =====
            0  2    0       2
            1  70   1       300
            2  99   2       1200
            == ==== ======= =====
        """

    @abc.abstractmethod
    def check(self) -> bool:
        """Check if the `Connector` is able to fetch data."""

    @abc.abstractmethod
    def check_host_reachable(self) -> bool:
        """Check if the `host` is reachable."""


class Parser(abc.ABC):
    """The parser converts an abstract `FieldRequest` into a backend specific
    `Query`."""

    @abc.abstractmethod
    def parse(self, req: "request.FieldRequest") -> List[Query]:
        """Parse a `FieldRequest` into a `Query` that can be executed by a corresponding
        `Connector`.

        Parameters
        ----------
        req : request.FieldRequest
            Request to parse

        Returns
        -------
        Query
            Resulting Query
        """

    @abc.abstractmethod
    def query(self, req: "request.QueryRequest") -> List[Query]:
        """Convert a `QueryRequest` into a `Query` that can be executed by a
        corresponding `Connector`.

        Parameters
        ----------
        req : request.QueryRequest
            Request to convert

        Returns
        -------
        Query
            Resulting query
        """


class Environment(abc.ABC):
    """An `Environment` encapsulates SMF Explorer's capability to fetch data from a
    specific backend.
    It holds the `Parser` and `Connector` that help execute a `Request` against the
    backend.
    The `mode` is used to identify the type of `Environment`.
    Additionally the mode is important throughout SMF Explorer to allow `Environment`
    specific samples and post-processors.

    Hooks
    -----
    Each `Environment` can have three hooks that allow the `Environment` to make changes
    to a `FieldRequest` or fetched DataFrame.
    The hooks should only apply changes that are specific to the `Environment` (e.g.
    Apply a default sorting condition that is just important for this `Environment`)

    The supported hooks are.

    `_pre_hook` : Callable[[request.FieldRequest], None]
        This hook is called directly after the user called the `run()` method
    `_pre_fetch_hook` : Callable[[request.FieldRequest], None]
        This hook is called just before the request is made. At this point all other
        changes SMF Explorer made to the request are already done.
    `_post_hook` : Callable[[pandas.DataFrame, request.FieldRequest], pandas.DataFrame]
        Called with the retrieved DataFrame just before it is returned to the user
    """

    def __init__(self, connection_info: Dict[str, str]) -> None:
        """Create a new Environment from the given connection info.

        Args:
            connection_info (Dict[str, str]): Connections info created from connection
            string using the `core.environment.factory.resolve_connection_string` method
        """
        self._connector: Connector = None
        self._parser: Parser = None
        self._connection_info: Dict[str, str] = connection_info

    def new_context(
        self, *dataset_names: Union[str, Iterable[str]]
    ) -> "context.Context":
        """Create a new `Context` for the `Environment` with a optional list if
        `dataset_names`."""

        # Using a dict here to preserve order
        datasets: Dict[str, None] = {}

        for val in dataset_names:
            if isinstance(val, str):
                for v in util.expand_dataset_template(val):
                    datasets[v] = None
            else:
                for elem in val:
                    for v in util.expand_dataset_template(elem):
                        datasets[v] = None

        return context.Context(list(datasets.keys()), self)

    def get_dataset_description(self, dataset_name: str) -> Dict:
        return self.connector.fetch_dataset_description(dataset_name)

    def get_available_records(self, dataset_name: str) -> pd.DataFrame:
        """Fetch the available record types and subtypes for `dataset_name`.

        Args
        ----
            dataset_name (str): The dataset name to fetch the types for

        Returns
        -------
        DataFrame
            List of type/subtypes and amount contained in the dataset as pandas
            DataFrame.
            A subtype of `0` means that the type has no subtype.
            The list is sorted by type and subtype.

            == ==== ======= =====
               type subtype count
            == ==== ======= =====
            0  2    0       2
            1  70   1       300
            2  99   2       1200
            == ==== ======= =====
        """
        df = self.connector.fetch_dataset_smftypes(dataset_name)
        df.reset_index(inplace=True, drop=True)
        return df

    def get_available_types(self, dataset_name: str) -> pd.DataFrame:
        """Fetch the available record types for `dataset_name`.

        Args:
            dataset_name (str): The dataset name to fetch the types for

        Returns
        -------
        DataFrame
            List of type and amount contained in the dataset as pandas DataFrame.
            The list is sorted by type.

            == ==== =====
               type count
            == ==== =====
            0  2    2
            1  70   300
            2  99   1200
            == ==== =====
        """
        df = self.get_available_records(dataset_name)
        df = df.groupby(["type"], as_index=False).sum()[["type", "count"]]
        df.reset_index(inplace=True, drop=True)
        return df

    def get_available_subtypes(self, dataset_name: str, type_: int) -> pd.DataFrame:
        """Fetch the available record subtypes for `dataset_name` and `type_`.

        Args:
            dataset_name (str): The dataset name to fetch the subtypes for
            type_ (int): The record type to fetch subtypes for

        Returns
        -------
        DataFrame
            List of subtype and amount contained in the dataset for `type_` as pandas
            DataFrame.
            A subtype of `0` means that the type has no subtype.
            The list is sorted by subtype.

            == ======= =====
               subtype count
            == ======= =====
            0  0       2
            1  1       300
            2  2       1200
            == ======= =====
        """

        df = self.get_available_records(dataset_name)
        df = df[df["type"] == type_]
        df.reset_index(inplace=True, drop=True)
        return df[["subtype", "count"]]

    def check_dataset_unsafe(self, dataset_name: str) -> bool:
        """Check if the current dataset is available.

        Raises an exception when the check fails with more information on the reason.

        Parameters
        ----------
        dataset_name : str
            Name of the dataset to check.

        Returns
        -------
        bool
            Result of check.
        """
        return self._connector.check_dataset_unsafe(dataset_name)

    def check_dataset(self, dataset_name: str) -> bool:
        """Check if a dataset is available for the current `Environment`.

        Returns `False` if any error occurred during check.

        Parameters
        ----------
        dataset_name : str
            Name of the dataset do check.
        """
        return self._connector.check_dataset(dataset_name)

    @classmethod
    @abc.abstractmethod
    def check_environment_availability(cls, connection_info: Dict[str, str]) -> bool:
        """Checks if connection info is valid for the Environment type or if the
        Environment can provide data without connection info."""

    def check(self) -> bool:
        """Checks if the `Environment` is able to connect."""
        return self._connector.check()

    def check_host_reachable(self) -> bool:
        return self._connector.check_host_reachable()

    @property
    def connector(self) -> Connector:
        """The `Connector` associated with this `Environment` instance."""
        return self._connector

    @property
    def parser(self) -> Parser:
        """The `Parser` associated with this `Environment` instance."""
        return self._parser

    @staticmethod
    @abc.abstractmethod
    def mode() -> str:
        """The `mode` string is used to identify the type of `Environment`"""

    @property
    def connection_info(self) -> Dict[str, str]:
        """Connection info used to create the environment"""
        return self._connection_info

    def _pre_hook(self, req: "request.FieldRequest") -> None:
        """Is called directly after the user called the `run()` method."""
        # pylint: disable=unused-argument
        return None

    def _pre_fetch_hook(self, req: "request.FieldRequest") -> None:
        """Is called just before the request is made. At this point all other
        changes SMF Explorer made to the request are already done."""
        # pylint: disable=unused-argument
        return None

    def _post_hook(self, df: pd.DataFrame, req: "request.FieldRequest") -> pd.DataFrame:
        """Called with the retrieved DataFrame just before it is returned to the
        user."""
        # pylint: disable=unused-argument
        return df
