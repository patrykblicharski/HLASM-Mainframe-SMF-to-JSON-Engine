# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Module for the `EnvironmentFactory`.

New `Environment` implementations can be registered with the `register_environment_type`
decorator.
"""
import logging
import os
import re
from typing import ClassVar, Dict, Type

from smfexplorer import error
from smfexplorer.core.environment import Environment

_LOG = logging.getLogger(__name__)


class EnvironmentFactory:
    """Factory for `Environments`"""

    __default_environment: ClassVar[Environment] = None
    environment_classes: Dict[str, Type[Environment]] = {}
    supported_environment_modes = set()

    @staticmethod
    def resolve_connection_string(connection_string: str) -> Dict[str, str]:
        """Converts a string of the form 'option1=value1;option2=value2' int a dictionary of all the options"""
        regex = re.compile(
            r"(?:(?<=.\;)|^)(?:(?P<key>[a-zA-Z0-9_]+)\=(?:\"(?P<value1>[^\"\v]*)\"|(?P<value2>[^\;\=\v]*)))(?:(?=\;.)|\;?$)"
        )

        result = {}
        for match in regex.findall(connection_string):
            if not match[1] and not match[2]:
                result[match[0]] = ""
            else:
                result[match[0]] = match[1] if match[1] != "" else match[2]

        return result

    @classmethod
    def init_default_environment(cls):
        """Look for possible default environment SMF Explorer can use.
        If no environment is found the user needs to create one manually.
        """

        if "SMF_EXPLORER_CONNECTION_STRING" in os.environ:
            _LOG.debug(
                "Connection string was found in environment variable: '%s'",
                os.environ["SMF_EXPLORER_CONNECTION_STRING"],
            )

            cls.__default_environment = cls.create_environment(
                os.environ["SMF_EXPLORER_CONNECTION_STRING"]
            )
        elif "SMFPY_CONNECTION_STRING" in os.environ:
            _LOG.debug(
                "Connection string was found in environment variable: '%s'",
                os.environ["SMFPY_CONNECTION_STRING"],
            )

            cls.__default_environment = cls.create_environment(
                os.environ["SMFPY_CONNECTION_STRING"]
            )

        if cls.__default_environment is not None:
            return

        _LOG.debug(
            "No connection string found in environment variables. Checking for other available environments"
        )

        for mode in [
            m
            for m in cls.supported_environment_modes
            if (
                m in cls.environment_classes
                and cls.environment_classes[m].check_environment_availability(None)
            )
        ]:
            # Mode is available: Try to create environment
            _LOG.debug(
                "Environment with mode '%s' reports availability. Trying to create environment",
                mode,
            )
            try:
                cls.__default_environment = cls.environment_classes[mode](None)
                if not cls.__default_environment.check():
                    _LOG.debug("Failed check for environment mode '%s'", mode)
            except error.EnvironmentError as ex:
                cls.__default_environment = None
                _LOG.debug(
                    "There was an error creating a possible default environment with mode '%s'",
                    ex.mode,
                    exc_info=ex,
                )

        _LOG.debug("No default environment found")

    @classmethod
    def get_default_environment(cls):
        """Return the default environment or try to initialize one.

        If the the default environment was not yet created this calls
        `init_default_environment()`.
        The default environment might be `None` if the factory was unable to create one.
        """
        if cls.__default_environment is None:
            cls.init_default_environment()
        return cls.__default_environment

    @classmethod
    def set_default_environment(cls, default_environment: Environment):
        """Set the default environment.

        Calling `init_default_environment()` is the preferred way to create an
        environment.
        """
        cls.__default_environment = default_environment

    @classmethod
    def create_environment(cls, connection_string: str) -> Environment:
        """Create a new Environment from a connection string.
        This is used when the user manually requests an environment.
        """
        if not connection_string or not isinstance(connection_string, str):
            raise TypeError()

        connection_info = cls.resolve_connection_string(connection_string)

        if "mode" not in connection_info:
            raise error.EnvironmentError("Connection string is missing 'mode' option")

        mode = connection_info["mode"]

        if not mode in cls.supported_environment_modes:
            raise error.EnvironmentError(f"Unknown mode '{mode}'", mode=mode)

        if not mode in cls.environment_classes:
            raise error.EnvironmentError(
                f"Missing implementation for mode '{mode}'. Please report this as a bug report against SMF Explorer or the plugin that introduces this mode",
                mode=mode,
            )

        if not cls.environment_classes[mode].check_environment_availability(
            connection_info
        ):
            raise error.EnvironmentError(
                f"Availability check for mode '{mode}' failed", mode=mode
            )

        environment = cls.environment_classes[mode](connection_info)
        if not environment.check():
            raise error.EnvironmentError(
                "Basic check with the provided connection string failed. Make sure that the provided connection string is correct and there are no connectivity issues",
                mode=mode,
            )

        return environment


def register_environment_type(type_: Type[Environment]) -> Type[Environment]:
    """Register a new Environment type to the factory."""
    EnvironmentFactory.environment_classes[type_.mode()] = type_
    EnvironmentFactory.supported_environment_modes.add(type_.mode())

    return type_
