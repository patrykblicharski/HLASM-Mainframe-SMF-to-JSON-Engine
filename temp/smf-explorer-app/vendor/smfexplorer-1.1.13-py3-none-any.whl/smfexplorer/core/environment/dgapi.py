# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Module for the Data Gatherer Rest API Backend.

The connection string for this `Environment` type has the following options:

- mode :            Must be `dgapi`.
- url  :            URL of the DG SMF API endpoint.
- validate_ssl :    If set to `false`, TLS certificate validation is disabled. Is
                    enabled by default.
"""
import collections
import dataclasses
import datetime
import functools
import json
import logging
import os
import platform
import re
import subprocess
import warnings
from typing import (
    Any,
    Callable,
    Deque,
    Dict,
    Iterable,
    List,
    NamedTuple,
    Optional,
    Set,
    Tuple,
)
from urllib import parse as urlparse

import pandas as pd
import requests
import requests.exceptions

from smfexplorer import error as se_error
from smfexplorer import resolvers as se_resolvers
from smfexplorer.core import environment as se_environment
from smfexplorer.core import executor as se_executor
from smfexplorer.core import expressions as se_expressions
from smfexplorer.core import field as se_field
from smfexplorer.core import request as se_request
from smfexplorer.core import request_graph as se_reqgraph
from smfexplorer.core.environment import factory as se_environment_factory

_LOG = logging.getLogger(__name__)


# Disable ssl warning
def __disable_ssl_warning():
    # pylint: disable=no-member,import-outside-toplevel,redefined-outer-name
    import urllib3
    from urllib3.exceptions import InsecureRequestWarning

    urllib3.disable_warnings(category=InsecureRequestWarning)
    requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)


__disable_ssl_warning()

# ---------------------------------------------------------------------------- #
#                  Query, Connector and Parser Implementations                 #
# ---------------------------------------------------------------------------- #

_BASE_PATH = "/v1/smf"


class DGQuery(se_environment.Query):
    """`Query` for the DG API."""

    def __init__(
        self,
        dataset_name: str,
        smf_type: int,
        smf_subtype: int,
        start_time: datetime.datetime = None,
        end_time: datetime.datetime = None,
        system_name: str = None,
        fields: Dict[str, List[str]] = None,
        request: se_request.Request = None,
        record_index: bool = False,
        map_index: Set[se_field.RecordMap] = None,
        data_parser: "DGDataParser" = None,
        dataset_index: bool = False,
    ):
        super().__init__(dataset_name)
        self.smf_type = smf_type
        self.smf_subtype = smf_subtype
        self.fields = fields
        self.start_time = start_time
        self.end_time = end_time
        self.system_name = system_name
        self.request = request

        self.data_parser = data_parser

        self.record_index: bool = record_index
        self.map_index: Set[se_field.RecordMap] = map_index or set()
        self.dataset_index: bool = dataset_index

    @property
    def raw(self) -> str:

        params = {}

        params["datasetName"] = self.dataset_name

        if self.fields:
            for key, value in self.fields.items():
                if not value:
                    continue
                params[f"{f'{key}' if key else ''}"] = ",".join(value)

        if self.system_name:
            params["systemName"] = self.system_name.ljust(4)

        if self.start_time:
            params["startTime"] = self.start_time.isoformat()

        if self.end_time:
            params["endTime"] = self.end_time.isoformat()

        return (
            f"{_BASE_PATH}/type/{self.smf_type}/subtype/{self.smf_subtype}?"
            f"{urlparse.urlencode(params, quote_via=urlparse.quote_plus)}"
        )


_DG_API_NAME = "z/OS Data Gatherer: SMF Data REST Services"


class DGDataParser:
    """Helper class to convert from JSON object to DataFrame.

    The `DGDataParser` converts the JSON object returned by the Data Gatherer into
    the LEFT JOINed DataFrame representation SMF Explorer expects.

    The data is parsed by looking at all SMF maps(sections) individually and merging
    them in the end.
    For the merge to work the sections include an index chain (columns containing and
    index for all the parent sections up to the record).
    The indices make each entry uniquely identifiable.

    The parser is prebuilt during `Query` creation and applied directly after `Query`
    execution.
    """

    @dataclasses.dataclass()
    class ParseState:
        """State for the `DGDataParser`."""

        dataframes: Dict[se_reqgraph.RGNode, List] = dataclasses.field(
            default_factory=lambda: {}
        )
        tables: Dict[str, List] = None

    class SectionParser:
        """Parser for a single section in the returned JSON."""

        def __init__(
            self,
            data_parser: "DGDataParser",
            map_name: str,
            multi_map: bool,
            is_compound: bool,
            index_name: str,
            parent_index_chain: List[str],
        ) -> None:
            self.fields: Set[Tuple[str, str, Callable[[Any], Any]]] = set()
            self.record_maps: Set[str] = set()
            self.map_name = map_name
            self.multi_map = multi_map
            self.is_compound = is_compound
            self.data_parser = data_parser

            self.index_name = index_name
            self.index_chain = parent_index_chain + [index_name]

        def parse_entry(
            self,
            state: "DGDataParser.ParseState",
            data: Dict[str, Any],
            index: int,
            parent_index: Dict[str, int],
        ):
            """Parse a single entry in a section.

            If the parsed entry contains sub-maps, the section parser of that map is
            recursively called.

            Parameters
            ----------
            state : DGDataParser.ParseState
                The current parsing state
            data : Dict[str, Any]
                The raw data for the section
            index : int
                The current index of the entry
            parent_index : Dict[str, int]
                The map of indices of the parent sections to also insert in the
                resulting `DataFrame`
            """
            index_fields = {**parent_index, self.index_name: index}
            row = {}

            # Make sure data is not None to create NA fields for empty sections and their subsections
            data = data or {}

            for name, origin, transform in self.fields:
                if origin in data:
                    row[name] = transform(data[origin]) if transform else data[origin]
                else:
                    row[name] = pd.NA

            state.tables[self.index_name].append({**index_fields, **row})

            for record_map in self.record_maps:
                map_parser = self.data_parser.section_parsers[record_map]
                if data is None or map_parser.map_name not in data:
                    _LOG.debug(
                        "The map %s was requested but not found fetched data.",
                        map_parser.map_name,
                    )
                map_parser.parse_section(
                    state,
                    (
                        data[map_parser.map_name]
                        if (data is not None and map_parser.map_name in data)
                        else None
                    ),
                    index_fields,
                )

        def parse_section(
            self,
            state: "DGDataParser.ParseState",
            data: Optional[Dict[str, Any]],
            parent_index: Dict[str, int] = None,
        ):
            """Parse complete section contained in `data`.

            Parameters
            ----------
            state : DGDataParser.ParseState
                Current parsing state
            data : Optional[Dict[str, Any]]
                Raw data of the current section
            parent_index : Dict[str, int], optional
                _The map of indices of the parent sections to also insert in the
                resulting `DataFrame`, by default None
            """
            parent_index = parent_index or {}
            if (self.multi_map or self.is_compound) and data is not None:
                for index_str, entry_data in data.items():
                    self.parse_entry(state, entry_data, int(index_str), parent_index)
            else:
                self.parse_entry(state, data, 0, parent_index)

    @staticmethod
    def _time_transform(value: str):
        try:
            return datetime.datetime.strptime(value, "%H:%M:%S.%f").time()
        except ValueError:
            return datetime.datetime.strptime(value, "%H:%M:%S").time()

    @staticmethod
    def _date_transform(value: str):
        return datetime.date.fromisoformat(value)

    @staticmethod
    def _timedelta_transform(value: str):
        # TODO: Remove as soon as timedelta NA support is fixed for faster parsing
        # https://github.com/pandas-dev/pandas/issues/40566
        return pd.Timedelta(value)

    @staticmethod
    def _array_transform(obj):

        if not isinstance(obj, dict):
            raise se_error.SmfExplorerError(
                "Array transforms for dgapi must be dictionaries. This is a bug!"
            )

        return {int(key): value for key, value in obj.items()}

    def __init__(
        self,
        req: se_request.FieldRequest,
        record_index: bool,
        map_index: Iterable[se_field.RecordMap],
        environment: "DGEnvironment",
        array_fields: Dict[se_field.Field, List[se_field.Field]],
    ) -> None:

        self.req = req
        self.record_index = record_index
        self.map_index = set(map_index)

        self.map_index_to_remove: Set[se_field.RecordMap] = set()

        self.record = req._graph.root_node.record

        self.type_conversion = {}

        self.section_parsers: Dict[str, DGDataParser.SectionParser] = {}

        self.environment = environment

        self.array_fields = array_fields

        # We traverse the request graph in topological order here to create all the
        # SectionParsers.
        for node in se_reqgraph.traverse(self.req._graph.root_node):

            if (
                node.parent is not None
                and node.parent.node_type == se_reqgraph.RGNodeType.FIELD
                and (
                    node.field.virtual
                    or node.parent.field._pseudo_field
                    == se_field.PseudoField.ARRAY_FIELD
                )
            ):
                # If the node is a field that will be created in posprocessing, don't do
                # anything.
                continue

            # Get the SectionParser of this nodes parent.
            parent = (
                self.section_parsers[
                    (
                        node.parent.record.index.name
                        if node.parent.node_type == se_reqgraph.RGNodeType.RECORD
                        else node.parent.record_map.index.name
                    )
                ]
                if node.parent
                else None
            )

            if node.node_type == se_reqgraph.RGNodeType.RECORD:
                # Create SectionParser for Record
                self.section_parsers[node.record.index.name] = (
                    DGDataParser.SectionParser(
                        self, None, True, False, node.record.index.name, []
                    )
                )
            elif node.node_type == se_reqgraph.RGNodeType.MAP:
                # Create SectionParsers for RecordMaps
                if not node.record_map in self.map_index:
                    self.map_index_to_remove.add(node.record_map)

                field_name = self.environment._resolve_map_to_dg_names(
                    node.record_map.origin,
                    self.record.smf_type,
                    self.record.smf_subtype,
                ).field_name

                self.section_parsers[node.record_map.index.name] = (
                    DGDataParser.SectionParser(
                        self,
                        field_name,
                        node.record_map.is_multiple,
                        (
                            node.record_map.is_compound
                            if node.record_map.is_compound
                            else False
                        ),
                        node.record_map.index.name,
                        parent.index_chain,
                    )
                )
                parent.record_maps.add(node.record_map.index.name)
            elif node.node_type == se_reqgraph.RGNodeType.FIELD:
                # Add field specific information to SectionParsers.
                if (
                    node.field._pseudo_field
                    and node.field._pseudo_field == se_field.PseudoField.DATASET_INDEX
                ):
                    # Don't add dataset index fields as they are by the executor.
                    continue

                # Find transform functions for fields that require it.
                transform = None
                if node.field.type:
                    if node.field.type == se_field.FieldType.DATE:
                        transform = DGDataParser._date_transform
                    elif node.field.type == se_field.FieldType.TIME:
                        transform = DGDataParser._time_transform
                    elif node.field.type == se_field.FieldType.TIMEDELTA:
                        transform = DGDataParser._timedelta_transform

                    if (
                        node.field._pseudo_field
                        and node.field._pseudo_field != se_field.PseudoField.ARRAY_FIELD
                    ):
                        pass
                    if not (
                        node.field._pseudo_field
                        and node.field._pseudo_field == se_field.PseudoField.ARRAY_FIELD
                    ):
                        self.type_conversion[node.field.name] = (
                            node.field.type.pandas_type
                        )

                if node.field._pseudo_field:
                    if node.field._pseudo_field in [
                        se_field.PseudoField.MAP_INDEX,
                        se_field.PseudoField.RECORD_INDEX,
                    ]:
                        # Index fields are dynamically generated during parsing.
                        # Adding them here would result in an exception
                        continue
                    elif node.field._pseudo_field == se_field.PseudoField.ARRAY_FIELD:
                        # Array fields need to be transformed to have integer indices.
                        transform = DGDataParser._array_transform

                origin = node.field.origin
                if node.field._pseudo_field:
                    # Common pseudo fields have an x in the name that needs to be
                    # replaced by the SMF type.
                    origin = node.field.origin.replace(
                        "x", str(self.record.smf_type), 1
                    )
                parent.fields.add(
                    (
                        node.field.name,
                        self.environment._resolve_field_to_dg_name(
                            origin, self.record.smf_type, self.record.smf_subtype
                        ),
                        transform,
                    )
                )

        # Copy the type information from the origin of array fields.
        for origin, fields in self.array_fields.items():
            for field in fields:
                self.type_conversion[field.name] = origin.type.pandas_type

    @staticmethod
    def _extract_array_fields(
        df: pd.DataFrame, origin: se_field.Field, targets: List[se_field.Field]
    ) -> None:
        for field in targets:
            df[field.name] = df[origin.name].apply(
                lambda e, i=field._array_index: e[i] if not pd.isna(e) else pd.NA
            )

    def build_dataframe(self, raw_data: Dict[str, Any]) -> pd.DataFrame:
        """Converts the raw representation returned by the DG REST API into a pandas
        `DataFrame` using the `SectionParsers` defined during initialization.

        Parameters
        ----------
        raw_data : Dict[str, Any]
            Raw data dictionary. The result of loading the JSON return by DG REST API.

        Returns
        -------
        pd.DataFrame
            LEFT JOINed `DataFrame` with initial type conversions and transforms
            applied.

        Raises
        ---------
            se_error.ParserError: if the resulting dataframe exceeds 50% of available memory
        """

        state = DGDataParser.ParseState()
        state.tables = {k: [] for k in self.section_parsers}

        self.section_parsers[self.record.index.name].parse_section(state, raw_data)

        result_df = pd.DataFrame(state.tables[self.record.index.name])

        for index_name, section in self.section_parsers.items():
            if index_name == self.record.index.name:
                continue
            df = pd.DataFrame(state.tables[index_name])
            try:
                self.check_memory_requirement(result_df, df, section.index_chain[:-1])
            except se_error.ParserError:
                raise
            result_df = result_df.merge(df, on=section.index_chain[:-1], how="left")

        for index_name in self.section_parsers:
            result_df[index_name] += 1

        columns_to_remove = [map.index.name for map in self.map_index_to_remove]
        if not self.record_index:
            columns_to_remove.append(self.record.index.name)

        result_df.drop(columns_to_remove, axis=1, inplace=True)

        for origin, targets in self.array_fields.items():
            DGDataParser._extract_array_fields(result_df, origin, targets)

        result_df = result_df.astype(self.type_conversion, copy=False)

        return result_df

    def check_memory_requirement(self, result_df, df, on):
        """estimate whether the upcoming left join will result in a memory error

        Parameters
        ----------
            result_df: pd.DataFrame
                the dataframe to be joined to
            df: pd.DataFrame
                the dataframe to join
            on: List[String]
                the columns to join on

        Raises
        ---------
            se_error.ParserError: if the resulting dataframe exceeds 50% of available memory
        """
        new_columns = set()
        row_size = 0
        for col in result_df.columns:
            row_size += result_df[col].dtypes.itemsize
            new_columns.add(col)

        for col in df.columns:
            if col not in new_columns:
                new_columns.add(col)
                row_size += df[col].dtypes.itemsize

        left_value_counts = result_df[on].value_counts().to_dict()
        right_value_counts = df[on].value_counts().to_dict()
        for key in left_value_counts.keys():
            if key in right_value_counts:
                left_value_counts[key] = (
                    left_value_counts[key] * right_value_counts[key]
                )
        n_rows = sum(list(left_value_counts.values()))
        result_size = n_rows * row_size

        if platform.system().lower() == "os/390":
            avail_mem = getAvailableMemoryInByte()
        else:
            import psutil

            avail_mem = psutil.virtual_memory().available

        if result_size > 0.5 * avail_mem:
            raise se_error.ParserError(
                f"The processing of request exceeds available memory. Required: {result_size * 2} Available: {avail_mem}."
            )


def convert_str_to_byte(vsz64):
    vsz64 = vsz64.strip()
    units = {"K": 1024, "M": 1024**2, "G": 1024**3, "T": 1024**4, "P": 1024**5}
    unit = vsz64[-1]
    if unit.isalpha():
        if unit in units.keys():
            return int(vsz64[:-1]) * units[unit]
        else:
            raise ValueError(f"Unknown unit: {unit}")
    else:
        return int(vsz64)


def getAvailableMemoryInByte():
    try:
        result = subprocess.run(
            [
                "ps",
                "-ef",
                "-o",
                "pid,uid,user,tty=TTY",
                "-o",
                "atime,comm",
                "-o",
                "vsz64,vszlmt64",
            ],
            capture_output=True,
        )
        printed_str = result.stdout.decode("ascii")
        pid = str(os.getpid())
        for line in printed_str.split("\n"):
            words = line.split()
            if (len(words) > 0) and (words[0].strip() == pid):
                values = line.split()
                vsz64 = values[-2]
                vszlmt64 = values[-1]
                return convert_str_to_byte(vszlmt64) - convert_str_to_byte(vsz64)
        raise se_error.SmfExplorerError(
            "No information about available virtual memory for current process found"
        )
    except Exception as e:
        raise se_error.SmfExplorerError(
            f"Error getting available memory information: {e}"
        )


class DGConnector(se_environment.Connector):
    """Manages the connection to the DG Rest API, including session management, json
    decoding and HTTP error handling.
    """

    def __init__(
        self, url: str, username: str, password: str, validate_ssl: bool = False
    ) -> None:
        if url.endswith("/"):
            url = url[: -len("/")]
        self._url = url

        self._session = requests.Session()
        self._session.verify = validate_ssl
        self._session.auth = (username, password)
        self._username = username
        self._password = password

    def query(self, query: DGQuery) -> pd.DataFrame:

        resp = self.make_request(query.raw, dataset_name=query.dataset_name)

        try:
            raw_data: Dict[str, Any] = resp.json()
        except json.JSONDecodeError as ex:
            raise se_error.ConnectorError(
                f"Failed to decode response from DG API on dataset "
                f"'{query.dataset_name}': {ex.msg}",
                connector=self,
            ) from ex

        _LOG.debug("Response: %s", resp.content.decode())

        try:
            df = query.data_parser.build_dataframe(raw_data)
        except se_error.ParserError as ex:
            desc = self.fetch_dataset_description(query.dataset_name)
            start_time = desc["first_time_in_buffer"]
            end_time = desc["last_time_in_buffer"]
            error_message = (
                f" The processing of request for dataset {query.dataset_name} failed: {str(ex)}"
                + "Try increasing the available memory, reducing number of requested fields or limiting the time period"
                + f"to retrieve data from. Available time frame: start: {start_time}, end: {end_time}."
            )
            raise se_error.ParserError(error_message, parser=query.data_parser) from ex

        if query.dataset_index:
            df["dataset_index"] = query.dataset_name
        return df

    def make_request(
        self, path: str, dataset_name: str = None, **kwargs
    ) -> requests.Response:
        try:

            resp = self._session.get(
                f"{self._url}{path}", auth=(self._username, self._password), **kwargs
            )

        except requests.exceptions.RequestException as ex:
            if ex.strerror is None:
                raise se_error.ConnectorError(
                    "Unexpected error connecting to REST Services. Check connection to host.",
                    connector=self,
                ) from ex
            else:
                raise se_error.ConnectorError(
                    f"Error connecting to REST Services: {ex.strerror}",
                    connector=self,
                ) from ex

        if not resp.ok:
            if resp.status_code == 401:
                raise se_error.ConnectorError(
                    "User authentication failed",
                    connector=self,
                    reason=se_error.ConnectorErrorReason.MISSING_AUTHENTICATION,
                )
            if resp.status_code == 403:
                raise se_error.ConnectorError(
                    "User has insufficient permissions for request",
                    connector=self,
                    reason=se_error.ConnectorErrorReason.INSUFFICIENT_PERMISSION,
                )
            if resp.status_code == 404:
                raise se_error.ConnectorError(
                    f"Unable to find dataset '{dataset_name}'",
                    connector=self,
                    reason=se_error.ConnectorErrorReason.DATASET_NOT_FOUND,
                )
            if resp.status_code == 429:
                raise se_error.ConnectorError(
                    "Other request for the dataset is currently processed. Try again later.",
                    connector=self,
                    reason=se_error.ConnectorErrorReason.SERVICE_UNAVAILABLE,
                )
            try:
                raw_error = resp.json()
            except requests.exceptions.JSONDecodeError:
                raw_error = {}

            if "message" in raw_error:
                raise se_error.ConnectorError(
                    f"""Failed to fetch data{f" for dataset '{dataset_name}'" if dataset_name else ""} with """
                    f"status code {resp.status_code} and message: "
                    f"'{raw_error['message']}'",
                    connector=self,
                )

            raise se_error.ConnectorError(
                f"""Failed to fetch data{f" for dataset '{dataset_name}'" if dataset_name else ""} with status code {resp.status_code}""",
                connector=self,
            )

        return resp

    def check_dataset_unsafe(self, dataset_name: str) -> bool:
        _LOG.debug("Checking for dataset '%s'", dataset_name)

        try:
            self.make_request(
                f"/v1/smf/discover/dataset/exists/{dataset_name}",
                dataset_name=dataset_name,
                params=[("datasetName", dataset_name)],
            )
        except se_error.ConnectorError as ex:
            if ex.reason == se_error.ConnectorErrorReason.DATASET_NOT_FOUND:
                _LOG.debug("Dataset '%s' not found", dataset_name)
                return False
            raise

        _LOG.debug("Found dataset '%s'", dataset_name)
        return True

    def fetch_dataset_description(self, dataset_name: str) -> Dict:
        _LOG.debug("Fetch description for dataset '%s'", dataset_name)

        resp = self.make_request(
            f"/v1/smf/discover/describe/{dataset_name}",
            dataset_name=dataset_name,
            params=[("datasetName", dataset_name)],
        ).json()
        results = {}
        if "datasetCreationDate" in resp:
            results["creation_date"] = datetime.datetime.strptime(
                resp["datasetCreationDate"], "%Y-%m-%d"
            ).date()
        else:
            results["creation_date"] = pd.NaT
        results.update(self.extract_meta_data(resp))
        results["type_info"] = self.extract_dataset_smftypes(resp["smfGroups"])
        return results

    def extract_dataset_smftypes(self, discovery_data: Dict[str, Any]) -> pd.DataFrame:
        results = []
        for smf_type_str, value in discovery_data.items():
            smf_subtype = 0
            if "-" in smf_type_str:
                smf_type, smf_subtype = map(int, smf_type_str.split("-"))
            else:
                smf_type = int(smf_type_str)
            metadata = {"type": smf_type, "subtype": smf_subtype}
            metadata.update(self.extract_meta_data(value))
            results.append(metadata)
        result_df = pd.DataFrame(results)
        result_df = result_df.astype(
            {
                "type": "Int64",
                "subtype": "Int64",
                "count": "Int64",
                "estimated_size_in_bytes": "Int64",
            }
        )
        return result_df

    def extract_meta_data(self, value):
        record_count = value.get("totalNumberOfRecords", 0)
        system_ids = value.get("smfIds", [])
        estimated_raw_size = value.get("estimatedByteSize", 0)

        default_value = ""

        earliestSmfRecordMoveTime = DGConnector.parse_iso_format(
            value.get("earliestSmfRecordMoveTime", default_value)
        )
        latestSmfRecordMoveTime = DGConnector.parse_iso_format(
            value.get("latestSmfRecordMoveTime", default_value)
        )
        earliestStartOfSmfInterval = DGConnector.parse_iso_format(
            value.get("earliestStartOfSmfInterval", default_value)
        )
        latestStartOfSmfInterval = DGConnector.parse_iso_format(
            value.get("latestStartOfSmfInterval", default_value)
        )
        earliestEndOfSmfInterval = DGConnector.parse_iso_format(
            value.get("earliestEndOfSmfInterval", default_value)
        )
        latestEndOfSmfInterval = DGConnector.parse_iso_format(
            value.get("latestEndOfSmfInterval", default_value)
        )

        result = {
            "count": record_count,
            "system_ids": system_ids,
            "estimated_size_in_bytes": estimated_raw_size,
            "first_time_in_buffer": earliestSmfRecordMoveTime,
            "last_time_in_buffer": latestSmfRecordMoveTime,
            "earliest_start": earliestStartOfSmfInterval,
            "lastest_start": latestStartOfSmfInterval,
            "earliest_end": earliestEndOfSmfInterval,
            "lastest_end": latestEndOfSmfInterval,
        }
        return result

    def fetch_dataset_smftypes(self, dataset_name: str) -> pd.DataFrame:
        _LOG.debug("Fetch smftypes for dataset '%s'", dataset_name)
        discovery_data = self.fetch_dataset_description(dataset_name)
        return discovery_data["type_info"][["type", "subtype", "count"]]

    def check_host_reachable(self) -> bool:
        pass

    def _check_api_doc(self) -> Tuple[bool, Dict[str, str]]:
        try:
            resp = self._session.get(f"{self._url}/v3/api-docs")
        except requests.exceptions.RequestException as ex:
            _LOG.debug(
                "Failed dgapi environment check with: %s", ex.strerror, exc_info=ex
            )
            return (False, None)

        if resp.status_code != 200:
            _LOG.debug(
                "Failed dgapi environment check with status_code %s", resp.status_code
            )
            return (False, None)

        try:
            resp_data = resp.json()
        except ValueError as ex:
            _LOG.debug(
                "Failed dgapi environment check: response could not be parsed",
                ex_info=ex,
            )
            return (False, None)

        if "info" in resp_data and "title" in resp_data["info"]:
            if resp_data["info"]["title"].startswith(_DG_API_NAME):
                return (True, resp_data)

        _LOG.debug("Failed dgapi environment check: response did not match criteria")
        return (False, resp_data)

    def check(self) -> bool:
        return self._check_api_doc()[0]

    @staticmethod
    def parse_iso_format(s: str) -> pd.Timestamp:
        if not s:
            return pd.NaT
        elif "." in s:
            s = s.replace("T", " ")
            return pd.Timestamp(datetime.datetime.fromisoformat(s.ljust(23, "0")))
        else:
            return pd.Timestamp(datetime.datetime.fromisoformat(s))


class DGParser(se_environment.Parser):
    """Parser for the DG API backend. Converts `Request`s into HTTP Requests"""

    @dataclasses.dataclass
    class ParserState:
        """Helper class to store state during recursive request parsing."""

        smf_type: int = None
        smf_subtype: int = None

        record_index: se_field.Field = None
        map_index: Dict[se_field.RecordMap, se_field.Field] = dataclasses.field(
            default_factory=dict
        )
        dataset_index: se_field.Field = None

        field_list: Dict[str, List[str]] = dataclasses.field(default_factory=lambda: {})

        array_entry_fields: Dict[se_field.Field, List[se_field.Field]] = (
            dataclasses.field(default_factory=lambda: {})
        )

    def __init__(self, environment: "DGEnvironment") -> None:
        super().__init__()

        self.environment: DGEnvironment = environment

    @staticmethod
    def _resolve_pseudo_fields(field: se_field.Field, state: "DGParser.ParserState"):
        if field._pseudo_field == se_field.PseudoField.HEADER_DATE:
            state.field_list[f"SMF{state.smf_type}_SUBTYPE{state.smf_subtype}"].append(
                f"SMF{state.smf_type}DTE"
            )
        elif field._pseudo_field == se_field.PseudoField.HEADER_TIME:
            state.field_list[f"SMF{state.smf_type}_SUBTYPE{state.smf_subtype}"].append(
                f"SMF{state.smf_type}TME"
            )
        elif field._pseudo_field == se_field.PseudoField.HEADER_FLG:
            state.field_list[f"SMF{state.smf_type}_SUBTYPE{state.smf_subtype}"].append(
                f"SMF{state.smf_type}FLG"
            )
        elif field._pseudo_field == se_field.PseudoField.HEADER_RTY:
            state.field_list[f"SMF{state.smf_type}_SUBTYPE{state.smf_subtype}"].append(
                f"SMF{state.smf_type}RTY"
            )
        elif field._pseudo_field == se_field.PseudoField.HEADER_SID:
            state.field_list[f"SMF{state.smf_type}_SUBTYPE{state.smf_subtype}"].append(
                f"SMF{state.smf_type}SID"
            )
        elif field._pseudo_field == se_field.PseudoField.HEADER_STP:
            state.field_list[f"SMF{state.smf_type}_SUBTYPE{state.smf_subtype}"].append(
                f"SMF{state.smf_type}STP"
            )
        elif field._pseudo_field == se_field.PseudoField.HEADER_WID:
            state.field_list[f"SMF{state.smf_type}_SUBTYPE{state.smf_subtype}"].append(
                f"SMF{state.smf_type}WID"
            )
        elif field._pseudo_field == se_field.PseudoField.MAP_INDEX:
            state.map_index[field.record_map] = field
        elif field._pseudo_field == se_field.PseudoField.RECORD_INDEX:
            state.record_index = field
        elif field._pseudo_field == se_field.PseudoField.DATASET_INDEX:
            state.dataset_index = field

    def _resolve_node(self, node: se_reqgraph.RGNode, state: "DGParser.ParserState"):

        if node.node_type == se_reqgraph.RGNodeType.RECORD:
            state.smf_type = node.record.smf_type
            state.smf_subtype = node.record.smf_subtype
            state.field_list[f"SMF{state.smf_type}_SUBTYPE{state.smf_subtype}"] = []

        if node.node_type == se_reqgraph.RGNodeType.MAP:
            query_name = self.environment._resolve_map_to_dg_names(
                node.record_map.origin,
                state.smf_type,
                state.smf_subtype,
            ).query_name
            state.field_list[query_name] = []

        if node.node_type == se_reqgraph.RGNodeType.FIELD and not node.field.virtual:
            field_name = self.environment._resolve_field_to_dg_name(
                node.field.origin, state.smf_type, state.smf_subtype
            )

            if (
                node.field._pseudo_field
                and node.field._pseudo_field != se_field.PseudoField.ARRAY_FIELD
            ):
                DGParser._resolve_pseudo_fields(node.field, state)
            elif (
                node.field._array_index is not None
                and node.field._ref
                and node.field._ref._pseudo_field == se_field.PseudoField.ARRAY_FIELD
            ):
                if not node.field._ref in state.array_entry_fields:
                    state.array_entry_fields[node.field._ref] = []
                state.array_entry_fields[node.field._ref].append(node.field)
            elif node.field.record_map:
                query_name = self.environment._resolve_map_to_dg_names(
                    node.field.record_map.origin,
                    state.smf_type,
                    state.smf_subtype,
                ).query_name

                state.field_list[query_name].append(field_name)
            else:
                state.field_list[
                    f"SMF{state.smf_type}_SUBTYPE{state.smf_subtype}"
                ].append(field_name)

    def parse(self, req: se_request.FieldRequest) -> List[se_environment.Query]:

        _LOG.debug("Parsing request %s", req)

        state = DGParser.ParserState()
        for node in se_reqgraph.traverse(req._graph.root_node):
            self._resolve_node(node, state)

        data_parser = DGDataParser(
            req,
            state.record_index is not None,
            set(state.map_index.keys()),
            environment=self.environment,
            array_fields=state.array_entry_fields,
        )

        return [
            DGQuery(
                dataset_name,
                state.smf_type,
                state.smf_subtype,
                start_time=req.start_time,
                end_time=req.end_time,
                system_name=req.system_name,
                fields=state.field_list,
                request=req,
                record_index=state.record_index is not None,
                map_index=set(state.map_index.keys()),
                data_parser=data_parser,
                dataset_index=state.dataset_index is not None,
            )
            for dataset_name in req.context.dataset_names
        ]

    def query(self, req: se_request.QueryRequest) -> List[se_environment.Query]:
        raise NotImplementedError(
            "The DG REST API Environment does not support query based requests yet"
        )


# ---------------------------------------------------------------------------- #
#                               Environment Setup                              #
# ---------------------------------------------------------------------------- #

ENVIRONMENT_MODE = "dgapi"


class DGNames(NamedTuple):
    """Mapping to resolve query names to field names in JSON response."""

    query_name: str
    field_name: str


@dataclasses.dataclass
class DGNamesCache:
    """Cache for storing DG specific field and map names."""

    dg_query_to_field_names: Dict[str, str] = dataclasses.field(default_factory=dict)
    dg_original_to_query_names: Dict[str, str] = dataclasses.field(default_factory=dict)
    fields: Dict[str, str] = dataclasses.field(default_factory=dict)


@se_environment_factory.register_environment_type
class DGEnvironment(se_environment.Environment):
    """Environment implementation for the DG Rest API."""

    __MAP_REGEX = re.compile(
        r"^SMF(?P<smf_type>[0-9]+)(?:_SUBTYPE(?P<smf_subtype>[0-9]+))?(?:_(?P<map>.*))?$"
    )

    __BASE_SCHEMA_REGEX = re.compile(
        r"^SMF(?P<smf_type>[0-9]+)(?:_SUBTYPE(?P<smf_subtype>[0-9]+))?$"
    )

    __FIELD_REGEX = re.compile(r"^smf\d+Subtype\d+(?P<name>.*)$")
    __REF_REGEX = re.compile(r"^#/components/schemas/(?P<name>.*)$")

    def __init__(self, connection_info: Dict[str, str]) -> None:
        super().__init__(connection_info)

        self._dg_names_cache: Dict[Tuple(int, int), DGNamesCache] = None
        """Cache to store DG Rest API names for maps"""

        if not "url" in connection_info or not connection_info["url"].strip():
            raise se_error.EnvironmentError(
                "Missing or empty 'url' parameter in connection string",
                mode=ENVIRONMENT_MODE,
            )

        url = connection_info["url"]

        url_match = re.match(r"^(?:(?P<scheme>[a-zA-Z]+):)?", url)
        if not "scheme" in url_match.groupdict() or not url_match.group("scheme"):
            raise se_error.EnvironmentError(
                "Missing protocol scheme in url", mode=ENVIRONMENT_MODE
            )
        if url_match.groupdict()["scheme"] not in ["https", "http"]:
            raise se_error.EnvironmentError(
                "Schema of provided connection information is not http[s]",
                mode=ENVIRONMENT_MODE,
            )
        if url_match.groupdict()["scheme"] != "https":
            warnings.warn(
                "Using non-encrypted http connections potentially exposes user credentials and data",
                se_error.InsecureConnectionWarning,
            )

        verify_ssl = True
        if "verify_ssl" in connection_info and connection_info[
            "verify_ssl"
        ].lower() in ["false", "no", "n", "0"]:
            verify_ssl = False

        if ("username" not in connection_info) or ("password" not in connection_info):
            raise se_error.EnvironmentError(
                "No authentication information provided",
                mode=ENVIRONMENT_MODE,
            )

        username = connection_info["username"].strip()
        password = connection_info["password"].strip()

        self._connector: DGConnector = DGConnector(url, username, password, verify_ssl)
        self._parser: DGParser = DGParser(self)

    @classmethod
    def check_environment_availability(cls, connection_info: Dict[str, str]) -> bool:
        if connection_info:
            if all([x in connection_info for x in ["url"]]):
                return True
        return False

    def __build_apidoc_mappings(self, api_doc: Dict[str, str]):

        smf_map_queue: Deque[Tuple[Tuple[int, int], str, Dict[str, Any]]] = (
            collections.deque()
        )
        schema_cache: Dict[str, Dict[str, Any]] = {}

        for schema_name, schema_value in api_doc["components"]["schemas"].items():

            schema_match = self.__BASE_SCHEMA_REGEX.match(schema_name)

            if schema_match is None:
                schema_cache[schema_name] = schema_value
            else:
                smf_type: int = int(schema_match.group("smf_type"))
                smf_subtype: int = int(schema_match.group("smf_subtype") or 0)

                smf_type_tuple = (smf_type, smf_subtype)

                self._dg_names_cache[smf_type_tuple] = DGNamesCache()

                smf_map_queue.append((smf_type_tuple, schema_name, schema_value))

        while smf_map_queue:
            smf_type_tuple, schema_name, schema_value = smf_map_queue.popleft()

            if "x-zml-structure-name" in schema_value:
                control_block_name = schema_value["x-zml-structure-name"]
                if (
                    control_block_name
                    in self._dg_names_cache[smf_type_tuple].dg_original_to_query_names
                ):
                    control_block_name = schema_name
            else:
                control_block_name = schema_name

            self._dg_names_cache[smf_type_tuple].dg_original_to_query_names[
                control_block_name
            ] = schema_name

            for prop_name, prop_value in schema_value["properties"].items():
                prop_name: str
                prop_value: Dict[str, Any]

                if "$ref" in prop_value:
                    ref = prop_value["$ref"]
                elif (
                    "additionalProperties" in prop_value
                    and "$ref" in prop_value["additionalProperties"]
                ):
                    ref = prop_value["additionalProperties"]["$ref"]
                else:
                    if "x-zdg-original-name" in prop_value:
                        self._dg_names_cache[smf_type_tuple].fields[
                            prop_value["x-zdg-original-name"]
                        ] = prop_name
                    continue

                ref_match = self.__REF_REGEX.match(ref)

                if ref_match is None:
                    continue

                prop_schema_name = ref_match.group("name")

                self._dg_names_cache[smf_type_tuple].dg_query_to_field_names[
                    prop_schema_name
                ] = prop_name

                if prop_schema_name in schema_cache:
                    smf_map_queue.append(
                        (
                            smf_type_tuple,
                            prop_schema_name,
                            schema_cache[prop_schema_name],
                        )
                    )

    @functools.lru_cache
    def _resolve_map_to_dg_names(
        self, map_name: str, smf_type: int, smf_subtype: int = 0
    ) -> DGNames:

        if (smf_type, smf_subtype) not in self._dg_names_cache:
            raise se_error.EnvironmentError(
                f"DGAPI Environment was unable to find mappings for SMF {smf_type} Subtype {smf_subtype}",
                mode=ENVIRONMENT_MODE,
            )

        cache = self._dg_names_cache[(smf_type, smf_subtype)]

        if map_name in cache.dg_original_to_query_names:
            query_name = cache.dg_original_to_query_names[map_name]
        else:
            query_name = f"SMF{smf_type}_SUBTYPE{smf_subtype}_{map_name}"

        if not query_name in cache.dg_query_to_field_names:
            raise se_error.EnvironmentError(
                f"DGAPI Environment was unable find mappings for '{map_name}' SMF {smf_type} Subtype {smf_subtype}",
                mode=ENVIRONMENT_MODE,
            )

        return DGNames(query_name, cache.dg_query_to_field_names[query_name])

    @functools.lru_cache
    def _resolve_field_to_dg_name(
        self, field_name: str, smf_type: int, smf_subtype: int = 0
    ) -> str:

        if (smf_type, smf_subtype) not in self._dg_names_cache:
            raise se_error.EnvironmentError(
                f"DGAPI Environment was unable to find mappings for SMF {smf_type} Subtype {smf_subtype}",
                mode=ENVIRONMENT_MODE,
            )

        fields_cache = self._dg_names_cache[(smf_type, smf_subtype)].fields

        if field_name not in fields_cache:
            return field_name

        return fields_cache[field_name]

    def check(self) -> bool:
        check_result, api_doc = self._connector._check_api_doc()

        if check_result and self._dg_names_cache is None:
            self._dg_names_cache = {}
            self.__build_apidoc_mappings(api_doc)

        return check_result

    @staticmethod
    def mode() -> str:
        return ENVIRONMENT_MODE

    @staticmethod
    def _traverse_where_expressions(
        expr: se_expressions.WhereExpression, fields: Set[se_field.Field]
    ) -> None:

        if not isinstance(expr, se_expressions.WhereExpression):
            return

        if expr.operation == se_expressions.WhereExpressionType.OPERAND and isinstance(
            expr.operands[0], se_field.Field
        ):
            fields.add(expr.operands[0])
        else:
            for op in expr.operands:
                op: se_expressions.WhereExpression
                DGEnvironment._traverse_where_expressions(op, fields)

    def _pre_hook(self, req: se_request.FieldRequest) -> None:

        where_fields: Set[se_field.Field] = set()

        for expr in req.where_expressions:
            DGEnvironment._traverse_where_expressions(expr, where_fields)

        req.add_fields(where_fields, show_fields=False)

        req.post_processors.insert(
            0,
            se_resolvers.POST_RESOLVER.create(
                "core.correct_timestamps", mode=ENVIRONMENT_MODE
            ),
        )

    def _post_hook(
        self, df: pd.DataFrame, req: se_request.FieldRequest
    ) -> pd.DataFrame:

        return se_executor.generic_sorter(
            se_executor.generic_where_resolver(df, req.where_expressions),
            req.sort_expressions,
        )
