# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
import functools
from typing import Callable, Dict, Union

from smfexplorer.core import request


class Samples:
    def __init__(self):
        self._simple_samples: Dict[str, Callable] = dict()
        self._mode_samples: Dict[str, Dict[str, Callable]] = dict()

    def sample_names(self, mode: str) -> list:
        names = list(self._simple_samples.keys())
        if mode in self._mode_samples:
            names += self._mode_samples[mode].keys()
        return names

    def register(self, name: str = None, *modes: str):
        def decorator(func: Callable[..., request.Request]):
            nonlocal name
            nonlocal modes
            if not name:
                name = func.__name__

            if modes:
                for mode in modes:
                    if not mode in self._mode_samples:
                        self._mode_samples[mode] = {}
                    self._mode_samples[mode][name] = func
            else:
                self._simple_samples[name] = func

            return func

        return decorator

    def resolve(self, name: str, ctx):
        mode = ctx.environment.mode
        if name in self._simple_samples:
            func = self._simple_samples[name]
        elif mode in self._mode_samples and name in self._mode_samples[mode]:
            func = self._mode_samples[mode][name]
        else:
            return None

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, ctx=ctx, **kwargs)

            result.context = ctx

            return result

        wrapper.__name__ = name

        return wrapper


class SamplesResolver:
    def __init__(self, sample: Samples, ctx):
        self._sample = sample
        self._ctx = ctx

    def __dir__(self):
        return super().__dir__() + self._sample.sample_names(self._ctx.environment.mode)

    def __getattr__(
        self, name
    ) -> Callable[[], Union[request.FieldRequest, request.QueryRequest]]:
        result = self._sample.resolve(name, self._ctx)
        if result:
            return result

        raise AttributeError(f"{self.__class__.__name__} has no attribute {name}")
