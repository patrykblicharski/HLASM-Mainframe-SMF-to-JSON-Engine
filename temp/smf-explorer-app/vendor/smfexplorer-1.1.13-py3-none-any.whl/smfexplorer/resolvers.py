# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from smfexplorer.core.post_resolver import PostResolver
from smfexplorer.core.samples import Samples

POST_RESOLVER = PostResolver()
SAMPLES = Samples()


def register_post_processor(name: str, *modes: str):
    """Register a new `PostProcessor`. This is a decorator

    The decorated function needs to return a `PostProcessor` and may be given a `Field`, `RecordMap` or `Record` if it is used in the underlieing field Mappings.

    `modes` specifies the `Environment` modes the `PostProcessor` should be registered for.
    This allows to specify post-processors base on the backend the data is fetched from.

    Parameters
    ----------
    name : str
        Name of the `PostProcessor`
    modes: str
        Environment modes to register the post-processor for
    """
    return POST_RESOLVER.register(name, *modes)


def register_sample(*modes: str, name: str = None):
    """Register a new sample. This is a decorator.

    `modes` specifies the `Environment` modes the sample should be registered for.
    This allows to specify samples base on the backend the data is fetched from.
    The sample will not be shown with `ctx.samples.[sample_name]` if the `Environment` used by a `Context` does not support it.

    Parameters
    ----------
    name : str, optional
        The name of the sample. If non the name of the decorated function is used. Defaults to None.
    modes: str
        Environment modes to register the sample for
    """
    return SAMPLES.register(name, *modes)
