# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""SMF-py Module - Framework to fetch SMF data"""

# Allow namespaced modules - This is needed for plugin support
from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

import logging as _logging
import warnings
from typing import Iterable, Optional, Union

import pandas as _pandas

# isort: off

# ---------------------------------------------------------------------------- #
#                                 Logging Setup                                #
# ---------------------------------------------------------------------------- #″

_LOG = _logging.getLogger(__name__)

from smfexplorer._version import __version__

_LOG.debug("Running SMF Explorer version: %s", __version__)

# ---------------------------------------------------------------------------- #
#                                 Basic Imports                                #
# ---------------------------------------------------------------------------- #

import smfexplorer.error as __error

# Import dynamic fields module once to initialize for plugin load
import smfexplorer.fields as _
import smfexplorer.resolvers as _
from smfexplorer.core.plugin import PluginManager as __PluginManager

# ---------------------------------------------------------------------------- #
#                             Plugin Initialization                            #
# ---------------------------------------------------------------------------- #


__PLUGIN_MANAGER = __PluginManager()
__PLUGIN_MANAGER._load_plugins()

# ---------------------------------------------------------------------------- #
#                               Environment Setup                              #
# ---------------------------------------------------------------------------- #

from smfexplorer.core.environment import Environment
from smfexplorer.core.environment.factory import (
    EnvironmentFactory as __EnvironmentFactory,
)

# Import predefined environments
import smfexplorer.core.environment.dgapi as _


def setup(connection_string: str) -> None:
    """Setup SMF Explorer default environment with the information from `connection_string`.

    SMF Explorer will try to setup a default environment on it's own if possible.
    This function needs to be called if that is not possible.

    Args:
        connection_string (str): Connection string for a specific environment in the form `option1=value1;option2=value2...`
    """
    __EnvironmentFactory.set_default_environment(
        __EnvironmentFactory.create_environment(connection_string)
    )


def new_environment(connection_string: str) -> Environment:
    """Create a new `Environment` from `connection_string`.

    If only one `Environment` is required the user should call `smfexplorer.setup()` instead.

    Args:
        connection_string (str): Connection string for a specific environment in the form `option1=value1;option2=value2...`

    Returns:
        Environment: The `Environment` created with `connection_string`
    """
    return __EnvironmentFactory.create_environment(connection_string)


def set_default_environment(environment: Environment) -> None:
    """Replace the default `Environment` with `environment`.

    Usually users should call `smfexplorer.setup()` to create the default environment.

    Args:
        environment (Environment): The `Environment` to set as default
    """
    __EnvironmentFactory.set_default_environment(environment)


def get_default_environment() -> Optional[Environment]:
    """Get the default `Environment` SMF Explorer uses. Might be `None`.

    Returns:
        Optional[Environment]: [description]
    """
    return __EnvironmentFactory.get_default_environment()


# ---------------------------------------------------------------------------- #
#                   General Purpose Imports for SMF Explorer                   #
# ---------------------------------------------------------------------------- #

from smfexplorer.core.context import Context as __Context
from smfexplorer.core.expressions import (
    AND,
    ASC,
    BETWEEN,
    DESC,
    EQ,
    GT,
    GTE,
    LIKE,
    LT,
    LTE,
    NLIKE,
    NOT,
    NQ,
    OR,
)
from smfexplorer.util.names import names

# ---------------------------------------------------------------------------- #
#                     Default Environment Wrapper Functions                    #
# ---------------------------------------------------------------------------- #


def new_context(*dataset_names: Union[str, Iterable[str]]) -> __Context:
    """Create new `Context` for the default environment

    Parameters
    ----------
    dataset_names : str, list of str
        Name(s) of the dataset(s) to fetch SMF data from.
    """
    env = __EnvironmentFactory.get_default_environment()
    if not env:
        _LOG.debug("Default environment not set")
        raise __error.EnvironmentError(
            "Default environment is not defined. Initialize it with `smfexplorer.setup()`"
        )

    return env.new_context(*dataset_names)


def get_supported_records(dataset_name: str) -> _pandas.DataFrame:
    """Fetch the supported record types and subtypes for `dataset_name` using the default `Environment`

    Args:
        dataset_name (str): The dataset name to fetch the types for

    Raises:
        EnvironmentError: If no default `Environment` is set

    Returns
    -------
    DataFrame
        List of type/subtypes and amount contained in the dataset as pandas DataFrame.
         `Subtype` `0` means that the type has no subtype. The list is sorted by type and subtype.

            type    subtype     count
        0   2       0           2
        1   70      1           300
        2   99      2           1200
    """
    env = __EnvironmentFactory.get_default_environment()
    if not env:
        _LOG.debug("Default environment not set")
        raise __error.EnvironmentError(
            "Default environment is not defined. Initialize it with `smfexplorer.setup()`"
        )
    return env.get_supported_records(dataset_name)


def get_supported_types(dataset_name: str) -> _pandas.DataFrame:
    """Fetch the supported record types for `dataset_name` using the default `Environment`

    Args:
        dataset_name (str): The dataset name to fetch the types for

    Raises:
        EnvironmentError: If no default `Environment` is set

    Returns
    -------
    DataFrame
        List of type and amount contained in the dataset as pandas DataFrame.
        The list is sorted by type.

            type    count
        0   2       2
        1   70      300
        2   99      1200
    """
    env = __EnvironmentFactory.get_default_environment()
    if not env:
        _LOG.debug("Default environment not set")
        raise __error.EnvironmentError(
            "Default environment is not defined. Initialize it with `smfexplorer.setup()`"
        )
    return env.get_supported_types(dataset_name)


def get_supported_subtypes(dataset_name: str, type_: int) -> _pandas.DataFrame:
    """Fetch the supported record subtypes for `dataset_name` and `type_` using the default `Environment`

    Args:
        dataset_name (str): The dataset name to fetch the subtypes for
        type_ (int): The record type to fetch subtypes for

    Raises:
        EnvironmentError: If no default `Environment` is set

    Returns
    -------
    DataFrame
        List of subtype and amount contained in the dataset for `type_` as pandas DataFrame.
         `subtype` of `0` means that the type has no subtype. The list is sorted by subtype.

            subtype count
        0   1       2
        1   12      300
        2   13      1200
    """
    env = __EnvironmentFactory.get_default_environment()
    if not env:
        _LOG.debug("Default environment not set")
        raise __error.EnvironmentError(
            "Default environment is not defined. Initialize it with `smfexplorer.setup()`"
        )
    return env.get_supported_subtypes(dataset_name, type_)


def check_dataset(dataset_name: str) -> bool:
    """Check if `dataset_name` is accessible from the default `Environment`

    Args:
        dataset_name (str): The dataset name to check for

    Raises:
        EnvironmentError: If no default `Environment` is set
    """
    env = __EnvironmentFactory.get_default_environment()
    if not env:
        _LOG.debug("Default environment not set")
        raise __error.EnvironmentError(
            "Default environment is not defined. Initialize it with `smfexplorer.setup()`"
        )
    return env.check_dataset(dataset_name)


# ---------------------------------------------------------------------------- #
#                       Imports for Module Initialization                      #
# ---------------------------------------------------------------------------- #″

__PLUGIN_MANAGER._run_post_init()

# ---------------------------------------------------------------------------- #
#                              SMF Explorer Info Function                             #
# ---------------------------------------------------------------------------- #


def info() -> str:
    """Return a summary of SMF Explorer's current status"""
    import textwrap

    from smfexplorer.resolvers import POST_RESOLVER

    env_mode = "none"
    if __EnvironmentFactory.get_default_environment():
        env_mode = __EnvironmentFactory.get_default_environment().mode

    post_proc_list = []
    for mode in POST_RESOLVER._post_processor_mode_map.keys():
        post_proc_list.append(
            f"Registered Post-Processors for mode '{mode}':\n\n"
            + textwrap.fill(
                ", ".join(POST_RESOLVER._post_processor_mode_map[mode].keys())
            )
            + "\n"
        )

    post_proc_string = "\n\n".join(post_proc_list)

    return f"""SMF Explorer - Version {__version__}

Default Environment mode: { env_mode }
Loaded Plugins: { ", ".join([plugin for plugin in __PLUGIN_MANAGER._plugins]) }


Registered Post-Processors:

{textwrap.fill(", ".join(POST_RESOLVER._post_processor_map.keys()))}


{post_proc_string}"""
