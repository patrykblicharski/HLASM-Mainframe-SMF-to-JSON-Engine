# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

# pylint: disable=redefined-outer-name

import base64
import datetime
from urllib import parse as url_parse

import pandas as pd
import pytest
import requests
import requests_mock
from pandas.testing import assert_frame_equal

import smfexplorer
from smfexplorer import error
from smfexplorer.core import context as se_context
from smfexplorer.core import request as se_request
from smfexplorer.core.environment import dgapi as se_dgapi
from smfexplorer.core.environment.factory import EnvironmentFactory
from smfexplorer.fields import COMMON
from smfexplorer.tests.fields import T200S1 as t1

DG_URL = "https://dgapi.com"
username = "user1"
password = "pA$$W0rd"
space = " "


@pytest.fixture
def dgapi_connector() -> se_dgapi.DGConnector:
    return se_dgapi.DGConnector(DG_URL, username, password, False)


@pytest.fixture
def empty_context() -> se_context.Context:

    mock_environment = se_dgapi.DGEnvironment(
        {"url": DG_URL, "username": username, "password": password}
    )

    mock_environment._dg_names_cache = {
        (200, 1): se_dgapi.DGNamesCache(
            {
                "SMF200_SUBTYPE1_MAP_A": "smf200Subtype1MapA",
                "SMF200_SUBTYPE1_MAP_B": "smf200Subtype1MapB",
                "SMF200_SUBTYPE1_MAP_C": "smf200Subtype1MapC",
            },
            {
                "T200S1_MAP_A": "SMF200_SUBTYPE1_MAP_A",
                "T200S1_MAP_B": "SMF200_SUBTYPE1_MAP_B",
                "T200S1_MAP_C": "SMF200_SUBTYPE1_MAP_C",
            },
            {},
        )
    }

    return se_context.Context(["DATASET.NAME"], mock_environment)


@pytest.fixture
def dgapi_parser() -> se_dgapi.DGParser:
    return se_dgapi.DGParser(
        environment=se_dgapi.DGEnvironment(
            {"url": DG_URL, "username": username, "password": password}
        )
    )


class TestDGParser:
    def test_single_map(self, empty_context: se_context.Context):
        request = se_request.FieldRequest(
            [t1.mapa_a, t1.mapa_post], context=empty_context
        )
        query = empty_context.environment.parser.parse(request)[0]

        assert query.dataset_name == "DATASET.NAME"
        assert query.raw == "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
            {
                "datasetName": "DATASET.NAME",
                "SMF200_SUBTYPE1_MAP_A": "T200S1_POST,T200S1_A",
            }
        )

    def test_single_map_with_common_fields(self, empty_context: se_context.Context):

        request = se_request.FieldRequest(
            [COMMON.flg, t1.mapa_a, t1.mapa_post], context=empty_context
        )
        query = empty_context.environment.parser.parse(request)[0]

        assert query.dataset_name == "DATASET.NAME"
        assert query.raw == "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
            {
                "datasetName": "DATASET.NAME",
                "SMF200_SUBTYPE1": "SMF200FLG",
                "SMF200_SUBTYPE1_MAP_A": "T200S1_POST,T200S1_A",
            }
        )

    def test_single_map_with_common_field_from_record(
        self, empty_context: se_context.Context
    ):

        request = se_request.FieldRequest(
            [t1.f_a, t1.mapa_a, t1.mapa_post], context=empty_context
        )
        query = empty_context.environment.parser.parse(request)[0]

        assert query.dataset_name == "DATASET.NAME"
        assert query.raw == "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
            {
                "datasetName": "DATASET.NAME",
                "SMF200_SUBTYPE1": "T200S1_A",
                "SMF200_SUBTYPE1_MAP_A": "T200S1_POST,T200S1_A",
            }
        )

    def test_single_map_with_virtual_field(self, empty_context: se_context.Context):

        request = se_request.FieldRequest(
            [t1.mapa_a, t1.mapa_virtual], context=empty_context
        )
        query = empty_context.environment.parser.parse(request)[0]

        assert query.dataset_name == "DATASET.NAME"
        assert query.raw == "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
            {"datasetName": "DATASET.NAME", "SMF200_SUBTYPE1_MAP_A": "T200S1_A"}
        )

    def test_multiple_maps(self, empty_context: se_context.Context):

        request = se_request.FieldRequest([t1.mapa_a, t1.mapb_a], context=empty_context)
        query = empty_context.environment.parser.parse(request)[0]

        assert query.dataset_name == "DATASET.NAME"
        assert query.raw == "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
            {
                "datasetName": "DATASET.NAME",
                "SMF200_SUBTYPE1_MAP_B": "T200S1_A",
                "SMF200_SUBTYPE1_MAP_A": "T200S1_A",
            }
        )

    def test_multiple_maps_with_map_hierarchy(self, empty_context: se_context.Context):

        request = se_request.FieldRequest([t1.mapb_a, t1.mapc_a], context=empty_context)
        query = empty_context.environment.parser.parse(request)[0]

        assert query.dataset_name == "DATASET.NAME"
        assert query.raw == "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
            {
                "datasetName": "DATASET.NAME",
                "SMF200_SUBTYPE1_MAP_B": "T200S1_A",
                "SMF200_SUBTYPE1_MAP_C": "T200S1_A",
            }
        )

    def test_check_sysid_is_added_to_request(self, empty_context: se_context.Context):

        request = se_request.FieldRequest([t1.mapa_post], context=empty_context)
        request = request.of_system("SYSA")
        query = empty_context.environment.parser.parse(request)[0]
        assert query.raw == "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
            {
                "datasetName": "DATASET.NAME",
                "SMF200_SUBTYPE1_MAP_A": "T200S1_POST",
                "systemName": "SYSA",
            }
        )

    def test_check_time_filter_is_added_to_request(
        self, empty_context: se_context.Context
    ):

        request = se_request.FieldRequest([t1.mapa_post], context=empty_context)
        request = request.in_time(
            start_time=datetime.datetime(2022, 1, 1, 2, 3, 4),
            end_time=datetime.datetime(2022, 1, 31, 3, 4, 5),
        )
        query = empty_context.environment.parser.parse(request)[0]
        assert query.raw == "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
            {
                "datasetName": "DATASET.NAME",
                "SMF200_SUBTYPE1_MAP_A": "T200S1_POST",
                "startTime": "2022-01-01T02:03:04",
                "endTime": "2022-01-31T03:04:05",
            }
        )


# TODO: Where expression resolution


class TestDGConnector:
    def test_check_dataset(self, dgapi_connector: se_dgapi.DGConnector):

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL
                + "/v1/smf/discover/dataset/exists/TEST.DATASET?datasetName=TEST.DATASET",
                status_code=200,
                text="true",
            )

            assert dgapi_connector.check_dataset("TEST.DATASET")

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL
                + "/v1/smf/discover/dataset/exists/TEST.DATASET?datasetName=TEST.DATASET",
                status_code=200,
                text="true",
            )

            assert dgapi_connector.check_dataset_unsafe("TEST.DATASET")

    def test_check_dataset_not_found(self, dgapi_connector: se_dgapi.DGConnector):

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL
                + "/v1/smf/discover/dataset/exists/TEST.DATASET?datasetName=TEST.DATASET",
                status_code=404,
                text="false",
            )

            assert not dgapi_connector.check_dataset("TEST.DATASET")

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL
                + "/v1/smf/discover/dataset/exists/TEST.DATASET?datasetName=TEST.DATASET",
                status_code=500,
            )
            assert not dgapi_connector.check_dataset("TEST.DATASET")

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL
                + "/v1/smf/discover/dataset/exists/TEST.DATASET?datasetName=TEST.DATASET",
                exc=requests.exceptions.RequestException,
            )
            assert not dgapi_connector.check_dataset("TEST.DATASET")

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL
                + "/v1/smf/discover/dataset/exists/TEST.DATASET?datasetName=TEST.DATASET",
                status_code=404,
                text="false",
            )

            assert not dgapi_connector.check_dataset_unsafe("TEST.DATASET")

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL
                + "/v1/smf/discover/dataset/exists/TEST.DATASET?datasetName=TEST.DATASET",
                status_code=500,
            )

            with pytest.raises(
                error.ConnectorError,
                match=r"Failed to fetch data for dataset 'TEST.DATASET' with status code 500",
            ):
                dgapi_connector.check_dataset_unsafe("TEST.DATASET")

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL
                + "/v1/smf/discover/dataset/exists/TEST.DATASET?datasetName=TEST.DATASET",
                exc=requests.exceptions.RequestException,
            )

            with pytest.raises(
                error.ConnectorError,
                match=r"Unexpected error connecting to REST Services. Check connection to host.",
            ):
                dgapi_connector.check_dataset_unsafe("TEST.DATASET")

    def test_fetch_dataset_description(self, dgapi_connector: se_dgapi.DGConnector):
        with requests_mock.Mocker() as mock:
            response = {
                "datasetCreationDate": "2020-01-01",
                "estimatedByteSize": 100,
                "totalNumberOfRecords": 20,
                "smfIds": ["SYSA", "SYSB"],
                "earliestSmfRecordMoveTime": "2020-01-01T00:01:02.03",
                "latestSmfRecordMoveTime": "2020-12-31T00:01:02.03",
                "earliestStartOfSmfInterval": "2020-02-01T00:01:02.03",
                "latestEndOfSmfInterval": "2020-05-01T00:01:02.03",
                "smfGroups": {
                    "2": {
                        "estimatedByteSize": 60,
                        "totalNumberOfRecords": 15,
                        "smfIds": ["SYSA"],
                        "earliestSmfRecordMoveTime": "2020-01-01T00:01:02.03",
                        "latestSmfRecordMoveTime": "2020-06-01T00:01:02.03",
                        "earliestStartOfSmfInterval": "2020-02-01T00:01:02.03",
                        "latestStartOfSmfInterval": "2020-03-01T00:01:02.03",
                        "earliestEndOfSmfInterval": "2020-04-01T00:01:02.03",
                        "latestEndOfSmfInterval": "2020-05-01T00:01:02.03",
                    },
                    "70-1": {
                        "estimatedByteSize": 40,
                        "totalNumberOfRecords": 5,
                        "smfIds": ["SYSB"],
                        "earliestSmfRecordMoveTime": "2020-06-01T00:01:02.03",
                        "latestSmfRecordMoveTime": "2020-06-30T00:01:02.03",
                    },
                },
            }

            type_info_expected = pd.DataFrame(
                {
                    "type": [2, 70],
                    "subtype": [0, 1],
                    "count": [15, 5],
                    "system_ids": [["SYSA"], ["SYSB"]],
                    "estimated_size_in_bytes": [60, 40],
                    "first_time_in_buffer": [
                        pd.Timestamp("2020-01-01 00:01:02.030000"),
                        pd.Timestamp("2020-06-01 00:01:02.030000"),
                    ],
                    "last_time_in_buffer": [
                        pd.Timestamp("2020-06-01 00:01:02.030000"),
                        pd.Timestamp("2020-06-30 00:01:02.030000"),
                    ],
                    "earliest_start": [
                        pd.Timestamp("2020-02-01 00:01:02.030000"),
                        pd.NaT,
                    ],
                    "lastest_start": [
                        pd.Timestamp("2020-03-01 00:01:02.030000"),
                        pd.NaT,
                    ],
                    "earliest_end": [
                        pd.Timestamp("2020-04-01 00:01:02.030000"),
                        pd.NaT,
                    ],
                    "lastest_end": [pd.Timestamp("2020-05-01 00:01:02.030000"), pd.NaT],
                }
            )

            type_info_expected = type_info_expected.astype(
                {
                    "type": "Int64",
                    "subtype": "Int64",
                    "count": "Int64",
                    "estimated_size_in_bytes": "Int64",
                }
            )

            mock.get(
                DG_URL
                + "/v1/smf/discover/describe/TEST.DATASET?datasetName=TEST.DATASET",
                json=response,
            )

            result = dgapi_connector.fetch_dataset_description("TEST.DATASET")

            assert result["creation_date"] == datetime.date(2020, 1, 1)
            assert result["count"] == 20
            assert result["system_ids"] == ["SYSA", "SYSB"]
            assert result["estimated_size_in_bytes"] == 100
            assert result["first_time_in_buffer"] == pd.Timestamp(
                "2020-01-01 00:01:02.030000"
            )
            assert result["last_time_in_buffer"] == pd.Timestamp(
                "2020-12-31 00:01:02.030000"
            )
            assert result["earliest_start"] == pd.Timestamp(
                "2020-02-01 00:01:02.030000"
            )
            assert result["lastest_start"] is pd.NaT
            assert result["earliest_end"] is pd.NaT
            assert result["lastest_end"] == pd.Timestamp("2020-05-01 00:01:02.030000")

            assert_frame_equal(result["type_info"], type_info_expected)

    def test_fetch_smf_types_of_dataset(self, dgapi_connector: se_dgapi.DGConnector):

        with requests_mock.Mocker() as mock:

            mock.get(
                DG_URL
                + "/v1/smf/discover/describe/TEST.DATASET?datasetName=TEST.DATASET",
                json={
                    "smfGroups": {
                        "2": {"totalNumberOfRecords": 2},
                        "70-1": {"totalNumberOfRecords": 100},
                        "71-3": {"totalNumberOfRecords": 200},
                        "90": {"totalNumberOfRecords": 300},
                        "99-1": {"totalNumberOfRecords": 400},
                    },
                },
            )

            expected = pd.DataFrame(
                {
                    "type": [2, 70, 71, 90, 99],
                    "subtype": [0, 1, 3, 0, 1],
                    "count": [2, 100, 200, 300, 400],
                },
                dtype="Int64",
            )

            assert_frame_equal(
                dgapi_connector.fetch_dataset_smftypes("TEST.DATASET"), expected
            )

    def test_fetch_smf_types_of_dataset_not_found(
        self, dgapi_connector: se_dgapi.DGConnector
    ):

        with requests_mock.Mocker() as mock:

            mock.get(
                DG_URL
                + "/v1/smf/discover/describe/TEST.DATASET?datasetName=TEST.DATASET",
                status_code=404,
            )

            with pytest.raises(error.ConnectorError, match=r"Unable to find dataset"):
                dgapi_connector.fetch_dataset_smftypes("TEST.DATASET")

        with requests_mock.Mocker() as mock:

            mock.get(
                DG_URL
                + "/v1/smf/discover/describe/TEST.DATASET?datasetName=TEST.DATASET",
                status_code=500,
            )

            with pytest.raises(
                error.ConnectorError,
                match=r"Failed to fetch data for dataset 'TEST.DATASET' with status code 500",
            ):
                dgapi_connector.fetch_dataset_smftypes("TEST.DATASET")

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL
                + "/v1/smf/discover/describe/TEST.DATASET?datasetName=TEST.DATASET",
                exc=requests.exceptions.RequestException,
            )

            with pytest.raises(
                error.ConnectorError,
                match=r"Unexpected error connecting to REST Services. Check connection to host.",
            ):
                dgapi_connector.fetch_dataset_smftypes("TEST.DATASET")

    def test_check_connection_availablility(
        self, dgapi_connector: se_dgapi.DGConnector
    ):

        with requests_mock.Mocker() as mock:
            mock.get(DG_URL + "/v3/api-docs", exc=requests.exceptions.RequestException)

            assert not dgapi_connector.check()

        with requests_mock.Mocker() as mock:
            mock.get(DG_URL + "/v3/api-docs", status_code=404)

            assert not dgapi_connector.check()

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL + "/v3/api-docs",
                status_code=200,
                text="""{"info": {"title: "TEST"}}""",
            )

            assert not dgapi_connector.check()

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL + "/v3/api-docs",
                status_code=200,
                json={"infos": {"title": se_dgapi._DG_API_NAME}},
            )

            assert not dgapi_connector.check()

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL + "/v3/api-docs",
                status_code=200,
                json={"info": {"title": "Other"}},
            )

            assert not dgapi_connector.check()

        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL + "/v3/api-docs",
                status_code=200,
                json={"info": {"title": se_dgapi._DG_API_NAME}},
            )

            assert dgapi_connector.check()

    def test_check_if_authentication_info_is_added_to_request(
        self, dgapi_connector: se_dgapi.DGConnector
    ):
        query = se_dgapi.DGQuery("DATASET.NAME", 200, 1)
        with requests_mock.Mocker() as mock:
            mock.get(
                DG_URL + "/v1/smf/type/200/subtype/1?datasetName=DATASET.NAME",
                status_code=200,
            )
            encoded_auth = base64.b64encode(f"{username}:{password}".encode()).decode()
            resp = dgapi_connector.make_request(
                query.raw, dataset_name=query.dataset_name
            )
            assert resp.request.headers["Authorization"] == f"Basic {encoded_auth}"


class TestDGDataParser:

    # TODO: Extend Test for data parser

    def test_basic_test(self, empty_context: se_context.Context):

        request = se_request.FieldRequest([t1.date, t1.mapa_a], context=empty_context)

        parser = se_dgapi.DGDataParser(
            request,
            True,
            map_index=[t1.mapa_a.record_map],
            environment=empty_context.environment,
            array_fields={},
        )

        df = parser.build_dataframe(
            {
                "0": {
                    "SMF200DTE": "2021-01-01",
                    "smf200Subtype1MapA": {"T200S1_A": "A"},
                },
                "1": {
                    "SMF200DTE": "2021-01-01",
                    "smf200Subtype1MapA": {"T200S1_A": "A"},
                },
            }
        )

        expected_df = pd.DataFrame(
            {
                "smf20001_index": [1, 2],
                "date": [datetime.date(2021, 1, 1), datetime.date(2021, 1, 1)],
                "smf20001_t200s1_map_a_index": [1, 1],
                "mapa_a": ["A", "A"],
            }
        )

        assert_frame_equal(df, expected_df)

    def test_array_parsing(self, empty_context: se_context.Context):
        request = se_request.FieldRequest(
            [t1.date, t1.mapa_array, t1.mapa_array[0]], context=empty_context
        )

        parser = se_dgapi.DGDataParser(
            request,
            True,
            map_index=[t1.mapa_a.record_map],
            environment=empty_context.environment,
            array_fields={t1.mapa_array: [t1.mapa_array[0]]},
        )

        df = parser.build_dataframe(
            {
                "0": {
                    "SMF200DTE": "2021-01-01",
                    "smf200Subtype1MapA": {
                        "T200S1_ARRAY": {"0": 1, "1": 2, "2": 3, "3": 4}
                    },
                },
                "1": {
                    "SMF200DTE": "2021-01-01",
                    "smf200Subtype1MapA": {
                        "T200S1_ARRAY": {"0": 1, "1": 2, "2": 3, "3": 4}
                    },
                },
            }
        )

        expected_df = pd.DataFrame(
            {
                "smf20001_index": [1, 2],
                "date": [datetime.date(2021, 1, 1), datetime.date(2021, 1, 1)],
                "smf20001_t200s1_map_a_index": [1, 1],
                "mapa_array": [
                    {0: 1, 1: 2, 2: 3, 3: 4},
                    {0: 1, 1: 2, 2: 3, 3: 4},
                ],
                "mapa_array[0]": [1, 1],
            }
        )

        expected_df = expected_df.astype({"mapa_array[0]": "Int64"}, copy=False)

        assert_frame_equal(df, expected_df)

    def test_array_parsing_with_na(self, empty_context: se_context.Context):
        request = se_request.FieldRequest(
            [t1.date, t1.mapa_array, t1.mapa_array[0]], context=empty_context
        )

        parser = se_dgapi.DGDataParser(
            request,
            True,
            map_index=[t1.mapa_a.record_map],
            environment=empty_context.environment,
            array_fields={t1.mapa_array: [t1.mapa_array[0]]},
        )

        df = parser.build_dataframe(
            {
                "0": {
                    "SMF200DTE": "2021-01-01",
                    "smf200Subtype1MapA": {},
                },
                "1": {
                    "SMF200DTE": "2021-01-01",
                    "smf200Subtype1MapA": {},
                },
            }
        )

        expected_df = pd.DataFrame(
            {
                "smf20001_index": [1, 2],
                "date": [datetime.date(2021, 1, 1), datetime.date(2021, 1, 1)],
                "smf20001_t200s1_map_a_index": [1, 1],
                "mapa_array": [pd.NA, pd.NA],
                "mapa_array[0]": [pd.NA, pd.NA],
            }
        )

        expected_df = expected_df.astype({"mapa_array[0]": "Int64"}, copy=False)

        assert_frame_equal(df, expected_df)


# ---------------------------------------------------------------------------- #
#                                DG Environment                                #
# ---------------------------------------------------------------------------- #


class TestDGEnvironment:
    @pytest.mark.parametrize(
        "connection_info,result",
        [
            (dict(), False),
            (dict(verify_ssl=""), False),
            (dict(url=""), True),
            (dict(url="", verify_ssl=""), True),
        ],
    )
    def test_check_environment_connection_info(
        self,
        connection_info,
        result,
    ):
        connection_info["username"] = username
        connection_info["password"] = password
        assert (
            se_dgapi.DGEnvironment.check_environment_availability(connection_info)
            == result
        )

    def test_create_with_username_and_password(self):
        connection_info = dict(url="https://relay.com:12002/zosdg")
        connection_info["username"] = username
        connection_info["password"] = password

        env = se_dgapi.DGEnvironment(connection_info)

        assert env.mode() == "dgapi"
        assert isinstance(env.connector, se_dgapi.DGConnector)
        assert isinstance(env.parser, se_dgapi.DGParser)

        assert env.connector._url == "https://relay.com:12002/zosdg"
        assert env.connector._session.auth == (username, password)

    def test_name_and_password_with_surrounding_space(self):
        connection_info = dict(url="https://relay.com:12002/zosdg")

        connection_info["username"] = f"username{space}"  # pragma: allowlist-secret
        connection_info["password"] = (
            f"{space}pas{space}@sword"  # pragma: allowlist-secret
        )
        env = se_dgapi.DGEnvironment(connection_info)
        assert env.connector._username == "username"  # pragma: allowlist-secret
        assert env.connector._password == "pas @sword"  # pragma: allowlist-secret

    @pytest.mark.parametrize(
        "verify_ssl,verify_ssl_result", [("yes", True), ("no", False), (None, True)]
    )
    def test_create_environment_with_verify_ssl(self, verify_ssl, verify_ssl_result):

        connection_info = dict(
            url="https://relay.com:12002/zosdg", username=username, password=password
        )

        if verify_ssl:
            connection_info["verify_ssl"] = verify_ssl

        env = se_dgapi.DGEnvironment(connection_info)

        assert env.mode() == "dgapi"
        assert isinstance(env.connector, se_dgapi.DGConnector)
        assert isinstance(env.parser, se_dgapi.DGParser)

        assert env.connector._url == "https://relay.com:12002/zosdg"
        assert env.connector._session.verify == verify_ssl_result

    @pytest.mark.parametrize(
        "info,warning,message",
        [
            (
                dict(
                    url="http://dgapi.domain.com:8080/some/path",
                    username="user",
                    password="password",
                ),
                error.InsecureConnectionWarning,
                r"Using non-encrypted http connections potentially exposes user credentials and data",
            )
        ],
    )
    def test_warnings_during_create(self, info, warning, message):
        with pytest.warns(warning, match=message):
            se_dgapi.DGEnvironment(info)

    @pytest.mark.parametrize(
        "info,message",
        [
            (
                dict(),
                r"Missing or empty 'url' parameter in connection string",
            ),
            (
                dict(url=""),
                r"Missing or empty 'url' parameter in connection string",
            ),
            (
                dict(url="dgapi.domain.com:8080/some/path"),
                r"Missing protocol scheme in url",
            ),
            (
                dict(url="https://relay.com:12002/zosdg"),
                r"No authentication information provided",
            ),
            (
                dict(url="ftp://dgapi.domain.com:8080/some/path"),
                r"Schema of provided connection information is not http\[s\]",
            ),
        ],
    )
    def test_errors_during_create(self, info, message):

        with pytest.raises(error.EnvironmentError, match=message):
            se_dgapi.DGEnvironment(info)

    def test_adding_where_expressions_to_request_sets_fields_lists_correctly(
        self, empty_context: se_context.Context
    ):
        request = se_request.FieldRequest([t1.mapa_post], context=empty_context)
        request = request.where(t1.mapa_a == "A")
        empty_context.environment._pre_hook(request)

        assert t1.mapa_a in request.fields

        request = se_request.FieldRequest([t1.mapa_post], context=empty_context)
        request = request.where(t1.mapa_a == t1.mapa_virtual)
        empty_context.environment._pre_hook(request)

        assert t1.mapa_a in request.fields
        assert t1.mapa_virtual in request.fields

    def test_setup_default_environment_and_check_ds(self):
        dsname = "SOME.DS.NAME"
        conn = f"mode=dgapi;url={DG_URL};verify_ssl=false;username={username};password={password}"

        with requests_mock.Mocker() as mock:
            response = {
                "info": {"title": "z/OS Data Gatherer: SMF Data REST Services"},
                "components": {"schemas": {}},
            }
            mock.get(f"{DG_URL}/v3/api-docs", status_code=200, json=response)
            smfexplorer.setup(conn)
        assert EnvironmentFactory.get_default_environment()
        ctx = smfexplorer.new_context(dsname)
        assert ctx.environment._connection_info == {
            "mode": "dgapi",
            "url": DG_URL,
            "verify_ssl": "false",
            "username": username,
            "password": password,
        }

        with requests_mock.Mocker() as mock:
            mock.get(
                f"{DG_URL}/v1/smf/discover/dataset/exists/{dsname}", status_code=200
            )
            assert smfexplorer.check_dataset(dsname)

        EnvironmentFactory.set_default_environment(None)
        assert not EnvironmentFactory.get_default_environment()
