# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from typing import Dict
from unittest import mock

from smfexplorer.core.environment import Connector, Environment, Parser


class MockEnvironment(Environment):
    def __init__(self, connection_info: Dict[str, str]) -> None:
        super().__init__(connection_info)

        self._parser = mock.Mock(spec=Parser)
        self._connector = mock.Mock(spec=Connector)

    @classmethod
    def check_environment_availability(cls, connection_info: Dict[str, str]) -> bool:
        return super().check_environment_availability(connection_info)

    @staticmethod
    def mode() -> str:
        return "test"

    def check(self) -> bool:
        return super().check()
