# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
import pytest

from smfexplorer.core import post_processor as se_post_processor
from smfexplorer.core import post_resolver as se_post_resolver


@pytest.fixture
def resolver():
    yield se_post_resolver.PostResolver()


class TestPostResolver:
    def test_registration_and_resolution_of_post_processors(
        self,
        resolver: se_post_resolver.PostResolver,
    ):
        @resolver.register("test")
        def proc():
            return se_post_processor.PostProcessor(
                se_post_processor.PostProcessorType.MAP, lambda: "child"
            )

        @resolver.register("test.specific", "relay")
        def relay_proc():
            return se_post_processor.PostProcessor(
                se_post_processor.PostProcessorType.FRAME, lambda: "parent"
            )

        @resolver.register("test.specific", "dsdbc")
        def dsdbc_proc():
            return se_post_processor.PostProcessor(
                se_post_processor.PostProcessorType.FILTER, lambda: "parent"
            )

        result = resolver.create("test")
        assert result.processor_type == se_post_processor.PostProcessorType.MAP

        second_result = resolver.create("test")
        assert result is second_result

        resolver.clear_cache()
        third_result = resolver.create("test")
        assert not result is third_result

        result_relay = resolver.create("test.specific", mode="relay")
        assert result_relay.processor_type == se_post_processor.PostProcessorType.FRAME

        result_dsdbc = resolver.create("test.specific", mode="dsdbc")
        assert result_dsdbc.processor_type == se_post_processor.PostProcessorType.FILTER

        assert not resolver.create("test.none")

        @resolver.register("test.relay_only", "relay")
        def relay_only():
            return se_post_processor.PostProcessor(
                se_post_processor.PostProcessorType.MAP, lambda: "parent"
            )

        assert not resolver.create("test.relay_only", mode="dsdbc")
