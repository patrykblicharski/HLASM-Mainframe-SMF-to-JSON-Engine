# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
import pytest

from smfexplorer.core.field import Field
from smfexplorer.tests.fields import T200S1 as t1
from smfexplorer.tests.fields import T200S2 as t2
from smfexplorer.util.names import names


class TestUtils:
    def test_single_field(self):
        assert names(t1.f_a) == "f_a"

    def test_single_field_and_args(self):
        assert names(t1.f_a, t1.f_post) == ["f_a", "f_post"]

    def test_array_field(self):
        assert names([t1.f_a, t1.f_post]) == ["f_a", "f_post"]

    def test_array_field_and_args(self):
        assert names([t1.f_a, t1.f_post], t1.f_post_param) == [
            "f_a",
            "f_post",
            "f_post_param",
        ]
