# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from typing import Tuple
from unittest import mock

import pandas as pd
import pytest
from pandas.testing import assert_frame_equal

from smfexplorer import error, resolvers
from smfexplorer.core import context as se_context
from smfexplorer.core import environment as se_environment
from smfexplorer.core import executor as se_executor
from smfexplorer.core import expressions as se_expressions
from smfexplorer.core import field as se_field
from smfexplorer.core import request as se_request
from smfexplorer.fields import COMMON
from smfexplorer.tests.fields import T200S1 as t1
from smfexplorer.tests.fields import T200S2 as t2
from smfexplorer.tests.helpers import MockEnvironment


@pytest.fixture(scope="function")
def environment():
    yield MockEnvironment({})


@pytest.fixture(scope="function")
def context(environment: se_environment.Environment):
    yield se_context.Context(["TEST_DATASET"], environment)


@pytest.fixture(scope="class")
def post_procs():
    def virtual_post(df: pd.DataFrame):
        if "mapa_a" in df:
            df["mapa_virtual"] = df["mapa_a"]
        elif "mapb_a" in df:
            df["mapb_virtual"] = df["mapb_a"]
        return df

    record_post_proc = mock.Mock(
        required_fields=[COMMON.timestamp], apply=mock.Mock(side_effect=lambda df: df)
    )
    record_map_post_proc = mock.Mock(
        required_fields=[COMMON.timestamp], apply=mock.Mock(side_effect=lambda df: df)
    )
    field_post_proc = mock.Mock(
        required_fields=[COMMON.timestamp], apply=mock.Mock(side_effect=lambda df: df)
    )
    field_v_post_proc = mock.Mock(
        required_fields=[COMMON.timestamp], apply=mock.Mock(side_effect=virtual_post)
    )

    @resolvers.register_post_processor("test.record_post_proc", "test")
    def test_record_proc(record: se_field.Record):
        record_post_proc(record)
        return record_post_proc

    @resolvers.register_post_processor("test.map_post_proc", "test")
    def test_record_map_proc(record_map: se_field.RecordMap):
        record_map_post_proc(record_map)
        return record_map_post_proc

    @resolvers.register_post_processor("test.field_post_proc_a", "test")
    def test_field_proc(field: se_field.Field):
        field_post_proc(field)
        return field_post_proc

    @resolvers.register_post_processor("test.field_virtual_a", "test")
    def test_virtual_field_proc(field: se_field.Field):
        field_v_post_proc(field)
        return field_v_post_proc

    yield (record_post_proc, record_map_post_proc, field_post_proc, field_v_post_proc)

    del resolvers.POST_RESOLVER._post_processor_mode_map["test"]
    resolvers.POST_RESOLVER.clear_cache()


class TestExecutor:
    def test_apply_record_post_processors(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t2.mapa_a], context)

        se_executor.collect_post_processors(request)

        record_mock.assert_called_with(t2.mapa_a.record)
        map_mock.assert_called_with(t2.mapa_a.record_map)

        assert request.post_processors[0] is record_mock
        assert request.post_processors[1] is map_mock

        assert COMMON.timestamp in request.fields

    def test_apply_field_post_processors(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t1.mapa_post], context)

        se_executor.collect_post_processors(request)

        field_mock.assert_called_with(t1.mapa_post)

        assert request.post_processors[0] is field_mock

    # TODO: FIX Test
    @pytest.mark.skip
    def test_not_applying_field_post_processors_if_not_defined_for_mode(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t1.mapa_post], context)

        with mock.patch.object(context.environment, "mode") as mode_mock:
            mode_mock.return_value = "other"
            se_executor.collect_post_processors(request)

        field_mock.assert_not_called()

        assert not request.post_processors

    def test_apply_virtual_field_post_processors(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t1.mapa_virtual, t1.mapa_post], context)

        se_executor.collect_post_processors(request)

        field_mock.assert_called_with(t1.mapa_post)
        field_v_mock.assert_called_with(t1.mapa_virtual)

        assert request.post_processors[0] is field_mock
        assert request.post_processors[1] is field_v_mock

    def test_execute_post_processors(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t1.mapa_virtual, t1.mapa_post], context)

        se_executor.collect_post_processors(request)

        field_mock.assert_called_with(t1.mapa_post)
        field_v_mock.assert_called_with(t1.mapa_virtual)

        assert request.post_processors[0] is field_mock
        assert request.post_processors[1] is field_v_mock

        df = pd.DataFrame({"mapa_a": [5, 4, 3, 2, 1], "mapa_post": [1, 2, 3, 4, 5]})
        expected = pd.DataFrame(
            {
                "mapa_a": [5, 4, 3, 2, 1],
                "mapa_post": [1, 2, 3, 4, 5],
                "mapa_virtual": [5, 4, 3, 2, 1],
            }
        )

        result = se_executor.execute_post_process(df, request)

        assert_frame_equal(result, expected)

        field_v_mock.apply.assert_called_with(df)

    def test_dataframe_cleanup(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t1.mapa_virtual, t1.mapa_post], context)

        se_executor.collect_post_processors(request)

        field_mock.assert_called_with(t1.mapa_post)
        field_v_mock.assert_called_with(t1.mapa_virtual)

        assert request.post_processors[0] is field_mock
        assert request.post_processors[1] is field_v_mock

        df = pd.DataFrame(
            {
                "mapa_a": [5, 4, 3, 2, 1],
                "mapa_post": [1, 2, 3, 4, 5],
                "mapa_virtual": [5, 4, 3, 2, 1],
            }
        )

        expected = pd.DataFrame(
            {
                "mapa_virtual": [5, 4, 3, 2, 1],
                "mapa_post": [1, 2, 3, 4, 5],
            }
        )

        result = se_executor.cleanup_dataframe(df, request)

        assert_frame_equal(result, expected)

    def test_run_field_request(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        from datetime import date, time

        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t1.mapb_virtual, t1.mapb_post], context)

        df = pd.DataFrame(
            {
                "time": [time.fromisoformat("10:00:00.000")] * 5,
                "date": [date.fromisoformat("2001-01-01")] * 5,
                "mapb_a": [5, 4, 3, 2, 1],
                "mapb_post": [1, 2, 3, 4, 5],
            }
        )
        context.environment.connector.query.return_value = df
        context.environment.parser.parse.return_value = [mock.Mock()]

        result = se_executor.run(request)

        field_mock.assert_called_with(t1.mapb_post)
        field_v_mock.assert_called_with(t1.mapb_virtual)
        record_mock.assert_called_with(t1.mapb_post.record)
        map_mock.assert_called_with(t1.mapb_post.record_map)

        expected = pd.DataFrame(
            {"mapb_virtual": [5, 4, 3, 2, 1], "mapb_post": [1, 2, 3, 4, 5]}
        )

        assert_frame_equal(result, expected, check_dtype=False)

    def test_run_field_request_empty_dataset(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t1.mapa_virtual, t1.mapb_a], context)

        context.environment.connector.query.side_effect = error.EmptyDataSetError
        context.environment.parser.parse.return_value = [mock.Mock()]

        with pytest.raises(error.EmptyDataSetError):
            se_executor.run(request)

    def test_run_field_request_dry_run(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t1.mapa_virtual, t1.mapb_a], context)

        context.environment.parser.parse.return_value = ["Query"]

        assert se_executor.run(request, dry_run=True) == ["Query"]

    def test_run_query_request(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.QueryRequest("Query", context)

        df = pd.DataFrame({"mapa_a": [5, 4, 3, 2, 1], "mapa_post": [1, 2, 3, 4, 5]})
        context.environment.connector.query.return_value = df
        context.environment.parser.query.return_value = [mock.Mock()]

        result = se_executor.run(request)

        expected = pd.DataFrame(
            {"mapa_a": [5, 4, 3, 2, 1], "mapa_post": [1, 2, 3, 4, 5]}
        )

        assert_frame_equal(result, expected, check_dtype=False)

    def test_run_query_request_empty_dataset(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.QueryRequest("Query", context)

        context.environment.connector.query.side_effect = error.EmptyDataSetError
        context.environment.parser.query.return_value = [mock.Mock()]

        with pytest.raises(error.EmptyDataSetError):
            se_executor.run(request)

    def test_run_query_request_dry_run(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.QueryRequest("Query", context)

        context.environment.parser.query.return_value = ["Query"]

        assert se_executor.run(request, dry_run=True) == ["Query"]

    def test_find_fields_to_remove_and_extract(
        self,
        post_procs: Tuple[mock.Mock],
        context: se_context.Context,
    ):
        record_mock, map_mock, field_mock, field_v_mock = post_procs

        request = se_request.FieldRequest([t1.mapa_virtual, t1.mapa_post], context)

        fields_to_remove = se_executor.find_fields_to_remove(request)
        fields_to_extract = se_executor.find_fields_to_extract(
            ["mapa_a", "mapa_virtual", "mapa_post"],
            fields_to_remove,
            request.requested_fields,
        )

        assert fields_to_remove == set(["mapa_a"])
        assert fields_to_extract == [t1.mapa_virtual, t1.mapb_a]

    def test_generic_sort_works_correctly(self):
        mock_data = pd.DataFrame(
            data={
                "mapa_post": [10, 20, 30, 10, 20, 30],
                "mapb_a": [10, 10, 10, 20, 40, 60],
            }
        )

        expected_result = pd.DataFrame(
            data={
                "mapa_post": [10, 10, 20, 20, 30, 30],
                "mapb_a": [20, 10, 40, 10, 60, 10],
            }
        )

        result = se_executor.generic_sorter(
            mock_data,
            [se_expressions.ASC(t1.mapa_post), se_expressions.DESC(t1.mapb_a)],
        )

        assert_frame_equal(expected_result, result)

        assert mock_data is se_executor.generic_sorter(mock_data, [])

    # TODO: Fix test for new types
    @pytest.mark.skip
    @pytest.mark.parametrize(
        "level,expected_dtypes",
        enumerate(
            [
                [
                    "Int64",
                    "float64",
                    "float64",
                    "float64",
                    "object",
                    "Int64",
                    "Int64",
                    "Int64",
                    "Int64",
                    "Int64",
                    "Int64",
                    "Int64",
                ],
                [
                    "Int64",
                    "float32",
                    "float32",
                    "float32",
                    "object",
                    "Int64",
                    "Int64",
                    "Int64",
                    "Int64",
                    "Int64",
                    "Int64",
                    "Int64",
                ],
                [
                    "UInt8",
                    "float32",
                    "float32",
                    "float32",
                    "object",
                    "UInt8",
                    "UInt16",
                    "UInt32",
                    "UInt64",
                    "Int16",
                    "Int32",
                    "Int64",
                ],
                [
                    "UInt8",
                    "float32",
                    "float32",
                    "float32",
                    "object",
                    "UInt8",
                    "UInt16",
                    "UInt32",
                    "UInt64",
                    "Int16",
                    "Int32",
                    "Int64",
                ],
            ]
        ),
    )
    def test_optimize_memory_footprint(
        self,
        level,
        expected_dtypes,
    ):
        dummy_dataframe = pd.DataFrame(
            {
                "uint": [1, 2, 3],
                "uint2": [1.0, 2.0, 3.0],
                "int2": [-1.0, 2.0, 3.0],
                "float": [0.1, 0.2, 0.3],
                "str": ["a", "a", "a"],
                "small_int": [1, 1, 0],
                "uint16": [1000, 2000, 3000],
                "uint32": [100000, 200000, 300000],
                "uint64": [5000000000, 6000000000, 7000000000],
                "int16": [1000, -2000, 3000],
                "int32": [100000, -200000, 300000],
                "int64": [5000000000, -6000000000, 7000000000],
            }
        ).convert_dtypes(convert_floating=True)
        optimized_df = se_executor.optimize_memory_footprint(
            dummy_dataframe, level=level
        )
        assert [d.name for d in optimized_df.dtypes] == expected_dtypes

    @pytest.mark.parametrize(
        "operator,result",
        [
            (t1.mapa_a, "`mapa_a`"),
            (9.2, "@STORE[1]"),
            (True, "True"),
            (False, "False"),
            ("String", "'String'"),
            (20, "@STORE[1]"),
            (lambda: True, "True"),
            (object(), "@STORE[1]"),
        ],
    )
    def test_operands(
        self,
        operator,
        result,
    ):
        expr = se_expressions.WhereExpression(
            se_expressions.WhereExpressionType.OPERAND,
            se_expressions.WhereExpressionReturnType.VALUE,
            (operator,),
        )
        assert (
            se_executor._resolve_generic_where_operand(
                expr, se_executor._OperandStore()
            )
            == result
        )

    @pytest.mark.parametrize(
        "expression,result",
        [
            (se_expressions.EQ(1, 1), "(1 == 1)"),
            (se_expressions.NQ(1, 1), "(1 != 1)"),
            (se_expressions.GT(1, 1), "(1 > 1)"),
            (se_expressions.GTE(1, 1), "(1 >= 1)"),
            (se_expressions.LT(1, 1), "(1 < 1)"),
            (se_expressions.LTE(1, 1), "(1 <= 1)"),
            (se_expressions.NOT(se_expressions.EQ(1, 1)), "(not (1 == 1))"),
            (
                se_expressions.AND(se_expressions.EQ(1, 1), se_expressions.EQ(2, 2)),
                "((1 == 1) and (2 == 2))",
            ),
            (
                se_expressions.OR(se_expressions.EQ(1, 1), se_expressions.EQ(2, 2)),
                "((1 == 1) or (2 == 2))",
            ),
            (
                se_expressions.AND(
                    se_expressions.EQ(1, 1),
                    se_expressions.EQ(2, 2),
                    se_expressions.EQ(3, 3),
                ),
                "((1 == 1) and (2 == 2) and (3 == 3))",
            ),
            (
                se_expressions.OR(
                    se_expressions.EQ(1, 1),
                    se_expressions.EQ(2, 2),
                    se_expressions.EQ(3, 3),
                ),
                "((1 == 1) or (2 == 2) or (3 == 3))",
            ),
            (se_expressions.BETWEEN(3, 2, 4), "((3 >= 2) and (3 <= 4))"),
            (se_expressions.LIKE("HELLO", "%LLO"), "('HELLO'.str.fullmatch('.*LLO'))"),
            (
                se_expressions.NLIKE("HELLO", "%LA"),
                "(not 'HELLO'.str.fullmatch('.*LA'))",
            ),
            (
                se_expressions.NLIKE(t1.mapa_post, "$%"),
                r"(not `mapa_post`.str.fullmatch('\$.*'))",
            ),
        ],
    )
    def test_where_legacy_functions(
        self,
        expression,
        result,
    ):
        assert se_executor._resolve_generic_where_expression(expression) == result

    @pytest.mark.parametrize(
        "expression,result",
        [
            (t1.mapa_post == 3, "(`mapa_post` == 3)"),
            (t1.mapa_post != 3, "(`mapa_post` != 3)"),
            (t1.mapa_post > 3, "(`mapa_post` > 3)"),
            (t1.mapa_post >= 3, "(`mapa_post` >= 3)"),
            (t1.mapa_post < 3, "(`mapa_post` < 3)"),
            (t1.mapa_post <= 3, "(`mapa_post` <= 3)"),
            (t1.mapa_post == "$%", r"(`mapa_post`.str.fullmatch('\$.*'))"),
            (t1.mapa_post != "$%", r"(not `mapa_post`.str.fullmatch('\$.*'))"),
        ],
    )
    def test_where_expression_resolver(
        self,
        expression,
        result,
    ):
        assert se_executor._resolve_generic_where_expression(expression) == result
