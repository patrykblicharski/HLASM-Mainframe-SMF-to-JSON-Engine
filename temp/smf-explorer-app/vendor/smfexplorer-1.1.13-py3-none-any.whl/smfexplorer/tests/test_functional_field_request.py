# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

# pylint: disable=redefined-outer-name

import base64
import datetime
from urllib import parse as url_parse

import pandas as pd
import pytest
import requests
import requests_mock
from pandas.testing import assert_frame_equal

from smfexplorer import ASC, DESC, error
from smfexplorer.core import context as se_context
from smfexplorer.core import request as se_request
from smfexplorer.core.environment import dgapi as se_dgapi
from smfexplorer.fields import COMMON
from smfexplorer.tests.fields import T200S1 as t1
from smfexplorer.tests.parms_functional_test import (
    dg_names_cache,
    parms_test_filter_values,
    parms_test_single_field_request,
    parms_test_sort_values,
    parms_test_sort_where,
)

DG_URL = "https://dgapi.com"
username = "user1"
password = "pA$$W0rd"


@pytest.fixture
def dgapi_connector() -> se_dgapi.DGConnector:
    return se_dgapi.DGConnector(DG_URL, username, password, False)


@pytest.fixture
def empty_context() -> se_context.Context:

    mock_environment = se_dgapi.DGEnvironment(
        {"url": DG_URL, "username": username, "password": password}
    )

    mock_environment._dg_names_cache = dg_names_cache

    return se_context.Context(["DATASET.NAME"], mock_environment)


@pytest.fixture
def dgapi_parser() -> se_dgapi.DGParser:
    return se_dgapi.DGParser(
        environment=se_dgapi.DGEnvironment(
            {"url": DG_URL, "username": username, "password": password}
        )
    )


class TestFieldRequestFunctionality:
    @pytest.mark.parametrize(
        "field_to_request, request_str, response, expected_df, dtypes",
        parms_test_single_field_request,
    )
    def test_single_field_request(
        self,
        field_to_request,
        request_str,
        response,
        expected_df,
        dtypes,
        empty_context: se_context.Context,
    ):
        request = se_request.FieldRequest(field_to_request, context=empty_context)
        self.execute_test_requests(
            request, request_str, response, expected_df, dtypes, empty_context
        )

    @pytest.mark.parametrize(
        "field_to_request, sort_by, request_str, response, expected_df, dtypes, mode",
        parms_test_sort_values,
    )
    def test_sort_values(
        self,
        field_to_request,
        sort_by,
        request_str,
        response,
        expected_df,
        dtypes,
        mode,
        empty_context: se_context.Context,
    ):
        request = se_request.FieldRequest(field_to_request, context=empty_context)
        if mode == "ASC":
            request = request.sort(ASC(sort_by))
        if mode == "DESC":
            request = request.sort(DESC(sort_by))
        self.execute_test_requests(
            request, request_str, response, expected_df, dtypes, empty_context
        )

    @pytest.mark.parametrize(
        "field_to_request, where_expr, request_str, response, expected_df, dtypes",
        parms_test_filter_values,
    )
    def test_filter_values(
        self,
        field_to_request,
        where_expr,
        request_str,
        response,
        expected_df,
        dtypes,
        empty_context: se_context.Context,
    ):
        request = se_request.FieldRequest(
            field_to_request, context=empty_context
        ).where(where_expr)
        self.execute_test_requests(
            request, request_str, response, expected_df, dtypes, empty_context
        )

    @pytest.mark.parametrize(
        "field_to_request, sort_expr, where_expr, request_str, response, expected_df, dtypes",
        parms_test_sort_where,
    )
    def test_sort_filter_values(
        self,
        field_to_request,
        sort_expr,
        where_expr,
        request_str,
        response,
        expected_df,
        dtypes,
        empty_context: se_context.Context,
    ):
        request = (
            se_request.FieldRequest(field_to_request, context=empty_context)
            .sort(sort_expr)
            .where(where_expr)
        )
        self.execute_test_requests(
            request, request_str, response, expected_df, dtypes, empty_context
        )

    def execute_test_requests(
        self, request, request_str, response, expected_df, dtypes, empty_context
    ):

        query = empty_context.environment.parser.parse(request)[0]
        assert query.dataset_name == "DATASET.NAME"
        assert query.raw == request_str

        request_str = DG_URL + request_str
        with requests_mock.Mocker() as mock:
            mock.get(request_str, status_code=200, json=response)
            actual_df = request.run()

            for col, dtype in dtypes.items():
                expected_df[col] = expected_df[col].astype(dtype)
            print(actual_df)
            print(actual_df.dtypes)
            print(expected_df)
            print(expected_df.dtypes)
        assert actual_df.equals(expected_df)
