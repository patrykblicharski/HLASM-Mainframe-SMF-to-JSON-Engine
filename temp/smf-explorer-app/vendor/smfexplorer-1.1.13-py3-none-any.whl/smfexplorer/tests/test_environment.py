# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
import os
from typing import Dict
from unittest import mock

import pandas as pd
import pytest
from pandas.testing import assert_frame_equal

from smfexplorer import error
from smfexplorer.core import environment as se_environment
from smfexplorer.core import request as se_request
from smfexplorer.core.environment import dgapi as se_dgapi
from smfexplorer.core.environment import factory as se_factory
from smfexplorer.tests.helpers import MockEnvironment


@pytest.fixture
def environment() -> se_environment.Environment:

    connector = mock.Mock(spec=se_environment.Connector)

    expected = pd.DataFrame(
        {
            "type": [2, 70, 71, 90, 99, 99],
            "subtype": [0, 1, 3, 0, 1, 2],
            "count": [2, 100, 200, 300, 400, 500],
        }
    )

    connector.fetch_dataset_smftypes.return_value = expected

    env = MockEnvironment({})

    env._connector = connector
    env._parser = mock.Mock(sepc=se_environment.Parser)

    yield env


class TestEnvironment:
    def test_create_new_context(self, environment: se_environment.Environment):

        assert environment.mode() == "test"

        ctx = environment.new_context("DATASET1", "DATASET2")

        assert ctx.environment is environment
        assert ctx.dataset_names == ["DATASET1", "DATASET2"]

    def test_record_type_fetch_wrappers(self, environment: se_environment.Environment):

        expected = pd.DataFrame(
            {
                "type": [2, 70, 71, 90, 99, 99],
                "subtype": [0, 1, 3, 0, 1, 2],
                "count": [2, 100, 200, 300, 400, 500],
            }
        )
        assert_frame_equal(environment.get_available_records(""), expected)

        expected = pd.DataFrame(
            {
                "type": [2, 70, 71, 90, 99],
                "count": [2, 100, 200, 300, 900],
            }
        )
        assert_frame_equal(environment.get_available_types(""), expected)

        expected = pd.DataFrame(
            {
                "subtype": [1, 2],
                "count": [400, 500],
            }
        )
        assert_frame_equal(environment.get_available_subtypes("", 99), expected)

        assert len(environment.get_available_subtypes("", 77)) == 0

    def test_check_dataset_wrapper(self, environment: se_environment.Environment):

        environment.check_dataset("DATASET")

        environment.connector.check_dataset.assert_called_with("DATASET")

    def test_default_hooks_dont_change_request_and_dataframe(
        self, environment: se_environment.Environment
    ):

        request = se_request.FieldRequest([])
        ids = (request._id, request._subid)

        assert environment._pre_hook(request) is None
        assert ids == (request._id, request._subid)

        assert environment._pre_fetch_hook(request) is None
        assert ids == (request._id, request._subid)

        df = pd.DataFrame()

        assert environment._post_hook(df, request) is df


class TestEnvironmentFactory:
    @pytest.fixture(scope="function")
    def teardown_env_factory(self):
        os.environ.pop("SMF_EXPLORER_CONNECTION_STRING", "")
        os.environ.pop("SMFPY_CONNECTION_STRING", "")
        yield None
        se_factory.EnvironmentFactory._EnvironmentFactory__default_environment = None

    @pytest.mark.parametrize(
        "connection_str,expected_info",
        [
            (
                "mode=relay;host=https://relay.com;port=8080;token=smfexplorertoken",
                dict(
                    mode="relay",
                    host="https://relay.com",
                    port="8080",
                    token="smfexplorertoken",
                ),
            ),
            ("mode=relay", dict(mode="relay")),
            (
                'mode="relay";host="https://relay.com";port="8080";token="smfexplorertoken"',
                dict(
                    mode="relay",
                    host="https://relay.com",
                    port="8080",
                    token="smfexplorertoken",
                ),
            ),
            ('mode="relay"', dict(mode="relay")),
            (
                'mode="relay";host=https://relay.com;port="8080";token="smfexplorer;token"',
                dict(
                    mode="relay",
                    host="https://relay.com",
                    port="8080",
                    token="smfexplorer;token",
                ),
            ),
            ('mode="relay;"', dict(mode="relay;")),
            ('mode="";mode2=;', dict(mode="", mode2="")),
        ],
    )
    def test_connection_string_resolver(
        self,
        connection_str,
        expected_info,
    ):
        assert (
            se_factory.EnvironmentFactory.resolve_connection_string(connection_str)
            == expected_info
        )

    @pytest.mark.parametrize(
        "connection_str",
        [
            "",
            'mode"relay";',
            'mode"relay"',
        ],
    )
    def test_connection_string_with_empty_or_wring_information(self, connection_str):
        assert (
            se_factory.EnvironmentFactory.resolve_connection_string(connection_str)
            == {}
        )

    def test_create_environment(self):

        with pytest.raises(TypeError):
            se_factory.EnvironmentFactory.create_environment(None)

        with pytest.raises(
            error.EnvironmentError, match=r"Connection string is missing 'mode' option"
        ):
            se_factory.EnvironmentFactory.create_environment("host=https://relay.com")

        with pytest.raises(error.EnvironmentError, match=r"Unknown mode 'test'"):
            se_factory.EnvironmentFactory.create_environment(
                "mode=test;host=https://relay.com"
            )

        with mock.patch.object(
            se_dgapi.DGEnvironment, "check_environment_availability", return_value=False
        ):
            with pytest.raises(
                error.EnvironmentError,
                match=r"Availability check for mode 'dgapi' failed",
            ):
                se_factory.EnvironmentFactory.create_environment("mode=dgapi")

        with mock.patch.dict(
            se_factory.EnvironmentFactory.environment_classes, values={}, clear=True
        ):
            with pytest.raises(
                error.EnvironmentError, match=r"Missing implementation for mode 'dgapi'"
            ):
                se_factory.EnvironmentFactory.create_environment("mode=dgapi")

    def test_default_environment_getter_and_setter(self, teardown_env_factory):

        with mock.patch(
            "smfexplorer.core.environment.factory.EnvironmentFactory.init_default_environment"
        ) as init_func:
            se_factory.EnvironmentFactory.get_default_environment()
            init_func.assert_called()

            init_func.reset_mock()

            environment = mock.Mock(spec=se_environment.Environment)

            se_factory.EnvironmentFactory.set_default_environment(environment)

            assert (
                se_factory.EnvironmentFactory.get_default_environment() is environment
            )
            init_func.assert_not_called()

    def test_initialize_default_environment_with_environment_variable(
        self, teardown_env_factory
    ):

        with mock.patch.dict(
            os.environ, values={"SMF_EXPLORER_CONNECTION_STRING": "mode=relay"}
        ):

            mock_env = mock.Mock(spec=se_environment.Environment)

            with mock.patch(
                "smfexplorer.core.environment.factory.EnvironmentFactory.create_environment",
                return_value=mock_env,
            ) as create_func:
                se_factory.EnvironmentFactory.init_default_environment()

                create_func.assert_called_with("mode=relay")

    def test_initialize_default_environment_with_availablility_check(
        self, teardown_env_factory
    ):

        # -------------------- No default environment is expected -------------------- #

        se_factory.EnvironmentFactory.init_default_environment()

        assert (
            se_factory.EnvironmentFactory._EnvironmentFactory__default_environment
            is None
        )

        mock_connector = mock.Mock(spec=se_environment.Connector)
        mock_connector.check.return_value = False

        # -------------------------- Create test environment ------------------------- #

        with mock.patch.multiple(
            se_factory.EnvironmentFactory,
            environment_classes={"test": MockEnvironment},
            supported_environment_modes=set(["test"]),
        ):

            with mock.patch.multiple(
                MockEnvironment,
                check_environment_availability=mock.Mock(return_value=True),
                check=mock.Mock(return_value=True),
            ):
                se_factory.EnvironmentFactory.init_default_environment()

            assert (
                se_factory.EnvironmentFactory._EnvironmentFactory__default_environment.__class__
                is MockEnvironment
            )

            se_factory.EnvironmentFactory._EnvironmentFactory__default_environment = (
                None
            )

            # ------------------- Exception during environment creation ------------------ #

            with mock.patch.multiple(
                MockEnvironment,
                check_environment_availability=mock.Mock(return_value=True),
                check=mock.Mock(side_effect=error.EnvironmentError()),
            ):

                se_factory.EnvironmentFactory.init_default_environment()

            assert (
                se_factory.EnvironmentFactory._EnvironmentFactory__default_environment
                is None
            )
