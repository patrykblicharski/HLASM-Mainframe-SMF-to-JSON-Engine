# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from unittest import mock

import pytest

from smfexplorer.core import field as se_field
from smfexplorer.tests.fields import T200S1 as t1
from smfexplorer.tests.fields import T200S2 as t2

# TODO: Add additional tests for fields, records and maps


class TestField:
    def test_raw_field_access(self):

        raw_a = t1.mapa_post.raw

        assert raw_a.name == "mapa_post_raw"
        assert raw_a._post is None
        assert raw_a is t1.mapa_post.raw

        raw_v = t1.mapa_virtual.raw

        assert raw_v is t1.mapa_a

        assert t1.mapb_virtual_b is t1.mapb_virtual_b.raw

    def test_field_equality_same_name(self):
        assert t1.mapa_a != t2.mapa_a
        assert t1.mapa_a == t1.mapa_a
