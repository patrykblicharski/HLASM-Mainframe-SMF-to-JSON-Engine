# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from unittest.mock import MagicMock, patch

import pytest

from smfexplorer.core.environment.dgapi import (
    convert_str_to_byte,
    getAvailableMemoryInByte,
)


def test_convert_str_to_byte():
    assert convert_str_to_byte("10K") == 10 * 1024
    assert convert_str_to_byte("10M") == 10 * 1024**2
    assert convert_str_to_byte("10G") == 10 * 1024**3
    assert convert_str_to_byte("10T") == 10 * 1024**4
    assert convert_str_to_byte("10P") == 10 * 1024**5
    assert convert_str_to_byte("1234") == 1234

    with pytest.raises(ValueError):
        convert_str_to_byte("1024X")
    with pytest.raises(ValueError):
        convert_str_to_byte("10X4T")


@patch("os.getpid", return_value=654321)
@patch("smfexplorer.core.environment.dgapi.subprocess.run")
def test_getAvailableMemoryInByte(mock_run, mock_pid):
    output_str = r""" PID TTY       TIME COMMAND        VSZ64   VSZLMT64
123456 ?         4:37 ABCXYZ       2822M      4096M
654321 ?         4:37 /usr/lpp/      2822M      4096M
111222 ?         0:00 -                  0          0"""
    mock_stdout = MagicMock()
    mock_stdout.configure_mock(**{"stdout.decode.return_value": output_str})

    mock_run.return_value = mock_stdout
    result = getAvailableMemoryInByte()
    mock_pid.assert_called_once()
    mock_run.assert_called_once()
    assert result == 1335885824
