# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
import copy

import pytest

from smfexplorer import error
from smfexplorer.core import field as field
from smfexplorer.core import request_graph as se_rg
from smfexplorer.fields import COMMON
from smfexplorer.tests.fields import T200S1 as t1
from smfexplorer.tests.fields import T200S2 as t2


class TestRequestGraph:
    class TestNode:
        def test_equality(self):
            node_a = se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapa_a)
            node_b = se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapa_a)
            node_c = se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapa_post)
            assert node_a == node_b
            assert node_a != node_c
            node_b.parent = node_c
            assert node_a == node_b
            node_b.children[node_c] = node_c
            assert node_a == node_b
            node_d = se_rg.RGNode(se_rg.RGNodeType.MAP, field=t1.mapa_a)
            assert node_d != node_a

        def test_deep_equality(self):
            node_a = se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapa_a)
            node_b = se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapa_a)
            node_c = se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapa_post)
            node_d = se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapb_virtual)
            assert node_a.deep_eq(node_b)
            node_a.children[node_c] = node_c
            assert not node_a.deep_eq(node_b)
            assert not node_b.deep_eq(node_a)
            node_b.children[node_c] = node_c
            assert node_a.deep_eq(node_b)
            assert node_b.deep_eq(node_a)
            node_b.children[node_d] = node_d
            assert not node_a.deep_eq(node_b)
            assert not node_b.deep_eq(node_a)

        def test_record_resolution(self):
            result_node = se_rg.resolve_record_node(t1.f_a.record)
            expected_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
            assert result_node.deep_eq(expected_node)

        def test_record_map_resolution(self):
            result_node = se_rg.resolve_record_map_node(t1.mapa_a.record_map)
            expected_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
            child_node = se_rg.RGNode(
                se_rg.RGNodeType.MAP,
                record_map=t1.mapa_a.record_map,
                parent=expected_node,
            )
            expected_node.children[child_node] = child_node
            assert result_node.parent.deep_eq(expected_node)

        def test_record_map_resolution_for_nested_map(self):
            result_node = se_rg.resolve_record_map_node(t1.mapc_a.record_map)
            expected_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
            child_node = se_rg.RGNode(
                se_rg.RGNodeType.MAP,
                record_map=t1.mapb_a.record_map,
                parent=expected_node,
            )
            expected_node.children[child_node] = child_node
            child_node2 = se_rg.RGNode(
                se_rg.RGNodeType.MAP, record_map=t1.mapc_a.record_map, parent=child_node
            )
            child_node.children[child_node2] = child_node2
            assert result_node.parent.parent.deep_eq(expected_node)

        def test_field_resolution(self):
            result_node = se_rg.resolve_field_node(t1.mapa_a)
            expected_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
            child_node = se_rg.RGNode(
                se_rg.RGNodeType.MAP,
                record_map=t1.mapa_a.record_map,
                parent=expected_node,
            )
            expected_node.children[child_node] = child_node
            child_node2 = se_rg.RGNode(
                se_rg.RGNodeType.FIELD, field=t1.mapa_a, parent=child_node
            )
            child_node.children[child_node2] = child_node2
            assert result_node.parent.parent.deep_eq(expected_node)

        def test_virtual_field_resolution(self):
            result_node = se_rg.resolve_field_node(t1.mapa_virtual)
            expected_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
            child_node = se_rg.RGNode(
                se_rg.RGNodeType.MAP,
                record_map=t1.mapa_a.record_map,
                parent=expected_node,
            )
            expected_node.children[child_node] = child_node
            child_node2 = se_rg.RGNode(
                se_rg.RGNodeType.FIELD, field=t1.mapa_a, parent=child_node
            )
            child_node.children[child_node2] = child_node2
            child_node3 = se_rg.RGNode(
                se_rg.RGNodeType.FIELD, field=t1.mapa_virtual, parent=child_node2
            )
            child_node2.children[child_node3] = child_node3
            assert result_node.parent.parent.parent.deep_eq(expected_node)

        def test_common_field_resolution(self):
            result_node = se_rg.resolve_field_node(COMMON.flg)
            expected_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=None)
            child_node = se_rg.RGNode(
                se_rg.RGNodeType.FIELD, field=COMMON.flg, parent=expected_node
            )
            expected_node.children[child_node] = child_node
            assert result_node.parent.deep_eq(expected_node)

    def test_insert_record(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_record_node(t1.f_a.record)
        )
        root_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
        expected_tree = se_rg.RequestGraph(root_node=root_node)
        assert expected_tree == result_tree

    def test_insert_record_map(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_record_map_node(t1.mapa_a.record_map)
        )
        root_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
        child_node = se_rg.RGNode(
            se_rg.RGNodeType.MAP, record_map=t1.mapa_a.record_map, parent=root_node
        )
        root_node.children[child_node] = child_node
        expected_tree = se_rg.RequestGraph(root_node=root_node)
        expected_tree.nodes[child_node] = child_node
        assert expected_tree == result_tree

    def test_insert_fields_of_same_map(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapa_post_param)
        )
        root_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
        child_node = se_rg.RGNode(
            se_rg.RGNodeType.MAP, record_map=t1.mapa_a.record_map, parent=root_node
        )
        root_node.children[child_node] = child_node
        child_node2 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapa_post_param, parent=child_node
        )
        child_node.children[child_node2] = child_node2
        expected_tree = se_rg.RequestGraph(root_node=root_node)
        expected_tree.nodes[child_node] = child_node
        expected_tree.nodes[child_node2] = child_node2
        assert expected_tree == result_tree
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapa_virtual)
        )
        child_node3 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapa_a, parent=child_node
        )
        child_node.children[child_node3] = child_node3
        child_node4 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapa_virtual, parent=child_node3
        )
        child_node3.children[child_node4] = child_node4
        expected_tree.nodes[child_node3] = child_node3
        expected_tree.nodes[child_node4] = child_node4
        assert expected_tree == result_tree

    def test_field_of_different_maps(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(result_tree, se_rg.resolve_field_node(t1.mapa_post))
        root_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
        child_node = se_rg.RGNode(
            se_rg.RGNodeType.MAP, record_map=t1.mapa_a.record_map, parent=root_node
        )
        root_node.children[child_node] = child_node
        child_node2 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapa_post, parent=child_node
        )
        child_node.children[child_node2] = child_node2
        expected_tree = se_rg.RequestGraph(root_node=root_node)
        expected_tree.nodes[child_node] = child_node
        expected_tree.nodes[child_node2] = child_node2
        assert expected_tree == result_tree
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapb_virtual)
        )
        child_node3 = se_rg.RGNode(
            se_rg.RGNodeType.MAP, record_map=t1.mapb_a.record_map, parent=root_node
        )
        root_node.children[child_node3] = child_node3
        child_node4 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapb_a, parent=child_node3
        )
        child_node3.children[child_node4] = child_node4
        child_node5 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapb_virtual, parent=child_node4
        )
        child_node4.children[child_node5] = child_node5
        expected_tree.nodes[child_node3] = child_node3
        expected_tree.nodes[child_node4] = child_node4
        expected_tree.nodes[child_node5] = child_node5
        assert expected_tree == result_tree

    def test_insert_common_field(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapa_post_param)
        )
        se_rg.insert_node_into_tree(result_tree, se_rg.resolve_field_node(COMMON.flg))
        root_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
        child_node = se_rg.RGNode(
            se_rg.RGNodeType.MAP, record_map=t1.mapa_a.record_map, parent=root_node
        )
        root_node.children[child_node] = child_node
        child_node2 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapa_post_param, parent=child_node
        )
        child_node.children[child_node2] = child_node2
        child_node3 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=COMMON.flg, parent=root_node
        )
        root_node.children[child_node3] = child_node3
        expected_tree = se_rg.RequestGraph(root_node=root_node)
        expected_tree.nodes[child_node] = child_node
        expected_tree.nodes[child_node2] = child_node2
        expected_tree.nodes[child_node3] = child_node3
        assert expected_tree == result_tree
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapa_virtual)
        )
        child_node3 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapa_a, parent=child_node
        )
        child_node.children[child_node3] = child_node3
        child_node4 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapa_virtual, parent=child_node3
        )
        child_node3.children[child_node4] = child_node4
        expected_tree.nodes[child_node3] = child_node3
        expected_tree.nodes[child_node4] = child_node4
        assert expected_tree == result_tree

    def test_insert_common_field_first(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(result_tree, se_rg.resolve_field_node(COMMON.flg))
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapa_post_param)
        )
        root_node = se_rg.RGNode(se_rg.RGNodeType.RECORD, record=t1.f_a.record)
        child_node = se_rg.RGNode(
            se_rg.RGNodeType.MAP, record_map=t1.mapa_a.record_map, parent=root_node
        )
        root_node.children[child_node] = child_node
        child_node2 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=t1.mapa_post_param, parent=child_node
        )
        child_node.children[child_node2] = child_node2
        child_node3 = se_rg.RGNode(
            se_rg.RGNodeType.FIELD, field=COMMON.flg, parent=root_node
        )
        root_node.children[child_node3] = child_node3
        expected_tree = se_rg.RequestGraph(root_node=root_node)
        expected_tree.nodes[child_node] = child_node
        expected_tree.nodes[child_node2] = child_node2
        expected_tree.nodes[child_node3] = child_node3
        assert expected_tree == result_tree

    def test_error_on_insertion_of_fields_from_differen_records(self):
        result_tree = se_rg.RequestGraph()
        with pytest.raises(error.RGError):
            se_rg.insert_node_into_tree(
                result_tree, se_rg.resolve_field_node(t1.mapa_a)
            )
            se_rg.insert_node_into_tree(result_tree, se_rg.resolve_field_node(t2.f_a))

    def test_deep_copy(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(result_tree, se_rg.resolve_field_node(t1.mapa_a))
        other_tree = copy.deepcopy(result_tree)
        assert result_tree == other_tree
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapa_post_param)
        )
        assert result_tree != other_tree

    def test_find_children_of_type(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapb_post_param)
        )
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapb_virtual)
        )
        se_rg.insert_node_into_tree(result_tree, se_rg.resolve_field_node(t1.mapb_a))
        search_result = result_tree.get_all_nodes_of_type(se_rg.RGNodeType.FIELD)
        expected_result = [
            se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapb_post_param),
            se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapb_a),
            se_rg.RGNode(se_rg.RGNodeType.FIELD, field=t1.mapb_virtual),
        ]
        assert set(search_result) == set(expected_result)

    def test_find_all_fields(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapb_post_param)
        )
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapb_virtual)
        )
        se_rg.insert_node_into_tree(result_tree, se_rg.resolve_field_node(t1.mapb_a))
        search_result = result_tree.get_all_fields()
        expected_result = [t1.mapb_post_param, t1.mapb_a, t1.mapb_virtual]
        assert set(search_result) == set(expected_result)

    def test_resolution_of_virtual_fields_with_multiple_parents(self):
        result_tree = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(
            result_tree, se_rg.resolve_field_node(t1.mapb_virtual_a)
        )
        traversed_result = [
            node.field
            for node in se_rg.traverse(
                result_tree.root_node, types=[se_rg.RGNodeType.FIELD]
            )
        ]
        expected_result = [t1.mapb_a, t1.mapb_virtual, t1.mapb_virtual_a]
        assert expected_result == traversed_result

    def test_traverse_graph_ordering(self):

        graph = se_rg.RequestGraph()
        se_rg.insert_node_into_tree(graph, se_rg.resolve_field_node(t1.f_virtual))

        result = {}

        for index, node in enumerate(
            se_rg.traverse(graph.root_node, types=[se_rg.RGNodeType.FIELD])
        ):
            result[node.field] = index

        assert result[t1.f_virtual] > result[t1.f_a]
