# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from unittest.mock import Mock

import pandas as pd
import pytest
from pandas.testing import assert_frame_equal

from smfexplorer import error
from smfexplorer.core.context import Context
from smfexplorer.core.environment import Environment
from smfexplorer.tests.helpers import MockEnvironment


class TestContext:
    def test_access_connector_and_parser(self):
        connector = Mock()
        parser = Mock()

        environment = MockEnvironment({})

        environment._connector = connector
        environment._parser = parser

        ctx = Context([], environment)

        with pytest.warns(FutureWarning):
            assert ctx.parser is parser
            assert ctx.connector is connector

    def test_get_available_records(self):

        df = pd.DataFrame(
            {
                "type": [2, 99, 99, 99],
                "subtype": [0, 1, 2, 3],
                "count": [2, 100, 200, 300],
            }
        )

        environment = Mock(Environment)
        environment.get_available_records.return_value = df

        ctx = Context(["FIRST_DATASET"], environment)

        result = ctx.get_available_records()
        assert_frame_equal(result, df)
        assert result is ctx.get_available_records()

        ctx.dataset_names = ["FIRST_DATASET"]
        assert not result is ctx.get_available_records()

        expected = pd.DataFrame({"type": [2, 99], "count": [2, 600]})

        assert_frame_equal(ctx.get_available_types(), expected)

        expected = pd.DataFrame({"subtype": [1, 2, 3], "count": [100, 200, 300]})

        assert_frame_equal(ctx.get_available_subtypes(99), expected)

        ctx = Context(["FIRST_DATASET", "SECOND_DATASET"], environment)

        expected = pd.DataFrame(
            {
                "type": [2, 99, 99, 99],
                "subtype": [0, 1, 2, 3],
                "count": [4, 200, 400, 600],
            }
        )

        assert_frame_equal(ctx.get_available_records(), expected)

        expected = pd.DataFrame({"type": [2, 99], "count": [4, 1200]})

        assert_frame_equal(ctx.get_available_types(), expected)

        expected = pd.DataFrame({"subtype": [1, 2, 3], "count": [200, 400, 600]})

        assert_frame_equal(ctx.get_available_subtypes(99), expected)

        ctx = Context([], environment)

        with pytest.raises(error.SmfExplorerError, match="no dataset names defined"):
            ctx.get_available_records()
