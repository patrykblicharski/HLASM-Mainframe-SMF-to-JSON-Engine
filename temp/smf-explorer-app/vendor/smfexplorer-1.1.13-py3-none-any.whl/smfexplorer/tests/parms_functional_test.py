# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from urllib import parse as url_parse

import pandas as pd

from smfexplorer import ASC, DESC
from smfexplorer.core.environment import dgapi as se_dgapi
from smfexplorer.core.expressions import WhereExpression
from smfexplorer.tests.fields import T200S1 as t1
from smfexplorer.tests.fields import T200S2 as t2

dg_names_cache = {
    (200, 1): se_dgapi.DGNamesCache(
        {
            "SMF200_SUBTYPE1_MAP_A": "smf200Subtype1MapA",
            "SMF200_SUBTYPE1_MAP_B": "smf200Subtype1MapB",
            "SMF200_SUBTYPE1_MAP_C": "smf200Subtype1MapC",
        },
        {
            "T200S1_MAP_A": "SMF200_SUBTYPE1_MAP_A",
            "T200S1_MAP_B": "SMF200_SUBTYPE1_MAP_B",
            "T200S1_MAP_C": "SMF200_SUBTYPE1_MAP_C",
        },
        {},
    ),
    (200, 2): se_dgapi.DGNamesCache(
        {
            "SMF200_SUBTYPE2_MAP_A": "smf200Subtype2MapA",
            "SMF200_SUBTYPE2_MAP_B": "smf200Subtype2MapB",
            "SMF200_SUBTYPE2_MAP_C": "smf200Subtype2MapC",
        },
        {
            "T200S2_MAP_A": "SMF200_SUBTYPE2_MAP_A",
            "T200S2_MAP_B": "SMF200_SUBTYPE2_MAP_B",
            "T200S2_MAP_C": "SMF200_SUBTYPE2_MAP_C",
        },
        {},
    ),
}

request_str1 = "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
    {
        "datasetName": "DATASET.NAME",
        "SMF200_SUBTYPE1": "SMF200DTE,SMF200TME",
        "SMF200_SUBTYPE1_MAP_A": "T200S1_POST,T200S1_A",
    }
)
response1 = {
    "0": {
        "SMF200DTE": "2021-01-01",
        "SMF200TME": "00:01:02.030000",
        "smf200Subtype1MapA": {"T200S1_A": "A", "T200S1_POST": 2},
    },
    "1": {
        "SMF200DTE": "2021-01-03",
        "SMF200TME": "00:01:02.030000",
        "smf200Subtype1MapA": {"T200S1_A": "B", "T200S1_POST": 0},
    },
    "2": {
        "SMF200DTE": "2021-01-02",
        "SMF200TME": "00:01:02.030000",
        "smf200Subtype1MapA": {"T200S1_A": "C", "T200S1_POST": 1},
    },
}

expected_df1 = pd.DataFrame(
    {
        "timestamp": [
            pd.Timestamp("2021-01-01 00:01:02.030"),
            pd.Timestamp("2021-01-03 00:01:02.030"),
            pd.Timestamp("2021-01-02 00:01:02.030"),
        ],
        "mapa_a": ["A", "B", "C"],
        "mapa_post": [2, 0, 1],
    }
)

sorted_field1 = t1.mapa_post
mode1 = "ASC"
expected_df1_sorted_mapa_post = pd.DataFrame(
    {
        "timestamp": [
            pd.Timestamp("2021-01-03 00:01:02.030"),
            pd.Timestamp("2021-01-02 00:01:02.030"),
            pd.Timestamp("2021-01-01 00:01:02.030"),
        ],
        "mapa_a": ["B", "C", "A"],
        "mapa_post": [0, 1, 2],
    }
)

sorted_field2 = t1.timestamp
mode2 = "DESC"
expected_df1_sorted_timestamp = pd.DataFrame(
    {
        "timestamp": [
            pd.Timestamp("2021-01-03 00:01:02.030"),
            pd.Timestamp("2021-01-02 00:01:02.030"),
            pd.Timestamp("2021-01-01 00:01:02.030"),
        ],
        "mapa_a": ["B", "C", "A"],
        "mapa_post": [0, 1, 2],
    }
)

dtypes1 = {"timestamp": "datetime64[ns]", "mapa_a": "object", "mapa_post": "UInt8"}

field_to_request1 = [t1.timestamp, t1.mapa_a, t1.mapa_post]


request_str2 = "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
    {
        "datasetName": "DATASET.NAME",
        "SMF200_SUBTYPE1_MAP_A": "T200S1_TIMEDELTA,T200S1_STR,T200S1_ARRAY,T200S1_FLOAT",
    }
)
response2 = {
    "0": {
        "smf200Subtype1MapA": {
            "T200S1_TIMEDELTA": "0 days 00:10:00",
            "T200S1_STR": "S0",
            "T200S1_ARRAY": {"0": 0, "1": 0, "2": 0, "3": 0},
            "T200S1_FLOAT": 0.1,
        },
    },
    "1": {
        "smf200Subtype1MapA": {
            "T200S1_TIMEDELTA": "1 days 00:20:00",
            "T200S1_STR": "S1",
            "T200S1_ARRAY": {"0": 1, "1": 1, "2": 1, "3": 1},
            "T200S1_FLOAT": 1.2,
        },
    },
    "2": {
        "smf200Subtype1MapA": {
            "T200S1_TIMEDELTA": "2 days 00:30:00",
            "T200S1_STR": "S2",
            "T200S1_ARRAY": {"0": 2, "1": 2, "2": 2, "3": 2},
            "T200S1_FLOAT": 2.3,
        },
    },
}

expected_df2 = pd.DataFrame(
    {
        "mapa_float": [0.1, 1.2, 2.3],
        "mapa_array_1": [0, 1, 2],
        "mapa_str": ["S0", "S1", "S2"],
        "mapa_timedelta": ["0 days 00:10:00", "1 days 00:20:00", "2 days 00:30:00"],
    }
)

dtypes2 = {
    "mapa_float": "float32",
    "mapa_array_1": "UInt8",
    "mapa_str": "string",
    "mapa_timedelta": "timedelta64[ns]",
}

field_to_request2 = [t1.mapa_float, t1.mapa_array_1, t1.mapa_str, t1.mapa_timedelta]

request_str3 = "/v1/smf/type/200/subtype/1?" + url_parse.urlencode(
    {
        "datasetName": "DATASET.NAME",
        "SMF200_SUBTYPE1_MAP_B": "T200S1_A",
        "SMF200_SUBTYPE1_MAP_A": "T200S1_FLGS",
    }
)

response3 = {
    "0": {
        "smf200Subtype1MapA": {
            "T200S1_FLGS": "010",
        },
        "smf200Subtype1MapB": {
            "T200S1_A": "010",
        },
    },
    "1": {
        "smf200Subtype1MapA": {
            "T200S1_FLGS": "100",
        },
        "smf200Subtype1MapB": {
            "T200S1_A": "100",
        },
    },
    "2": {
        "smf200Subtype1MapA": {
            "T200S1_FLGS": "011",
        },
        "smf200Subtype1MapB": {
            "T200S1_A": "011",
        },
    },
}
expected_df3 = pd.DataFrame(
    {"mapa_flag1": [True, False, True], "mapb_a": ["010", "100", "011"]}
)
dtypes3 = {}

field_to_request3 = [t1.mapa_flag1, t1.mapb_a]

response4 = {
    "0": {
        "smf200Subtype2MapA": {
            "smf200Subtype2MapB": {
                "0": {
                    "T200S2_A": "A",
                },
                "1": {
                    "T200S2_A": "B",
                },
            }
        },
        "smf200Subtype2MapC": {
            "0": {
                "T200S2_C": 0,
            },
            "1": {
                "T200S2_C": 1,
            },
            "2": {
                "T200S2_C": 2,
            },
        },
    },
}
expected_df4 = pd.DataFrame(
    {"mapb_a": ["A", "B", "A", "B", "A", "B"], "mapc_a": [0, 0, 1, 1, 2, 2]}
)
request_str4 = "/v1/smf/type/200/subtype/2?" + url_parse.urlencode(
    {
        "datasetName": "DATASET.NAME",
        "SMF200_SUBTYPE2_MAP_C": "T200S2_C",
        "SMF200_SUBTYPE2_MAP_B": "T200S2_A",
    }
)
dtypes4 = {"mapc_a": "UInt8"}
field_to_request4 = [t2.mapb_a, t2.mapc_a]


parms1 = (field_to_request1, request_str1, response1, expected_df1, dtypes1)
parms2 = (field_to_request2, request_str2, response2, expected_df2, dtypes2)
parms3 = (field_to_request3, request_str3, response3, expected_df3, dtypes3)
parms4 = (field_to_request4, request_str4, response4, expected_df4, dtypes4)

parms_test_single_field_request = [parms1, parms2, parms3, parms4]

parms1_sort = (
    field_to_request1,
    sorted_field1,
    request_str1,
    response1,
    expected_df1_sorted_mapa_post,
    dtypes1,
    mode1,
)
parms2_sort = (
    field_to_request1,
    sorted_field2,
    request_str1,
    response1,
    expected_df1_sorted_timestamp,
    dtypes1,
    mode2,
)

parms_test_sort_values = [parms1_sort, parms2_sort]

where_expr1 = t1.mapa_str == "S0"
expected_df2_filter_equal = pd.DataFrame(
    {
        "mapa_float": [0.1, 1.2, 2.3],
        "mapa_array_1": [0, 1, 2],
        "mapa_str": ["S0", "S1", "S2"],
        "mapa_timedelta": ["0 days 00:10:00", "1 days 00:20:00", "2 days 00:30:00"],
    }
)
parms1_filter = (
    field_to_request2,
    where_expr1,
    request_str2,
    response2,
    expected_df2_filter_equal,
    dtypes2,
)

where_expr1 = t1.mapa_str == "S0"
expected_df2_filter_equal = pd.DataFrame(
    {
        "mapa_float": [0.1],
        "mapa_array_1": [0],
        "mapa_str": ["S0"],
        "mapa_timedelta": ["0 days 00:10:00"],
    }
)


parms1_filter = (
    field_to_request2,
    where_expr1,
    request_str2,
    response2,
    expected_df2_filter_equal,
    dtypes2,
)

where_expr2 = t1.mapa_str != "S0"
expected_df2_filter_notequal = pd.DataFrame(
    {
        "mapa_float": [1.2, 2.3],
        "mapa_array_1": [1, 2],
        "mapa_str": ["S1", "S2"],
        "mapa_timedelta": ["1 days 00:20:00", "2 days 00:30:00"],
    }
)
parms2_filter = (
    field_to_request2,
    where_expr2,
    request_str2,
    response2,
    expected_df2_filter_notequal,
    dtypes2,
)

where_expr3 = t1.mapa_array_1 > 1
expected_df2_filter_greater = pd.DataFrame(
    {
        "mapa_float": [2.3],
        "mapa_array_1": [2],
        "mapa_str": ["S2"],
        "mapa_timedelta": ["2 days 00:30:00"],
    }
)
parms3_filter = (
    field_to_request2,
    where_expr3,
    request_str2,
    response2,
    expected_df2_filter_greater,
    dtypes2,
)

where_expr4 = t1.mapa_array_1 < 2
expected_df2_filter_smaller = pd.DataFrame(
    {
        "mapa_float": [0.1, 1.2],
        "mapa_array_1": [0, 1],
        "mapa_str": ["S0", "S1"],
        "mapa_timedelta": ["0 days 00:10:00", "1 days 00:20:00"],
    }
)
parms4_filter = (
    field_to_request2,
    where_expr4,
    request_str2,
    response2,
    expected_df2_filter_smaller,
    dtypes2,
)


where_expr5 = t1.mapa_array_1 <= 2
parms5_filter = (
    field_to_request2,
    where_expr5,
    request_str2,
    response2,
    expected_df2,
    dtypes2,
)

where_expr6 = t1.mapa_array_1 >= 0
parms6_filter = (
    field_to_request2,
    where_expr6,
    request_str2,
    response2,
    expected_df2,
    dtypes2,
)

where_expr7 = (t1.mapa_array_1 > 0) & (t1.mapa_array_1 < 2)
expected_df2_filter_and = pd.DataFrame(
    {
        "mapa_float": [1.2],
        "mapa_array_1": [1],
        "mapa_str": ["S1"],
        "mapa_timedelta": ["1 days 00:20:00"],
    }
)
parms7_filter = (
    field_to_request2,
    where_expr7,
    request_str2,
    response2,
    expected_df2_filter_and,
    dtypes2,
)


parms_test_filter_values = [
    parms1_filter,
    parms2_filter,
    parms3_filter,
    parms4_filter,
    parms5_filter,
    parms6_filter,
    parms7_filter,
]

expected_sort_where_df = pd.DataFrame(
    {
        "timestamp": [
            pd.Timestamp("2021-01-03 00:01:02.030"),
            pd.Timestamp("2021-01-02 00:01:02.030"),
        ],
        "mapa_a": ["B", "C"],
        "mapa_post": [0, 1],
    }
)
sort_expr = ASC(t1.mapa_post)
where_expr = t1.mapa_a != "A"
parms_sort_where = (
    field_to_request1,
    sort_expr,
    where_expr,
    request_str1,
    response1,
    expected_sort_where_df,
    dtypes1,
)


parms_test_sort_where = [parms_sort_where]
