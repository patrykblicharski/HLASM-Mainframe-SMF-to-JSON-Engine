# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
import pandas as pd
import pytest
from pandas.testing import assert_series_equal

from smfexplorer.core import field as se_field
from smfexplorer.fields import COMMON
from smfexplorer.plugin.base import post_processors as base_pp
from smfexplorer.tests.fields import T200S1 as t1
from smfexplorer.tests.fields import T200S2 as t2


#     return test_df
@pytest.fixture
def dataframe():
    """Supplies dataframe for each test"""
    test_df = pd.DataFrame(
        {
            COMMON.timestamp.name: [pd.Timestamp(100)] * 6,
            t1.f_a.name: [0, 1, 2, 3, 4, 5],
            t1.f_post.name: [0, 1, 2, 3, 4, 5],
            t1.f_post_param.name: [
                "10000000",
                "01000000",
                "00100000",
                "00010000",
                "00001000",
                "00000000",
            ],
            t1.mapa_str.name: ["A", "ABC", "FF", "15", "0", "8a"],
        }
    )

    yield test_df


class TestPostProcessors:
    def test_timestamp_creation(self):
        from datetime import date, time

        df = pd.DataFrame(
            {
                COMMON.time.name: [
                    time.fromisoformat("10:00:00.000"),
                    time.fromisoformat("15:30:30.000"),
                    time.fromisoformat("20:15:45.500"),
                ],
                COMMON.date.name: [
                    date.fromisoformat("2001-01-01"),
                    date.fromisoformat("2010-05-05"),
                    date.fromisoformat("2021-12-31"),
                ],
            }
        )

        post_proc = base_pp.timestamp_post_processor(COMMON.timestamp)

        result = post_proc.apply(df)

        expected = pd.Series(
            pd.to_datetime(
                [
                    "2001-01-01 10:00:00.0",
                    "2010-05-05 15:30:30.0",
                    "2021-12-31 20:15:45.5",
                ]
            ),
            name=COMMON.timestamp.name,
        )

        assert_series_equal(expected, result[COMMON.timestamp.name])

    @pytest.fixture
    def timestamp_correction_df(self):
        yield pd.DataFrame(
            {
                COMMON.timestamp.name: pd.to_datetime(
                    [
                        "2020-01-01 00:00:00.000",
                        "2020-01-01 00:00:00.100",
                        "2020-01-01 00:00:00.150",
                        "2020-01-01 00:00:00.500",
                        "2020-01-01 00:00:02.200",
                        "2020-01-01 00:00:02.100",
                        "2020-01-01 00:00:02.050",
                        "2020-01-01 00:00:02.500",
                        "2020-01-01 00:00:04.200",
                        "2020-01-01 00:00:04.500",
                        "2020-01-01 00:00:04.000",
                        "2020-01-01 00:00:04.100",
                        "2020-01-01 00:00:06.000",
                        "2020-01-01 00:00:06.100",
                        "2020-01-01 00:00:06.200",
                    ]
                )
            }
        )

    @pytest.fixture
    def timestamp_correction_expected(self):
        yield pd.DataFrame(
            {
                COMMON.timestamp.name: pd.to_datetime(
                    [
                        "2020-01-01 00:00:00.000",
                        "2020-01-01 00:00:00.000",
                        "2020-01-01 00:00:00.000",
                        "2020-01-01 00:00:00.500",
                        "2020-01-01 00:00:02.200",
                        "2020-01-01 00:00:02.200",
                        "2020-01-01 00:00:02.200",
                        "2020-01-01 00:00:02.500",
                        "2020-01-01 00:00:04.200",
                        "2020-01-01 00:00:04.500",
                        "2020-01-01 00:00:04.000",
                        "2020-01-01 00:00:04.000",
                        "2020-01-01 00:00:06.000",
                        "2020-01-01 00:00:06.000",
                        "2020-01-01 00:00:06.200",
                    ]
                )
            }
        )

    # # @test("[Post-Processors] Timestamp correction for timestamps closer then 200 ms"
    # #      )
    # # def _(dataframe=timestamp_correction_df, expected_output=timestamp_correction_expected):
    # #     post_proc = correct_timestamps()
    # #     result = post_proc.apply(dataframe)

    # #     assert_series_equal(result[COMMON.timestamp.name],
    # #                         expected_output[COMMON.timestamp.name])

    def test_math_postprocessor(self, dataframe):
        FieldSum = se_field.Field(
            name="test",
            origin="test",
            post="core.math",
            post_param="test = f_a + f_post",
            virtual=True,
            ref=[t1.f_a, t1.f_post],
        )

        post_proc = base_pp.math_post_processor(FieldSum)
        proc_df = post_proc.apply(dataframe)
        expected_output = pd.Series([0, 2, 4, 6, 8, 10], name=FieldSum.name)

        assert_series_equal(proc_df[FieldSum.name], expected_output)

    def test_sum_postprocessor(self, dataframe):

        FieldSum = se_field.Field(
            name="test",
            origin="test",
            post="core.math.sum",
            virtual=True,
            ref=[t1.f_a, t1.f_post],
        )

        post_proc = base_pp.sum_post_processor(FieldSum)
        proc_df = post_proc.apply(dataframe)
        expected_output = pd.Series([0, 2, 4, 6, 8, 10], name=FieldSum.name)

        assert_series_equal(proc_df[FieldSum.name], expected_output)

    def test_map_postprocessor(self, dataframe):

        FieldMap = se_field.Field(
            name="test",
            origin="test",
            post="core.map",
            post_param={
                "map": {
                    0: "A",
                    2: "B",
                    4: "C",
                },
                "default": "Nothing",
            },
            virtual=True,
            ref=t1.f_a,
        )

        post_proc = base_pp.map_post_processor(FieldMap)
        proc_df = post_proc.apply(dataframe)
        excepted_output = pd.Series(
            ["A", "Nothing", "B", "Nothing", "C", "Nothing"], name=FieldMap.name
        )

        assert_series_equal(proc_df[FieldMap.name], excepted_output)

    def test_map_postprocessor_without_default(self, dataframe):

        FieldMap = se_field.Field(
            name="test",
            origin="test",
            post="core.map",
            post_param={
                "map": {
                    0: "A",
                    2: "B",
                    4: "C",
                }
            },
            virtual=True,
            ref=t1.f_a,
        )

        post_proc = base_pp.map_post_processor(FieldMap)
        proc_df = post_proc.apply(dataframe)
        excepted_output = pd.Series(["A", 1, "B", 3, "C", 5], name=FieldMap.name)

        assert_series_equal(proc_df[FieldMap.name], excepted_output)

    def test_flagmap_postprocessor(self, dataframe):

        FieldFlagMap = se_field.Field(
            name="test",
            origin="test",
            post="core.flagmap",
            post_param={
                "map": {
                    0: "A",
                    1: "B",
                    2: "C",
                    3: "D",
                    4: "E",
                },
                "default": "Unknown",
            },
            virtual=True,
            ref=t1.f_post_param,
        )

        post_proc = base_pp.flag_map_post_processor(FieldFlagMap)
        proc_df = post_proc.apply(dataframe)
        excepted_output = pd.Series(
            ["A", "B", "C", "D", "E", "Unknown"], name=FieldFlagMap.name
        )

        assert_series_equal(proc_df[FieldFlagMap.name], excepted_output)

    @pytest.mark.parametrize("index", range(5))
    def test_flag_postprocessor(self, dataframe, index):

        FieldFlags = se_field.Field(
            name="test",
            origin="test",
            post="core.flag",
            post_param=index,
            virtual=True,
            ref=t1.f_post_param,
        )

        expected = [False] * 6
        expected[index] = True

        post_proc = base_pp.flags_post_processor(FieldFlags)
        proc_df = post_proc.apply(dataframe)
        excepted_output = pd.Series(expected, name=FieldFlags.name)

        assert_series_equal(proc_df[FieldFlags.name], excepted_output)

    def test_multiflag_postprocessor(self, dataframe):

        FieldMultiFlag = se_field.Field(
            name="test",
            origin="test",
            post="core.multiflags",
            post_param={
                "start_bit": 0,
                "map": {
                    "00": "A",
                    "01": "B",
                    "10": "C",
                },
            },
            virtual=True,
            ref=t1.f_post_param,
        )

        post_proc = base_pp.multiflags_post_processor(FieldMultiFlag)
        proc_df = post_proc.apply(dataframe)
        excepted_output = pd.Series(
            ["C", "B", "A", "A", "A", "A"], name=FieldMultiFlag.name
        )

        assert_series_equal(proc_df[FieldMultiFlag.name], excepted_output)

    def test_scaling_postprocessor(self):

        FieldScaled = se_field.Field(
            name="test", origin="test", post="core.scale", post_param=10
        )
        FieldScaledV = se_field.Field(
            name="testv",
            origin="testv",
            post="core.scale",
            post_param=10,
            virtual=True,
            ref=FieldScaled,
        )

        post_proc = base_pp.scale_value_processor(FieldScaled)
        proc_df = post_proc.apply(
            pd.DataFrame({FieldScaled.name: [10, 100, 200, 300, 455]})
        )
        excepted_output = pd.Series([1, 10, 20, 30, 45.5], name=FieldScaled.name)

        assert_series_equal(proc_df[FieldScaled.name], excepted_output)

        post_proc = base_pp.scale_value_processor(FieldScaledV)
        proc_df = post_proc.apply(
            pd.DataFrame({FieldScaled.name: [10, 100, 200, 300, 455]})
        )
        excepted_output = pd.Series([1, 10, 20, 30, 45.5], name=FieldScaledV.name)

        assert_series_equal(proc_df[FieldScaledV.name], excepted_output)
        assert_series_equal(
            proc_df[FieldScaled.name],
            pd.Series([10, 100, 200, 300, 455], name=FieldScaled.name),
        )

    def test_hex2int_post_processor(self, dataframe):
        TestField = se_field.Field(
            name="mapa_str",
            origin="test",
            post="core.time_to_milli",
        )

        post_proc = base_pp.hex2int_post_processor(TestField)
        proc_df = post_proc.apply(dataframe)
        excepted_output = pd.Series([10, 2748, 255, 21, 0, 138], name=TestField.name)

        assert_series_equal(proc_df[TestField.name], excepted_output)
