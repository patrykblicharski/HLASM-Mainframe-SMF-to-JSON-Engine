# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from unittest.mock import patch

import pandas as pd
import pytest

from smfexplorer import error
from smfexplorer.core import context as se_context
from smfexplorer.core import request as se_request
from smfexplorer.fields import SMF99S2
from smfexplorer.plugin.wlm.samples import smf_99_1, smf_99_2, smf_99_12, smf_99_14


class TestSamples:
    @pytest.mark.parametrize(
        "sample",
        [
            smf_99_1.cp_service,
            smf_99_1.zaap_service,
            smf_99_1.ziip_service,
            smf_99_1.free_cp_cap,
            smf_99_1.free_zaap_cap,
            smf_99_1.free_ziip_cap,
            smf_99_1.p_utilization,
            smf_99_1.p_num_online,
            smf_99_1.capacity_factors,
            smf_99_1.contention_analysis,
            smf_99_1.cp_usage_and_trickels,
            smf_99_1.page_ins_and_uic,
            smf_99_1.rg_capping,
            smf_99_1.smf_99_01_sample,
            smf_99_2.io_samples,
            smf_99_2.response_time,
            smf_99_2.smf_99_02_sample,
            smf_99_2.srv_samples,
            smf_99_2.srv_service,
            smf_99_12.hiper_dispatch,
            smf_99_14.topology,
        ],
    )
    def test_sample_smoke_test(self, sample):
        assert isinstance(sample(None), se_request.Request)

    def test_smf99s2_cics_ims_sample(self):

        ctx = se_context.Context([""], None)

        with patch("smfexplorer.core.executor.run") as executor:
            executor.return_value = pd.DataFrame(
                {SMF99S2.pserv_on.name: [1, 2, 3, 4, 5]}
            )

            result = smf_99_2.cics_ims(ctx)
            assert isinstance(result, se_request.Request)

        with patch("smfexplorer.core.executor.run") as executor:
            executor.return_value = pd.DataFrame(
                {SMF99S2.pserv_on.name: [0, 0, 0, 0, 0]}
            )

            with pytest.raises(error.RequestError):
                result = smf_99_2.cics_ims(ctx)
