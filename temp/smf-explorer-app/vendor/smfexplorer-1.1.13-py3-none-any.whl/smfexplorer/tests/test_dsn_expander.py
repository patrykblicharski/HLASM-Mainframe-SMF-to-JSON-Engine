# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
import pytest

from smfexplorer import error
from smfexplorer import util as se_util


class TestDSNExpander:
    @pytest.mark.parametrize(
        "range,result",
        [
            (("1", "3"), ["1", "2", "3"]),
            (("a", "c"), ["A", "B", "C"]),
            (("A", "C"), ["A", "B", "C"]),
            (("21", "23"), ["21", "22", "23"]),
        ],
    )
    def test_range_resolver(self, range, result):
        assert se_util._resolve_range(*range) == result

    @pytest.mark.parametrize("range", [("1", "a"), ("2", "1"), ("@", "+"), ("b", "a")])
    def test_range_resolver_exception(self, range):
        with pytest.raises(error.DSNExpanderError):
            se_util._resolve_range(*range)

    @pytest.mark.parametrize(
        "template,result",
        [
            ("DATA.SYS[1..2]", ["DATA.SYS1", "DATA.SYS2"]),
            (
                "DATA.SYS[1..2].TYPE[abc,xyz]",
                [
                    "DATA.SYS1.TYPEABC",
                    "DATA.SYS1.TYPEXYZ",
                    "DATA.SYS2.TYPEABC",
                    "DATA.SYS2.TYPEXYZ",
                ],
            ),
            ("DATA.SYS1.ABZ.TEST", ["DATA.SYS1.ABZ.TEST"]),
            ("DATA[a..c].SYS", ["DATAA.SYS", "DATAB.SYS", "DATAC.SYS"]),
            ("DATA[a,b,c].SYS", ["DATAA.SYS", "DATAB.SYS", "DATAC.SYS"]),
            ("DATA[a,b].TEST[+c,d]", ["DATAA.TESTC", "DATAB.TESTD"]),
            ("DATA[a,b].TEST[+c,d][+e,f]", ["DATAA.TESTCE", "DATAB.TESTDF"]),
            (
                "DATA[a,b].TEST[+c,d][e,f]",
                ["DATAA.TESTCE", "DATAA.TESTCF", "DATAB.TESTDE", "DATAB.TESTDF"],
            ),
            ("DATA[a,b].TEST[+,d]", ["DATAA.TEST", "DATAB.TESTD"]),
        ],
    )
    def test_expand_dataset_name(
        self,
        template,
        result,
    ):
        assert se_util.expand_dataset_template(template) == result

    @pytest.mark.parametrize(
        "template",
        [
            "DATA[+a,b].TEST",
            "DATA[a,b].TEST[+c,d,e]",
            "DATA[a,b].TEST[+c,d][+e,f,g]",
            "DATA[a,b].TEST[+c,d,e][e,f][+g,h]",
        ],
    )
    def test_error_on_expand(self, template):
        with pytest.raises(error.DSNExpanderError):
            se_util.expand_dataset_template(template)
