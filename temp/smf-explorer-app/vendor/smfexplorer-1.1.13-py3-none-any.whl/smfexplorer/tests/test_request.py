# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from unittest import mock

import pandas as pd
import pytest

import smfexplorer as se
from smfexplorer import error as se_error
from smfexplorer.core import context as se_context
from smfexplorer.core import request as se_request
from smfexplorer.fields import COMMON
from smfexplorer.tests.fields import T200S1 as t1


@pytest.fixture
def empty_ctx():
    return se_context.Context("DATASET.NAME", mock.Mock())


class TestRequest:
    def test_only_common_fields_in_request_return_an_error(self, empty_ctx):
        request = se_request.FieldRequest([COMMON.flg], context=empty_ctx)
        with pytest.raises(se_error.RequestError, match=r".*No Record defined.*"):
            request.run()

    def test_field_in_display_is_part_of_request(self, empty_ctx):
        def assert_field(request, dry_run):
            assert t1.mapa_a in request.fields
            assert not dry_run

        with mock.patch("smfexplorer.core.executor.run") as m:
            m.return_value = pd.DataFrame()
            m.side_effect = assert_field

            request = se_request.FieldRequest([t1.mapa_post], context=empty_ctx)
            request.run(display=[t1.mapa_a])

    def test_adding_sort_expressions_to_request_sets_fields_lists_correctly(
        self, empty_ctx
    ):
        request = se_request.FieldRequest([t1.mapa_post], context=empty_ctx)
        request = request.sort(se.ASC(t1.mapa_a))

        assert t1.mapa_a in request.fields
