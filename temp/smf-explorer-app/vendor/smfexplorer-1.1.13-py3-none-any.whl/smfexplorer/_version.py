# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""SMF Explorer Version"""

try:
    from importlib.metadata import version
except ImportError:
    from importlib_metadata import version

__version__ = version("smfexplorer")
