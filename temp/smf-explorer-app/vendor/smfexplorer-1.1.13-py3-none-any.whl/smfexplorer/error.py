# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
import functools
from enum import Enum, auto


class SmfExplorerError(Exception):
    """Base Error for SMF Explorer"""


class ConnectorErrorReason(Enum):
    UNSPECIFIED: int = auto()
    DATASET_NOT_FOUND = auto()
    INSUFFICIENT_PERMISSION = auto()
    SERVICE_UNAVAILABLE = auto()
    MISSING_AUTHENTICATION = auto()


class ConnectorError(SmfExplorerError):
    """Connector related error"""

    def __init__(
        self,
        *args,
        connector=None,
        reason: ConnectorErrorReason = ConnectorErrorReason.UNSPECIFIED,
    ):
        super().__init__(*args)

        self.reason = reason
        self.connector = connector


class EmptyDataSetError(ConnectorError):
    """Error thrown if Dataset is empty"""

    def __init__(self, connector=None):
        super().__init__(
            "Empty result! The datasets probably do not contain data for the requested fields or the specified record.",
            connector=connector,
        )


class ParserError(SmfExplorerError):
    """Parser related error"""

    def __init__(self, *args, parser=None):
        super().__init__(*args)

        self.parser = parser


class RequestError(SmfExplorerError):
    """General purpose error related to a user request"""

    def __init__(self, *args, request=None):
        super().__init__(*args)

        self.request = request


class RGError(RequestError):
    """Error related to `RequestGraph` creation"""


class ExpressionError(SmfExplorerError):
    """Error related to a sort or where expression"""

    def __init__(self, *args, expression=None):
        super().__init__(*args)

        self.expression = expression


class DSNExpanderError(SmfExplorerError):
    """Error related to resolving a dataset name expression"""

    def __init__(self, *args):
        super().__init__(*args)


class PluginError(SmfExplorerError):
    """Error related to loading plugins"""

    def __init__(self, *args, name: str = None):
        super().__init__(*args)

        self.plugin_name = name


class EnvironmentError(SmfExplorerError):
    """Error related to creation of an Environment"""

    def __init__(self, *args: object, mode: str = None) -> None:
        super().__init__(*args)
        self.mode = mode


class SmfExplorerWarning(Warning):
    pass


class InsecureConnectionWarning(SmfExplorerWarning):
    pass


def wrap_exception(logger, msg: str):
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            try:
                return func(*args, **kwargs)
            except SmfExplorerError as ex:
                logger.debug(msg, exc_info=ex)
                raise

        return wrapper

    return decorator
