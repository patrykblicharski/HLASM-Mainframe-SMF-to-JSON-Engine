# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Sample requests for SMF 72 subtype 3"""
from smfexplorer import resolvers
from smfexplorer.core.request import FieldRequest


@resolvers.register_sample()
def smf_72_03_sample(ctx) -> FieldRequest:
    """Request necessary fields for SMF72 subtype 3 analysis

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF72S3 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.class_name,
            F.class_period,
            F.class_goal_type,
            F.class_goal_percentile,
            F.class_goal_value,
            F.is_report_class,
            F.performance_index,
            F.execution_velocity,
            F.utilization_total,
            F.utilization_cp,
            F.utilization_zaap,
            F.utilization_zaap_on_cp,
            F.utilization_ziip,
            F.utilization_ziip_on_cp,
            F.sample_unknown,
            F.sample_idle,
            F.sample_cpu_using,
            F.sample_zaap_using,
            F.sample_ziip_using,
            F.sample_io_using,
            F.sample_cpu_delay,
            F.sample_zaap_delay,
            F.sample_ziip_delay,
            F.sample_io_delay,
            F.sample_swapin_delay,
            F.sample_mpl_delay,
            F.sample_queue_delay,
            F.sample_cpu_capping_delay,
            F.sample_storage_delay,
            F.sample_server_delay,
            F.sample_crypto_using,
            F.sample_crypto_delay,
            F.sample_dasd_io_using,
            F.sample_resource_group_capping,
            F.sample_quiesce_count,
            F.transaction_total_count,
            F.transaction_total_per_second,
            F.transaction_executed_per_second,
            F.transaction_average_active,
            F.transaction_total_swapped_in,
            F.transaction_enclave_average,
            F.transaction_response_time_mean,
            F.transaction_response_time_variance,
            F.transaction_execution_time_mean,
            F.transaction_queue_delay_time_mean,
            F.transaction_aff_delay_time_mean,
            F.transaction_inel_delay_time_mean,
            F.transaction_jcl_time_mean,
            F.transaction_address_space_percentage,
        ]
    )
