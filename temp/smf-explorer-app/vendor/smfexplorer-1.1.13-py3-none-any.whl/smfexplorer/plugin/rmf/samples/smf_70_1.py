# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Sample requests for SMF 70 subtype 1"""
from smfexplorer import resolvers
from smfexplorer.core.request import FieldRequest


@resolvers.register_sample()
def lpar_information(ctx) -> FieldRequest:
    """Request necessary fields from SMF70S1 on LPARs

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF70S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.lpar_name,
            F.system_name,
            F.sysplex_name,
            F.lpar_system_name,
            F.lpar_number,
            F.lpar_cpu_count,
        ]
    )


@resolvers.register_sample()
def processor_information(ctx) -> FieldRequest:
    """Request necessary fields from SMF70S1 on processors

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF70S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.cpu_name,
            F.cpu_count,
            F.cpu_polarization,
            F.processor_weight,
            F.share_actual,
            F.msu_effective,
            F.msu_physical,
            F.utilization_per_cpu_physical,
            F.lpar_management_per_cpu,
            F.logical_processor_online_time,
            F.logical_processor_is_online,
            F.dispatch_time_total,
            F.interval_in_milliseconds,
            F.share_current,
            F.share_minimum,
            F.share_maximum,
            F.cap_wlm_percentage,
            F.cap_actual_percentage,
            F.cap_absolute,
            F.cap_absolute_group,
        ]
    )
