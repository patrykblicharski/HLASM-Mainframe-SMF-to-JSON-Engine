# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from typing import List, Type

from smfexplorer.plugin import FieldPlugin, Plugin, PluginManager, SamplesPlugin


class SmfExplorerRmfPlugin(Plugin, SamplesPlugin, FieldPlugin):
    @staticmethod
    def name() -> str:
        return "rmf"

    def initialize(self):
        super().initialize()

    def post_initialize(self):
        super().post_initialize()

    # @staticmethod
    # def get_field_definitions() -> List[Tuple[str, str]]:
    #     return [
    #         ("SMF70S1", "smfexplorer.plugin.rmf.fields.smf70.smf70s1"),
    #         ("SMF70S2", "smfexplorer.plugin.rmf.fields.smf70.smf70s2"),
    #         ("SMF71S1", "smfexplorer.plugin.rmf.fields.smf71.smf71s1"),
    #         ("SMF72S3", "smfexplorer.plugin.rmf.fields.smf72.smf72s3"),
    #         ("SMF72S4", "smfexplorer.plugin.rmf.fields.smf72.smf72s4"),
    #         ("SMF72S5", "smfexplorer.plugin.rmf.fields.smf72.smf72s5"),
    #     ]

    @staticmethod
    def get_provided_smf_types() -> List[str]:
        return [
            "SMF70S1",
            "SMF70S2",
            "SMF71S1",
            "SMF72S3",
            "SMF72S4",
            "SMF72S5",
        ]

    @staticmethod
    def register_samples() -> None:
        import smfexplorer.plugin.rmf.samples.smf_70_1 as _
        import smfexplorer.plugin.rmf.samples.smf_72_3 as _


def _get_smfexplorer_plugin_class() -> Type[Plugin]:
    return SmfExplorerRmfPlugin
