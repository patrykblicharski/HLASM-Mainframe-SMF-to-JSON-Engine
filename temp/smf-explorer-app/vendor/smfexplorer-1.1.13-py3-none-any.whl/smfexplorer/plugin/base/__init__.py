# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from pkgutil import extend_path

__path__ = extend_path(__path__, __name__)

from typing import List, Type

from smfexplorer.plugin import FieldPlugin, Plugin, PostProcessorPlugin


class SmfExplorerBasePlugin(Plugin, FieldPlugin, PostProcessorPlugin):
    @staticmethod
    def name() -> str:
        return "base"

    @staticmethod
    def required_plugins() -> List[str]:
        return []

    def initialize(self):
        super().initialize()

    def post_initialize(self):
        super().post_initialize()

    # @staticmethod
    # def get_field_definitions() -> List[Tuple[str, str]]:
    #     return [("COMMON", "smfexplorer.plugin.base.fields.common")]

    @staticmethod
    def get_provided_smf_types() -> List[str]:
        return ["COMMON"]

    @staticmethod
    def register_post_processors() -> None:
        import smfexplorer.plugin.base.post_processors as _


def _get_smfexplorer_plugin_class() -> Type[Plugin]:
    return SmfExplorerBasePlugin
