# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Base post-processors for smfexplorer"""
import collections
import datetime

import numpy as np
import pandas as pd

from smfexplorer import error, resolvers
from smfexplorer.core.environment import dgapi
from smfexplorer.core.field import Field
from smfexplorer.core.post_processor import PostProcessor, PostProcessorType
from smfexplorer.util.names import names

# TODO: Check environment restrictions here


@resolvers.register_post_processor("core.timestamp")
def timestamp_post_processor(field: Field):
    def converter(df: pd.DataFrame):
        df[field.name] = df.apply(
            lambda row: pd.Timestamp.combine(row["date"], row["time"]), axis=1
        )
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.timedelta")
def timedelta_post_processor(field: Field):
    def converter(df: pd.DataFrame):
        df[field.name] = pd.to_timedelta(df[field.name], unit=field._post_param)
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.hex2int")
def hex2int_post_processor(field: Field):
    def converter(df: pd.DataFrame):
        df[field.name] = df[field.name].apply(int, base=16)
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.not_implemented")
def not_implemented_processor(field: Field):
    """Post-processor to indicate that the implementation is missing"""
    raise NotImplementedError(
        f"The post processor for the field {field.name} is not implemented"
    )


@resolvers.register_post_processor("core.flags")
def flags_post_processor(field: Field):
    """Post-processor to convert flag fields into boolean values"""

    def converter(df: pd.DataFrame):
        df[field.name] = (
            np.char.find(
                df[names(field._ref)].values.astype(str),
                "1",
                start=field._post_param,
                end=field._post_param + 1,
            )
            == field._post_param
        )
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.alias")
def alias_post_processor(field: Field):
    """Array postprocessor for array virtual fields"""

    def converter(df: pd.DataFrame):
        df[field.name] = df[names(field._ref)]
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.multiflags")
def multiflags_post_processor(field: Field):
    """Flags postprocessor for multiple bit mapping"""
    start_bit = field._post_param["start_bit"]
    length = len(next(field._post_param["map"].keys().__iter__()))

    if "default" in field._post_param:
        map_dict = collections.defaultdict(lambda: field._post_param["default"])
        map_dict.update(field._post_param["map"])
    else:
        map_dict = field._post_param["map"]

    def converter(df: pd.DataFrame):
        df[field.name] = (
            df[names(field._ref)].str.slice(start_bit, start_bit + length).map(map_dict)
        )
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.flagmap")
def flag_map_post_processor(field: Field):
    padded_map = {
        "0" * k + "1" + "0" * (7 - k): v for k, v in field._post_param["map"].items()
    }
    if "default" in field._post_param:
        flag_map = collections.defaultdict(lambda: field._post_param["default"])
        flag_map.update(padded_map)
    else:
        flag_map = padded_map

    def converter(df: pd.DataFrame):
        df[field.name] = df[names(field._ref) if field.virtual else names(field)].map(
            flag_map
        )
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.map")
def map_post_processor(field: Field):
    """Post-processor to map values"""
    if "default" in field._post_param:
        mapper = collections.defaultdict(lambda: field._post_param["default"])
        mapper.update(field._post_param["map"])
    else:
        map_dict = field._post_param["map"]
        mapper = lambda key: map_dict[key] if key in map_dict else key

    def converter(df: pd.DataFrame):
        df[field.name] = df[names(field._ref) if field.virtual else names(field)].map(
            mapper
        )
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.math.sum")
def sum_post_processor(field: Field):
    """Post-processor to sum multiple fields. Mainly used for samples."""

    referenced_fields = field._ref if type(field._ref) == list else [field._ref]

    def converter(df: pd.DataFrame):
        df[field.name] = df[names(referenced_fields)].sum(axis=1)
        return df

    return PostProcessor(
        PostProcessorType.FRAME, converter, required_fields=referenced_fields
    )


@resolvers.register_post_processor("core.math")
def math_post_processor(field: Field):
    """Post-processor to apply simple arithmetics to multiple fields. Supports all pythonic math
    expressions. See pd.DataFrame.eval documentation for full list of capabilities."""

    def converter(df: pd.DataFrame):
        string_expression = field._post_param
        target_columns = df.columns.tolist() + [field.name]
        df.eval(string_expression, inplace=True)
        df.drop(
            [col for col in df.columns if col not in target_columns],
            axis=1,
            inplace=True,
        )
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.inline")
def inline_post_processor(field: Field):
    def converter(df: pd.DataFrame):
        target_columns = df.columns.tolist() + [field.name]
        df[field.name] = field._post_param(df)
        df.drop(
            [col for col in df.columns if col not in target_columns],
            axis=1,
            inplace=True,
        )
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.aggregate")
def agg_post_processor(field: Field):
    """Post-processor to aggregate a field from one map, according to another field.

    post_param is one of the viable function strings that pandas use in transform()"""

    field_to_aggregate = field._ref[0]
    fields_to_groupby = field._ref[1:]

    def converter(df: pd.DataFrame):
        groups = df[names([field_to_aggregate] + fields_to_groupby)].groupby(
            names(fields_to_groupby)
        )
        df[field.name] = groups.transform(field._post_param)
        return df

    referenced_fields = field._ref if type(field._ref) == list else [field._ref]

    return PostProcessor(
        PostProcessorType.FRAME, converter, required_fields=referenced_fields
    )


@resolvers.register_post_processor("core.scale")
def scale_value_processor(field: Field):
    """Post Processor to correct scaled values"""

    src_field = field
    if field.virtual:
        if not isinstance(field._ref, Field):
            raise TypeError(
                f"Scale post processors are only allowed on virtual fields with one dependency. Dependency of '{field.name}' is not a single Field"
            )
        src_field = field._ref

    def converter(df: pd.DataFrame):
        df[field.name] = df[src_field.name] / field._post_param
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)


@resolvers.register_post_processor("core.time_to_milli")
def convert_to_milliseconds(field: Field):

    src_field = field
    if field.virtual:
        if not isinstance(field._ref, Field):
            raise TypeError(
                f"Convert to milliseconds post processors are only allowed on virtual fields with one dependency. Dependency of '{field.name}' is not a single Field"
            )
        src_field = field._ref

    def converter(df: pd.DataFrame):
        df[field.name] = df[src_field.name].apply(
            lambda s: ((s.minute * 60) + s.second) * 1e3 + (s.microsecond / 1e3)
        )
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)
