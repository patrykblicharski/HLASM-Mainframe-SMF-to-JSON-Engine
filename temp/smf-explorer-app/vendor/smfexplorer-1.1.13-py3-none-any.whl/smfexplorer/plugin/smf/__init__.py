# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from typing import List, Type

from smfexplorer.plugin import FieldPlugin, Plugin, PluginManager, SamplesPlugin


class SmfExplorerSmfPlugin(Plugin, SamplesPlugin, FieldPlugin):
    @staticmethod
    def name() -> str:
        return "smf"

    def initialize(self):
        super().initialize()

    def post_initialize(self):
        super().post_initialize()

    @staticmethod
    def get_provided_smf_types() -> List[str]:
        return ["SMF30S1", "SMF30S2", "SMF30S3", "SMF30S4", "SMF30S5", "SMF30S6"]

    @staticmethod
    def register_post_processors() -> None:
        import smfexplorer.plugin.smf.post_processors as _


def _get_smfexplorer_plugin_class() -> Type[Plugin]:
    return SmfExplorerSmfPlugin
