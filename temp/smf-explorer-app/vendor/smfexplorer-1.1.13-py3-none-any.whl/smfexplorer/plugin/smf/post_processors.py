# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Post-Processors for SMF"""

import numpy as np
import pandas as pd

from smfexplorer import resolvers
from smfexplorer.core.field import Field
from smfexplorer.core.post_processor import PostProcessor, PostProcessorType
from smfexplorer.util.names import names


@resolvers.register_post_processor("smf.binary_str_to_hex_str")
def binary_str_to_hex_str(field: Field):
    def converter(df: pd.DataFrame):
        df[field.name] = df[field.name].map(lambda x: hex(int(x, 2))[2:].zfill(4))
        return df

    return PostProcessor(PostProcessorType.FRAME, converter)
