# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from typing import List, Tuple, Type

from smfexplorer.core.field import Field
from smfexplorer.plugin import (
    FieldPlugin,
    Plugin,
    PluginManager,
    PostProcessorPlugin,
    SamplesPlugin,
)


class SmfExplorerWlmPlugin(Plugin, SamplesPlugin, PostProcessorPlugin, FieldPlugin):
    @staticmethod
    def name() -> str:
        return "wlm"

    def initialize(self):
        super().initialize()

    def post_initialize(self):
        super().post_initialize()

    # @staticmethod
    # def get_field_definitions() -> List[Tuple[str, str]]:
    #     return [
    #         ("SMF99COMMON", "smfexplorer.plugin.wlm.fields.smf99.smf99common"),
    #         ("SMF99S1", "smfexplorer.plugin.wlm.fields.smf99.smf99s1"),
    #         ("SMF99S2", "smfexplorer.plugin.wlm.fields.smf99.smf99s2"),
    #         ("SMF99S3", "smfexplorer.plugin.wlm.fields.smf99.smf99s3"),
    #         ("SMF99S4", "smfexplorer.plugin.wlm.fields.smf99.smf99s4"),
    #         ("SMF99S5", "smfexplorer.plugin.wlm.fields.smf99.smf99s5"),
    #         ("SMF99S6", "smfexplorer.plugin.wlm.fields.smf99.smf99s6"),
    #         ("SMF99S7", "smfexplorer.plugin.wlm.fields.smf99.smf99s7"),
    #         ("SMF99S8", "smfexplorer.plugin.wlm.fields.smf99.smf99s8"),
    #         ("SMF99S9", "smfexplorer.plugin.wlm.fields.smf99.smf99s9"),
    #         ("SMF99S10", "smfexplorer.plugin.wlm.fields.smf99.smf99s10"),
    #         ("SMF99S11", "smfexplorer.plugin.wlm.fields.smf99.smf99s11"),
    #         ("SMF99S12", "smfexplorer.plugin.wlm.fields.smf99.smf99s12"),
    #         ("SMF99S13", "smfexplorer.plugin.wlm.fields.smf99.smf99s13"),
    #         ("SMF99S14", "smfexplorer.plugin.wlm.fields.smf99.smf99s14"),
    #         ("SMF113S1", "smfexplorer.plugin.wlm.fields.smf113.smf113s1"),
    #         ("SMF113S2", "smfexplorer.plugin.wlm.fields.smf113.smf113s2"),
    #     ]

    @staticmethod
    def get_provided_smf_types() -> List[Tuple[str, str]]:
        return [
            "SMF99COMMON",
            "SMF99S1",
            "SMF99S2",
            "SMF99S3",
            "SMF99S4",
            "SMF99S5",
            "SMF99S6",
            "SMF99S7",
            "SMF99S8",
            "SMF99S9",
            "SMF99S10",
            "SMF99S11",
            "SMF99S12",
            "SMF99S13",
            "SMF99S14",
            "SMF113S1",
            "SMF113S2",
        ]

    @staticmethod
    def register_post_processors() -> None:
        import smfexplorer.plugin.wlm.post_processors as _

    @staticmethod
    def register_samples() -> None:
        import smfexplorer.plugin.wlm.samples.smf_99_1 as _
        import smfexplorer.plugin.wlm.samples.smf_99_2 as _
        import smfexplorer.plugin.wlm.samples.smf_99_12 as _
        import smfexplorer.plugin.wlm.samples.smf_99_14 as _


def _get_smfexplorer_plugin_class() -> Type[Plugin]:
    return SmfExplorerWlmPlugin
