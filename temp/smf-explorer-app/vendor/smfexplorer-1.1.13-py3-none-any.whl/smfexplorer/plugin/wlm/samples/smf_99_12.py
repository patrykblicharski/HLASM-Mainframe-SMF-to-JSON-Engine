# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Sample requests for SMF 99 subtype 12"""
from smfexplorer import resolvers
from smfexplorer.core.request import FieldRequest


@resolvers.register_sample()
def hiper_dispatch(ctx) -> FieldRequest:
    """Request hiper dispatch information per processor type.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S12 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.cpu_type,
            F.cpu_vh,
            F.cpu_vm,
            F.cpu_vl,
            F.vl_parked,
            F.vl_unparked,
            F.mvs_busy,
            F.vcm_mvsbusydynathrunpark,
            F.vcm_mvsbusydynathrpark,
            F.lpar_busy,
            F.cec_utilization,
            F.cec_free_capacity,
            F.cec_capacity_used,
            F.lpar_capacity_allocated,
            F.lpar_capacity_guaranteed,
            F.lpar_capacity_guaranteed_vm,
            F.lpar_capacity_non_guaranteed,
            F.lpar_capacity_used,
            F.lpar_cap_used_non_guaranteed,
            F.lpar_capacity_used_vm_vl,
            F.lpar_capacity_used_vh,
            F.vm_vl_cap_above_guaranteed,
            F.vm_vl_capacity_of_allocated,
            F.lpar_capacity_unused,
            F.vm_vl_allocated_capacity,
            F.vcm_ceccaptotal,
            F.lpar_busy_projected,
            F.vcm_projvhmutil,
            F.hd_request,
            F.hd_action_explanation,
        ]
    )
