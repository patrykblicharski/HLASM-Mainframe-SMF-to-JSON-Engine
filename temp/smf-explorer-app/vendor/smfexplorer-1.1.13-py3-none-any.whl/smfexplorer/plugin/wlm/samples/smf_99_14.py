# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Sample requests for SMF 99 subtype 14"""
from smfexplorer import resolvers
from smfexplorer.core.request import FieldRequest as _FieldRequest


@resolvers.register_sample()
def topology(ctx) -> _FieldRequest:
    """Request topology information per processor.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S14 as F

    return _FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.hd_topochg_cpu_index,
            F.processor,
            F.cp_cputype,
            F.speed_change,
            F.wuq_error,
            F.honor_priority_change,
            F.affinity_nodes_rebuild,
            F.topology_change,
            F.vcm_cpsperan,
            F.vcm_lparphysprocshr,
            F.cp_ci_nlinuse,
            F.cp_ci_nl1,
            F.cp_ci_nl2,
            F.cp_ci_nl3,
            F.cp_ci_nl4,
            F.cp_ci_nl5,
            F.mpwq_affinity_node,
        ]
    )
