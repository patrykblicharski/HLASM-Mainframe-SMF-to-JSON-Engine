# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Sample Requests for SMF 99 subtype 2"""
import logging

from smfexplorer import resolvers
from smfexplorer.core.expressions import LIKE
from smfexplorer.core.request import FieldRequest
from smfexplorer.error import RequestError

LOG = logging.getLogger(__name__)


@resolvers.register_sample()
def smf_99_02_sample(ctx) -> FieldRequest:
    """Request for commonly used SMF 99 Subtype 2 data.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S2 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.srv_class_name,
            F.period_num,
            F.period_imp,
            F.goal_type_name,
            F.goal_value,
            F.pi_local,
            F.disp_prio,
            F.srv_cp_service,
            F.srv_ziip_service,
            F.srv_zaap_service,
            F.samp_io_using,
            F.samp_io_delay,
            F.samp_io_disconnected,
            F.samp_io_unit_queue,
            F.mpl_in,
            F.mpl_out,
            F.mpl_av,
            F.ready_user_av,
            F.idle,
            F.mpl_delay,
            F.cross_mem_delay,
            F.io_using,
            F.io_delay,
            F.cpu_using,
            F.cpu_delay,
            F.buffer_pool_delay,
            F.ziip_using,
            F.ziip_delay,
            F.zaap_using,
            F.zaap_delay,
            F.cap_delay,
            F.history_rows,
        ]
    )


@resolvers.register_sample()
def srv_service(ctx) -> FieldRequest:
    """Request service Class service consumption for CP, zIIP and zAAP.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S2 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.srv_class_name,
            F.srv_cp_service,
            F.srv_ziip_service,
            F.srv_zaap_service,
            F.period_num,
        ]
    )


@resolvers.register_sample()
def io_samples(ctx) -> FieldRequest:
    """Request IO samples for service class.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S2 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.srv_class_name,
            F.samp_io_using,
            F.samp_io_delay,
            F.samp_io_disconnected,
            F.samp_io_unit_queue,
            F.period_num,
        ]
    )


@resolvers.register_sample()
def srv_samples(ctx) -> FieldRequest:
    """Request sampling information for service class.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S2 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.srv_class_name,
            F.idle,
            F.mpl_delay,
            F.cross_mem_delay,
            F.io_using,
            F.io_delay,
            F.cpu_using,
            F.cpu_delay,
            F.buffer_pool_delay,
            F.ziip_using,
            F.ziip_delay,
            F.zaap_using,
            F.zaap_delay,
            F.cap_delay,
            F.history_rows,
        ]
    )


@resolvers.register_sample()
def response_time(ctx) -> FieldRequest:
    """Request sampling information for response time distribution.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S2 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.srv_class_name,
            F.period_num,
            F.period_imp,
            F.goal_type_name,
            F.goal_value,
            F.prtp,
            F.rt_distri_avg_resp_time,
            F.rt_distri_sum_trans,
            F.rt_distri_int_sum_trans,
            F.rt_distri_num_trans[0],
            F.rt_distri_num_trans[1],
            F.rt_distri_num_trans[2],
            F.rt_distri_num_trans[3],
            F.rt_distri_num_trans[4],
            F.rt_distri_num_trans[5],
            F.rt_distri_num_trans[6],
            F.rt_distri_num_trans[7],
            F.rt_distri_num_trans[8],
            F.rt_distri_num_trans[9],
            F.rt_distri_num_trans[10],
            F.rt_distri_num_trans[11],
            F.rt_distri_num_trans[12],
            F.rt_distri_num_trans[13],
            F.rt_distri_num_trans[14],
            F.rt_distri_num_trans[15],
            F.rt_distri_num_trans[16],
            F.rt_distri_num_trans[17],
            F.rt_distri_num_trans[18],
            F.rt_distri_num_trans[19],
            F.rt_distri_num_trans[20],
            F.rt_distri_num_trans[21],
            F.rt_distri_num_trans[22],
            F.rt_distri_num_trans[23],
            F.rt_distri_num_trans[24],
            F.rt_distri_num_trans[25],
            F.rt_distri_num_trans[26],
            F.rt_distri_num_trans[27],
        ]
    ).where((F.goal_type == 1) | (F.goal_type == 2))


@resolvers.register_sample()
def cics_ims(ctx) -> FieldRequest:
    """Request the necessary columns for cics/ims workload analysis.

    Columns renamed and converted to string or boolean output:
        - cpu_critical
            Indicates whether the period is CPU critical or not.
        - stgcrit_implicit
            Indicates whether the period belongs to a service class that was assigned storage
            protection (storage critical). The service class was used in subsystem type CICS® or IMS
            and the rule specified storage critical = yes.
        - pserver_type_name
            Describes the type of the server associated with the record, based on the bits in the field 'pserver_type'.
            (T = transaction, E = enclave and Q = queue server)

    Returns
    -------
    Request
        Request object that can be executed.

    Notes
    -----
    If the record cannot be associated with a server, then the dataframe does not contain the fields
    'server_cnm', 'server_pnum' and 'server_obs' and an information output is given to the user.
    """
    from smfexplorer.fields import SMF99S2 as F

    requested_fields = [
        F.timestamp,
        F.sid,
        F.srv_class_name,
        F.pcnm,
        F.period_num,
        F.period_imp,
        F.pserver_type_name,
        F.goal_type,
        F.goal_value,
        F.prtp,
        F.pi_local,
        F.pi_sysplex,
        F.disp_prio,
        F.piodp,
        F.srv_cp_service,
        F.srv_zaap_service,
        F.cpu_critical,
        F.stgcrit_implicit,
        F.rvn,
        F.vn2,
    ]

    if ctx is not None:
        dataframe = ctx.request([F.pserv_on]).run()
        contains_server_data = dataframe[[F.pserv_on.name]].sum().sum() > 0

        LOG.debug("contains server data: %s", contains_server_data)
        if contains_server_data:
            requested_fields.extend([F.server_cnm, F.server_pnum, F.server_obs])
        else:
            raise RequestError(
                "Record is not associated with a server. Dataframe does not contain the following fields: 'server_cnm', 'server_pnum' and 'server_obs' "
            )

    # only request internal service classes and filter by Transaction server
    return FieldRequest(requested_fields).where(
        LIKE(F.srv_class_name, "$SRMS%") & LIKE(F.pserver_type, "1%")
    )
