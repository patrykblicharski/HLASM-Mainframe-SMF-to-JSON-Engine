# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Sample requests for SMF 99 subtype 1"""
from smfexplorer import resolvers
from smfexplorer.core.request import FieldRequest


@resolvers.register_sample()
def cp_service(ctx) -> FieldRequest:
    """Request CP service consumption per importance level

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.cp_sys,
            F.cp_imp1,
            F.cp_imp2,
            F.cp_imp3,
            F.cp_imp4,
            F.cp_imp5,
            F.cp_disc,
            F.cp_free,
        ]
    )


@resolvers.register_sample()
def ziip_service(ctx) -> FieldRequest:
    """Request zIIP service consumption per importance level

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.ziip_sys,
            F.ziip_imp1,
            F.ziip_imp2,
            F.ziip_imp3,
            F.ziip_imp4,
            F.ziip_imp5,
            F.ziip_disc,
            F.ziip_free,
        ]
    )


@resolvers.register_sample()
def zaap_service(ctx) -> FieldRequest:
    """Request zAAP service consumption per importance level

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.zaap_sys,
            F.zaap_imp1,
            F.zaap_imp2,
            F.zaap_imp3,
            F.zaap_imp4,
            F.zaap_imp5,
            F.zaap_disc,
            F.zaap_free,
        ]
    )


@resolvers.register_sample()
def p_utilization(ctx) -> FieldRequest:
    """Request CP, zIIP, zAAP and total utilization.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [F.timestamp, F.sid, F.cp_util, F.ziip_util, F.zaap_util, F.total_util]
    )


@resolvers.register_sample()
def capacity_factors(ctx) -> FieldRequest:
    """Request capacity and max capacity factors for CP, zIIP and zAAP.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.cp_cap_fac,
            F.cp_max_fac,
            F.ziip_cap_fac,
            F.ziip_max_fac,
            F.zaap_cap_fac,
            F.zaap_max_fac,
        ]
    )


@resolvers.register_sample()
def p_num_online(ctx) -> FieldRequest:
    """Request number of CPs, zIIPs and zAAPs online.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest([F.timestamp, F.sid, F.cp_online, F.ziip_online, F.zaap_online])


@resolvers.register_sample()
def free_cp_cap(ctx) -> FieldRequest:
    """Request free capacity for CP.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [F.timestamp, F.sid, F.cap_wait, F.cap_guar, F.cap_cec, F.cap_lcp, F.cp_free]
    )


@resolvers.register_sample()
def free_ziip_cap(ctx) -> FieldRequest:
    """Request free capacity for zIIP.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.cap_wait_ziip,
            F.cap_guar_ziip,
            F.cap_cec_ziip,
            F.cap_lcp_ziip,
            F.ziip_free,
        ]
    )


@resolvers.register_sample()
def free_zaap_cap(ctx) -> FieldRequest:
    """Request free capacity for zAAP

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.cap_wait_zaap,
            F.cap_guar_zaap,
            F.cap_cec_zaap,
            F.cap_lcp_zaap,
            F.zaap_free,
        ]
    )


@resolvers.register_sample()
def cp_usage_and_trickels(ctx) -> FieldRequest:
    """Request CP usage and trickels.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest([F.timestamp, F.sid, F.cp_util, F.cctrcuse, F.cctrcwtr])


@resolvers.register_sample()
def page_ins_and_uic(ctx) -> FieldRequest:
    """Request page-in rate count and UIC bucket information.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [F.timestamp, F.sid, F.uic1, F.uic2, F.uic3, F.uic4, F.page_ins]
    )


@resolvers.register_sample()
def smf_99_01_sample(ctx) -> FieldRequest:
    """Request for commonly used SMF 99 subtype 1 data.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.cp_sys,
            F.cp_imp1,
            F.cp_imp2,
            F.cp_imp3,
            F.cp_imp4,
            F.cp_imp5,
            F.cp_disc,
            F.cp_free,
            F.ziip_sys,
            F.ziip_imp1,
            F.ziip_imp2,
            F.ziip_imp3,
            F.ziip_imp4,
            F.ziip_imp5,
            F.ziip_disc,
            F.ziip_free,
            F.cp_util,
            F.ziip_util,
            F.zaap_util,
            F.total_util,
            F.cap_wait,
            F.cap_guar,
            F.cap_cec,
            F.cap_lcp,
            F.cap_wait_ziip,
            F.cap_guar_ziip,
            F.cap_cec_ziip,
            F.cap_lcp_ziip,
            F.uic1,
            F.uic2,
            F.uic3,
            F.uic4,
            F.page_ins,
            F.cp_util,
            F.cctrcuse,
            F.cctrcwtr,
        ]
    )


@resolvers.register_sample()
def rg_capping(ctx) -> FieldRequest:
    """Request for RG and TRG capping data.

    Returns
    -------
    Request
        Request object that can be executed.
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.cp_sys,
            F.rgname,
            F.min_sr,
            F.max_sr,
            F.act_sr,
            F.slices,
            F.rg_perc_min,
            F.rg_perc_max,
            F.rg_total_sr,
            F.rg_mem_limit,
            F.rg_mem_usage_4k,
            F.rg_mem_fixed_frames_4k,
            F.rg_mem_backed_2g_frames,
            F.rg_mem_discretionary_4k,
            F.rg_mem_discretionary_2g,
            F.rg_mem_shortage_flags,
            F.rg_isp,
            F.rg_lacs,
            F.rg_susifa,
            F.rg_sussup,
            F.rg_capacity,
            F.rg_type,
        ]
    )


@resolvers.register_sample()
def contention_analysis(ctx) -> FieldRequest:
    """Request for contention analysis, so the features match them for the Machine Learning Model

    Returns
    -------
    Request
        Request object that can be executed
    """
    from smfexplorer.fields import SMF99S1 as F

    return FieldRequest(
        [
            F.timestamp,
            F.sid,
            F.total_util,
            F.cp_util,
            F.cp_sys,
            F.cp_imp1,
            F.cp_imp2,
            F.cp_imp3,
            F.cp_imp4,
            F.cp_imp5,
            F.cp_disc,
            F.cp_free,
            F.cap_wait,
            F.cap_guar,
            F.cap_cec,
            F.cap_lcp,
            F.uic1,
            F.uic2,
            F.uic3,
            F.uic4,
            F.ziip_util,
            F.ziip_sys,
            F.ziip_imp1,
            F.ziip_imp2,
            F.ziip_imp5,
            F.ziip_free,
            F.cp_dispatch_time,
            F.cp_wait_time,
            F.ziip_dispatch_time,
            F.ziip_wait_time,
            F.ziip_cap_fac,
            F.ziip_max_fac,
            F.lpar_busy_time,
            F.lpar_busy_time_ziip,
            F.ifac_uncapped,
            F.ifac_ziip,
            F.cap_wait_ziip,
            F.cap_guar_ziip,
            F.cap_cec_ziip,
            F.cap_lcp_ziip,
        ]
    )
