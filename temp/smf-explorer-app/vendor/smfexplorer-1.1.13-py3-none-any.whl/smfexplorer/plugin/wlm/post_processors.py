# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Post-Processors for WLM"""

import numpy as np
import pandas as pd

from smfexplorer import resolvers
from smfexplorer.core.field import Record
from smfexplorer.core.post_processor import PostProcessor, PostProcessorType
from smfexplorer.util.names import names


@resolvers.register_post_processor("wlm.smf99s12.timestamp_correction")
def smf99s12_timestamp_correction(record: Record):
    """Post Processor to override Subtype 12 timestamps to handle 2 second report interval."""
    from smfexplorer.fields import SMF99S12

    def converter(df: pd.DataFrame):

        min_sequ = (
            df[names(SMF99S12.sid, SMF99S12.vcm_smf_sequ)]
            .groupby(by=names(SMF99S12.sid))
            .min()
        )

        min_sequ.rename(columns={SMF99S12.vcm_smf_sequ.name: "__offset"}, inplace=True)

        offset = df[names([SMF99S12.sid])].merge(
            min_sequ, on=names(SMF99S12.sid), how="left"
        )["__offset"]

        offset = pd.to_timedelta(
            ((df[names(SMF99S12.vcm_smf_sequ)] - offset) % 5) * 2, unit="s"
        )

        df[SMF99S12.timestamp.name] += offset

        return df

    return PostProcessor(
        PostProcessorType.FRAME,
        converter,
        required_fields=[SMF99S12.timestamp, SMF99S12.sid, SMF99S12.vcm_smf_sequ],
    )
