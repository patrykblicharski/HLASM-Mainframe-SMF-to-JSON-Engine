# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
from typing import List, Union

from smfexplorer.core.field import Field


def names(field: Union[Field, List[Field]], *args: Field) -> Union[str, List[str]]:
    """Helper function for pandas integration.
    Converts a Field or list of Fields to the correct string or list of strings.

    Example
    -------
    ```python
    # returns Series with just cpu_util column
    df[names(SMF99S1.cpu_util)]

    # Returns DataFrame with columns cpu_util, ziip_util and zaap_util
    df[names(SMF99S1.cpu_util, SMF99S1.ziip_util, SMF99S1.ziip_util)]
    df[names([SMF99S1.cpu_util, SMF99S1.ziip_util, SMF99S1.ziip_util])]
    df[names([SMF99S1.cpu_util, SMF99S1.ziip_util], SMF99S1.ziip_util)]
    ```
    """
    result = []
    if args:
        result += [f.name for f in args]
    if isinstance(field, list):
        return [f.name for f in field] + result
    else:
        if result:
            return [field.name] + result
        return field.name
