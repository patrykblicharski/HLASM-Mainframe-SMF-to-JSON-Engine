# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""The helpers module provides a set of usefull utility functions
Those can be functions to create `PostProcessors` or help managing Jupyter Notebooks.
"""

import itertools
import re
import string
from typing import AnyStr, List

from smfexplorer.error import DSNExpanderError


def conn_str_from_relay(relay_str: str) -> str:
    """Create a SMF Explorer connection string from the string returned by the relay"""
    parts = relay_str.split(":")
    return f"mode=relay;host={parts[0]}:{parts[1]};token={parts[3]};port={parts[2]}"


__TOKEN_REGEX = re.compile(r"\[(.*?)\]")
__RANGE_REGEX = re.compile(r"^(?P<start>[0-9]+|\w)\.\.(?P<end>[0-9]+|\w)$")
__ASCII_LIST = list(string.ascii_uppercase)


def _resolve_range(start: str, end: str) -> List[str]:
    if start.isdigit() and end.isdecimal():
        start, end = int(start), int(end)
        if end <= start:
            raise DSNExpanderError(
                f"Error parsing range: Range {start}..{end} has invalid order"
            )
        return [f"{n}" for n in range(start, end + 1)]
    elif start.isalpha() and end.isalpha():
        start, end = start.upper(), end.upper()
        istart, iend = __ASCII_LIST.index(start), __ASCII_LIST.index(end)

        if iend <= istart:
            raise DSNExpanderError(
                f"Error parsing range: Range {start}..{end} has invalid order"
            )

        return [__ASCII_LIST[i] for i in range(istart, iend + 1)]
    else:
        raise DSNExpanderError(f"Error parsing range: Range {start}..{end} is invalid")


def _expand_token(template: str):
    subtokens = template.split(",")

    result = []
    for sub in subtokens:
        match = __RANGE_REGEX.search(sub)
        if match:
            result += _resolve_range(
                match.groupdict()["start"], match.groupdict()["end"]
            )
        else:
            result.append(sub.upper())

    return result


def flatten_tuples(object):
    for item in object:
        if isinstance(item, tuple):
            yield from flatten_tuples(item)
        else:
            yield item


def expand_dataset_template(template: AnyStr) -> List[str]:
    """Expand a template into a list of dataset names

    A template can contain tokens. Tokens are denoted by surrounding pair of `[]`.
    The token itself is a list of values to expand seperated by `,`.
    Each value can be a plain string or a range.

    A range value has the from `<start>..<end>`, where `<start>` and `<end>` can be
    a pair of numbers or single chars. Ranges include the start and end elements.

    If there is more then one token in a template the cartesian product of the sets of values is build.
    To instead join the tokens in an additive manner use the `[+<token>]` syntax to tell the expander
    to add the token to the previous one.
    Notice that a `+` token may not be used as the first token and that the number of elements needs to
    match with the previous token.

    Example
    -------
    The template `DNS.NAME[a..c].SYS[MAIN,A]` would create the following list of datasets:

    - DNS.NAMEA.SYSMAIN
    - DNS.NAMEA.SYSA
    - DNS.NAMEB.SYSMAIN
    - DNS.NAMEB.SYSA
    - DNS.NAMEC.SYSMAIN
    - DNS.NAMEC.SYSA

    The template `DNS.NAME[a..c].SYS[+1,2,3]` would create the following list of datasets:

    - DNS.NAMEA.SYS1
    - DNS.NAMEB.SYS2
    - DNS.NAMEC.SYS3

    Parameters
    ----------
    template : AnyStr
        The template string containing an arbitrary amount of tokens

    Returns
    -------
    List[str]
        A list of all generated dataset names. If `template` has no tokens a List with only the `template` will be returned
    """

    tokens = __TOKEN_REGEX.findall(template)

    if not tokens:
        return [template]

    resolved_tokens = []

    for token in tokens:
        template = template.replace(f"[{token}]", "{}")
        if token.startswith("+"):
            if len(resolved_tokens) == 0:
                raise DSNExpanderError(
                    f"The extending token [{token}] may not be the first token"
                )
            new_token = tuple(_expand_token(token[1:]))
            prev_token = resolved_tokens[-1]

            if len(new_token) != len(prev_token):
                raise DSNExpanderError(
                    f"The token [{token}] has a different number of elements from the previous token"
                )

            resolved_tokens[-1] = tuple(zip(prev_token, new_token))
        else:
            resolved_tokens.append(tuple(_expand_token(token)))

    token_product = [
        tuple(flatten_tuples(p)) for p in itertools.product(*resolved_tokens)
    ]

    result = []
    for product in token_product:
        result.append(template.format(*product))

    return result
