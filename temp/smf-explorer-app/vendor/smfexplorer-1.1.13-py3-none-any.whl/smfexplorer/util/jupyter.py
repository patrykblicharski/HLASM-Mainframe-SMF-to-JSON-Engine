# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Utility functions for SMF Explorer used in Jupyter Notebooks"""
import functools
import logging as _logging
import re as _re
import threading as _threading
import typing
from collections import OrderedDict
from typing import Any, Callable, Dict, List, Tuple

import IPython.display as _ipython
import ipywidgets as _ipywidgets
import itables
import traitlets as _traitlets

import smfexplorer.core.context as _context
from smfexplorer.error import ConnectorError, ConnectorErrorReason, SmfExplorerError
from smfexplorer.util import expand_dataset_template

_LOG = _logging.getLogger(__name__)


def configure_tables(paging: bool = True):
    """Configure itables to be the default output for DataFrames."""
    itables.options.maxBytes = 0
    itables.options.maxColumns = 0
    itables.options.showIndex = True
    itables.options.classes = ["compact", "row-border", "order-column"]
    itables.options.scrollX = True
    itables.options.scrollY = "350px"
    itables.options.scrollCollaps = True
    itables.options.paging = paging

    itables.init_notebook_mode(all_interactive=True)


def _debounce(wait):
    def decorator(func):
        timer = None

        def debounced(*args, **kwargs):
            nonlocal timer

            def call_it():
                func(*args, **kwargs)

            if timer is not None:
                timer.cancel()
            timer = _threading.Timer(wait, call_it)
            timer.start()

        return debounced

    return decorator


_DSN_REGEX = _re.compile(
    r"^(?:(?:;?\s*((?:[a-zA-Z0-9]|\[.*\])+)(?:[\._](?:[a-zA-Z0-9]|\[.*\])+))+)$"
)


def _validate_input(input: str):
    return _DSN_REGEX.match(input.strip())


def _input_to_dsn(input: str):
    parts = input.replace("_", ".").split(";")

    names = []

    for part in parts:
        names += expand_dataset_template(part.strip())

    return names


class _Initializer:
    def __init__(
        self,
        handler: Callable,
        output: _ipywidgets.Output,
        name: str,
        interactive_elements: Dict[str, _ipywidgets.ValueWidget],
    ) -> None:

        self._name = handler.__name__ if not name else name
        self._handler: Callable = handler
        self._output: _ipywidgets.Output = output
        functools.update_wrapper(self, handler)

        self._registered_initializers: typing.OrderedDict[str, _Initializer] = (
            OrderedDict()
        )

        self._value: Any = None
        self._element_values: Dict[str, Any] = {}

        self._interactive_elements: Dict[str, _ipywidgets.ValueWidget] = {}
        for name, element in interactive_elements.items():
            if isinstance(element, _ipywidgets.ValueWidget):
                self._interactive_elements[name] = element
                element.observe(self._element_handler, names="value")

        self._parent_kwds = {}

    def _element_handler(self, change: Dict[str, Any]):
        element_args = {
            name: element.value for name, element in self._interactive_elements.items()
        }
        for _, initializer in self._registered_initializers.items():
            initializer._call(
                **{self._name: self._value, **self._parent_kwds, **element_args}
            )

    def register(
        self,
        create_output: bool = False,
        name: str = None,
        **interactive_elements: _ipywidgets.ValueWidget,
    ):
        def decorator(function):
            output = None
            if create_output:
                output = _ipywidgets.Output()
                _ipython.display(output)

            initializer = _Initializer(function, output, name, interactive_elements)
            self._registered_initializers[function.__name__] = initializer

            if not self._value is None:
                element_args = {
                    name: element.value
                    for name, element in self._interactive_elements.items()
                }
                initializer._call(
                    **{self._name: self._value, **self._parent_kwds, **element_args}
                )

            return initializer

        return decorator

    def register_output(
        self, name: str = None, **interactive_elements: _ipywidgets.ValueWidget
    ):
        return self.register(create_output=True, name=name, **interactive_elements)

    def _call(self, **kwds):
        self._parent_kwds.update(kwds)

        if self._output:
            self._output.clear_output(wait=True)
            with self._output:
                self._value = self._handler(**kwds)
        else:
            self._value = self._handler(**kwds)

        element_args = {
            name: element.value for name, element in self._interactive_elements.items()
        }
        for _, initializer in self._registered_initializers.items():
            initializer._call(
                **{self._name: self._value, **self._parent_kwds, **element_args}
            )

    def __call__(self, *args: Any, **kwds: Any) -> Any:
        return self._handler(*args, **kwds)


class ConfigWidget(_ipywidgets.VBox):
    """Provides a configuration widget to change the dataset name associated with the Context.
    The widget supports to observe its 'value' traitlet that holds a list of dataset names.
    This makes it possible to use the widget with IPythonWidgets interactive functions.
    """

    value = _traitlets.List()

    def get_interact_value(self):
        """Return the value for this widget which should be passed to
        interactive functions. Custom widgets can change this method
        to process the raw value ``self.value``.
        """
        return self.value

    def __init__(
        self,
        ctx: _context.Context,
        init_button_description: str = "Init",
        additional_buttons: List[Tuple[str, Callable]] = None,
    ) -> None:
        """Initialise new configuration widget for ctx.

        Parameters
        ----------
        ctx : Context
            The Context to be configured
        init_button_description: str
            Set alternative Init button description
        additional_buttons: list, optional
            A list of buttons that execute functions in the form ([button_label], [function])

        Returns
        -------
        Widget
            The configuration widget
        """
        _ipywidgets.VBox.__init__(self)

        self.ctx = ctx

        self._value = ";".join(ctx.dataset_names)

        self.dsn_info_label = _ipywidgets.HTML()

        self.dsn_text_field = _ipywidgets.Text(
            placeholder="Dataset Name(s)", disabled=False
        )
        self.dsn_text_field.layout.width = "500px"
        self.dsn_text_field.observe(self.dns_changed, "value")

        self.init_button = _ipywidgets.Button(
            description=init_button_description, tooltip=f"Initialize Report"
        )
        self.init_button.on_click(self.on_init_click)

        self.buttons = [self.init_button]

        if additional_buttons:
            for button in additional_buttons:
                new_button = _ipywidgets.Button(description=button[0])
                new_button.on_click(button[1])
                self.buttons.append(new_button)

        self.dsn_text_field.value = self._value
        self.children = (
            self.dsn_text_field,
            self.dsn_info_label,
            _ipywidgets.HBox(self.buttons),
        )

        self.registered_initializers: typing.OrderedDict[str, _Initializer] = (
            OrderedDict()
        )

    def on_init_click(self, _):
        try:
            self.dsn_text_field.disabled = True
            self.disable_buttons(True)
            dsn = _input_to_dsn(self._value)
            self.value = dsn

            for name, initializer in self.registered_initializers.items():
                initializer._call(dsn=dsn)
        finally:
            self.dsn_text_field.disabled = False
            self.disable_buttons(False)

    def disable_buttons(self, disabled: bool):
        for button in self.buttons:
            button.disabled = disabled

    def dns_changed(self, change):
        value = change["new"]

        self.disable_buttons(True)

        if not value:
            self.dsn_info_label.value = (
                "<b><font color='orange'>Please select a Dataset</b>"
            )
            return
        if not _validate_input(value):
            self.dsn_info_label.value = "<b><font color='red'>Invalid Name(s)</b>"
            return

        self.dsn_info_label.value = "<b><font color='blue'>Validating...</b>"
        self.check_dsn(value)

    @_debounce(0.8)
    def check_dsn(self, value):
        if not _validate_input(value):
            return
        try:
            dataset_names = _input_to_dsn(value)
        except SmfExplorerError as ex:
            self.dsn_info_label.value = (
                f"<b><font color='red'>Error parsing input: {ex}</b>"
            )
            return

        tested_ds_name = ""
        try:
            for ds_name in dataset_names:
                tested_ds_name = ds_name
                if not self.ctx.connector.check_dataset_unsafe(ds_name):
                    self.dsn_info_label.value = (
                        f"<b><font color='red'>Dataset not found: {tested_ds_name}</b>"
                    )
                    break
        except ConnectorError as ex:
            if ex.reason == ConnectorErrorReason.INSUFFICIENT_PERMISSION:
                self.dsn_info_label.value = f"<b><font color='red'>Insufficient permissions on dataset '{tested_ds_name}'</b>"
            elif ex.reason == ConnectorErrorReason.SERVICE_UNAVAILABLE:
                self.dsn_info_label.value = (
                    "<b><font color='red'>Service is unavailable</b>"
                )
            elif ex.reason == ConnectorErrorReason.MISSING_AUTHENTICATION:
                self.dsn_info_label.value = (
                    "<b><font color='red'>Unable to authenticate user</b>"
                )
            else:
                self.dsn_info_label.value = f"<b><font color='red'>Unknown error checking for dataset '{tested_ds_name}'</b>"
        else:
            self.disable_buttons(False)
            self.dsn_info_label.value = "<b><font color='green'>Dataset(s) found</b>"
            self.ctx.dataset_names = dataset_names
            self._value = value

    def register(
        self,
        create_output: bool = False,
        name: str = None,
        **interactive_elements: _ipywidgets.ValueWidget,
    ):
        def decorator(function):

            output = None
            if create_output:
                output = _ipywidgets.Output()
                _ipython.display(output)

            initializer = _Initializer(function, output, name, interactive_elements)
            self.registered_initializers[function.__name__] = initializer

            if self.value:
                initializer._call(dsn=self.value)
            return initializer

        return decorator

    def register_output(
        self, name: str = None, **interactive_elements: _ipywidgets.ValueWidget
    ):
        return self.register(create_output=True, name=name, **interactive_elements)
