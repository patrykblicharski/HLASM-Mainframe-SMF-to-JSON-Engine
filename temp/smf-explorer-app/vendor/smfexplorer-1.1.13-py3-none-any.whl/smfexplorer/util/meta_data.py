# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT
"""Helper functions to fetch meta data of dataset"""

from typing import List

import pandas as pd

import smfexplorer.core.context as _context
from smfexplorer.fields import SMF99S1


def metadata(ctx: _context.Context) -> List[pd.DataFrame]:
    """
    Request metadata of a dataset.

    Returns a list with 4 dataframes:

        1. Processor Online:
        Includes processor online on system and the timestamp, when a processor change is made.

        2. Processor Util:
        Includes utilization (mean, min, max, total usage of the system) on each system per processor.

        3. Service Consumption:
        Includes summed up service consumption over the whole interval, on each system, for each importance level and processor.

        4. Service Classes Service Consumption
        Includes the Service Consumption for each Service Class over the interval

    Returns
    -------
    List
        List with 4 dataframes (explained above)
    """

    # full smf99 subtype 1 dataset
    df_smf99s1_raw = ctx.samples.smf_99_01_sample().run()
    df_smf99s1_raw[SMF99S1.sid.name] = df_smf99s1_raw[SMF99S1.sid.name].astype(str)

    # service classes
    srv_classes_raw = pd.DataFrame()
    supported_subtypes = ctx.get_available_subtypes(99)
    subtype_2 = 2
    # check whether Subtype 2 is available
    if (
        subtype_2 in supported_subtypes["subtype"].values
        and supported_subtypes[supported_subtypes["subtype"] == subtype_2].iloc[0][
            "count"
        ]
        > 0
    ):
        srv_classes_raw = ctx.samples.srv_service().run()

    # processors online
    processor_online_raw = ctx.samples.p_num_online().run()

    # ---------------------------------------------------------------------------- #
    #                     Service Consumption per Processor                        #
    # ---------------------------------------------------------------------------- #

    # Service Consumption Fields for each Processor
    cp_sc_fields = [
        SMF99S1.cp_sys.name,
        SMF99S1.cp_imp1.name,
        SMF99S1.cp_imp2.name,
        SMF99S1.cp_imp3.name,
        SMF99S1.cp_imp4.name,
        SMF99S1.cp_imp5.name,
        SMF99S1.cp_disc.name,
    ]
    ziip_sc_fields = [
        SMF99S1.ziip_sys.name,
        SMF99S1.ziip_imp1.name,
        SMF99S1.ziip_imp2.name,
        SMF99S1.ziip_imp3.name,
        SMF99S1.ziip_imp4.name,
        SMF99S1.ziip_imp5.name,
        SMF99S1.ziip_disc.name,
    ]
    zaap_sc_fields = [
        SMF99S1.zaap_sys.name,
        SMF99S1.zaap_imp1.name,
        SMF99S1.zaap_imp2.name,
        SMF99S1.zaap_imp3.name,
        SMF99S1.zaap_imp4.name,
        SMF99S1.zaap_imp5.name,
        SMF99S1.zaap_disc.name,
    ]
    general_fields = [SMF99S1.timestamp.name, SMF99S1.sid.name]

    # Dataframe Service Consumption grouped by System
    df_serv_con = (
        df_smf99s1_raw[[*general_fields, *cp_sc_fields, *ziip_sc_fields]]
        .groupby(SMF99S1.sid.name)
        .sum()
        .reset_index()
    )

    # Total Service Consumption per Processor
    df_serv_con["cp_total"] = df_serv_con[cp_sc_fields].sum(axis=1)
    df_serv_con["ziip_total"] = df_serv_con[ziip_sc_fields].sum(axis=1)

    # Total Percentage Usage per Processor
    df_serv_con["cp_usage"] = (
        df_serv_con["cp_total"]
        / df_serv_con[["cp_total", "ziip_total"]].sum(axis=1)
        * 100
    )
    df_serv_con["ziip_usage"] = (
        df_serv_con["ziip_total"]
        / df_serv_con[["cp_total", "ziip_total"]].sum(axis=1)
        * 100
    )

    # ---------------------------------------------------------------------------- #
    #                            Processor Utilization                             #
    # ---------------------------------------------------------------------------- #

    utilization_values = [
        SMF99S1.cp_util.name,
        SMF99S1.ziip_util.name,
        SMF99S1.zaap_util.name,
    ]
    describe_values = ["mean", "min", "max"]

    processor_util_raw = df_smf99s1_raw[[*general_fields, *utilization_values]].groupby(
        SMF99S1.sid.name
    )

    processor_util_cp = processor_util_raw.describe()[SMF99S1.cp_util.name][
        describe_values
    ].reset_index()
    processor_util_cp["usage"] = df_serv_con["cp_usage"]
    processor_util_ziip = processor_util_raw.describe()[SMF99S1.ziip_util.name][
        describe_values
    ].reset_index()
    processor_util_ziip["usage"] = df_serv_con["ziip_usage"]

    processor_util = pd.concat(
        [processor_util_cp.round(2), processor_util_ziip.round(2)],
        keys=[SMF99S1.cp_util.name, SMF99S1.ziip_util.name],
    )
    processor_util.index = processor_util.index.droplevel(1)

    # ---------------------------------------------------------------------------- #
    #                              Processor Online                                #
    # ---------------------------------------------------------------------------- #

    processors = [
        SMF99S1.sid.name,
        SMF99S1.cp_online.name,
        SMF99S1.ziip_online.name,
        SMF99S1.zaap_online.name,
    ]
    sids = processor_online_raw.groupby(processors)
    processor_online = (
        sids.first()
        .sort_values(by=[SMF99S1.sid.name, SMF99S1.timestamp.name])
        .dropna()
        .reset_index()
    )

    return [processor_online, processor_util, df_serv_con, srv_classes_raw]
