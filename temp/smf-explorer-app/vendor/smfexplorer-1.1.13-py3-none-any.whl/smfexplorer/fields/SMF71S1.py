# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 71 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=71,
                                smf_subtype=1,
                                spec='SMF 71 Subtype 1',
                                post=None)
"""SMF 71 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __interval_in_milliseconds_inline_post(df):
    return df.interval.dt.total_seconds() * 1e3



SMF71PRO: Final[RecordMap] = RecordMap(
    origin='SMF71PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=True)
"""RMF Product Section"""
SMF71PAG: Final[RecordMap] = RecordMap(
    origin='SMF71PAG',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='PAGING DATA SECTION',
    post=None,
    record_mapping=False)
"""PAGING DATA SECTION"""

date : Final[Field] = Field(
    name='date',
    origin='SMF71DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF71DTE`
    Record: `SMF71S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF71DTE`
    Record: `SMF71S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF71TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF71TME`
    Record: `SMF71S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF71TME`
    Record: `SMF71S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF71DTE`), `time`(`SMF71TME`)
    Record: `SMF71S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF71DTE`), `time`(`SMF71TME`)
    Record: `SMF71S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF71LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF71LEN`
    Record: `SMF71S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF71LEN`
    Record: `SMF71S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF71SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF71SEG`
    Record: `SMF71S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF71SEG`
    Record: `SMF71S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF71FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF71FLG`
    Record: `SMF71S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF71FLG`
    Record: `SMF71S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF71FLG`)
    Record: `SMF71S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF71RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF71RTY`
    Record: `SMF71S1`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF71RTY`
    Record: `SMF71S1`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF71TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF71TME`
    Record: `SMF71S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF71TME`
    Record: `SMF71S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF71DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF71DTE`
    Record: `SMF71S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF71DTE`
    Record: `SMF71S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF71SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF71SID`
    Record: `SMF71S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF71SID`
    Record: `SMF71S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF71SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF71SSI`
    Record: `SMF71S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF71SSI`
    Record: `SMF71S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF71STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF71STY`
    Record: `SMF71S1`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF71STY`
    Record: `SMF71S1`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF71TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF71TRN`
    Record: `SMF71S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF71TRN`
    Record: `SMF71S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF71PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF71PRS`
    Record: `SMF71S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF71PRS`
    Record: `SMF71S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF71PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF71PRL`
    Record: `SMF71S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF71PRL`
    Record: `SMF71S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF71PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF71PRN`
    Record: `SMF71S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF71PRN`
    Record: `SMF71S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

pds : Final[Field] = Field(
    name='pds',
    origin='SMF71PDS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO PAGING DATA SECTION

SMF Info
--------
    Field: `SMF71PDS`
    Record: `SMF71S1`
    Map: Not part of a map

OFFSET TO PAGING DATA SECTION
"""
pds.__doc__ = """OFFSET TO PAGING DATA SECTION

SMF Info
--------
    Field: `SMF71PDS`
    Record: `SMF71S1`
    Map: Not part of a map

OFFSET TO PAGING DATA SECTION
"""

pdl : Final[Field] = Field(
    name='pdl',
    origin='SMF71PDL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF PAGING DATA SECTION

SMF Info
--------
    Field: `SMF71PDL`
    Record: `SMF71S1`
    Map: Not part of a map

LENGTH OF PAGING DATA SECTION
"""
pdl.__doc__ = """LENGTH OF PAGING DATA SECTION

SMF Info
--------
    Field: `SMF71PDL`
    Record: `SMF71S1`
    Map: Not part of a map

LENGTH OF PAGING DATA SECTION
"""

pdn : Final[Field] = Field(
    name='pdn',
    origin='SMF71PDN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF PAGING DATA SECTIONS

SMF Info
--------
    Field: `SMF71PDN`
    Record: `SMF71S1`
    Map: Not part of a map

NUMBER OF PAGING DATA SECTIONS
"""
pdn.__doc__ = """NUMBER OF PAGING DATA SECTIONS

SMF Info
--------
    Field: `SMF71PDN`
    Record: `SMF71S1`
    Map: Not part of a map

NUMBER OF PAGING DATA SECTIONS
"""

sws : Final[Field] = Field(
    name='sws',
    origin='SMF71SWS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO SWAP PLACEMENT DATA SECTION

SMF Info
--------
    Field: `SMF71SWS`
    Record: `SMF71S1`
    Map: Not part of a map

OFFSET TO SWAP PLACEMENT DATA SECTION
"""
sws.__doc__ = """OFFSET TO SWAP PLACEMENT DATA SECTION

SMF Info
--------
    Field: `SMF71SWS`
    Record: `SMF71S1`
    Map: Not part of a map

OFFSET TO SWAP PLACEMENT DATA SECTION
"""

swl : Final[Field] = Field(
    name='swl',
    origin='SMF71SWL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF SWAP PLACEMENT DATA SECTION

SMF Info
--------
    Field: `SMF71SWL`
    Record: `SMF71S1`
    Map: Not part of a map

LENGTH OF SWAP PLACEMENT DATA SECTION
"""
swl.__doc__ = """LENGTH OF SWAP PLACEMENT DATA SECTION

SMF Info
--------
    Field: `SMF71SWL`
    Record: `SMF71S1`
    Map: Not part of a map

LENGTH OF SWAP PLACEMENT DATA SECTION
"""

swn : Final[Field] = Field(
    name='swn',
    origin='SMF71SWN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF SWAP PLACEMENT DATA SECTION

SMF Info
--------
    Field: `SMF71SWN`
    Record: `SMF71S1`
    Map: Not part of a map

NUMBER OF SWAP PLACEMENT DATA SECTION
"""
swn.__doc__ = """NUMBER OF SWAP PLACEMENT DATA SECTION

SMF Info
--------
    Field: `SMF71SWN`
    Record: `SMF71S1`
    Map: Not part of a map

NUMBER OF SWAP PLACEMENT DATA SECTION
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF71MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF71MFV`
    Record: `SMF71S1`
    Map: `SMF71PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF71MFV`
    Record: `SMF71S1`
    Map: `SMF71PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF71PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF71PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF71PRD`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF71PRD`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF71IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF71PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF71IST`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF71IST`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF71DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF71PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF71DAT`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF71DAT`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Date monitor interval start
"""

interval : Final[Field] = Field(
    name='interval',
    origin='SMF71INT',
    post='core.packed_time',
    post_param=None,
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF71PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF71INT`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Duration of monitor interval

Post Processing (`core.packed_time`)
---------------
No post-processing parameter defined
"""
interval.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF71INT`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Duration of monitor interval

Post Processing (`core.packed_time`)
---------------
No post-processing parameter defined
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF71SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF71SAM`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF71SAM`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF71FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF71PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF71FLA`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF71FLA`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF71PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF71FLA`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF71CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF71PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF71CYC`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF71CYC`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF71MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF71PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF71MVS`
    Record: `SMF71S1`
    Map: `SMF71PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF71MVS`
    Record: `SMF71S1`
    Map: `SMF71PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF71IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF71IML`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF71IML`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF71PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF71PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF71PRF`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF71PRF`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF71PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF71PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF71PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF71PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF71PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF71PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF71PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF71PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF71PRF`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF71PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF71PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF71PTN`
    Record: `SMF71S1`
    Map: `SMF71PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF71PTN`
    Record: `SMF71S1`
    Map: `SMF71PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF71SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF71SRL`
    Record: `SMF71S1`
    Map: `SMF71PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF71SRL`
    Record: `SMF71S1`
    Map: `SMF71PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF71IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF71PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF71IET`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF71IET`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF71LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF71LGO`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF71LGO`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF71RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF71RAO`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF71RAO`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF71RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF71RAL`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF71RAL`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF71RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF71RAN`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF71RAN`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF71OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF71OIL`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF71OIL`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF71SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF71SYN`
    Record: `SMF71S1`
    Map: `SMF71PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF71SYN`
    Record: `SMF71S1`
    Map: `SMF71PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF71GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF71PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF71GIE`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF71GIE`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF71XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF71PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF71XNM`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF71XNM`
    Record: `SMF71S1`
    Map: `SMF71PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF71SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF71PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF71SNM`
    Record: `SMF71S1`
    Map: `SMF71PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF71SNM`
    Record: `SMF71S1`
    Map: `SMF71PRO`

System name for current system as defined in CVTSNAME
"""

interval_in_milliseconds : Final[Field] = Field(
    name='interval_in_milliseconds',
    origin=None,
    post="core.inline",
    post_param=__interval_in_milliseconds_inline_post,
    virtual=True,
    ref=interval,
    record=record,
    record_map=SMF71PRO,
)
"""Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF71INT`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""
interval_in_milliseconds.__doc__ = """Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF71INT`)
    Record: `SMF71S1`
    Map: `SMF71PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""

pin : Final[Field] = Field(
    name='pin',
    origin='SMF71PIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""PAGE-INS EXCLUDING VIO AND SWAP (LPA,CSA, AND ADDRESS SPACE PAGE INS - NON VIO, NON-SWAP, NON-BLOCK) - FROM RCETOTPI

SMF Info
--------
    Field: `SMF71PIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

PAGE-INS EXCLUDING VIO AND SWAP (LPA,CSA, AND ADDRESS SPACE PAGE INS - NON VIO, NON-SWAP, NON-BLOCK) - FROM RCETOTPI
"""
pin.__doc__ = """PAGE-INS EXCLUDING VIO AND SWAP (LPA,CSA, AND ADDRESS SPACE PAGE INS - NON VIO, NON-SWAP, NON-BLOCK) - FROM RCETOTPI

SMF Info
--------
    Field: `SMF71PIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

PAGE-INS EXCLUDING VIO AND SWAP (LPA,CSA, AND ADDRESS SPACE PAGE INS - NON VIO, NON-SWAP, NON-BLOCK) - FROM RCETOTPI
"""

pot : Final[Field] = Field(
    name='pot',
    origin='SMF71POT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""PAGE-OUTS EXCLUDING VIO AND SWAP (LPA, CSA, AND ADDRESS SPACE PAGE OUTS - NON VIO, NON SWAP) - FROM RCETOTPO

SMF Info
--------
    Field: `SMF71POT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

PAGE-OUTS EXCLUDING VIO AND SWAP (LPA, CSA, AND ADDRESS SPACE PAGE OUTS - NON VIO, NON SWAP) - FROM RCETOTPO
"""
pot.__doc__ = """PAGE-OUTS EXCLUDING VIO AND SWAP (LPA, CSA, AND ADDRESS SPACE PAGE OUTS - NON VIO, NON SWAP) - FROM RCETOTPO

SMF Info
--------
    Field: `SMF71POT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

PAGE-OUTS EXCLUDING VIO AND SWAP (LPA, CSA, AND ADDRESS SPACE PAGE OUTS - NON VIO, NON SWAP) - FROM RCETOTPO
"""

ssq : Final[Field] = Field(
    name='ssq',
    origin='SMF71SSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""# OF MEMORY SWAP SEQUENCES

SMF Info
--------
    Field: `SMF71SSQ`
    Record: `SMF71S1`
    Map: `SMF71PAG`

# OF MEMORY SWAP SEQUENCES
"""
ssq.__doc__ = """# OF MEMORY SWAP SEQUENCES

SMF Info
--------
    Field: `SMF71SSQ`
    Record: `SMF71S1`
    Map: `SMF71PAG`

# OF MEMORY SWAP SEQUENCES
"""

sin : Final[Field] = Field(
    name='sin',
    origin='SMF71SIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""SWAP-IN PAGES (ADDRESS SPACE PAGE INS - NON VIO, SWAP) - FROM RCESWPPI

SMF Info
--------
    Field: `SMF71SIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SWAP-IN PAGES (ADDRESS SPACE PAGE INS - NON VIO, SWAP) - FROM RCESWPPI
"""
sin.__doc__ = """SWAP-IN PAGES (ADDRESS SPACE PAGE INS - NON VIO, SWAP) - FROM RCESWPPI

SMF Info
--------
    Field: `SMF71SIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SWAP-IN PAGES (ADDRESS SPACE PAGE INS - NON VIO, SWAP) - FROM RCESWPPI
"""

sot : Final[Field] = Field(
    name='sot',
    origin='SMF71SOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""SWAP-OUT PAGES (ADDRESS SPACE PAGE OUTS - NON VIO, SWAP) - FROM RCESWPPO

SMF Info
--------
    Field: `SMF71SOT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SWAP-OUT PAGES (ADDRESS SPACE PAGE OUTS - NON VIO, SWAP) - FROM RCESWPPO
"""
sot.__doc__ = """SWAP-OUT PAGES (ADDRESS SPACE PAGE OUTS - NON VIO, SWAP) - FROM RCESWPPO

SMF Info
--------
    Field: `SMF71SOT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SWAP-OUT PAGES (ADDRESS SPACE PAGE OUTS - NON VIO, SWAP) - FROM RCESWPPO
"""

vin : Final[Field] = Field(
    name='vin',
    origin='SMF71VIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""VIO PAGE-INS (ADDRESS SPACE PAGE INS - VIO, NON SWAP) - FROM RCEVIOPI

SMF Info
--------
    Field: `SMF71VIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

VIO PAGE-INS (ADDRESS SPACE PAGE INS - VIO, NON SWAP) - FROM RCEVIOPI
"""
vin.__doc__ = """VIO PAGE-INS (ADDRESS SPACE PAGE INS - VIO, NON SWAP) - FROM RCEVIOPI

SMF Info
--------
    Field: `SMF71VIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

VIO PAGE-INS (ADDRESS SPACE PAGE INS - VIO, NON SWAP) - FROM RCEVIOPI
"""

vot : Final[Field] = Field(
    name='vot',
    origin='SMF71VOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""VIO PAGE-OUTS (ADDRESS SPACE PAGE OUTS - VIO, NON SWAP) - FROM RCEVIOPO

SMF Info
--------
    Field: `SMF71VOT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

VIO PAGE-OUTS (ADDRESS SPACE PAGE OUTS - VIO, NON SWAP) - FROM RCEVIOPO
"""
vot.__doc__ = """VIO PAGE-OUTS (ADDRESS SPACE PAGE OUTS - VIO, NON SWAP) - FROM RCEVIOPO

SMF Info
--------
    Field: `SMF71VOT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

VIO PAGE-OUTS (ADDRESS SPACE PAGE OUTS - VIO, NON SWAP) - FROM RCEVIOPO
"""

sni : Final[Field] = Field(
    name='sni',
    origin='SMF71SNI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""SYS PGABLE AREAS NON-VIO PAGE-IN (LPA/CSA PAGE INS - NON VIO, NON SWAP) - FROM RCECOMPI

SMF Info
--------
    Field: `SMF71SNI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SYS PGABLE AREAS NON-VIO PAGE-IN (LPA/CSA PAGE INS - NON VIO, NON SWAP) - FROM RCECOMPI
"""
sni.__doc__ = """SYS PGABLE AREAS NON-VIO PAGE-IN (LPA/CSA PAGE INS - NON VIO, NON SWAP) - FROM RCECOMPI

SMF Info
--------
    Field: `SMF71SNI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SYS PGABLE AREAS NON-VIO PAGE-IN (LPA/CSA PAGE INS - NON VIO, NON SWAP) - FROM RCECOMPI
"""

sno : Final[Field] = Field(
    name='sno',
    origin='SMF71SNO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""SPA NON-VIO PAGE-OUTS (LPA/CSA PAGE OUTS - NON VIO, NON SWAP) - FROM RCECOMPO

SMF Info
--------
    Field: `SMF71SNO`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SPA NON-VIO PAGE-OUTS (LPA/CSA PAGE OUTS - NON VIO, NON SWAP) - FROM RCECOMPO
"""
sno.__doc__ = """SPA NON-VIO PAGE-OUTS (LPA/CSA PAGE OUTS - NON VIO, NON SWAP) - FROM RCECOMPO

SMF Info
--------
    Field: `SMF71SNO`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SPA NON-VIO PAGE-OUTS (LPA/CSA PAGE OUTS - NON VIO, NON SWAP) - FROM RCECOMPO
"""

lni : Final[Field] = Field(
    name='lni',
    origin='SMF71LNI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""(LPA PAGE INS - NON VIO, NON SWAP) FROM RCELPAPI

SMF Info
--------
    Field: `SMF71LNI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

(LPA PAGE INS - NON VIO, NON SWAP) FROM RCELPAPI
"""
lni.__doc__ = """(LPA PAGE INS - NON VIO, NON SWAP) FROM RCELPAPI

SMF Info
--------
    Field: `SMF71LNI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

(LPA PAGE INS - NON VIO, NON SWAP) FROM RCELPAPI
"""

afc : Final[Field] = Field(
    name='afc',
    origin='SMF71AFC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAIN STOR AVAILABLE FRAME COUNT (SNAPSHOT OF UNUSED) FROM RCEAFC

SMF Info
--------
    Field: `SMF71AFC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAIN STOR AVAILABLE FRAME COUNT (SNAPSHOT OF UNUSED) FROM RCEAFC
"""
afc.__doc__ = """MAIN STOR AVAILABLE FRAME COUNT (SNAPSHOT OF UNUSED) FROM RCEAFC

SMF Info
--------
    Field: `SMF71AFC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAIN STOR AVAILABLE FRAME COUNT (SNAPSHOT OF UNUSED) FROM RCEAFC
"""

tfc : Final[Field] = Field(
    name='tfc',
    origin='SMF71TFC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAIN STOR TOTAL FRAME COUNT EXCLUDING NUCLEUS, BAD OR OFFLINE FRAMES-FROM RCEPOOL incl. PFT frames (RCEPRMCT) incl. FLPA/EFLPA frames and real frame zero

SMF Info
--------
    Field: `SMF71TFC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAIN STOR TOTAL FRAME COUNT EXCLUDING NUCLEUS, BAD OR OFFLINE FRAMES-FROM RCEPOOL incl. PFT frames (RCEPRMCT) incl. FLPA/EFLPA frames and real frame zero
"""
tfc.__doc__ = """MAIN STOR TOTAL FRAME COUNT EXCLUDING NUCLEUS, BAD OR OFFLINE FRAMES-FROM RCEPOOL incl. PFT frames (RCEPRMCT) incl. FLPA/EFLPA frames and real frame zero

SMF Info
--------
    Field: `SMF71TFC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAIN STOR TOTAL FRAME COUNT EXCLUDING NUCLEUS, BAD OR OFFLINE FRAMES-FROM RCEPOOL incl. PFT frames (RCEPRMCT) incl. FLPA/EFLPA frames and real frame zero
"""

tsc : Final[Field] = Field(
    name='tsc',
    origin='SMF71TSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AUX TOTAL SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS) - FROM ASMSLOTS

SMF Info
--------
    Field: `SMF71TSC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AUX TOTAL SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS) - FROM ASMSLOTS
"""
tsc.__doc__ = """AUX TOTAL SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS) - FROM ASMSLOTS

SMF Info
--------
    Field: `SMF71TSC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AUX TOTAL SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS) - FROM ASMSLOTS
"""

dsc : Final[Field] = Field(
    name='dsc',
    origin='SMF71DSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AUX DATA SET SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS FOR VIO PAGES) FROM ASMVSC

SMF Info
--------
    Field: `SMF71DSC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AUX DATA SET SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS FOR VIO PAGES) FROM ASMVSC
"""
dsc.__doc__ = """AUX DATA SET SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS FOR VIO PAGES) FROM ASMVSC

SMF Info
--------
    Field: `SMF71DSC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AUX DATA SET SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS FOR VIO PAGES) FROM ASMVSC
"""

vsc : Final[Field] = Field(
    name='vsc',
    origin='SMF71VSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AUX VIRT MEMORY SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS FOR NON VIO PAGES) FROM ASMNVSC

SMF Info
--------
    Field: `SMF71VSC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AUX VIRT MEMORY SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS FOR NON VIO PAGES) FROM ASMNVSC
"""
vsc.__doc__ = """AUX VIRT MEMORY SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS FOR NON VIO PAGES) FROM ASMNVSC

SMF Info
--------
    Field: `SMF71VSC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AUX VIRT MEMORY SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS FOR NON VIO PAGES) FROM ASMNVSC
"""

nsc : Final[Field] = Field(
    name='nsc',
    origin='SMF71NSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AUX UNALLOCATED SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS UNALLOCATED) - FROM ASMSLOTS MINUS ASMVSC+ASMNVSC+ASMERRS

SMF Info
--------
    Field: `SMF71NSC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AUX UNALLOCATED SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS UNALLOCATED) - FROM ASMSLOTS MINUS ASMVSC+ASMNVSC+ASMERRS
"""
nsc.__doc__ = """AUX UNALLOCATED SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS UNALLOCATED) - FROM ASMSLOTS MINUS ASMVSC+ASMNVSC+ASMERRS

SMF Info
--------
    Field: `SMF71NSC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AUX UNALLOCATED SLOT COUNT (SNAPSHOT OF LOCAL PAGE DS SLOTS UNALLOCATED) - FROM ASMSLOTS MINUS ASMVSC+ASMNVSC+ASMERRS
"""

fin : Final[Field] = Field(
    name='fin',
    origin='SMF71FIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""NO. FRAMES IN NUCLEUS CALCULATED FROM ((CVTDOFFE-CVT DOFFS)+(CVTRWNE-CVTRWNS)+ (CVT ERWNE-CVTERWNS)+(CVTRONE-CVTRO NS)) / 4096

SMF Info
--------
    Field: `SMF71FIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

NO. FRAMES IN NUCLEUS CALCULATED FROM ((CVTDOFFE-CVT DOFFS)+(CVTRWNE-CVTRWNS)+ (CVT ERWNE-CVTERWNS)+(CVTRONE-CVTRO NS)) / 4096
"""
fin.__doc__ = """NO. FRAMES IN NUCLEUS CALCULATED FROM ((CVTDOFFE-CVT DOFFS)+(CVTRWNE-CVTRWNS)+ (CVT ERWNE-CVTERWNS)+(CVTRONE-CVTRO NS)) / 4096

SMF Info
--------
    Field: `SMF71FIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

NO. FRAMES IN NUCLEUS CALCULATED FROM ((CVTDOFFE-CVT DOFFS)+(CVTRWNE-CVTRWNS)+ (CVT ERWNE-CVTERWNS)+(CVTRONE-CVTRO NS)) / 4096
"""

mnf : Final[Field] = Field(
    name='mnf',
    origin='SMF71MNF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN AVAIL. PAGE FRAMES - FROM RCEAFC

SMF Info
--------
    Field: `SMF71MNF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN AVAIL. PAGE FRAMES - FROM RCEAFC
"""
mnf.__doc__ = """MIN AVAIL. PAGE FRAMES - FROM RCEAFC

SMF Info
--------
    Field: `SMF71MNF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN AVAIL. PAGE FRAMES - FROM RCEAFC
"""

mxf : Final[Field] = Field(
    name='mxf',
    origin='SMF71MXF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX AVAIL. PAGE FRAMES

SMF Info
--------
    Field: `SMF71MXF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX AVAIL. PAGE FRAMES
"""
mxf.__doc__ = """MAX AVAIL. PAGE FRAMES

SMF Info
--------
    Field: `SMF71MXF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX AVAIL. PAGE FRAMES
"""

avf : Final[Field] = Field(
    name='avf',
    origin='SMF71AVF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG AVAIL. PAGE FRAMES

SMF Info
--------
    Field: `SMF71AVF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG AVAIL. PAGE FRAMES
"""
avf.__doc__ = """AVG AVAIL. PAGE FRAMES

SMF Info
--------
    Field: `SMF71AVF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG AVAIL. PAGE FRAMES
"""

mnp : Final[Field] = Field(
    name='mnp',
    origin='SMF71MNP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN CSA FRAMES - FROM (RCECOMAL-RCELPAAL-RCESQAAL), includes Restricted Use CSA

SMF Info
--------
    Field: `SMF71MNP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN CSA FRAMES - FROM (RCECOMAL-RCELPAAL-RCESQAAL), includes Restricted Use CSA
"""
mnp.__doc__ = """MIN CSA FRAMES - FROM (RCECOMAL-RCELPAAL-RCESQAAL), includes Restricted Use CSA

SMF Info
--------
    Field: `SMF71MNP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN CSA FRAMES - FROM (RCECOMAL-RCELPAAL-RCESQAAL), includes Restricted Use CSA
"""

mxp : Final[Field] = Field(
    name='mxp',
    origin='SMF71MXP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX CSA FRAMES, includes RUCSA

SMF Info
--------
    Field: `SMF71MXP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX CSA FRAMES, includes RUCSA
"""
mxp.__doc__ = """MAX CSA FRAMES, includes RUCSA

SMF Info
--------
    Field: `SMF71MXP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX CSA FRAMES, includes RUCSA
"""

avp : Final[Field] = Field(
    name='avp',
    origin='SMF71AVP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG CSA FRAMES, includes RUCSA

SMF Info
--------
    Field: `SMF71AVP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG CSA FRAMES, includes RUCSA
"""
avp.__doc__ = """AVG CSA FRAMES, includes RUCSA

SMF Info
--------
    Field: `SMF71AVP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG CSA FRAMES, includes RUCSA
"""

mns : Final[Field] = Field(
    name='mns',
    origin='SMF71MNS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN ADDR SPACE FRAMES - FROM ( RCEPOOL+RCEPRMCT-(RCAFC+RCE_Fr eemainedFrames)- RCEAFC-RCECOMAL-RCELSAAL)

SMF Info
--------
    Field: `SMF71MNS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN ADDR SPACE FRAMES - FROM ( RCEPOOL+RCEPRMCT-(RCAFC+RCE_Fr eemainedFrames)- RCEAFC-RCECOMAL-RCELSAAL)
"""
mns.__doc__ = """MIN ADDR SPACE FRAMES - FROM ( RCEPOOL+RCEPRMCT-(RCAFC+RCE_Fr eemainedFrames)- RCEAFC-RCECOMAL-RCELSAAL)

SMF Info
--------
    Field: `SMF71MNS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN ADDR SPACE FRAMES - FROM ( RCEPOOL+RCEPRMCT-(RCAFC+RCE_Fr eemainedFrames)- RCEAFC-RCECOMAL-RCELSAAL)
"""

mxs : Final[Field] = Field(
    name='mxs',
    origin='SMF71MXS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX ADDR SPACE FRAMES

SMF Info
--------
    Field: `SMF71MXS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX ADDR SPACE FRAMES
"""
mxs.__doc__ = """MAX ADDR SPACE FRAMES

SMF Info
--------
    Field: `SMF71MXS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX ADDR SPACE FRAMES
"""

avs : Final[Field] = Field(
    name='avs',
    origin='SMF71AVS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG ADDR SPACE FRAMES

SMF Info
--------
    Field: `SMF71AVS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG ADDR SPACE FRAMES
"""
avs.__doc__ = """AVG ADDR SPACE FRAMES

SMF Info
--------
    Field: `SMF71AVS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG ADDR SPACE FRAMES
"""

mnt : Final[Field] = Field(
    name='mnt',
    origin='SMF71MNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Min total frames - from (RCEPOOL + RCEPRMCT) + FLPA/EFLPA frames + real frame zero

SMF Info
--------
    Field: `SMF71MNT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min total frames - from (RCEPOOL + RCEPRMCT) + FLPA/EFLPA frames + real frame zero
"""
mnt.__doc__ = """Min total frames - from (RCEPOOL + RCEPRMCT) + FLPA/EFLPA frames + real frame zero

SMF Info
--------
    Field: `SMF71MNT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min total frames - from (RCEPOOL + RCEPRMCT) + FLPA/EFLPA frames + real frame zero
"""

mxt : Final[Field] = Field(
    name='mxt',
    origin='SMF71MXT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX TOTAL FRAMES

SMF Info
--------
    Field: `SMF71MXT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX TOTAL FRAMES
"""
mxt.__doc__ = """MAX TOTAL FRAMES

SMF Info
--------
    Field: `SMF71MXT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX TOTAL FRAMES
"""

avt : Final[Field] = Field(
    name='avt',
    origin='SMF71AVT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG TOTAL FRAMES

SMF Info
--------
    Field: `SMF71AVT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG TOTAL FRAMES
"""
avt.__doc__ = """AVG TOTAL FRAMES

SMF Info
--------
    Field: `SMF71AVT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG TOTAL FRAMES
"""

mnq : Final[Field] = Field(
    name='mnq',
    origin='SMF71MNQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN SQA FIXED FRAMES - FROM RCESQAAL

SMF Info
--------
    Field: `SMF71MNQ`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN SQA FIXED FRAMES - FROM RCESQAAL
"""
mnq.__doc__ = """MIN SQA FIXED FRAMES - FROM RCESQAAL

SMF Info
--------
    Field: `SMF71MNQ`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN SQA FIXED FRAMES - FROM RCESQAAL
"""

mxq : Final[Field] = Field(
    name='mxq',
    origin='SMF71MXQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX SQA FIXED FRAMES

SMF Info
--------
    Field: `SMF71MXQ`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX SQA FIXED FRAMES
"""
mxq.__doc__ = """MAX SQA FIXED FRAMES

SMF Info
--------
    Field: `SMF71MXQ`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX SQA FIXED FRAMES
"""

avq : Final[Field] = Field(
    name='avq',
    origin='SMF71AVQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG SQA FIXED FRAMES

SMF Info
--------
    Field: `SMF71AVQ`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG SQA FIXED FRAMES
"""
avq.__doc__ = """AVG SQA FIXED FRAMES

SMF Info
--------
    Field: `SMF71AVQ`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG SQA FIXED FRAMES
"""

mnc : Final[Field] = Field(
    name='mnc',
    origin='SMF71MNC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN CSA FIXED FRAMES - FROM RCECOMFX-RCESQAAL), includes RUCSA

SMF Info
--------
    Field: `SMF71MNC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN CSA FIXED FRAMES - FROM RCECOMFX-RCESQAAL), includes RUCSA
"""
mnc.__doc__ = """MIN CSA FIXED FRAMES - FROM RCECOMFX-RCESQAAL), includes RUCSA

SMF Info
--------
    Field: `SMF71MNC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN CSA FIXED FRAMES - FROM RCECOMFX-RCESQAAL), includes RUCSA
"""

mxc : Final[Field] = Field(
    name='mxc',
    origin='SMF71MXC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX CSA FIXED FRAMES includes RUCSA

SMF Info
--------
    Field: `SMF71MXC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX CSA FIXED FRAMES includes RUCSA
"""
mxc.__doc__ = """MAX CSA FIXED FRAMES includes RUCSA

SMF Info
--------
    Field: `SMF71MXC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX CSA FIXED FRAMES includes RUCSA
"""

avc : Final[Field] = Field(
    name='avc',
    origin='SMF71AVC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG CSA FIXED FRAMES includes RUCSA

SMF Info
--------
    Field: `SMF71AVC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG CSA FIXED FRAMES includes RUCSA
"""
avc.__doc__ = """AVG CSA FIXED FRAMES includes RUCSA

SMF Info
--------
    Field: `SMF71AVC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG CSA FIXED FRAMES includes RUCSA
"""

mnr : Final[Field] = Field(
    name='mnr',
    origin='SMF71MNR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN ADDRESS SPACE FIXED FRAMES (WITHOUT LSQA) - FROM (RCETOTFX-(RCECOMFX+ RCELSAAL))

SMF Info
--------
    Field: `SMF71MNR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN ADDRESS SPACE FIXED FRAMES (WITHOUT LSQA) - FROM (RCETOTFX-(RCECOMFX+ RCELSAAL))
"""
mnr.__doc__ = """MIN ADDRESS SPACE FIXED FRAMES (WITHOUT LSQA) - FROM (RCETOTFX-(RCECOMFX+ RCELSAAL))

SMF Info
--------
    Field: `SMF71MNR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN ADDRESS SPACE FIXED FRAMES (WITHOUT LSQA) - FROM (RCETOTFX-(RCECOMFX+ RCELSAAL))
"""

mxr : Final[Field] = Field(
    name='mxr',
    origin='SMF71MXR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX ADDRESS SPACE FIXED FRAMES (W/O LSQA)

SMF Info
--------
    Field: `SMF71MXR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX ADDRESS SPACE FIXED FRAMES (W/O LSQA)
"""
mxr.__doc__ = """MAX ADDRESS SPACE FIXED FRAMES (W/O LSQA)

SMF Info
--------
    Field: `SMF71MXR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX ADDRESS SPACE FIXED FRAMES (W/O LSQA)
"""

avr : Final[Field] = Field(
    name='avr',
    origin='SMF71AVR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG ADDRESS SPACE FIXED FRAMES (W/O LSQA)

SMF Info
--------
    Field: `SMF71AVR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG ADDRESS SPACE FIXED FRAMES (W/O LSQA)
"""
avr.__doc__ = """AVG ADDRESS SPACE FIXED FRAMES (W/O LSQA)

SMF Info
--------
    Field: `SMF71AVR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG ADDRESS SPACE FIXED FRAMES (W/O LSQA)
"""

mnx : Final[Field] = Field(
    name='mnx',
    origin='SMF71MNX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Min total fixed frames - from (RCETOTFX) + FLPA/EFLPA frames

SMF Info
--------
    Field: `SMF71MNX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min total fixed frames - from (RCETOTFX) + FLPA/EFLPA frames
"""
mnx.__doc__ = """Min total fixed frames - from (RCETOTFX) + FLPA/EFLPA frames

SMF Info
--------
    Field: `SMF71MNX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min total fixed frames - from (RCETOTFX) + FLPA/EFLPA frames
"""

mxx : Final[Field] = Field(
    name='mxx',
    origin='SMF71MXX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX TOTAL FIXED FRAMES

SMF Info
--------
    Field: `SMF71MXX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX TOTAL FIXED FRAMES
"""
mxx.__doc__ = """MAX TOTAL FIXED FRAMES

SMF Info
--------
    Field: `SMF71MXX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX TOTAL FIXED FRAMES
"""

avx : Final[Field] = Field(
    name='avx',
    origin='SMF71AVX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG TOTAL FIXED FRAMES

SMF Info
--------
    Field: `SMF71AVX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG TOTAL FIXED FRAMES
"""
avx.__doc__ = """AVG TOTAL FIXED FRAMES

SMF Info
--------
    Field: `SMF71AVX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG TOTAL FIXED FRAMES
"""

mnu : Final[Field] = Field(
    name='mnu',
    origin='SMF71MNU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN AVAILABLE LOCAL PAGE DATASET SLOTS FROM (ASMSLOTS-( ASMVSC+ASMNVSC+ASMERRS))

SMF Info
--------
    Field: `SMF71MNU`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN AVAILABLE LOCAL PAGE DATASET SLOTS FROM (ASMSLOTS-( ASMVSC+ASMNVSC+ASMERRS))
"""
mnu.__doc__ = """MIN AVAILABLE LOCAL PAGE DATASET SLOTS FROM (ASMSLOTS-( ASMVSC+ASMNVSC+ASMERRS))

SMF Info
--------
    Field: `SMF71MNU`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN AVAILABLE LOCAL PAGE DATASET SLOTS FROM (ASMSLOTS-( ASMVSC+ASMNVSC+ASMERRS))
"""

mxu : Final[Field] = Field(
    name='mxu',
    origin='SMF71MXU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX AVAILABLE LOCAL PAGE DATASET SLOTS

SMF Info
--------
    Field: `SMF71MXU`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX AVAILABLE LOCAL PAGE DATASET SLOTS
"""
mxu.__doc__ = """MAX AVAILABLE LOCAL PAGE DATASET SLOTS

SMF Info
--------
    Field: `SMF71MXU`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX AVAILABLE LOCAL PAGE DATASET SLOTS
"""

avu : Final[Field] = Field(
    name='avu',
    origin='SMF71AVU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG AVAILABLE LOCAL PAGE DATASET SLOTS

SMF Info
--------
    Field: `SMF71AVU`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG AVAILABLE LOCAL PAGE DATASET SLOTS
"""
avu.__doc__ = """AVG AVAILABLE LOCAL PAGE DATASET SLOTS

SMF Info
--------
    Field: `SMF71AVU`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG AVAILABLE LOCAL PAGE DATASET SLOTS
"""

mnv : Final[Field] = Field(
    name='mnv',
    origin='SMF71MNV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES - FROM ASMVSC

SMF Info
--------
    Field: `SMF71MNV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES - FROM ASMVSC
"""
mnv.__doc__ = """MIN LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES - FROM ASMVSC

SMF Info
--------
    Field: `SMF71MNV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES - FROM ASMVSC
"""

mxv : Final[Field] = Field(
    name='mxv',
    origin='SMF71MXV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES

SMF Info
--------
    Field: `SMF71MXV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES
"""
mxv.__doc__ = """MAX LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES

SMF Info
--------
    Field: `SMF71MXV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES
"""

avv : Final[Field] = Field(
    name='avv',
    origin='SMF71AVV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES

SMF Info
--------
    Field: `SMF71AVV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES
"""
avv.__doc__ = """AVG LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES

SMF Info
--------
    Field: `SMF71AVV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LOCAL PAGE DATASET SLOTS ALLOCATED TO VIO PRIVATE AREA PAGES
"""

mnm : Final[Field] = Field(
    name='mnm',
    origin='SMF71MNM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN LOCAL PAGE DATA SET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES FROM ASMNVSC

SMF Info
--------
    Field: `SMF71MNM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN LOCAL PAGE DATA SET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES FROM ASMNVSC
"""
mnm.__doc__ = """MIN LOCAL PAGE DATA SET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES FROM ASMNVSC

SMF Info
--------
    Field: `SMF71MNM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN LOCAL PAGE DATA SET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES FROM ASMNVSC
"""

mxm : Final[Field] = Field(
    name='mxm',
    origin='SMF71MXM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX LOCAL PAGE DATASET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES

SMF Info
--------
    Field: `SMF71MXM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LOCAL PAGE DATASET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES
"""
mxm.__doc__ = """MAX LOCAL PAGE DATASET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES

SMF Info
--------
    Field: `SMF71MXM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LOCAL PAGE DATASET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES
"""

avm : Final[Field] = Field(
    name='avm',
    origin='SMF71AVM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG LOCAL PAGE DATASET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES

SMF Info
--------
    Field: `SMF71AVM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LOCAL PAGE DATASET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES
"""
avm.__doc__ = """AVG LOCAL PAGE DATASET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES

SMF Info
--------
    Field: `SMF71AVM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LOCAL PAGE DATASET SLOTS ALLOCATED TO NON VIO PRIVATE AREA PAGES
"""

mnb : Final[Field] = Field(
    name='mnb',
    origin='SMF71MNB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN UNAVAILABLE(BAD) LOCAL PAGE DATASET FROM ASMERRS

SMF Info
--------
    Field: `SMF71MNB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN UNAVAILABLE(BAD) LOCAL PAGE DATASET FROM ASMERRS
"""
mnb.__doc__ = """MIN UNAVAILABLE(BAD) LOCAL PAGE DATASET FROM ASMERRS

SMF Info
--------
    Field: `SMF71MNB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN UNAVAILABLE(BAD) LOCAL PAGE DATASET FROM ASMERRS
"""

mxb : Final[Field] = Field(
    name='mxb',
    origin='SMF71MXB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX UNAVAILABLE(BAD) LOCAL PAGE DATA SET

SMF Info
--------
    Field: `SMF71MXB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX UNAVAILABLE(BAD) LOCAL PAGE DATA SET
"""
mxb.__doc__ = """MAX UNAVAILABLE(BAD) LOCAL PAGE DATA SET

SMF Info
--------
    Field: `SMF71MXB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX UNAVAILABLE(BAD) LOCAL PAGE DATA SET
"""

avb : Final[Field] = Field(
    name='avb',
    origin='SMF71AVB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG UNAVAILABLE(BAD) LOCAL PAGE DATA SET

SMF Info
--------
    Field: `SMF71AVB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG UNAVAILABLE(BAD) LOCAL PAGE DATA SET
"""
avb.__doc__ = """AVG UNAVAILABLE(BAD) LOCAL PAGE DATA SET

SMF Info
--------
    Field: `SMF71AVB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG UNAVAILABLE(BAD) LOCAL PAGE DATA SET
"""

mna : Final[Field] = Field(
    name='mna',
    origin='SMF71MNA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN TOTAL LOCAL PAGE DATASET SLOTS FROM ASMSLOTS

SMF Info
--------
    Field: `SMF71MNA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN TOTAL LOCAL PAGE DATASET SLOTS FROM ASMSLOTS
"""
mna.__doc__ = """MIN TOTAL LOCAL PAGE DATASET SLOTS FROM ASMSLOTS

SMF Info
--------
    Field: `SMF71MNA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN TOTAL LOCAL PAGE DATASET SLOTS FROM ASMSLOTS
"""

mxa : Final[Field] = Field(
    name='mxa',
    origin='SMF71MXA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX TOTAL LOCAL PAGE DATASET SLOTS

SMF Info
--------
    Field: `SMF71MXA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX TOTAL LOCAL PAGE DATASET SLOTS
"""
mxa.__doc__ = """MAX TOTAL LOCAL PAGE DATASET SLOTS

SMF Info
--------
    Field: `SMF71MXA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX TOTAL LOCAL PAGE DATASET SLOTS
"""

is1 : Final[Field] = Field(
    name='is1',
    origin='SMF71IS1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""INVALID SAMPLES TO BE SKIPPED BECAUSE THERE WERE ERRORS AT THE RSM FIXED FRAMES COUNTING INTERFACE (IARXCNTF)

SMF Info
--------
    Field: `SMF71IS1`
    Record: `SMF71S1`
    Map: `SMF71PAG`

INVALID SAMPLES TO BE SKIPPED BECAUSE THERE WERE ERRORS AT THE RSM FIXED FRAMES COUNTING INTERFACE (IARXCNTF)
"""
is1.__doc__ = """INVALID SAMPLES TO BE SKIPPED BECAUSE THERE WERE ERRORS AT THE RSM FIXED FRAMES COUNTING INTERFACE (IARXCNTF)

SMF Info
--------
    Field: `SMF71IS1`
    Record: `SMF71S1`
    Map: `SMF71PAG`

INVALID SAMPLES TO BE SKIPPED BECAUSE THERE WERE ERRORS AT THE RSM FIXED FRAMES COUNTING INTERFACE (IARXCNTF)
"""

is2 : Final[Field] = Field(
    name='is2',
    origin='SMF71IS2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""INVALID SAMPLES TO BE SKIPPED BECAUSE THERE WHERE NEGATIVE VALUES AT THE CALCULATION OF THE FIXED CSA FRAMES COUNT

SMF Info
--------
    Field: `SMF71IS2`
    Record: `SMF71S1`
    Map: `SMF71PAG`

INVALID SAMPLES TO BE SKIPPED BECAUSE THERE WHERE NEGATIVE VALUES AT THE CALCULATION OF THE FIXED CSA FRAMES COUNT
"""
is2.__doc__ = """INVALID SAMPLES TO BE SKIPPED BECAUSE THERE WHERE NEGATIVE VALUES AT THE CALCULATION OF THE FIXED CSA FRAMES COUNT

SMF Info
--------
    Field: `SMF71IS2`
    Record: `SMF71S1`
    Map: `SMF71PAG`

INVALID SAMPLES TO BE SKIPPED BECAUSE THERE WHERE NEGATIVE VALUES AT THE CALCULATION OF THE FIXED CSA FRAMES COUNT
"""

nlp : Final[Field] = Field(
    name='nlp',
    origin='SMF71NLP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Min LPA frames - from (CTLPAF) + FLPA/EFLPA frames

SMF Info
--------
    Field: `SMF71NLP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min LPA frames - from (CTLPAF) + FLPA/EFLPA frames
"""
nlp.__doc__ = """Min LPA frames - from (CTLPAF) + FLPA/EFLPA frames

SMF Info
--------
    Field: `SMF71NLP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min LPA frames - from (CTLPAF) + FLPA/EFLPA frames
"""

xlp : Final[Field] = Field(
    name='xlp',
    origin='SMF71XLP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX LPA FRAMES

SMF Info
--------
    Field: `SMF71XLP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LPA FRAMES
"""
xlp.__doc__ = """MAX LPA FRAMES

SMF Info
--------
    Field: `SMF71XLP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LPA FRAMES
"""

alp : Final[Field] = Field(
    name='alp',
    origin='SMF71ALP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG LPA FRAMES

SMF Info
--------
    Field: `SMF71ALP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LPA FRAMES
"""
alp.__doc__ = """AVG LPA FRAMES

SMF Info
--------
    Field: `SMF71ALP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LPA FRAMES
"""

nlf : Final[Field] = Field(
    name='nlf',
    origin='SMF71NLF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Min LPA fixed frames - from (CTFLPAF) + FLPA/EFLPA frames

SMF Info
--------
    Field: `SMF71NLF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min LPA fixed frames - from (CTFLPAF) + FLPA/EFLPA frames
"""
nlf.__doc__ = """Min LPA fixed frames - from (CTFLPAF) + FLPA/EFLPA frames

SMF Info
--------
    Field: `SMF71NLF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min LPA fixed frames - from (CTFLPAF) + FLPA/EFLPA frames
"""

xlf : Final[Field] = Field(
    name='xlf',
    origin='SMF71XLF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX LPA FIXED FRAMES

SMF Info
--------
    Field: `SMF71XLF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LPA FIXED FRAMES
"""
xlf.__doc__ = """MAX LPA FIXED FRAMES

SMF Info
--------
    Field: `SMF71XLF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LPA FIXED FRAMES
"""

alf : Final[Field] = Field(
    name='alf',
    origin='SMF71ALF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG LPA FIXED FRAMES

SMF Info
--------
    Field: `SMF71ALF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LPA FIXED FRAMES
"""
alf.__doc__ = """AVG LPA FIXED FRAMES

SMF Info
--------
    Field: `SMF71ALF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LPA FIXED FRAMES
"""

nls : Final[Field] = Field(
    name='nls',
    origin='SMF71NLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN LSQA FIXED FRAMES FROM RCELSAAL

SMF Info
--------
    Field: `SMF71NLS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN LSQA FIXED FRAMES FROM RCELSAAL
"""
nls.__doc__ = """MIN LSQA FIXED FRAMES FROM RCELSAAL

SMF Info
--------
    Field: `SMF71NLS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN LSQA FIXED FRAMES FROM RCELSAAL
"""

xls : Final[Field] = Field(
    name='xls',
    origin='SMF71XLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX LSQA FIXED FRAMES

SMF Info
--------
    Field: `SMF71XLS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LSQA FIXED FRAMES
"""
xls.__doc__ = """MAX LSQA FIXED FRAMES

SMF Info
--------
    Field: `SMF71XLS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX LSQA FIXED FRAMES
"""

als : Final[Field] = Field(
    name='als',
    origin='SMF71ALS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG LSQA FIXED FRAMES

SMF Info
--------
    Field: `SMF71ALS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LSQA FIXED FRAMES
"""
als.__doc__ = """AVG LSQA FIXED FRAMES

SMF Info
--------
    Field: `SMF71ALS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG LSQA FIXED FRAMES
"""

mnl : Final[Field] = Field(
    name='mnl',
    origin='SMF71MNL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of fixed frames below 16 MEG. - from (RCEBELFX) + FLPA frames

SMF Info
--------
    Field: `SMF71MNL`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed frames below 16 MEG. - from (RCEBELFX) + FLPA frames
"""
mnl.__doc__ = """Minimum number of fixed frames below 16 MEG. - from (RCEBELFX) + FLPA frames

SMF Info
--------
    Field: `SMF71MNL`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed frames below 16 MEG. - from (RCEBELFX) + FLPA frames
"""

mxl : Final[Field] = Field(
    name='mxl',
    origin='SMF71MXL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAXIMUM NUMBER OF FIXED FRAMES BELOW 16 MEG.

SMF Info
--------
    Field: `SMF71MXL`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAXIMUM NUMBER OF FIXED FRAMES BELOW 16 MEG.
"""
mxl.__doc__ = """MAXIMUM NUMBER OF FIXED FRAMES BELOW 16 MEG.

SMF Info
--------
    Field: `SMF71MXL`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAXIMUM NUMBER OF FIXED FRAMES BELOW 16 MEG.
"""

avl : Final[Field] = Field(
    name='avl',
    origin='SMF71AVL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVERAGE NUMBER OF FIXED FRAMES BELOW 16 MEG.

SMF Info
--------
    Field: `SMF71AVL`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVERAGE NUMBER OF FIXED FRAMES BELOW 16 MEG.
"""
avl.__doc__ = """AVERAGE NUMBER OF FIXED FRAMES BELOW 16 MEG.

SMF Info
--------
    Field: `SMF71AVL`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVERAGE NUMBER OF FIXED FRAMES BELOW 16 MEG.
"""

pmv : Final[Field] = Field(
    name='pmv',
    origin='SMF71PMV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""TOTAL PAGE MOVES - FROM (RCEPAGMV)

SMF Info
--------
    Field: `SMF71PMV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

TOTAL PAGE MOVES - FROM (RCEPAGMV)
"""
pmv.__doc__ = """TOTAL PAGE MOVES - FROM (RCEPAGMV)

SMF Info
--------
    Field: `SMF71PMV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

TOTAL PAGE MOVES - FROM (RCEPAGMV)
"""

opt : Final[Field] = Field(
    name='opt',
    origin='SMF71OPT',
    type=FieldType.STRING,
    record=record,
    record_map=SMF71PAG,
)
"""SRM OPT MEMBER NAME - FROM RMPTOPTN

SMF Info
--------
    Field: `SMF71OPT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SRM OPT MEMBER NAME - FROM RMPTOPTN
"""
opt.__doc__ = """SRM OPT MEMBER NAME - FROM RMPTOPTN

SMF Info
--------
    Field: `SMF71OPT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

SRM OPT MEMBER NAME - FROM RMPTOPTN
"""

lic : Final[Field] = Field(
    name='lic',
    origin='SMF71LIC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MIN HIGH UIC - FROM MCVSTCRI

SMF Info
--------
    Field: `SMF71LIC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN HIGH UIC - FROM MCVSTCRI
"""
lic.__doc__ = """MIN HIGH UIC - FROM MCVSTCRI

SMF Info
--------
    Field: `SMF71LIC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MIN HIGH UIC - FROM MCVSTCRI
"""

hic : Final[Field] = Field(
    name='hic',
    origin='SMF71HIC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""MAX HIGH UIC - FROM MCVSTCRI

SMF Info
--------
    Field: `SMF71HIC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX HIGH UIC - FROM MCVSTCRI
"""
hic.__doc__ = """MAX HIGH UIC - FROM MCVSTCRI

SMF Info
--------
    Field: `SMF71HIC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

MAX HIGH UIC - FROM MCVSTCRI
"""

aca : Final[Field] = Field(
    name='aca',
    origin='SMF71ACA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""AVG HIGH UIC - FROM MCVSTCRI - SCALE FACTOR IS -1

SMF Info
--------
    Field: `SMF71ACA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG HIGH UIC - FROM MCVSTCRI - SCALE FACTOR IS -1
"""
aca.__doc__ = """AVG HIGH UIC - FROM MCVSTCRI - SCALE FACTOR IS -1

SMF Info
--------
    Field: `SMF71ACA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

AVG HIGH UIC - FROM MCVSTCRI - SCALE FACTOR IS -1
"""

msr : Final[Field] = Field(
    name='msr',
    origin='SMF71MSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""min SQA pages in central storage CTSQAF + CTRSQAF

SMF Info
--------
    Field: `SMF71MSR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

min SQA pages in central storage CTSQAF + CTRSQAF
"""
msr.__doc__ = """min SQA pages in central storage CTSQAF + CTRSQAF

SMF Info
--------
    Field: `SMF71MSR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

min SQA pages in central storage CTSQAF + CTRSQAF
"""

xsr : Final[Field] = Field(
    name='xsr',
    origin='SMF71XSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""max SQA pages in central storage

SMF Info
--------
    Field: `SMF71XSR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

max SQA pages in central storage
"""
xsr.__doc__ = """max SQA pages in central storage

SMF Info
--------
    Field: `SMF71XSR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

max SQA pages in central storage
"""

asr : Final[Field] = Field(
    name='asr',
    origin='SMF71ASR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""avg SQA pages in central storage

SMF Info
--------
    Field: `SMF71ASR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

avg SQA pages in central storage
"""
asr.__doc__ = """avg SQA pages in central storage

SMF Info
--------
    Field: `SMF71ASR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

avg SQA pages in central storage
"""

mlr : Final[Field] = Field(
    name='mlr',
    origin='SMF71MLR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""min LSQA pages in central storage CTLSQAF + CTRLSQAF

SMF Info
--------
    Field: `SMF71MLR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

min LSQA pages in central storage CTLSQAF + CTRLSQAF
"""
mlr.__doc__ = """min LSQA pages in central storage CTLSQAF + CTRLSQAF

SMF Info
--------
    Field: `SMF71MLR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

min LSQA pages in central storage CTLSQAF + CTRLSQAF
"""

xlr : Final[Field] = Field(
    name='xlr',
    origin='SMF71XLR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""max LSQA pages in central storage

SMF Info
--------
    Field: `SMF71XLR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

max LSQA pages in central storage
"""
xlr.__doc__ = """max LSQA pages in central storage

SMF Info
--------
    Field: `SMF71XLR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

max LSQA pages in central storage
"""

alr : Final[Field] = Field(
    name='alr',
    origin='SMF71ALR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""avg LSQA pages in central storage

SMF Info
--------
    Field: `SMF71ALR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

avg LSQA pages in central storage
"""
alr.__doc__ = """avg LSQA pages in central storage

SMF Info
--------
    Field: `SMF71ALR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

avg LSQA pages in central storage
"""

isc : Final[Field] = Field(
    name='isc',
    origin='SMF71ISC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""no of invalid samples returned from RMF collector service

SMF Info
--------
    Field: `SMF71ISC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

no of invalid samples returned from RMF collector service
"""
isc.__doc__ = """no of invalid samples returned from RMF collector service

SMF Info
--------
    Field: `SMF71ISC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

no of invalid samples returned from RMF collector service
"""

hot : Final[Field] = Field(
    name='hot',
    origin='SMF71HOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of hiperspace page-outs

SMF Info
--------
    Field: `SMF71HOT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of hiperspace page-outs
"""
hot.__doc__ = """Number of hiperspace page-outs

SMF Info
--------
    Field: `SMF71HOT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of hiperspace page-outs
"""

hin : Final[Field] = Field(
    name='hin',
    origin='SMF71HIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of hiperspace page-ins

SMF Info
--------
    Field: `SMF71HIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of hiperspace page-ins
"""
hin.__doc__ = """Number of hiperspace page-ins

SMF Info
--------
    Field: `SMF71HIN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of hiperspace page-ins
"""

blp : Final[Field] = Field(
    name='blp',
    origin='SMF71BLP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of blocked pages paged in, does not include VIO or hiperspace

SMF Info
--------
    Field: `SMF71BLP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of blocked pages paged in, does not include VIO or hiperspace
"""
blp.__doc__ = """Number of blocked pages paged in, does not include VIO or hiperspace

SMF Info
--------
    Field: `SMF71BLP`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of blocked pages paged in, does not include VIO or hiperspace
"""

blk : Final[Field] = Field(
    name='blk',
    origin='SMF71BLK',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of blocks paged in

SMF Info
--------
    Field: `SMF71BLK`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of blocks paged in
"""
blk.__doc__ = """Number of blocks paged in

SMF Info
--------
    Field: `SMF71BLK`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of blocks paged in
"""

pmt : Final[Field] = Field(
    name='pmt',
    origin='SMF71PMT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF71PAG,
)
"""Steal Timer - elapsed time spent in a preferred steal in CPU Timer units

SMF Info
--------
    Field: `SMF71PMT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Steal Timer - elapsed time spent in a preferred steal in CPU Timer units
"""
pmt.__doc__ = """Steal Timer - elapsed time spent in a preferred steal in CPU Timer units

SMF Info
--------
    Field: `SMF71PMT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Steal Timer - elapsed time spent in a preferred steal in CPU Timer units
"""

sbi : Final[Field] = Field(
    name='sbi',
    origin='SMF71SBI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""System Pageable Areas Block Page-Ins

SMF Info
--------
    Field: `SMF71SBI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

System Pageable Areas Block Page-Ins
"""
sbi.__doc__ = """System Pageable Areas Block Page-Ins

SMF Info
--------
    Field: `SMF71SBI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

System Pageable Areas Block Page-Ins
"""

lbi : Final[Field] = Field(
    name='lbi',
    origin='SMF71LBI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""LPA Block Page-Ins

SMF Info
--------
    Field: `SMF71LBI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

LPA Block Page-Ins
"""
lbi.__doc__ = """LPA Block Page-Ins

SMF Info
--------
    Field: `SMF71LBI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

LPA Block Page-Ins
"""

asi : Final[Field] = Field(
    name='asi',
    origin='SMF71ASI',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Number of page-ins from auxiliary storage for shared pages (long floating point)

SMF Info
--------
    Field: `SMF71ASI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of page-ins from auxiliary storage for shared pages (long floating point)
"""
asi.__doc__ = """Number of page-ins from auxiliary storage for shared pages (long floating point)

SMF Info
--------
    Field: `SMF71ASI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of page-ins from auxiliary storage for shared pages (long floating point)
"""

aso : Final[Field] = Field(
    name='aso',
    origin='SMF71ASO',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Number of page-outs to auxiliary storage for shared pages (long floating point)

SMF Info
--------
    Field: `SMF71ASO`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of page-outs to auxiliary storage for shared pages (long floating point)
"""
aso.__doc__ = """Number of page-outs to auxiliary storage for shared pages (long floating point)

SMF Info
--------
    Field: `SMF71ASO`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of page-outs to auxiliary storage for shared pages (long floating point)
"""

mgt : Final[Field] = Field(
    name='mgt',
    origin='SMF71MGT',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of shared pages in the system (long floating point)

SMF Info
--------
    Field: `SMF71MGT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared pages in the system (long floating point)
"""
mgt.__doc__ = """Minimum number of shared pages in the system (long floating point)

SMF Info
--------
    Field: `SMF71MGT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared pages in the system (long floating point)
"""

xgt : Final[Field] = Field(
    name='xgt',
    origin='SMF71XGT',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of shared pages in the system (long floating point)

SMF Info
--------
    Field: `SMF71XGT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared pages in the system (long floating point)
"""
xgt.__doc__ = """Maximum number of shared pages in the system (long floating point)

SMF Info
--------
    Field: `SMF71XGT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared pages in the system (long floating point)
"""

agt : Final[Field] = Field(
    name='agt',
    origin='SMF71AGT',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of shared pages in the system (long floating point)

SMF Info
--------
    Field: `SMF71AGT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages in the system (long floating point)
"""
agt.__doc__ = """Average number of shared pages in the system (long floating point)

SMF Info
--------
    Field: `SMF71AGT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages in the system (long floating point)
"""

mgc : Final[Field] = Field(
    name='mgc',
    origin='SMF71MGC',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of shared pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71MGC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared pages in central storage (long floating point)
"""
mgc.__doc__ = """Minimum number of shared pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71MGC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared pages in central storage (long floating point)
"""

xgc : Final[Field] = Field(
    name='xgc',
    origin='SMF71XGC',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of shared pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71XGC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared pages in central storage (long floating point)
"""
xgc.__doc__ = """Maximum number of shared pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71XGC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared pages in central storage (long floating point)
"""

agc : Final[Field] = Field(
    name='agc',
    origin='SMF71AGC',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of shared pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71AGC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages in central storage (long floating point)
"""
agc.__doc__ = """Average number of shared pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71AGC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages in central storage (long floating point)
"""

mga : Final[Field] = Field(
    name='mga',
    origin='SMF71MGA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of auxiliary slots in use for shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71MGA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of auxiliary slots in use for shared page groups (long floating point)
"""
mga.__doc__ = """Minimum number of auxiliary slots in use for shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71MGA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of auxiliary slots in use for shared page groups (long floating point)
"""

xga : Final[Field] = Field(
    name='xga',
    origin='SMF71XGA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of auxiliary slots in use for shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71XGA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of auxiliary slots in use for shared page groups (long floating point)
"""
xga.__doc__ = """Maximum number of auxiliary slots in use for shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71XGA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of auxiliary slots in use for shared page groups (long floating point)
"""

aga : Final[Field] = Field(
    name='aga',
    origin='SMF71AGA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of auxiliary slots in use for shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71AGA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of auxiliary slots in use for shared page groups (long floating point)
"""
aga.__doc__ = """Average number of auxiliary slots in use for shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71AGA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of auxiliary slots in use for shared page groups (long floating point)
"""

mgf : Final[Field] = Field(
    name='mgf',
    origin='SMF71MGF',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of shared pages fixed in the system (long floating point)

SMF Info
--------
    Field: `SMF71MGF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared pages fixed in the system (long floating point)
"""
mgf.__doc__ = """Minimum number of shared pages fixed in the system (long floating point)

SMF Info
--------
    Field: `SMF71MGF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared pages fixed in the system (long floating point)
"""

xgf : Final[Field] = Field(
    name='xgf',
    origin='SMF71XGF',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of shared pages fixed in the system (long floating point)

SMF Info
--------
    Field: `SMF71XGF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared pages fixed in the system (long floating point)
"""
xgf.__doc__ = """Maximum number of shared pages fixed in the system (long floating point)

SMF Info
--------
    Field: `SMF71XGF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared pages fixed in the system (long floating point)
"""

agf : Final[Field] = Field(
    name='agf',
    origin='SMF71AGF',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of shared pages fixed in the system (long floating point)

SMF Info
--------
    Field: `SMF71AGF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages fixed in the system (long floating point)
"""
agf.__doc__ = """Average number of shared pages fixed in the system (long floating point)

SMF Info
--------
    Field: `SMF71AGF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages fixed in the system (long floating point)
"""

mgb : Final[Field] = Field(
    name='mgb',
    origin='SMF71MGB',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of shared pages fixed below 16MB in the system (long floating point)

SMF Info
--------
    Field: `SMF71MGB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared pages fixed below 16MB in the system (long floating point)
"""
mgb.__doc__ = """Minimum number of shared pages fixed below 16MB in the system (long floating point)

SMF Info
--------
    Field: `SMF71MGB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared pages fixed below 16MB in the system (long floating point)
"""

xgb : Final[Field] = Field(
    name='xgb',
    origin='SMF71XGB',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of shared pages fixed below 16MB in the system (long floating point)

SMF Info
--------
    Field: `SMF71XGB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared pages fixed below 16MB in the system (long floating point)
"""
xgb.__doc__ = """Maximum number of shared pages fixed below 16MB in the system (long floating point)

SMF Info
--------
    Field: `SMF71XGB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared pages fixed below 16MB in the system (long floating point)
"""

agb : Final[Field] = Field(
    name='agb',
    origin='SMF71AGB',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of shared pages fixed below 16MB in the system (long floating point)

SMF Info
--------
    Field: `SMF71AGB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages fixed below 16MB in the system (long floating point)
"""
agb.__doc__ = """Average number of shared pages fixed below 16MB in the system (long floating point)

SMF Info
--------
    Field: `SMF71AGB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages fixed below 16MB in the system (long floating point)
"""

cam : Final[Field] = Field(
    name='cam',
    origin='SMF71CAM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of available central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CAM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of available central storage frames (long floating point)
"""
cam.__doc__ = """Minimum number of available central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CAM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of available central storage frames (long floating point)
"""

cax : Final[Field] = Field(
    name='cax',
    origin='SMF71CAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of available central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CAX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of available central storage frames (long floating point)
"""
cax.__doc__ = """Maximum number of available central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CAX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of available central storage frames (long floating point)
"""

caa : Final[Field] = Field(
    name='caa',
    origin='SMF71CAA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of available central storage frames (rceafc+rce_freemainedframes max(rceafcok,mccafcok*mccdefam )) (long floating point)

SMF Info
--------
    Field: `SMF71CAA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of available central storage frames (rceafc+rce_freemainedframes max(rceafcok,mccafcok*mccdefam )) (long floating point)
"""
caa.__doc__ = """Average number of available central storage frames (rceafc+rce_freemainedframes max(rceafcok,mccafcok*mccdefam )) (long floating point)

SMF Info
--------
    Field: `SMF71CAA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of available central storage frames (rceafc+rce_freemainedframes max(rceafcok,mccafcok*mccdefam )) (long floating point)
"""

clm : Final[Field] = Field(
    name='clm',
    origin='SMF71CLM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of low impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CLM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of low impact central storage frames (long floating point)
"""
clm.__doc__ = """Minimum number of low impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CLM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of low impact central storage frames (long floating point)
"""

clx : Final[Field] = Field(
    name='clx',
    origin='SMF71CLX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of low impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CLX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of low impact central storage frames (long floating point)
"""
clx.__doc__ = """Maximum number of low impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CLX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of low impact central storage frames (long floating point)
"""

cla : Final[Field] = Field(
    name='cla',
    origin='SMF71CLA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of low impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CLA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of low impact central storage frames (long floating point)
"""
cla.__doc__ = """Average number of low impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CLA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of low impact central storage frames (long floating point)
"""

cmm : Final[Field] = Field(
    name='cmm',
    origin='SMF71CMM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of medium impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CMM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of medium impact central storage frames (long floating point)
"""
cmm.__doc__ = """Minimum number of medium impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CMM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of medium impact central storage frames (long floating point)
"""

cmx : Final[Field] = Field(
    name='cmx',
    origin='SMF71CMX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of medium impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CMX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of medium impact central storage frames (long floating point)
"""
cmx.__doc__ = """Maximum number of medium impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CMX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of medium impact central storage frames (long floating point)
"""

cma : Final[Field] = Field(
    name='cma',
    origin='SMF71CMA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of medium impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CMA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of medium impact central storage frames (long floating point)
"""
cma.__doc__ = """Average number of medium impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CMA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of medium impact central storage frames (long floating point)
"""

chm : Final[Field] = Field(
    name='chm',
    origin='SMF71CHM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of high impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CHM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high impact central storage frames (long floating point)
"""
chm.__doc__ = """Minimum number of high impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CHM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high impact central storage frames (long floating point)
"""

chx : Final[Field] = Field(
    name='chx',
    origin='SMF71CHX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of high impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CHX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high impact central storage frames (long floating point)
"""
chx.__doc__ = """Maximum number of high impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CHX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high impact central storage frames (long floating point)
"""

cha : Final[Field] = Field(
    name='cha',
    origin='SMF71CHA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of high impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CHA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high impact central storage frames (long floating point)
"""
cha.__doc__ = """Average number of high impact central storage frames (long floating point)

SMF Info
--------
    Field: `SMF71CHA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high impact central storage frames (long floating point)
"""

mvi : Final[Field] = Field(
    name='mvi',
    origin='SMF71MVI',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Min. number of VIO pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71MVI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min. number of VIO pages in central storage (long floating point)
"""
mvi.__doc__ = """Min. number of VIO pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71MVI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min. number of VIO pages in central storage (long floating point)
"""

xvi : Final[Field] = Field(
    name='xvi',
    origin='SMF71XVI',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Max. number of VIO pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71XVI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Max. number of VIO pages in central storage (long floating point)
"""
xvi.__doc__ = """Max. number of VIO pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71XVI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Max. number of VIO pages in central storage (long floating point)
"""

avi : Final[Field] = Field(
    name='avi',
    origin='SMF71AVI',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Avg. number of VIO pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71AVI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Avg. number of VIO pages in central storage (long floating point)
"""
avi.__doc__ = """Avg. number of VIO pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71AVI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Avg. number of VIO pages in central storage (long floating point)
"""

mhi : Final[Field] = Field(
    name='mhi',
    origin='SMF71MHI',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Min. number of hiperspace pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71MHI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min. number of hiperspace pages in central storage (long floating point)
"""
mhi.__doc__ = """Min. number of hiperspace pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71MHI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min. number of hiperspace pages in central storage (long floating point)
"""

xhi : Final[Field] = Field(
    name='xhi',
    origin='SMF71XHI',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Max. number of hiperspace pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71XHI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Max. number of hiperspace pages in central storage (long floating point)
"""
xhi.__doc__ = """Max. number of hiperspace pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71XHI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Max. number of hiperspace pages in central storage (long floating point)
"""

ahi : Final[Field] = Field(
    name='ahi',
    origin='SMF71AHI',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Avg. number of hiperspace pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71AHI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Avg. number of hiperspace pages in central storage (long floating point)
"""
ahi.__doc__ = """Avg. number of hiperspace pages in central storage (long floating point)

SMF Info
--------
    Field: `SMF71AHI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Avg. number of hiperspace pages in central storage (long floating point)
"""

vws : Final[Field] = Field(
    name='vws',
    origin='SMF71VWS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Number of VIO pages written to central storage (long floating point)

SMF Info
--------
    Field: `SMF71VWS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of VIO pages written to central storage (long floating point)
"""
vws.__doc__ = """Number of VIO pages written to central storage (long floating point)

SMF Info
--------
    Field: `SMF71VWS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of VIO pages written to central storage (long floating point)
"""

vrs : Final[Field] = Field(
    name='vrs',
    origin='SMF71VRS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Number of VIO pages read from central storage (long floating point)

SMF Info
--------
    Field: `SMF71VRS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of VIO pages read from central storage (long floating point)
"""
vrs.__doc__ = """Number of VIO pages read from central storage (long floating point)

SMF Info
--------
    Field: `SMF71VRS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of VIO pages read from central storage (long floating point)
"""

hws : Final[Field] = Field(
    name='hws',
    origin='SMF71HWS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Number of hipersp. pages written to central storage (long floating point)

SMF Info
--------
    Field: `SMF71HWS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of hipersp. pages written to central storage (long floating point)
"""
hws.__doc__ = """Number of hipersp. pages written to central storage (long floating point)

SMF Info
--------
    Field: `SMF71HWS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of hipersp. pages written to central storage (long floating point)
"""

hrs : Final[Field] = Field(
    name='hrs',
    origin='SMF71HRS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Number of hipersp. pages read from central storage (long floating point)

SMF Info
--------
    Field: `SMF71HRS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of hipersp. pages read from central storage (long floating point)
"""
hrs.__doc__ = """Number of hipersp. pages read from central storage (long floating point)

SMF Info
--------
    Field: `SMF71HRS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of hipersp. pages read from central storage (long floating point)
"""

mfb : Final[Field] = Field(
    name='mfb',
    origin='SMF71MFB',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Min number of pages fixed between 16M and 2G (long floating point)

SMF Info
--------
    Field: `SMF71MFB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min number of pages fixed between 16M and 2G (long floating point)
"""
mfb.__doc__ = """Min number of pages fixed between 16M and 2G (long floating point)

SMF Info
--------
    Field: `SMF71MFB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Min number of pages fixed between 16M and 2G (long floating point)
"""

xfb : Final[Field] = Field(
    name='xfb',
    origin='SMF71XFB',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Max number of pages fixed between 16M and 2G (long floating point)

SMF Info
--------
    Field: `SMF71XFB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Max number of pages fixed between 16M and 2G (long floating point)
"""
xfb.__doc__ = """Max number of pages fixed between 16M and 2G (long floating point)

SMF Info
--------
    Field: `SMF71XFB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Max number of pages fixed between 16M and 2G (long floating point)
"""

afb : Final[Field] = Field(
    name='afb',
    origin='SMF71AFB',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Avg number of pages fixed between 16M and 2G (long floating point)

SMF Info
--------
    Field: `SMF71AFB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Avg number of pages fixed between 16M and 2G (long floating point)
"""
afb.__doc__ = """Avg number of pages fixed between 16M and 2G (long floating point)

SMF Info
--------
    Field: `SMF71AFB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Avg number of pages fixed between 16M and 2G (long floating point)
"""

pth : Final[Field] = Field(
    name='pth',
    origin='SMF71PTH',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of pages in the system used by shared memory objects (long floating point)

SMF Info
--------
    Field: `SMF71PTH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of pages in the system used by shared memory objects (long floating point)
"""
pth.__doc__ = """Average number of pages in the system used by shared memory objects (long floating point)

SMF Info
--------
    Field: `SMF71PTH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of pages in the system used by shared memory objects (long floating point)
"""

pch : Final[Field] = Field(
    name='pch',
    origin='SMF71PCH',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of shared pages in central storage -virt. storage addr above the bar including high virtual DAT (long floating point)

SMF Info
--------
    Field: `SMF71PCH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages in central storage -virt. storage addr above the bar including high virtual DAT (long floating point)
"""
pch.__doc__ = """Average number of shared pages in central storage -virt. storage addr above the bar including high virtual DAT (long floating point)

SMF Info
--------
    Field: `SMF71PCH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages in central storage -virt. storage addr above the bar including high virtual DAT (long floating point)
"""

pah : Final[Field] = Field(
    name='pah',
    origin='SMF71PAH',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of shared pages in auxiliary storage -virt. storage addr above the bar (long floating point)

SMF Info
--------
    Field: `SMF71PAH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages in auxiliary storage -virt. storage addr above the bar (long floating point)
"""
pah.__doc__ = """Average number of shared pages in auxiliary storage -virt. storage addr above the bar (long floating point)

SMF Info
--------
    Field: `SMF71PAH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared pages in auxiliary storage -virt. storage addr above the bar (long floating point)
"""

blg : Final[Field] = Field(
    name='blg',
    origin='SMF71BLG',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""High water mark for number of shared bytes from large virtual memory in memory object (long floating point)

SMF Info
--------
    Field: `SMF71BLG`
    Record: `SMF71S1`
    Map: `SMF71PAG`

High water mark for number of shared bytes from large virtual memory in memory object (long floating point)
"""
blg.__doc__ = """High water mark for number of shared bytes from large virtual memory in memory object (long floating point)

SMF Info
--------
    Field: `SMF71BLG`
    Record: `SMF71S1`
    Map: `SMF71PAG`

High water mark for number of shared bytes from large virtual memory in memory object (long floating point)
"""

pih : Final[Field] = Field(
    name='pih',
    origin='SMF71PIH',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Number of page-ins from auxiliary storage for shared pages with virtual storage address above the bar (long floating point)

SMF Info
--------
    Field: `SMF71PIH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of page-ins from auxiliary storage for shared pages with virtual storage address above the bar (long floating point)
"""
pih.__doc__ = """Number of page-ins from auxiliary storage for shared pages with virtual storage address above the bar (long floating point)

SMF Info
--------
    Field: `SMF71PIH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of page-ins from auxiliary storage for shared pages with virtual storage address above the bar (long floating point)
"""

poh : Final[Field] = Field(
    name='poh',
    origin='SMF71POH',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Number of page-outs to auxiliary storage for shared pages with virtual storage address above the bar (long floating point)

SMF Info
--------
    Field: `SMF71POH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of page-outs to auxiliary storage for shared pages with virtual storage address above the bar (long floating point)
"""
poh.__doc__ = """Number of page-outs to auxiliary storage for shared pages with virtual storage address above the bar (long floating point)

SMF Info
--------
    Field: `SMF71POH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of page-outs to auxiliary storage for shared pages with virtual storage address above the bar (long floating point)
"""

ulm : Final[Field] = Field(
    name='ulm',
    origin='SMF71ULM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Lowest minimum system UIC during the interval (from MCTMinSystemUIC)

SMF Info
--------
    Field: `SMF71ULM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest minimum system UIC during the interval (from MCTMinSystemUIC)
"""
ulm.__doc__ = """Lowest minimum system UIC during the interval (from MCTMinSystemUIC)

SMF Info
--------
    Field: `SMF71ULM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest minimum system UIC during the interval (from MCTMinSystemUIC)
"""

ulc : Final[Field] = Field(
    name='ulc',
    origin='SMF71ULC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Lowest current system UIC during the interval (from MCTCurSystemUIC)

SMF Info
--------
    Field: `SMF71ULC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest current system UIC during the interval (from MCTCurSystemUIC)
"""
ulc.__doc__ = """Lowest current system UIC during the interval (from MCTCurSystemUIC)

SMF Info
--------
    Field: `SMF71ULC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest current system UIC during the interval (from MCTCurSystemUIC)
"""

uhc : Final[Field] = Field(
    name='uhc',
    origin='SMF71UHC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Highest current system UIC during the interval (from MCTCurSystemUIC)

SMF Info
--------
    Field: `SMF71UHC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest current system UIC during the interval (from MCTCurSystemUIC)
"""
uhc.__doc__ = """Highest current system UIC during the interval (from MCTCurSystemUIC)

SMF Info
--------
    Field: `SMF71UHC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest current system UIC during the interval (from MCTCurSystemUIC)
"""

uhx : Final[Field] = Field(
    name='uhx',
    origin='SMF71UHX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Highest maximum system UIC during the interval (from MCTMaxSystemUIC)

SMF Info
--------
    Field: `SMF71UHX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest maximum system UIC during the interval (from MCTMaxSystemUIC)
"""
uhx.__doc__ = """Highest maximum system UIC during the interval (from MCTMaxSystemUIC)

SMF Info
--------
    Field: `SMF71UHX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest maximum system UIC during the interval (from MCTMaxSystemUIC)
"""

uam : Final[Field] = Field(
    name='uam',
    origin='SMF71UAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Average minimum system UIC during the interval (from MCTMinSystemUIC)

SMF Info
--------
    Field: `SMF71UAM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average minimum system UIC during the interval (from MCTMinSystemUIC)
"""
uam.__doc__ = """Average minimum system UIC during the interval (from MCTMinSystemUIC)

SMF Info
--------
    Field: `SMF71UAM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average minimum system UIC during the interval (from MCTMinSystemUIC)
"""

uac : Final[Field] = Field(
    name='uac',
    origin='SMF71UAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Average current system UIC during the interval (from MCTCurSystemUIC)

SMF Info
--------
    Field: `SMF71UAC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average current system UIC during the interval (from MCTCurSystemUIC)
"""
uac.__doc__ = """Average current system UIC during the interval (from MCTCurSystemUIC)

SMF Info
--------
    Field: `SMF71UAC`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average current system UIC during the interval (from MCTCurSystemUIC)
"""

uax : Final[Field] = Field(
    name='uax',
    origin='SMF71UAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Average maximum system UIC during the interval (from MCTMaxSystemUIC)

SMF Info
--------
    Field: `SMF71UAX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average maximum system UIC during the interval (from MCTMaxSystemUIC)
"""
uax.__doc__ = """Average maximum system UIC during the interval (from MCTMaxSystemUIC)

SMF Info
--------
    Field: `SMF71UAX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average maximum system UIC during the interval (from MCTMaxSystemUIC)
"""

lom : Final[Field] = Field(
    name='lom',
    origin='SMF71LOM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71LOM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""
lom.__doc__ = """Minimum number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71LOM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""

lox : Final[Field] = Field(
    name='lox',
    origin='SMF71LOX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71LOX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""
lox.__doc__ = """Maximum number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71LOX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""

loa : Final[Field] = Field(
    name='loa',
    origin='SMF71LOA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71LOA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""
loa.__doc__ = """Average number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71LOA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of fixed memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""

lrm : Final[Field] = Field(
    name='lrm',
    origin='SMF71LRM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 1 MB pages fixed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71LRM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB pages fixed in central storage (long floating point)
"""
lrm.__doc__ = """Minimum number of 1 MB pages fixed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71LRM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB pages fixed in central storage (long floating point)
"""

lrx : Final[Field] = Field(
    name='lrx',
    origin='SMF71LRX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 1 MB pages fixed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71LRX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB pages fixed in central storage (long floating point)
"""
lrx.__doc__ = """Maximum number of 1 MB pages fixed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71LRX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB pages fixed in central storage (long floating point)
"""

lra : Final[Field] = Field(
    name='lra',
    origin='SMF71LRA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 1 MB pages fixed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71LRA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB pages fixed in central storage (long floating point)
"""
lra.__doc__ = """Average number of 1 MB pages fixed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71LRA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB pages fixed in central storage (long floating point)
"""

com : Final[Field] = Field(
    name='com',
    origin='SMF71COM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of memory objects allocated in the high virtual common storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71COM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of memory objects allocated in the high virtual common storage of the system (long floating point)
"""
com.__doc__ = """Minimum number of memory objects allocated in the high virtual common storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71COM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of memory objects allocated in the high virtual common storage of the system (long floating point)
"""

cox : Final[Field] = Field(
    name='cox',
    origin='SMF71COX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of memory objects allocated in the high virtual common storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71COX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of memory objects allocated in the high virtual common storage of the system (long floating point)
"""
cox.__doc__ = """Maximum number of memory objects allocated in the high virtual common storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71COX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of memory objects allocated in the high virtual common storage of the system (long floating point)
"""

coa : Final[Field] = Field(
    name='coa',
    origin='SMF71COA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of memory objects allocated in the high virtual common storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71COA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of memory objects allocated in the high virtual common storage of the system (long floating point)
"""
coa.__doc__ = """Average number of memory objects allocated in the high virtual common storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71COA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of memory objects allocated in the high virtual common storage of the system (long floating point)
"""

crm : Final[Field] = Field(
    name='crm',
    origin='SMF71CRM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CRM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of pages from high virtual common storage that are backed in central storage (long floating point)
"""
crm.__doc__ = """Minimum number of pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CRM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of pages from high virtual common storage that are backed in central storage (long floating point)
"""

crx : Final[Field] = Field(
    name='crx',
    origin='SMF71CRX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CRX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of pages from high virtual common storage that are backed in central storage (long floating point)
"""
crx.__doc__ = """Maximum number of pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CRX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of pages from high virtual common storage that are backed in central storage (long floating point)
"""

cra : Final[Field] = Field(
    name='cra',
    origin='SMF71CRA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CRA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of pages from high virtual common storage that are backed in central storage (long floating point)
"""
cra.__doc__ = """Average number of pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CRA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of pages from high virtual common storage that are backed in central storage (long floating point)
"""

cfm : Final[Field] = Field(
    name='cfm',
    origin='SMF71CFM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of fixed pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CFM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed pages from high virtual common storage that are backed in central storage (long floating point)
"""
cfm.__doc__ = """Minimum number of fixed pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CFM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed pages from high virtual common storage that are backed in central storage (long floating point)
"""

cfx : Final[Field] = Field(
    name='cfx',
    origin='SMF71CFX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of fixed pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CFX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of fixed pages from high virtual common storage that are backed in central storage (long floating point)
"""
cfx.__doc__ = """Maximum number of fixed pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CFX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of fixed pages from high virtual common storage that are backed in central storage (long floating point)
"""

cfa : Final[Field] = Field(
    name='cfa',
    origin='SMF71CFA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of fixed pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CFA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of fixed pages from high virtual common storage that are backed in central storage (long floating point)
"""
cfa.__doc__ = """Average number of fixed pages from high virtual common storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71CFA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of fixed pages from high virtual common storage that are backed in central storage (long floating point)
"""

csm : Final[Field] = Field(
    name='csm',
    origin='SMF71CSM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of auxiliary storage slots used for high virtual common memory pages on backed on DASD (long floating point)

SMF Info
--------
    Field: `SMF71CSM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of auxiliary storage slots used for high virtual common memory pages on backed on DASD (long floating point)
"""
csm.__doc__ = """Minimum number of auxiliary storage slots used for high virtual common memory pages on backed on DASD (long floating point)

SMF Info
--------
    Field: `SMF71CSM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of auxiliary storage slots used for high virtual common memory pages on backed on DASD (long floating point)
"""

csx : Final[Field] = Field(
    name='csx',
    origin='SMF71CSX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of auxiliary storage slots used for high virtual common memory pages backed on DASD (long floating point)

SMF Info
--------
    Field: `SMF71CSX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of auxiliary storage slots used for high virtual common memory pages backed on DASD (long floating point)
"""
csx.__doc__ = """Maximum number of auxiliary storage slots used for high virtual common memory pages backed on DASD (long floating point)

SMF Info
--------
    Field: `SMF71CSX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of auxiliary storage slots used for high virtual common memory pages backed on DASD (long floating point)
"""

csa : Final[Field] = Field(
    name='csa',
    origin='SMF71CSA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of auxiliary storage slots used for high virtual common memory pages on backed on DASD (long floating point)

SMF Info
--------
    Field: `SMF71CSA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of auxiliary storage slots used for high virtual common memory pages on backed on DASD (long floating point)
"""
csa.__doc__ = """Average number of auxiliary storage slots used for high virtual common memory pages on backed on DASD (long floating point)

SMF Info
--------
    Field: `SMF71CSA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of auxiliary storage slots used for high virtual common memory pages on backed on DASD (long floating point)
"""

som : Final[Field] = Field(
    name='som',
    origin='SMF71SOM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of memory objects allocated in the high virtual shared storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71SOM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of memory objects allocated in the high virtual shared storage of the system (long floating point)
"""
som.__doc__ = """Minimum number of memory objects allocated in the high virtual shared storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71SOM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of memory objects allocated in the high virtual shared storage of the system (long floating point)
"""

sox : Final[Field] = Field(
    name='sox',
    origin='SMF71SOX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of memory objects allocated in the high virtual shared storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71SOX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of memory objects allocated in the high virtual shared storage of the system (long floating point)
"""
sox.__doc__ = """Maximum number of memory objects allocated in the high virtual shared storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71SOX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of memory objects allocated in the high virtual shared storage of the system (long floating point)
"""

soa : Final[Field] = Field(
    name='soa',
    origin='SMF71SOA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of memory objects allocated in the high virtual shared storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71SOA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of memory objects allocated in the high virtual shared storage of the system (long floating point)
"""
soa.__doc__ = """Average number of memory objects allocated in the high virtual shared storage of the system (long floating point)

SMF Info
--------
    Field: `SMF71SOA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of memory objects allocated in the high virtual shared storage of the system (long floating point)
"""

srm : Final[Field] = Field(
    name='srm',
    origin='SMF71SRM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of pages from high virtual shared storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71SRM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of pages from high virtual shared storage that are backed in central storage (long floating point)
"""
srm.__doc__ = """Minimum number of pages from high virtual shared storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71SRM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of pages from high virtual shared storage that are backed in central storage (long floating point)
"""

srx : Final[Field] = Field(
    name='srx',
    origin='SMF71SRX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of pages from high virtual shared storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71SRX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of pages from high virtual shared storage that are backed in central storage (long floating point)
"""
srx.__doc__ = """Maximum number of pages from high virtual shared storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71SRX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of pages from high virtual shared storage that are backed in central storage (long floating point)
"""

sra : Final[Field] = Field(
    name='sra',
    origin='SMF71SRA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of pages from high virtual shared storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71SRA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of pages from high virtual shared storage that are backed in central storage (long floating point)
"""
sra.__doc__ = """Average number of pages from high virtual shared storage that are backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71SRA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of pages from high virtual shared storage that are backed in central storage (long floating point)
"""

grn : Final[Field] = Field(
    name='grn',
    origin='SMF71GRN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of getmain requests that have been issued

SMF Info
--------
    Field: `SMF71GRN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of getmain requests that have been issued
"""
grn.__doc__ = """Number of getmain requests that have been issued

SMF Info
--------
    Field: `SMF71GRN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of getmain requests that have been issued
"""

fbn : Final[Field] = Field(
    name='fbn',
    origin='SMF71FBN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of pages backed during getmain requests that have been issued

SMF Info
--------
    Field: `SMF71FBN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of pages backed during getmain requests that have been issued
"""
fbn.__doc__ = """Number of pages backed during getmain requests that have been issued

SMF Info
--------
    Field: `SMF71FBN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of pages backed during getmain requests that have been issued
"""

frn : Final[Field] = Field(
    name='frn',
    origin='SMF71FRN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of fix requests that have been issued for storage (address space only) below two gigabytes

SMF Info
--------
    Field: `SMF71FRN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of fix requests that have been issued for storage (address space only) below two gigabytes
"""
frn.__doc__ = """Number of fix requests that have been issued for storage (address space only) below two gigabytes

SMF Info
--------
    Field: `SMF71FRN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of fix requests that have been issued for storage (address space only) below two gigabytes
"""

ffn : Final[Field] = Field(
    name='ffn',
    origin='SMF71FFN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of pages that were requested to be fixed for storage (address space only) below two gigabytes

SMF Info
--------
    Field: `SMF71FFN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of pages that were requested to be fixed for storage (address space only) below two gigabytes
"""
ffn.__doc__ = """Number of pages that were requested to be fixed for storage (address space only) below two gigabytes

SMF Info
--------
    Field: `SMF71FFN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of pages that were requested to be fixed for storage (address space only) below two gigabytes
"""

rn : Final[Field] = Field(
    name='rn',
    origin='SMF711RN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of first reference faults taken

SMF Info
--------
    Field: `SMF711RN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of first reference faults taken
"""
rn.__doc__ = """Number of first reference faults taken

SMF Info
--------
    Field: `SMF711RN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of first reference faults taken
"""

nrn : Final[Field] = Field(
    name='nrn',
    origin='SMF71NRN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Number of non-first reference faults taken

SMF Info
--------
    Field: `SMF71NRN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of non-first reference faults taken
"""
nrn.__doc__ = """Number of non-first reference faults taken

SMF Info
--------
    Field: `SMF71NRN`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Number of non-first reference faults taken
"""

rfl : Final[Field] = Field(
    name='rfl',
    origin='SMF71RFL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF71PAG,
)
"""Flags

SMF Info
--------
    Field: `SMF71RFL`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Flags
"""
rfl.__doc__ = """Flags

SMF Info
--------
    Field: `SMF71RFL`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Flags
"""

scm : Final[Field] = Field(
    name='scm',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=rfl,
    record=record,
    record_map=SMF71PAG,
)
"""SCM support enabled(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rfl`(`SMF71RFL`)
    Record: `SMF71S1`
    Map: `SMF71PAG`

SCM support enabled

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
scm.__doc__ = """SCM support enabled(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rfl`(`SMF71RFL`)
    Record: `SMF71S1`
    Map: `SMF71PAG`

SCM support enabled

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

plp : Final[Field] = Field(
    name='plp',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=rfl,
    record=record,
    record_map=SMF71PAG,
)
"""Pageable Large Pages support enabled(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rfl`(`SMF71RFL`)
    Record: `SMF71S1`
    Map: `SMF71PAG`

Pageable Large Pages support enabled

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
plp.__doc__ = """Pageable Large Pages support enabled(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rfl`(`SMF71RFL`)
    Record: `SMF71S1`
    Map: `SMF71PAG`

Pageable Large Pages support enabled

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

dmemi : Final[Field] = Field(
    name='dmemi',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=rfl,
    record=record,
    record_map=SMF71PAG,
)
"""Dedicated memory usage counts are invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rfl`(`SMF71RFL`)
    Record: `SMF71S1`
    Map: `SMF71PAG`

Dedicated memory usage counts are invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
dmemi.__doc__ = """Dedicated memory usage counts are invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rfl`(`SMF71RFL`)
    Record: `SMF71S1`
    Map: `SMF71PAG`

Dedicated memory usage counts are invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

lfa : Final[Field] = Field(
    name='lfa',
    origin='SMF71LFA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""The maximum number of fixed 1 MB pages that can be allocated as specified in the LFAREA parameter (long floating point)

SMF Info
--------
    Field: `SMF71LFA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

The maximum number of fixed 1 MB pages that can be allocated as specified in the LFAREA parameter (long floating point)
"""
lfa.__doc__ = """The maximum number of fixed 1 MB pages that can be allocated as specified in the LFAREA parameter (long floating point)

SMF Info
--------
    Field: `SMF71LFA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

The maximum number of fixed 1 MB pages that can be allocated as specified in the LFAREA parameter (long floating point)
"""

l1m : Final[Field] = Field(
    name='l1m',
    origin='SMF71L1M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Lowest maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L1M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)
"""
l1m.__doc__ = """Lowest maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L1M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)
"""

l1x : Final[Field] = Field(
    name='l1x',
    origin='SMF71L1X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Highest maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L1X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)
"""
l1x.__doc__ = """Highest maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L1X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)
"""

l1a : Final[Field] = Field(
    name='l1a',
    origin='SMF71L1A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L1A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)
"""
l1a.__doc__ = """Average maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L1A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average maximum number of 1 MB frames that can be used by fixed 1 MB pages (long floating point)
"""

l3m : Final[Field] = Field(
    name='l3m',
    origin='SMF71L3M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L3M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)
"""
l3m.__doc__ = """Minimum number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L3M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)
"""

l3x : Final[Field] = Field(
    name='l3x',
    origin='SMF71L3X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L3X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)
"""
l3x.__doc__ = """Maximum number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L3X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)
"""

l3a : Final[Field] = Field(
    name='l3a',
    origin='SMF71L3A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L3A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)
"""
l3a.__doc__ = """Average number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71L3A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB frames that are in-use and are no longer available for fixed 1 MB pages (long floating point)
"""

l7m : Final[Field] = Field(
    name='l7m',
    origin='SMF71L7M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2M) (long floating point)

SMF Info
--------
    Field: `SMF71L7M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2M) (long floating point)
"""
l7m.__doc__ = """Minimum number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2M) (long floating point)

SMF Info
--------
    Field: `SMF71L7M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2M) (long floating point)
"""

l7x : Final[Field] = Field(
    name='l7x',
    origin='SMF71L7X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2X) (long floating point)

SMF Info
--------
    Field: `SMF71L7X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2X) (long floating point)
"""
l7x.__doc__ = """Maximum number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2X) (long floating point)

SMF Info
--------
    Field: `SMF71L7X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2X) (long floating point)
"""

l7a : Final[Field] = Field(
    name='l7a',
    origin='SMF71L7A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2A) (long floating point)

SMF Info
--------
    Field: `SMF71L7A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2A) (long floating point)
"""
l7a.__doc__ = """Average number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2A) (long floating point)

SMF Info
--------
    Field: `SMF71L7A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of available 1 MB frames that can be used by fixed 1 MB pages (same as SMF71L2A) (long floating point)
"""

s1m : Final[Field] = Field(
    name='s1m',
    origin='SMF71S1M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum total number of high virtual shared memory pages (long floating point)

SMF Info
--------
    Field: `SMF71S1M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum total number of high virtual shared memory pages (long floating point)
"""
s1m.__doc__ = """Minimum total number of high virtual shared memory pages (long floating point)

SMF Info
--------
    Field: `SMF71S1M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum total number of high virtual shared memory pages (long floating point)
"""

s1x : Final[Field] = Field(
    name='s1x',
    origin='SMF71S1X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum total number of high virtual shared memory pages (long floating point)

SMF Info
--------
    Field: `SMF71S1X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum total number of high virtual shared memory pages (long floating point)
"""
s1x.__doc__ = """Maximum total number of high virtual shared memory pages (long floating point)

SMF Info
--------
    Field: `SMF71S1X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum total number of high virtual shared memory pages (long floating point)
"""

s1a : Final[Field] = Field(
    name='s1a',
    origin='SMF71S1A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of high virtual shared memory pages (long floating point)

SMF Info
--------
    Field: `SMF71S1A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of high virtual shared memory pages (long floating point)
"""
s1a.__doc__ = """Average total number of high virtual shared memory pages (long floating point)

SMF Info
--------
    Field: `SMF71S1A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of high virtual shared memory pages (long floating point)
"""

s2m : Final[Field] = Field(
    name='s2m',
    origin='SMF71S2M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71S2M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""
s2m.__doc__ = """Minimum number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71S2M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""

s2x : Final[Field] = Field(
    name='s2x',
    origin='SMF71S2X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71S2X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""
s2x.__doc__ = """Maximum number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71S2X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""

s2a : Final[Field] = Field(
    name='s2a',
    origin='SMF71S2A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71S2A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""
s2a.__doc__ = """Average number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)

SMF Info
--------
    Field: `SMF71S2A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared memory objects that are allocated in the system and can be backed in 1 MB frames (long floating point)
"""

s3m : Final[Field] = Field(
    name='s3m',
    origin='SMF71S3M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of frames in use for shared high virtual 4K pages (long floating point)

SMF Info
--------
    Field: `SMF71S3M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of frames in use for shared high virtual 4K pages (long floating point)
"""
s3m.__doc__ = """Minimum number of frames in use for shared high virtual 4K pages (long floating point)

SMF Info
--------
    Field: `SMF71S3M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of frames in use for shared high virtual 4K pages (long floating point)
"""

s3x : Final[Field] = Field(
    name='s3x',
    origin='SMF71S3X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of frames in use for shared high virtual 4K pages (long floating point)

SMF Info
--------
    Field: `SMF71S3X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of frames in use for shared high virtual 4K pages (long floating point)
"""
s3x.__doc__ = """Maximum number of frames in use for shared high virtual 4K pages (long floating point)

SMF Info
--------
    Field: `SMF71S3X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of frames in use for shared high virtual 4K pages (long floating point)
"""

s3a : Final[Field] = Field(
    name='s3a',
    origin='SMF71S3A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of frames in use for shared high virtual 4K pages (long floating point)

SMF Info
--------
    Field: `SMF71S3A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of frames in use for shared high virtual 4K pages (long floating point)
"""
s3a.__doc__ = """Average number of frames in use for shared high virtual 4K pages (long floating point)

SMF Info
--------
    Field: `SMF71S3A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of frames in use for shared high virtual 4K pages (long floating point)
"""

s4m : Final[Field] = Field(
    name='s4m',
    origin='SMF71S4M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 1 MB pages used for shared memory objects backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71S4M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB pages used for shared memory objects backed in central storage (long floating point)
"""
s4m.__doc__ = """Minimum number of 1 MB pages used for shared memory objects backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71S4M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB pages used for shared memory objects backed in central storage (long floating point)
"""

s4x : Final[Field] = Field(
    name='s4x',
    origin='SMF71S4X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 1 MB pages used for shared memory objects backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71S4X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB pages used for shared memory objects backed in central storage (long floating point)
"""
s4x.__doc__ = """Maximum number of 1 MB pages used for shared memory objects backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71S4X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB pages used for shared memory objects backed in central storage (long floating point)
"""

s4a : Final[Field] = Field(
    name='s4a',
    origin='SMF71S4A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 1 MB pages used for shared memory objects backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71S4A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB pages used for shared memory objects backed in central storage (long floating point)
"""
s4a.__doc__ = """Average number of 1 MB pages used for shared memory objects backed in central storage (long floating point)

SMF Info
--------
    Field: `SMF71S4A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB pages used for shared memory objects backed in central storage (long floating point)
"""

s5m : Final[Field] = Field(
    name='s5m',
    origin='SMF71S5M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)

SMF Info
--------
    Field: `SMF71S5M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)
"""
s5m.__doc__ = """Minimum number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)

SMF Info
--------
    Field: `SMF71S5M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)
"""

s5x : Final[Field] = Field(
    name='s5x',
    origin='SMF71S5X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)

SMF Info
--------
    Field: `SMF71S5X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)
"""
s5x.__doc__ = """Maximum number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)

SMF Info
--------
    Field: `SMF71S5X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)
"""

s5a : Final[Field] = Field(
    name='s5a',
    origin='SMF71S5A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)

SMF Info
--------
    Field: `SMF71S5A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)
"""
s5a.__doc__ = """Average number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)

SMF Info
--------
    Field: `SMF71S5A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of auxiliary storage slots used for high virtual shared memory DASD pages (long floating point)
"""

s6m : Final[Field] = Field(
    name='s6m',
    origin='SMF71S6M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of high virtual shared memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S6M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual shared memory pages backed on SCM storage (long floating point)
"""
s6m.__doc__ = """Minimum number of high virtual shared memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S6M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual shared memory pages backed on SCM storage (long floating point)
"""

s6x : Final[Field] = Field(
    name='s6x',
    origin='SMF71S6X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of high virtual shared memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S6X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual shared memory pages backed on SCM storage (long floating point)
"""
s6x.__doc__ = """Maximum number of high virtual shared memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S6X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual shared memory pages backed on SCM storage (long floating point)
"""

s6a : Final[Field] = Field(
    name='s6a',
    origin='SMF71S6A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of high virtual shared memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S6A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual shared memory pages backed on SCM storage (long floating point)
"""
s6a.__doc__ = """Average number of high virtual shared memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S6A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual shared memory pages backed on SCM storage (long floating point)
"""

c1m : Final[Field] = Field(
    name='c1m',
    origin='SMF71C1M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum total number of high virtual common memory pages (long floating point)

SMF Info
--------
    Field: `SMF71C1M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum total number of high virtual common memory pages (long floating point)
"""
c1m.__doc__ = """Minimum total number of high virtual common memory pages (long floating point)

SMF Info
--------
    Field: `SMF71C1M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum total number of high virtual common memory pages (long floating point)
"""

c1x : Final[Field] = Field(
    name='c1x',
    origin='SMF71C1X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum total number of high virtual common memory pages (long floating point)

SMF Info
--------
    Field: `SMF71C1X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum total number of high virtual common memory pages (long floating point)
"""
c1x.__doc__ = """Maximum total number of high virtual common memory pages (long floating point)

SMF Info
--------
    Field: `SMF71C1X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum total number of high virtual common memory pages (long floating point)
"""

c1a : Final[Field] = Field(
    name='c1a',
    origin='SMF71C1A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of high virtual common memory pages (long floating point)

SMF Info
--------
    Field: `SMF71C1A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of high virtual common memory pages (long floating point)
"""
c1a.__doc__ = """Average total number of high virtual common memory pages (long floating point)

SMF Info
--------
    Field: `SMF71C1A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of high virtual common memory pages (long floating point)
"""

c2m : Final[Field] = Field(
    name='c2m',
    origin='SMF71C2M',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of high virtual common memory 1 MB fixed pages

SMF Info
--------
    Field: `SMF71C2M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual common memory 1 MB fixed pages
"""
c2m.__doc__ = """Minimum number of high virtual common memory 1 MB fixed pages

SMF Info
--------
    Field: `SMF71C2M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual common memory 1 MB fixed pages
"""

c2x : Final[Field] = Field(
    name='c2x',
    origin='SMF71C2X',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of high virtual common memory 1 MB fixed pages

SMF Info
--------
    Field: `SMF71C2X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual common memory 1 MB fixed pages
"""
c2x.__doc__ = """Maximum number of high virtual common memory 1 MB fixed pages

SMF Info
--------
    Field: `SMF71C2X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual common memory 1 MB fixed pages
"""

c2a : Final[Field] = Field(
    name='c2a',
    origin='SMF71C2A',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of high virtual common memory 1 MB fixed pages

SMF Info
--------
    Field: `SMF71C2A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual common memory 1 MB fixed pages
"""
c2a.__doc__ = """Average number of high virtual common memory 1 MB fixed pages

SMF Info
--------
    Field: `SMF71C2A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual common memory 1 MB fixed pages
"""

c3m : Final[Field] = Field(
    name='c3m',
    origin='SMF71C3M',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of high virtual common memory 1 MB pages backed in central storage

SMF Info
--------
    Field: `SMF71C3M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual common memory 1 MB pages backed in central storage
"""
c3m.__doc__ = """Minimum number of high virtual common memory 1 MB pages backed in central storage

SMF Info
--------
    Field: `SMF71C3M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual common memory 1 MB pages backed in central storage
"""

c3x : Final[Field] = Field(
    name='c3x',
    origin='SMF71C3X',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of high virtual common memory 1 MB pages backed in central storage

SMF Info
--------
    Field: `SMF71C3X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual common memory 1 MB pages backed in central storage
"""
c3x.__doc__ = """Maximum number of high virtual common memory 1 MB pages backed in central storage

SMF Info
--------
    Field: `SMF71C3X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual common memory 1 MB pages backed in central storage
"""

c3a : Final[Field] = Field(
    name='c3a',
    origin='SMF71C3A',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of high virtual common memory 1 MB pages backed in central storage

SMF Info
--------
    Field: `SMF71C3A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual common memory 1 MB pages backed in central storage
"""
c3a.__doc__ = """Average number of high virtual common memory 1 MB pages backed in central storage

SMF Info
--------
    Field: `SMF71C3A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual common memory 1 MB pages backed in central storage
"""

c4m : Final[Field] = Field(
    name='c4m',
    origin='SMF71C4M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of high virtual common memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71C4M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual common memory pages backed on SCM storage (long floating point)
"""
c4m.__doc__ = """Minimum number of high virtual common memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71C4M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual common memory pages backed on SCM storage (long floating point)
"""

c4x : Final[Field] = Field(
    name='c4x',
    origin='SMF71C4X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of high virtual common memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71C4X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual common memory pages backed on SCM storage (long floating point)
"""
c4x.__doc__ = """Maximum number of high virtual common memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71C4X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual common memory pages backed on SCM storage (long floating point)
"""

c4a : Final[Field] = Field(
    name='c4a',
    origin='SMF71C4A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of high virtual common memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71C4A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual common memory pages backed on SCM storage (long floating point)
"""
c4a.__doc__ = """Average number of high virtual common memory pages backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71C4A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual common memory pages backed on SCM storage (long floating point)
"""

tsm : Final[Field] = Field(
    name='tsm',
    origin='SMF71TSM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum total number of 4K SCM blocks available to ASM (long floating point)

SMF Info
--------
    Field: `SMF71TSM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum total number of 4K SCM blocks available to ASM (long floating point)
"""
tsm.__doc__ = """Minimum total number of 4K SCM blocks available to ASM (long floating point)

SMF Info
--------
    Field: `SMF71TSM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum total number of 4K SCM blocks available to ASM (long floating point)
"""

tsx : Final[Field] = Field(
    name='tsx',
    origin='SMF71TSX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum total number of 4K SCM blocks available to ASM (long floating point)

SMF Info
--------
    Field: `SMF71TSX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum total number of 4K SCM blocks available to ASM (long floating point)
"""
tsx.__doc__ = """Maximum total number of 4K SCM blocks available to ASM (long floating point)

SMF Info
--------
    Field: `SMF71TSX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum total number of 4K SCM blocks available to ASM (long floating point)
"""

tsa : Final[Field] = Field(
    name='tsa',
    origin='SMF71TSA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of 4K SCM blocks available to ASM (long floating point)

SMF Info
--------
    Field: `SMF71TSA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of 4K SCM blocks available to ASM (long floating point)
"""
tsa.__doc__ = """Average total number of 4K SCM blocks available to ASM (long floating point)

SMF Info
--------
    Field: `SMF71TSA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of 4K SCM blocks available to ASM (long floating point)
"""

asm : Final[Field] = Field(
    name='asm',
    origin='SMF71ASM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of available (not in-use) SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71ASM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of available (not in-use) SCM blocks (long floating point)
"""
asm.__doc__ = """Minimum number of available (not in-use) SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71ASM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of available (not in-use) SCM blocks (long floating point)
"""

asx : Final[Field] = Field(
    name='asx',
    origin='SMF71ASX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of available (not in-use) SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71ASX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of available (not in-use) SCM blocks (long floating point)
"""
asx.__doc__ = """Maximum number of available (not in-use) SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71ASX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of available (not in-use) SCM blocks (long floating point)
"""

asv : Final[Field] = Field(
    name='asv',
    origin='SMF71ASV',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of available (not in-use) SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71ASV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of available (not in-use) SCM blocks (long floating point)
"""
asv.__doc__ = """Average number of available (not in-use) SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71ASV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of available (not in-use) SCM blocks (long floating point)
"""

bsm : Final[Field] = Field(
    name='bsm',
    origin='SMF71BSM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of bad SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71BSM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of bad SCM blocks (long floating point)
"""
bsm.__doc__ = """Minimum number of bad SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71BSM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of bad SCM blocks (long floating point)
"""

bsx : Final[Field] = Field(
    name='bsx',
    origin='SMF71BSX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of bad SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71BSX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of bad SCM blocks (long floating point)
"""
bsx.__doc__ = """Maximum number of bad SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71BSX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of bad SCM blocks (long floating point)
"""

bsa : Final[Field] = Field(
    name='bsa',
    origin='SMF71BSA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of bad SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71BSA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of bad SCM blocks (long floating point)
"""
bsa.__doc__ = """Average number of bad SCM blocks (long floating point)

SMF Info
--------
    Field: `SMF71BSA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of bad SCM blocks (long floating point)
"""

usm : Final[Field] = Field(
    name='usm',
    origin='SMF71USM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of SCM blocks in-use (long floating point)

SMF Info
--------
    Field: `SMF71USM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of SCM blocks in-use (long floating point)
"""
usm.__doc__ = """Minimum number of SCM blocks in-use (long floating point)

SMF Info
--------
    Field: `SMF71USM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of SCM blocks in-use (long floating point)
"""

usx : Final[Field] = Field(
    name='usx',
    origin='SMF71USX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of SCM blocks in-use (long floating point)

SMF Info
--------
    Field: `SMF71USX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of SCM blocks in-use (long floating point)
"""
usx.__doc__ = """Maximum number of SCM blocks in-use (long floating point)

SMF Info
--------
    Field: `SMF71USX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of SCM blocks in-use (long floating point)
"""

usa : Final[Field] = Field(
    name='usa',
    origin='SMF71USA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of SCM blocks in-use (long floating point)

SMF Info
--------
    Field: `SMF71USA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of SCM blocks in-use (long floating point)
"""
usa.__doc__ = """Average number of SCM blocks in-use (long floating point)

SMF Info
--------
    Field: `SMF71USA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of SCM blocks in-use (long floating point)
"""

tls : Final[Field] = Field(
    name='tls',
    origin='SMF71TLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Total number of logical swaps (from RMCASRC)

SMF Info
--------
    Field: `SMF71TLS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Total number of logical swaps (from RMCASRC)
"""
tls.__doc__ = """Total number of logical swaps (from RMCASRC)

SMF Info
--------
    Field: `SMF71TLS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Total number of logical swaps (from RMCASRC)
"""

s7m : Final[Field] = Field(
    name='s7m',
    origin='SMF71S7M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of shared page groups backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S7M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared page groups backed on SCM storage (long floating point)
"""
s7m.__doc__ = """Minimum number of shared page groups backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S7M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of shared page groups backed on SCM storage (long floating point)
"""

s7x : Final[Field] = Field(
    name='s7x',
    origin='SMF71S7X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of shared page groups backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S7X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared page groups backed on SCM storage (long floating point)
"""
s7x.__doc__ = """Maximum number of shared page groups backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S7X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of shared page groups backed on SCM storage (long floating point)
"""

s7a : Final[Field] = Field(
    name='s7a',
    origin='SMF71S7A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of shared page groups backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S7A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared page groups backed on SCM storage (long floating point)
"""
s7a.__doc__ = """Average number of shared page groups backed on SCM storage (long floating point)

SMF Info
--------
    Field: `SMF71S7A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of shared page groups backed on SCM storage (long floating point)
"""

lvf : Final[Field] = Field(
    name='lvf',
    origin='SMF71LVF',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of unused central storage page frames (same as SMF71AVF) (long floating point)

SMF Info
--------
    Field: `SMF71LVF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of unused central storage page frames (same as SMF71AVF) (long floating point)
"""
lvf.__doc__ = """Average number of unused central storage page frames (same as SMF71AVF) (long floating point)

SMF Info
--------
    Field: `SMF71LVF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of unused central storage page frames (same as SMF71AVF) (long floating point)
"""

lvs : Final[Field] = Field(
    name='lvs',
    origin='SMF71LVS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of pageable address space central storage frames in the private address space (same as SMF71AVS) (long floating point)

SMF Info
--------
    Field: `SMF71LVS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of pageable address space central storage frames in the private address space (same as SMF71AVS) (long floating point)
"""
lvs.__doc__ = """Average number of pageable address space central storage frames in the private address space (same as SMF71AVS) (long floating point)

SMF Info
--------
    Field: `SMF71LVS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of pageable address space central storage frames in the private address space (same as SMF71AVS) (long floating point)
"""

lvt : Final[Field] = Field(
    name='lvt',
    origin='SMF71LVT',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of central storage frames used (same as SMF71AVT) (long floating point)

SMF Info
--------
    Field: `SMF71LVT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of central storage frames used (same as SMF71AVT) (long floating point)
"""
lvt.__doc__ = """Average total number of central storage frames used (same as SMF71AVT) (long floating point)

SMF Info
--------
    Field: `SMF71LVT`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of central storage frames used (same as SMF71AVT) (long floating point)
"""

lvr : Final[Field] = Field(
    name='lvr',
    origin='SMF71LVR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of non-LSQA fixed central storage frames in the private address space (same as SMF71AVR) (long floating point)

SMF Info
--------
    Field: `SMF71LVR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of non-LSQA fixed central storage frames in the private address space (same as SMF71AVR) (long floating point)
"""
lvr.__doc__ = """Average number of non-LSQA fixed central storage frames in the private address space (same as SMF71AVR) (long floating point)

SMF Info
--------
    Field: `SMF71LVR`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of non-LSQA fixed central storage frames in the private address space (same as SMF71AVR) (long floating point)
"""

lvx : Final[Field] = Field(
    name='lvx',
    origin='SMF71LVX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of fixed central storage frames used (same as SMF71AVX) (long floating point)

SMF Info
--------
    Field: `SMF71LVX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of fixed central storage frames used (same as SMF71AVX) (long floating point)
"""
lvx.__doc__ = """Average total number of fixed central storage frames used (same as SMF71AVX) (long floating point)

SMF Info
--------
    Field: `SMF71LVX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of fixed central storage frames used (same as SMF71AVX) (long floating point)
"""

lvu : Final[Field] = Field(
    name='lvu',
    origin='SMF71LVU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of usable local page data set slots that have not been allocated (same as SMF71AVU) (long floating point)

SMF Info
--------
    Field: `SMF71LVU`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of usable local page data set slots that have not been allocated (same as SMF71AVU) (long floating point)
"""
lvu.__doc__ = """Average number of usable local page data set slots that have not been allocated (same as SMF71AVU) (long floating point)

SMF Info
--------
    Field: `SMF71LVU`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of usable local page data set slots that have not been allocated (same as SMF71AVU) (long floating point)
"""

lvv : Final[Field] = Field(
    name='lvv',
    origin='SMF71LVV',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of local page data set slots allocated to VIO private area pages (same as SMF71AVV) (long floating point)

SMF Info
--------
    Field: `SMF71LVV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of local page data set slots allocated to VIO private area pages (same as SMF71AVV) (long floating point)
"""
lvv.__doc__ = """Average number of local page data set slots allocated to VIO private area pages (same as SMF71AVV) (long floating point)

SMF Info
--------
    Field: `SMF71LVV`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of local page data set slots allocated to VIO private area pages (same as SMF71AVV) (long floating point)
"""

lvm : Final[Field] = Field(
    name='lvm',
    origin='SMF71LVM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of local page data set slots allocated to non-VIO private area pages (same as SMF71AVM) (long floating point)

SMF Info
--------
    Field: `SMF71LVM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of local page data set slots allocated to non-VIO private area pages (same as SMF71AVM) (long floating point)
"""
lvm.__doc__ = """Average number of local page data set slots allocated to non-VIO private area pages (same as SMF71AVM) (long floating point)

SMF Info
--------
    Field: `SMF71LVM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of local page data set slots allocated to non-VIO private area pages (same as SMF71AVM) (long floating point)
"""

lvb : Final[Field] = Field(
    name='lvb',
    origin='SMF71LVB',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of unusable local page data set slots (same as SMF71AVB) (long floating point)

SMF Info
--------
    Field: `SMF71LVB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of unusable local page data set slots (same as SMF71AVB) (long floating point)
"""
lvb.__doc__ = """Average number of unusable local page data set slots (same as SMF71AVB) (long floating point)

SMF Info
--------
    Field: `SMF71LVB`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of unusable local page data set slots (same as SMF71AVB) (long floating point)
"""

mcf : Final[Field] = Field(
    name='mcf',
    origin='SMF71MCF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF71PAG,
)
"""Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

SMF Info
--------
    Field: `SMF71MCF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.
"""
mcf.__doc__ = """Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

SMF Info
--------
    Field: `SMF71MCF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.
"""

cpm : Final[Field] = Field(
    name='cpm',
    origin='SMF71CPM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of high virtual common pages is-use (long floating point)

SMF Info
--------
    Field: `SMF71CPM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual common pages is-use (long floating point)
"""
cpm.__doc__ = """Minimum number of high virtual common pages is-use (long floating point)

SMF Info
--------
    Field: `SMF71CPM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of high virtual common pages is-use (long floating point)
"""

cpx : Final[Field] = Field(
    name='cpx',
    origin='SMF71CPX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of high virtual common pages is-use (long floating point)

SMF Info
--------
    Field: `SMF71CPX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual common pages is-use (long floating point)
"""
cpx.__doc__ = """Maximum number of high virtual common pages is-use (long floating point)

SMF Info
--------
    Field: `SMF71CPX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of high virtual common pages is-use (long floating point)
"""

cpa : Final[Field] = Field(
    name='cpa',
    origin='SMF71CPA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of high virtual common pages is-use (long floating point)

SMF Info
--------
    Field: `SMF71CPA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual common pages is-use (long floating point)
"""
cpa.__doc__ = """Average number of high virtual common pages is-use (long floating point)

SMF Info
--------
    Field: `SMF71CPA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of high virtual common pages is-use (long floating point)
"""

plm : Final[Field] = Field(
    name='plm',
    origin='SMF71PLM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71PLM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)
"""
plm.__doc__ = """Minimum number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71PLM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)
"""

plx : Final[Field] = Field(
    name='plx',
    origin='SMF71PLX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71PLX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)
"""
plx.__doc__ = """Maximum number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71PLX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)
"""

pla : Final[Field] = Field(
    name='pla',
    origin='SMF71PLA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71PLA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)
"""
pla.__doc__ = """Average number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)

SMF Info
--------
    Field: `SMF71PLA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB frames that are in-use by pageable 1 MB pages (long floating point)
"""

gom : Final[Field] = Field(
    name='gom',
    origin='SMF71GOM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of fixed 2 GB memory objects allocated in the system (long floating point)

SMF Info
--------
    Field: `SMF71GOM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed 2 GB memory objects allocated in the system (long floating point)
"""
gom.__doc__ = """Minimum number of fixed 2 GB memory objects allocated in the system (long floating point)

SMF Info
--------
    Field: `SMF71GOM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed 2 GB memory objects allocated in the system (long floating point)
"""

gox : Final[Field] = Field(
    name='gox',
    origin='SMF71GOX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of fixed 2 GB memory objects allocated in the system (long floating point)

SMF Info
--------
    Field: `SMF71GOX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of fixed 2 GB memory objects allocated in the system (long floating point)
"""
gox.__doc__ = """Maximum number of fixed 2 GB memory objects allocated in the system (long floating point)

SMF Info
--------
    Field: `SMF71GOX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of fixed 2 GB memory objects allocated in the system (long floating point)
"""

goa : Final[Field] = Field(
    name='goa',
    origin='SMF71GOA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of fixed 2 GB memory objects allocated in the system (long floating point)

SMF Info
--------
    Field: `SMF71GOA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of fixed 2 GB memory objects allocated in the system (long floating point)
"""
goa.__doc__ = """Average number of fixed 2 GB memory objects allocated in the system (long floating point)

SMF Info
--------
    Field: `SMF71GOA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of fixed 2 GB memory objects allocated in the system (long floating point)
"""

grm : Final[Field] = Field(
    name='grm',
    origin='SMF71GRM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 2 GB pages fixed in central storage (same as SMF71GUM) (long floating point)

SMF Info
--------
    Field: `SMF71GRM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 2 GB pages fixed in central storage (same as SMF71GUM) (long floating point)
"""
grm.__doc__ = """Minimum number of 2 GB pages fixed in central storage (same as SMF71GUM) (long floating point)

SMF Info
--------
    Field: `SMF71GRM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 2 GB pages fixed in central storage (same as SMF71GUM) (long floating point)
"""

grx : Final[Field] = Field(
    name='grx',
    origin='SMF71GRX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 2 GB pages fixed in central storage (same as SMF71GUX) (long floating point)

SMF Info
--------
    Field: `SMF71GRX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 2 GB pages fixed in central storage (same as SMF71GUX) (long floating point)
"""
grx.__doc__ = """Maximum number of 2 GB pages fixed in central storage (same as SMF71GUX) (long floating point)

SMF Info
--------
    Field: `SMF71GRX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 2 GB pages fixed in central storage (same as SMF71GUX) (long floating point)
"""

gra : Final[Field] = Field(
    name='gra',
    origin='SMF71GRA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 2 GB pages fixed in central storage (same as SMF71GUA) (long floating point)

SMF Info
--------
    Field: `SMF71GRA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 2 GB pages fixed in central storage (same as SMF71GUA) (long floating point)
"""
gra.__doc__ = """Average number of 2 GB pages fixed in central storage (same as SMF71GUA) (long floating point)

SMF Info
--------
    Field: `SMF71GRA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 2 GB pages fixed in central storage (same as SMF71GUA) (long floating point)
"""

gum : Final[Field] = Field(
    name='gum',
    origin='SMF71GUM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 2 GB frames in the Large Frame Area that are in-use by fixed memory objects (same as SMF71GRM) (long floating point)

SMF Info
--------
    Field: `SMF71GUM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 2 GB frames in the Large Frame Area that are in-use by fixed memory objects (same as SMF71GRM) (long floating point)
"""
gum.__doc__ = """Minimum number of 2 GB frames in the Large Frame Area that are in-use by fixed memory objects (same as SMF71GRM) (long floating point)

SMF Info
--------
    Field: `SMF71GUM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 2 GB frames in the Large Frame Area that are in-use by fixed memory objects (same as SMF71GRM) (long floating point)
"""

gux : Final[Field] = Field(
    name='gux',
    origin='SMF71GUX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 2 GB frames in the Large Frame Area that are in-use by fixed memory objects (same as SMF71GRX) (long floating point)

SMF Info
--------
    Field: `SMF71GUX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 2 GB frames in the Large Frame Area that are in-use by fixed memory objects (same as SMF71GRX) (long floating point)
"""
gux.__doc__ = """Maximum number of 2 GB frames in the Large Frame Area that are in-use by fixed memory objects (same as SMF71GRX) (long floating point)

SMF Info
--------
    Field: `SMF71GUX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 2 GB frames in the Large Frame Area that are in-use by fixed memory objects (same as SMF71GRX) (long floating point)
"""

gua : Final[Field] = Field(
    name='gua',
    origin='SMF71GUA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 2 GB frames in the Large Frame Area hat are in-use by fixed memory objects (same as SMF71GRA) (long floating point)

SMF Info
--------
    Field: `SMF71GUA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 2 GB frames in the Large Frame Area hat are in-use by fixed memory objects (same as SMF71GRA) (long floating point)
"""
gua.__doc__ = """Average number of 2 GB frames in the Large Frame Area hat are in-use by fixed memory objects (same as SMF71GRA) (long floating point)

SMF Info
--------
    Field: `SMF71GUA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 2 GB frames in the Large Frame Area hat are in-use by fixed memory objects (same as SMF71GRA) (long floating point)
"""

guh : Final[Field] = Field(
    name='guh',
    origin='SMF71GUH',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""High water mark for the number of 2 GB frames that are used by the system (long floating point)

SMF Info
--------
    Field: `SMF71GUH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

High water mark for the number of 2 GB frames that are used by the system (long floating point)
"""
guh.__doc__ = """High water mark for the number of 2 GB frames that are used by the system (long floating point)

SMF Info
--------
    Field: `SMF71GUH`
    Record: `SMF71S1`
    Map: `SMF71PAG`

High water mark for the number of 2 GB frames that are used by the system (long floating point)
"""

gam : Final[Field] = Field(
    name='gam',
    origin='SMF71GAM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)

SMF Info
--------
    Field: `SMF71GAM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)
"""
gam.__doc__ = """Minimum number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)

SMF Info
--------
    Field: `SMF71GAM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)
"""

gax : Final[Field] = Field(
    name='gax',
    origin='SMF71GAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)

SMF Info
--------
    Field: `SMF71GAX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)
"""
gax.__doc__ = """Maximum number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)

SMF Info
--------
    Field: `SMF71GAX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)
"""

gaa : Final[Field] = Field(
    name='gaa',
    origin='SMF71GAA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)

SMF Info
--------
    Field: `SMF71GAA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)
"""
gaa.__doc__ = """Average number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)

SMF Info
--------
    Field: `SMF71GAA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 2 GB frames in the Large Frame Area hat are not in-use (long floating point)
"""

gfm : Final[Field] = Field(
    name='gfm',
    origin='SMF71GFM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Lowest maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)

SMF Info
--------
    Field: `SMF71GFM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)
"""
gfm.__doc__ = """Lowest maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)

SMF Info
--------
    Field: `SMF71GFM`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)
"""

gfx : Final[Field] = Field(
    name='gfx',
    origin='SMF71GFX',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Highest maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)

SMF Info
--------
    Field: `SMF71GFX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)
"""
gfx.__doc__ = """Highest maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)

SMF Info
--------
    Field: `SMF71GFX`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)
"""

gfa : Final[Field] = Field(
    name='gfa',
    origin='SMF71GFA',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)

SMF Info
--------
    Field: `SMF71GFA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)
"""
gfa.__doc__ = """Average maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)

SMF Info
--------
    Field: `SMF71GFA`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average maximum number of 2 GB frames that can be used by fixed 2 GB pages (long floating point)
"""

nnf : Final[Field] = Field(
    name='nnf',
    origin='SMF71NNF',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of non-nucleus frames comprising permanent storage (long floating point)

SMF Info
--------
    Field: `SMF71NNF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of non-nucleus frames comprising permanent storage (long floating point)
"""
nnf.__doc__ = """Average number of non-nucleus frames comprising permanent storage (long floating point)

SMF Info
--------
    Field: `SMF71NNF`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of non-nucleus frames comprising permanent storage (long floating point)
"""

lsi : Final[Field] = Field(
    name='lsi',
    origin='SMF71LSI',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of system-ini tiated demotions from pageable large frame groups to 4K page frames (long floating point)

SMF Info
--------
    Field: `SMF71LSI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of system-ini tiated demotions from pageable large frame groups to 4K page frames (long floating point)
"""
lsi.__doc__ = """Average number of system-ini tiated demotions from pageable large frame groups to 4K page frames (long floating point)

SMF Info
--------
    Field: `SMF71LSI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of system-ini tiated demotions from pageable large frame groups to 4K page frames (long floating point)
"""

lri : Final[Field] = Field(
    name='lri',
    origin='SMF71LRI',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of request-ini tiated demotions from pageable large frame groups to 4K page frames (long floating point)

SMF Info
--------
    Field: `SMF71LRI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of request-ini tiated demotions from pageable large frame groups to 4K page frames (long floating point)
"""
lri.__doc__ = """Average number of request-ini tiated demotions from pageable large frame groups to 4K page frames (long floating point)

SMF Info
--------
    Field: `SMF71LRI`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of request-ini tiated demotions from pageable large frame groups to 4K page frames (long floating point)
"""

mhw : Final[Field] = Field(
    name='mhw',
    origin='SMF71MHW',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""High water mark of the number of 1 MB frames that were used to satisfy fixed 1 MB page requests (long floating point)

SMF Info
--------
    Field: `SMF71MHW`
    Record: `SMF71S1`
    Map: `SMF71PAG`

High water mark of the number of 1 MB frames that were used to satisfy fixed 1 MB page requests (long floating point)
"""
mhw.__doc__ = """High water mark of the number of 1 MB frames that were used to satisfy fixed 1 MB page requests (long floating point)

SMF Info
--------
    Field: `SMF71MHW`
    Record: `SMF71S1`
    Map: `SMF71PAG`

High water mark of the number of 1 MB frames that were used to satisfy fixed 1 MB page requests (long floating point)
"""

pis : Final[Field] = Field(
    name='pis',
    origin='SMF71PIS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of page-ins of 4 KB pages from SCM (long floating point)

SMF Info
--------
    Field: `SMF71PIS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of page-ins of 4 KB pages from SCM (long floating point)
"""
pis.__doc__ = """Average total number of page-ins of 4 KB pages from SCM (long floating point)

SMF Info
--------
    Field: `SMF71PIS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of page-ins of 4 KB pages from SCM (long floating point)
"""

pos : Final[Field] = Field(
    name='pos',
    origin='SMF71POS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of page outs of 4 KB pages to SCM (long floating point)

SMF Info
--------
    Field: `SMF71POS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of page outs of 4 KB pages to SCM (long floating point)
"""
pos.__doc__ = """Average total number of page outs of 4 KB pages to SCM (long floating point)

SMF Info
--------
    Field: `SMF71POS`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of page outs of 4 KB pages to SCM (long floating point)
"""

pi1 : Final[Field] = Field(
    name='pi1',
    origin='SMF71PI1',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of page-ins of 1 MB pages from SCM (long floating point)

SMF Info
--------
    Field: `SMF71PI1`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of page-ins of 1 MB pages from SCM (long floating point)
"""
pi1.__doc__ = """Average total number of page-ins of 1 MB pages from SCM (long floating point)

SMF Info
--------
    Field: `SMF71PI1`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of page-ins of 1 MB pages from SCM (long floating point)
"""

po1 : Final[Field] = Field(
    name='po1',
    origin='SMF71PO1',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of page outs of 1 MB pages to SCM (long floating point)

SMF Info
--------
    Field: `SMF71PO1`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of page outs of 1 MB pages to SCM (long floating point)
"""
po1.__doc__ = """Average total number of page outs of 1 MB pages to SCM (long floating point)

SMF Info
--------
    Field: `SMF71PO1`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of page outs of 1 MB pages to SCM (long floating point)
"""

l8m : Final[Field] = Field(
    name='l8m',
    origin='SMF71L8M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum total number of 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L8M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum total number of 1 MB frames in central storage (long floating point)
"""
l8m.__doc__ = """Minimum total number of 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L8M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum total number of 1 MB frames in central storage (long floating point)
"""

l8x : Final[Field] = Field(
    name='l8x',
    origin='SMF71L8X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum total number of 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L8X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum total number of 1 MB frames in central storage (long floating point)
"""
l8x.__doc__ = """Maximum total number of 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L8X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum total number of 1 MB frames in central storage (long floating point)
"""

l8a : Final[Field] = Field(
    name='l8a',
    origin='SMF71L8A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average total number of 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L8A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of 1 MB frames in central storage (long floating point)
"""
l8a.__doc__ = """Average total number of 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L8A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average total number of 1 MB frames in central storage (long floating point)
"""

l9m : Final[Field] = Field(
    name='l9m',
    origin='SMF71L9M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of available 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L9M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of available 1 MB frames in central storage (long floating point)
"""
l9m.__doc__ = """Minimum number of available 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L9M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of available 1 MB frames in central storage (long floating point)
"""

l9x : Final[Field] = Field(
    name='l9x',
    origin='SMF71L9X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of available 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L9X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of available 1 MB frames in central storage (long floating point)
"""
l9x.__doc__ = """Maximum number of available 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L9X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of available 1 MB frames in central storage (long floating point)
"""

l9a : Final[Field] = Field(
    name='l9a',
    origin='SMF71L9A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of available 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L9A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of available 1 MB frames in central storage (long floating point)
"""
l9a.__doc__ = """Average number of available 1 MB frames in central storage (long floating point)

SMF Info
--------
    Field: `SMF71L9A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of available 1 MB frames in central storage (long floating point)
"""

l10m : Final[Field] = Field(
    name='l10m',
    origin='SMF71L10M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 1 MB frames that are in-use by memory objects (long floating point)

SMF Info
--------
    Field: `SMF71L10M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB frames that are in-use by memory objects (long floating point)
"""
l10m.__doc__ = """Minimum number of 1 MB frames that are in-use by memory objects (long floating point)

SMF Info
--------
    Field: `SMF71L10M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 1 MB frames that are in-use by memory objects (long floating point)
"""

l10x : Final[Field] = Field(
    name='l10x',
    origin='SMF71L10X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 1 MB frames that are in-use by memory objects (long floating point)

SMF Info
--------
    Field: `SMF71L10X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB frames that are in-use by memory objects (long floating point)
"""
l10x.__doc__ = """Maximum number of 1 MB frames that are in-use by memory objects (long floating point)

SMF Info
--------
    Field: `SMF71L10X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 1 MB frames that are in-use by memory objects (long floating point)
"""

l10a : Final[Field] = Field(
    name='l10a',
    origin='SMF71L10A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 1 MB frames that are in-use by memory objects (long floating point)

SMF Info
--------
    Field: `SMF71L10A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB frames that are in-use by memory objects (long floating point)
"""
l10a.__doc__ = """Average number of 1 MB frames that are in-use by memory objects (long floating point)

SMF Info
--------
    Field: `SMF71L10A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 1 MB frames that are in-use by memory objects (long floating point)
"""

m6c : Final[Field] = Field(
    name='m6c',
    origin='SMF71M6C',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6C`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of frames backing 64-bit shared page groups (long floating point)
"""
m6c.__doc__ = """Minimum number of frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6C`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of frames backing 64-bit shared page groups (long floating point)
"""

x6c : Final[Field] = Field(
    name='x6c',
    origin='SMF71X6C',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6C`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of frames backing 64-bit shared page groups (long floating point)
"""
x6c.__doc__ = """Maximum number of frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6C`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of frames backing 64-bit shared page groups (long floating point)
"""

a6c : Final[Field] = Field(
    name='a6c',
    origin='SMF71A6C',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6C`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of frames backing 64-bit shared page groups (long floating point)
"""
a6c.__doc__ = """Average number of frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6C`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of frames backing 64-bit shared page groups (long floating point)
"""

m6f : Final[Field] = Field(
    name='m6f',
    origin='SMF71M6F',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of fixed frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6F`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed frames backing 64-bit shared page groups (long floating point)
"""
m6f.__doc__ = """Minimum number of fixed frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6F`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of fixed frames backing 64-bit shared page groups (long floating point)
"""

x6f : Final[Field] = Field(
    name='x6f',
    origin='SMF71X6F',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of fixed frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6F`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of fixed frames backing 64-bit shared page groups (long floating point)
"""
x6f.__doc__ = """Maximum number of fixed frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6F`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of fixed frames backing 64-bit shared page groups (long floating point)
"""

a6f : Final[Field] = Field(
    name='a6f',
    origin='SMF71A6F',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of fixed frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6F`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of fixed frames backing 64-bit shared page groups (long floating point)
"""
a6f.__doc__ = """Average number of fixed frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6F`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of fixed frames backing 64-bit shared page groups (long floating point)
"""

m6b : Final[Field] = Field(
    name='m6b',
    origin='SMF71M6B',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 24-bit frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6B`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 24-bit frames backing 64-bit shared page groups (long floating point)
"""
m6b.__doc__ = """Minimum number of 24-bit frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6B`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 24-bit frames backing 64-bit shared page groups (long floating point)
"""

x6b : Final[Field] = Field(
    name='x6b',
    origin='SMF71X6B',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 24-bit frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6B`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 24-bit frames backing 64-bit shared page groups (long floating point)
"""
x6b.__doc__ = """Maximum number of 24-bit frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6B`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 24-bit frames backing 64-bit shared page groups (long floating point)
"""

a6b : Final[Field] = Field(
    name='a6b',
    origin='SMF71A6B',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 24-bit frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6B`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 24-bit frames backing 64-bit shared page groups (long floating point)
"""
a6b.__doc__ = """Average number of 24-bit frames backing 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6B`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 24-bit frames backing 64-bit shared page groups (long floating point)
"""

m6a : Final[Field] = Field(
    name='m6a',
    origin='SMF71M6A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)
"""
m6a.__doc__ = """Minimum number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)
"""

x6a : Final[Field] = Field(
    name='x6a',
    origin='SMF71X6A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)
"""
x6a.__doc__ = """Maximum number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)
"""

a6a : Final[Field] = Field(
    name='a6a',
    origin='SMF71A6A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)
"""
a6a.__doc__ = """Average number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of auxiliary DASD slots used to back 64-bit shared page groups (long floating point)
"""

m6s : Final[Field] = Field(
    name='m6s',
    origin='SMF71M6S',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of SCM blocks used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6S`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of SCM blocks used to back 64-bit shared page groups (long floating point)
"""
m6s.__doc__ = """Minimum number of SCM blocks used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71M6S`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of SCM blocks used to back 64-bit shared page groups (long floating point)
"""

x6s : Final[Field] = Field(
    name='x6s',
    origin='SMF71X6S',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of SCM blocks used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6S`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of SCM blocks used to back 64-bit shared page groups (long floating point)
"""
x6s.__doc__ = """Maximum number of SCM blocks used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71X6S`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of SCM blocks used to back 64-bit shared page groups (long floating point)
"""

a6s : Final[Field] = Field(
    name='a6s',
    origin='SMF71A6S',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of SCM blocks used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6S`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of SCM blocks used to back 64-bit shared page groups (long floating point)
"""
a6s.__doc__ = """Average number of SCM blocks used to back 64-bit shared page groups (long floating point)

SMF Info
--------
    Field: `SMF71A6S`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of SCM blocks used to back 64-bit shared page groups (long floating point)
"""

m6t : Final[Field] = Field(
    name='m6t',
    origin='SMF71M6T',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of 64-bit shared page groups in the system (long floating point)

SMF Info
--------
    Field: `SMF71M6T`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 64-bit shared page groups in the system (long floating point)
"""
m6t.__doc__ = """Minimum number of 64-bit shared page groups in the system (long floating point)

SMF Info
--------
    Field: `SMF71M6T`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of 64-bit shared page groups in the system (long floating point)
"""

x6t : Final[Field] = Field(
    name='x6t',
    origin='SMF71X6T',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of 64-bit shared page groups in the system (long floating point)

SMF Info
--------
    Field: `SMF71X6T`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 64-bit shared page groups in the system (long floating point)
"""
x6t.__doc__ = """Maximum number of 64-bit shared page groups in the system (long floating point)

SMF Info
--------
    Field: `SMF71X6T`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of 64-bit shared page groups in the system (long floating point)
"""

a6t : Final[Field] = Field(
    name='a6t',
    origin='SMF71A6T',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of 64-bit shared page groups in the system (long floating point)

SMF Info
--------
    Field: `SMF71A6T`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 64-bit shared page groups in the system (long floating point)
"""
a6t.__doc__ = """Average number of 64-bit shared page groups in the system (long floating point)

SMF Info
--------
    Field: `SMF71A6T`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of 64-bit shared page groups in the system (long floating point)
"""

dmemassignable2g : Final[Field] = Field(
    name='dmemassignable2g',
    origin='SMF71_DMEMASSIGNABLE2G',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Total amount of dedicated memory at system initialization that can be used by address spaces in 2G units. Note: This field does not include dedicated memory used by the system. (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMASSIGNABLE2G`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Total amount of dedicated memory at system initialization that can be used by address spaces in 2G units. Note: This field does not include dedicated memory used by the system. (long floating point)
"""
dmemassignable2g.__doc__ = """Total amount of dedicated memory at system initialization that can be used by address spaces in 2G units. Note: This field does not include dedicated memory used by the system. (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMASSIGNABLE2G`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Total amount of dedicated memory at system initialization that can be used by address spaces in 2G units. Note: This field does not include dedicated memory used by the system. (long floating point)
"""

dmemnumberofjobsusingdmem_m : Final[Field] = Field(
    name='dmemnumberofjobsusingdmem_m',
    origin='SMF71_DMEMNUMBEROFJOBSUSINGDMEM_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of address spaces using dedicated memory (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMNUMBEROFJOBSUSINGDMEM_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of address spaces using dedicated memory (long floating point)
"""
dmemnumberofjobsusingdmem_m.__doc__ = """Minimum number of address spaces using dedicated memory (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMNUMBEROFJOBSUSINGDMEM_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of address spaces using dedicated memory (long floating point)
"""

dmemnumberofjobsusingdmem_x : Final[Field] = Field(
    name='dmemnumberofjobsusingdmem_x',
    origin='SMF71_DMEMNUMBEROFJOBSUSINGDMEM_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of address spaces using dedicated memory (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMNUMBEROFJOBSUSINGDMEM_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of address spaces using dedicated memory (long floating point)
"""
dmemnumberofjobsusingdmem_x.__doc__ = """Maximum number of address spaces using dedicated memory (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMNUMBEROFJOBSUSINGDMEM_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of address spaces using dedicated memory (long floating point)
"""

dmemnumberofjobsusingdmem_a : Final[Field] = Field(
    name='dmemnumberofjobsusingdmem_a',
    origin='SMF71_DMEMNUMBEROFJOBSUSINGDMEM_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of address spaces using dedicated memory (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMNUMBEROFJOBSUSINGDMEM_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of address spaces using dedicated memory (long floating point)
"""
dmemnumberofjobsusingdmem_a.__doc__ = """Average number of address spaces using dedicated memory (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMNUMBEROFJOBSUSINGDMEM_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of address spaces using dedicated memory (long floating point)
"""

dmemtotal2g_m : Final[Field] = Field(
    name='dmemtotal2g_m',
    origin='SMF71_DMEMTOTAL2G_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTAL2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""
dmemtotal2g_m.__doc__ = """Minimum amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTAL2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""

dmemtotal2g_x : Final[Field] = Field(
    name='dmemtotal2g_x',
    origin='SMF71_DMEMTOTAL2G_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTAL2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""
dmemtotal2g_x.__doc__ = """Maximum amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTAL2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""

dmemtotal2g_a : Final[Field] = Field(
    name='dmemtotal2g_a',
    origin='SMF71_DMEMTOTAL2G_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTAL2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""
dmemtotal2g_a.__doc__ = """Average amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTAL2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of online and offline dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""

dmemtotalonline2g_m : Final[Field] = Field(
    name='dmemtotalonline2g_m',
    origin='SMF71_DMEMTOTALONLINE2G_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTALONLINE2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""
dmemtotalonline2g_m.__doc__ = """Minimum amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTALONLINE2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""

dmemtotalonline2g_x : Final[Field] = Field(
    name='dmemtotalonline2g_x',
    origin='SMF71_DMEMTOTALONLINE2G_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTALONLINE2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""
dmemtotalonline2g_x.__doc__ = """Maximum amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTALONLINE2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""

dmemtotalonline2g_a : Final[Field] = Field(
    name='dmemtotalonline2g_a',
    origin='SMF71_DMEMTOTALONLINE2G_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTALONLINE2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""
dmemtotalonline2g_a.__doc__ = """Average amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMTOTALONLINE2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of online dedicated memory in 2G units, including dedicated memory used by the system (long floating point)
"""

dmemavailable2g_m : Final[Field] = Field(
    name='dmemavailable2g_m',
    origin='SMF71_DMEMAVAILABLE2G_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMAVAILABLE2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)
"""
dmemavailable2g_m.__doc__ = """Minimum amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMAVAILABLE2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)
"""

dmemavailable2g_x : Final[Field] = Field(
    name='dmemavailable2g_x',
    origin='SMF71_DMEMAVAILABLE2G_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMAVAILABLE2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)
"""
dmemavailable2g_x.__doc__ = """Maximum amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMAVAILABLE2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)
"""

dmemavailable2g_a : Final[Field] = Field(
    name='dmemavailable2g_a',
    origin='SMF71_DMEMAVAILABLE2G_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMAVAILABLE2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)
"""
dmemavailable2g_a.__doc__ = """Average amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMAVAILABLE2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of available dedicated memory in 2G units that can be used by address spaces (long floating point)
"""

dmemrequested2g_m : Final[Field] = Field(
    name='dmemrequested2g_m',
    origin='SMF71_DMEMREQUESTED2G_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMREQUESTED2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""
dmemrequested2g_m.__doc__ = """Minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMREQUESTED2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""

dmemrequested2g_x : Final[Field] = Field(
    name='dmemrequested2g_x',
    origin='SMF71_DMEMREQUESTED2G_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMREQUESTED2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""
dmemrequested2g_x.__doc__ = """Maximum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMREQUESTED2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""

dmemrequested2g_a : Final[Field] = Field(
    name='dmemrequested2g_a',
    origin='SMF71_DMEMREQUESTED2G_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMREQUESTED2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""
dmemrequested2g_a.__doc__ = """Average amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMREQUESTED2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""

dmemminrequested2g_m : Final[Field] = Field(
    name='dmemminrequested2g_m',
    origin='SMF71_DMEMMINREQUESTED2G_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Lowest minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMMINREQUESTED2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""
dmemminrequested2g_m.__doc__ = """Lowest minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMMINREQUESTED2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Lowest minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""

dmemminrequested2g_x : Final[Field] = Field(
    name='dmemminrequested2g_x',
    origin='SMF71_DMEMMINREQUESTED2G_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Highest minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMMINREQUESTED2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""
dmemminrequested2g_x.__doc__ = """Highest minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMMINREQUESTED2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Highest minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""

dmemminrequested2g_a : Final[Field] = Field(
    name='dmemminrequested2g_a',
    origin='SMF71_DMEMMINREQUESTED2G_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMMINREQUESTED2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""
dmemminrequested2g_a.__doc__ = """Average minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMMINREQUESTED2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average minimum amount of requested dedicated memory in 2G units over all address spaces (long floating point)
"""

dmemassigned2g_m : Final[Field] = Field(
    name='dmemassigned2g_m',
    origin='SMF71_DMEMASSIGNED2G_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum amount of assigned dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMASSIGNED2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of assigned dedicated memory in 2G units over all address spaces (long floating point)
"""
dmemassigned2g_m.__doc__ = """Minimum amount of assigned dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMASSIGNED2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of assigned dedicated memory in 2G units over all address spaces (long floating point)
"""

dmemassigned2g_x : Final[Field] = Field(
    name='dmemassigned2g_x',
    origin='SMF71_DMEMASSIGNED2G_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum amount of assigned dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMASSIGNED2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of assigned dedicated memory in 2G units over all address spaces (long floating point)
"""
dmemassigned2g_x.__doc__ = """Maximum amount of assigned dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMASSIGNED2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of assigned dedicated memory in 2G units over all address spaces (long floating point)
"""

dmemassigned2g_a : Final[Field] = Field(
    name='dmemassigned2g_a',
    origin='SMF71_DMEMASSIGNED2G_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average amount of assigned dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMASSIGNED2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of assigned dedicated memory in 2G units over all address spaces (long floating point)
"""
dmemassigned2g_a.__doc__ = """Average amount of assigned dedicated memory in 2G units over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMASSIGNED2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of assigned dedicated memory in 2G units over all address spaces (long floating point)
"""

dmeminuseas2g_m : Final[Field] = Field(
    name='dmeminuseas2g_m',
    origin='SMF71_DMEMINUSEAS2G_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum amount of dedicated memory used as 2G frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of dedicated memory used as 2G frames over all address spaces (long floating point)
"""
dmeminuseas2g_m.__doc__ = """Minimum amount of dedicated memory used as 2G frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS2G_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of dedicated memory used as 2G frames over all address spaces (long floating point)
"""

dmeminuseas2g_x : Final[Field] = Field(
    name='dmeminuseas2g_x',
    origin='SMF71_DMEMINUSEAS2G_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum amount of dedicated memory used as 2G frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of dedicated memory used as 2G frames over all address spaces (long floating point)
"""
dmeminuseas2g_x.__doc__ = """Maximum amount of dedicated memory used as 2G frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS2G_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of dedicated memory used as 2G frames over all address spaces (long floating point)
"""

dmeminuseas2g_a : Final[Field] = Field(
    name='dmeminuseas2g_a',
    origin='SMF71_DMEMINUSEAS2G_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average amount of dedicated memory used as 2G frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of dedicated memory used as 2G frames over all address spaces (long floating point)
"""
dmeminuseas2g_a.__doc__ = """Average amount of dedicated memory used as 2G frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS2G_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of dedicated memory used as 2G frames over all address spaces (long floating point)
"""

dmeminuseas1mfixed_m : Final[Field] = Field(
    name='dmeminuseas1mfixed_m',
    origin='SMF71_DMEMINUSEAS1MFIXED_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MFIXED_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)
"""
dmeminuseas1mfixed_m.__doc__ = """Minimum amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MFIXED_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)
"""

dmeminuseas1mfixed_x : Final[Field] = Field(
    name='dmeminuseas1mfixed_x',
    origin='SMF71_DMEMINUSEAS1MFIXED_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MFIXED_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)
"""
dmeminuseas1mfixed_x.__doc__ = """Maximum amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MFIXED_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)
"""

dmeminuseas1mfixed_a : Final[Field] = Field(
    name='dmeminuseas1mfixed_a',
    origin='SMF71_DMEMINUSEAS1MFIXED_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MFIXED_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)
"""
dmeminuseas1mfixed_a.__doc__ = """Average amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MFIXED_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of dedicated memory used as 1M fixed frames over all address spaces (long floating point)
"""

dmeminuseas1mpageable_m : Final[Field] = Field(
    name='dmeminuseas1mpageable_m',
    origin='SMF71_DMEMINUSEAS1MPAGEABLE_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MPAGEABLE_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)
"""
dmeminuseas1mpageable_m.__doc__ = """Minimum amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MPAGEABLE_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)
"""

dmeminuseas1mpageable_x : Final[Field] = Field(
    name='dmeminuseas1mpageable_x',
    origin='SMF71_DMEMINUSEAS1MPAGEABLE_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MPAGEABLE_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)
"""
dmeminuseas1mpageable_x.__doc__ = """Maximum amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MPAGEABLE_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)
"""

dmeminuseas1mpageable_a : Final[Field] = Field(
    name='dmeminuseas1mpageable_a',
    origin='SMF71_DMEMINUSEAS1MPAGEABLE_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MPAGEABLE_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)
"""
dmeminuseas1mpageable_a.__doc__ = """Average amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS1MPAGEABLE_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of dedicated memory used as 1M pageable frames over all address spaces (long floating point)
"""

dmeminuseas4k_m : Final[Field] = Field(
    name='dmeminuseas4k_m',
    origin='SMF71_DMEMINUSEAS4K_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum amount of dedicated memory used as 4K frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS4K_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of dedicated memory used as 4K frames over all address spaces (long floating point)
"""
dmeminuseas4k_m.__doc__ = """Minimum amount of dedicated memory used as 4K frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS4K_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum amount of dedicated memory used as 4K frames over all address spaces (long floating point)
"""

dmeminuseas4k_x : Final[Field] = Field(
    name='dmeminuseas4k_x',
    origin='SMF71_DMEMINUSEAS4K_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum amount of dedicated memory used as 4K frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS4K_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of dedicated memory used as 4K frames over all address spaces (long floating point)
"""
dmeminuseas4k_x.__doc__ = """Maximum amount of dedicated memory used as 4K frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS4K_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum amount of dedicated memory used as 4K frames over all address spaces (long floating point)
"""

dmeminuseas4k_a : Final[Field] = Field(
    name='dmeminuseas4k_a',
    origin='SMF71_DMEMINUSEAS4K_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average amount of dedicated memory used as 4K frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS4K_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of dedicated memory used as 4K frames over all address spaces (long floating point)
"""
dmeminuseas4k_a.__doc__ = """Average amount of dedicated memory used as 4K frames over all address spaces (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEAS4K_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average amount of dedicated memory used as 4K frames over all address spaces (long floating point)
"""

dmeminuseasdattables4k_m : Final[Field] = Field(
    name='dmeminuseasdattables4k_m',
    origin='SMF71_DMEMINUSEASDATTABLES4K_M',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Minimum number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEASDATTABLES4K_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)
"""
dmeminuseasdattables4k_m.__doc__ = """Minimum number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEASDATTABLES4K_M`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Minimum number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)
"""

dmeminuseasdattables4k_x : Final[Field] = Field(
    name='dmeminuseasdattables4k_x',
    origin='SMF71_DMEMINUSEASDATTABLES4K_X',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Maximum number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEASDATTABLES4K_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)
"""
dmeminuseasdattables4k_x.__doc__ = """Maximum number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEASDATTABLES4K_X`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Maximum number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)
"""

dmeminuseasdattables4k_a : Final[Field] = Field(
    name='dmeminuseasdattables4k_a',
    origin='SMF71_DMEMINUSEASDATTABLES4K_A',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF71PAG,
)
"""Average number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEASDATTABLES4K_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)
"""
dmeminuseasdattables4k_a.__doc__ = """Average number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)

SMF Info
--------
    Field: `SMF71_DMEMINUSEASDATTABLES4K_A`
    Record: `SMF71S1`
    Map: `SMF71PAG`

Average number of dedicated memory frames in 4K units backing DAT tables (system use) (long floating point)
"""
