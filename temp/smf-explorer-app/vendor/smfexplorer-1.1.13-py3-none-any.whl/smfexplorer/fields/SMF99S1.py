# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 99 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=99,
                                smf_subtype=1,
                                spec='SMF 99 Subtype 1',
                                post=None)
"""SMF 99 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF99_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_SDEF_MAP',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 self defining Section',
    post=None,
    record_mapping=False)
"""SMF99 self defining Section"""
SMF99_PRODUCT_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_PRODUCT_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Product Information Section',
    post=None,
    record_mapping=False)
"""SMF99 Product Information Section"""
SMF99_S1_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_SDEF_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Subtype 1 self defining section',
    post=None,
    record_mapping=False)
"""SMF99 Subtype 1 self defining section"""
SMF99_S1_SS_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_SS_MAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='System State Information',
    post=None,
    record_mapping=False)
"""System State Information"""
SMF99_S1_PP_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_PP_MAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Subtype1 Paging Plot Information Section',
    post=None,
    record_mapping=False)
"""SMF99 Subtype1 Paging Plot Information Section"""
SMF99_S1_SL_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_SL_MAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 subtype 1 Software Licensing Infor mation - Contains information...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 Software Licensing Infor mation - Contains information..."""
SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_PP_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_ONE_CURVE_POINT_MAP',
    record=record,
    parent=SMF99_S1_PP_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1, 3, and 5 - map to format points on a plot with one cu...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1, 3, and 5 - map to format points on a plot with one cu..."""
SMF99_S1_BP_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_BP_MAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 subtype 1 Buffer Pool Information (internal use by IBM) BASED (a...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 Buffer Pool Information (internal use by IBM) BASED (a..."""
SMF99_S1_AAT_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_AAT_MAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1 trace table entry - The trace table contains informati...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 trace table entry - The trace table contains informati..."""
PRIORITY_TABLE_ENTRY_SECTION: Final[RecordMap] = RecordMap(
    origin='PRIORITY_TABLE_ENTRY_SECTION',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1 Priority table entries for CP',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 Priority table entries for CP"""
SMF99_S1_RG_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_RG_MAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1 Resource Group entry - Contains information about reso...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 Resource Group entry - Contains information about reso..."""
SMF99_S1_GR_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_GR_MAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1 Generic Resource entry - Contains information about Ge...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 Generic Resource entry - Contains information about Ge..."""
SMF99_S1_SLT_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_SLT_MAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1 Software Licensing table Information - Contains inform...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 Software Licensing table Information - Contains inform..."""
PRIORITY_TABLE_ENTRY_SECTION_ZAAP: Final[RecordMap] = RecordMap(
    origin='PRIORITY_TABLE_ENTRY_SECTION_ZAAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1 Priority table entries for ZAAP',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 Priority table entries for ZAAP"""
SMF99_S1_ZE_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S1_ZE_MAP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1 zIIP Entitlement Information BASED(addr(smf_hdr_MAP) +...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 zIIP Entitlement Information BASED(addr(smf_hdr_MAP) +..."""
PRIORITY_TABLE_ENTRY_SECTION_ZIIP: Final[RecordMap] = RecordMap(
    origin='PRIORITY_TABLE_ENTRY_SECTION_ZIIP',
    record=record,
    parent=SMF99_S1_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1 Priority table entries for ZIIP',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1 Priority table entries for ZIIP"""
SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_BP_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_ONE_CURVE_POINT_MAP',
    record=record,
    parent=SMF99_S1_BP_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 1, 3, and 5 - map to format points on a plot with one cu...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 1, 3, and 5 - map to format points on a plot with one cu..."""

date : Final[Field] = Field(
    name='date',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF99LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S1`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""
len.__doc__ = """Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S1`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF99SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S1`
    Map: Not part of a map

Segment descriptor (see record length field)
"""
seg.__doc__ = """Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S1`
    Map: Not part of a map

Segment descriptor (see record length field)
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF99FLG',
    type=FieldType.STRING,
    record=record,
)
"""System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S1`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""
flg.__doc__ = """System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S1`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""

stu : Final[Field] = Field(
    name='stu',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S1`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
stu.__doc__ = """Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S1`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF99RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S1`
    Map: Not part of a map

Record type 99
"""
rty.__doc__ = """Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S1`
    Map: Not part of a map

Record type 99
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S1`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""
tme.__doc__ = """Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S1`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S1`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""
dte.__doc__ = """Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S1`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF99SID',
    type=FieldType.STRING,
    record=record,
)
"""System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S1`
    Map: Not part of a map

System identification (from the SID parameter).
"""
sid.__doc__ = """System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S1`
    Map: Not part of a map

System identification (from the SID parameter).
"""

ssid : Final[Field] = Field(
    name='ssid',
    origin='SMF99SSID',
    type=FieldType.STRING,
    record=record,
)
"""Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S1`
    Map: Not part of a map

Sub System Identification
"""
ssid.__doc__ = """Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S1`
    Map: Not part of a map

Sub System Identification
"""

tid : Final[Field] = Field(
    name='tid',
    origin='SMF99TID',
    type=FieldType.INTEGER,
    record=record,
)
"""Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S1`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""
tid.__doc__ = """Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S1`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""

sdef_len : Final[Field] = Field(
    name='sdef_len',
    origin='SMF99_SDEF_LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S1`
    Map: Not part of a map

Length of self definition section
"""
sdef_len.__doc__ = """Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S1`
    Map: Not part of a map

Length of self definition section
"""

pof : Final[Field] = Field(
    name='pof',
    origin='SMF99POF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""
pof.__doc__ = """Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""

pln : Final[Field] = Field(
    name='pln',
    origin='SMF99PLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""
pln.__doc__ = """Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""

pon : Final[Field] = Field(
    name='pon',
    origin='SMF99PON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""
pon.__doc__ = """Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""

dof : Final[Field] = Field(
    name='dof',
    origin='SMF99DOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""
dof.__doc__ = """Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""

dln : Final[Field] = Field(
    name='dln',
    origin='SMF99DLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""
dln.__doc__ = """Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""

don : Final[Field] = Field(
    name='don',
    origin='SMF99DON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""
don.__doc__ = """Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S1`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""

vn2 : Final[Field] = Field(
    name='vn2',
    origin='SMF99VN2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""
vn2.__doc__ = """Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""

rvn : Final[Field] = Field(
    name='rvn',
    origin='SMF99RVN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""
rvn.__doc__ = """Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""

pnm : Final[Field] = Field(
    name='pnm',
    origin='SMF99PNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""
pnm.__doc__ = """Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""

slv : Final[Field] = Field(
    name='slv',
    origin='SMF99SLV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""
slv.__doc__ = """System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF99SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""
snm.__doc__ = """System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""

pflg : Final[Field] = Field(
    name='pflg',
    origin='SMF99PFLG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""
pflg.__doc__ = """Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""

record_incomplete : Final[Field] = Field(
    name='record_incomplete',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
record_incomplete.__doc__ = """Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

reasm_indicator : Final[Field] = Field(
    name='reasm_indicator',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
reasm_indicator.__doc__ = """Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S1`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

tof : Final[Field] = Field(
    name='tof',
    origin='SMF99TOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the trace section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99TOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the trace section from the beginning of the record (including RDW).
"""
tof.__doc__ = """Offset to the trace section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99TOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the trace section from the beginning of the record (including RDW).
"""

tln : Final[Field] = Field(
    name='tln',
    origin='SMF99TLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the trace section

SMF Info
--------
    Field: `SMF99TLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the trace section
"""
tln.__doc__ = """Length of the trace section

SMF Info
--------
    Field: `SMF99TLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the trace section
"""

ton : Final[Field] = Field(
    name='ton',
    origin='SMF99TON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of trace sections

SMF Info
--------
    Field: `SMF99TON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of trace sections
"""
ton.__doc__ = """Number of trace sections

SMF Info
--------
    Field: `SMF99TON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of trace sections
"""

ssof : Final[Field] = Field(
    name='ssof',
    origin='SMF99SSOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the System state section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99SSOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the System state section from the beginning of the record (including RDW).
"""
ssof.__doc__ = """Offset to the System state section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99SSOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the System state section from the beginning of the record (including RDW).
"""

ssln : Final[Field] = Field(
    name='ssln',
    origin='SMF99SSLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the System state section

SMF Info
--------
    Field: `SMF99SSLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the System state section
"""
ssln.__doc__ = """Length of the System state section

SMF Info
--------
    Field: `SMF99SSLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the System state section
"""

sson : Final[Field] = Field(
    name='sson',
    origin='SMF99SSON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of system state sections

SMF Info
--------
    Field: `SMF99SSON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of system state sections
"""
sson.__doc__ = """Number of system state sections

SMF Info
--------
    Field: `SMF99SSON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of system state sections
"""

ppof : Final[Field] = Field(
    name='ppof',
    origin='SMF99PPOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the Paging plot section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99PPOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Paging plot section from the beginning of the record (including RDW).
"""
ppof.__doc__ = """Offset to the Paging plot section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99PPOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Paging plot section from the beginning of the record (including RDW).
"""

ppln : Final[Field] = Field(
    name='ppln',
    origin='SMF99PPLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the Paging plot section

SMF Info
--------
    Field: `SMF99PPLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Paging plot section
"""
ppln.__doc__ = """Length of the Paging plot section

SMF Info
--------
    Field: `SMF99PPLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Paging plot section
"""

ppon : Final[Field] = Field(
    name='ppon',
    origin='SMF99PPON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of paging plot sections

SMF Info
--------
    Field: `SMF99PPON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of paging plot sections
"""
ppon.__doc__ = """Number of paging plot sections

SMF Info
--------
    Field: `SMF99PPON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of paging plot sections
"""

ptof : Final[Field] = Field(
    name='ptof',
    origin='SMF99PTOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the Priority table section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99PTOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Priority table section from the beginning of the record (including RDW).
"""
ptof.__doc__ = """Offset to the Priority table section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99PTOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Priority table section from the beginning of the record (including RDW).
"""

ptln : Final[Field] = Field(
    name='ptln',
    origin='SMF99PTLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the Priority table section

SMF Info
--------
    Field: `SMF99PTLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Priority table section
"""
ptln.__doc__ = """Length of the Priority table section

SMF Info
--------
    Field: `SMF99PTLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Priority table section
"""

pton : Final[Field] = Field(
    name='pton',
    origin='SMF99PTON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of Priority table sections

SMF Info
--------
    Field: `SMF99PTON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of Priority table sections
"""
pton.__doc__ = """Number of Priority table sections

SMF Info
--------
    Field: `SMF99PTON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of Priority table sections
"""

rgof : Final[Field] = Field(
    name='rgof',
    origin='SMF99RGOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the Resource Group section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99RGOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Resource Group section from the beginning of the record (including RDW).
"""
rgof.__doc__ = """Offset to the Resource Group section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99RGOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Resource Group section from the beginning of the record (including RDW).
"""

rgln : Final[Field] = Field(
    name='rgln',
    origin='SMF99RGLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the resource group section

SMF Info
--------
    Field: `SMF99RGLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the resource group section
"""
rgln.__doc__ = """Length of the resource group section

SMF Info
--------
    Field: `SMF99RGLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the resource group section
"""

rgon : Final[Field] = Field(
    name='rgon',
    origin='SMF99RGON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of resource group sections

SMF Info
--------
    Field: `SMF99RGON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of resource group sections
"""
rgon.__doc__ = """Number of resource group sections

SMF Info
--------
    Field: `SMF99RGON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of resource group sections
"""

grof : Final[Field] = Field(
    name='grof',
    origin='SMF99GROF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the generic resouce section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99GROF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the generic resouce section from the beginning of the record (including RDW).
"""
grof.__doc__ = """Offset to the generic resouce section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99GROF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the generic resouce section from the beginning of the record (including RDW).
"""

grln : Final[Field] = Field(
    name='grln',
    origin='SMF99GRLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the generic resource section

SMF Info
--------
    Field: `SMF99GRLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the generic resource section
"""
grln.__doc__ = """Length of the generic resource section

SMF Info
--------
    Field: `SMF99GRLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the generic resource section
"""

gron : Final[Field] = Field(
    name='gron',
    origin='SMF99GRON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of generic resource sections

SMF Info
--------
    Field: `SMF99GRON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of generic resource sections
"""
gron.__doc__ = """Number of generic resource sections

SMF Info
--------
    Field: `SMF99GRON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of generic resource sections
"""

slof : Final[Field] = Field(
    name='slof',
    origin='SMF99SLOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the software licensing section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99SLOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the software licensing section from the beginning of the record (including RDW).
"""
slof.__doc__ = """Offset to the software licensing section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99SLOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the software licensing section from the beginning of the record (including RDW).
"""

slln : Final[Field] = Field(
    name='slln',
    origin='SMF99SLLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the software licensing section

SMF Info
--------
    Field: `SMF99SLLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the software licensing section
"""
slln.__doc__ = """Length of the software licensing section

SMF Info
--------
    Field: `SMF99SLLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the software licensing section
"""

slon : Final[Field] = Field(
    name='slon',
    origin='SMF99SLON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of software licensing sections

SMF Info
--------
    Field: `SMF99SLON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of software licensing sections
"""
slon.__doc__ = """Number of software licensing sections

SMF Info
--------
    Field: `SMF99SLON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of software licensing sections
"""

sltof : Final[Field] = Field(
    name='sltof',
    origin='SMF99SLTOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the software licensing service table section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99SLTOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the software licensing service table section from the beginning of the record (including RDW).
"""
sltof.__doc__ = """Offset to the software licensing service table section from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99SLTOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the software licensing service table section from the beginning of the record (including RDW).
"""

sltln : Final[Field] = Field(
    name='sltln',
    origin='SMF99SLTLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the software licensing service table section

SMF Info
--------
    Field: `SMF99SLTLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the software licensing service table section
"""
sltln.__doc__ = """Length of the software licensing service table section

SMF Info
--------
    Field: `SMF99SLTLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the software licensing service table section
"""

slton : Final[Field] = Field(
    name='slton',
    origin='SMF99SLTON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of software licensing service table sections

SMF Info
--------
    Field: `SMF99SLTON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of software licensing service table sections
"""
slton.__doc__ = """Number of software licensing service table sections

SMF Info
--------
    Field: `SMF99SLTON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of software licensing service table sections
"""

piof : Final[Field] = Field(
    name='piof',
    origin='SMF99PIOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the Priority table section (IFA) from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99PIOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Priority table section (IFA) from the beginning of the record (including RDW).
"""
piof.__doc__ = """Offset to the Priority table section (IFA) from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99PIOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Priority table section (IFA) from the beginning of the record (including RDW).
"""

piln : Final[Field] = Field(
    name='piln',
    origin='SMF99PILN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the Priority table section (IFA)

SMF Info
--------
    Field: `SMF99PILN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Priority table section (IFA)
"""
piln.__doc__ = """Length of the Priority table section (IFA)

SMF Info
--------
    Field: `SMF99PILN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Priority table section (IFA)
"""

pion : Final[Field] = Field(
    name='pion',
    origin='SMF99PION',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of Priority table sections (IFA)

SMF Info
--------
    Field: `SMF99PION`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of Priority table sections (IFA)
"""
pion.__doc__ = """Number of Priority table sections (IFA)

SMF Info
--------
    Field: `SMF99PION`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of Priority table sections (IFA)
"""

zeof : Final[Field] = Field(
    name='zeof',
    origin='SMF99ZEOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the zIIP Entitlement sections from the beginning of the record

SMF Info
--------
    Field: `SMF99ZEOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the zIIP Entitlement sections from the beginning of the record
"""
zeof.__doc__ = """Offset to the zIIP Entitlement sections from the beginning of the record

SMF Info
--------
    Field: `SMF99ZEOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the zIIP Entitlement sections from the beginning of the record
"""

zeln : Final[Field] = Field(
    name='zeln',
    origin='SMF99ZELN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of a zIIP Entitlement section

SMF Info
--------
    Field: `SMF99ZELN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of a zIIP Entitlement section
"""
zeln.__doc__ = """Length of a zIIP Entitlement section

SMF Info
--------
    Field: `SMF99ZELN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of a zIIP Entitlement section
"""

zeon : Final[Field] = Field(
    name='zeon',
    origin='SMF99ZEON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of zIIP Entitlement sections

SMF Info
--------
    Field: `SMF99ZEON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of zIIP Entitlement sections
"""
zeon.__doc__ = """Number of zIIP Entitlement sections

SMF Info
--------
    Field: `SMF99ZEON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of zIIP Entitlement sections
"""

psof : Final[Field] = Field(
    name='psof',
    origin='SMF99PSOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the Priority table section (SUP) from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99PSOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Priority table section (SUP) from the beginning of the record (including RDW).
"""
psof.__doc__ = """Offset to the Priority table section (SUP) from the beginning of the record (including RDW).

SMF Info
--------
    Field: `SMF99PSOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Priority table section (SUP) from the beginning of the record (including RDW).
"""

psln : Final[Field] = Field(
    name='psln',
    origin='SMF99PSLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the Priority table section (SUP)

SMF Info
--------
    Field: `SMF99PSLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Priority table section (SUP)
"""
psln.__doc__ = """Length of the Priority table section (SUP)

SMF Info
--------
    Field: `SMF99PSLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Priority table section (SUP)
"""

pson : Final[Field] = Field(
    name='pson',
    origin='SMF99PSON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of Priority table sections (SUP)

SMF Info
--------
    Field: `SMF99PSON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of Priority table sections (SUP)
"""
pson.__doc__ = """Number of Priority table sections (SUP)

SMF Info
--------
    Field: `SMF99PSON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of Priority table sections (SUP)
"""

bpof : Final[Field] = Field(
    name='bpof',
    origin='SMF99BPOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Offset to the Buffer Pool section (BP) from the beginning of the record

SMF Info
--------
    Field: `SMF99BPOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Buffer Pool section (BP) from the beginning of the record
"""
bpof.__doc__ = """Offset to the Buffer Pool section (BP) from the beginning of the record

SMF Info
--------
    Field: `SMF99BPOF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Offset to the Buffer Pool section (BP) from the beginning of the record
"""

bpln : Final[Field] = Field(
    name='bpln',
    origin='SMF99BPLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Length of the Buffer Pool section (BP)

SMF Info
--------
    Field: `SMF99BPLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Buffer Pool section (BP)
"""
bpln.__doc__ = """Length of the Buffer Pool section (BP)

SMF Info
--------
    Field: `SMF99BPLN`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Length of the Buffer Pool section (BP)
"""

bpon : Final[Field] = Field(
    name='bpon',
    origin='SMF99BPON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SDEF_MAP,
)
"""Number of Buffer Pool sections (BP)

SMF Info
--------
    Field: `SMF99BPON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of Buffer Pool sections (BP)
"""
bpon.__doc__ = """Number of Buffer Pool sections (BP)

SMF Info
--------
    Field: `SMF99BPON`
    Record: `SMF99S1`
    Map: `SMF99_S1_SDEF_MAP`

Number of Buffer Pool sections (BP)
"""

cp_util : Final[Field] = Field(
    name='cp_util',
    origin='SMF99_CPUA',
    post='core.scale',
    post_param=16.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Average utilization of regular CPs, scaled by 16

SMF Info
--------
    Field: `SMF99_CPUA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Average utilization of regular CPs, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16.0`
"""
cp_util.__doc__ = """Average utilization of regular CPs, scaled by 16

SMF Info
--------
    Field: `SMF99_CPUA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Average utilization of regular CPs, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16.0`
"""

ump : Final[Field] = Field(
    name='ump',
    origin='SMF99_UMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Recent unmanaged paging and swap cost percentage

SMF Info
--------
    Field: `SMF99_UMP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Recent unmanaged paging and swap cost percentage
"""
ump.__doc__ = """Recent unmanaged paging and swap cost percentage

SMF Info
--------
    Field: `SMF99_UMP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Recent unmanaged paging and swap cost percentage
"""

uic1 : Final[Field] = Field(
    name='uic1',
    origin='SMF99_UIC1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Frames in uic bucket 1 - The central and expanded UIC buckets contain a count of frames that have not been referenced for specified periods of time. So, UIC bucket 1 is a count of the frames that have most recently been referenced, where bucket 4 contains a count of the frames that have not been referenced in a long time. The UIC delimiter values specify the cutoff points for each bucket . For example,SMF99_EUIC3 will contain the count of all the expanded storage frames whose time since they were last referenced is between SMF99_ESTB2 and SMF99_ESTB3.

SMF Info
--------
    Field: `SMF99_UIC1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in uic bucket 1 - The central and expanded UIC buckets contain a count of frames that have not been referenced for specified periods of time. So, UIC bucket 1 is a count of the frames that have most recently been referenced, where bucket 4 contains a count of the frames that have not been referenced in a long time. The UIC delimiter values specify the cutoff points for each bucket . For example,SMF99_EUIC3 will contain the count of all the expanded storage frames whose time since they were last referenced is between SMF99_ESTB2 and SMF99_ESTB3.
"""
uic1.__doc__ = """Frames in uic bucket 1 - The central and expanded UIC buckets contain a count of frames that have not been referenced for specified periods of time. So, UIC bucket 1 is a count of the frames that have most recently been referenced, where bucket 4 contains a count of the frames that have not been referenced in a long time. The UIC delimiter values specify the cutoff points for each bucket . For example,SMF99_EUIC3 will contain the count of all the expanded storage frames whose time since they were last referenced is between SMF99_ESTB2 and SMF99_ESTB3.

SMF Info
--------
    Field: `SMF99_UIC1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in uic bucket 1 - The central and expanded UIC buckets contain a count of frames that have not been referenced for specified periods of time. So, UIC bucket 1 is a count of the frames that have most recently been referenced, where bucket 4 contains a count of the frames that have not been referenced in a long time. The UIC delimiter values specify the cutoff points for each bucket . For example,SMF99_EUIC3 will contain the count of all the expanded storage frames whose time since they were last referenced is between SMF99_ESTB2 and SMF99_ESTB3.
"""

uic2 : Final[Field] = Field(
    name='uic2',
    origin='SMF99_UIC2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Frames in uic bucket 2

SMF Info
--------
    Field: `SMF99_UIC2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in uic bucket 2
"""
uic2.__doc__ = """Frames in uic bucket 2

SMF Info
--------
    Field: `SMF99_UIC2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in uic bucket 2
"""

uic3 : Final[Field] = Field(
    name='uic3',
    origin='SMF99_UIC3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Frames in uic bucket 3

SMF Info
--------
    Field: `SMF99_UIC3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in uic bucket 3
"""
uic3.__doc__ = """Frames in uic bucket 3

SMF Info
--------
    Field: `SMF99_UIC3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in uic bucket 3
"""

uic4 : Final[Field] = Field(
    name='uic4',
    origin='SMF99_UIC4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Frames in uic bucket 4

SMF Info
--------
    Field: `SMF99_UIC4`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in uic bucket 4
"""
uic4.__doc__ = """Frames in uic bucket 4

SMF Info
--------
    Field: `SMF99_UIC4`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in uic bucket 4
"""

euic1 : Final[Field] = Field(
    name='euic1',
    origin='SMF99_EUIC1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Frames in Expanded uic bucket 1

SMF Info
--------
    Field: `SMF99_EUIC1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in Expanded uic bucket 1
"""
euic1.__doc__ = """Frames in Expanded uic bucket 1

SMF Info
--------
    Field: `SMF99_EUIC1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in Expanded uic bucket 1
"""

euic2 : Final[Field] = Field(
    name='euic2',
    origin='SMF99_EUIC2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Frames in Expanded uic bucket 2

SMF Info
--------
    Field: `SMF99_EUIC2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in Expanded uic bucket 2
"""
euic2.__doc__ = """Frames in Expanded uic bucket 2

SMF Info
--------
    Field: `SMF99_EUIC2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in Expanded uic bucket 2
"""

euic3 : Final[Field] = Field(
    name='euic3',
    origin='SMF99_EUIC3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Frames in Expanded uic bucket 3

SMF Info
--------
    Field: `SMF99_EUIC3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in Expanded uic bucket 3
"""
euic3.__doc__ = """Frames in Expanded uic bucket 3

SMF Info
--------
    Field: `SMF99_EUIC3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in Expanded uic bucket 3
"""

euic4 : Final[Field] = Field(
    name='euic4',
    origin='SMF99_EUIC4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Frames in Expanded uic bucket 4

SMF Info
--------
    Field: `SMF99_EUIC4`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in Expanded uic bucket 4
"""
euic4.__doc__ = """Frames in Expanded uic bucket 4

SMF Info
--------
    Field: `SMF99_EUIC4`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames in Expanded uic bucket 4
"""

frv1 : Final[Field] = Field(
    name='frv1',
    origin='SMF99_FRV1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""UIC delimiter value 1

SMF Info
--------
    Field: `SMF99_FRV1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

UIC delimiter value 1
"""
frv1.__doc__ = """UIC delimiter value 1

SMF Info
--------
    Field: `SMF99_FRV1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

UIC delimiter value 1
"""

frv2 : Final[Field] = Field(
    name='frv2',
    origin='SMF99_FRV2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""UIC delimiter value 2

SMF Info
--------
    Field: `SMF99_FRV2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

UIC delimiter value 2
"""
frv2.__doc__ = """UIC delimiter value 2

SMF Info
--------
    Field: `SMF99_FRV2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

UIC delimiter value 2
"""

frv3 : Final[Field] = Field(
    name='frv3',
    origin='SMF99_FRV3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""UIC delimiter value 3

SMF Info
--------
    Field: `SMF99_FRV3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

UIC delimiter value 3
"""
frv3.__doc__ = """UIC delimiter value 3

SMF Info
--------
    Field: `SMF99_FRV3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

UIC delimiter value 3
"""

estb1 : Final[Field] = Field(
    name='estb1',
    origin='SMF99_ESTB1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""expanded storage UIC delimiter value 1

SMF Info
--------
    Field: `SMF99_ESTB1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

expanded storage UIC delimiter value 1
"""
estb1.__doc__ = """expanded storage UIC delimiter value 1

SMF Info
--------
    Field: `SMF99_ESTB1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

expanded storage UIC delimiter value 1
"""

estb2 : Final[Field] = Field(
    name='estb2',
    origin='SMF99_ESTB2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""expanded storage UIC delimiter value 2

SMF Info
--------
    Field: `SMF99_ESTB2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

expanded storage UIC delimiter value 2
"""
estb2.__doc__ = """expanded storage UIC delimiter value 2

SMF Info
--------
    Field: `SMF99_ESTB2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

expanded storage UIC delimiter value 2
"""

estb3 : Final[Field] = Field(
    name='estb3',
    origin='SMF99_ESTB3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""expanded storage UIC delimiter value 3

SMF Info
--------
    Field: `SMF99_ESTB3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

expanded storage UIC delimiter value 3
"""
estb3.__doc__ = """expanded storage UIC delimiter value 3

SMF Info
--------
    Field: `SMF99_ESTB3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

expanded storage UIC delimiter value 3
"""

w2mig : Final[Field] = Field(
    name='w2mig',
    origin='SMF99_W2MIG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Write to migrate percentage

SMF Info
--------
    Field: `SMF99_W2MIG`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Write to migrate percentage
"""
w2mig.__doc__ = """Write to migrate percentage

SMF Info
--------
    Field: `SMF99_W2MIG`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Write to migrate percentage
"""

ptavail : Final[Field] = Field(
    name='ptavail',
    origin='SMF99_PTAVAIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Total processor time available, including captured time plus wait time

SMF Info
--------
    Field: `SMF99_PTAVAIL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Total processor time available, including captured time plus wait time
"""
ptavail.__doc__ = """Total processor time available, including captured time plus wait time

SMF Info
--------
    Field: `SMF99_PTAVAIL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Total processor time available, including captured time plus wait time
"""

short_flags : Final[Field] = Field(
    name='short_flags',
    origin='SMF99_SHORT_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""shortage flags

SMF Info
--------
    Field: `SMF99_SHORT_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

shortage flags
"""
short_flags.__doc__ = """shortage flags

SMF Info
--------
    Field: `SMF99_SHORT_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

shortage flags
"""

short : Final[Field] = Field(
    name='short',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=short_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Real storage shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Real storage shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
short.__doc__ = """Real storage shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Real storage shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

asm1 : Final[Field] = Field(
    name='asm1',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=short_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""First level Aux shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

First level Aux shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
asm1.__doc__ = """First level Aux shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

First level Aux shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

ams2 : Final[Field] = Field(
    name='ams2',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=short_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Critical Aux shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Critical Aux shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
ams2.__doc__ = """Critical Aux shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Critical Aux shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

sqa1 : Final[Field] = Field(
    name='sqa1',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=short_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""First level SQA shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

First level SQA shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
sqa1.__doc__ = """First level SQA shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

First level SQA shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

sqa2 : Final[Field] = Field(
    name='sqa2',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=short_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Critical SQA shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Critical SQA shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
sqa2.__doc__ = """Critical SQA shortage exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `short_flags`(`SMF99_SHORT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Critical SQA shortage exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

status_flags : Final[Field] = Field(
    name='status_flags',
    origin='SMF99_STATUS_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Status flags

SMF Info
--------
    Field: `SMF99_STATUS_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Status flags
"""
status_flags.__doc__ = """Status flags

SMF Info
--------
    Field: `SMF99_STATUS_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Status flags
"""

dcm_on : Final[Field] = Field(
    name='dcm_on',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=status_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Dynamic chpid management is active (using balance algorithm if SMF99_DCM_G OALALG_ON is off)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `status_flags`(`SMF99_STATUS_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Dynamic chpid management is active (using balance algorithm if SMF99_DCM_G OALALG_ON is off)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
dcm_on.__doc__ = """Dynamic chpid management is active (using balance algorithm if SMF99_DCM_G OALALG_ON is off)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `status_flags`(`SMF99_STATUS_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Dynamic chpid management is active (using balance algorithm if SMF99_DCM_G OALALG_ON is off)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

dcm_goalalg_on : Final[Field] = Field(
    name='dcm_goalalg_on',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=status_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Dynamic chpid management goal algorithm is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `status_flags`(`SMF99_STATUS_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Dynamic chpid management goal algorithm is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
dcm_goalalg_on.__doc__ = """Dynamic chpid management goal algorithm is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `status_flags`(`SMF99_STATUS_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Dynamic chpid management goal algorithm is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

compat_mode : Final[Field] = Field(
    name='compat_mode',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=status_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Indicates if in COMPAT mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `status_flags`(`SMF99_STATUS_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Indicates if in COMPAT mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
compat_mode.__doc__ = """Indicates if in COMPAT mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `status_flags`(`SMF99_STATUS_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Indicates if in COMPAT mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

total_pag_cost : Final[Field] = Field(
    name='total_pag_cost',
    origin='SMF99_TOTAL_PAG_COST',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Recent total paging and swap cost percentage * 10

SMF Info
--------
    Field: `SMF99_TOTAL_PAG_COST`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Recent total paging and swap cost percentage * 10
"""
total_pag_cost.__doc__ = """Recent total paging and swap cost percentage * 10

SMF Info
--------
    Field: `SMF99_TOTAL_PAG_COST`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Recent total paging and swap cost percentage * 10
"""

cpps : Final[Field] = Field(
    name='cpps',
    origin='SMF99_CPPS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Common protective processor storage target in frames

SMF Info
--------
    Field: `SMF99_CPPS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Common protective processor storage target in frames
"""
cpps.__doc__ = """Common protective processor storage target in frames

SMF Info
--------
    Field: `SMF99_CPPS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Common protective processor storage target in frames
"""

suic1 : Final[Field] = Field(
    name='suic1',
    origin='SMF99_SUIC1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Shared central UIC bucket 1, measured in frame counts

SMF Info
--------
    Field: `SMF99_SUIC1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared central UIC bucket 1, measured in frame counts
"""
suic1.__doc__ = """Shared central UIC bucket 1, measured in frame counts

SMF Info
--------
    Field: `SMF99_SUIC1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared central UIC bucket 1, measured in frame counts
"""

suic2 : Final[Field] = Field(
    name='suic2',
    origin='SMF99_SUIC2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Shared central UIC bucket 2, measured in frame counts

SMF Info
--------
    Field: `SMF99_SUIC2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared central UIC bucket 2, measured in frame counts
"""
suic2.__doc__ = """Shared central UIC bucket 2, measured in frame counts

SMF Info
--------
    Field: `SMF99_SUIC2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared central UIC bucket 2, measured in frame counts
"""

suic3 : Final[Field] = Field(
    name='suic3',
    origin='SMF99_SUIC3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Shared central UIC bucket 3, measured in frame counts

SMF Info
--------
    Field: `SMF99_SUIC3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared central UIC bucket 3, measured in frame counts
"""
suic3.__doc__ = """Shared central UIC bucket 3, measured in frame counts

SMF Info
--------
    Field: `SMF99_SUIC3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared central UIC bucket 3, measured in frame counts
"""

suic4 : Final[Field] = Field(
    name='suic4',
    origin='SMF99_SUIC4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Shared central UIC bucket 4, measured in frame counts

SMF Info
--------
    Field: `SMF99_SUIC4`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared central UIC bucket 4, measured in frame counts
"""
suic4.__doc__ = """Shared central UIC bucket 4, measured in frame counts

SMF Info
--------
    Field: `SMF99_SUIC4`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared central UIC bucket 4, measured in frame counts
"""

seuc1 : Final[Field] = Field(
    name='seuc1',
    origin='SMF99_SEUC1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Shared expanded UIC bucket 1, measured in frame counts

SMF Info
--------
    Field: `SMF99_SEUC1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared expanded UIC bucket 1, measured in frame counts
"""
seuc1.__doc__ = """Shared expanded UIC bucket 1, measured in frame counts

SMF Info
--------
    Field: `SMF99_SEUC1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared expanded UIC bucket 1, measured in frame counts
"""

seuc2 : Final[Field] = Field(
    name='seuc2',
    origin='SMF99_SEUC2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Shared expanded UIC bucket 2, measured in frame counts

SMF Info
--------
    Field: `SMF99_SEUC2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared expanded UIC bucket 2, measured in frame counts
"""
seuc2.__doc__ = """Shared expanded UIC bucket 2, measured in frame counts

SMF Info
--------
    Field: `SMF99_SEUC2`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared expanded UIC bucket 2, measured in frame counts
"""

seuc3 : Final[Field] = Field(
    name='seuc3',
    origin='SMF99_SEUC3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Shared expanded UIC bucket 3, measured in frame counts

SMF Info
--------
    Field: `SMF99_SEUC3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared expanded UIC bucket 3, measured in frame counts
"""
seuc3.__doc__ = """Shared expanded UIC bucket 3, measured in frame counts

SMF Info
--------
    Field: `SMF99_SEUC3`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared expanded UIC bucket 3, measured in frame counts
"""

seuc4 : Final[Field] = Field(
    name='seuc4',
    origin='SMF99_SEUC4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Shared expanded UIC bucket 4, measured in frame counts

SMF Info
--------
    Field: `SMF99_SEUC4`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared expanded UIC bucket 4, measured in frame counts
"""
seuc4.__doc__ = """Shared expanded UIC bucket 4, measured in frame counts

SMF Info
--------
    Field: `SMF99_SEUC4`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Shared expanded UIC bucket 4, measured in frame counts
"""

stwss : Final[Field] = Field(
    name='stwss',
    origin='SMF99_STWSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Protective processor storage target for shared area, measured in frame counts

SMF Info
--------
    Field: `SMF99_STWSS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Protective processor storage target for shared area, measured in frame counts
"""
stwss.__doc__ = """Protective processor storage target for shared area, measured in frame counts

SMF Info
--------
    Field: `SMF99_STWSS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Protective processor storage target for shared area, measured in frame counts
"""

num_ext_sc : Final[Field] = Field(
    name='num_ext_sc',
    origin='SMF99_NUM_EXT_SC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Number of external service classes

SMF Info
--------
    Field: `SMF99_NUM_EXT_SC`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of external service classes
"""
num_ext_sc.__doc__ = """Number of external service classes

SMF Info
--------
    Field: `SMF99_NUM_EXT_SC`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of external service classes
"""

default_io_velocity : Final[Field] = Field(
    name='default_io_velocity',
    origin='SMF99_DEFAULT_IO_VELOCITY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Default I/O velocity. Calculated by IOS at the beginning of each measurement interval during data gathering.

SMF Info
--------
    Field: `SMF99_DEFAULT_IO_VELOCITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Default I/O velocity. Calculated by IOS at the beginning of each measurement interval during data gathering.
"""
default_io_velocity.__doc__ = """Default I/O velocity. Calculated by IOS at the beginning of each measurement interval during data gathering.

SMF Info
--------
    Field: `SMF99_DEFAULT_IO_VELOCITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Default I/O velocity. Calculated by IOS at the beginning of each measurement interval during data gathering.
"""

ifac : Final[Field] = Field(
    name='ifac',
    origin='SMF99_SU_IFACTOR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Service unit inflation factor

SMF Info
--------
    Field: `SMF99_SU_IFACTOR`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Service unit inflation factor
"""
ifac.__doc__ = """Service unit inflation factor

SMF Info
--------
    Field: `SMF99_SU_IFACTOR`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Service unit inflation factor
"""

iopiscaling : Final[Field] = Field(
    name='iopiscaling',
    origin='SMF99_IOPISCALING',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""IOPIScaling OPT parm

SMF Info
--------
    Field: `SMF99_IOPISCALING`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

IOPIScaling OPT parm
"""
iopiscaling.__doc__ = """IOPIScaling OPT parm

SMF Info
--------
    Field: `SMF99_IOPISCALING`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

IOPIScaling OPT parm
"""

ls_disc : Final[Field] = Field(
    name='ls_disc',
    origin='SMF99_LS_DISC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Frames owned by logically swapped spaces in non-short response time periods that are discretionary

SMF Info
--------
    Field: `SMF99_LS_DISC`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames owned by logically swapped spaces in non-short response time periods that are discretionary
"""
ls_disc.__doc__ = """Frames owned by logically swapped spaces in non-short response time periods that are discretionary

SMF Info
--------
    Field: `SMF99_LS_DISC`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Frames owned by logically swapped spaces in non-short response time periods that are discretionary
"""

capws : Final[Field] = Field(
    name='capws',
    origin='SMF99_CAPWS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CAP workarea - working set size accumulator

SMF Info
--------
    Field: `SMF99_CAPWS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

CAP workarea - working set size accumulator
"""
capws.__doc__ = """CAP workarea - working set size accumulator

SMF Info
--------
    Field: `SMF99_CAPWS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

CAP workarea - working set size accumulator
"""

secws : Final[Field] = Field(
    name='secws',
    origin='SMF99_SECWS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Number of secondary working set pages for which swap-ins have been started

SMF Info
--------
    Field: `SMF99_SECWS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of secondary working set pages for which swap-ins have been started
"""
secws.__doc__ = """Number of secondary working set pages for which swap-ins have been started

SMF Info
--------
    Field: `SMF99_SECWS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of secondary working set pages for which swap-ins have been started
"""

page_ins : Final[Field] = Field(
    name='page_ins',
    origin='SMF99_PGINS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Page-ins rate count used for calculating the system paging rate

SMF Info
--------
    Field: `SMF99_PGINS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Page-ins rate count used for calculating the system paging rate
"""
page_ins.__doc__ = """Page-ins rate count used for calculating the system paging rate

SMF Info
--------
    Field: `SMF99_PGINS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Page-ins rate count used for calculating the system paging rate
"""

zaap_norm : Final[Field] = Field(
    name='zaap_norm',
    origin='SMF99_IFA_NORMALIZATION',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Normalization factor for assist processors

SMF Info
--------
    Field: `SMF99_IFA_NORMALIZATION`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Normalization factor for assist processors
"""
zaap_norm.__doc__ = """Normalization factor for assist processors

SMF Info
--------
    Field: `SMF99_IFA_NORMALIZATION`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Normalization factor for assist processors
"""

cp_online : Final[Field] = Field(
    name='cp_online',
    origin='SMF99_CPUS_ONLINE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Number of regular CPs online

SMF Info
--------
    Field: `SMF99_CPUS_ONLINE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of regular CPs online
"""
cp_online.__doc__ = """Number of regular CPs online

SMF Info
--------
    Field: `SMF99_CPUS_ONLINE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of regular CPs online
"""

zaap_online : Final[Field] = Field(
    name='zaap_online',
    origin='SMF99_IFAS_ONLINE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Number of online assist processors

SMF Info
--------
    Field: `SMF99_IFAS_ONLINE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of online assist processors
"""
zaap_online.__doc__ = """Number of online assist processors

SMF Info
--------
    Field: `SMF99_IFAS_ONLINE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of online assist processors
"""

zaap_util : Final[Field] = Field(
    name='zaap_util',
    origin='SMF99_IFAA',
    post='core.scale',
    post_param=16.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Average Utilization of assist processors, scaled by 16

SMF Info
--------
    Field: `SMF99_IFAA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Average Utilization of assist processors, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16.0`
"""
zaap_util.__doc__ = """Average Utilization of assist processors, scaled by 16

SMF Info
--------
    Field: `SMF99_IFAA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Average Utilization of assist processors, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16.0`
"""

total_util : Final[Field] = Field(
    name='total_util',
    origin='SMF99_CPUIFAA',
    post='core.scale',
    post_param=16.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Average utilization of regular CPs and assist processors, scaled by 16

SMF Info
--------
    Field: `SMF99_CPUIFAA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Average utilization of regular CPs and assist processors, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16.0`
"""
total_util.__doc__ = """Average utilization of regular CPs and assist processors, scaled by 16

SMF Info
--------
    Field: `SMF99_CPUIFAA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Average utilization of regular CPs and assist processors, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16.0`
"""

ifa_flags : Final[Field] = Field(
    name='ifa_flags',
    origin='SMF99_IFA_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Assist processors related flags

SMF Info
--------
    Field: `SMF99_IFA_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Assist processors related flags
"""
ifa_flags.__doc__ = """Assist processors related flags

SMF Info
--------
    Field: `SMF99_IFA_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Assist processors related flags
"""

ifacrossover : Final[Field] = Field(
    name='ifacrossover',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=ifa_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Assist processor work may be executed on regular CPs(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ifa_flags`(`SMF99_IFA_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Assist processor work may be executed on regular CPs

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
ifacrossover.__doc__ = """Assist processor work may be executed on regular CPs(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ifa_flags`(`SMF99_IFA_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Assist processor work may be executed on regular CPs

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

ifahonorpriority : Final[Field] = Field(
    name='ifahonorpriority',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=ifa_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Assist processor work may run on regular CPs at priority(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ifa_flags`(`SMF99_IFA_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Assist processor work may run on regular CPs at priority

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
ifahonorpriority.__doc__ = """Assist processor work may run on regular CPs at priority(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ifa_flags`(`SMF99_IFA_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Assist processor work may run on regular CPs at priority

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

suphonorpriority : Final[Field] = Field(
    name='suphonorpriority',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=ifa_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Assist processor work may run on regular CPs at priority(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ifa_flags`(`SMF99_IFA_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Assist processor work may run on regular CPs at priority

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
suphonorpriority.__doc__ = """Assist processor work may run on regular CPs at priority(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ifa_flags`(`SMF99_IFA_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Assist processor work may run on regular CPs at priority

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ioms_opt : Final[Field] = Field(
    name='ioms_opt',
    origin='SMF99_IOMS_OPT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""STORAGESERVERMGT opt parameter

SMF Info
--------
    Field: `SMF99_IOMS_OPT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

STORAGESERVERMGT opt parameter
"""
ioms_opt.__doc__ = """STORAGESERVERMGT opt parameter

SMF Info
--------
    Field: `SMF99_IOMS_OPT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

STORAGESERVERMGT opt parameter
"""

cap_wait : Final[Field] = Field(
    name='cap_wait',
    origin='SMF99_FREE_LPAR_CAPACITY_WT_RELATED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free LPAR capacity based on the accumulated logical CPU wait times

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_WT_RELATED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free LPAR capacity based on the accumulated logical CPU wait times
"""
cap_wait.__doc__ = """Free LPAR capacity based on the accumulated logical CPU wait times

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_WT_RELATED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free LPAR capacity based on the accumulated logical CPU wait times
"""

cap_guar : Final[Field] = Field(
    name='cap_guar',
    origin='SMF99_FREE_LPAR_CAPACITY_GUARANTEED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free LPAR capacity which is always available based on the LPAR weight

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_GUARANTEED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free LPAR capacity which is always available based on the LPAR weight
"""
cap_guar.__doc__ = """Free LPAR capacity which is always available based on the LPAR weight

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_GUARANTEED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free LPAR capacity which is always available based on the LPAR weight
"""

cap_cec : Final[Field] = Field(
    name='cap_cec',
    origin='SMF99_FREE_LPAR_CAPACITY_CEC_RELATED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused capacity of the CEC

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_CEC_RELATED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused capacity of the CEC
"""
cap_cec.__doc__ = """Free LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused capacity of the CEC

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_CEC_RELATED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused capacity of the CEC
"""

cap_lcp : Final[Field] = Field(
    name='cap_lcp',
    origin='SMF99_FREE_LPAR_CAPACITY_LCP_CONFIG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free LPAR capacity based on the configured LCPs

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_LCP_CONFIG`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free LPAR capacity based on the configured LCPs
"""
cap_lcp.__doc__ = """Free LPAR capacity based on the configured LCPs

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_LCP_CONFIG`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free LPAR capacity based on the configured LCPs
"""

itavail : Final[Field] = Field(
    name='itavail',
    origin='SMF99_ITAVAIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Total IFA processor time available

SMF Info
--------
    Field: `SMF99_ITAVAIL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Total IFA processor time available
"""
itavail.__doc__ = """Total IFA processor time available

SMF Info
--------
    Field: `SMF99_ITAVAIL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Total IFA processor time available
"""

ziip_norm : Final[Field] = Field(
    name='ziip_norm',
    origin='SMF99_SUP_NORMALIZATION',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Normalization factor for SUP processors

SMF Info
--------
    Field: `SMF99_SUP_NORMALIZATION`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Normalization factor for SUP processors
"""
ziip_norm.__doc__ = """Normalization factor for SUP processors

SMF Info
--------
    Field: `SMF99_SUP_NORMALIZATION`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Normalization factor for SUP processors
"""

ziip_online : Final[Field] = Field(
    name='ziip_online',
    origin='SMF99_SUPS_ONLINE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Number of online SUP processors

SMF Info
--------
    Field: `SMF99_SUPS_ONLINE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of online SUP processors
"""
ziip_online.__doc__ = """Number of online SUP processors

SMF Info
--------
    Field: `SMF99_SUPS_ONLINE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Number of online SUP processors
"""

ziip_util : Final[Field] = Field(
    name='ziip_util',
    origin='SMF99_SUPA',
    post='core.scale',
    post_param=16.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Average Utilization of SUP processors, scaled by 16

SMF Info
--------
    Field: `SMF99_SUPA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Average Utilization of SUP processors, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16.0`
"""
ziip_util.__doc__ = """Average Utilization of SUP processors, scaled by 16

SMF Info
--------
    Field: `SMF99_SUPA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Average Utilization of SUP processors, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16.0`
"""

cap_image_guar : Final[Field] = Field(
    name='cap_image_guar',
    origin='SMF99_GUARANTEED_IMAGE_CAPACITY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Guaranteed image capacity available to MVS image in service units per minute

SMF Info
--------
    Field: `SMF99_GUARANTEED_IMAGE_CAPACITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Guaranteed image capacity available to MVS image in service units per minute
"""
cap_image_guar.__doc__ = """Guaranteed image capacity available to MVS image in service units per minute

SMF Info
--------
    Field: `SMF99_GUARANTEED_IMAGE_CAPACITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Guaranteed image capacity available to MVS image in service units per minute
"""

cctinthd : Final[Field] = Field(
    name='cctinthd',
    origin='SMF99_CCTINTHD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Blocked workload, OPT parameter BLWLINTHD for starvation threshold

SMF Info
--------
    Field: `SMF99_CCTINTHD`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, OPT parameter BLWLINTHD for starvation threshold
"""
cctinthd.__doc__ = """Blocked workload, OPT parameter BLWLINTHD for starvation threshold

SMF Info
--------
    Field: `SMF99_CCTINTHD`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, OPT parameter BLWLINTHD for starvation threshold
"""

ccttrpct : Final[Field] = Field(
    name='ccttrpct',
    origin='SMF99_CCTTRPCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Blocked workload, OPT parameter BLWLTRPCT for percentage of cp trickling

SMF Info
--------
    Field: `SMF99_CCTTRPCT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, OPT parameter BLWLTRPCT for percentage of cp trickling
"""
ccttrpct.__doc__ = """Blocked workload, OPT parameter BLWLTRPCT for percentage of cp trickling

SMF Info
--------
    Field: `SMF99_CCTTRPCT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, OPT parameter BLWLTRPCT for percentage of cp trickling
"""

ccttrate : Final[Field] = Field(
    name='ccttrate',
    origin='SMF99_CCTTRATE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Blocked workload, calculate trickle rate maximum number of trickles per second

SMF Info
--------
    Field: `SMF99_CCTTRATE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, calculate trickle rate maximum number of trickles per second
"""
ccttrate.__doc__ = """Blocked workload, calculate trickle rate maximum number of trickles per second

SMF Info
--------
    Field: `SMF99_CCTTRATE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, calculate trickle rate maximum number of trickles per second
"""

cccttsh : Final[Field] = Field(
    name='cccttsh',
    origin='SMF99_CCCTTSH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Blocked workload, length of major time slice, means length of trickle

SMF Info
--------
    Field: `SMF99_CCCTTSH`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, length of major time slice, means length of trickle
"""
cccttsh.__doc__ = """Blocked workload, length of major time slice, means length of trickle

SMF Info
--------
    Field: `SMF99_CCCTTSH`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, length of major time slice, means length of trickle
"""

cctrc100 : Final[Field] = Field(
    name='cctrc100',
    origin='SMF99_CCTRC100',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Blocked workload, number of times CP utilization is = 100 % in the current interval

SMF Info
--------
    Field: `SMF99_CCTRC100`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, number of times CP utilization is = 100 % in the current interval
"""
cctrc100.__doc__ = """Blocked workload, number of times CP utilization is = 100 % in the current interval

SMF Info
--------
    Field: `SMF99_CCTRC100`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, number of times CP utilization is = 100 % in the current interval
"""

cctrcdsp : Final[Field] = Field(
    name='cctrcdsp',
    origin='SMF99_CCTRCDSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Blocked workload, number of times dispatcher was called to do trickle in the current interval

SMF Info
--------
    Field: `SMF99_CCTRCDSP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, number of times dispatcher was called to do trickle in the current interval
"""
cctrcdsp.__doc__ = """Blocked workload, number of times dispatcher was called to do trickle in the current interval

SMF Info
--------
    Field: `SMF99_CCTRCDSP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, number of times dispatcher was called to do trickle in the current interval
"""

cctrcuse : Final[Field] = Field(
    name='cctrcuse',
    origin='SMF99_CCTRCUSE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Blocked workload, number of trickles used in the current interval

SMF Info
--------
    Field: `SMF99_CCTRCUSE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, number of trickles used in the current interval
"""
cctrcuse.__doc__ = """Blocked workload, number of trickles used in the current interval

SMF Info
--------
    Field: `SMF99_CCTRCUSE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, number of trickles used in the current interval
"""

cctrcwtr : Final[Field] = Field(
    name='cctrcwtr',
    origin='SMF99_CCTRCWTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Blocked workload, number of addr.space/ enclaves waiting longer than the threshold

SMF Info
--------
    Field: `SMF99_CCTRCWTR`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, number of addr.space/ enclaves waiting longer than the threshold
"""
cctrcwtr.__doc__ = """Blocked workload, number of addr.space/ enclaves waiting longer than the threshold

SMF Info
--------
    Field: `SMF99_CCTRCWTR`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, number of addr.space/ enclaves waiting longer than the threshold
"""

cccittsh : Final[Field] = Field(
    name='cccittsh',
    origin='SMF99_CCCITTSH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Blocked workload, length of initial task time slice high value

SMF Info
--------
    Field: `SMF99_CCCITTSH`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, length of initial task time slice high value
"""
cccittsh.__doc__ = """Blocked workload, length of initial task time slice high value

SMF Info
--------
    Field: `SMF99_CCCITTSH`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Blocked workload, length of initial task time slice high value
"""

stavail : Final[Field] = Field(
    name='stavail',
    origin='SMF99_STAVAIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Total SUP processor time available

SMF Info
--------
    Field: `SMF99_STAVAIL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Total SUP processor time available
"""
stavail.__doc__ = """Total SUP processor time available

SMF Info
--------
    Field: `SMF99_STAVAIL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Total SUP processor time available
"""

cap_wait_zaap : Final[Field] = Field(
    name='cap_wait_zaap',
    origin='SMF99_FREE_LPAR_CAPACITY_WT_RELATED_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free zAAP LPAR capacity based on the accumulated logical zAAP wait times

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_WT_RELATED_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zAAP LPAR capacity based on the accumulated logical zAAP wait times
"""
cap_wait_zaap.__doc__ = """Free zAAP LPAR capacity based on the accumulated logical zAAP wait times

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_WT_RELATED_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zAAP LPAR capacity based on the accumulated logical zAAP wait times
"""

cap_guar_zaap : Final[Field] = Field(
    name='cap_guar_zaap',
    origin='SMF99_FREE_LPAR_CAPACITY_GUARANTEED_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free zAAP LPAR capacity which is always available based on the zAAP LPAR weight

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_GUARANTEED_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zAAP LPAR capacity which is always available based on the zAAP LPAR weight
"""
cap_guar_zaap.__doc__ = """Free zAAP LPAR capacity which is always available based on the zAAP LPAR weight

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_GUARANTEED_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zAAP LPAR capacity which is always available based on the zAAP LPAR weight
"""

cap_cec_zaap : Final[Field] = Field(
    name='cap_cec_zaap',
    origin='SMF99_FREE_LPAR_CAPACITY_CEC_RELATD_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free zAAP LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused zAAP capacity of the CEC

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_CEC_RELATD_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zAAP LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused zAAP capacity of the CEC
"""
cap_cec_zaap.__doc__ = """Free zAAP LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused zAAP capacity of the CEC

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_CEC_RELATD_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zAAP LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused zAAP capacity of the CEC
"""

cap_lcp_zaap : Final[Field] = Field(
    name='cap_lcp_zaap',
    origin='SMF99_FREE_LPAR_CAPACITY_LCP_CONFIG_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free zAAP LPAR capacity based on the configured Logical zAAPs

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_LCP_CONFIG_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zAAP LPAR capacity based on the configured Logical zAAPs
"""
cap_lcp_zaap.__doc__ = """Free zAAP LPAR capacity based on the configured Logical zAAPs

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_LCP_CONFIG_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zAAP LPAR capacity based on the configured Logical zAAPs
"""

cap_wait_ziip : Final[Field] = Field(
    name='cap_wait_ziip',
    origin='SMF99_FREE_LPAR_CAPACITY_WT_RELATED_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free zIIP LPAR capacity based on the accumulated logical zIIP wait times

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_WT_RELATED_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zIIP LPAR capacity based on the accumulated logical zIIP wait times
"""
cap_wait_ziip.__doc__ = """Free zIIP LPAR capacity based on the accumulated logical zIIP wait times

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_WT_RELATED_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zIIP LPAR capacity based on the accumulated logical zIIP wait times
"""

cap_guar_ziip : Final[Field] = Field(
    name='cap_guar_ziip',
    origin='SMF99_FREE_LPAR_CAPACITY_GUARANTEED_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free zIIP LPAR capacity which is always available based on the zIIP LPAR weight

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_GUARANTEED_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zIIP LPAR capacity which is always available based on the zIIP LPAR weight
"""
cap_guar_ziip.__doc__ = """Free zIIP LPAR capacity which is always available based on the zIIP LPAR weight

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_GUARANTEED_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zIIP LPAR capacity which is always available based on the zIIP LPAR weight
"""

cap_cec_ziip : Final[Field] = Field(
    name='cap_cec_ziip',
    origin='SMF99_FREE_LPAR_CAPACITY_CEC_RELATD_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free zIIP LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused zIIP capacity of the CEC

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_CEC_RELATD_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zIIP LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused zIIP capacity of the CEC
"""
cap_cec_ziip.__doc__ = """Free zIIP LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused zIIP capacity of the CEC

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_CEC_RELATD_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zIIP LPAR capacity which is the total of what is always available to the LPAR and the portion of the unused zIIP capacity of the CEC
"""

cap_lcp_ziip : Final[Field] = Field(
    name='cap_lcp_ziip',
    origin='SMF99_FREE_LPAR_CAPACITY_LCP_CONFIG_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Free zIIP LPAR capacity based on the configured Logical zIIPs

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_LCP_CONFIG_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zIIP LPAR capacity based on the configured Logical zIIPs
"""
cap_lcp_ziip.__doc__ = """Free zIIP LPAR capacity based on the configured Logical zIIPs

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_LCP_CONFIG_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Free zIIP LPAR capacity based on the configured Logical zIIPs
"""

svtwtss : Final[Field] = Field(
    name='svtwtss',
    origin='SMF99_SVTWTSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Short wait time slice

SMF Info
--------
    Field: `SMF99_SVTWTSS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Short wait time slice
"""
svtwtss.__doc__ = """Short wait time slice

SMF Info
--------
    Field: `SMF99_SVTWTSS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Short wait time slice
"""

cp_wait_time : Final[Field] = Field(
    name='cp_wait_time',
    origin='SMF99_DELTAWAITTIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""LPAR CP Wait Time

SMF Info
--------
    Field: `SMF99_DELTAWAITTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR CP Wait Time
"""
cp_wait_time.__doc__ = """LPAR CP Wait Time

SMF Info
--------
    Field: `SMF99_DELTAWAITTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR CP Wait Time
"""

zaap_wait_time : Final[Field] = Field(
    name='zaap_wait_time',
    origin='SMF99_DELTAWAITTIMEZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""LPAR zAAP Wait Time

SMF Info
--------
    Field: `SMF99_DELTAWAITTIMEZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR zAAP Wait Time
"""
zaap_wait_time.__doc__ = """LPAR zAAP Wait Time

SMF Info
--------
    Field: `SMF99_DELTAWAITTIMEZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR zAAP Wait Time
"""

ziip_wait_time : Final[Field] = Field(
    name='ziip_wait_time',
    origin='SMF99_DELTAWAITTIMEZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""LPAR zIIP Wait Time

SMF Info
--------
    Field: `SMF99_DELTAWAITTIMEZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR zIIP Wait Time
"""
ziip_wait_time.__doc__ = """LPAR zIIP Wait Time

SMF Info
--------
    Field: `SMF99_DELTAWAITTIMEZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR zIIP Wait Time
"""

cp_dispatch_time : Final[Field] = Field(
    name='cp_dispatch_time',
    origin='SMF99_DELTADISPTIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""LPAR CP Dispatch Time

SMF Info
--------
    Field: `SMF99_DELTADISPTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR CP Dispatch Time
"""
cp_dispatch_time.__doc__ = """LPAR CP Dispatch Time

SMF Info
--------
    Field: `SMF99_DELTADISPTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR CP Dispatch Time
"""

zaap_dispatch_time : Final[Field] = Field(
    name='zaap_dispatch_time',
    origin='SMF99_DELTADISPTIMEZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""LPAR zAAP Dispatch Time

SMF Info
--------
    Field: `SMF99_DELTADISPTIMEZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR zAAP Dispatch Time
"""
zaap_dispatch_time.__doc__ = """LPAR zAAP Dispatch Time

SMF Info
--------
    Field: `SMF99_DELTADISPTIMEZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR zAAP Dispatch Time
"""

ziip_dispatch_time : Final[Field] = Field(
    name='ziip_dispatch_time',
    origin='SMF99_DELTADISPTIMEZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""LPAR zIIP Dispatch Time

SMF Info
--------
    Field: `SMF99_DELTADISPTIMEZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR zIIP Dispatch Time
"""
ziip_dispatch_time.__doc__ = """LPAR zIIP Dispatch Time

SMF Info
--------
    Field: `SMF99_DELTADISPTIMEZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

LPAR zIIP Dispatch Time
"""

cp_cap_fac : Final[Field] = Field(
    name='cp_cap_fac',
    origin='SMF99_CF',
    post='core.scale',
    post_param=1024.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Capacity factor for CPs scaled by 1024

SMF Info
--------
    Field: `SMF99_CF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Capacity factor for CPs scaled by 1024

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""
cp_cap_fac.__doc__ = """Capacity factor for CPs scaled by 1024

SMF Info
--------
    Field: `SMF99_CF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Capacity factor for CPs scaled by 1024

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""

zaap_cap_fac : Final[Field] = Field(
    name='zaap_cap_fac',
    origin='SMF99_CF_ZAAP',
    post='core.scale',
    post_param=1024.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_CF_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""
zaap_cap_fac.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_CF_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""

ziip_cap_fac : Final[Field] = Field(
    name='ziip_cap_fac',
    origin='SMF99_CF_ZIIP',
    post='core.scale',
    post_param=1024.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_CF_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""
ziip_cap_fac.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_CF_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""

cp_max_fac : Final[Field] = Field(
    name='cp_max_fac',
    origin='SMF99_MCF',
    post='core.scale',
    post_param=1024.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MCF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""
cp_max_fac.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MCF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""

zaap_max_fac : Final[Field] = Field(
    name='zaap_max_fac',
    origin='SMF99_MCF_ZAAP',
    post='core.scale',
    post_param=1024.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MCF_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""
zaap_max_fac.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MCF_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""

ziip_max_fac : Final[Field] = Field(
    name='ziip_max_fac',
    origin='SMF99_MCF_ZIIP',
    post='core.scale',
    post_param=1024.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MCF_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""
ziip_max_fac.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MCF_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024.0`
"""

lpar_busy_time : Final[Field] = Field(
    name='lpar_busy_time',
    origin='SMF99_LPARBUSYTIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_LPARBUSYTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
lpar_busy_time.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_LPARBUSYTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

lpar_busy_time_zaap : Final[Field] = Field(
    name='lpar_busy_time_zaap',
    origin='SMF99_LPARBUSYTIME_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_LPARBUSYTIME_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
lpar_busy_time_zaap.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_LPARBUSYTIME_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

lpar_busy_time_ziip : Final[Field] = Field(
    name='lpar_busy_time_ziip',
    origin='SMF99_LPARBUSYTIME_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_LPARBUSYTIME_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
lpar_busy_time_ziip.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_LPARBUSYTIME_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

online_cores_all : Final[Field] = Field(
    name='online_cores_all',
    origin='SMF99_ONLINE_CORES_ALL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_ONLINE_CORES_ALL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
online_cores_all.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_ONLINE_CORES_ALL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

online_cores_cp : Final[Field] = Field(
    name='online_cores_cp',
    origin='SMF99_ONLINE_CORES_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_ONLINE_CORES_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
online_cores_cp.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_ONLINE_CORES_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

online_cores_zaap : Final[Field] = Field(
    name='online_cores_zaap',
    origin='SMF99_ONLINE_CORES_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_ONLINE_CORES_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
online_cores_zaap.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_ONLINE_CORES_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

online_cores_ziip : Final[Field] = Field(
    name='online_cores_ziip',
    origin='SMF99_ONLINE_CORES_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_ONLINE_CORES_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
online_cores_ziip.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_ONLINE_CORES_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_flags : Final[Field] = Field(
    name='mt_flags',
    origin='SMF99_MT_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_flags.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

procascore : Final[Field] = Field(
    name='procascore',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=mt_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flags`(`SMF99_MT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
procascore.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flags`(`SMF99_MT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

multicpuspercore : Final[Field] = Field(
    name='multicpuspercore',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=mt_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flags`(`SMF99_MT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
multicpuspercore.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flags`(`SMF99_MT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

mt_installedbasic : Final[Field] = Field(
    name='mt_installedbasic',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=mt_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flags`(`SMF99_MT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
mt_installedbasic.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flags`(`SMF99_MT_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

mt_cp : Final[Field] = Field(
    name='mt_cp',
    origin='SMF99_MT_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_cp.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_zaap : Final[Field] = Field(
    name='mt_zaap',
    origin='SMF99_MT_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_zaap.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_ziip : Final[Field] = Field(
    name='mt_ziip',
    origin='SMF99_MT_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_ziip.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_opt_cp : Final[Field] = Field(
    name='mt_opt_cp',
    origin='SMF99_MT_OPT_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_OPT_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_opt_cp.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_OPT_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_opt_zaap : Final[Field] = Field(
    name='mt_opt_zaap',
    origin='SMF99_MT_OPT_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_OPT_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_opt_zaap.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_OPT_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_opt_ziip : Final[Field] = Field(
    name='mt_opt_ziip',
    origin='SMF99_MT_OPT_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_OPT_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_opt_ziip.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_OPT_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_installed_info : Final[Field] = Field(
    name='mt_installed_info',
    origin='SMF99_MT_INSTALLED_INFO',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_INSTALLED_INFO`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_installed_info.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_INSTALLED_INFO`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_installed : Final[Field] = Field(
    name='mt_installed',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=mt_installed_info,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_installed_info`(`SMF99_MT_INSTALLED_INFO`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
mt_installed.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_installed_info`(`SMF99_MT_INSTALLED_INFO`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

mt_maxthreadid : Final[Field] = Field(
    name='mt_maxthreadid',
    origin='SMF99_MT_MAXTHREADID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_MAXTHREADID`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_maxthreadid.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_MAXTHREADID`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_general_info : Final[Field] = Field(
    name='mt_general_info',
    origin='SMF99_MT_GENERAL_INFO',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_MT_GENERAL_INFO`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""
mt_general_info.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_MT_GENERAL_INFO`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available
"""

mt_specialfeature : Final[Field] = Field(
    name='mt_specialfeature',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=mt_general_info,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_general_info`(`SMF99_MT_GENERAL_INFO`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
mt_specialfeature.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_general_info`(`SMF99_MT_GENERAL_INFO`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

ifac_uncapped : Final[Field] = Field(
    name='ifac_uncapped',
    origin='SMF99_SU_IFACTOR_UNCAPPED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Uncapped Service unit inflation factor (reg. CPs)

SMF Info
--------
    Field: `SMF99_SU_IFACTOR_UNCAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Uncapped Service unit inflation factor (reg. CPs)
"""
ifac_uncapped.__doc__ = """Uncapped Service unit inflation factor (reg. CPs)

SMF Info
--------
    Field: `SMF99_SU_IFACTOR_UNCAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Uncapped Service unit inflation factor (reg. CPs)
"""

ifac_zaap : Final[Field] = Field(
    name='ifac_zaap',
    origin='SMF99_SU_IFACTOR_IFA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Uncapped Service unit inflation factor (zAAPs)

SMF Info
--------
    Field: `SMF99_SU_IFACTOR_IFA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Uncapped Service unit inflation factor (zAAPs)
"""
ifac_zaap.__doc__ = """Uncapped Service unit inflation factor (zAAPs)

SMF Info
--------
    Field: `SMF99_SU_IFACTOR_IFA`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Uncapped Service unit inflation factor (zAAPs)
"""

ifac_ziip : Final[Field] = Field(
    name='ifac_ziip',
    origin='SMF99_SU_IFACTOR_SUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Uncapped Service unit inflation factor (zIIPs)

SMF Info
--------
    Field: `SMF99_SU_IFACTOR_SUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Uncapped Service unit inflation factor (zIIPs)
"""
ifac_ziip.__doc__ = """Uncapped Service unit inflation factor (zIIPs)

SMF Info
--------
    Field: `SMF99_SU_IFACTOR_SUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Uncapped Service unit inflation factor (zIIPs)
"""

dispatch_times_su : Final[Field] = Field(
    name='dispatch_times_su',
    origin='SMF99_DISPATCH_TIMES_SU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CPxx service units based on D204 dispatch times

SMF Info
--------
    Field: `SMF99_DISPATCH_TIMES_SU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

CPxx service units based on D204 dispatch times
"""
dispatch_times_su.__doc__ = """CPxx service units based on D204 dispatch times

SMF Info
--------
    Field: `SMF99_DISPATCH_TIMES_SU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

CPxx service units based on D204 dispatch times
"""

dispatch_times_su_zaap : Final[Field] = Field(
    name='dispatch_times_su_zaap',
    origin='SMF99_DISPATCH_TIMES_SU_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP service units based on D204 dispatch times

SMF Info
--------
    Field: `SMF99_DISPATCH_TIMES_SU_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zAAP service units based on D204 dispatch times
"""
dispatch_times_su_zaap.__doc__ = """zAAP service units based on D204 dispatch times

SMF Info
--------
    Field: `SMF99_DISPATCH_TIMES_SU_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zAAP service units based on D204 dispatch times
"""

dispatch_times_su_ziip : Final[Field] = Field(
    name='dispatch_times_su_ziip',
    origin='SMF99_DISPATCH_TIMES_SU_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP service units based on D204 dispatch times

SMF Info
--------
    Field: `SMF99_DISPATCH_TIMES_SU_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zIIP service units based on D204 dispatch times
"""
dispatch_times_su_ziip.__doc__ = """zIIP service units based on D204 dispatch times

SMF Info
--------
    Field: `SMF99_DISPATCH_TIMES_SU_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zIIP service units based on D204 dispatch times
"""

service_accum_oi : Final[Field] = Field(
    name='service_accum_oi',
    origin='SMF99_SERVICE_ACCUM_OI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CP processor time accumulated over the interval

SMF Info
--------
    Field: `SMF99_SERVICE_ACCUM_OI`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

CP processor time accumulated over the interval
"""
service_accum_oi.__doc__ = """CP processor time accumulated over the interval

SMF Info
--------
    Field: `SMF99_SERVICE_ACCUM_OI`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

CP processor time accumulated over the interval
"""

service_accum_oi_zaap : Final[Field] = Field(
    name='service_accum_oi_zaap',
    origin='SMF99_SERVICE_ACCUM_OI_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP processor time accumulated over the interval

SMF Info
--------
    Field: `SMF99_SERVICE_ACCUM_OI_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zAAP processor time accumulated over the interval
"""
service_accum_oi_zaap.__doc__ = """zAAP processor time accumulated over the interval

SMF Info
--------
    Field: `SMF99_SERVICE_ACCUM_OI_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zAAP processor time accumulated over the interval
"""

service_accum_oi_ziip : Final[Field] = Field(
    name='service_accum_oi_ziip',
    origin='SMF99_SERVICE_ACCUM_OI_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP processor time accumulated over the interval

SMF Info
--------
    Field: `SMF99_SERVICE_ACCUM_OI_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zIIP processor time accumulated over the interval
"""
service_accum_oi_ziip.__doc__ = """zIIP processor time accumulated over the interval

SMF Info
--------
    Field: `SMF99_SERVICE_ACCUM_OI_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zIIP processor time accumulated over the interval
"""

model_zcbp : Final[Field] = Field(
    name='model_zcbp',
    origin='SMF99_MODEL_ZCBP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_MODEL_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
model_zcbp.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_MODEL_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

mcr_zcbp : Final[Field] = Field(
    name='mcr_zcbp',
    origin='SMF99_MCR_ZCBP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_MCR_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
mcr_zcbp.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_MCR_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

nommcr_zcbp : Final[Field] = Field(
    name='nommcr_zcbp',
    origin='SMF99_NOMMCR_ZCBP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_NOMMCR_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
nommcr_zcbp.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_NOMMCR_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

zcbp_flags : Final[Field] = Field(
    name='zcbp_flags',
    origin='SMF99_ZCBP_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zCBP related flags

SMF Info
--------
    Field: `SMF99_ZCBP_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zCBP related flags
"""
zcbp_flags.__doc__ = """zCBP related flags

SMF Info
--------
    Field: `SMF99_ZCBP_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

zCBP related flags
"""

zaap_in_sysplex : Final[Field] = Field(
    name='zaap_in_sysplex',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=zcbp_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""On if at least one zAAP processor is online sysplex(V)

SMF Info (Virtual Field)
--------
    Field: Based on `zcbp_flags`(`SMF99_ZCBP_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

On if at least one zAAP processor is online sysplex

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
zaap_in_sysplex.__doc__ = """On if at least one zAAP processor is online sysplex(V)

SMF Info (Virtual Field)
--------
    Field: Based on `zcbp_flags`(`SMF99_ZCBP_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

On if at least one zAAP processor is online sysplex

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

zcbp_in_sysplex : Final[Field] = Field(
    name='zcbp_in_sysplex',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=zcbp_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only(V)

SMF Info (Virtual Field)
--------
    Field: Based on `zcbp_flags`(`SMF99_ZCBP_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
zcbp_in_sysplex.__doc__ = """For IBM use only(V)

SMF Info (Virtual Field)
--------
    Field: Based on `zcbp_flags`(`SMF99_ZCBP_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

ira870_issued : Final[Field] = Field(
    name='ira870_issued',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=zcbp_flags,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""On if message IRA870E has been issued(V)

SMF Info (Virtual Field)
--------
    Field: Based on `zcbp_flags`(`SMF99_ZCBP_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

On if message IRA870E has been issued

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
ira870_issued.__doc__ = """On if message IRA870E has been issued(V)

SMF Info (Virtual Field)
--------
    Field: Based on `zcbp_flags`(`SMF99_ZCBP_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

On if message IRA870E has been issued

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

enq_dp : Final[Field] = Field(
    name='enq_dp',
    origin='SMF99_ENQ_DP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Temporary dispatching priority for address spaces holding ENQs that are delaying others

SMF Info
--------
    Field: `SMF99_ENQ_DP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Temporary dispatching priority for address spaces holding ENQs that are delaying others
"""
enq_dp.__doc__ = """Temporary dispatching priority for address spaces holding ENQs that are delaying others

SMF Info
--------
    Field: `SMF99_ENQ_DP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Temporary dispatching priority for address spaces holding ENQs that are delaying others
"""

zep : Final[Field] = Field(
    name='zep',
    origin='SMF99_ZEP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_ZEP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
zep.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_ZEP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

mmt_diagnose : Final[Field] = Field(
    name='mmt_diagnose',
    origin='SMF99_MMT_DIAGNOSE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_MMT_DIAGNOSE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
mmt_diagnose.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_MMT_DIAGNOSE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

cpmp : Final[Field] = Field(
    name='cpmp',
    origin='SMF99_CPMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_CPMP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
cpmp.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_CPMP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

cpub : Final[Field] = Field(
    name='cpub',
    origin='SMF99_CPUB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_CPUB`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
cpub.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_CPUB`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

free_lpar_capacity_ub_cpu : Final[Field] = Field(
    name='free_lpar_capacity_ub_cpu',
    origin='SMF99_FREE_LPAR_CAPACITY_UB_CPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_UB_CPU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
free_lpar_capacity_ub_cpu.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_UB_CPU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

free_lpar_capacity_ub_ziip : Final[Field] = Field(
    name='free_lpar_capacity_ub_ziip',
    origin='SMF99_FREE_LPAR_CAPACITY_UB_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_UB_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
free_lpar_capacity_ub_ziip.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_FREE_LPAR_CAPACITY_UB_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

lpc_max_guaranteed_ub_cpu : Final[Field] = Field(
    name='lpc_max_guaranteed_ub_cpu',
    origin='SMF99_LPC_MAX_GUARANTEED_UB_CPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_LPC_MAX_GUARANTEED_UB_CPU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
lpc_max_guaranteed_ub_cpu.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_LPC_MAX_GUARANTEED_UB_CPU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

lpc_max_guaranteed_ub_ziip : Final[Field] = Field(
    name='lpc_max_guaranteed_ub_ziip',
    origin='SMF99_LPC_MAX_GUARANTEED_UB_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_LPC_MAX_GUARANTEED_UB_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
lpc_max_guaranteed_ub_ziip.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_LPC_MAX_GUARANTEED_UB_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

boostinfo : Final[Field] = Field(
    name='boostinfo',
    origin='SMF99_BOOSTINFO',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""Copy of RMCTZ_BoostInfo

SMF Info
--------
    Field: `SMF99_BOOSTINFO`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Copy of RMCTZ_BoostInfo
"""
boostinfo.__doc__ = """Copy of RMCTZ_BoostInfo

SMF Info
--------
    Field: `SMF99_BOOSTINFO`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Copy of RMCTZ_BoostInfo
"""

mmt_diagnose_v1 : Final[Field] = Field(
    name='mmt_diagnose_v1',
    origin='SMF99_MMT_DIAGNOSE_V1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_MMT_DIAGNOSE_V1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""
mmt_diagnose_v1.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_MMT_DIAGNOSE_V1`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

For IBM use only
"""

ilsu_array : Final[Field] = Field(
    name='ilsu_array',
    origin='SMF99_ILSU_ARRAY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 8,
)
"""Array of Importance Level Service Units.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.

SMF Info
--------
    Field: `SMF99_ILSU_ARRAY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Array of Importance Level Service Units.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.
"""
ilsu_array.__doc__ = """Array of Importance Level Service Units.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.

SMF Info
--------
    Field: `SMF99_ILSU_ARRAY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Array of Importance Level Service Units.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.
"""

stgcrit_hsk_skip_clock : Final[Field] = Field(
    name='stgcrit_hsk_skip_clock',
    origin='SMF99_STGCRIT_HSK_SKIP_CLOCK',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 7,
)
"""Storage critical housekeeping skip clock counter for each importance level.

SMF Info
--------
    Field: `SMF99_STGCRIT_HSK_SKIP_CLOCK`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Storage critical housekeeping skip clock counter for each importance level.
"""
stgcrit_hsk_skip_clock.__doc__ = """Storage critical housekeeping skip clock counter for each importance level.

SMF Info
--------
    Field: `SMF99_STGCRIT_HSK_SKIP_CLOCK`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Storage critical housekeeping skip clock counter for each importance level.
"""

ilsu_zaap_array : Final[Field] = Field(
    name='ilsu_zaap_array',
    origin='SMF99_ILSU_ZAAP_ARRAY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 8,
)
"""Array of Importance Level Service Units of zAAPs.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.

SMF Info
--------
    Field: `SMF99_ILSU_ZAAP_ARRAY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Array of Importance Level Service Units of zAAPs.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.
"""
ilsu_zaap_array.__doc__ = """Array of Importance Level Service Units of zAAPs.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.

SMF Info
--------
    Field: `SMF99_ILSU_ZAAP_ARRAY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Array of Importance Level Service Units of zAAPs.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.
"""

ilsu_ziip_array : Final[Field] = Field(
    name='ilsu_ziip_array',
    origin='SMF99_ILSU_ZIIP_ARRAY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SS_MAP,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 8,
)
"""Array of Importance Level Service Units of zIIPs.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.

SMF Info
--------
    Field: `SMF99_ILSU_ZIIP_ARRAY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Array of Importance Level Service Units of zIIPs.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.
"""
ilsu_ziip_array.__doc__ = """Array of Importance Level Service Units of zIIPs.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.

SMF Info
--------
    Field: `SMF99_ILSU_ZIIP_ARRAY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Array of Importance Level Service Units of zIIPs.The first entry contains Service Units pertaining to Importance Level 0,the second entry contains Service Units pertaining to Importance Level 1,and so on. The last entry contains Service Units pertaining to unused Service.
"""

cp_sys : Final[Field] = Field(
    name='cp_sys',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_array[0],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CP service consumption for importance sys(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
cp_sys.__doc__ = """CP service consumption for importance sys(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

cp_imp1 : Final[Field] = Field(
    name='cp_imp1',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_array[1],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CP service consumption for importance level 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
cp_imp1.__doc__ = """CP service consumption for importance level 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

cp_imp2 : Final[Field] = Field(
    name='cp_imp2',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_array[2],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CP service consumption for importance level 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
cp_imp2.__doc__ = """CP service consumption for importance level 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

cp_imp3 : Final[Field] = Field(
    name='cp_imp3',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_array[3],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CP service consumption for importance level 3(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
cp_imp3.__doc__ = """CP service consumption for importance level 3(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

cp_imp4 : Final[Field] = Field(
    name='cp_imp4',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_array[4],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CP service consumption for importance level 4(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
cp_imp4.__doc__ = """CP service consumption for importance level 4(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

cp_imp5 : Final[Field] = Field(
    name='cp_imp5',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_array[5],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CP service consumption for importance level 5(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
cp_imp5.__doc__ = """CP service consumption for importance level 5(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

cp_disc : Final[Field] = Field(
    name='cp_disc',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_array[6],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CP service consumption for importance discretionary(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
cp_disc.__doc__ = """CP service consumption for importance discretionary(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

cp_free : Final[Field] = Field(
    name='cp_free',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_array[7],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""CP free service capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
cp_free.__doc__ = """CP free service capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_array`(`SMF99_ILSU_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains.

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

zaap_sys : Final[Field] = Field(
    name='zaap_sys',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_zaap_array[0],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP service consumption for importance sys(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
zaap_sys.__doc__ = """zAAP service consumption for importance sys(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

zaap_imp1 : Final[Field] = Field(
    name='zaap_imp1',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_zaap_array[1],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP service consumption for importance level 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
zaap_imp1.__doc__ = """zAAP service consumption for importance level 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

zaap_imp2 : Final[Field] = Field(
    name='zaap_imp2',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_zaap_array[2],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP service consumption for importance level 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
zaap_imp2.__doc__ = """zAAP service consumption for importance level 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

zaap_imp3 : Final[Field] = Field(
    name='zaap_imp3',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_zaap_array[3],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP service consumption for importance level 3(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
zaap_imp3.__doc__ = """zAAP service consumption for importance level 3(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

zaap_imp4 : Final[Field] = Field(
    name='zaap_imp4',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_zaap_array[4],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP service consumption for importance level 4(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
zaap_imp4.__doc__ = """zAAP service consumption for importance level 4(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

zaap_imp5 : Final[Field] = Field(
    name='zaap_imp5',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_zaap_array[5],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP service consumption for importance level 5(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
zaap_imp5.__doc__ = """zAAP service consumption for importance level 5(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

zaap_disc : Final[Field] = Field(
    name='zaap_disc',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_zaap_array[6],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP service consumption for importance discretionary(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
zaap_disc.__doc__ = """zAAP service consumption for importance discretionary(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

zaap_free : Final[Field] = Field(
    name='zaap_free',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_zaap_array[7],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zAAP free service capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
zaap_free.__doc__ = """zAAP free service capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_zaap_array`(`SMF99_ILSU_ZAAP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

ziip_sys : Final[Field] = Field(
    name='ziip_sys',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_ziip_array[0],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP service consumption for importance sys(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
ziip_sys.__doc__ = """zIIP service consumption for importance sys(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

ziip_imp1 : Final[Field] = Field(
    name='ziip_imp1',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_ziip_array[1],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP service consumption for importance level 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
ziip_imp1.__doc__ = """zIIP service consumption for importance level 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

ziip_imp2 : Final[Field] = Field(
    name='ziip_imp2',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_ziip_array[2],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP service consumption for importance level 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
ziip_imp2.__doc__ = """zIIP service consumption for importance level 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

ziip_imp3 : Final[Field] = Field(
    name='ziip_imp3',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_ziip_array[3],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP service consumption for importance level 3(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
ziip_imp3.__doc__ = """zIIP service consumption for importance level 3(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

ziip_imp4 : Final[Field] = Field(
    name='ziip_imp4',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_ziip_array[4],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP service consumption for importance level 4(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
ziip_imp4.__doc__ = """zIIP service consumption for importance level 4(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

ziip_imp5 : Final[Field] = Field(
    name='ziip_imp5',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_ziip_array[5],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP service consumption for importance level 5(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
ziip_imp5.__doc__ = """zIIP service consumption for importance level 5(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

ziip_disc : Final[Field] = Field(
    name='ziip_disc',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_ziip_array[6],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP service consumption for importance discretionary(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
ziip_disc.__doc__ = """zIIP service consumption for importance discretionary(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

ziip_free : Final[Field] = Field(
    name='ziip_free',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=ilsu_ziip_array[7],
    record=record,
    record_map=SMF99_S1_SS_MAP,
)
"""zIIP free service capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
ziip_free.__doc__ = """zIIP free service capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ilsu_ziip_array`(`SMF99_ILSU_ZIIP_ARRAY`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SS_MAP`

"Description of the array: A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains."

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

pagp_bw : Final[Field] = Field(
    name='pagp_bw',
    origin='SMF99_PAGP_BW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_PP_MAP,
)
"""Bucket width

SMF Info
--------
    Field: `SMF99_PAGP_BW`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Bucket width
"""
pagp_bw.__doc__ = """Bucket width

SMF Info
--------
    Field: `SMF99_PAGP_BW`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Bucket width
"""

pagp_lstx : Final[Field] = Field(
    name='pagp_lstx',
    origin='SMF99_PAGP_LSTX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_PP_MAP,
)
"""Last plotted x bucket

SMF Info
--------
    Field: `SMF99_PAGP_LSTX`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Last plotted x bucket
"""
pagp_lstx.__doc__ = """Last plotted x bucket

SMF Info
--------
    Field: `SMF99_PAGP_LSTX`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Last plotted x bucket
"""

pagp_points_of : Final[Field] = Field(
    name='pagp_points_of',
    origin='SMF99_PAGP_POINTS_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_PP_MAP,
)
"""Offset of point entries

SMF Info
--------
    Field: `SMF99_PAGP_POINTS_OF`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Offset of point entries
"""
pagp_points_of.__doc__ = """Offset of point entries

SMF Info
--------
    Field: `SMF99_PAGP_POINTS_OF`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Offset of point entries
"""

pagp_points_on : Final[Field] = Field(
    name='pagp_points_on',
    origin='SMF99_PAGP_POINTS_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_PP_MAP,
)
"""Number of point entries

SMF Info
--------
    Field: `SMF99_PAGP_POINTS_ON`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Number of point entries
"""
pagp_points_on.__doc__ = """Number of point entries

SMF Info
--------
    Field: `SMF99_PAGP_POINTS_ON`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Number of point entries
"""

pagp_points_ln : Final[Field] = Field(
    name='pagp_points_ln',
    origin='SMF99_PAGP_POINTS_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_PP_MAP,
)
"""Length of a point entry

SMF Info
--------
    Field: `SMF99_PAGP_POINTS_LN`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Length of a point entry
"""
pagp_points_ln.__doc__ = """Length of a point entry

SMF Info
--------
    Field: `SMF99_PAGP_POINTS_LN`
    Record: `SMF99S1`
    Map: `SMF99_S1_PP_MAP`

Length of a point entry
"""

slconfigflags : Final[Field] = Field(
    name='slconfigflags',
    origin='SMF99_SLCONFIGFLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Configuration flags

SMF Info
--------
    Field: `SMF99_SLCONFIGFLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Configuration flags
"""
slconfigflags.__doc__ = """Configuration flags

SMF Info
--------
    Field: `SMF99_SLCONFIGFLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Configuration flags
"""

slstsi : Final[Field] = Field(
    name='slstsi',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=slconfigflags,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Indicates that the machine supports the store system information instruction.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that the machine supports the store system information instruction.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
slstsi.__doc__ = """Indicates that the machine supports the store system information instruction.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that the machine supports the store system information instruction.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sllpar : Final[Field] = Field(
    name='sllpar',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=slconfigflags,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Indicates that MVS is running in a logical partition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that MVS is running in a logical partition

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sllpar.__doc__ = """Indicates that MVS is running in a logical partition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that MVS is running in a logical partition

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

slvm : Final[Field] = Field(
    name='slvm',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=slconfigflags,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Indicates that MVS is running in a virtual machine(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that MVS is running in a virtual machine

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
slvm.__doc__ = """Indicates that MVS is running in a virtual machine(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that MVS is running in a virtual machine

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

slhassharedlogicalcpus : Final[Field] = Field(
    name='slhassharedlogicalcpus',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=slconfigflags,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Indicates that the logical CPUs are shared with other partitions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that the logical CPUs are shared with other partitions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
slhassharedlogicalcpus.__doc__ = """Indicates that the logical CPUs are shared with other partitions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that the logical CPUs are shared with other partitions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

slcappedbycustomer : Final[Field] = Field(
    name='slcappedbycustomer',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=slconfigflags,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Indicates that the logical partition is configured to be capped (as opposed to being capped by WLM)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that the logical partition is configured to be capped (as opposed to being capped by WLM)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
slcappedbycustomer.__doc__ = """Indicates that the logical partition is configured to be capped (as opposed to being capped by WLM)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slconfigflags`(`SMF99_SLCONFIGFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that the logical partition is configured to be capped (as opposed to being capped by WLM)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

slstateflags : Final[Field] = Field(
    name='slstateflags',
    origin='SMF99_SLSTATEFLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""State flags.

SMF Info
--------
    Field: `SMF99_SLSTATEFLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

State flags.
"""
slstateflags.__doc__ = """State flags.

SMF Info
--------
    Field: `SMF99_SLSTATEFLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

State flags.
"""

slcappedbywlm : Final[Field] = Field(
    name='slcappedbywlm',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=slstateflags,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Indicates that the logical partition is capped by WLM.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slstateflags`(`SMF99_SLSTATEFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that the logical partition is capped by WLM.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
slcappedbywlm.__doc__ = """Indicates that the logical partition is capped by WLM.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `slstateflags`(`SMF99_SLSTATEFLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Indicates that the logical partition is capped by WLM.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

slimgcapacity : Final[Field] = Field(
    name='slimgcapacity',
    origin='SMF99_SLIMGCAPACITY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Capacity available to MVS image in millions of service units per hour, when not running as VM guest. If running as VM guest, capacity available to VM.

SMF Info
--------
    Field: `SMF99_SLIMGCAPACITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Capacity available to MVS image in millions of service units per hour, when not running as VM guest. If running as VM guest, capacity available to VM.
"""
slimgcapacity.__doc__ = """Capacity available to MVS image in millions of service units per hour, when not running as VM guest. If running as VM guest, capacity available to VM.

SMF Info
--------
    Field: `SMF99_SLIMGCAPACITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Capacity available to MVS image in millions of service units per hour, when not running as VM guest. If running as VM guest, capacity available to VM.
"""

slceccapacity : Final[Field] = Field(
    name='slceccapacity',
    origin='SMF99_SLCECCAPACITY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Capacity of CEC in millions of service units per hour.

SMF Info
--------
    Field: `SMF99_SLCECCAPACITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Capacity of CEC in millions of service units per hour.
"""
slceccapacity.__doc__ = """Capacity of CEC in millions of service units per hour.

SMF Info
--------
    Field: `SMF99_SLCECCAPACITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Capacity of CEC in millions of service units per hour.
"""

slceccpucount : Final[Field] = Field(
    name='slceccpucount',
    origin='SMF99_SLCECCPUCOUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Number of available CPUs in the CEC. This includes online and offline CPUs. It does not include reserved CPUs (CPUs that can be added via Capacity Upgrade on Demand).

SMF Info
--------
    Field: `SMF99_SLCECCPUCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of available CPUs in the CEC. This includes online and offline CPUs. It does not include reserved CPUs (CPUs that can be added via Capacity Upgrade on Demand).
"""
slceccpucount.__doc__ = """Number of available CPUs in the CEC. This includes online and offline CPUs. It does not include reserved CPUs (CPUs that can be added via Capacity Upgrade on Demand).

SMF Info
--------
    Field: `SMF99_SLCECCPUCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of available CPUs in the CEC. This includes online and offline CPUs. It does not include reserved CPUs (CPUs that can be added via Capacity Upgrade on Demand).
"""

sllogicalcpucount : Final[Field] = Field(
    name='sllogicalcpucount',
    origin='SMF99_SLLOGICALCPUCOUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Number of available CPUs in the logical partition. This includes online and offline CPUs. It does not include reserved CPUs (CPUs that can be added via Capacity Upgrade on Demand).

SMF Info
--------
    Field: `SMF99_SLLOGICALCPUCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of available CPUs in the logical partition. This includes online and offline CPUs. It does not include reserved CPUs (CPUs that can be added via Capacity Upgrade on Demand).
"""
sllogicalcpucount.__doc__ = """Number of available CPUs in the logical partition. This includes online and offline CPUs. It does not include reserved CPUs (CPUs that can be added via Capacity Upgrade on Demand).

SMF Info
--------
    Field: `SMF99_SLLOGICALCPUCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of available CPUs in the logical partition. This includes online and offline CPUs. It does not include reserved CPUs (CPUs that can be added via Capacity Upgrade on Demand).
"""

slcecserviceunitspersectoshare : Final[Field] = Field(
    name='slcecserviceunitspersectoshare',
    origin='SMF99_SLCECSERVICEUNITSPERSECTOSHARE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""The CEC capacity in basic-mode service units per second that is available for sharing among partitions using shared logical processors.

SMF Info
--------
    Field: `SMF99_SLCECSERVICEUNITSPERSECTOSHARE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

The CEC capacity in basic-mode service units per second that is available for sharing among partitions using shared logical processors.
"""
slcecserviceunitspersectoshare.__doc__ = """The CEC capacity in basic-mode service units per second that is available for sharing among partitions using shared logical processors.

SMF Info
--------
    Field: `SMF99_SLCECSERVICEUNITSPERSECTOSHARE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

The CEC capacity in basic-mode service units per second that is available for sharing among partitions using shared logical processors.
"""

slimgmsuatcurrentweight : Final[Field] = Field(
    name='slimgmsuatcurrentweight',
    origin='SMF99_SLIMGMSUATCURRENTWEIGHT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""MVS image capacity in millions of service units per hour that is represented by the partition's current weight.

SMF Info
--------
    Field: `SMF99_SLIMGMSUATCURRENTWEIGHT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

MVS image capacity in millions of service units per hour that is represented by the partition's current weight.
"""
slimgmsuatcurrentweight.__doc__ = """MVS image capacity in millions of service units per hour that is represented by the partition's current weight.

SMF Info
--------
    Field: `SMF99_SLIMGMSUATCURRENTWEIGHT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

MVS image capacity in millions of service units per hour that is represented by the partition's current weight.
"""

slimgcplimit : Final[Field] = Field(
    name='slimgcplimit',
    origin='SMF99_SLIMGCPLIMIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""MVS image capacity in hundredths of processor units (100=1 CPU)

SMF Info
--------
    Field: `SMF99_SLIMGCPLIMIT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

MVS image capacity in hundredths of processor units (100=1 CPU)
"""
slimgcplimit.__doc__ = """MVS image capacity in hundredths of processor units (100=1 CPU)

SMF Info
--------
    Field: `SMF99_SLIMGCPLIMIT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

MVS image capacity in hundredths of processor units (100=1 CPU)
"""

slavgmsu : Final[Field] = Field(
    name='slavgmsu',
    origin='SMF99_SLAVGMSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Average service rate in millions of service units per hour. This is a long-term average.

SMF Info
--------
    Field: `SMF99_SLAVGMSU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Average service rate in millions of service units per hour. This is a long-term average.
"""
slavgmsu.__doc__ = """Average service rate in millions of service units per hour. This is a long-term average.

SMF Info
--------
    Field: `SMF99_SLAVGMSU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Average service rate in millions of service units per hour. This is a long-term average.
"""

slavgmsucapped : Final[Field] = Field(
    name='slavgmsucapped',
    origin='SMF99_SLAVGMSUCAPPED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Average service rate in millions of service units per hour while the partition was capped. This is a short-term average.

SMF Info
--------
    Field: `SMF99_SLAVGMSUCAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Average service rate in millions of service units per hour while the partition was capped. This is a short-term average.
"""
slavgmsucapped.__doc__ = """Average service rate in millions of service units per hour while the partition was capped. This is a short-term average.

SMF Info
--------
    Field: `SMF99_SLAVGMSUCAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Average service rate in millions of service units per hour while the partition was capped. This is a short-term average.
"""

slavgmsuuncapped : Final[Field] = Field(
    name='slavgmsuuncapped',
    origin='SMF99_SLAVGMSUUNCAPPED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Average service rate in millions of service units per hour while the partition was uncapped. This is a short-term average

SMF Info
--------
    Field: `SMF99_SLAVGMSUUNCAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Average service rate in millions of service units per hour while the partition was uncapped. This is a short-term average
"""
slavgmsuuncapped.__doc__ = """Average service rate in millions of service units per hour while the partition was uncapped. This is a short-term average

SMF Info
--------
    Field: `SMF99_SLAVGMSUUNCAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Average service rate in millions of service units per hour while the partition was uncapped. This is a short-term average
"""

slintervalservice : Final[Field] = Field(
    name='slintervalservice',
    origin='SMF99_SLINTERVALSERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.

SMF Info
--------
    Field: `SMF99_SLINTERVALSERVICE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.
"""
slintervalservice.__doc__ = """Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.

SMF Info
--------
    Field: `SMF99_SLINTERVALSERVICE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.
"""

slintervaltime : Final[Field] = Field(
    name='slintervaltime',
    origin='SMF99_SLINTERVALTIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Elapsed time over last policy adjustment interval in 1.024 milliseconds

SMF Info
--------
    Field: `SMF99_SLINTERVALTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Elapsed time over last policy adjustment interval in 1.024 milliseconds
"""
slintervaltime.__doc__ = """Elapsed time over last policy adjustment interval in 1.024 milliseconds

SMF Info
--------
    Field: `SMF99_SLINTERVALTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Elapsed time over last policy adjustment interval in 1.024 milliseconds
"""

slrollinterval : Final[Field] = Field(
    name='slrollinterval',
    origin='SMF99_SLROLLINTERVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Number of policy adjustment intervals between computation of average service rate.

SMF Info
--------
    Field: `SMF99_SLROLLINTERVAL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of policy adjustment intervals between computation of average service rate.
"""
slrollinterval.__doc__ = """Number of policy adjustment intervals between computation of average service rate.

SMF Info
--------
    Field: `SMF99_SLROLLINTERVAL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of policy adjustment intervals between computation of average service rate.
"""

slservicetableintervals : Final[Field] = Field(
    name='slservicetableintervals',
    origin='SMF99_SLSERVICETABLEINTERVALS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Number of consecutive policy adjustment intervals that have passed since the last time that the service table was updated.

SMF Info
--------
    Field: `SMF99_SLSERVICETABLEINTERVALS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of consecutive policy adjustment intervals that have passed since the last time that the service table was updated.
"""
slservicetableintervals.__doc__ = """Number of consecutive policy adjustment intervals that have passed since the last time that the service table was updated.

SMF Info
--------
    Field: `SMF99_SLSERVICETABLEINTERVALS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of consecutive policy adjustment intervals that have passed since the last time that the service table was updated.
"""

slintervalstocap : Final[Field] = Field(
    name='slintervalstocap',
    origin='SMF99_SLINTERVALSTOCAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Number of consecutive policy adjustment intervals to cap the partition.

SMF Info
--------
    Field: `SMF99_SLINTERVALSTOCAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of consecutive policy adjustment intervals to cap the partition.
"""
slintervalstocap.__doc__ = """Number of consecutive policy adjustment intervals to cap the partition.

SMF Info
--------
    Field: `SMF99_SLINTERVALSTOCAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of consecutive policy adjustment intervals to cap the partition.
"""

slintervalstouncap : Final[Field] = Field(
    name='slintervalstouncap',
    origin='SMF99_SLINTERVALSTOUNCAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Number of consecutive policy adjustment intervals to uncap the partition.

SMF Info
--------
    Field: `SMF99_SLINTERVALSTOUNCAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of consecutive policy adjustment intervals to uncap the partition.
"""
slintervalstouncap.__doc__ = """Number of consecutive policy adjustment intervals to uncap the partition.

SMF Info
--------
    Field: `SMF99_SLINTERVALSTOUNCAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of consecutive policy adjustment intervals to uncap the partition.
"""

slpatternintervalcount : Final[Field] = Field(
    name='slpatternintervalcount',
    origin='SMF99_SLPATTERNINTERVALCOUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Number of consecutive policy adjustment intervals that have passed in the current cap/uncap state indicated by SMF99_SLCap pedByWlm.

SMF Info
--------
    Field: `SMF99_SLPATTERNINTERVALCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of consecutive policy adjustment intervals that have passed in the current cap/uncap state indicated by SMF99_SLCap pedByWlm.
"""
slpatternintervalcount.__doc__ = """Number of consecutive policy adjustment intervals that have passed in the current cap/uncap state indicated by SMF99_SLCap pedByWlm.

SMF Info
--------
    Field: `SMF99_SLPATTERNINTERVALCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Number of consecutive policy adjustment intervals that have passed in the current cap/uncap state indicated by SMF99_SLCap pedByWlm.
"""

sl_query_response_code : Final[Field] = Field(
    name='sl_query_response_code',
    origin='SMF99_SL_QUERY_RESPONSE_CODE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Response code from the last 'query' for lpar information

SMF Info
--------
    Field: `SMF99_SL_QUERY_RESPONSE_CODE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Response code from the last 'query' for lpar information
"""
sl_query_response_code.__doc__ = """Response code from the last 'query' for lpar information

SMF Info
--------
    Field: `SMF99_SL_QUERY_RESPONSE_CODE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Response code from the last 'query' for lpar information
"""

sl_setcap_response_code : Final[Field] = Field(
    name='sl_setcap_response_code',
    origin='SMF99_SL_SETCAP_RESPONSE_CODE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Response code from the last attempt to 'set capping flags'

SMF Info
--------
    Field: `SMF99_SL_SETCAP_RESPONSE_CODE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Response code from the last attempt to 'set capping flags'
"""
sl_setcap_response_code.__doc__ = """Response code from the last attempt to 'set capping flags'

SMF Info
--------
    Field: `SMF99_SL_SETCAP_RESPONSE_CODE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Response code from the last attempt to 'set capping flags'
"""

slintervalservice_zaap : Final[Field] = Field(
    name='slintervalservice_zaap',
    origin='SMF99_SLINTERVALSERVICE_ZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""ZAAP Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.

SMF Info
--------
    Field: `SMF99_SLINTERVALSERVICE_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

ZAAP Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.
"""
slintervalservice_zaap.__doc__ = """ZAAP Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.

SMF Info
--------
    Field: `SMF99_SLINTERVALSERVICE_ZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

ZAAP Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.
"""

slintervalservice_ziip : Final[Field] = Field(
    name='slintervalservice_ziip',
    origin='SMF99_SLINTERVALSERVICE_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""ZIIP Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.

SMF Info
--------
    Field: `SMF99_SLINTERVALSERVICE_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

ZIIP Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.
"""
slintervalservice_ziip.__doc__ = """ZIIP Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.

SMF Info
--------
    Field: `SMF99_SLINTERVALSERVICE_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

ZIIP Service units over last policy adjustment interval. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated by SRM.
"""

slunusedscaling : Final[Field] = Field(
    name='slunusedscaling',
    origin='SMF99_SLUNUSEDSCALING',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""The scaling factor of unused group capacity which is stored in 48 buckets in the service table

SMF Info
--------
    Field: `SMF99_SLUNUSEDSCALING`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

The scaling factor of unused group capacity which is stored in 48 buckets in the service table
"""
slunusedscaling.__doc__ = """The scaling factor of unused group capacity which is stored in 48 buckets in the service table

SMF Info
--------
    Field: `SMF99_SLUNUSEDSCALING`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

The scaling factor of unused group capacity which is stored in 48 buckets in the service table
"""

hardwaregroupname : Final[Field] = Field(
    name='hardwaregroupname',
    origin='SMF99_HARDWAREGROUPNAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units

SMF Info
--------
    Field: `SMF99_HARDWAREGROUPNAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units
"""
hardwaregroupname.__doc__ = """Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units

SMF Info
--------
    Field: `SMF99_HARDWAREGROUPNAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units
"""

hardwaregroupcputypecapcp : Final[Field] = Field(
    name='hardwaregroupcputypecapcp',
    origin='SMF99_HARDWAREGROUPCPUTYPECAPCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units

SMF Info
--------
    Field: `SMF99_HARDWAREGROUPCPUTYPECAPCP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units
"""
hardwaregroupcputypecapcp.__doc__ = """Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units

SMF Info
--------
    Field: `SMF99_HARDWAREGROUPCPUTYPECAPCP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units
"""

hardwaregroupcputypecapzaap : Final[Field] = Field(
    name='hardwaregroupcputypecapzaap',
    origin='SMF99_HARDWAREGROUPCPUTYPECAPZAAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units

SMF Info
--------
    Field: `SMF99_HARDWAREGROUPCPUTYPECAPZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units
"""
hardwaregroupcputypecapzaap.__doc__ = """Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units

SMF Info
--------
    Field: `SMF99_HARDWAREGROUPCPUTYPECAPZAAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units
"""

hardwaregroupcputypecapziip : Final[Field] = Field(
    name='hardwaregroupcputypecapziip',
    origin='SMF99_HARDWAREGROUPCPUTYPECAPZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units

SMF Info
--------
    Field: `SMF99_HARDWAREGROUPCPUTYPECAPZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units
"""
hardwaregroupcputypecapziip.__doc__ = """Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units

SMF Info
--------
    Field: `SMF99_HARDWAREGROUPCPUTYPECAPZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Hardware Group is capped by PR/SM to a limit which is defined in hundredths of processor units
"""

rtcapleadtime : Final[Field] = Field(
    name='rtcapleadtime',
    origin='SMF99_RTCAPLEADTIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""RTCapLeadTime OPT parameter (in minutes)

SMF Info
--------
    Field: `SMF99_RTCAPLEADTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

RTCapLeadTime OPT parameter (in minutes)
"""
rtcapleadtime.__doc__ = """RTCapLeadTime OPT parameter (in minutes)

SMF Info
--------
    Field: `SMF99_RTCAPLEADTIME`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

RTCapLeadTime OPT parameter (in minutes)
"""

time_to_cap : Final[Field] = Field(
    name='time_to_cap',
    origin='SMF99_TIME_TO_CAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated remaining time (in seconds) before the image will be capped

SMF Info
--------
    Field: `SMF99_TIME_TO_CAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated remaining time (in seconds) before the image will be capped
"""
time_to_cap.__doc__ = """estimated remaining time (in seconds) before the image will be capped

SMF Info
--------
    Field: `SMF99_TIME_TO_CAP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated remaining time (in seconds) before the image will be capped
"""

time_to_cap_group : Final[Field] = Field(
    name='time_to_cap_group',
    origin='SMF99_TIME_TO_CAP_GROUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated remaining time (in seconds) before the group will be capped

SMF Info
--------
    Field: `SMF99_TIME_TO_CAP_GROUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated remaining time (in seconds) before the group will be capped
"""
time_to_cap_group.__doc__ = """estimated remaining time (in seconds) before the group will be capped

SMF Info
--------
    Field: `SMF99_TIME_TO_CAP_GROUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated remaining time (in seconds) before the group will be capped
"""

time_to_cap_dc : Final[Field] = Field(
    name='time_to_cap_dc',
    origin='SMF99_TIME_TO_CAP_DC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated remaining time (in seconds) before the image will be reach its DC limit

SMF Info
--------
    Field: `SMF99_TIME_TO_CAP_DC`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated remaining time (in seconds) before the image will be reach its DC limit
"""
time_to_cap_dc.__doc__ = """estimated remaining time (in seconds) before the image will be reach its DC limit

SMF Info
--------
    Field: `SMF99_TIME_TO_CAP_DC`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated remaining time (in seconds) before the image will be reach its DC limit
"""

fc_service : Final[Field] = Field(
    name='fc_service',
    origin='SMF99_FC_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated service for capping forecast

SMF Info
--------
    Field: `SMF99_FC_SERVICE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated service for capping forecast
"""
fc_service.__doc__ = """estimated service for capping forecast

SMF Info
--------
    Field: `SMF99_FC_SERVICE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated service for capping forecast
"""

fc_msu : Final[Field] = Field(
    name='fc_msu',
    origin='SMF99_FC_MSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated MSUs for capping forecast

SMF Info
--------
    Field: `SMF99_FC_MSU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated MSUs for capping forecast
"""
fc_msu.__doc__ = """estimated MSUs for capping forecast

SMF Info
--------
    Field: `SMF99_FC_MSU`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated MSUs for capping forecast
"""

fc_unused : Final[Field] = Field(
    name='fc_unused',
    origin='SMF99_FC_UNUSED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated unused service

SMF Info
--------
    Field: `SMF99_FC_UNUSED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated unused service
"""
fc_unused.__doc__ = """estimated unused service

SMF Info
--------
    Field: `SMF99_FC_UNUSED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated unused service
"""

fc_imgmsulimit : Final[Field] = Field(
    name='fc_imgmsulimit',
    origin='SMF99_FC_IMGMSULIMIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated image limit at LcctTime2Cap

SMF Info
--------
    Field: `SMF99_FC_IMGMSULIMIT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated image limit at LcctTime2Cap
"""
fc_imgmsulimit.__doc__ = """estimated image limit at LcctTime2Cap

SMF Info
--------
    Field: `SMF99_FC_IMGMSULIMIT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated image limit at LcctTime2Cap
"""

fc_imgmsulimitgroup : Final[Field] = Field(
    name='fc_imgmsulimitgroup',
    origin='SMF99_FC_IMGMSULIMITGROUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated image limit at LcctTime2CapGroup

SMF Info
--------
    Field: `SMF99_FC_IMGMSULIMITGROUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated image limit at LcctTime2CapGroup
"""
fc_imgmsulimitgroup.__doc__ = """estimated image limit at LcctTime2CapGroup

SMF Info
--------
    Field: `SMF99_FC_IMGMSULIMITGROUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated image limit at LcctTime2CapGroup
"""

fc_lastbucketpercent : Final[Field] = Field(
    name='fc_lastbucketpercent',
    origin='SMF99_FC_LASTBUCKETPERCENT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""much of the last bucket is used for the calculation of the service forecast (%)

SMF Info
--------
    Field: `SMF99_FC_LASTBUCKETPERCENT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

much of the last bucket is used for the calculation of the service forecast (%)
"""
fc_lastbucketpercent.__doc__ = """much of the last bucket is used for the calculation of the service forecast (%)

SMF Info
--------
    Field: `SMF99_FC_LASTBUCKETPERCENT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

much of the last bucket is used for the calculation of the service forecast (%)
"""

fc_newunusedavg : Final[Field] = Field(
    name='fc_newunusedavg',
    origin='SMF99_FC_NEWUNUSEDAVG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated unused MSU average (scaled by 1000)

SMF Info
--------
    Field: `SMF99_FC_NEWUNUSEDAVG`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated unused MSU average (scaled by 1000)
"""
fc_newunusedavg.__doc__ = """estimated unused MSU average (scaled by 1000)

SMF Info
--------
    Field: `SMF99_FC_NEWUNUSEDAVG`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated unused MSU average (scaled by 1000)
"""

fc_donatedsus : Final[Field] = Field(
    name='fc_donatedsus',
    origin='SMF99_FC_DONATEDSUS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""These service units have been donated by one or more group members during the last complete five minute interval

SMF Info
--------
    Field: `SMF99_FC_DONATEDSUS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

These service units have been donated by one or more group members during the last complete five minute interval
"""
fc_donatedsus.__doc__ = """These service units have been donated by one or more group members during the last complete five minute interval

SMF Info
--------
    Field: `SMF99_FC_DONATEDSUS`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

These service units have been donated by one or more group members during the last complete five minute interval
"""

fc_capdiff : Final[Field] = Field(
    name='fc_capdiff',
    origin='SMF99_FC_CAPDIFF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""capacity difference (soft cap)

SMF Info
--------
    Field: `SMF99_FC_CAPDIFF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

capacity difference (soft cap)
"""
fc_capdiff.__doc__ = """capacity difference (soft cap)

SMF Info
--------
    Field: `SMF99_FC_CAPDIFF`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

capacity difference (soft cap)
"""

fc_capdiffportion : Final[Field] = Field(
    name='fc_capdiffportion',
    origin='SMF99_FC_CAPDIFFPORTION',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""capacity difference (soft cap) for ILSS

SMF Info
--------
    Field: `SMF99_FC_CAPDIFFPORTION`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

capacity difference (soft cap) for ILSS
"""
fc_capdiffportion.__doc__ = """capacity difference (soft cap) for ILSS

SMF Info
--------
    Field: `SMF99_FC_CAPDIFFPORTION`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

capacity difference (soft cap) for ILSS
"""

fc_capdiffgroup : Final[Field] = Field(
    name='fc_capdiffgroup',
    origin='SMF99_FC_CAPDIFFGROUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""capacity difference (group cap)

SMF Info
--------
    Field: `SMF99_FC_CAPDIFFGROUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

capacity difference (group cap)
"""
fc_capdiffgroup.__doc__ = """capacity difference (group cap)

SMF Info
--------
    Field: `SMF99_FC_CAPDIFFGROUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

capacity difference (group cap)
"""

fc_capdiffportiongroup : Final[Field] = Field(
    name='fc_capdiffportiongroup',
    origin='SMF99_FC_CAPDIFFPORTIONGROUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""capacity difference (group cap) for ILSS

SMF Info
--------
    Field: `SMF99_FC_CAPDIFFPORTIONGROUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

capacity difference (group cap) for ILSS
"""
fc_capdiffportiongroup.__doc__ = """capacity difference (group cap) for ILSS

SMF Info
--------
    Field: `SMF99_FC_CAPDIFFPORTIONGROUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

capacity difference (group cap) for ILSS
"""

time_to_cap_gcshare : Final[Field] = Field(
    name='time_to_cap_gcshare',
    origin='SMF99_TIME_TO_CAP_GCSHARE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""estimated remaining time (in seconds) before the image will be reach its GC limit share

SMF Info
--------
    Field: `SMF99_TIME_TO_CAP_GCSHARE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated remaining time (in seconds) before the image will be reach its GC limit share
"""
time_to_cap_gcshare.__doc__ = """estimated remaining time (in seconds) before the image will be reach its GC limit share

SMF Info
--------
    Field: `SMF99_TIME_TO_CAP_GCSHARE`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

estimated remaining time (in seconds) before the image will be reach its GC limit share
"""

slimgcapacity_zcbp : Final[Field] = Field(
    name='slimgcapacity_zcbp',
    origin='SMF99_SLIMGCAPACITY_ZCBP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_SLIMGCAPACITY_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

For IBM use only
"""
slimgcapacity_zcbp.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_SLIMGCAPACITY_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

For IBM use only
"""

slceccapacity_zcbp : Final[Field] = Field(
    name='slceccapacity_zcbp',
    origin='SMF99_SLCECCAPACITY_ZCBP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_SLCECCAPACITY_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

For IBM use only
"""
slceccapacity_zcbp.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_SLCECCAPACITY_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

For IBM use only
"""

slceccpucount_zcbp : Final[Field] = Field(
    name='slceccpucount_zcbp',
    origin='SMF99_SLCECCPUCOUNT_ZCBP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_SLCECCPUCOUNT_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

For IBM use only
"""
slceccpucount_zcbp.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_SLCECCPUCOUNT_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

For IBM use only
"""

sllogicalcpucount_zcbp : Final[Field] = Field(
    name='sllogicalcpucount_zcbp',
    origin='SMF99_SLLOGICALCPUCOUNT_ZCBP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_SLLOGICALCPUCOUNT_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

For IBM use only
"""
sllogicalcpucount_zcbp.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_SLLOGICALCPUCOUNT_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

For IBM use only
"""

sus_ziip : Final[Field] = Field(
    name='sus_ziip',
    origin='SMF99_SUS_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Total unweighted zIIP-eligible service units spent on zIIP

SMF Info
--------
    Field: `SMF99_SUS_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Total unweighted zIIP-eligible service units spent on zIIP
"""
sus_ziip.__doc__ = """Total unweighted zIIP-eligible service units spent on zIIP

SMF Info
--------
    Field: `SMF99_SUS_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Total unweighted zIIP-eligible service units spent on zIIP
"""

sus_ziip_on_cp : Final[Field] = Field(
    name='sus_ziip_on_cp',
    origin='SMF99_SUS_ZIIP_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Total unweighted zIIP-eligible service units spent on CP

SMF Info
--------
    Field: `SMF99_SUS_ZIIP_ON_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Total unweighted zIIP-eligible service units spent on CP
"""
sus_ziip_on_cp.__doc__ = """Total unweighted zIIP-eligible service units spent on CP

SMF Info
--------
    Field: `SMF99_SUS_ZIIP_ON_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Total unweighted zIIP-eligible service units spent on CP
"""

sus_java_on_ziip : Final[Field] = Field(
    name='sus_java_on_ziip',
    origin='SMF99_SUS_JAVA_ON_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Total unweighted zIIP-eligible Java service units spent on zIIP

SMF Info
--------
    Field: `SMF99_SUS_JAVA_ON_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Total unweighted zIIP-eligible Java service units spent on zIIP
"""
sus_java_on_ziip.__doc__ = """Total unweighted zIIP-eligible Java service units spent on zIIP

SMF Info
--------
    Field: `SMF99_SUS_JAVA_ON_ZIIP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Total unweighted zIIP-eligible Java service units spent on zIIP
"""

sus_java_on_cp : Final[Field] = Field(
    name='sus_java_on_cp',
    origin='SMF99_SUS_JAVA_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SL_MAP,
)
"""Total unweighted zIIP-eligible Java service units spent on CP

SMF Info
--------
    Field: `SMF99_SUS_JAVA_ON_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Total unweighted zIIP-eligible Java service units spent on CP
"""
sus_java_on_cp.__doc__ = """Total unweighted zIIP-eligible Java service units spent on CP

SMF Info
--------
    Field: `SMF99_SUS_JAVA_ON_CP`
    Record: `SMF99S1`
    Map: `SMF99_S1_SL_MAP`

Total unweighted zIIP-eligible Java service units spent on CP
"""

plot_xval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_PP_MAP : Final[Field] = Field(
    name='plot_xval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_PP_MAP',
    origin='SMF99_PLOT_XVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_PP_MAP,
)
"""X value of point plotted in a bucket

SMF Info
--------
    Field: `SMF99_PLOT_XVAL`
    Record: `SMF99S1`
    Map: `SMF99_ONE_CURVE_POINT_MAP`

X value of point plotted in a bucket
"""
plot_xval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_PP_MAP.__doc__ = """X value of point plotted in a bucket

SMF Info
--------
    Field: `SMF99_PLOT_XVAL`
    Record: `SMF99S1`
    Map: `SMF99_ONE_CURVE_POINT_MAP`

X value of point plotted in a bucket
"""

plot_yval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_PP_MAP : Final[Field] = Field(
    name='plot_yval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_PP_MAP',
    origin='SMF99_PLOT_YVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_PP_MAP,
)
"""Y value of point plotted in a bucket

SMF Info
--------
    Field: `SMF99_PLOT_YVAL`
    Record: `SMF99S1`
    Map: `SMF99_ONE_CURVE_POINT_MAP`

Y value of point plotted in a bucket
"""
plot_yval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_PP_MAP.__doc__ = """Y value of point plotted in a bucket

SMF Info
--------
    Field: `SMF99_PLOT_YVAL`
    Record: `SMF99S1`
    Map: `SMF99_ONE_CURVE_POINT_MAP`

Y value of point plotted in a bucket
"""

bp_res_name : Final[Field] = Field(
    name='bp_res_name',
    origin='SMF99_BP_RES_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Name of Buffer Pool

SMF Info
--------
    Field: `SMF99_BP_RES_NAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Name of Buffer Pool
"""
bp_res_name.__doc__ = """Name of Buffer Pool

SMF Info
--------
    Field: `SMF99_BP_RES_NAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Name of Buffer Pool
"""

bp_as_name : Final[Field] = Field(
    name='bp_as_name',
    origin='SMF99_BP_AS_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Name of owning AS

SMF Info
--------
    Field: `SMF99_BP_AS_NAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Name of owning AS
"""
bp_as_name.__doc__ = """Name of owning AS

SMF Info
--------
    Field: `SMF99_BP_AS_NAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Name of owning AS
"""

bp_res_tkn : Final[Field] = Field(
    name='bp_res_tkn',
    origin='SMF99_BP_RES_TKN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""BP Token

SMF Info
--------
    Field: `SMF99_BP_RES_TKN`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

BP Token
"""
bp_res_tkn.__doc__ = """BP Token

SMF Info
--------
    Field: `SMF99_BP_RES_TKN`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

BP Token
"""

bp_sc_name : Final[Field] = Field(
    name='bp_sc_name',
    origin='SMF99_BP_SC_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Name of related service class

SMF Info
--------
    Field: `SMF99_BP_SC_NAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Name of related service class
"""
bp_sc_name.__doc__ = """Name of related service class

SMF Info
--------
    Field: `SMF99_BP_SC_NAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Name of related service class
"""

bp_adj_size : Final[Field] = Field(
    name='bp_adj_size',
    origin='SMF99_BP_ADJ_SIZE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Min adjustment size for buffer pool

SMF Info
--------
    Field: `SMF99_BP_ADJ_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Min adjustment size for buffer pool
"""
bp_adj_size.__doc__ = """Min adjustment size for buffer pool

SMF Info
--------
    Field: `SMF99_BP_ADJ_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Min adjustment size for buffer pool
"""

bp_min_size : Final[Field] = Field(
    name='bp_min_size',
    origin='SMF99_BP_MIN_SIZE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Minimum size for buffer pool

SMF Info
--------
    Field: `SMF99_BP_MIN_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Minimum size for buffer pool
"""
bp_min_size.__doc__ = """Minimum size for buffer pool

SMF Info
--------
    Field: `SMF99_BP_MIN_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Minimum size for buffer pool
"""

bp_max_size : Final[Field] = Field(
    name='bp_max_size',
    origin='SMF99_BP_MAX_SIZE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Max size for buffer pool

SMF Info
--------
    Field: `SMF99_BP_MAX_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Max size for buffer pool
"""
bp_max_size.__doc__ = """Max size for buffer pool

SMF Info
--------
    Field: `SMF99_BP_MAX_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Max size for buffer pool
"""

bp_use_size : Final[Field] = Field(
    name='bp_use_size',
    origin='SMF99_BP_USE_SIZE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""used size of buffer pool

SMF Info
--------
    Field: `SMF99_BP_USE_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

used size of buffer pool
"""
bp_use_size.__doc__ = """used size of buffer pool

SMF Info
--------
    Field: `SMF99_BP_USE_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

used size of buffer pool
"""

bp_cur_size : Final[Field] = Field(
    name='bp_cur_size',
    origin='SMF99_BP_CUR_SIZE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""current size of buffer pool

SMF Info
--------
    Field: `SMF99_BP_CUR_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

current size of buffer pool
"""
bp_cur_size.__doc__ = """current size of buffer pool

SMF Info
--------
    Field: `SMF99_BP_CUR_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

current size of buffer pool
"""

bp_target_size : Final[Field] = Field(
    name='bp_target_size',
    origin='SMF99_BP_TARGET_SIZE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""target size of buffer pool

SMF Info
--------
    Field: `SMF99_BP_TARGET_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

target size of buffer pool
"""
bp_target_size.__doc__ = """target size of buffer pool

SMF Info
--------
    Field: `SMF99_BP_TARGET_SIZE`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

target size of buffer pool
"""

bphr_bw : Final[Field] = Field(
    name='bphr_bw',
    origin='SMF99_BPHR_BW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Bucket width

SMF Info
--------
    Field: `SMF99_BPHR_BW`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Bucket width
"""
bphr_bw.__doc__ = """Bucket width

SMF Info
--------
    Field: `SMF99_BPHR_BW`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Bucket width
"""

bphr_lstx : Final[Field] = Field(
    name='bphr_lstx',
    origin='SMF99_BPHR_LSTX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Last plotted x bucket

SMF Info
--------
    Field: `SMF99_BPHR_LSTX`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Last plotted x bucket
"""
bphr_lstx.__doc__ = """Last plotted x bucket

SMF Info
--------
    Field: `SMF99_BPHR_LSTX`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Last plotted x bucket
"""

bphr_points_of : Final[Field] = Field(
    name='bphr_points_of',
    origin='SMF99_BPHR_POINTS_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Offset of point entries

SMF Info
--------
    Field: `SMF99_BPHR_POINTS_OF`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Offset of point entries
"""
bphr_points_of.__doc__ = """Offset of point entries

SMF Info
--------
    Field: `SMF99_BPHR_POINTS_OF`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Offset of point entries
"""

bphr_points_on : Final[Field] = Field(
    name='bphr_points_on',
    origin='SMF99_BPHR_POINTS_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Number of point entries

SMF Info
--------
    Field: `SMF99_BPHR_POINTS_ON`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Number of point entries
"""
bphr_points_on.__doc__ = """Number of point entries

SMF Info
--------
    Field: `SMF99_BPHR_POINTS_ON`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Number of point entries
"""

bphr_points_ln : Final[Field] = Field(
    name='bphr_points_ln',
    origin='SMF99_BPHR_POINTS_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Length of a point entry

SMF Info
--------
    Field: `SMF99_BPHR_POINTS_LN`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Length of a point entry
"""
bphr_points_ln.__doc__ = """Length of a point entry

SMF Info
--------
    Field: `SMF99_BPHR_POINTS_LN`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Length of a point entry
"""

bp_hr_plot_area : Final[Field] = Field(
    name='bp_hr_plot_area',
    origin='SMF99_BP_HR_PLOT_AREA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_BP_MAP,
)
"""Storage for hit ratio plot

SMF Info
--------
    Field: `SMF99_BP_HR_PLOT_AREA`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Storage for hit ratio plot
"""
bp_hr_plot_area.__doc__ = """Storage for hit ratio plot

SMF Info
--------
    Field: `SMF99_BP_HR_PLOT_AREA`
    Record: `SMF99S1`
    Map: `SMF99_S1_BP_MAP`

Storage for hit ratio plot
"""

tpid : Final[Field] = Field(
    name='tpid',
    origin='SMF99_TPID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Policy adjustment interval identifier

SMF Info
--------
    Field: `SMF99_TPID`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Policy adjustment interval identifier
"""
tpid.__doc__ = """Policy adjustment interval identifier

SMF Info
--------
    Field: `SMF99_TPID`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Policy adjustment interval identifier
"""

trid : Final[Field] = Field(
    name='trid',
    origin='SMF99_TRID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Resource adjustment interval identifier

SMF Info
--------
    Field: `SMF99_TRID`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Resource adjustment interval identifier
"""
trid.__doc__ = """Resource adjustment interval identifier

SMF Info
--------
    Field: `SMF99_TRID`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Resource adjustment interval identifier
"""

trace : Final[Field] = Field(
    name='trace',
    origin='SMF99_TCOD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Policy adjustment action code

SMF Info
--------
    Field: `SMF99_TCOD`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Policy adjustment action code
"""
trace.__doc__ = """Policy adjustment action code

SMF Info
--------
    Field: `SMF99_TCOD`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Policy adjustment action code
"""

tjob : Final[Field] = Field(
    name='tjob',
    origin='SMF99_TJOB',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Job name of address space effected by action being traced (blank if not an address space level action)

SMF Info
--------
    Field: `SMF99_TJOB`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Job name of address space effected by action being traced (blank if not an address space level action)
"""
tjob.__doc__ = """Job name of address space effected by action being traced (blank if not an address space level action)

SMF Info
--------
    Field: `SMF99_TJOB`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Job name of address space effected by action being traced (blank if not an address space level action)
"""

tlpi : Final[Field] = Field(
    name='tlpi',
    origin='SMF99_TLPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Projected local performance index to be acheived as a result of the traced action

SMF Info
--------
    Field: `SMF99_TLPI`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Projected local performance index to be acheived as a result of the traced action
"""
tlpi.__doc__ = """Projected local performance index to be acheived as a result of the traced action

SMF Info
--------
    Field: `SMF99_TLPI`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Projected local performance index to be acheived as a result of the traced action
"""

tspi : Final[Field] = Field(
    name='tspi',
    origin='SMF99_TSPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Projected sysplex performance index to be acheived as a result of the traced action

SMF Info
--------
    Field: `SMF99_TSPI`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Projected sysplex performance index to be acheived as a result of the traced action
"""
tspi.__doc__ = """Projected sysplex performance index to be acheived as a result of the traced action

SMF Info
--------
    Field: `SMF99_TSPI`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Projected sysplex performance index to be acheived as a result of the traced action
"""

tgsr : Final[Field] = Field(
    name='tgsr',
    origin='SMF99_TGSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Projected resource group service rate be acheived as a result of the traced action

SMF Info
--------
    Field: `SMF99_TGSR`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Projected resource group service rate be acheived as a result of the traced action
"""
tgsr.__doc__ = """Projected resource group service rate be acheived as a result of the traced action

SMF Info
--------
    Field: `SMF99_TGSR`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Projected resource group service rate be acheived as a result of the traced action
"""

tdt1 : Final[Field] = Field(
    name='tdt1',
    origin='SMF99_TDT1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""System use

SMF Info
--------
    Field: `SMF99_TDT1`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""
tdt1.__doc__ = """System use

SMF Info
--------
    Field: `SMF99_TDT1`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""

tdt2 : Final[Field] = Field(
    name='tdt2',
    origin='SMF99_TDT2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""System use

SMF Info
--------
    Field: `SMF99_TDT2`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""
tdt2.__doc__ = """System use

SMF Info
--------
    Field: `SMF99_TDT2`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""

tdt3 : Final[Field] = Field(
    name='tdt3',
    origin='SMF99_TDT3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""System use

SMF Info
--------
    Field: `SMF99_TDT3`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""
tdt3.__doc__ = """System use

SMF Info
--------
    Field: `SMF99_TDT3`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""

trgn : Final[Field] = Field(
    name='trgn',
    origin='SMF99_TRGN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Resource group Name (blank if no resource group)

SMF Info
--------
    Field: `SMF99_TRGN`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Resource group Name (blank if no resource group)
"""
trgn.__doc__ = """Resource group Name (blank if no resource group)

SMF Info
--------
    Field: `SMF99_TRGN`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Resource group Name (blank if no resource group)
"""

tcnm : Final[Field] = Field(
    name='tcnm',
    origin='SMF99_TCNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Service Class Name

SMF Info
--------
    Field: `SMF99_TCNM`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Service Class Name
"""
tcnm.__doc__ = """Service Class Name

SMF Info
--------
    Field: `SMF99_TCNM`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Service Class Name
"""

tper : Final[Field] = Field(
    name='tper',
    origin='SMF99_TPER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Service period number

SMF Info
--------
    Field: `SMF99_TPER`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Service period number
"""
tper.__doc__ = """Service period number

SMF Info
--------
    Field: `SMF99_TPER`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Service period number
"""

tasid : Final[Field] = Field(
    name='tasid',
    origin='SMF99_TASID',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Address Space ID number

SMF Info
--------
    Field: `SMF99_TASID`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Address Space ID number
"""
tasid.__doc__ = """Address Space ID number

SMF Info
--------
    Field: `SMF99_TASID`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Address Space ID number
"""

tdt4 : Final[Field] = Field(
    name='tdt4',
    origin='SMF99_TDT4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""System use

SMF Info
--------
    Field: `SMF99_TDT4`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""
tdt4.__doc__ = """System use

SMF Info
--------
    Field: `SMF99_TDT4`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""

tflg : Final[Field] = Field(
    name='tflg',
    origin='SMF99_TFLG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""System use

SMF Info
--------
    Field: `SMF99_TFLG`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""
tflg.__doc__ = """System use

SMF Info
--------
    Field: `SMF99_TFLG`
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

System use
"""

tifa : Final[Field] = Field(
    name='tifa',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=tflg,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""on if trace entry is for IFA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `tflg`(`SMF99_TFLG`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

on if trace entry is for IFA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
tifa.__doc__ = """on if trace entry is for IFA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `tflg`(`SMF99_TFLG`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

on if trace entry is for IFA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

tsup : Final[Field] = Field(
    name='tsup',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=tflg,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""on if trace entry is for SUP(V)

SMF Info (Virtual Field)
--------
    Field: Based on `tflg`(`SMF99_TFLG`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

on if trace entry is for SUP

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
tsup.__doc__ = """on if trace entry is for SUP(V)

SMF Info (Virtual Field)
--------
    Field: Based on `tflg`(`SMF99_TFLG`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

on if trace entry is for SUP

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

trace_code : Final[Field] = Field(
    name='trace_code',
    origin=None,
    post='core.map',
    post_param={'map': {105: 'RA_UU_ADD_SRV_GR', 9180: 'QMPL_NA_REC QMPL', 9190: 'QMPL_NA_STOR', 9191: 'QMPL_AUX_STOR', 9195: 'QMPL_NA_RUA0', 9200: 'QMPL_NA_MPL', 9202: 'QMPL_NA_IDLE', 9205: 'QMPL_NA_QUEUE', 9210: 'QMPL_NA_PEND', 9220: 'QMPL_NA_UNMGED', 9230: 'QMPL_NA_REC_RR', 9240: 'QMPL_NA_REC_GR', 9245: 'QMPL_NA_SYSLOC', 9246: 'QMPL_NA_NOSYS', 9247: 'QMPL_LIM_GSMAX', 9250: 'INC_QMPL_GR', 9251: 'DEC_QMPL_GR', 9260: 'INC_QMPL_RR', 9261: 'DEC_QMPL_RR', 9270: 'QMPL_NA_NETVAL', 9280: 'QMPL_NA_NO_REQ', 9285: 'QMPL_NA_GSMAX', 9294: 'PA_QMPL_LIMIT_AVT', 9295: 'RA_INC_QMPL_AFF', 9296: 'QMPL_LIMIT_NUM', 9297: 'QMPL_IMPACT_PER', 9298: 'QMPL_CPU_DON', 9299: 'QMPL_INC_GSMAX'}},
    virtual=True,
    ref=trace,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Policy adjustment action code(V)

SMF Info (Virtual Field)
--------
    Field: Based on `trace`(`SMF99_TCOD`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    105 => RA_UU_ADD_SRV_GR
    9180 => QMPL_NA_REC QMPL
    9190 => QMPL_NA_STOR
    9191 => QMPL_AUX_STOR
    9195 => QMPL_NA_RUA0
    9200 => QMPL_NA_MPL
    9202 => QMPL_NA_IDLE
    9205 => QMPL_NA_QUEUE
    9210 => QMPL_NA_PEND
    9220 => QMPL_NA_UNMGED
    9230 => QMPL_NA_REC_RR
    9240 => QMPL_NA_REC_GR
    9245 => QMPL_NA_SYSLOC
    9246 => QMPL_NA_NOSYS
    9247 => QMPL_LIM_GSMAX
    9250 => INC_QMPL_GR
    9251 => DEC_QMPL_GR
    9260 => INC_QMPL_RR
    9261 => DEC_QMPL_RR
    9270 => QMPL_NA_NETVAL
    9280 => QMPL_NA_NO_REQ
    9285 => QMPL_NA_GSMAX
    9294 => PA_QMPL_LIMIT_AVT
    9295 => RA_INC_QMPL_AFF
    9296 => QMPL_LIMIT_NUM
    9297 => QMPL_IMPACT_PER
    9298 => QMPL_CPU_DON
    9299 => QMPL_INC_GSMAX
"""
trace_code.__doc__ = """Policy adjustment action code(V)

SMF Info (Virtual Field)
--------
    Field: Based on `trace`(`SMF99_TCOD`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    105 => RA_UU_ADD_SRV_GR
    9180 => QMPL_NA_REC QMPL
    9190 => QMPL_NA_STOR
    9191 => QMPL_AUX_STOR
    9195 => QMPL_NA_RUA0
    9200 => QMPL_NA_MPL
    9202 => QMPL_NA_IDLE
    9205 => QMPL_NA_QUEUE
    9210 => QMPL_NA_PEND
    9220 => QMPL_NA_UNMGED
    9230 => QMPL_NA_REC_RR
    9240 => QMPL_NA_REC_GR
    9245 => QMPL_NA_SYSLOC
    9246 => QMPL_NA_NOSYS
    9247 => QMPL_LIM_GSMAX
    9250 => INC_QMPL_GR
    9251 => DEC_QMPL_GR
    9260 => INC_QMPL_RR
    9261 => DEC_QMPL_RR
    9270 => QMPL_NA_NETVAL
    9280 => QMPL_NA_NO_REQ
    9285 => QMPL_NA_GSMAX
    9294 => PA_QMPL_LIMIT_AVT
    9295 => RA_INC_QMPL_AFF
    9296 => QMPL_LIMIT_NUM
    9297 => QMPL_IMPACT_PER
    9298 => QMPL_CPU_DON
    9299 => QMPL_INC_GSMAX
"""

trace_action : Final[Field] = Field(
    name='trace_action',
    origin=None,
    post='core.map',
    post_param={'map': {105: 'add server', 9180: 'QMPL recommendations not allowed', 9190: 'No QMPL action', 9191: 'Available auxilliary storage', 9195: 'No QMPL action', 9200: 'No QMPL action', 9202: 'No QMPL action', 9205: 'No QMPL action', 9210: 'No QMPL action', 9220: 'No QMPL action', 9230: 'No QMPL action', 9240: 'No QMPL action', 9245: 'No QMPL action', 9246: 'No QMPL action', 9247: 'QMPL increase limited', 9250: 'increase QMPL', 9251: 'decrease QMPL', 9260: 'increase QMPL', 9261: 'decrease QMPL', 9270: 'No QMPL action', 9280: 'No QMPL action', 9285: 'No QMPL action', 9294: 'Limited number of initiators', 9295: 'Start an initiator', 9296: 'Limited number of initiators', 9297: 'Impacted Period', 9298: 'Period CPU assess will be reduced', 9299: 'QMPL action'}},
    virtual=True,
    ref=trace,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Policy adjustment action code(V)

SMF Info (Virtual Field)
--------
    Field: Based on `trace`(`SMF99_TCOD`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    105 => add server
    9180 => QMPL recommendations not allowed
    9190 => No QMPL action
    9191 => Available auxilliary storage
    9195 => No QMPL action
    9200 => No QMPL action
    9202 => No QMPL action
    9205 => No QMPL action
    9210 => No QMPL action
    9220 => No QMPL action
    9230 => No QMPL action
    9240 => No QMPL action
    9245 => No QMPL action
    9246 => No QMPL action
    9247 => QMPL increase limited
    9250 => increase QMPL
    9251 => decrease QMPL
    9260 => increase QMPL
    9261 => decrease QMPL
    9270 => No QMPL action
    9280 => No QMPL action
    9285 => No QMPL action
    9294 => Limited number of initiators
    9295 => Start an initiator
    9296 => Limited number of initiators
    9297 => Impacted Period
    9298 => Period CPU assess will be reduced
    9299 => QMPL action
"""
trace_action.__doc__ = """Policy adjustment action code(V)

SMF Info (Virtual Field)
--------
    Field: Based on `trace`(`SMF99_TCOD`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    105 => add server
    9180 => QMPL recommendations not allowed
    9190 => No QMPL action
    9191 => Available auxilliary storage
    9195 => No QMPL action
    9200 => No QMPL action
    9202 => No QMPL action
    9205 => No QMPL action
    9210 => No QMPL action
    9220 => No QMPL action
    9230 => No QMPL action
    9240 => No QMPL action
    9245 => No QMPL action
    9246 => No QMPL action
    9247 => QMPL increase limited
    9250 => increase QMPL
    9251 => decrease QMPL
    9260 => increase QMPL
    9261 => decrease QMPL
    9270 => No QMPL action
    9280 => No QMPL action
    9285 => No QMPL action
    9294 => Limited number of initiators
    9295 => Start an initiator
    9296 => Limited number of initiators
    9297 => Impacted Period
    9298 => Period CPU assess will be reduced
    9299 => QMPL action
"""

trace_details : Final[Field] = Field(
    name='trace_details',
    origin=None,
    post='core.map',
    post_param={'map': {105: 'resource adjustment, underutilized', 9190: 'critical shortage condition exists', 9191: 'for server spaces', 9195: 'ready user average is zero', 9200: 'MPL problem exists', 9202: 'idle inits observed', 9205: "resource period isn't a queue server", 9210: 'previous QMPL recommendation(s) exists', 9220: 'unmanaged queue', 9230: 'no receiver value', 9240: 'no receiver value', 9245: 'better system to start initiators available', 9246: 'no system to start initiators', 9247: 'resource group maximum reached', 9250: 'for queue servers, goal receiver', 9251: 'for queue servers, goal receiver', 9260: 'for queue servers, resource receiver', 9261: 'for queue servers, resource receiver', 9270: 'insufficient net value for queue servers', 9280: 'no queued requests', 9285: 'to increase resource group service maximum', 9294: 'to the number of available AS - 10', 9295: 'for a batch work queue due to specific affinity requirement', 9296: 'to not the doubled number of current initiators', 9297: 'by starting the initiators on this system', 9298: 'by adding initiators on this system', 9299: 'to increase resource group service maximum'}},
    virtual=True,
    ref=trace,
    record=record,
    record_map=SMF99_S1_AAT_MAP,
)
"""Policy adjustment action code(V)

SMF Info (Virtual Field)
--------
    Field: Based on `trace`(`SMF99_TCOD`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    105 => resource adjustment, underutilized
    9190 => critical shortage condition exists
    9191 => for server spaces
    9195 => ready user average is zero
    9200 => MPL problem exists
    9202 => idle inits observed
    9205 => resource period isn't a queue server
    9210 => previous QMPL recommendation(s) exists
    9220 => unmanaged queue
    9230 => no receiver value
    9240 => no receiver value
    9245 => better system to start initiators available
    9246 => no system to start initiators
    9247 => resource group maximum reached
    9250 => for queue servers, goal receiver
    9251 => for queue servers, goal receiver
    9260 => for queue servers, resource receiver
    9261 => for queue servers, resource receiver
    9270 => insufficient net value for queue servers
    9280 => no queued requests
    9285 => to increase resource group service maximum
    9294 => to the number of available AS - 10
    9295 => for a batch work queue due to specific affinity requirement
    9296 => to not the doubled number of current initiators
    9297 => by starting the initiators on this system
    9298 => by adding initiators on this system
    9299 => to increase resource group service maximum
"""
trace_details.__doc__ = """Policy adjustment action code(V)

SMF Info (Virtual Field)
--------
    Field: Based on `trace`(`SMF99_TCOD`)
    Record: `SMF99S1`
    Map: `SMF99_S1_AAT_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    105 => resource adjustment, underutilized
    9190 => critical shortage condition exists
    9191 => for server spaces
    9195 => ready user average is zero
    9200 => MPL problem exists
    9202 => idle inits observed
    9205 => resource period isn't a queue server
    9210 => previous QMPL recommendation(s) exists
    9220 => unmanaged queue
    9230 => no receiver value
    9240 => no receiver value
    9245 => better system to start initiators available
    9246 => no system to start initiators
    9247 => resource group maximum reached
    9250 => for queue servers, goal receiver
    9251 => for queue servers, goal receiver
    9260 => for queue servers, resource receiver
    9261 => for queue servers, resource receiver
    9270 => insufficient net value for queue servers
    9280 => no queued requests
    9285 => to increase resource group service maximum
    9294 => to the number of available AS - 10
    9295 => for a batch work queue due to specific affinity requirement
    9296 => to not the doubled number of current initiators
    9297 => by starting the initiators on this system
    9298 => by adding initiators on this system
    9299 => to increase resource group service maximum
"""

ptprty_PriorityTableEntrySections : Final[Field] = Field(
    name='ptprty_PriorityTableEntrySections',
    origin='SMF99_PTPRTY',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""Dispatch priority

SMF Info
--------
    Field: `SMF99_PTPRTY`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

Dispatch priority
"""
ptprty_PriorityTableEntrySections.__doc__ = """Dispatch priority

SMF Info
--------
    Field: `SMF99_PTPRTY`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

Dispatch priority
"""

ptnp_PriorityTableEntrySections : Final[Field] = Field(
    name='ptnp_PriorityTableEntrySections',
    origin='SMF99_PTNP',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""New dispatch priority (zero if not changed)

SMF Info
--------
    Field: `SMF99_PTNP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

New dispatch priority (zero if not changed)
"""
ptnp_PriorityTableEntrySections.__doc__ = """New dispatch priority (zero if not changed)

SMF Info
--------
    Field: `SMF99_PTNP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

New dispatch priority (zero if not changed)
"""

ptimdp_PriorityTableEntrySections : Final[Field] = Field(
    name='ptimdp_PriorityTableEntrySections',
    origin='SMF99_PTIMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes

SMF Info
--------
    Field: `SMF99_PTIMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes
"""
ptimdp_PriorityTableEntrySections.__doc__ = """initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes

SMF Info
--------
    Field: `SMF99_PTIMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes
"""

ptpmdp_PriorityTableEntrySections : Final[Field] = Field(
    name='ptpmdp_PriorityTableEntrySections',
    origin='SMF99_PTPMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""projected maximum percentage of processor demanded at priority

SMF Info
--------
    Field: `SMF99_PTPMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

projected maximum percentage of processor demanded at priority
"""
ptpmdp_PriorityTableEntrySections.__doc__ = """projected maximum percentage of processor demanded at priority

SMF Info
--------
    Field: `SMF99_PTPMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

projected maximum percentage of processor demanded at priority
"""

ptcpuu_PriorityTableEntrySections : Final[Field] = Field(
    name='ptcpuu_PriorityTableEntrySections',
    origin='SMF99_PTCPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

cpu using samples at priority
"""
ptcpuu_PriorityTableEntrySections.__doc__ = """cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

cpu using samples at priority
"""

ptcpud_PriorityTableEntrySections : Final[Field] = Field(
    name='ptcpud_PriorityTableEntrySections',
    origin='SMF99_PTCPUD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

cpu delay samples at priority
"""
ptcpud_PriorityTableEntrySections.__doc__ = """cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

cpu delay samples at priority
"""

ptw2ur_PriorityTableEntrySections : Final[Field] = Field(
    name='ptw2ur_PriorityTableEntrySections',
    origin='SMF99_PTW2UR',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""wait-to-using ratio at priority (*16)

SMF Info
--------
    Field: `SMF99_PTW2UR`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

wait-to-using ratio at priority (*16)
"""
ptw2ur_PriorityTableEntrySections.__doc__ = """wait-to-using ratio at priority (*16)

SMF Info
--------
    Field: `SMF99_PTW2UR`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

wait-to-using ratio at priority (*16)
"""

ptapu_PriorityTableEntrySections : Final[Field] = Field(
    name='ptapu_PriorityTableEntrySections',
    origin='SMF99_PTAPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""actual measured processor used at priority

SMF Info
--------
    Field: `SMF99_PTAPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

actual measured processor used at priority
"""
ptapu_PriorityTableEntrySections.__doc__ = """actual measured processor used at priority

SMF Info
--------
    Field: `SMF99_PTAPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

actual measured processor used at priority
"""

ptppu_PriorityTableEntrySections : Final[Field] = Field(
    name='ptppu_PriorityTableEntrySections',
    origin='SMF99_PTPPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""projected processor time to be used at priority

SMF Info
--------
    Field: `SMF99_PTPPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

projected processor time to be used at priority
"""
ptppu_PriorityTableEntrySections.__doc__ = """projected processor time to be used at priority

SMF Info
--------
    Field: `SMF99_PTPPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

projected processor time to be used at priority
"""

ptacmd_PriorityTableEntrySections : Final[Field] = Field(
    name='ptacmd_PriorityTableEntrySections',
    origin='SMF99_PTACMD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""achievable cumulative max demand for priorities affected by a move

SMF Info
--------
    Field: `SMF99_PTACMD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

achievable cumulative max demand for priorities affected by a move
"""
ptacmd_PriorityTableEntrySections.__doc__ = """achievable cumulative max demand for priorities affected by a move

SMF Info
--------
    Field: `SMF99_PTACMD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

achievable cumulative max demand for priorities affected by a move
"""

ptimaxd_PriorityTableEntrySections : Final[Field] = Field(
    name='ptimaxd_PriorityTableEntrySections',
    origin='SMF99_PTIMAXD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""initial cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTIMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

initial cumulative maximum demand
"""
ptimaxd_PriorityTableEntrySections.__doc__ = """initial cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTIMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

initial cumulative maximum demand
"""

ptwmaxd_PriorityTableEntrySections : Final[Field] = Field(
    name='ptwmaxd_PriorityTableEntrySections',
    origin='SMF99_PTWMAXD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""Projected cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTWMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

Projected cumulative maximum demand
"""
ptwmaxd_PriorityTableEntrySections.__doc__ = """Projected cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTWMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

Projected cumulative maximum demand
"""

ptiamtw_PriorityTableEntrySections : Final[Field] = Field(
    name='ptiamtw_PriorityTableEntrySections',
    origin='SMF99_PTIAMTW',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""initial average mean time to wait

SMF Info
--------
    Field: `SMF99_PTIAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

initial average mean time to wait
"""
ptiamtw_PriorityTableEntrySections.__doc__ = """initial average mean time to wait

SMF Info
--------
    Field: `SMF99_PTIAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

initial average mean time to wait
"""

ptwamtw_PriorityTableEntrySections : Final[Field] = Field(
    name='ptwamtw_PriorityTableEntrySections',
    origin='SMF99_PTWAMTW',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""Projected average mean time to wait

SMF Info
--------
    Field: `SMF99_PTWAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

Projected average mean time to wait
"""
ptwamtw_PriorityTableEntrySections.__doc__ = """Projected average mean time to wait

SMF Info
--------
    Field: `SMF99_PTWAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

Projected average mean time to wait
"""

ptscpuu_PriorityTableEntrySections : Final[Field] = Field(
    name='ptscpuu_PriorityTableEntrySections',
    origin='SMF99_PTSCPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""sample based cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

sample based cpu using samples at priority
"""
ptscpuu_PriorityTableEntrySections.__doc__ = """sample based cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

sample based cpu using samples at priority
"""

ptscpud_PriorityTableEntrySections : Final[Field] = Field(
    name='ptscpud_PriorityTableEntrySections',
    origin='SMF99_PTSCPUD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION,
)
"""sample based cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

sample based cpu delay samples at priority
"""
ptscpud_PriorityTableEntrySections.__doc__ = """sample based cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION`

sample based cpu delay samples at priority
"""

rgname : Final[Field] = Field(
    name='rgname',
    origin='SMF99_RGNAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""name

SMF Info
--------
    Field: `SMF99_RGNAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

name
"""
rgname.__doc__ = """name

SMF Info
--------
    Field: `SMF99_RGNAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

name
"""

min_sr : Final[Field] = Field(
    name='min_sr',
    origin='SMF99_MIN_SR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Minimum service rate for the group

SMF Info
--------
    Field: `SMF99_MIN_SR`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Minimum service rate for the group
"""
min_sr.__doc__ = """Minimum service rate for the group

SMF Info
--------
    Field: `SMF99_MIN_SR`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Minimum service rate for the group
"""

max_sr : Final[Field] = Field(
    name='max_sr',
    origin='SMF99_MAX_SR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Maximum service rate for the group (FFFFFFFF if not specified in the policy)

SMF Info
--------
    Field: `SMF99_MAX_SR`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Maximum service rate for the group (FFFFFFFF if not specified in the policy)
"""
max_sr.__doc__ = """Maximum service rate for the group (FFFFFFFF if not specified in the policy)

SMF Info
--------
    Field: `SMF99_MAX_SR`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Maximum service rate for the group (FFFFFFFF if not specified in the policy)
"""

act_sr : Final[Field] = Field(
    name='act_sr',
    origin='SMF99_ACT_SR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Service rate received in last interval on the local system

SMF Info
--------
    Field: `SMF99_ACT_SR`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Service rate received in last interval on the local system
"""
act_sr.__doc__ = """Service rate received in last interval on the local system

SMF Info
--------
    Field: `SMF99_ACT_SR`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Service rate received in last interval on the local system
"""

spas : Final[Field] = Field(
    name='spas',
    origin='SMF99_SPAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""service per awake slice

SMF Info
--------
    Field: `SMF99_SPAS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

service per awake slice
"""
spas.__doc__ = """service per awake slice

SMF Info
--------
    Field: `SMF99_SPAS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

service per awake slice
"""

slices : Final[Field] = Field(
    name='slices',
    origin='SMF99_SLICES',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Number of time slices that work in this group was capped

SMF Info
--------
    Field: `SMF99_SLICES`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Number of time slices that work in this group was capped
"""
slices.__doc__ = """Number of time slices that work in this group was capped

SMF Info
--------
    Field: `SMF99_SLICES`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Number of time slices that work in this group was capped
"""

rhelpcnt0 : Final[Field] = Field(
    name='rhelpcnt0',
    origin='SMF99_RHELPCNT0',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""a count of the remote systems that can help work at importance 0

SMF Info
--------
    Field: `SMF99_RHELPCNT0`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 0
"""
rhelpcnt0.__doc__ = """a count of the remote systems that can help work at importance 0

SMF Info
--------
    Field: `SMF99_RHELPCNT0`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 0
"""

rhelpcnt1 : Final[Field] = Field(
    name='rhelpcnt1',
    origin='SMF99_RHELPCNT1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""a count of the remote systems that can help work at importance 1

SMF Info
--------
    Field: `SMF99_RHELPCNT1`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 1
"""
rhelpcnt1.__doc__ = """a count of the remote systems that can help work at importance 1

SMF Info
--------
    Field: `SMF99_RHELPCNT1`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 1
"""

rhelpcnt2 : Final[Field] = Field(
    name='rhelpcnt2',
    origin='SMF99_RHELPCNT2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""a count of the remote systems that can help work at importance 2

SMF Info
--------
    Field: `SMF99_RHELPCNT2`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 2
"""
rhelpcnt2.__doc__ = """a count of the remote systems that can help work at importance 2

SMF Info
--------
    Field: `SMF99_RHELPCNT2`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 2
"""

rhelpcnt3 : Final[Field] = Field(
    name='rhelpcnt3',
    origin='SMF99_RHELPCNT3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""a count of the remote systems that can help work at importance 3

SMF Info
--------
    Field: `SMF99_RHELPCNT3`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 3
"""
rhelpcnt3.__doc__ = """a count of the remote systems that can help work at importance 3

SMF Info
--------
    Field: `SMF99_RHELPCNT3`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 3
"""

rhelpcnt4 : Final[Field] = Field(
    name='rhelpcnt4',
    origin='SMF99_RHELPCNT4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""a count of the remote systems that can help work at importance 4

SMF Info
--------
    Field: `SMF99_RHELPCNT4`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 4
"""
rhelpcnt4.__doc__ = """a count of the remote systems that can help work at importance 4

SMF Info
--------
    Field: `SMF99_RHELPCNT4`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 4
"""

rhelpcnt5 : Final[Field] = Field(
    name='rhelpcnt5',
    origin='SMF99_RHELPCNT5',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""a count of the remote systems that can help work at importance 5

SMF Info
--------
    Field: `SMF99_RHELPCNT5`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 5
"""
rhelpcnt5.__doc__ = """a count of the remote systems that can help work at importance 5

SMF Info
--------
    Field: `SMF99_RHELPCNT5`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 5
"""

rhelpcnt6 : Final[Field] = Field(
    name='rhelpcnt6',
    origin='SMF99_RHELPCNT6',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""a count of the remote systems that can help work at importance 6

SMF Info
--------
    Field: `SMF99_RHELPCNT6`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 6
"""
rhelpcnt6.__doc__ = """a count of the remote systems that can help work at importance 6

SMF Info
--------
    Field: `SMF99_RHELPCNT6`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

a count of the remote systems that can help work at importance 6
"""

lhelp_flgs : Final[Field] = Field(
    name='lhelp_flgs',
    origin='SMF99_LHELP_FLGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Local system can help work at each importance. 1 - can help, 0 - cannot help

SMF Info
--------
    Field: `SMF99_LHELP_FLGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at each importance. 1 - can help, 0 - cannot help
"""
lhelp_flgs.__doc__ = """Local system can help work at each importance. 1 - can help, 0 - cannot help

SMF Info
--------
    Field: `SMF99_LHELP_FLGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at each importance. 1 - can help, 0 - cannot help
"""

lhelp6 : Final[Field] = Field(
    name='lhelp6',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=lhelp_flgs,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Local system can help work at importance 0. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 0. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
lhelp6.__doc__ = """Local system can help work at importance 0. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 0. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

lhelp5 : Final[Field] = Field(
    name='lhelp5',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=lhelp_flgs,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Local system can help work at importance 1. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 1. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
lhelp5.__doc__ = """Local system can help work at importance 1. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 1. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

lhelp4 : Final[Field] = Field(
    name='lhelp4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=lhelp_flgs,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Local system can help work at importance 2. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 2. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
lhelp4.__doc__ = """Local system can help work at importance 2. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 2. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

lhelp3 : Final[Field] = Field(
    name='lhelp3',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=lhelp_flgs,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Local system can help work at importance 3. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 3. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
lhelp3.__doc__ = """Local system can help work at importance 3. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 3. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

lhelp2 : Final[Field] = Field(
    name='lhelp2',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=lhelp_flgs,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Local system can help work at importance 4. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 4. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
lhelp2.__doc__ = """Local system can help work at importance 4. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 4. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

lhelp1 : Final[Field] = Field(
    name='lhelp1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=lhelp_flgs,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Local system can help work at importance 5. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 5. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
lhelp1.__doc__ = """Local system can help work at importance 5. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 5. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

lhelp0 : Final[Field] = Field(
    name='lhelp0',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=lhelp_flgs,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Local system can help work at importance 6. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 6. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
lhelp0.__doc__ = """Local system can help work at importance 6. 1 - can help, 0 - cannot help(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lhelp_flgs`(`SMF99_LHELP_FLGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Local system can help work at importance 6. 1 - can help, 0 - cannot help

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rg_flags : Final[Field] = Field(
    name='rg_flags',
    origin='SMF99_RG_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""resource group flags

SMF Info
--------
    Field: `SMF99_RG_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

resource group flags
"""
rg_flags.__doc__ = """resource group flags

SMF Info
--------
    Field: `SMF99_RG_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

resource group flags
"""

rg_is_dynamic : Final[Field] = Field(
    name='rg_is_dynamic',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Indicates that the resource group is a dynamic resource group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group is a dynamic resource group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rg_is_dynamic.__doc__ = """Indicates that the resource group is a dynamic resource group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group is a dynamic resource group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

rg_percent_capped : Final[Field] = Field(
    name='rg_percent_capped',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Indicates that the resource group is capacity is specified in percentage of the total LPAR capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group is capacity is specified in percentage of the total LPAR capacity

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
rg_percent_capped.__doc__ = """Indicates that the resource group is capacity is specified in percentage of the total LPAR capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group is capacity is specified in percentage of the total LPAR capacity

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rg_percent_single_processor : Final[Field] = Field(
    name='rg_percent_single_processor',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Indicates that the resource group is capacity is specified in percentage of a single processor capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group is capacity is specified in percentage of a single processor capacity

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
rg_percent_single_processor.__doc__ = """Indicates that the resource group is capacity is specified in percentage of a single processor capacity(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group is capacity is specified in percentage of a single processor capacity

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

rg_msu_per_hour : Final[Field] = Field(
    name='rg_msu_per_hour',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Indicates that the resource group capacity is specified in MSU/h(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group capacity is specified in MSU/h

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
rg_msu_per_hour.__doc__ = """Indicates that the resource group capacity is specified in MSU/h(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group capacity is specified in MSU/h

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rg_raw_sus : Final[Field] = Field(
    name='rg_raw_sus',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Indicates that the resource group capacity is specified in raw service units(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group capacity is specified in raw service units

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rg_raw_sus.__doc__ = """Indicates that the resource group capacity is specified in raw service units(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group capacity is specified in raw service units

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rg_isp : Final[Field] = Field(
    name='rg_isp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Indicates that specialty processor consumption is included in the group consumption(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that specialty processor consumption is included in the group consumption

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rg_isp.__doc__ = """Indicates that specialty processor consumption is included in the group consumption(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that specialty processor consumption is included in the group consumption

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

rg_trg : Final[Field] = Field(
    name='rg_trg',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Indicates that the resource group is a tenant resource group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group is a tenant resource group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
rg_trg.__doc__ = """Indicates that the resource group is a tenant resource group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Indicates that the resource group is a tenant resource group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

rg_hwc : Final[Field] = Field(
    name='rg_hwc',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""For IBM use only(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

For IBM use only

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
rg_hwc.__doc__ = """For IBM use only(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

For IBM use only

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rg_perc_min : Final[Field] = Field(
    name='rg_perc_min',
    origin='SMF99_RG_PERC_MIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Percentage min value, if min/max specified in percentages. Or MSU min value if min/max specified in MSU

SMF Info
--------
    Field: `SMF99_RG_PERC_MIN`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Percentage min value, if min/max specified in percentages. Or MSU min value if min/max specified in MSU
"""
rg_perc_min.__doc__ = """Percentage min value, if min/max specified in percentages. Or MSU min value if min/max specified in MSU

SMF Info
--------
    Field: `SMF99_RG_PERC_MIN`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Percentage min value, if min/max specified in percentages. Or MSU min value if min/max specified in MSU
"""

rg_perc_max : Final[Field] = Field(
    name='rg_perc_max',
    origin='SMF99_RG_PERC_MAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Percentage max value, if min/max specified in percentages. Or MSU max value if min/max specified in MSU

SMF Info
--------
    Field: `SMF99_RG_PERC_MAX`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Percentage max value, if min/max specified in percentages. Or MSU max value if min/max specified in MSU
"""
rg_perc_max.__doc__ = """Percentage max value, if min/max specified in percentages. Or MSU max value if min/max specified in MSU

SMF Info
--------
    Field: `SMF99_RG_PERC_MAX`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Percentage max value, if min/max specified in percentages. Or MSU max value if min/max specified in MSU
"""

rg_total_sr : Final[Field] = Field(
    name='rg_total_sr',
    origin='SMF99_RG_TOTAL_SR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Total service rate. If the min/max values are specified as percentages, the service rate represents only the local system. Otherwise the service rate of the sysplex.

SMF Info
--------
    Field: `SMF99_RG_TOTAL_SR`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Total service rate. If the min/max values are specified as percentages, the service rate represents only the local system. Otherwise the service rate of the sysplex.
"""
rg_total_sr.__doc__ = """Total service rate. If the min/max values are specified as percentages, the service rate represents only the local system. Otherwise the service rate of the sysplex.

SMF Info
--------
    Field: `SMF99_RG_TOTAL_SR`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Total service rate. If the min/max values are specified as percentages, the service rate represents only the local system. Otherwise the service rate of the sysplex.
"""

rg_mem_limit : Final[Field] = Field(
    name='rg_mem_limit',
    origin='SMF99_RG_MEM_LIMIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Maximum memory limit for resource group in Gigabytes

SMF Info
--------
    Field: `SMF99_RG_MEM_LIMIT`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Maximum memory limit for resource group in Gigabytes
"""
rg_mem_limit.__doc__ = """Maximum memory limit for resource group in Gigabytes

SMF Info
--------
    Field: `SMF99_RG_MEM_LIMIT`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Maximum memory limit for resource group in Gigabytes
"""

rg_mem_usage_4k : Final[Field] = Field(
    name='rg_mem_usage_4k',
    origin='SMF99_RG_MEM_USAGE_4K',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Amount of memory used by a memory pool normalized to 4K frames.

SMF Info
--------
    Field: `SMF99_RG_MEM_USAGE_4K`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Amount of memory used by a memory pool normalized to 4K frames.
"""
rg_mem_usage_4k.__doc__ = """Amount of memory used by a memory pool normalized to 4K frames.

SMF Info
--------
    Field: `SMF99_RG_MEM_USAGE_4K`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Amount of memory used by a memory pool normalized to 4K frames.
"""

rg_mem_fixed_frames_4k : Final[Field] = Field(
    name='rg_mem_fixed_frames_4k',
    origin='SMF99_RG_MEM_FIXED_FRAMES_4K',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Amount of fixed frames in a memory pool nomalized to 4K frames.

SMF Info
--------
    Field: `SMF99_RG_MEM_FIXED_FRAMES_4K`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Amount of fixed frames in a memory pool nomalized to 4K frames.
"""
rg_mem_fixed_frames_4k.__doc__ = """Amount of fixed frames in a memory pool nomalized to 4K frames.

SMF Info
--------
    Field: `SMF99_RG_MEM_FIXED_FRAMES_4K`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Amount of fixed frames in a memory pool nomalized to 4K frames.
"""

rg_mem_backed_2g_frames : Final[Field] = Field(
    name='rg_mem_backed_2g_frames',
    origin='SMF99_RG_MEM_BACKED_2G_FRAMES',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Number of backed 2G (fixed) frames in the memory pool.

SMF Info
--------
    Field: `SMF99_RG_MEM_BACKED_2G_FRAMES`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Number of backed 2G (fixed) frames in the memory pool.
"""
rg_mem_backed_2g_frames.__doc__ = """Number of backed 2G (fixed) frames in the memory pool.

SMF Info
--------
    Field: `SMF99_RG_MEM_BACKED_2G_FRAMES`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Number of backed 2G (fixed) frames in the memory pool.
"""

rg_mem_discretionary_4k : Final[Field] = Field(
    name='rg_mem_discretionary_4k',
    origin='SMF99_RG_MEM_DISCRETIONARY_4K',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Amount of available disrectionary memory normalized to 4K frames.

SMF Info
--------
    Field: `SMF99_RG_MEM_DISCRETIONARY_4K`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Amount of available disrectionary memory normalized to 4K frames.
"""
rg_mem_discretionary_4k.__doc__ = """Amount of available disrectionary memory normalized to 4K frames.

SMF Info
--------
    Field: `SMF99_RG_MEM_DISCRETIONARY_4K`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Amount of available disrectionary memory normalized to 4K frames.
"""

rg_mem_discretionary_2g : Final[Field] = Field(
    name='rg_mem_discretionary_2g',
    origin='SMF99_RG_MEM_DISCRETIONARY_2G',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Amount of available discretionary memory in 2G frames.

SMF Info
--------
    Field: `SMF99_RG_MEM_DISCRETIONARY_2G`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Amount of available discretionary memory in 2G frames.
"""
rg_mem_discretionary_2g.__doc__ = """Amount of available discretionary memory in 2G frames.

SMF Info
--------
    Field: `SMF99_RG_MEM_DISCRETIONARY_2G`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Amount of available discretionary memory in 2G frames.
"""

rg_mem_shortage_flags : Final[Field] = Field(
    name='rg_mem_shortage_flags',
    origin='SMF99_RG_MEM_SHORTAGE_FLAGS',
    post='core.map',
    post_param={'map': {0: 'No Shortage', 192: 'Available Frame Shortage', 160: 'Pageable Storage Shortage', 224: 'Available + Pageable Shortage'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Memory Pool shortage flags.

SMF Info
--------
    Field: `SMF99_RG_MEM_SHORTAGE_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Memory Pool shortage flags.

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    0 => No Shortage
    192 => Available Frame Shortage
    160 => Pageable Storage Shortage
    224 => Available + Pageable Shortage
"""
rg_mem_shortage_flags.__doc__ = """Memory Pool shortage flags.

SMF Info
--------
    Field: `SMF99_RG_MEM_SHORTAGE_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Memory Pool shortage flags.

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    0 => No Shortage
    192 => Available Frame Shortage
    160 => Pageable Storage Shortage
    224 => Available + Pageable Shortage
"""

rg_lacs : Final[Field] = Field(
    name='rg_lacs',
    origin='SMF99_RG_LACS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Tenant resource group long-term average of CPU service in MSU/h. Only valid if SMF99_RG_TRG is ON

SMF Info
--------
    Field: `SMF99_RG_LACS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Tenant resource group long-term average of CPU service in MSU/h. Only valid if SMF99_RG_TRG is ON
"""
rg_lacs.__doc__ = """Tenant resource group long-term average of CPU service in MSU/h. Only valid if SMF99_RG_TRG is ON

SMF Info
--------
    Field: `SMF99_RG_LACS`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Tenant resource group long-term average of CPU service in MSU/h. Only valid if SMF99_RG_TRG is ON
"""

rg_susifa : Final[Field] = Field(
    name='rg_susifa',
    origin='SMF99_RG_SUSIFA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Tenant resource group's aggregated IFA service units. Only valid if SMF99_RG_TRG is ON

SMF Info
--------
    Field: `SMF99_RG_SUSIFA`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Tenant resource group's aggregated IFA service units. Only valid if SMF99_RG_TRG is ON
"""
rg_susifa.__doc__ = """Tenant resource group's aggregated IFA service units. Only valid if SMF99_RG_TRG is ON

SMF Info
--------
    Field: `SMF99_RG_SUSIFA`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Tenant resource group's aggregated IFA service units. Only valid if SMF99_RG_TRG is ON
"""

rg_sussup : Final[Field] = Field(
    name='rg_sussup',
    origin='SMF99_RG_SUSSUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Tenant resource group's aggregated SUP service units. Only valid if SMF99_RG_TRG is ON

SMF Info
--------
    Field: `SMF99_RG_SUSSUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Tenant resource group's aggregated SUP service units. Only valid if SMF99_RG_TRG is ON
"""
rg_sussup.__doc__ = """Tenant resource group's aggregated SUP service units. Only valid if SMF99_RG_TRG is ON

SMF Info
--------
    Field: `SMF99_RG_SUSSUP`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Tenant resource group's aggregated SUP service units. Only valid if SMF99_RG_TRG is ON
"""

rg_lacs_zcbp : Final[Field] = Field(
    name='rg_lacs_zcbp',
    origin='SMF99_RG_LACS_ZCBP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_RG_LACS_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

For IBM use only
"""
rg_lacs_zcbp.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_RG_LACS_ZCBP`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

For IBM use only
"""

rg_memsmpcnt : Final[Field] = Field(
    name='rg_memsmpcnt',
    origin='SMF99_RG_MEMSMPCNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Number of times storage frames were sampled in SMF99_RG_FRAMECNT

SMF Info
--------
    Field: `SMF99_RG_MEMSMPCNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Number of times storage frames were sampled in SMF99_RG_FRAMECNT
"""
rg_memsmpcnt.__doc__ = """Number of times storage frames were sampled in SMF99_RG_FRAMECNT

SMF Info
--------
    Field: `SMF99_RG_MEMSMPCNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Number of times storage frames were sampled in SMF99_RG_FRAMECNT
"""

rg_framecnt : Final[Field] = Field(
    name='rg_framecnt',
    origin='SMF99_RG_FRAMECNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Tenant resource group's aggregated ammount of storage frames (4K+1M+2G, normalized to 4K). Only valid if SMF99_RG_TRG is ON

SMF Info
--------
    Field: `SMF99_RG_FRAMECNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Tenant resource group's aggregated ammount of storage frames (4K+1M+2G, normalized to 4K). Only valid if SMF99_RG_TRG is ON
"""
rg_framecnt.__doc__ = """Tenant resource group's aggregated ammount of storage frames (4K+1M+2G, normalized to 4K). Only valid if SMF99_RG_TRG is ON

SMF Info
--------
    Field: `SMF99_RG_FRAMECNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Tenant resource group's aggregated ammount of storage frames (4K+1M+2G, normalized to 4K). Only valid if SMF99_RG_TRG is ON
"""

rg_type : Final[Field] = Field(
    name='rg_type',
    origin=None,
    post='core.flagmap',
    post_param={'default': 'Regular', 'map': {0: 'Dynamic', 6: 'Tenant'}},
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Type of resource group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'Regular', 'map': {0: 'Dynamic', 6: 'Tenant'}}
"""
rg_type.__doc__ = """Type of resource group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'Regular', 'map': {0: 'Dynamic', 6: 'Tenant'}}
"""

rg_capacity : Final[Field] = Field(
    name='rg_capacity',
    origin=None,
    post='core.flagmap',
    post_param={'default': 'None', 'map': {1: '% LPAR Capacity', 2: '% Processor Capacity', 3: 'MSU/h', 4: 'Raw Service Units'}},
    virtual=True,
    ref=rg_flags,
    record=record,
    record_map=SMF99_S1_RG_MAP,
)
"""Unit resource group capacity is specified in(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'None', 'map': {1: '% LPAR Capacity', 2: '% Processor Capacity', 3: 'MSU/h', 4: 'Raw Service Units'}}
"""
rg_capacity.__doc__ = """Unit resource group capacity is specified in(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rg_flags`(`SMF99_RG_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_RG_MAP`

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'None', 'map': {1: '% LPAR Capacity', 2: '% Processor Capacity', 3: 'MSU/h', 4: 'Raw Service Units'}}
"""

gr_sysname : Final[Field] = Field(
    name='gr_sysname',
    origin='SMF99_GR_SYSNAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_GR_MAP,
)
"""Name of system sessions were routed to

SMF Info
--------
    Field: `SMF99_GR_SYSNAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Name of system sessions were routed to
"""
gr_sysname.__doc__ = """Name of system sessions were routed to

SMF Info
--------
    Field: `SMF99_GR_SYSNAME`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Name of system sessions were routed to
"""

gr_tso_sessions_routed : Final[Field] = Field(
    name='gr_tso_sessions_routed',
    origin='SMF99_GR_TSO_SESSIONS_ROUTED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_GR_MAP,
)
"""Number of TSO sessions routed to system named in SMF99_GR_SYSNAME

SMF Info
--------
    Field: `SMF99_GR_TSO_SESSIONS_ROUTED`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Number of TSO sessions routed to system named in SMF99_GR_SYSNAME
"""
gr_tso_sessions_routed.__doc__ = """Number of TSO sessions routed to system named in SMF99_GR_SYSNAME

SMF Info
--------
    Field: `SMF99_GR_TSO_SESSIONS_ROUTED`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Number of TSO sessions routed to system named in SMF99_GR_SYSNAME
"""

gr_nontso_sessions_routed : Final[Field] = Field(
    name='gr_nontso_sessions_routed',
    origin='SMF99_GR_NONTSO_SESSIONS_ROUTED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_GR_MAP,
)
"""Number of non-TSO sessions routed to system named in SMF99_GR_SYSNAME

SMF Info
--------
    Field: `SMF99_GR_NONTSO_SESSIONS_ROUTED`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Number of non-TSO sessions routed to system named in SMF99_GR_SYSNAME
"""
gr_nontso_sessions_routed.__doc__ = """Number of non-TSO sessions routed to system named in SMF99_GR_SYSNAME

SMF Info
--------
    Field: `SMF99_GR_NONTSO_SESSIONS_ROUTED`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Number of non-TSO sessions routed to system named in SMF99_GR_SYSNAME
"""

gr_tso_avg_cost : Final[Field] = Field(
    name='gr_tso_avg_cost',
    origin='SMF99_GR_TSO_AVG_COST',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_GR_MAP,
)
"""Average cost of TSO session in raw cpu service units on system SMF99_GR_SYSNAME

SMF Info
--------
    Field: `SMF99_GR_TSO_AVG_COST`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Average cost of TSO session in raw cpu service units on system SMF99_GR_SYSNAME
"""
gr_tso_avg_cost.__doc__ = """Average cost of TSO session in raw cpu service units on system SMF99_GR_SYSNAME

SMF Info
--------
    Field: `SMF99_GR_TSO_AVG_COST`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Average cost of TSO session in raw cpu service units on system SMF99_GR_SYSNAME
"""

gr_tso_pi : Final[Field] = Field(
    name='gr_tso_pi',
    origin='SMF99_GR_TSO_PI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_GR_MAP,
)
"""Weighted average PI of service class periods running TSO work on system SMF99_GR_SYSNAME

SMF Info
--------
    Field: `SMF99_GR_TSO_PI`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Weighted average PI of service class periods running TSO work on system SMF99_GR_SYSNAME
"""
gr_tso_pi.__doc__ = """Weighted average PI of service class periods running TSO work on system SMF99_GR_SYSNAME

SMF Info
--------
    Field: `SMF99_GR_TSO_PI`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

Weighted average PI of service class periods running TSO work on system SMF99_GR_SYSNAME
"""

gr_flags : Final[Field] = Field(
    name='gr_flags',
    origin='SMF99_GR_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S1_GR_MAP,
)
"""flags

SMF Info
--------
    Field: `SMF99_GR_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

flags
"""
gr_flags.__doc__ = """flags

SMF Info
--------
    Field: `SMF99_GR_FLAGS`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

flags
"""

gr_shortage : Final[Field] = Field(
    name='gr_shortage',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=gr_flags,
    record=record,
    record_map=SMF99_S1_GR_MAP,
)
"""SMF99_GR_SYSNAME had a shortage that may have caused sessions not to be routed to it(V)

SMF Info (Virtual Field)
--------
    Field: Based on `gr_flags`(`SMF99_GR_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

SMF99_GR_SYSNAME had a shortage that may have caused sessions not to be routed to it

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
gr_shortage.__doc__ = """SMF99_GR_SYSNAME had a shortage that may have caused sessions not to be routed to it(V)

SMF Info (Virtual Field)
--------
    Field: Based on `gr_flags`(`SMF99_GR_FLAGS`)
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

SMF99_GR_SYSNAME had a shortage that may have caused sessions not to be routed to it

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

gr_service_by_importance : Final[Field] = Field(
    name='gr_service_by_importance',
    origin='SMF99_GR_SERVICE_BY_IMPORTANCE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_GR_MAP,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 8,
)
"""A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains. Index of zero corresponds to system work and index of 7 to unused capacity.

SMF Info
--------
    Field: `SMF99_GR_SERVICE_BY_IMPORTANCE`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains. Index of zero corresponds to system work and index of 7 to unused capacity.
"""
gr_service_by_importance.__doc__ = """A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains. Index of zero corresponds to system work and index of 7 to unused capacity.

SMF Info
--------
    Field: `SMF99_GR_SERVICE_BY_IMPORTANCE`
    Record: `SMF99S1`
    Map: `SMF99_S1_GR_MAP`

A single entry in the array of Importance Level Service Units, containing the number of Service Units consumed by work at this Importance Level (or unused) over the last ten seconds. The entries are indexed with an origin of zero so that the index matches the Importance Level to which the entry pertains. Index of zero corresponds to system work and index of 7 to unused capacity.
"""

sltserviceuncapped : Final[Field] = Field(
    name='sltserviceuncapped',
    origin='SMF99_SLTSERVICEUNCAPPED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SLT_MAP,
)
"""Basic-mode service units accumulated while the partition was uncapped. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measuredfor software licensing. These service units cannot be directly compared to other service units calculated in SRM.

SMF Info
--------
    Field: `SMF99_SLTSERVICEUNCAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Basic-mode service units accumulated while the partition was uncapped. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measuredfor software licensing. These service units cannot be directly compared to other service units calculated in SRM.
"""
sltserviceuncapped.__doc__ = """Basic-mode service units accumulated while the partition was uncapped. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measuredfor software licensing. These service units cannot be directly compared to other service units calculated in SRM.

SMF Info
--------
    Field: `SMF99_SLTSERVICEUNCAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Basic-mode service units accumulated while the partition was uncapped. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measuredfor software licensing. These service units cannot be directly compared to other service units calculated in SRM.
"""

sltservicecapped : Final[Field] = Field(
    name='sltservicecapped',
    origin='SMF99_SLTSERVICECAPPED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SLT_MAP,
)
"""Basic-mode service units accumulated while the partition was capped. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated in SRM.

SMF Info
--------
    Field: `SMF99_SLTSERVICECAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Basic-mode service units accumulated while the partition was capped. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated in SRM.
"""
sltservicecapped.__doc__ = """Basic-mode service units accumulated while the partition was capped. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated in SRM.

SMF Info
--------
    Field: `SMF99_SLTSERVICECAPPED`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Basic-mode service units accumulated while the partition was capped. NOTE: The service units are calculated using the MP factor for the number of physical CPUs, not the number of logical CPUs. This is consistent with how capacity is measured for software licensing. These service units cannot be directly compared to other service units calculated in SRM.
"""

sltserviceuncappedcount : Final[Field] = Field(
    name='sltserviceuncappedcount',
    origin='SMF99_SLTSERVICEUNCAPPEDCOUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SLT_MAP,
)
"""Number of seconds that the partition was uncapped.

SMF Info
--------
    Field: `SMF99_SLTSERVICEUNCAPPEDCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Number of seconds that the partition was uncapped.
"""
sltserviceuncappedcount.__doc__ = """Number of seconds that the partition was uncapped.

SMF Info
--------
    Field: `SMF99_SLTSERVICEUNCAPPEDCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Number of seconds that the partition was uncapped.
"""

sltservicecappedcount : Final[Field] = Field(
    name='sltservicecappedcount',
    origin='SMF99_SLTSERVICECAPPEDCOUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SLT_MAP,
)
"""Number of seconds that the partition was capped.

SMF Info
--------
    Field: `SMF99_SLTSERVICECAPPEDCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Number of seconds that the partition was capped.
"""
sltservicecappedcount.__doc__ = """Number of seconds that the partition was capped.

SMF Info
--------
    Field: `SMF99_SLTSERVICECAPPEDCOUNT`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Number of seconds that the partition was capped.
"""

sltservicelastupdateinterval : Final[Field] = Field(
    name='sltservicelastupdateinterval',
    origin='SMF99_SLTSERVICELASTUPDATEINTERVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SLT_MAP,
)
"""Policy adjustment interval ID when this entry was last updated. Since the ID is only 1 byte, it will wrap multiple times over the course of the table. That is, the time span of the table is greater than 255 intervals so the interval IDs will wrap around.

SMF Info
--------
    Field: `SMF99_SLTSERVICELASTUPDATEINTERVAL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Policy adjustment interval ID when this entry was last updated. Since the ID is only 1 byte, it will wrap multiple times over the course of the table. That is, the time span of the table is greater than 255 intervals so the interval IDs will wrap around.
"""
sltservicelastupdateinterval.__doc__ = """Policy adjustment interval ID when this entry was last updated. Since the ID is only 1 byte, it will wrap multiple times over the course of the table. That is, the time span of the table is greater than 255 intervals so the interval IDs will wrap around.

SMF Info
--------
    Field: `SMF99_SLTSERVICELASTUPDATEINTERVAL`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Policy adjustment interval ID when this entry was last updated. Since the ID is only 1 byte, it will wrap multiple times over the course of the table. That is, the time span of the table is greater than 255 intervals so the interval IDs will wrap around.
"""

sltserviceunusedgroupcapacity : Final[Field] = Field(
    name='sltserviceunusedgroupcapacity',
    origin='SMF99_SLTSERVICEUNUSEDGROUPCAPACITY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_SLT_MAP,
)
"""Service units which would be allowed by the group capacity limit but are not consumed by the members of the group

SMF Info
--------
    Field: `SMF99_SLTSERVICEUNUSEDGROUPCAPACITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Service units which would be allowed by the group capacity limit but are not consumed by the members of the group
"""
sltserviceunusedgroupcapacity.__doc__ = """Service units which would be allowed by the group capacity limit but are not consumed by the members of the group

SMF Info
--------
    Field: `SMF99_SLTSERVICEUNUSEDGROUPCAPACITY`
    Record: `SMF99S1`
    Map: `SMF99_S1_SLT_MAP`

Service units which would be allowed by the group capacity limit but are not consumed by the members of the group
"""

zaap_ptprty_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptprty_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTPRTY',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""Dispatch priority

SMF Info
--------
    Field: `SMF99_PTPRTY`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

Dispatch priority
"""
zaap_ptprty_PriorityTableEntrySectionZaaps.__doc__ = """Dispatch priority

SMF Info
--------
    Field: `SMF99_PTPRTY`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

Dispatch priority
"""

zaap_ptnp_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptnp_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTNP',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""New dispatch priority (zero if not changed)

SMF Info
--------
    Field: `SMF99_PTNP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

New dispatch priority (zero if not changed)
"""
zaap_ptnp_PriorityTableEntrySectionZaaps.__doc__ = """New dispatch priority (zero if not changed)

SMF Info
--------
    Field: `SMF99_PTNP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

New dispatch priority (zero if not changed)
"""

zaap_ptimdp_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptimdp_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTIMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes

SMF Info
--------
    Field: `SMF99_PTIMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes
"""
zaap_ptimdp_PriorityTableEntrySectionZaaps.__doc__ = """initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes

SMF Info
--------
    Field: `SMF99_PTIMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes
"""

zaap_ptpmdp_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptpmdp_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTPMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""projected maximum percentage of processor demanded at priority

SMF Info
--------
    Field: `SMF99_PTPMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

projected maximum percentage of processor demanded at priority
"""
zaap_ptpmdp_PriorityTableEntrySectionZaaps.__doc__ = """projected maximum percentage of processor demanded at priority

SMF Info
--------
    Field: `SMF99_PTPMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

projected maximum percentage of processor demanded at priority
"""

zaap_ptcpuu_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptcpuu_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTCPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

cpu using samples at priority
"""
zaap_ptcpuu_PriorityTableEntrySectionZaaps.__doc__ = """cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

cpu using samples at priority
"""

zaap_ptcpud_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptcpud_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTCPUD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

cpu delay samples at priority
"""
zaap_ptcpud_PriorityTableEntrySectionZaaps.__doc__ = """cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

cpu delay samples at priority
"""

zaap_ptw2ur_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptw2ur_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTW2UR',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""wait-to-using ratio at priority (*16)

SMF Info
--------
    Field: `SMF99_PTW2UR`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

wait-to-using ratio at priority (*16)
"""
zaap_ptw2ur_PriorityTableEntrySectionZaaps.__doc__ = """wait-to-using ratio at priority (*16)

SMF Info
--------
    Field: `SMF99_PTW2UR`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

wait-to-using ratio at priority (*16)
"""

zaap_ptapu_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptapu_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTAPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""actual measured processor used at priority

SMF Info
--------
    Field: `SMF99_PTAPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

actual measured processor used at priority
"""
zaap_ptapu_PriorityTableEntrySectionZaaps.__doc__ = """actual measured processor used at priority

SMF Info
--------
    Field: `SMF99_PTAPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

actual measured processor used at priority
"""

zaap_ptppu_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptppu_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTPPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""projected processor time to be used at priority

SMF Info
--------
    Field: `SMF99_PTPPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

projected processor time to be used at priority
"""
zaap_ptppu_PriorityTableEntrySectionZaaps.__doc__ = """projected processor time to be used at priority

SMF Info
--------
    Field: `SMF99_PTPPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

projected processor time to be used at priority
"""

zaap_ptacmd_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptacmd_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTACMD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""achievable cumulative max demand for priorities affected by a move

SMF Info
--------
    Field: `SMF99_PTACMD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

achievable cumulative max demand for priorities affected by a move
"""
zaap_ptacmd_PriorityTableEntrySectionZaaps.__doc__ = """achievable cumulative max demand for priorities affected by a move

SMF Info
--------
    Field: `SMF99_PTACMD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

achievable cumulative max demand for priorities affected by a move
"""

zaap_ptimaxd_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptimaxd_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTIMAXD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""initial cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTIMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

initial cumulative maximum demand
"""
zaap_ptimaxd_PriorityTableEntrySectionZaaps.__doc__ = """initial cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTIMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

initial cumulative maximum demand
"""

zaap_ptwmaxd_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptwmaxd_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTWMAXD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""Projected cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTWMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

Projected cumulative maximum demand
"""
zaap_ptwmaxd_PriorityTableEntrySectionZaaps.__doc__ = """Projected cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTWMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

Projected cumulative maximum demand
"""

zaap_ptiamtw_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptiamtw_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTIAMTW',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""initial average mean time to wait

SMF Info
--------
    Field: `SMF99_PTIAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

initial average mean time to wait
"""
zaap_ptiamtw_PriorityTableEntrySectionZaaps.__doc__ = """initial average mean time to wait

SMF Info
--------
    Field: `SMF99_PTIAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

initial average mean time to wait
"""

zaap_ptwamtw_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptwamtw_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTWAMTW',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""Projected average mean time to wait

SMF Info
--------
    Field: `SMF99_PTWAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

Projected average mean time to wait
"""
zaap_ptwamtw_PriorityTableEntrySectionZaaps.__doc__ = """Projected average mean time to wait

SMF Info
--------
    Field: `SMF99_PTWAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

Projected average mean time to wait
"""

zaap_ptscpuu_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptscpuu_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTSCPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""sample based cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

sample based cpu using samples at priority
"""
zaap_ptscpuu_PriorityTableEntrySectionZaaps.__doc__ = """sample based cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

sample based cpu using samples at priority
"""

zaap_ptscpud_PriorityTableEntrySectionZaaps : Final[Field] = Field(
    name='zaap_ptscpud_PriorityTableEntrySectionZaaps',
    origin='SMF99_PTSCPUD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZAAP,
)
"""sample based cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

sample based cpu delay samples at priority
"""
zaap_ptscpud_PriorityTableEntrySectionZaaps.__doc__ = """sample based cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZAAP`

sample based cpu delay samples at priority
"""

ze_index : Final[Field] = Field(
    name='ze_index',
    origin='SMF99_ZE_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_ZE_MAP,
)
"""Index into the entitlement history

SMF Info
--------
    Field: `SMF99_ZE_INDEX`
    Record: `SMF99S1`
    Map: `SMF99_S1_ZE_MAP`

Index into the entitlement history
"""
ze_index.__doc__ = """Index into the entitlement history

SMF Info
--------
    Field: `SMF99_ZE_INDEX`
    Record: `SMF99S1`
    Map: `SMF99_S1_ZE_MAP`

Index into the entitlement history
"""

ze_earned : Final[Field] = Field(
    name='ze_earned',
    origin='SMF99_ZE_EARNED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_ZE_MAP,
)
"""Entitlement Earned

SMF Info
--------
    Field: `SMF99_ZE_EARNED`
    Record: `SMF99S1`
    Map: `SMF99_S1_ZE_MAP`

Entitlement Earned
"""
ze_earned.__doc__ = """Entitlement Earned

SMF Info
--------
    Field: `SMF99_ZE_EARNED`
    Record: `SMF99S1`
    Map: `SMF99_S1_ZE_MAP`

Entitlement Earned
"""

ze_consumed : Final[Field] = Field(
    name='ze_consumed',
    origin='SMF99_ZE_CONSUMED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_ZE_MAP,
)
"""Entitlement Consumed

SMF Info
--------
    Field: `SMF99_ZE_CONSUMED`
    Record: `SMF99S1`
    Map: `SMF99_S1_ZE_MAP`

Entitlement Consumed
"""
ze_consumed.__doc__ = """Entitlement Consumed

SMF Info
--------
    Field: `SMF99_ZE_CONSUMED`
    Record: `SMF99S1`
    Map: `SMF99_S1_ZE_MAP`

Entitlement Consumed
"""

ze_redeposited : Final[Field] = Field(
    name='ze_redeposited',
    origin='SMF99_ZE_REDEPOSITED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S1_ZE_MAP,
)
"""Entitlement Redeposited

SMF Info
--------
    Field: `SMF99_ZE_REDEPOSITED`
    Record: `SMF99S1`
    Map: `SMF99_S1_ZE_MAP`

Entitlement Redeposited
"""
ze_redeposited.__doc__ = """Entitlement Redeposited

SMF Info
--------
    Field: `SMF99_ZE_REDEPOSITED`
    Record: `SMF99S1`
    Map: `SMF99_S1_ZE_MAP`

Entitlement Redeposited
"""

ziip_ptprty_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptprty_PriorityTableEntrySectionZiips',
    origin='SMF99_PTPRTY',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""Dispatch priority

SMF Info
--------
    Field: `SMF99_PTPRTY`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

Dispatch priority
"""
ziip_ptprty_PriorityTableEntrySectionZiips.__doc__ = """Dispatch priority

SMF Info
--------
    Field: `SMF99_PTPRTY`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

Dispatch priority
"""

ziip_ptnp_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptnp_PriorityTableEntrySectionZiips',
    origin='SMF99_PTNP',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""New dispatch priority (zero if not changed)

SMF Info
--------
    Field: `SMF99_PTNP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

New dispatch priority (zero if not changed)
"""
ziip_ptnp_PriorityTableEntrySectionZiips.__doc__ = """New dispatch priority (zero if not changed)

SMF Info
--------
    Field: `SMF99_PTNP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

New dispatch priority (zero if not changed)
"""

ziip_ptimdp_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptimdp_PriorityTableEntrySectionZiips',
    origin='SMF99_PTIMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes

SMF Info
--------
    Field: `SMF99_PTIMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes
"""
ziip_ptimdp_PriorityTableEntrySectionZiips.__doc__ = """initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes

SMF Info
--------
    Field: `SMF99_PTIMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

initial maximum percentage of processor demanded at priority, initial value before any priority moves or slice changes
"""

ziip_ptpmdp_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptpmdp_PriorityTableEntrySectionZiips',
    origin='SMF99_PTPMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""projected maximum percentage of processor demanded at priority

SMF Info
--------
    Field: `SMF99_PTPMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

projected maximum percentage of processor demanded at priority
"""
ziip_ptpmdp_PriorityTableEntrySectionZiips.__doc__ = """projected maximum percentage of processor demanded at priority

SMF Info
--------
    Field: `SMF99_PTPMDP`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

projected maximum percentage of processor demanded at priority
"""

ziip_ptcpuu_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptcpuu_PriorityTableEntrySectionZiips',
    origin='SMF99_PTCPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

cpu using samples at priority
"""
ziip_ptcpuu_PriorityTableEntrySectionZiips.__doc__ = """cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

cpu using samples at priority
"""

ziip_ptcpud_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptcpud_PriorityTableEntrySectionZiips',
    origin='SMF99_PTCPUD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

cpu delay samples at priority
"""
ziip_ptcpud_PriorityTableEntrySectionZiips.__doc__ = """cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

cpu delay samples at priority
"""

ziip_ptw2ur_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptw2ur_PriorityTableEntrySectionZiips',
    origin='SMF99_PTW2UR',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""wait-to-using ratio at priority (*16)

SMF Info
--------
    Field: `SMF99_PTW2UR`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

wait-to-using ratio at priority (*16)
"""
ziip_ptw2ur_PriorityTableEntrySectionZiips.__doc__ = """wait-to-using ratio at priority (*16)

SMF Info
--------
    Field: `SMF99_PTW2UR`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

wait-to-using ratio at priority (*16)
"""

ziip_ptapu_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptapu_PriorityTableEntrySectionZiips',
    origin='SMF99_PTAPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""actual measured processor used at priority

SMF Info
--------
    Field: `SMF99_PTAPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

actual measured processor used at priority
"""
ziip_ptapu_PriorityTableEntrySectionZiips.__doc__ = """actual measured processor used at priority

SMF Info
--------
    Field: `SMF99_PTAPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

actual measured processor used at priority
"""

ziip_ptppu_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptppu_PriorityTableEntrySectionZiips',
    origin='SMF99_PTPPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""projected processor time to be used at priority

SMF Info
--------
    Field: `SMF99_PTPPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

projected processor time to be used at priority
"""
ziip_ptppu_PriorityTableEntrySectionZiips.__doc__ = """projected processor time to be used at priority

SMF Info
--------
    Field: `SMF99_PTPPU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

projected processor time to be used at priority
"""

ziip_ptacmd_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptacmd_PriorityTableEntrySectionZiips',
    origin='SMF99_PTACMD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""achievable cumulative max demand for priorities affected by a move

SMF Info
--------
    Field: `SMF99_PTACMD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

achievable cumulative max demand for priorities affected by a move
"""
ziip_ptacmd_PriorityTableEntrySectionZiips.__doc__ = """achievable cumulative max demand for priorities affected by a move

SMF Info
--------
    Field: `SMF99_PTACMD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

achievable cumulative max demand for priorities affected by a move
"""

ziip_ptimaxd_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptimaxd_PriorityTableEntrySectionZiips',
    origin='SMF99_PTIMAXD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""initial cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTIMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

initial cumulative maximum demand
"""
ziip_ptimaxd_PriorityTableEntrySectionZiips.__doc__ = """initial cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTIMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

initial cumulative maximum demand
"""

ziip_ptwmaxd_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptwmaxd_PriorityTableEntrySectionZiips',
    origin='SMF99_PTWMAXD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""Projected cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTWMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

Projected cumulative maximum demand
"""
ziip_ptwmaxd_PriorityTableEntrySectionZiips.__doc__ = """Projected cumulative maximum demand

SMF Info
--------
    Field: `SMF99_PTWMAXD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

Projected cumulative maximum demand
"""

ziip_ptiamtw_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptiamtw_PriorityTableEntrySectionZiips',
    origin='SMF99_PTIAMTW',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""initial average mean time to wait

SMF Info
--------
    Field: `SMF99_PTIAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

initial average mean time to wait
"""
ziip_ptiamtw_PriorityTableEntrySectionZiips.__doc__ = """initial average mean time to wait

SMF Info
--------
    Field: `SMF99_PTIAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

initial average mean time to wait
"""

ziip_ptwamtw_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptwamtw_PriorityTableEntrySectionZiips',
    origin='SMF99_PTWAMTW',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""Projected average mean time to wait

SMF Info
--------
    Field: `SMF99_PTWAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

Projected average mean time to wait
"""
ziip_ptwamtw_PriorityTableEntrySectionZiips.__doc__ = """Projected average mean time to wait

SMF Info
--------
    Field: `SMF99_PTWAMTW`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

Projected average mean time to wait
"""

ziip_ptscpuu_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptscpuu_PriorityTableEntrySectionZiips',
    origin='SMF99_PTSCPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""sample based cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

sample based cpu using samples at priority
"""
ziip_ptscpuu_PriorityTableEntrySectionZiips.__doc__ = """sample based cpu using samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUU`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

sample based cpu using samples at priority
"""

ziip_ptscpud_PriorityTableEntrySectionZiips : Final[Field] = Field(
    name='ziip_ptscpud_PriorityTableEntrySectionZiips',
    origin='SMF99_PTSCPUD',
    type=FieldType.INTEGER,
    record=record,
    record_map=PRIORITY_TABLE_ENTRY_SECTION_ZIIP,
)
"""sample based cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

sample based cpu delay samples at priority
"""
ziip_ptscpud_PriorityTableEntrySectionZiips.__doc__ = """sample based cpu delay samples at priority

SMF Info
--------
    Field: `SMF99_PTSCPUD`
    Record: `SMF99S1`
    Map: `PRIORITY_TABLE_ENTRY_SECTION_ZIIP`

sample based cpu delay samples at priority
"""

plot_xval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_BP_MAP : Final[Field] = Field(
    name='plot_xval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_BP_MAP',
    origin='SMF99_PLOT_XVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_BP_MAP,
)
"""X value of point plotted in a bucket

SMF Info
--------
    Field: `SMF99_PLOT_XVAL`
    Record: `SMF99S1`
    Map: `SMF99_ONE_CURVE_POINT_MAP`

X value of point plotted in a bucket
"""
plot_xval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_BP_MAP.__doc__ = """X value of point plotted in a bucket

SMF Info
--------
    Field: `SMF99_PLOT_XVAL`
    Record: `SMF99S1`
    Map: `SMF99_ONE_CURVE_POINT_MAP`

X value of point plotted in a bucket
"""

plot_yval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_BP_MAP : Final[Field] = Field(
    name='plot_yval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_BP_MAP',
    origin='SMF99_PLOT_YVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_BP_MAP,
)
"""Y value of point plotted in a bucket

SMF Info
--------
    Field: `SMF99_PLOT_YVAL`
    Record: `SMF99S1`
    Map: `SMF99_ONE_CURVE_POINT_MAP`

Y value of point plotted in a bucket
"""
plot_yval_SMF99_ONE_CURVE_POINT_MAP_SMF99_S1_BP_MAP.__doc__ = """Y value of point plotted in a bucket

SMF Info
--------
    Field: `SMF99_PLOT_YVAL`
    Record: `SMF99S1`
    Map: `SMF99_ONE_CURVE_POINT_MAP`

Y value of point plotted in a bucket
"""
