# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 4"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=4,
                                spec='SMF 74 Subtype 4',
                                post=None)
"""SMF 74 Subtype 4"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R744FLCF: Final[RecordMap] = RecordMap(
    origin='R744FLCF',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Local CF Data Section',
    post=None,
    record_mapping=False)
"""Local CF Data Section"""
R744GSRG: Final[RecordMap] = RecordMap(
    origin='R744GSRG',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Storage Data Section',
    post=None,
    record_mapping=False)
"""Storage Data Section"""
R744XCON: Final[RecordMap] = RecordMap(
    origin='R744XCON',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Connectivity Data Section',
    post=None,
    record_mapping=False)
"""Connectivity Data Section"""
R744QSDS: Final[RecordMap] = RecordMap(
    origin='R744QSDS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Structure Data Section',
    post=None,
    record_mapping=False)
"""Structure Data Section"""
R744SREQ: Final[RecordMap] = RecordMap(
    origin='R744SREQ',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Request Data Section',
    post=None,
    record_mapping=False)
"""Request Data Section"""
R744PROC: Final[RecordMap] = RecordMap(
    origin='R744PROC',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Processor Unitilization Data Section',
    post=None,
    record_mapping=False)
"""Processor Unitilization Data Section"""
R744CACH: Final[RecordMap] = RecordMap(
    origin='R744CACH',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Cache Data Section',
    post=None,
    record_mapping=False)
"""Cache Data Section"""
R744CFRF: Final[RecordMap] = RecordMap(
    origin='R744CFRF',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Remote Facility Data Section',
    post=None,
    record_mapping=False)
"""Remote Facility Data Section"""
R744CHPA: Final[RecordMap] = RecordMap(
    origin='R744CHPA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Channel Path Data Section',
    post=None,
    record_mapping=False)
"""Channel Path Data Section"""
R744MSCM: Final[RecordMap] = RecordMap(
    origin='R744MSCM',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Storage Class Memory Data Section',
    post=None,
    record_mapping=False)
"""Storage Class Memory Data Section"""
R744ADUP: Final[RecordMap] = RecordMap(
    origin='R744ADUP',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Asynchronous CF Duplexing Data Section',
    post=None,
    record_mapping=False)
"""Asynchronous CF Duplexing Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S4`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S4`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S4`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S4`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S4`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S4`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S4`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S4`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S4`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S4`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S4`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S4`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S4`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S4`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S4`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S4`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S4`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S4`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S4`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S4`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S4`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S4`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S4`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S4`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S4`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S4`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S4`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S4`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S4`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S4`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S4`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S4`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S4`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

fo : Final[Field] = Field(
    name='fo',
    origin='SMF744FO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to local CF data section

SMF Info
--------
    Field: `SMF744FO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to local CF data section
"""
fo.__doc__ = """Offset to local CF data section

SMF Info
--------
    Field: `SMF744FO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to local CF data section
"""

fl : Final[Field] = Field(
    name='fl',
    origin='SMF744FL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of local CF data section

SMF Info
--------
    Field: `SMF744FL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of local CF data section
"""
fl.__doc__ = """Length of local CF data section

SMF Info
--------
    Field: `SMF744FL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of local CF data section
"""

fn : Final[Field] = Field(
    name='fn',
    origin='SMF744FN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of local CF data sections

SMF Info
--------
    Field: `SMF744FN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of local CF data sections
"""
fn.__doc__ = """Number of local CF data sections

SMF Info
--------
    Field: `SMF744FN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of local CF data sections
"""

xo : Final[Field] = Field(
    name='xo',
    origin='SMF744XO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to connectivity data section

SMF Info
--------
    Field: `SMF744XO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to connectivity data section
"""
xo.__doc__ = """Offset to connectivity data section

SMF Info
--------
    Field: `SMF744XO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to connectivity data section
"""

xl : Final[Field] = Field(
    name='xl',
    origin='SMF744XL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of connectivity data section

SMF Info
--------
    Field: `SMF744XL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of connectivity data section
"""
xl.__doc__ = """Length of connectivity data section

SMF Info
--------
    Field: `SMF744XL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of connectivity data section
"""

xn : Final[Field] = Field(
    name='xn',
    origin='SMF744XN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of connectivity data sections

SMF Info
--------
    Field: `SMF744XN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of connectivity data sections
"""
xn.__doc__ = """Number of connectivity data sections

SMF Info
--------
    Field: `SMF744XN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of connectivity data sections
"""

go : Final[Field] = Field(
    name='go',
    origin='SMF744GO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to storage data section

SMF Info
--------
    Field: `SMF744GO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to storage data section
"""
go.__doc__ = """Offset to storage data section

SMF Info
--------
    Field: `SMF744GO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to storage data section
"""

gl : Final[Field] = Field(
    name='gl',
    origin='SMF744GL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of storage data section

SMF Info
--------
    Field: `SMF744GL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of storage data section
"""
gl.__doc__ = """Length of storage data section

SMF Info
--------
    Field: `SMF744GL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of storage data section
"""

gn : Final[Field] = Field(
    name='gn',
    origin='SMF744GN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of storage data sections

SMF Info
--------
    Field: `SMF744GN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of storage data sections
"""
gn.__doc__ = """Number of storage data sections

SMF Info
--------
    Field: `SMF744GN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of storage data sections
"""

qo : Final[Field] = Field(
    name='qo',
    origin='SMF744QO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to structure data section

SMF Info
--------
    Field: `SMF744QO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to structure data section
"""
qo.__doc__ = """Offset to structure data section

SMF Info
--------
    Field: `SMF744QO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to structure data section
"""

ql : Final[Field] = Field(
    name='ql',
    origin='SMF744QL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of structure data section

SMF Info
--------
    Field: `SMF744QL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of structure data section
"""
ql.__doc__ = """Length of structure data section

SMF Info
--------
    Field: `SMF744QL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of structure data section
"""

qn : Final[Field] = Field(
    name='qn',
    origin='SMF744QN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of structure data sections

SMF Info
--------
    Field: `SMF744QN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of structure data sections
"""
qn.__doc__ = """Number of structure data sections

SMF Info
--------
    Field: `SMF744QN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of structure data sections
"""

so : Final[Field] = Field(
    name='so',
    origin='SMF744SO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to request data section

SMF Info
--------
    Field: `SMF744SO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to request data section
"""
so.__doc__ = """Offset to request data section

SMF Info
--------
    Field: `SMF744SO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to request data section
"""

sl : Final[Field] = Field(
    name='sl',
    origin='SMF744SL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of request data section

SMF Info
--------
    Field: `SMF744SL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of request data section
"""
sl.__doc__ = """Length of request data section

SMF Info
--------
    Field: `SMF744SL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of request data section
"""

sn : Final[Field] = Field(
    name='sn',
    origin='SMF744SN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of request data sections

SMF Info
--------
    Field: `SMF744SN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of request data sections
"""
sn.__doc__ = """Number of request data sections

SMF Info
--------
    Field: `SMF744SN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of request data sections
"""

po : Final[Field] = Field(
    name='po',
    origin='SMF744PO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to processor data section

SMF Info
--------
    Field: `SMF744PO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to processor data section
"""
po.__doc__ = """Offset to processor data section

SMF Info
--------
    Field: `SMF744PO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to processor data section
"""

pl : Final[Field] = Field(
    name='pl',
    origin='SMF744PL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of processor data section

SMF Info
--------
    Field: `SMF744PL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of processor data section
"""
pl.__doc__ = """Length of processor data section

SMF Info
--------
    Field: `SMF744PL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of processor data section
"""

pn : Final[Field] = Field(
    name='pn',
    origin='SMF744PN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of processor data sections

SMF Info
--------
    Field: `SMF744PN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of processor data sections
"""
pn.__doc__ = """Number of processor data sections

SMF Info
--------
    Field: `SMF744PN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of processor data sections
"""

co : Final[Field] = Field(
    name='co',
    origin='SMF744CO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Cache Data Section

SMF Info
--------
    Field: `SMF744CO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to Cache Data Section
"""
co.__doc__ = """Offset to Cache Data Section

SMF Info
--------
    Field: `SMF744CO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to Cache Data Section
"""

cl : Final[Field] = Field(
    name='cl',
    origin='SMF744CL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Cache Data Section

SMF Info
--------
    Field: `SMF744CL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of Cache Data Section
"""
cl.__doc__ = """Length of Cache Data Section

SMF Info
--------
    Field: `SMF744CL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of Cache Data Section
"""

cn : Final[Field] = Field(
    name='cn',
    origin='SMF744CN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Cache Data Section

SMF Info
--------
    Field: `SMF744CN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of Cache Data Section
"""
cn.__doc__ = """Number of Cache Data Section

SMF Info
--------
    Field: `SMF744CN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of Cache Data Section
"""

ro : Final[Field] = Field(
    name='ro',
    origin='SMF744RO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CF Remote Faciliy Data Section

SMF Info
--------
    Field: `SMF744RO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to CF Remote Faciliy Data Section
"""
ro.__doc__ = """Offset to CF Remote Faciliy Data Section

SMF Info
--------
    Field: `SMF744RO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to CF Remote Faciliy Data Section
"""

rl : Final[Field] = Field(
    name='rl',
    origin='SMF744RL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CF Remote Faciliy Data Section

SMF Info
--------
    Field: `SMF744RL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of CF Remote Faciliy Data Section
"""
rl.__doc__ = """Length of CF Remote Faciliy Data Section

SMF Info
--------
    Field: `SMF744RL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of CF Remote Faciliy Data Section
"""

rn : Final[Field] = Field(
    name='rn',
    origin='SMF744RN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CF Remote Faciliy Data Sections

SMF Info
--------
    Field: `SMF744RN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of CF Remote Faciliy Data Sections
"""
rn.__doc__ = """Number of CF Remote Faciliy Data Sections

SMF Info
--------
    Field: `SMF744RN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of CF Remote Faciliy Data Sections
"""

ho : Final[Field] = Field(
    name='ho',
    origin='SMF744HO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Channel Path Data Section

SMF Info
--------
    Field: `SMF744HO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to Channel Path Data Section
"""
ho.__doc__ = """Offset to Channel Path Data Section

SMF Info
--------
    Field: `SMF744HO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to Channel Path Data Section
"""

hl : Final[Field] = Field(
    name='hl',
    origin='SMF744HL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Channel Path Data Section

SMF Info
--------
    Field: `SMF744HL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of Channel Path Data Section
"""
hl.__doc__ = """Length of Channel Path Data Section

SMF Info
--------
    Field: `SMF744HL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of Channel Path Data Section
"""

hn : Final[Field] = Field(
    name='hn',
    origin='SMF744HN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Channel Path Data Sections

SMF Info
--------
    Field: `SMF744HN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of Channel Path Data Sections
"""
hn.__doc__ = """Number of Channel Path Data Sections

SMF Info
--------
    Field: `SMF744HN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of Channel Path Data Sections
"""

mo : Final[Field] = Field(
    name='mo',
    origin='SMF744MO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to SCM Data Section

SMF Info
--------
    Field: `SMF744MO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to SCM Data Section
"""
mo.__doc__ = """Offset to SCM Data Section

SMF Info
--------
    Field: `SMF744MO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to SCM Data Section
"""

ml : Final[Field] = Field(
    name='ml',
    origin='SMF744ML',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of SCM Data Section

SMF Info
--------
    Field: `SMF744ML`
    Record: `SMF74S4`
    Map: Not part of a map

Length of SCM Data Section
"""
ml.__doc__ = """Length of SCM Data Section

SMF Info
--------
    Field: `SMF744ML`
    Record: `SMF74S4`
    Map: Not part of a map

Length of SCM Data Section
"""

mn : Final[Field] = Field(
    name='mn',
    origin='SMF744MN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of SCM Data Sections

SMF Info
--------
    Field: `SMF744MN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of SCM Data Sections
"""
mn.__doc__ = """Number of SCM Data Sections

SMF Info
--------
    Field: `SMF744MN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of SCM Data Sections
"""

ao : Final[Field] = Field(
    name='ao',
    origin='SMF744AO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Asynchronous CF Duplexing Data Section

SMF Info
--------
    Field: `SMF744AO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to Asynchronous CF Duplexing Data Section
"""
ao.__doc__ = """Offset to Asynchronous CF Duplexing Data Section

SMF Info
--------
    Field: `SMF744AO`
    Record: `SMF74S4`
    Map: Not part of a map

Offset to Asynchronous CF Duplexing Data Section
"""

al : Final[Field] = Field(
    name='al',
    origin='SMF744AL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Asynchronous CF Duplexing Data Section

SMF Info
--------
    Field: `SMF744AL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of Asynchronous CF Duplexing Data Section
"""
al.__doc__ = """Length of Asynchronous CF Duplexing Data Section

SMF Info
--------
    Field: `SMF744AL`
    Record: `SMF74S4`
    Map: Not part of a map

Length of Asynchronous CF Duplexing Data Section
"""

an : Final[Field] = Field(
    name='an',
    origin='SMF744AN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Asynchronous CF Duplexing Data Section

SMF Info
--------
    Field: `SMF744AN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of Asynchronous CF Duplexing Data Section
"""
an.__doc__ = """Number of Asynchronous CF Duplexing Data Section

SMF Info
--------
    Field: `SMF744AN`
    Record: `SMF74S4`
    Map: Not part of a map

Number of Asynchronous CF Duplexing Data Section
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S4`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S4`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S4`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S4`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S4`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S4`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S4`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S4`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S4`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S4`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S4`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S4`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S4`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S4`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

r744fnam : Final[Field] = Field(
    name='r744fnam',
    origin='R744FNAM',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""Name of Coupling Facility

SMF Info
--------
    Field: `R744FNAM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Name of Coupling Facility
"""
r744fnam.__doc__ = """Name of Coupling Facility

SMF Info
--------
    Field: `R744FNAM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Name of Coupling Facility
"""

r744fsys : Final[Field] = Field(
    name='r744fsys',
    origin='R744FSYS',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""Name of this system (from IEASYSxx parmlib member, SYSNAME param.)

SMF Info
--------
    Field: `R744FSYS`
    Record: `SMF74S4`
    Map: `R744FLCF`

Name of this system (from IEASYSxx parmlib member, SYSNAME param.)
"""
r744fsys.__doc__ = """Name of this system (from IEASYSxx parmlib member, SYSNAME param.)

SMF Info
--------
    Field: `R744FSYS`
    Record: `SMF74S4`
    Map: `R744FLCF`

Name of this system (from IEASYSxx parmlib member, SYSNAME param.)
"""

r744fflg : Final[Field] = Field(
    name='r744fflg',
    origin='R744FFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""Status Flags

SMF Info
--------
    Field: `R744FFLG`
    Record: `SMF74S4`
    Map: `R744FLCF`

Status Flags
"""
r744fflg.__doc__ = """Status Flags

SMF Info
--------
    Field: `R744FFLG`
    Record: `SMF74S4`
    Map: `R744FLCF`

Status Flags
"""

r744fcei : Final[Field] = Field(
    name='r744fcei',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744fflg,
    record=record,
    record_map=R744FLCF,
)
"""Coupling Facility was connected to the system at the end of the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Coupling Facility was connected to the system at the end of the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744fcei.__doc__ = """Coupling Facility was connected to the system at the end of the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Coupling Facility was connected to the system at the end of the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744fadi : Final[Field] = Field(
    name='r744fadi',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r744fflg,
    record=record,
    record_map=R744FLCF,
)
"""Coupling Facility became active during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Coupling Facility became active during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r744fadi.__doc__ = """Coupling Facility became active during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Coupling Facility became active during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r744fpec : Final[Field] = Field(
    name='r744fpec',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r744fflg,
    record=record,
    record_map=R744FLCF,
)
"""Permanent error in cycle gatherer during complete interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Permanent error in cycle gatherer during complete interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r744fpec.__doc__ = """Permanent error in cycle gatherer during complete interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Permanent error in cycle gatherer during complete interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r744fdyd : Final[Field] = Field(
    name='r744fdyd',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r744fflg,
    record=record,
    record_map=R744FLCF,
)
"""Dynamic CF dispatching active. Valid if R744FLVL > 14.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Dynamic CF dispatching active. Valid if R744FLVL > 14.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r744fdyd.__doc__ = """Dynamic CF dispatching active. Valid if R744FLVL > 14.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Dynamic CF dispatching active. Valid if R744FLVL > 14.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r744fthn : Final[Field] = Field(
    name='r744fthn',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r744fflg,
    record=record,
    record_map=R744FLCF,
)
"""Thin Interrupts are enabled. Valid if R744FLVL>18.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Thin Interrupts are enabled. Valid if R744FLVL>18.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r744fthn.__doc__ = """Thin Interrupts are enabled. Valid if R744FLVL>18.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Thin Interrupts are enabled. Valid if R744FLVL>18.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r744fnohw : Final[Field] = Field(
    name='r744fnohw',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r744fflg,
    record=record,
    record_map=R744FLCF,
)
"""No CF HW statistics available since optimized CF HW data gathering was active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

No CF HW statistics available since optimized CF HW data gathering was active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r744fnohw.__doc__ = """No CF HW statistics available since optimized CF HW data gathering was active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflg`(`R744FFLG`)
    Record: `SMF74S4`
    Map: `R744FLCF`

No CF HW statistics available since optimized CF HW data gathering was active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r744fflc : Final[Field] = Field(
    name='r744fflc',
    origin='R744FFLC',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""Informational flags

SMF Info
--------
    Field: `R744FFLC`
    Record: `SMF74S4`
    Map: `R744FLCF`

Informational flags
"""
r744fflc.__doc__ = """Informational flags

SMF Info
--------
    Field: `R744FFLC`
    Record: `SMF74S4`
    Map: `R744FLCF`

Informational flags
"""

r744famv : Final[Field] = Field(
    name='r744famv',
    origin='R744FAMV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""IXLYAMDA Version

SMF Info
--------
    Field: `R744FAMV`
    Record: `SMF74S4`
    Map: `R744FLCF`

IXLYAMDA Version
"""
r744famv.__doc__ = """IXLYAMDA Version

SMF Info
--------
    Field: `R744FAMV`
    Record: `SMF74S4`
    Map: `R744FLCF`

IXLYAMDA Version
"""

r744fpam : Final[Field] = Field(
    name='r744fpam',
    origin='R744FPAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Number of paths available to the CF

SMF Info
--------
    Field: `R744FPAM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of paths available to the CF
"""
r744fpam.__doc__ = """Number of paths available to the CF

SMF Info
--------
    Field: `R744FPAM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of paths available to the CF
"""

r744fpbc : Final[Field] = Field(
    name='r744fpbc',
    origin='R744FPBC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744FLCF,
)
"""Number of times CF requests fail due to path busy, long floating point

SMF Info
--------
    Field: `R744FPBC`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of times CF requests fail due to path busy, long floating point
"""
r744fpbc.__doc__ = """Number of times CF requests fail due to path busy, long floating point

SMF Info
--------
    Field: `R744FPBC`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of times CF requests fail due to path busy, long floating point
"""

r744fscg : Final[Field] = Field(
    name='r744fscg',
    origin='R744FSCG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Number of subchannels defined in the I/O gen

SMF Info
--------
    Field: `R744FSCG`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of subchannels defined in the I/O gen
"""
r744fscg.__doc__ = """Number of subchannels defined in the I/O gen

SMF Info
--------
    Field: `R744FSCG`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of subchannels defined in the I/O gen
"""

r744fscu : Final[Field] = Field(
    name='r744fscu',
    origin='R744FSCU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Number of subchannels currently in use

SMF Info
--------
    Field: `R744FSCU`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of subchannels currently in use
"""
r744fscu.__doc__ = """Number of subchannels currently in use

SMF Info
--------
    Field: `R744FSCU`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of subchannels currently in use
"""

r744fscl : Final[Field] = Field(
    name='r744fscl',
    origin='R744FSCL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Number of subchannels that can be used (Limit)

SMF Info
--------
    Field: `R744FSCL`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of subchannels that can be used (Limit)
"""
r744fscl.__doc__ = """Number of subchannels that can be used (Limit)

SMF Info
--------
    Field: `R744FSCL`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of subchannels that can be used (Limit)
"""

r744fscc : Final[Field] = Field(
    name='r744fscc',
    origin='R744FSCC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744FLCF,
)
"""Subchannel contetion count (all subchannel busy), long floating point

SMF Info
--------
    Field: `R744FSCC`
    Record: `SMF74S4`
    Map: `R744FLCF`

Subchannel contetion count (all subchannel busy), long floating point
"""
r744fscc.__doc__ = """Subchannel contetion count (all subchannel busy), long floating point

SMF Info
--------
    Field: `R744FSCC`
    Record: `SMF74S4`
    Map: `R744FLCF`

Subchannel contetion count (all subchannel busy), long floating point
"""

r744ftor : Final[Field] = Field(
    name='r744ftor',
    origin='R744FTOR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744FLCF,
)
"""Total number of requests from this system, long floating point

SMF Info
--------
    Field: `R744FTOR`
    Record: `SMF74S4`
    Map: `R744FLCF`

Total number of requests from this system, long floating point
"""
r744ftor.__doc__ = """Total number of requests from this system, long floating point

SMF Info
--------
    Field: `R744FTOR`
    Record: `SMF74S4`
    Map: `R744FLCF`

Total number of requests from this system, long floating point
"""

r744fail : Final[Field] = Field(
    name='r744fail',
    origin='R744FAIL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744FLCF,
)
"""Number of unsuccesful req. from this system, long floating point

SMF Info
--------
    Field: `R744FAIL`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of unsuccesful req. from this system, long floating point
"""
r744fail.__doc__ = """Number of unsuccesful req. from this system, long floating point

SMF Info
--------
    Field: `R744FAIL`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of unsuccesful req. from this system, long floating point
"""

r744ftim : Final[Field] = Field(
    name='r744ftim',
    origin='R744FTIM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Summed Service Time for unsuccessful requests in microseconds

SMF Info
--------
    Field: `R744FTIM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Summed Service Time for unsuccessful requests in microseconds
"""
r744ftim.__doc__ = """Summed Service Time for unsuccessful requests in microseconds

SMF Info
--------
    Field: `R744FTIM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Summed Service Time for unsuccessful requests in microseconds
"""

r744fsqu : Final[Field] = Field(
    name='r744fsqu',
    origin='R744FSQU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Summed squares of serv. time for unsucc. requests

SMF Info
--------
    Field: `R744FSQU`
    Record: `SMF74S4`
    Map: `R744FLCF`

Summed squares of serv. time for unsucc. requests
"""
r744fsqu.__doc__ = """Summed squares of serv. time for unsucc. requests

SMF Info
--------
    Field: `R744FSQU`
    Record: `SMF74S4`
    Map: `R744FLCF`

Summed squares of serv. time for unsucc. requests
"""

r744fctm : Final[Field] = Field(
    name='r744fctm',
    origin='R744FCTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Summed contention time for waiting for subchannels to become free (y-sec) for synchronous immediate operations

SMF Info
--------
    Field: `R744FCTM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Summed contention time for waiting for subchannels to become free (y-sec) for synchronous immediate operations
"""
r744fctm.__doc__ = """Summed contention time for waiting for subchannels to become free (y-sec) for synchronous immediate operations

SMF Info
--------
    Field: `R744FCTM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Summed contention time for waiting for subchannels to become free (y-sec) for synchronous immediate operations
"""

r744fcsq : Final[Field] = Field(
    name='r744fcsq',
    origin='R744FCSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Summed squares of contention time for waiting for subchannels to become free (y-sec *squared) for synchronous immediate operations

SMF Info
--------
    Field: `R744FCSQ`
    Record: `SMF74S4`
    Map: `R744FLCF`

Summed squares of contention time for waiting for subchannels to become free (y-sec *squared) for synchronous immediate operations
"""
r744fcsq.__doc__ = """Summed squares of contention time for waiting for subchannels to become free (y-sec *squared) for synchronous immediate operations

SMF Info
--------
    Field: `R744FCSQ`
    Record: `SMF74S4`
    Map: `R744FLCF`

Summed squares of contention time for waiting for subchannels to become free (y-sec *squared) for synchronous immediate operations
"""

r744fmod : Final[Field] = Field(
    name='r744fmod',
    origin='R744FMOD',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""EBCDIC type of CF. The type is right justified with leading blanks if necessary

SMF Info
--------
    Field: `R744FMOD`
    Record: `SMF74S4`
    Map: `R744FLCF`

EBCDIC type of CF. The type is right justified with leading blanks if necessary
"""
r744fmod.__doc__ = """EBCDIC type of CF. The type is right justified with leading blanks if necessary

SMF Info
--------
    Field: `R744FMOD`
    Record: `SMF74S4`
    Map: `R744FLCF`

EBCDIC type of CF. The type is right justified with leading blanks if necessary
"""

r744fver : Final[Field] = Field(
    name='r744fver',
    origin='R744FVER',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""EBCDIC model number of CF

SMF Info
--------
    Field: `R744FVER`
    Record: `SMF74S4`
    Map: `R744FLCF`

EBCDIC model number of CF
"""
r744fver.__doc__ = """EBCDIC model number of CF

SMF Info
--------
    Field: `R744FVER`
    Record: `SMF74S4`
    Map: `R744FLCF`

EBCDIC model number of CF
"""

r744fmpc : Final[Field] = Field(
    name='r744fmpc',
    origin='R744FMPC',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""EBCDIC manufacturer plant code of CF

SMF Info
--------
    Field: `R744FMPC`
    Record: `SMF74S4`
    Map: `R744FLCF`

EBCDIC manufacturer plant code of CF
"""
r744fmpc.__doc__ = """EBCDIC manufacturer plant code of CF

SMF Info
--------
    Field: `R744FMPC`
    Record: `SMF74S4`
    Map: `R744FLCF`

EBCDIC manufacturer plant code of CF
"""

r744flpn : Final[Field] = Field(
    name='r744flpn',
    origin='R744FLPN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Partition identifier of CF. Valid with SMF74SRL >= 55 (x85) and RMF version number SMF74MFV >= 718F

SMF Info
--------
    Field: `R744FLPN`
    Record: `SMF74S4`
    Map: `R744FLCF`

Partition identifier of CF. Valid with SMF74SRL >= 55 (x85) and RMF version number SMF74MFV >= 718F
"""
r744flpn.__doc__ = """Partition identifier of CF. Valid with SMF74SRL >= 55 (x85) and RMF version number SMF74MFV >= 718F

SMF Info
--------
    Field: `R744FLPN`
    Record: `SMF74S4`
    Map: `R744FLCF`

Partition identifier of CF. Valid with SMF74SRL >= 55 (x85) and RMF version number SMF74MFV >= 718F
"""

r744flvl : Final[Field] = Field(
    name='r744flvl',
    origin='R744FLVL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""CF level

SMF Info
--------
    Field: `R744FLVL`
    Record: `SMF74S4`
    Map: `R744FLCF`

CF level
"""
r744flvl.__doc__ = """CF level

SMF Info
--------
    Field: `R744FLVL`
    Record: `SMF74S4`
    Map: `R744FLCF`

CF level
"""

r744fpas : Final[Field] = Field(
    name='r744fpas',
    origin='R744FPAS',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""Path available mask for CF links

SMF Info
--------
    Field: `R744FPAS`
    Record: `SMF74S4`
    Map: `R744FLCF`

Path available mask for CF links
"""
r744fpas.__doc__ = """Path available mask for CF links

SMF Info
--------
    Field: `R744FPAS`
    Record: `SMF74S4`
    Map: `R744FLCF`

Path available mask for CF links
"""

r744fpis : Final[Field] = Field(
    name='r744fpis',
    origin='R744FPIS',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""Path installed mask for CF links

SMF Info
--------
    Field: `R744FPIS`
    Record: `SMF74S4`
    Map: `R744FLCF`

Path installed mask for CF links
"""
r744fpis.__doc__ = """Path installed mask for CF links

SMF Info
--------
    Field: `R744FPIS`
    Record: `SMF74S4`
    Map: `R744FLCF`

Path installed mask for CF links
"""

r744fpcm : Final[Field] = Field(
    name='r744fpcm',
    origin='R744FPCM',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""Composite path mask - paths having a physical and logical connection to the facility in the active policy

SMF Info
--------
    Field: `R744FPCM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Composite path mask - paths having a physical and logical connection to the facility in the active policy
"""
r744fpcm.__doc__ = """Composite path mask - paths having a physical and logical connection to the facility in the active policy

SMF Info
--------
    Field: `R744FPCM`
    Record: `SMF74S4`
    Map: `R744FLCF`

Composite path mask - paths having a physical and logical connection to the facility in the active policy
"""

r744fseq : Final[Field] = Field(
    name='r744fseq',
    origin='R744FSEQ',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""EBCDIC sequence number of this CF

SMF Info
--------
    Field: `R744FSEQ`
    Record: `SMF74S4`
    Map: `R744FLCF`

EBCDIC sequence number of this CF
"""
r744fseq.__doc__ = """EBCDIC sequence number of this CF

SMF Info
--------
    Field: `R744FSEQ`
    Record: `SMF74S4`
    Map: `R744FLCF`

EBCDIC sequence number of this CF
"""

r744fpsn : Final[Field] = Field(
    name='r744fpsn',
    origin='R744FPSN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Number of shared processors. Valid if R744FLVL > 14.

SMF Info
--------
    Field: `R744FPSN`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of shared processors. Valid if R744FLVL > 14.
"""
r744fpsn.__doc__ = """Number of shared processors. Valid if R744FLVL > 14.

SMF Info
--------
    Field: `R744FPSN`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of shared processors. Valid if R744FLVL > 14.
"""

r744fpdn : Final[Field] = Field(
    name='r744fpdn',
    origin='R744FPDN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Number of dedicated processors. Valid if R744FLVL > 14.

SMF Info
--------
    Field: `R744FPDN`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of dedicated processors. Valid if R744FLVL > 14.
"""
r744fpdn.__doc__ = """Number of dedicated processors. Valid if R744FLVL > 14.

SMF Info
--------
    Field: `R744FPDN`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of dedicated processors. Valid if R744FLVL > 14.
"""

r744fcpi : Final[Field] = Field(
    name='r744fcpi',
    origin='R744FCPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Index to first channel path data section associated with this coupling facility.

SMF Info
--------
    Field: `R744FCPI`
    Record: `SMF74S4`
    Map: `R744FLCF`

Index to first channel path data section associated with this coupling facility.
"""
r744fcpi.__doc__ = """Index to first channel path data section associated with this coupling facility.

SMF Info
--------
    Field: `R744FCPI`
    Record: `SMF74S4`
    Map: `R744FLCF`

Index to first channel path data section associated with this coupling facility.
"""

r744fcpn : Final[Field] = Field(
    name='r744fcpn',
    origin='R744FCPN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744FLCF,
)
"""Number of channel path data sections for channel paths of type 'CIB', 'CFP', 'CS5' or 'CL5' connected to this coupling facility. This count matches the number of subsequent channel path data sections.

SMF Info
--------
    Field: `R744FCPN`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of channel path data sections for channel paths of type 'CIB', 'CFP', 'CS5' or 'CL5' connected to this coupling facility. This count matches the number of subsequent channel path data sections.
"""
r744fcpn.__doc__ = """Number of channel path data sections for channel paths of type 'CIB', 'CFP', 'CS5' or 'CL5' connected to this coupling facility. This count matches the number of subsequent channel path data sections.

SMF Info
--------
    Field: `R744FCPN`
    Record: `SMF74S4`
    Map: `R744FLCF`

Number of channel path data sections for channel paths of type 'CIB', 'CFP', 'CS5' or 'CL5' connected to this coupling facility. This count matches the number of subsequent channel path data sections.
"""

r744ftap : Final[Field] = Field(
    name='r744ftap',
    origin='R744FTAP',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""CHPID array for channel path type acronyms

SMF Info
--------
    Field: `R744FTAP`
    Record: `SMF74S4`
    Map: `R744FLCF`

CHPID array for channel path type acronyms
"""
r744ftap.__doc__ = """CHPID array for channel path type acronyms

SMF Info
--------
    Field: `R744FTAP`
    Record: `SMF74S4`
    Map: `R744FLCF`

CHPID array for channel path type acronyms
"""

r744fidp : Final[Field] = Field(
    name='r744fidp',
    origin='R744FIDP',
    type=FieldType.STRING,
    record=record,
    record_map=R744FLCF,
)
"""CHPID array for channel path IDs.

SMF Info
--------
    Field: `R744FIDP`
    Record: `SMF74S4`
    Map: `R744FLCF`

CHPID array for channel path IDs.
"""
r744fidp.__doc__ = """CHPID array for channel path IDs.

SMF Info
--------
    Field: `R744FIDP`
    Record: `SMF74S4`
    Map: `R744FLCF`

CHPID array for channel path IDs.
"""

r744fcho : Final[Field] = Field(
    name='r744fcho',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744fflc,
    record=record,
    record_map=R744FLCF,
)
"""CHPIDs set offline during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflc`(`R744FFLC`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744fcho.__doc__ = """CHPIDs set offline during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744fflc`(`R744FFLC`)
    Record: `SMF74S4`
    Map: `R744FLCF`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744gcsd : Final[Field] = Field(
    name='r744gcsd',
    origin='R744GCSD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Total amount of control storage defined (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GCSD`
    Record: `SMF74S4`
    Map: `R744GSRG`

Total amount of control storage defined (units = 4K byte blocks)
"""
r744gcsd.__doc__ = """Total amount of control storage defined (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GCSD`
    Record: `SMF74S4`
    Map: `R744GSRG`

Total amount of control storage defined (units = 4K byte blocks)
"""

r744gcsf : Final[Field] = Field(
    name='r744gcsf',
    origin='R744GCSF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Amount of free control storage (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GCSF`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of free control storage (units = 4K byte blocks)
"""
r744gcsf.__doc__ = """Amount of free control storage (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GCSF`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of free control storage (units = 4K byte blocks)
"""

r744gtsd : Final[Field] = Field(
    name='r744gtsd',
    origin='R744GTSD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Total amount of CF storage defined (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GTSD`
    Record: `SMF74S4`
    Map: `R744GSRG`

Total amount of CF storage defined (units = 4K byte blocks)
"""
r744gtsd.__doc__ = """Total amount of CF storage defined (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GTSD`
    Record: `SMF74S4`
    Map: `R744GSRG`

Total amount of CF storage defined (units = 4K byte blocks)
"""

r744gtsf : Final[Field] = Field(
    name='r744gtsf',
    origin='R744GTSF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Amount of free CF storage (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GTSF`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of free CF storage (units = 4K byte blocks)
"""
r744gtsf.__doc__ = """Amount of free CF storage (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GTSF`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of free CF storage (units = 4K byte blocks)
"""

r744gdsa : Final[Field] = Field(
    name='r744gdsa',
    origin='R744GDSA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Amount of dump space allocated (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GDSA`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of dump space allocated (units = 4K byte blocks)
"""
r744gdsa.__doc__ = """Amount of dump space allocated (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GDSA`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of dump space allocated (units = 4K byte blocks)
"""

r744gdsf : Final[Field] = Field(
    name='r744gdsf',
    origin='R744GDSF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Amount of free dump space (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GDSF`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of free dump space (units = 4K byte blocks)
"""
r744gdsf.__doc__ = """Amount of free dump space (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GDSF`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of free dump space (units = 4K byte blocks)
"""

r744gdsr : Final[Field] = Field(
    name='r744gdsr',
    origin='R744GDSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Maximum amount of dump space requested (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GDSR`
    Record: `SMF74S4`
    Map: `R744GSRG`

Maximum amount of dump space requested (units = 4K byte blocks)
"""
r744gdsr.__doc__ = """Maximum amount of dump space requested (units = 4K byte blocks)

SMF Info
--------
    Field: `R744GDSR`
    Record: `SMF74S4`
    Map: `R744GSRG`

Maximum amount of dump space requested (units = 4K byte blocks)
"""

r744gtsc : Final[Field] = Field(
    name='r744gtsc',
    origin='R744GTSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Total amount of coupling facility storage class memory (units = 4K byte blocks) which may be concurrently used as structure extensions.

SMF Info
--------
    Field: `R744GTSC`
    Record: `SMF74S4`
    Map: `R744GSRG`

Total amount of coupling facility storage class memory (units = 4K byte blocks) which may be concurrently used as structure extensions.
"""
r744gtsc.__doc__ = """Total amount of coupling facility storage class memory (units = 4K byte blocks) which may be concurrently used as structure extensions.

SMF Info
--------
    Field: `R744GTSC`
    Record: `SMF74S4`
    Map: `R744GSRG`

Total amount of coupling facility storage class memory (units = 4K byte blocks) which may be concurrently used as structure extensions.
"""

r744gfsc : Final[Field] = Field(
    name='r744gfsc',
    origin='R744GFSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Amount of free coupling facility storage class memory (units = 4K byte blocks).

SMF Info
--------
    Field: `R744GFSC`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of free coupling facility storage class memory (units = 4K byte blocks).
"""
r744gfsc.__doc__ = """Amount of free coupling facility storage class memory (units = 4K byte blocks).

SMF Info
--------
    Field: `R744GFSC`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of free coupling facility storage class memory (units = 4K byte blocks).
"""

r744gisc : Final[Field] = Field(
    name='r744gisc',
    origin='R744GISC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744GSRG,
)
"""Amount of storage class memory increment. This is the number of 4K blocks that are assigned to a single storage class memory segment.

SMF Info
--------
    Field: `R744GISC`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of storage class memory increment. This is the number of 4K blocks that are assigned to a single storage class memory segment.
"""
r744gisc.__doc__ = """Amount of storage class memory increment. This is the number of 4K blocks that are assigned to a single storage class memory segment.

SMF Info
--------
    Field: `R744GISC`
    Record: `SMF74S4`
    Map: `R744GSRG`

Amount of storage class memory increment. This is the number of 4K blocks that are assigned to a single storage class memory segment.
"""

r744xsys : Final[Field] = Field(
    name='r744xsys',
    origin='R744XSYS',
    type=FieldType.STRING,
    record=record,
    record_map=R744XCON,
)
"""Name of remote system also reporting on this CF. From IEASYSxx parmlib member, SYSNAME parameter

SMF Info
--------
    Field: `R744XSYS`
    Record: `SMF74S4`
    Map: `R744XCON`

Name of remote system also reporting on this CF. From IEASYSxx parmlib member, SYSNAME parameter
"""
r744xsys.__doc__ = """Name of remote system also reporting on this CF. From IEASYSxx parmlib member, SYSNAME parameter

SMF Info
--------
    Field: `R744XSYS`
    Record: `SMF74S4`
    Map: `R744XCON`

Name of remote system also reporting on this CF. From IEASYSxx parmlib member, SYSNAME parameter
"""

r744qstr : Final[Field] = Field(
    name='r744qstr',
    origin='R744QSTR',
    type=FieldType.STRING,
    record=record,
    record_map=R744QSDS,
)
"""Name of structure allocated in this Coupling Facility

SMF Info
--------
    Field: `R744QSTR`
    Record: `SMF74S4`
    Map: `R744QSDS`

Name of structure allocated in this Coupling Facility
"""
r744qstr.__doc__ = """Name of structure allocated in this Coupling Facility

SMF Info
--------
    Field: `R744QSTR`
    Record: `SMF74S4`
    Map: `R744QSDS`

Name of structure allocated in this Coupling Facility
"""

r744qsiz : Final[Field] = Field(
    name='r744qsiz',
    origin='R744QSIZ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744QSDS,
)
"""Structure size as specified in CFRM active policy (units = 4K byte blocks)

SMF Info
--------
    Field: `R744QSIZ`
    Record: `SMF74S4`
    Map: `R744QSDS`

Structure size as specified in CFRM active policy (units = 4K byte blocks)
"""
r744qsiz.__doc__ = """Structure size as specified in CFRM active policy (units = 4K byte blocks)

SMF Info
--------
    Field: `R744QSIZ`
    Record: `SMF74S4`
    Map: `R744QSDS`

Structure size as specified in CFRM active policy (units = 4K byte blocks)
"""

r744qver : Final[Field] = Field(
    name='r744qver',
    origin='R744QVER',
    type=FieldType.STRING,
    record=record,
    record_map=R744QSDS,
)
"""Structure Version number

SMF Info
--------
    Field: `R744QVER`
    Record: `SMF74S4`
    Map: `R744QSDS`

Structure Version number
"""
r744qver.__doc__ = """Structure Version number

SMF Info
--------
    Field: `R744QVER`
    Record: `SMF74S4`
    Map: `R744QSDS`

Structure Version number
"""

r744qflg : Final[Field] = Field(
    name='r744qflg',
    origin='R744QFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R744QSDS,
)
"""Status Flags

SMF Info
--------
    Field: `R744QFLG`
    Record: `SMF74S4`
    Map: `R744QSDS`

Status Flags
"""
r744qflg.__doc__ = """Status Flags

SMF Info
--------
    Field: `R744QFLG`
    Record: `SMF74S4`
    Map: `R744QSDS`

Status Flags
"""

r744qact : Final[Field] = Field(
    name='r744qact',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744qflg,
    record=record,
    record_map=R744QSDS,
)
"""Active instance of structure (normal case)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Active instance of structure (normal case)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744qact.__doc__ = """Active instance of structure (normal case)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Active instance of structure (normal case)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744qrbn : Final[Field] = Field(
    name='r744qrbn',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r744qflg,
    record=record,
    record_map=R744QSDS,
)
"""New instance during rebuild(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

New instance during rebuild

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r744qrbn.__doc__ = """New instance during rebuild(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

New instance during rebuild

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r744qrbo : Final[Field] = Field(
    name='r744qrbo',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r744qflg,
    record=record,
    record_map=R744QSDS,
)
"""Old instance during rebuild(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Old instance during rebuild

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r744qrbo.__doc__ = """Old instance during rebuild(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Old instance during rebuild

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r744qtra : Final[Field] = Field(
    name='r744qtra',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r744qflg,
    record=record,
    record_map=R744QSDS,
)
"""Instance is just being added or deleted (in transition)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Instance is just being added or deleted (in transition)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r744qtra.__doc__ = """Instance is just being added or deleted (in transition)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Instance is just being added or deleted (in transition)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r744qhol : Final[Field] = Field(
    name='r744qhol',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r744qflg,
    record=record,
    record_map=R744QSDS,
)
"""Instance in hold, deletion could not be finished(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Instance in hold, deletion could not be finished

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r744qhol.__doc__ = """Instance in hold, deletion could not be finished(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Instance in hold, deletion could not be finished

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r744qdpt : Final[Field] = Field(
    name='r744qdpt',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r744qflg,
    record=record,
    record_map=R744QSDS,
)
"""Dump was initiated for this structure(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Dump was initiated for this structure

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r744qdpt.__doc__ = """Dump was initiated for this structure(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Dump was initiated for this structure

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r744qrbp : Final[Field] = Field(
    name='r744qrbp',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r744qflg,
    record=record,
    record_map=R744QSDS,
)
"""Structure rebuild in progress(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Structure rebuild in progress

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r744qrbp.__doc__ = """Structure rebuild in progress(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Structure rebuild in progress

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r744qrbd : Final[Field] = Field(
    name='r744qrbd',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r744qflg,
    record=record,
    record_map=R744QSDS,
)
"""The in-progress rebuild is a duplexing rebuild(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

The in-progress rebuild is a duplexing rebuild

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r744qrbd.__doc__ = """The in-progress rebuild is a duplexing rebuild(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qflg`(`R744QFLG`)
    Record: `SMF74S4`
    Map: `R744QSDS`

The in-progress rebuild is a duplexing rebuild

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r744qfl1 : Final[Field] = Field(
    name='r744qfl1',
    origin='R744QFL1',
    type=FieldType.STRING,
    record=record,
    record_map=R744QSDS,
)
"""Status Flags

SMF Info
--------
    Field: `R744QFL1`
    Record: `SMF74S4`
    Map: `R744QSDS`

Status Flags
"""
r744qfl1.__doc__ = """Status Flags

SMF Info
--------
    Field: `R744QFL1`
    Record: `SMF74S4`
    Map: `R744QSDS`

Status Flags
"""

r744qaad : Final[Field] = Field(
    name='r744qaad',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744qfl1,
    record=record,
    record_map=R744QSDS,
)
"""Duplexing is active using system managed asynchronous duplexing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qfl1`(`R744QFL1`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Duplexing is active using system managed asynchronous duplexing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744qaad.__doc__ = """Duplexing is active using system managed asynchronous duplexing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744qfl1`(`R744QFL1`)
    Record: `SMF74S4`
    Map: `R744QSDS`

Duplexing is active using system managed asynchronous duplexing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744snam : Final[Field] = Field(
    name='r744snam',
    origin='R744SNAM',
    type=FieldType.STRING,
    record=record,
    record_map=R744SREQ,
)
"""Name of connected structure in this Coupling Facility

SMF Info
--------
    Field: `R744SNAM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Name of connected structure in this Coupling Facility
"""
r744snam.__doc__ = """Name of connected structure in this Coupling Facility

SMF Info
--------
    Field: `R744SNAM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Name of connected structure in this Coupling Facility
"""

r744sver : Final[Field] = Field(
    name='r744sver',
    origin='R744SVER',
    type=FieldType.STRING,
    record=record,
    record_map=R744SREQ,
)
"""Structure Version number

SMF Info
--------
    Field: `R744SVER`
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure Version number
"""
r744sver.__doc__ = """Structure Version number

SMF Info
--------
    Field: `R744SVER`
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure Version number
"""

r744styp : Final[Field] = Field(
    name='r744styp',
    origin='R744STYP',
    type=FieldType.STRING,
    record=record,
    record_map=R744SREQ,
)
"""Structure type identifier Val Meaning 1 Unserialized List structure 2 Serialized List structure 3 Lock structure 4 Cache structure

SMF Info
--------
    Field: `R744STYP`
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure type identifier Val Meaning 1 Unserialized List structure 2 Serialized List structure 3 Lock structure 4 Cache structure
"""
r744styp.__doc__ = """Structure type identifier Val Meaning 1 Unserialized List structure 2 Serialized List structure 3 Lock structure 4 Cache structure

SMF Info
--------
    Field: `R744STYP`
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure type identifier Val Meaning 1 Unserialized List structure 2 Serialized List structure 3 Lock structure 4 Cache structure
"""

r744sflg : Final[Field] = Field(
    name='r744sflg',
    origin='R744SFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R744SREQ,
)
"""Status Flags

SMF Info
--------
    Field: `R744SFLG`
    Record: `SMF74S4`
    Map: `R744SREQ`

Status Flags
"""
r744sflg.__doc__ = """Status Flags

SMF Info
--------
    Field: `R744SFLG`
    Record: `SMF74S4`
    Map: `R744SREQ`

Status Flags
"""

r744scei : Final[Field] = Field(
    name='r744scei',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744sflg,
    record=record,
    record_map=R744SREQ,
)
"""Structure was connected to the system at the end of the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure was connected to the system at the end of the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744scei.__doc__ = """Structure was connected to the system at the end of the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure was connected to the system at the end of the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744sadi : Final[Field] = Field(
    name='r744sadi',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r744sflg,
    record=record,
    record_map=R744SREQ,
)
"""Structure became active during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure became active during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r744sadi.__doc__ = """Structure became active during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure became active during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r744scad : Final[Field] = Field(
    name='r744scad',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r744sflg,
    record=record,
    record_map=R744SREQ,
)
"""Structure is capable to participate in asynchronous duplexing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure is capable to participate in asynchronous duplexing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r744scad.__doc__ = """Structure is capable to participate in asynchronous duplexing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure is capable to participate in asynchronous duplexing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r744sdas : Final[Field] = Field(
    name='r744sdas',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r744sflg,
    record=record,
    record_map=R744SREQ,
)
"""Structure is in duplexing active state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure is in duplexing active state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r744sdas.__doc__ = """Structure is in duplexing active state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure is in duplexing active state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r744spri : Final[Field] = Field(
    name='r744spri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r744sflg,
    record=record,
    record_map=R744SREQ,
)
"""Structure is primary instance of an asynchronously duplexed structure(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure is primary instance of an asynchronously duplexed structure

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r744spri.__doc__ = """Structure is primary instance of an asynchronously duplexed structure(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure is primary instance of an asynchronously duplexed structure

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r744ssec : Final[Field] = Field(
    name='r744ssec',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r744sflg,
    record=record,
    record_map=R744SREQ,
)
"""Structure is secondary instance of an asynchronously duplexed structure(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure is secondary instance of an asynchronously duplexed structure

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r744ssec.__doc__ = """Structure is secondary instance of an asynchronously duplexed structure(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure is secondary instance of an asynchronously duplexed structure

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r744senc : Final[Field] = Field(
    name='r744senc',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r744sflg,
    record=record,
    record_map=R744SREQ,
)
"""Structure data is encrypted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure data is encrypted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r744senc.__doc__ = """Structure data is encrypted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sflg`(`R744SFLG`)
    Record: `SMF74S4`
    Map: `R744SREQ`

Structure data is encrypted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r744slec : Final[Field] = Field(
    name='r744slec',
    origin='R744SLEC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Lock structure only: Lock table entry characteristic

SMF Info
--------
    Field: `R744SLEC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Lock table entry characteristic
"""
r744slec.__doc__ = """Lock structure only: Lock table entry characteristic

SMF Info
--------
    Field: `R744SLEC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Lock table entry characteristic
"""

r744slel : Final[Field] = Field(
    name='r744slel',
    origin='R744SLEL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""List structure only: Limit on number of list entries. The estimated maximum number of list entries that may reside in storage class memory is not included. Lock structure: Limit on number of data elements.

SMF Info
--------
    Field: `R744SLEL`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Limit on number of list entries. The estimated maximum number of list entries that may reside in storage class memory is not included. Lock structure: Limit on number of data elements.
"""
r744slel.__doc__ = """List structure only: Limit on number of list entries. The estimated maximum number of list entries that may reside in storage class memory is not included. Lock structure: Limit on number of data elements.

SMF Info
--------
    Field: `R744SLEL`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Limit on number of list entries. The estimated maximum number of list entries that may reside in storage class memory is not included. Lock structure: Limit on number of data elements.
"""

r744slem : Final[Field] = Field(
    name='r744slem',
    origin='R744SLEM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""List structure only: Current number of list entries used during interval. The number of list entries that currently reside in storage class memory is not included. Lock structure: Current number of data elements in use.

SMF Info
--------
    Field: `R744SLEM`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Current number of list entries used during interval. The number of list entries that currently reside in storage class memory is not included. Lock structure: Current number of data elements in use.
"""
r744slem.__doc__ = """List structure only: Current number of list entries used during interval. The number of list entries that currently reside in storage class memory is not included. Lock structure: Current number of data elements in use.

SMF Info
--------
    Field: `R744SLEM`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Current number of list entries used during interval. The number of list entries that currently reside in storage class memory is not included. Lock structure: Current number of data elements in use.
"""

r744sltl : Final[Field] = Field(
    name='r744sltl',
    origin='R744SLTL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Lock structure only: Limit on number of lock table entries

SMF Info
--------
    Field: `R744SLTL`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Limit on number of lock table entries
"""
r744sltl.__doc__ = """Lock structure only: Limit on number of lock table entries

SMF Info
--------
    Field: `R744SLTL`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Limit on number of lock table entries
"""

r744sltm : Final[Field] = Field(
    name='r744sltm',
    origin='R744SLTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Lock structure only: Current number of lock table entries used during interval

SMF Info
--------
    Field: `R744SLTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Current number of lock table entries used during interval
"""
r744sltm.__doc__ = """Lock structure only: Current number of lock table entries used during interval

SMF Info
--------
    Field: `R744SLTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Current number of lock table entries used during interval
"""

r744ssta : Final[Field] = Field(
    name='r744ssta',
    origin='R744SSTA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Number of requests changed from synchronous to asynchronous, long floating point

SMF Info
--------
    Field: `R744SSTA`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of requests changed from synchronous to asynchronous, long floating point
"""
r744ssta.__doc__ = """Number of requests changed from synchronous to asynchronous, long floating point

SMF Info
--------
    Field: `R744SSTA`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of requests changed from synchronous to asynchronous, long floating point
"""

r744strc : Final[Field] = Field(
    name='r744strc',
    origin='R744STRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Total number of user requests completed, long floating point

SMF Info
--------
    Field: `R744STRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of user requests completed, long floating point
"""
r744strc.__doc__ = """Total number of user requests completed, long floating point

SMF Info
--------
    Field: `R744STRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of user requests completed, long floating point
"""

r744stac : Final[Field] = Field(
    name='r744stac',
    origin='R744STAC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Total number of asynchronous user requests completed, long floating point

SMF Info
--------
    Field: `R744STAC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of asynchronous user requests completed, long floating point
"""
r744stac.__doc__ = """Total number of asynchronous user requests completed, long floating point

SMF Info
--------
    Field: `R744STAC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of asynchronous user requests completed, long floating point
"""

r744sarc : Final[Field] = Field(
    name='r744sarc',
    origin='R744SARC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Count of number of times for async. requests executed by cf hardware, long floating point

SMF Info
--------
    Field: `R744SARC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of number of times for async. requests executed by cf hardware, long floating point
"""
r744sarc.__doc__ = """Count of number of times for async. requests executed by cf hardware, long floating point

SMF Info
--------
    Field: `R744SARC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of number of times for async. requests executed by cf hardware, long floating point
"""

r744satm : Final[Field] = Field(
    name='r744satm',
    origin='R744SATM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed service time for asynchronous requests in microseconds

SMF Info
--------
    Field: `R744SATM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed service time for asynchronous requests in microseconds
"""
r744satm.__doc__ = """Summed service time for asynchronous requests in microseconds

SMF Info
--------
    Field: `R744SATM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed service time for asynchronous requests in microseconds
"""

r744sasq : Final[Field] = Field(
    name='r744sasq',
    origin='R744SASQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed squares of serv. time for async. requests

SMF Info
--------
    Field: `R744SASQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed squares of serv. time for async. requests
"""
r744sasq.__doc__ = """Summed squares of serv. time for async. requests

SMF Info
--------
    Field: `R744SASQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed squares of serv. time for async. requests
"""

r744ssrc : Final[Field] = Field(
    name='r744ssrc',
    origin='R744SSRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Count of number of times for sync. requests executed by cf hardware, long floating point

SMF Info
--------
    Field: `R744SSRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of number of times for sync. requests executed by cf hardware, long floating point
"""
r744ssrc.__doc__ = """Count of number of times for sync. requests executed by cf hardware, long floating point

SMF Info
--------
    Field: `R744SSRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of number of times for sync. requests executed by cf hardware, long floating point
"""

r744sstm : Final[Field] = Field(
    name='r744sstm',
    origin='R744SSTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed service time for synchronous requests in microseconds

SMF Info
--------
    Field: `R744SSTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed service time for synchronous requests in microseconds
"""
r744sstm.__doc__ = """Summed service time for synchronous requests in microseconds

SMF Info
--------
    Field: `R744SSTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed service time for synchronous requests in microseconds
"""

r744sssq : Final[Field] = Field(
    name='r744sssq',
    origin='R744SSSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed squares of serv. time for sync. requests

SMF Info
--------
    Field: `R744SSSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed squares of serv. time for sync. requests
"""
r744sssq.__doc__ = """Summed squares of serv. time for sync. requests

SMF Info
--------
    Field: `R744SSSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed squares of serv. time for sync. requests
"""

r744sqrc : Final[Field] = Field(
    name='r744sqrc',
    origin='R744SQRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Count of number of times for queued requests, long floating point

SMF Info
--------
    Field: `R744SQRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of number of times for queued requests, long floating point
"""
r744sqrc.__doc__ = """Count of number of times for queued requests, long floating point

SMF Info
--------
    Field: `R744SQRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of number of times for queued requests, long floating point
"""

r744sqtm : Final[Field] = Field(
    name='r744sqtm',
    origin='R744SQTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed queue delay time in microseconds

SMF Info
--------
    Field: `R744SQTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed queue delay time in microseconds
"""
r744sqtm.__doc__ = """Summed queue delay time in microseconds

SMF Info
--------
    Field: `R744SQTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed queue delay time in microseconds
"""

r744sqsq : Final[Field] = Field(
    name='r744sqsq',
    origin='R744SQSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed squares of delay time for queued requests

SMF Info
--------
    Field: `R744SQSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed squares of delay time for queued requests
"""
r744sqsq.__doc__ = """Summed squares of delay time for queued requests

SMF Info
--------
    Field: `R744SQSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed squares of delay time for queued requests
"""

r744sdrc : Final[Field] = Field(
    name='r744sdrc',
    origin='R744SDRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Number of times a request was found delayed in case of dump serailization, long floating point

SMF Info
--------
    Field: `R744SDRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of times a request was found delayed in case of dump serailization, long floating point
"""
r744sdrc.__doc__ = """Number of times a request was found delayed in case of dump serailization, long floating point

SMF Info
--------
    Field: `R744SDRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of times a request was found delayed in case of dump serailization, long floating point
"""

r744sdtm : Final[Field] = Field(
    name='r744sdtm',
    origin='R744SDTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed dump delay time in microseconds

SMF Info
--------
    Field: `R744SDTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed dump delay time in microseconds
"""
r744sdtm.__doc__ = """Summed dump delay time in microseconds

SMF Info
--------
    Field: `R744SDTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed dump delay time in microseconds
"""

r744sdsq : Final[Field] = Field(
    name='r744sdsq',
    origin='R744SDSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed squares of dump delay time

SMF Info
--------
    Field: `R744SDSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed squares of dump delay time
"""
r744sdsq.__doc__ = """Summed squares of dump delay time

SMF Info
--------
    Field: `R744SDSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed squares of dump delay time
"""

r744sdmp : Final[Field] = Field(
    name='r744sdmp',
    origin='R744SDMP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Number of times dump serialization was found for this structure (list and cache structures only), long floating point

SMF Info
--------
    Field: `R744SDMP`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of times dump serialization was found for this structure (list and cache structures only), long floating point
"""
r744sdmp.__doc__ = """Number of times dump serialization was found for this structure (list and cache structures only), long floating point

SMF Info
--------
    Field: `R744SDMP`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of times dump serialization was found for this structure (list and cache structures only), long floating point
"""

r744shto : Final[Field] = Field(
    name='r744shto',
    origin='R744SHTO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Total number of requests added to the high priority queue during interval, long floating point

SMF Info
--------
    Field: `R744SHTO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of requests added to the high priority queue during interval, long floating point
"""
r744shto.__doc__ = """Total number of requests added to the high priority queue during interval, long floating point

SMF Info
--------
    Field: `R744SHTO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of requests added to the high priority queue during interval, long floating point
"""

r744shmn : Final[Field] = Field(
    name='r744shmn',
    origin='R744SHMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Minimum number of requests added to the high priority queue within one cycle (this is a rate per cycle)

SMF Info
--------
    Field: `R744SHMN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of requests added to the high priority queue within one cycle (this is a rate per cycle)
"""
r744shmn.__doc__ = """Minimum number of requests added to the high priority queue within one cycle (this is a rate per cycle)

SMF Info
--------
    Field: `R744SHMN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of requests added to the high priority queue within one cycle (this is a rate per cycle)
"""

r744shmx : Final[Field] = Field(
    name='r744shmx',
    origin='R744SHMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Maximum number of requests added to the high priority queue within one cycle (this is a rate per cycle)

SMF Info
--------
    Field: `R744SHMX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of requests added to the high priority queue within one cycle (this is a rate per cycle)
"""
r744shmx.__doc__ = """Maximum number of requests added to the high priority queue within one cycle (this is a rate per cycle)

SMF Info
--------
    Field: `R744SHMX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of requests added to the high priority queue within one cycle (this is a rate per cycle)
"""

r744slto : Final[Field] = Field(
    name='r744slto',
    origin='R744SLTO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Total number of requests added to the low priority queue during interval, long floating point

SMF Info
--------
    Field: `R744SLTO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of requests added to the low priority queue during interval, long floating point
"""
r744slto.__doc__ = """Total number of requests added to the low priority queue during interval, long floating point

SMF Info
--------
    Field: `R744SLTO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of requests added to the low priority queue during interval, long floating point
"""

r744slmn : Final[Field] = Field(
    name='r744slmn',
    origin='R744SLMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Minimum number of requests added to the low priority queue within one cycle (this is a rate per cycle)

SMF Info
--------
    Field: `R744SLMN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of requests added to the low priority queue within one cycle (this is a rate per cycle)
"""
r744slmn.__doc__ = """Minimum number of requests added to the low priority queue within one cycle (this is a rate per cycle)

SMF Info
--------
    Field: `R744SLMN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of requests added to the low priority queue within one cycle (this is a rate per cycle)
"""

r744slmx : Final[Field] = Field(
    name='r744slmx',
    origin='R744SLMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Maximum number of requests added to the low priority queue within one cycle (this is a rate per cycle)

SMF Info
--------
    Field: `R744SLMX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of requests added to the low priority queue within one cycle (this is a rate per cycle)
"""
r744slmx.__doc__ = """Maximum number of requests added to the low priority queue within one cycle (this is a rate per cycle)

SMF Info
--------
    Field: `R744SLMX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of requests added to the low priority queue within one cycle (this is a rate per cycle)
"""

r744sdto : Final[Field] = Field(
    name='r744sdto',
    origin='R744SDTO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Total number of requests added to the dump queue since dump serialization is in progress, long floating point

SMF Info
--------
    Field: `R744SDTO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of requests added to the dump queue since dump serialization is in progress, long floating point
"""
r744sdto.__doc__ = """Total number of requests added to the dump queue since dump serialization is in progress, long floating point

SMF Info
--------
    Field: `R744SDTO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of requests added to the dump queue since dump serialization is in progress, long floating point
"""

r744sdmn : Final[Field] = Field(
    name='r744sdmn',
    origin='R744SDMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Minimum number of requests added to the dump queue since dump serialization is in progress within one cycle, (rate per cycle)

SMF Info
--------
    Field: `R744SDMN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of requests added to the dump queue since dump serialization is in progress within one cycle, (rate per cycle)
"""
r744sdmn.__doc__ = """Minimum number of requests added to the dump queue since dump serialization is in progress within one cycle, (rate per cycle)

SMF Info
--------
    Field: `R744SDMN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of requests added to the dump queue since dump serialization is in progress within one cycle, (rate per cycle)
"""

r744sdmx : Final[Field] = Field(
    name='r744sdmx',
    origin='R744SDMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Maximum number of requests added to the dump queue since dump serialization is in progress within one cycle, (rate per cycle)

SMF Info
--------
    Field: `R744SDMX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of requests added to the dump queue since dump serialization is in progress within one cycle, (rate per cycle)
"""
r744sdmx.__doc__ = """Maximum number of requests added to the dump queue since dump serialization is in progress within one cycle, (rate per cycle)

SMF Info
--------
    Field: `R744SDMX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of requests added to the dump queue since dump serialization is in progress within one cycle, (rate per cycle)
"""

r744scn : Final[Field] = Field(
    name='r744scn',
    origin='R744SCN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Lock structure only: Number of times any request encountered lock contention, long floating point

SMF Info
--------
    Field: `R744SCN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Number of times any request encountered lock contention, long floating point
"""
r744scn.__doc__ = """Lock structure only: Number of times any request encountered lock contention, long floating point

SMF Info
--------
    Field: `R744SCN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Number of times any request encountered lock contention, long floating point
"""

r744sfcn : Final[Field] = Field(
    name='r744sfcn',
    origin='R744SFCN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Lock structure only: Number of times any request encountered false lock contention (storage contention within the structure), long floating point

SMF Info
--------
    Field: `R744SFCN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Number of times any request encountered false lock contention (storage contention within the structure), long floating point
"""
r744sfcn.__doc__ = """Lock structure only: Number of times any request encountered false lock contention (storage contention within the structure), long floating point

SMF Info
--------
    Field: `R744SFCN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Lock structure only: Number of times any request encountered false lock contention (storage contention within the structure), long floating point
"""

r744ssiz : Final[Field] = Field(
    name='r744ssiz',
    origin='R744SSIZ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Allocated size of structure (units = 4K byte blocks)

SMF Info
--------
    Field: `R744SSIZ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Allocated size of structure (units = 4K byte blocks)
"""
r744ssiz.__doc__ = """Allocated size of structure (units = 4K byte blocks)

SMF Info
--------
    Field: `R744SSIZ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Allocated size of structure (units = 4K byte blocks)
"""

r744smas : Final[Field] = Field(
    name='r744smas',
    origin='R744SMAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Maximum structure size

SMF Info
--------
    Field: `R744SMAS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum structure size
"""
r744smas.__doc__ = """Maximum structure size

SMF Info
--------
    Field: `R744SMAS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum structure size
"""

r744smis : Final[Field] = Field(
    name='r744smis',
    origin='R744SMIS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Minimum structure size

SMF Info
--------
    Field: `R744SMIS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum structure size
"""
r744smis.__doc__ = """Minimum structure size

SMF Info
--------
    Field: `R744SMIS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum structure size
"""

r744sdec : Final[Field] = Field(
    name='r744sdec',
    origin='R744SDEC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Cache structure only: Total directory entry count

SMF Info
--------
    Field: `R744SDEC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Cache structure only: Total directory entry count
"""
r744sdec.__doc__ = """Cache structure only: Total directory entry count

SMF Info
--------
    Field: `R744SDEC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Cache structure only: Total directory entry count
"""

r744sdel : Final[Field] = Field(
    name='r744sdel',
    origin='R744SDEL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Cache structure only: Total data element count

SMF Info
--------
    Field: `R744SDEL`
    Record: `SMF74S4`
    Map: `R744SREQ`

Cache structure only: Total data element count
"""
r744sdel.__doc__ = """Cache structure only: Total data element count

SMF Info
--------
    Field: `R744SDEL`
    Record: `SMF74S4`
    Map: `R744SREQ`

Cache structure only: Total data element count
"""

r744snlh : Final[Field] = Field(
    name='r744snlh',
    origin='R744SNLH',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""List structure only: Number of list headers

SMF Info
--------
    Field: `R744SNLH`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Number of list headers
"""
r744snlh.__doc__ = """List structure only: Number of list headers

SMF Info
--------
    Field: `R744SNLH`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Number of list headers
"""

r744smae : Final[Field] = Field(
    name='r744smae',
    origin='R744SMAE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""List structure only: Maximum number of elements. The estimated maximum number of list elements that may reside in storage class memory is not included.

SMF Info
--------
    Field: `R744SMAE`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Maximum number of elements. The estimated maximum number of list elements that may reside in storage class memory is not included.
"""
r744smae.__doc__ = """List structure only: Maximum number of elements. The estimated maximum number of list elements that may reside in storage class memory is not included.

SMF Info
--------
    Field: `R744SMAE`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Maximum number of elements. The estimated maximum number of list elements that may reside in storage class memory is not included.
"""

r744scue : Final[Field] = Field(
    name='r744scue',
    origin='R744SCUE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""List structure only: Current number of elements in use. The number of list elements that currently reside in storage class memory is not included.

SMF Info
--------
    Field: `R744SCUE`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Current number of elements in use. The number of list elements that currently reside in storage class memory is not included.
"""
r744scue.__doc__ = """List structure only: Current number of elements in use. The number of list elements that currently reside in storage class memory is not included.

SMF Info
--------
    Field: `R744SCUE`
    Record: `SMF74S4`
    Map: `R744SREQ`

List structure only: Current number of elements in use. The number of list elements that currently reside in storage class memory is not included.
"""

r744cdsi : Final[Field] = Field(
    name='r744cdsi',
    origin='R744CDSI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Index to first Cache Data section

SMF Info
--------
    Field: `R744CDSI`
    Record: `SMF74S4`
    Map: `R744SREQ`

Index to first Cache Data section
"""
r744cdsi.__doc__ = """Index to first Cache Data section

SMF Info
--------
    Field: `R744CDSI`
    Record: `SMF74S4`
    Map: `R744SREQ`

Index to first Cache Data section
"""

r744cdne : Final[Field] = Field(
    name='r744cdne',
    origin='R744CDNE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of Cache Data Section entries

SMF Info
--------
    Field: `R744CDNE`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of Cache Data Section entries
"""
r744cdne.__doc__ = """Number of Cache Data Section entries

SMF Info
--------
    Field: `R744CDNE`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of Cache Data Section entries
"""

r744spln : Final[Field] = Field(
    name='r744spln',
    origin='R744SPLN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Count of peer link not available conditions

SMF Info
--------
    Field: `R744SPLN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of peer link not available conditions
"""
r744spln.__doc__ = """Count of peer link not available conditions

SMF Info
--------
    Field: `R744SPLN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of peer link not available conditions
"""

r744spes : Final[Field] = Field(
    name='r744spes',
    origin='R744SPES',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Count of execution suppressed conditions, long floating point

SMF Info
--------
    Field: `R744SPES`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of execution suppressed conditions, long floating point
"""
r744spes.__doc__ = """Count of execution suppressed conditions, long floating point

SMF Info
--------
    Field: `R744SPES`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of execution suppressed conditions, long floating point
"""

r744sptc : Final[Field] = Field(
    name='r744sptc',
    origin='R744SPTC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Count of the number of 'waiting for peer subchannel' reported, long floating point

SMF Info
--------
    Field: `R744SPTC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of the number of 'waiting for peer subchannel' reported, long floating point
"""
r744sptc.__doc__ = """Count of the number of 'waiting for peer subchannel' reported, long floating point

SMF Info
--------
    Field: `R744SPTC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of the number of 'waiting for peer subchannel' reported, long floating point
"""

r744spst : Final[Field] = Field(
    name='r744spst',
    origin='R744SPST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed peer subchannel wait time (u-sec)

SMF Info
--------
    Field: `R744SPST`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed peer subchannel wait time (u-sec)
"""
r744spst.__doc__ = """Summed peer subchannel wait time (u-sec)

SMF Info
--------
    Field: `R744SPST`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed peer subchannel wait time (u-sec)
"""

r744spss : Final[Field] = Field(
    name='r744spss',
    origin='R744SPSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed peer subchannel wait time squared (u-sec squared)

SMF Info
--------
    Field: `R744SPSS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed peer subchannel wait time squared (u-sec squared)
"""
r744spss.__doc__ = """Summed peer subchannel wait time squared (u-sec squared)

SMF Info
--------
    Field: `R744SPSS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed peer subchannel wait time squared (u-sec squared)
"""

r744srtc : Final[Field] = Field(
    name='r744srtc',
    origin='R744SRTC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Count of the number of 'waiting for peer subchannel with reserve held' reported, long floating point

SMF Info
--------
    Field: `R744SRTC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of the number of 'waiting for peer subchannel with reserve held' reported, long floating point
"""
r744srtc.__doc__ = """Count of the number of 'waiting for peer subchannel with reserve held' reported, long floating point

SMF Info
--------
    Field: `R744SRTC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of the number of 'waiting for peer subchannel with reserve held' reported, long floating point
"""

r744srst : Final[Field] = Field(
    name='r744srst',
    origin='R744SRST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed peer subchannel wait with reserve time (u-sec)

SMF Info
--------
    Field: `R744SRST`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed peer subchannel wait with reserve time (u-sec)
"""
r744srst.__doc__ = """Summed peer subchannel wait with reserve time (u-sec)

SMF Info
--------
    Field: `R744SRST`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed peer subchannel wait with reserve time (u-sec)
"""

r744srss : Final[Field] = Field(
    name='r744srss',
    origin='R744SRSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed peer subchannel wait with reserve time squared (u-sec squared)

SMF Info
--------
    Field: `R744SRSS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed peer subchannel wait with reserve time squared (u-sec squared)
"""
r744srss.__doc__ = """Summed peer subchannel wait with reserve time squared (u-sec squared)

SMF Info
--------
    Field: `R744SRSS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed peer subchannel wait with reserve time squared (u-sec squared)
"""

r744sctc : Final[Field] = Field(
    name='r744sctc',
    origin='R744SCTC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Count of the number of 'waiting for peer completion' times reported, long floating point

SMF Info
--------
    Field: `R744SCTC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of the number of 'waiting for peer completion' times reported, long floating point
"""
r744sctc.__doc__ = """Count of the number of 'waiting for peer completion' times reported, long floating point

SMF Info
--------
    Field: `R744SCTC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of the number of 'waiting for peer completion' times reported, long floating point
"""

r744scst : Final[Field] = Field(
    name='r744scst',
    origin='R744SCST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed waiting for peer completion times (u-sec)

SMF Info
--------
    Field: `R744SCST`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed waiting for peer completion times (u-sec)
"""
r744scst.__doc__ = """Summed waiting for peer completion times (u-sec)

SMF Info
--------
    Field: `R744SCST`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed waiting for peer completion times (u-sec)
"""

r744scss : Final[Field] = Field(
    name='r744scss',
    origin='R744SCSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed waiting for peer completion times squared (u-sec squared)

SMF Info
--------
    Field: `R744SCSS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed waiting for peer completion times squared (u-sec squared)
"""
r744scss.__doc__ = """Summed waiting for peer completion times squared (u-sec squared)

SMF Info
--------
    Field: `R744SCSS`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed waiting for peer completion times squared (u-sec squared)
"""

r744slsv : Final[Field] = Field(
    name='r744slsv',
    origin='R744SLSV',
    type=FieldType.STRING,
    record=record,
    record_map=R744SREQ,
)
"""Logical structure version number

SMF Info
--------
    Field: `R744SLSV`
    Record: `SMF74S4`
    Map: `R744SREQ`

Logical structure version number
"""
r744slsv.__doc__ = """Logical structure version number

SMF Info
--------
    Field: `R744SLSV`
    Record: `SMF74S4`
    Map: `R744SREQ`

Logical structure version number
"""

r744setm : Final[Field] = Field(
    name='r744setm',
    origin='R744SETM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Summed structure execution time in u-sec (long floating point). Valid if R744FLVL > 14.

SMF Info
--------
    Field: `R744SETM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed structure execution time in u-sec (long floating point). Valid if R744FLVL > 14.
"""
r744setm.__doc__ = """Summed structure execution time in u-sec (long floating point). Valid if R744FLVL > 14.

SMF Info
--------
    Field: `R744SETM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed structure execution time in u-sec (long floating point). Valid if R744FLVL > 14.
"""

r744sisc : Final[Field] = Field(
    name='r744sisc',
    origin='R744SISC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Index to Storage Class Memory data section. This field is zero if there is no information available.

SMF Info
--------
    Field: `R744SISC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Index to Storage Class Memory data section. This field is zero if there is no information available.
"""
r744sisc.__doc__ = """Index to Storage Class Memory data section. This field is zero if there is no information available.

SMF Info
--------
    Field: `R744SISC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Index to Storage Class Memory data section. This field is zero if there is no information available.
"""

r744snsc : Final[Field] = Field(
    name='r744snsc',
    origin='R744SNSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of Storage Class Memory data sctions.

SMF Info
--------
    Field: `R744SNSC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of Storage Class Memory data sctions.
"""
r744snsc.__doc__ = """Number of Storage Class Memory data sctions.

SMF Info
--------
    Field: `R744SNSC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of Storage Class Memory data sctions.
"""

r744ssac : Final[Field] = Field(
    name='r744ssac',
    origin='R744SSAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Count of Storage Class Memory Access Required conditions that require the request to be restarted.

SMF Info
--------
    Field: `R744SSAC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of Storage Class Memory Access Required conditions that require the request to be restarted.
"""
r744ssac.__doc__ = """Count of Storage Class Memory Access Required conditions that require the request to be restarted.

SMF Info
--------
    Field: `R744SSAC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of Storage Class Memory Access Required conditions that require the request to be restarted.
"""

r744sosa : Final[Field] = Field(
    name='r744sosa',
    origin='R744SOSA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Count of successful operations to the coupling facility that encountered an SCM Access Required condition.

SMF Info
--------
    Field: `R744SOSA`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of successful operations to the coupling facility that encountered an SCM Access Required condition.
"""
r744sosa.__doc__ = """Count of successful operations to the coupling facility that encountered an SCM Access Required condition.

SMF Info
--------
    Field: `R744SOSA`
    Record: `SMF74S4`
    Map: `R744SREQ`

Count of successful operations to the coupling facility that encountered an SCM Access Required condition.
"""

r744siad : Final[Field] = Field(
    name='r744siad',
    origin='R744SIAD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Index to Asynchronous CF Duplexing data section. This field is zero if there is no Asynchronous CF Duplexing data available.

SMF Info
--------
    Field: `R744SIAD`
    Record: `SMF74S4`
    Map: `R744SREQ`

Index to Asynchronous CF Duplexing data section. This field is zero if there is no Asynchronous CF Duplexing data available.
"""
r744siad.__doc__ = """Index to Asynchronous CF Duplexing data section. This field is zero if there is no Asynchronous CF Duplexing data available.

SMF Info
--------
    Field: `R744SIAD`
    Record: `SMF74S4`
    Map: `R744SREQ`

Index to Asynchronous CF Duplexing data section. This field is zero if there is no Asynchronous CF Duplexing data available.
"""

r744sadn : Final[Field] = Field(
    name='r744sadn',
    origin='R744SADN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of Asynchronous CF Duplexing data sections.

SMF Info
--------
    Field: `R744SADN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of Asynchronous CF Duplexing data sections.
"""
r744sadn.__doc__ = """Number of Asynchronous CF Duplexing data sections.

SMF Info
--------
    Field: `R744SADN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of Asynchronous CF Duplexing data sections.
"""

r744sixc : Final[Field] = Field(
    name='r744sixc',
    origin='R744SIXC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of asynchronous duplex requests that requested sync up with the primary structure. (Valid if bit 1 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SIXC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of asynchronous duplex requests that requested sync up with the primary structure. (Valid if bit 1 of R744SXFL is set.)
"""
r744sixc.__doc__ = """Number of asynchronous duplex requests that requested sync up with the primary structure. (Valid if bit 1 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SIXC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of asynchronous duplex requests that requested sync up with the primary structure. (Valid if bit 1 of R744SXFL is set.)
"""

r744sxsc : Final[Field] = Field(
    name='r744sxsc',
    origin='R744SXSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of asynchronous duplex requests that were suspended waiting for the operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SXSC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of asynchronous duplex requests that were suspended waiting for the operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)
"""
r744sxsc.__doc__ = """Number of asynchronous duplex requests that were suspended waiting for the operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SXSC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of asynchronous duplex requests that were suspended waiting for the operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)
"""

r744sxst : Final[Field] = Field(
    name='r744sxst',
    origin='R744SXST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed suspend time, in microseconds, for suspended requests that were waiting for asynchronous duplex operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SXST`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed suspend time, in microseconds, for suspended requests that were waiting for asynchronous duplex operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)
"""
r744sxst.__doc__ = """Summed suspend time, in microseconds, for suspended requests that were waiting for asynchronous duplex operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SXST`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed suspend time, in microseconds, for suspended requests that were waiting for asynchronous duplex operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)
"""

r744sxsq : Final[Field] = Field(
    name='r744sxsq',
    origin='R744SXSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Square of summed suspend times, in square of microseconds, for suspended requests that were waiting for the asynchronous duplex operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SXSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Square of summed suspend times, in square of microseconds, for suspended requests that were waiting for the asynchronous duplex operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)
"""
r744sxsq.__doc__ = """Square of summed suspend times, in square of microseconds, for suspended requests that were waiting for the asynchronous duplex operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SXSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Square of summed suspend times, in square of microseconds, for suspended requests that were waiting for the asynchronous duplex operations to complete in the secondary structure of the current duplexing instance. (Valid if bit 1 of R744SXFL is set.)
"""

r744sado : Final[Field] = Field(
    name='r744sado',
    origin='R744SADO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of asynchronous duplex operations that were delayed because the primary structure was unable to accept new requests either because it could not forward requests to the secondary CF or because the secondary CF could not process incoming requests. (Valid if bit 0 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SADO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of asynchronous duplex operations that were delayed because the primary structure was unable to accept new requests either because it could not forward requests to the secondary CF or because the secondary CF could not process incoming requests. (Valid if bit 0 of R744SXFL is set.)
"""
r744sado.__doc__ = """Number of asynchronous duplex operations that were delayed because the primary structure was unable to accept new requests either because it could not forward requests to the secondary CF or because the secondary CF could not process incoming requests. (Valid if bit 0 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SADO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of asynchronous duplex operations that were delayed because the primary structure was unable to accept new requests either because it could not forward requests to the secondary CF or because the secondary CF could not process incoming requests. (Valid if bit 0 of R744SXFL is set.)
"""

r744sadr : Final[Field] = Field(
    name='r744sadr',
    origin='R744SADR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of asynchronous duplex requests that experienced a delayed operation because the primary CF was unable to accept new requests. (Valid if bit 0 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SADR`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of asynchronous duplex requests that experienced a delayed operation because the primary CF was unable to accept new requests. (Valid if bit 0 of R744SXFL is set.)
"""
r744sadr.__doc__ = """Number of asynchronous duplex requests that experienced a delayed operation because the primary CF was unable to accept new requests. (Valid if bit 0 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SADR`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of asynchronous duplex requests that experienced a delayed operation because the primary CF was unable to accept new requests. (Valid if bit 0 of R744SXFL is set.)
"""

r744sqch : Final[Field] = Field(
    name='r744sqch',
    origin='R744SQCH',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Asynchronous duplex operation queue statistic. The number of queue elements is the product of 4096*2**R744SQCH.

SMF Info
--------
    Field: `R744SQCH`
    Record: `SMF74S4`
    Map: `R744SREQ`

Asynchronous duplex operation queue statistic. The number of queue elements is the product of 4096*2**R744SQCH.
"""
r744sqch.__doc__ = """Asynchronous duplex operation queue statistic. The number of queue elements is the product of 4096*2**R744SQCH.

SMF Info
--------
    Field: `R744SQCH`
    Record: `SMF74S4`
    Map: `R744SREQ`

Asynchronous duplex operation queue statistic. The number of queue elements is the product of 4096*2**R744SQCH.
"""

r744sxfl : Final[Field] = Field(
    name='r744sxfl',
    origin='R744SXFL',
    type=FieldType.STRING,
    record=record,
    record_map=R744SREQ,
)
"""Flags

SMF Info
--------
    Field: `R744SXFL`
    Record: `SMF74S4`
    Map: `R744SREQ`

Flags
"""
r744sxfl.__doc__ = """Flags

SMF Info
--------
    Field: `R744SXFL`
    Record: `SMF74S4`
    Map: `R744SREQ`

Flags
"""

r744sxap : Final[Field] = Field(
    name='r744sxap',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744sxfl,
    record=record,
    record_map=R744SREQ,
)
"""data for primary instance of async duplexed structure is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sxfl`(`R744SXFL`)
    Record: `SMF74S4`
    Map: `R744SREQ`

data for primary instance of async duplexed structure is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744sxap.__doc__ = """data for primary instance of async duplexed structure is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sxfl`(`R744SXFL`)
    Record: `SMF74S4`
    Map: `R744SREQ`

data for primary instance of async duplexed structure is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744sxas : Final[Field] = Field(
    name='r744sxas',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r744sxfl,
    record=record,
    record_map=R744SREQ,
)
"""data for secondary instance of async duplexed structure is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sxfl`(`R744SXFL`)
    Record: `SMF74S4`
    Map: `R744SREQ`

data for secondary instance of async duplexed structure is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r744sxas.__doc__ = """data for secondary instance of async duplexed structure is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sxfl`(`R744SXFL`)
    Record: `SMF74S4`
    Map: `R744SREQ`

data for secondary instance of async duplexed structure is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r744sxcm : Final[Field] = Field(
    name='r744sxcm',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r744sxfl,
    record=record,
    record_map=R744SREQ,
)
"""data for write and read request measurements is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sxfl`(`R744SXFL`)
    Record: `SMF74S4`
    Map: `R744SREQ`

data for write and read request measurements is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r744sxcm.__doc__ = """data for write and read request measurements is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sxfl`(`R744SXFL`)
    Record: `SMF74S4`
    Map: `R744SREQ`

data for write and read request measurements is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r744sxmo : Final[Field] = Field(
    name='r744sxmo',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r744sxfl,
    record=record,
    record_map=R744SREQ,
)
"""data for CF monopolization delays is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sxfl`(`R744SXFL`)
    Record: `SMF74S4`
    Map: `R744SREQ`

data for CF monopolization delays is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r744sxmo.__doc__ = """data for CF monopolization delays is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744sxfl`(`R744SXFL`)
    Record: `SMF74S4`
    Map: `R744SREQ`

data for CF monopolization delays is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r744swdr : Final[Field] = Field(
    name='r744swdr',
    origin='R744SWDR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of requests to write data to the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWDR`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of requests to write data to the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""
r744swdr.__doc__ = """Number of requests to write data to the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWDR`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of requests to write data to the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""

r744swac : Final[Field] = Field(
    name='r744swac',
    origin='R744SWAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of adjunct areas written to the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWAC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of adjunct areas written to the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""
r744swac.__doc__ = """Number of adjunct areas written to the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWAC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of adjunct areas written to the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""

r744srdr : Final[Field] = Field(
    name='r744srdr',
    origin='R744SRDR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of requests to read data from the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SRDR`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of requests to read data from the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""
r744srdr.__doc__ = """Number of requests to read data from the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SRDR`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of requests to read data from the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""

r744srac : Final[Field] = Field(
    name='r744srac',
    origin='R744SRAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of adjunct areas read from the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SRAC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of adjunct areas read from the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""
r744srac.__doc__ = """Number of adjunct areas read from the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SRAC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of adjunct areas read from the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""

r744swec : Final[Field] = Field(
    name='r744swec',
    origin='R744SWEC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of data entries with data elements that have been written to the CF structure. Includes both single and multi entry write requests. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWEC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of data entries with data elements that have been written to the CF structure. Includes both single and multi entry write requests. (Valid if bit 2 of R744SXFL is set.)
"""
r744swec.__doc__ = """Number of data entries with data elements that have been written to the CF structure. Includes both single and multi entry write requests. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWEC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of data entries with data elements that have been written to the CF structure. Includes both single and multi entry write requests. (Valid if bit 2 of R744SXFL is set.)
"""

r744srec : Final[Field] = Field(
    name='r744srec',
    origin='R744SREC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Number of data entries with data elements that have been read from the CF structure. Includes both single and multi entry read requests. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SREC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of data entries with data elements that have been read from the CF structure. Includes both single and multi entry read requests. (Valid if bit 2 of R744SXFL is set.)
"""
r744srec.__doc__ = """Number of data entries with data elements that have been read from the CF structure. Includes both single and multi entry read requests. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SREC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of data entries with data elements that have been read from the CF structure. Includes both single and multi entry read requests. (Valid if bit 2 of R744SXFL is set.)
"""

r744swed : Final[Field] = Field(
    name='r744swed',
    origin='R744SWED',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Sum of 256 byte increments accumulated for entry data with data elements written to the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWED`
    Record: `SMF74S4`
    Map: `R744SREQ`

Sum of 256 byte increments accumulated for entry data with data elements written to the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""
r744swed.__doc__ = """Sum of 256 byte increments accumulated for entry data with data elements written to the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWED`
    Record: `SMF74S4`
    Map: `R744SREQ`

Sum of 256 byte increments accumulated for entry data with data elements written to the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""

r744swes : Final[Field] = Field(
    name='r744swes',
    origin='R744SWES',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Squares of summed number of 256 byte increments accumulated for entry data with data elements written to the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWES`
    Record: `SMF74S4`
    Map: `R744SREQ`

Squares of summed number of 256 byte increments accumulated for entry data with data elements written to the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""
r744swes.__doc__ = """Squares of summed number of 256 byte increments accumulated for entry data with data elements written to the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SWES`
    Record: `SMF74S4`
    Map: `R744SREQ`

Squares of summed number of 256 byte increments accumulated for entry data with data elements written to the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""

r744sred : Final[Field] = Field(
    name='r744sred',
    origin='R744SRED',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Sum of 256 byte increments accumulated for entry data with data elements read from the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SRED`
    Record: `SMF74S4`
    Map: `R744SREQ`

Sum of 256 byte increments accumulated for entry data with data elements read from the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""
r744sred.__doc__ = """Sum of 256 byte increments accumulated for entry data with data elements read from the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SRED`
    Record: `SMF74S4`
    Map: `R744SREQ`

Sum of 256 byte increments accumulated for entry data with data elements read from the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""

r744sres : Final[Field] = Field(
    name='r744sres',
    origin='R744SRES',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Squares of summed number of 256 byte increments accumula ted for entry data with data elements read from the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SRES`
    Record: `SMF74S4`
    Map: `R744SREQ`

Squares of summed number of 256 byte increments accumula ted for entry data with data elements read from the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""
r744sres.__doc__ = """Squares of summed number of 256 byte increments accumula ted for entry data with data elements read from the CF structure. (Valid if bit 2 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SRES`
    Record: `SMF74S4`
    Map: `R744SREQ`

Squares of summed number of 256 byte increments accumula ted for entry data with data elements read from the CF structure. (Valid if bit 2 of R744SXFL is set.)
"""

r744smrc : Final[Field] = Field(
    name='r744smrc',
    origin='R744SMRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Number of times a request was found delayed due to coupling facility resource monopolization. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of times a request was found delayed due to coupling facility resource monopolization. (Valid if bit 3 of R744SXFL is set.)
"""
r744smrc.__doc__ = """Number of times a request was found delayed due to coupling facility resource monopolization. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMRC`
    Record: `SMF74S4`
    Map: `R744SREQ`

Number of times a request was found delayed due to coupling facility resource monopolization. (Valid if bit 3 of R744SXFL is set.)
"""

r744smtm : Final[Field] = Field(
    name='r744smtm',
    origin='R744SMTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed queue time (in microseconds) for operations queued due to coupling facility resource monopolization. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed queue time (in microseconds) for operations queued due to coupling facility resource monopolization. (Valid if bit 3 of R744SXFL is set.)
"""
r744smtm.__doc__ = """Summed queue time (in microseconds) for operations queued due to coupling facility resource monopolization. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMTM`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed queue time (in microseconds) for operations queued due to coupling facility resource monopolization. (Valid if bit 3 of R744SXFL is set.)
"""

r744smsq : Final[Field] = Field(
    name='r744smsq',
    origin='R744SMSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Summed queue time squared for operations queued due to coupling facility resource monopolization (in microseconds squared). (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed queue time squared for operations queued due to coupling facility resource monopolization (in microseconds squared). (Valid if bit 3 of R744SXFL is set.)
"""
r744smsq.__doc__ = """Summed queue time squared for operations queued due to coupling facility resource monopolization (in microseconds squared). (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMSQ`
    Record: `SMF74S4`
    Map: `R744SREQ`

Summed queue time squared for operations queued due to coupling facility resource monopolization (in microseconds squared). (Valid if bit 3 of R744SXFL is set.)
"""

r744smto : Final[Field] = Field(
    name='r744smto',
    origin='R744SMTO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Total number of operations queued for CF monopolization avoidance. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMTO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of operations queued for CF monopolization avoidance. (Valid if bit 3 of R744SXFL is set.)
"""
r744smto.__doc__ = """Total number of operations queued for CF monopolization avoidance. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMTO`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of operations queued for CF monopolization avoidance. (Valid if bit 3 of R744SXFL is set.)
"""

r744smht : Final[Field] = Field(
    name='r744smht',
    origin='R744SMHT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744SREQ,
)
"""Total number of high priority operations queued for CF mono polization avoidance. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMHT`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of high priority operations queued for CF mono polization avoidance. (Valid if bit 3 of R744SXFL is set.)
"""
r744smht.__doc__ = """Total number of high priority operations queued for CF mono polization avoidance. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMHT`
    Record: `SMF74S4`
    Map: `R744SREQ`

Total number of high priority operations queued for CF mono polization avoidance. (Valid if bit 3 of R744SXFL is set.)
"""

r744smmn : Final[Field] = Field(
    name='r744smmn',
    origin='R744SMMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Minimum number of operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMMN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)
"""
r744smmn.__doc__ = """Minimum number of operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMMN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)
"""

r744smmx : Final[Field] = Field(
    name='r744smmx',
    origin='R744SMMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Maximum number of operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMMX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)
"""
r744smmx.__doc__ = """Maximum number of operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMMX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)
"""

r744smhn : Final[Field] = Field(
    name='r744smhn',
    origin='R744SMHN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Minimum number of high priority operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMHN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of high priority operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)
"""
r744smhn.__doc__ = """Minimum number of high priority operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMHN`
    Record: `SMF74S4`
    Map: `R744SREQ`

Minimum number of high priority operations queued for CF monopolization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)
"""

r744smhx : Final[Field] = Field(
    name='r744smhx',
    origin='R744SMHX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744SREQ,
)
"""Maximum number of high priority operations queued for CF mono polization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMHX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of high priority operations queued for CF mono polization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)
"""
r744smhx.__doc__ = """Maximum number of high priority operations queued for CF mono polization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)

SMF Info
--------
    Field: `R744SMHX`
    Record: `SMF74S4`
    Map: `R744SREQ`

Maximum number of high priority operations queued for CF mono polization avoidance during this interval. (Valid if bit 3 of R744SXFL is set.)
"""

r744pnum : Final[Field] = Field(
    name='r744pnum',
    origin='R744PNUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744PROC,
)
"""CPU number

SMF Info
--------
    Field: `R744PNUM`
    Record: `SMF74S4`
    Map: `R744PROC`

CPU number
"""
r744pnum.__doc__ = """CPU number

SMF Info
--------
    Field: `R744PNUM`
    Record: `SMF74S4`
    Map: `R744PROC`

CPU number
"""

r744pbsy : Final[Field] = Field(
    name='r744pbsy',
    origin='R744PBSY',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744PROC,
)
"""Busy time in microseconds

SMF Info
--------
    Field: `R744PBSY`
    Record: `SMF74S4`
    Map: `R744PROC`

Busy time in microseconds
"""
r744pbsy.__doc__ = """Busy time in microseconds

SMF Info
--------
    Field: `R744PBSY`
    Record: `SMF74S4`
    Map: `R744PROC`

Busy time in microseconds
"""

r744pwai : Final[Field] = Field(
    name='r744pwai',
    origin='R744PWAI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744PROC,
)
"""Wait time in microseconds

SMF Info
--------
    Field: `R744PWAI`
    Record: `SMF74S4`
    Map: `R744PROC`

Wait time in microseconds
"""
r744pwai.__doc__ = """Wait time in microseconds

SMF Info
--------
    Field: `R744PWAI`
    Record: `SMF74S4`
    Map: `R744PROC`

Wait time in microseconds
"""

r744ptyp : Final[Field] = Field(
    name='r744ptyp',
    origin='R744PTYP',
    type=FieldType.STRING,
    record=record,
    record_map=R744PROC,
)
"""Processor flags

SMF Info
--------
    Field: `R744PTYP`
    Record: `SMF74S4`
    Map: `R744PROC`

Processor flags
"""
r744ptyp.__doc__ = """Processor flags

SMF Info
--------
    Field: `R744PTYP`
    Record: `SMF74S4`
    Map: `R744PROC`

Processor flags
"""

r744ptde : Final[Field] = Field(
    name='r744ptde',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744ptyp,
    record=record,
    record_map=R744PROC,
)
"""Processor is dedicated. Valid if R744FLVL > 14.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744ptyp`(`R744PTYP`)
    Record: `SMF74S4`
    Map: `R744PROC`

Processor is dedicated. Valid if R744FLVL > 14.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744ptde.__doc__ = """Processor is dedicated. Valid if R744FLVL > 14.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744ptyp`(`R744PTYP`)
    Record: `SMF74S4`
    Map: `R744PROC`

Processor is dedicated. Valid if R744FLVL > 14.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744pwgt : Final[Field] = Field(
    name='r744pwgt',
    origin='R744PWGT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744PROC,
)
"""Shared processor weight. Valid if R744FLVL > 14.

SMF Info
--------
    Field: `R744PWGT`
    Record: `SMF74S4`
    Map: `R744PROC`

Shared processor weight. Valid if R744FLVL > 14.
"""
r744pwgt.__doc__ = """Shared processor weight. Valid if R744FLVL > 14.

SMF Info
--------
    Field: `R744PWGT`
    Record: `SMF74S4`
    Map: `R744PROC`

Shared processor weight. Valid if R744FLVL > 14.
"""

r744pbsg : Final[Field] = Field(
    name='r744pbsg',
    origin='R744PBSG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744PROC,
)
"""Assigned buffer summary group. Valid if R744FLVL > 24.

SMF Info
--------
    Field: `R744PBSG`
    Record: `SMF74S4`
    Map: `R744PROC`

Assigned buffer summary group. Valid if R744FLVL > 24.
"""
r744pbsg.__doc__ = """Assigned buffer summary group. Valid if R744FLVL > 24.

SMF Info
--------
    Field: `R744PBSG`
    Record: `SMF74S4`
    Map: `R744PROC`

Assigned buffer summary group. Valid if R744FLVL > 24.
"""

r744pcct : Final[Field] = Field(
    name='r744pcct',
    origin='R744PCCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744PROC,
)
"""Processor command count. Valid if R744FLVL > 24.

SMF Info
--------
    Field: `R744PCCT`
    Record: `SMF74S4`
    Map: `R744PROC`

Processor command count. Valid if R744FLVL > 24.
"""
r744pcct.__doc__ = """Processor command count. Valid if R744FLVL > 24.

SMF Info
--------
    Field: `R744PCCT`
    Record: `SMF74S4`
    Map: `R744PROC`

Processor command count. Valid if R744FLVL > 24.
"""

r744ptle : Final[Field] = Field(
    name='r744ptle',
    origin='R744PTLE',
    type=FieldType.STRING,
    record=record,
    record_map=R744PROC,
)
"""CPU-type topology list entry, as returned by the STSI instruction SYSIB 15.1.2 (Configuration Topology). Refer to Principles of Operation for format. Valid if R744FLVL > 24.

SMF Info
--------
    Field: `R744PTLE`
    Record: `SMF74S4`
    Map: `R744PROC`

CPU-type topology list entry, as returned by the STSI instruction SYSIB 15.1.2 (Configuration Topology). Refer to Principles of Operation for format. Valid if R744FLVL > 24.
"""
r744ptle.__doc__ = """CPU-type topology list entry, as returned by the STSI instruction SYSIB 15.1.2 (Configuration Topology). Refer to Principles of Operation for format. Valid if R744FLVL > 24.

SMF Info
--------
    Field: `R744PTLE`
    Record: `SMF74S4`
    Map: `R744PROC`

CPU-type topology list entry, as returned by the STSI instruction SYSIB 15.1.2 (Configuration Topology). Refer to Principles of Operation for format. Valid if R744FLVL > 24.
"""

r744crhc : Final[Field] = Field(
    name='r744crhc',
    origin='R744CRHC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Read hit Counter long floating point

SMF Info
--------
    Field: `R744CRHC`
    Record: `SMF74S4`
    Map: `R744CACH`

Read hit Counter long floating point
"""
r744crhc.__doc__ = """Read hit Counter long floating point

SMF Info
--------
    Field: `R744CRHC`
    Record: `SMF74S4`
    Map: `R744CACH`

Read hit Counter long floating point
"""

r744crmd : Final[Field] = Field(
    name='r744crmd',
    origin='R744CRMD',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Read miss, directory hit counter long floating point

SMF Info
--------
    Field: `R744CRMD`
    Record: `SMF74S4`
    Map: `R744CACH`

Read miss, directory hit counter long floating point
"""
r744crmd.__doc__ = """Read miss, directory hit counter long floating point

SMF Info
--------
    Field: `R744CRMD`
    Record: `SMF74S4`
    Map: `R744CACH`

Read miss, directory hit counter long floating point
"""

r744crma : Final[Field] = Field(
    name='r744crma',
    origin='R744CRMA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Read miss, assignment suppressed counter long floating point

SMF Info
--------
    Field: `R744CRMA`
    Record: `SMF74S4`
    Map: `R744CACH`

Read miss, assignment suppressed counter long floating point
"""
r744crma.__doc__ = """Read miss, assignment suppressed counter long floating point

SMF Info
--------
    Field: `R744CRMA`
    Record: `SMF74S4`
    Map: `R744CACH`

Read miss, assignment suppressed counter long floating point
"""

r744crmn : Final[Field] = Field(
    name='r744crmn',
    origin='R744CRMN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Read miss, name assigned counter long floating point

SMF Info
--------
    Field: `R744CRMN`
    Record: `SMF74S4`
    Map: `R744CACH`

Read miss, name assigned counter long floating point
"""
r744crmn.__doc__ = """Read miss, name assigned counter long floating point

SMF Info
--------
    Field: `R744CRMN`
    Record: `SMF74S4`
    Map: `R744CACH`

Read miss, name assigned counter long floating point
"""

r744crmt : Final[Field] = Field(
    name='r744crmt',
    origin='R744CRMT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Read miss, target storage class full long floating point

SMF Info
--------
    Field: `R744CRMT`
    Record: `SMF74S4`
    Map: `R744CACH`

Read miss, target storage class full long floating point
"""
r744crmt.__doc__ = """Read miss, target storage class full long floating point

SMF Info
--------
    Field: `R744CRMT`
    Record: `SMF74S4`
    Map: `R744CACH`

Read miss, target storage class full long floating point
"""

r744cwh0 : Final[Field] = Field(
    name='r744cwh0',
    origin='R744CWH0',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Write hit change bit 0 CTR long floating point

SMF Info
--------
    Field: `R744CWH0`
    Record: `SMF74S4`
    Map: `R744CACH`

Write hit change bit 0 CTR long floating point
"""
r744cwh0.__doc__ = """Write hit change bit 0 CTR long floating point

SMF Info
--------
    Field: `R744CWH0`
    Record: `SMF74S4`
    Map: `R744CACH`

Write hit change bit 0 CTR long floating point
"""

r744cwh1 : Final[Field] = Field(
    name='r744cwh1',
    origin='R744CWH1',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Write hit change bit 1 CTR long floating point

SMF Info
--------
    Field: `R744CWH1`
    Record: `SMF74S4`
    Map: `R744CACH`

Write hit change bit 1 CTR long floating point
"""
r744cwh1.__doc__ = """Write hit change bit 1 CTR long floating point

SMF Info
--------
    Field: `R744CWH1`
    Record: `SMF74S4`
    Map: `R744CACH`

Write hit change bit 1 CTR long floating point
"""

r744cwmn : Final[Field] = Field(
    name='r744cwmn',
    origin='R744CWMN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Write miss not registered counter long floating point

SMF Info
--------
    Field: `R744CWMN`
    Record: `SMF74S4`
    Map: `R744CACH`

Write miss not registered counter long floating point
"""
r744cwmn.__doc__ = """Write miss not registered counter long floating point

SMF Info
--------
    Field: `R744CWMN`
    Record: `SMF74S4`
    Map: `R744CACH`

Write miss not registered counter long floating point
"""

r744cwmi : Final[Field] = Field(
    name='r744cwmi',
    origin='R744CWMI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Write miss invalid state counter long floating point

SMF Info
--------
    Field: `R744CWMI`
    Record: `SMF74S4`
    Map: `R744CACH`

Write miss invalid state counter long floating point
"""
r744cwmi.__doc__ = """Write miss invalid state counter long floating point

SMF Info
--------
    Field: `R744CWMI`
    Record: `SMF74S4`
    Map: `R744CACH`

Write miss invalid state counter long floating point
"""

r744cwmt : Final[Field] = Field(
    name='r744cwmt',
    origin='R744CWMT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Write miss storage class full counter long floating point

SMF Info
--------
    Field: `R744CWMT`
    Record: `SMF74S4`
    Map: `R744CACH`

Write miss storage class full counter long floating point
"""
r744cwmt.__doc__ = """Write miss storage class full counter long floating point

SMF Info
--------
    Field: `R744CWMT`
    Record: `SMF74S4`
    Map: `R744CACH`

Write miss storage class full counter long floating point
"""

r744cder : Final[Field] = Field(
    name='r744cder',
    origin='R744CDER',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Directory entry reclaim counter long floating point

SMF Info
--------
    Field: `R744CDER`
    Record: `SMF74S4`
    Map: `R744CACH`

Directory entry reclaim counter long floating point
"""
r744cder.__doc__ = """Directory entry reclaim counter long floating point

SMF Info
--------
    Field: `R744CDER`
    Record: `SMF74S4`
    Map: `R744CACH`

Directory entry reclaim counter long floating point
"""

r744cdtr : Final[Field] = Field(
    name='r744cdtr',
    origin='R744CDTR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Data entry reclaim counter long floating point

SMF Info
--------
    Field: `R744CDTR`
    Record: `SMF74S4`
    Map: `R744CACH`

Data entry reclaim counter long floating point
"""
r744cdtr.__doc__ = """Data entry reclaim counter long floating point

SMF Info
--------
    Field: `R744CDTR`
    Record: `SMF74S4`
    Map: `R744CACH`

Data entry reclaim counter long floating point
"""

r744cxdr : Final[Field] = Field(
    name='r744cxdr',
    origin='R744CXDR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""XI directory reclaim counter long floating point

SMF Info
--------
    Field: `R744CXDR`
    Record: `SMF74S4`
    Map: `R744CACH`

XI directory reclaim counter long floating point
"""
r744cxdr.__doc__ = """XI directory reclaim counter long floating point

SMF Info
--------
    Field: `R744CXDR`
    Record: `SMF74S4`
    Map: `R744CACH`

XI directory reclaim counter long floating point
"""

r744cxfw : Final[Field] = Field(
    name='r744cxfw',
    origin='R744CXFW',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""XI write counter long floating point

SMF Info
--------
    Field: `R744CXFW`
    Record: `SMF74S4`
    Map: `R744CACH`

XI write counter long floating point
"""
r744cxfw.__doc__ = """XI write counter long floating point

SMF Info
--------
    Field: `R744CXFW`
    Record: `SMF74S4`
    Map: `R744CACH`

XI write counter long floating point
"""

r744cxni : Final[Field] = Field(
    name='r744cxni',
    origin='R744CXNI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""XI name invalidation counter long floating point

SMF Info
--------
    Field: `R744CXNI`
    Record: `SMF74S4`
    Map: `R744CACH`

XI name invalidation counter long floating point
"""
r744cxni.__doc__ = """XI name invalidation counter long floating point

SMF Info
--------
    Field: `R744CXNI`
    Record: `SMF74S4`
    Map: `R744CACH`

XI name invalidation counter long floating point
"""

r744cxci : Final[Field] = Field(
    name='r744cxci',
    origin='R744CXCI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""XI complement invalidation counter long floating point

SMF Info
--------
    Field: `R744CXCI`
    Record: `SMF74S4`
    Map: `R744CACH`

XI complement invalidation counter long floating point
"""
r744cxci.__doc__ = """XI complement invalidation counter long floating point

SMF Info
--------
    Field: `R744CXCI`
    Record: `SMF74S4`
    Map: `R744CACH`

XI complement invalidation counter long floating point
"""

r744ccoc : Final[Field] = Field(
    name='r744ccoc',
    origin='R744CCOC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Castout Counter long floating point

SMF Info
--------
    Field: `R744CCOC`
    Record: `SMF74S4`
    Map: `R744CACH`

Castout Counter long floating point
"""
r744ccoc.__doc__ = """Castout Counter long floating point

SMF Info
--------
    Field: `R744CCOC`
    Record: `SMF74S4`
    Map: `R744CACH`

Castout Counter long floating point
"""

r744crsm : Final[Field] = Field(
    name='r744crsm',
    origin='R744CRSM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Reference signal miss counter long floating point

SMF Info
--------
    Field: `R744CRSM`
    Record: `SMF74S4`
    Map: `R744CACH`

Reference signal miss counter long floating point
"""
r744crsm.__doc__ = """Reference signal miss counter long floating point

SMF Info
--------
    Field: `R744CRSM`
    Record: `SMF74S4`
    Map: `R744CACH`

Reference signal miss counter long floating point
"""

r744ctsf : Final[Field] = Field(
    name='r744ctsf',
    origin='R744CTSF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Target storage class full counter long floating point

SMF Info
--------
    Field: `R744CTSF`
    Record: `SMF74S4`
    Map: `R744CACH`

Target storage class full counter long floating point
"""
r744ctsf.__doc__ = """Target storage class full counter long floating point

SMF Info
--------
    Field: `R744CTSF`
    Record: `SMF74S4`
    Map: `R744CACH`

Target storage class full counter long floating point
"""

r744cdec : Final[Field] = Field(
    name='r744cdec',
    origin='R744CDEC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CACH,
)
"""Directory entry counter snapshot

SMF Info
--------
    Field: `R744CDEC`
    Record: `SMF74S4`
    Map: `R744CACH`

Directory entry counter snapshot
"""
r744cdec.__doc__ = """Directory entry counter snapshot

SMF Info
--------
    Field: `R744CDEC`
    Record: `SMF74S4`
    Map: `R744CACH`

Directory entry counter snapshot
"""

r744cdac : Final[Field] = Field(
    name='r744cdac',
    origin='R744CDAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CACH,
)
"""Data element counter snapshot

SMF Info
--------
    Field: `R744CDAC`
    Record: `SMF74S4`
    Map: `R744CACH`

Data element counter snapshot
"""
r744cdac.__doc__ = """Data element counter snapshot

SMF Info
--------
    Field: `R744CDAC`
    Record: `SMF74S4`
    Map: `R744CACH`

Data element counter snapshot
"""

r744ctcc : Final[Field] = Field(
    name='r744ctcc',
    origin='R744CTCC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CACH,
)
"""Total changed counter

SMF Info
--------
    Field: `R744CTCC`
    Record: `SMF74S4`
    Map: `R744CACH`

Total changed counter
"""
r744ctcc.__doc__ = """Total changed counter

SMF Info
--------
    Field: `R744CTCC`
    Record: `SMF74S4`
    Map: `R744CACH`

Total changed counter
"""

r744cdta : Final[Field] = Field(
    name='r744cdta',
    origin='R744CDTA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CACH,
)
"""Data area counter

SMF Info
--------
    Field: `R744CDTA`
    Record: `SMF74S4`
    Map: `R744CACH`

Data area counter
"""
r744cdta.__doc__ = """Data area counter

SMF Info
--------
    Field: `R744CDTA`
    Record: `SMF74S4`
    Map: `R744CACH`

Data area counter
"""

r744crlc : Final[Field] = Field(
    name='r744crlc',
    origin='R744CRLC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Completed reference list counter long floating point

SMF Info
--------
    Field: `R744CRLC`
    Record: `SMF74S4`
    Map: `R744CACH`

Completed reference list counter long floating point
"""
r744crlc.__doc__ = """Completed reference list counter long floating point

SMF Info
--------
    Field: `R744CRLC`
    Record: `SMF74S4`
    Map: `R744CACH`

Completed reference list counter long floating point
"""

r744cprl : Final[Field] = Field(
    name='r744cprl',
    origin='R744CPRL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""partially completed reference list counter long floating point

SMF Info
--------
    Field: `R744CPRL`
    Record: `SMF74S4`
    Map: `R744CACH`

partially completed reference list counter long floating point
"""
r744cprl.__doc__ = """partially completed reference list counter long floating point

SMF Info
--------
    Field: `R744CPRL`
    Record: `SMF74S4`
    Map: `R744CACH`

partially completed reference list counter long floating point
"""

r744cxrl : Final[Field] = Field(
    name='r744cxrl',
    origin='R744CXRL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""XI for local cache vector index replacement long floating point

SMF Info
--------
    Field: `R744CXRL`
    Record: `SMF74S4`
    Map: `R744CACH`

XI for local cache vector index replacement long floating point
"""
r744cxrl.__doc__ = """XI for local cache vector index replacement long floating point

SMF Info
--------
    Field: `R744CXRL`
    Record: `SMF74S4`
    Map: `R744CACH`

XI for local cache vector index replacement long floating point
"""

r744cwuc : Final[Field] = Field(
    name='r744cwuc',
    origin='R744CWUC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R744CACH,
)
"""Write unchanged counter long floating point

SMF Info
--------
    Field: `R744CWUC`
    Record: `SMF74S4`
    Map: `R744CACH`

Write unchanged counter long floating point
"""
r744cwuc.__doc__ = """Write unchanged counter long floating point

SMF Info
--------
    Field: `R744CWUC`
    Record: `SMF74S4`
    Map: `R744CACH`

Write unchanged counter long floating point
"""

r744rsys : Final[Field] = Field(
    name='r744rsys',
    origin='R744RSYS',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""System identification value for the remotely connected CF

SMF Info
--------
    Field: `R744RSYS`
    Record: `SMF74S4`
    Map: `R744CFRF`

System identification value for the remotely connected CF
"""
r744rsys.__doc__ = """System identification value for the remotely connected CF

SMF Info
--------
    Field: `R744RSYS`
    Record: `SMF74S4`
    Map: `R744CFRF`

System identification value for the remotely connected CF
"""

r744rnam : Final[Field] = Field(
    name='r744rnam',
    origin='R744RNAM',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""CF name (if applicable, else X'0')

SMF Info
--------
    Field: `R744RNAM`
    Record: `SMF74S4`
    Map: `R744CFRF`

CF name (if applicable, else X'0')
"""
r744rnam.__doc__ = """CF name (if applicable, else X'0')

SMF Info
--------
    Field: `R744RNAM`
    Record: `SMF74S4`
    Map: `R744CFRF`

CF name (if applicable, else X'0')
"""

r744rpgs : Final[Field] = Field(
    name='r744rpgs',
    origin='R744RPGS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Receiver path group size

SMF Info
--------
    Field: `R744RPGS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Receiver path group size
"""
r744rpgs.__doc__ = """Receiver path group size

SMF Info
--------
    Field: `R744RPGS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Receiver path group size
"""

r744rflg : Final[Field] = Field(
    name='r744rflg',
    origin='R744RFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""Status Flags

SMF Info
--------
    Field: `R744RFLG`
    Record: `SMF74S4`
    Map: `R744CFRF`

Status Flags
"""
r744rflg.__doc__ = """Status Flags

SMF Info
--------
    Field: `R744RFLG`
    Record: `SMF74S4`
    Map: `R744CFRF`

Status Flags
"""

r744rcei : Final[Field] = Field(
    name='r744rcei',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744rflg,
    record=record,
    record_map=R744CFRF,
)
"""CFRF was connected to the system at the end of the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744rflg`(`R744RFLG`)
    Record: `SMF74S4`
    Map: `R744CFRF`

CFRF was connected to the system at the end of the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744rcei.__doc__ = """CFRF was connected to the system at the end of the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744rflg`(`R744RFLG`)
    Record: `SMF74S4`
    Map: `R744CFRF`

CFRF was connected to the system at the end of the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744radi : Final[Field] = Field(
    name='r744radi',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r744rflg,
    record=record,
    record_map=R744CFRF,
)
"""Structure became active during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744rflg`(`R744RFLG`)
    Record: `SMF74S4`
    Map: `R744CFRF`

Structure became active during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r744radi.__doc__ = """Structure became active during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744rflg`(`R744RFLG`)
    Record: `SMF74S4`
    Map: `R744CFRF`

Structure became active during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r744rres : Final[Field] = Field(
    name='r744rres',
    origin='R744RRES',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Ready to execute signal counter

SMF Info
--------
    Field: `R744RRES`
    Record: `SMF74S4`
    Map: `R744CFRF`

Ready to execute signal counter
"""
r744rres.__doc__ = """Ready to execute signal counter

SMF Info
--------
    Field: `R744RRES`
    Record: `SMF74S4`
    Map: `R744CFRF`

Ready to execute signal counter
"""

r744rrcs : Final[Field] = Field(
    name='r744rrcs',
    origin='R744RRCS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Ready to complete signal counter

SMF Info
--------
    Field: `R744RRCS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Ready to complete signal counter
"""
r744rrcs.__doc__ = """Ready to complete signal counter

SMF Info
--------
    Field: `R744RRCS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Ready to complete signal counter
"""

r744rhes : Final[Field] = Field(
    name='r744rhes',
    origin='R744RHES',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Halt execution signal counter

SMF Info
--------
    Field: `R744RHES`
    Record: `SMF74S4`
    Map: `R744CFRF`

Halt execution signal counter
"""
r744rhes.__doc__ = """Halt execution signal counter

SMF Info
--------
    Field: `R744RHES`
    Record: `SMF74S4`
    Map: `R744CFRF`

Halt execution signal counter
"""

r744rrss : Final[Field] = Field(
    name='r744rrss',
    origin='R744RRSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Request for suppression signal counter

SMF Info
--------
    Field: `R744RRSS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Request for suppression signal counter
"""
r744rrss.__doc__ = """Request for suppression signal counter

SMF Info
--------
    Field: `R744RRSS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Request for suppression signal counter
"""

r744rrsa : Final[Field] = Field(
    name='r744rrsa',
    origin='R744RRSA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Request for suppression accepted signal counter

SMF Info
--------
    Field: `R744RRSA`
    Record: `SMF74S4`
    Map: `R744CFRF`

Request for suppression accepted signal counter
"""
r744rrsa.__doc__ = """Request for suppression accepted signal counter

SMF Info
--------
    Field: `R744RRSA`
    Record: `SMF74S4`
    Map: `R744CFRF`

Request for suppression accepted signal counter
"""

r744rsst : Final[Field] = Field(
    name='r744rsst',
    origin='R744RSST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Unused. Value now in R744RSSE

SMF Info
--------
    Field: `R744RSST`
    Record: `SMF74S4`
    Map: `R744CFRF`

Unused. Value now in R744RSSE
"""
r744rsst.__doc__ = """Unused. Value now in R744RSSE

SMF Info
--------
    Field: `R744RSST`
    Record: `SMF74S4`
    Map: `R744CFRF`

Unused. Value now in R744RSSE
"""

r744rsss : Final[Field] = Field(
    name='r744rsss',
    origin='R744RSSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Sum of squares of signal service times

SMF Info
--------
    Field: `R744RSSS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sum of squares of signal service times
"""
r744rsss.__doc__ = """Sum of squares of signal service times

SMF Info
--------
    Field: `R744RSSS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sum of squares of signal service times
"""

r744rdsc : Final[Field] = Field(
    name='r744rdsc',
    origin='R744RDSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Delayed signal counter

SMF Info
--------
    Field: `R744RDSC`
    Record: `SMF74S4`
    Map: `R744CFRF`

Delayed signal counter
"""
r744rdsc.__doc__ = """Delayed signal counter

SMF Info
--------
    Field: `R744RDSC`
    Record: `SMF74S4`
    Map: `R744CFRF`

Delayed signal counter
"""

r744rsdt : Final[Field] = Field(
    name='r744rsdt',
    origin='R744RSDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Sum of signal delay times

SMF Info
--------
    Field: `R744RSDT`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sum of signal delay times
"""
r744rsdt.__doc__ = """Sum of signal delay times

SMF Info
--------
    Field: `R744RSDT`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sum of signal delay times
"""

r744rssd : Final[Field] = Field(
    name='r744rssd',
    origin='R744RSSD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Sum of squares of signal times

SMF Info
--------
    Field: `R744RSSD`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sum of squares of signal times
"""
r744rssd.__doc__ = """Sum of squares of signal times

SMF Info
--------
    Field: `R744RSSD`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sum of squares of signal times
"""

r744rsrs : Final[Field] = Field(
    name='r744rsrs',
    origin='R744RSRS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Signal redrives signal counter

SMF Info
--------
    Field: `R744RSRS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Signal redrives signal counter
"""
r744rsrs.__doc__ = """Signal redrives signal counter

SMF Info
--------
    Field: `R744RSRS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Signal redrives signal counter
"""

r744rsse : Final[Field] = Field(
    name='r744rsse',
    origin='R744RSSE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Sum of signal service times

SMF Info
--------
    Field: `R744RSSE`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sum of signal service times
"""
r744rsse.__doc__ = """Sum of signal service times

SMF Info
--------
    Field: `R744RSSE`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sum of signal service times
"""

r744rcpi : Final[Field] = Field(
    name='r744rcpi',
    origin='R744RCPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Index to first channel path data section associated with this coupling facility.

SMF Info
--------
    Field: `R744RCPI`
    Record: `SMF74S4`
    Map: `R744CFRF`

Index to first channel path data section associated with this coupling facility.
"""
r744rcpi.__doc__ = """Index to first channel path data section associated with this coupling facility.

SMF Info
--------
    Field: `R744RCPI`
    Record: `SMF74S4`
    Map: `R744CFRF`

Index to first channel path data section associated with this coupling facility.
"""

r744rcpn : Final[Field] = Field(
    name='r744rcpn',
    origin='R744RCPN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Number of channel path data sections for channel paths of type 'CIB', 'CFP', 'CS5' or 'CL5' connected to this remote coupling facility. This includes the receiver/peer channel path over which signals may be sent from the subject CF to this remote CF and the sender/peer channel paths returning signals from this remote CF to the subject CF. This count matches the number of subsequent channel path data sections associated with this remote CF.

SMF Info
--------
    Field: `R744RCPN`
    Record: `SMF74S4`
    Map: `R744CFRF`

Number of channel path data sections for channel paths of type 'CIB', 'CFP', 'CS5' or 'CL5' connected to this remote coupling facility. This includes the receiver/peer channel path over which signals may be sent from the subject CF to this remote CF and the sender/peer channel paths returning signals from this remote CF to the subject CF. This count matches the number of subsequent channel path data sections associated with this remote CF.
"""
r744rcpn.__doc__ = """Number of channel path data sections for channel paths of type 'CIB', 'CFP', 'CS5' or 'CL5' connected to this remote coupling facility. This includes the receiver/peer channel path over which signals may be sent from the subject CF to this remote CF and the sender/peer channel paths returning signals from this remote CF to the subject CF. This count matches the number of subsequent channel path data sections associated with this remote CF.

SMF Info
--------
    Field: `R744RCPN`
    Record: `SMF74S4`
    Map: `R744CFRF`

Number of channel path data sections for channel paths of type 'CIB', 'CFP', 'CS5' or 'CL5' connected to this remote coupling facility. This includes the receiver/peer channel path over which signals may be sent from the subject CF to this remote CF and the sender/peer channel paths returning signals from this remote CF to the subject CF. This count matches the number of subsequent channel path data sections associated with this remote CF.
"""

r744rsgs : Final[Field] = Field(
    name='r744rsgs',
    origin='R744RSGS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Sender path group size

SMF Info
--------
    Field: `R744RSGS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sender path group size
"""
r744rsgs.__doc__ = """Sender path group size

SMF Info
--------
    Field: `R744RSGS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Sender path group size
"""

r744rsc : Final[Field] = Field(
    name='r744rsc',
    origin='R744RSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Number of subchannels associated with the remote CF.

SMF Info
--------
    Field: `R744RSC`
    Record: `SMF74S4`
    Map: `R744CFRF`

Number of subchannels associated with the remote CF.
"""
r744rsc.__doc__ = """Number of subchannels associated with the remote CF.

SMF Info
--------
    Field: `R744RSC`
    Record: `SMF74S4`
    Map: `R744CFRF`

Number of subchannels associated with the remote CF.
"""

r744ramc : Final[Field] = Field(
    name='r744ramc',
    origin='R744RAMC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Number of asynchronous messages that are sent to this remote facility. The count includes the number of asynchronous commands that sent and excludes path management commands and redrives of asynchronous commands.

SMF Info
--------
    Field: `R744RAMC`
    Record: `SMF74S4`
    Map: `R744CFRF`

Number of asynchronous messages that are sent to this remote facility. The count includes the number of asynchronous commands that sent and excludes path management commands and redrives of asynchronous commands.
"""
r744ramc.__doc__ = """Number of asynchronous messages that are sent to this remote facility. The count includes the number of asynchronous commands that sent and excludes path management commands and redrives of asynchronous commands.

SMF Info
--------
    Field: `R744RAMC`
    Record: `SMF74S4`
    Map: `R744CFRF`

Number of asynchronous messages that are sent to this remote facility. The count includes the number of asynchronous commands that sent and excludes path management commands and redrives of asynchronous commands.
"""

r744ramst : Final[Field] = Field(
    name='r744ramst',
    origin='R744RAMST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Total amount of service time for asynchronous messages sent to this remote CF, in micro seconds.

SMF Info
--------
    Field: `R744RAMST`
    Record: `SMF74S4`
    Map: `R744CFRF`

Total amount of service time for asynchronous messages sent to this remote CF, in micro seconds.
"""
r744ramst.__doc__ = """Total amount of service time for asynchronous messages sent to this remote CF, in micro seconds.

SMF Info
--------
    Field: `R744RAMST`
    Record: `SMF74S4`
    Map: `R744CFRF`

Total amount of service time for asynchronous messages sent to this remote CF, in micro seconds.
"""

r744ramsq : Final[Field] = Field(
    name='r744ramsq',
    origin='R744RAMSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Total amount of squares of service time for asynchronous messages sent to this remote CF, in square of microseconds.

SMF Info
--------
    Field: `R744RAMSQ`
    Record: `SMF74S4`
    Map: `R744CFRF`

Total amount of squares of service time for asynchronous messages sent to this remote CF, in square of microseconds.
"""
r744ramsq.__doc__ = """Total amount of squares of service time for asynchronous messages sent to this remote CF, in square of microseconds.

SMF Info
--------
    Field: `R744RAMSQ`
    Record: `SMF74S4`
    Map: `R744CFRF`

Total amount of squares of service time for asynchronous messages sent to this remote CF, in square of microseconds.
"""

r744rampb : Final[Field] = Field(
    name='r744rampb',
    origin='R744RAMPB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Asynchronous message path busy count.

SMF Info
--------
    Field: `R744RAMPB`
    Record: `SMF74S4`
    Map: `R744CFRF`

Asynchronous message path busy count.
"""
r744rampb.__doc__ = """Asynchronous message path busy count.

SMF Info
--------
    Field: `R744RAMPB`
    Record: `SMF74S4`
    Map: `R744CFRF`

Asynchronous message path busy count.
"""

r744ramns : Final[Field] = Field(
    name='r744ramns',
    origin='R744RAMNS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Asynchronous message no subchannel count.

SMF Info
--------
    Field: `R744RAMNS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Asynchronous message no subchannel count.
"""
r744ramns.__doc__ = """Asynchronous message no subchannel count.

SMF Info
--------
    Field: `R744RAMNS`
    Record: `SMF74S4`
    Map: `R744CFRF`

Asynchronous message no subchannel count.
"""

ndebyte1 : Final[Field] = Field(
    name='ndebyte1',
    origin='NDEBYTE1',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""Word 0 Byte 1

SMF Info
--------
    Field: `NDEBYTE1`
    Record: `SMF74S4`
    Map: `R744CFRF`

Word 0 Byte 1
"""
ndebyte1.__doc__ = """Word 0 Byte 1

SMF Info
--------
    Field: `NDEBYTE1`
    Record: `SMF74S4`
    Map: `R744CFRF`

Word 0 Byte 1
"""

ndeconfigcode : Final[Field] = Field(
    name='ndeconfigcode',
    origin='NDECONFIGCODE',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""Configuration code. Bits 0-3. B'0000' indicates side 0, B'0001' indicates side 1. If not partitioned, the value will be B'0000'

SMF Info
--------
    Field: `NDECONFIGCODE`
    Record: `SMF74S4`
    Map: `R744CFRF`

Configuration code. Bits 0-3. B'0000' indicates side 0, B'0001' indicates side 1. If not partitioned, the value will be B'0000'
"""
ndeconfigcode.__doc__ = """Configuration code. Bits 0-3. B'0000' indicates side 0, B'0001' indicates side 1. If not partitioned, the value will be B'0000'

SMF Info
--------
    Field: `NDECONFIGCODE`
    Record: `SMF74S4`
    Map: `R744CFRF`

Configuration code. Bits 0-3. B'0000' indicates side 0, B'0001' indicates side 1. If not partitioned, the value will be B'0000'
"""

ndeppmode : Final[Field] = Field(
    name='ndeppmode',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=ndeconfigcode,
    record=record,
    record_map=R744CFRF,
)
"""PP/SI mode indicator. 0 = processor is in single-image (SI) mode, 1 = processor is in physically partitioned (PP) mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ndeconfigcode`(`NDECONFIGCODE`)
    Record: `SMF74S4`
    Map: `R744CFRF`

PP/SI mode indicator. 0 = processor is in single-image (SI) mode, 1 = processor is in physically partitioned (PP) mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ndeppmode.__doc__ = """PP/SI mode indicator. 0 = processor is in single-image (SI) mode, 1 = processor is in physically partitioned (PP) mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ndeconfigcode`(`NDECONFIGCODE`)
    Record: `SMF74S4`
    Map: `R744CFRF`

PP/SI mode indicator. 0 = processor is in single-image (SI) mode, 1 = processor is in physically partitioned (PP) mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ndepartition : Final[Field] = Field(
    name='ndepartition',
    origin='NDEPARTITION',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""LPAR Partition Number

SMF Info
--------
    Field: `NDEPARTITION`
    Record: `SMF74S4`
    Map: `R744CFRF`

LPAR Partition Number
"""
ndepartition.__doc__ = """LPAR Partition Number

SMF Info
--------
    Field: `NDEPARTITION`
    Record: `SMF74S4`
    Map: `R744CFRF`

LPAR Partition Number
"""

ndetype : Final[Field] = Field(
    name='ndetype',
    origin='NDETYPE',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""EBCDIC node type

SMF Info
--------
    Field: `NDETYPE`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC node type
"""
ndetype.__doc__ = """EBCDIC node type

SMF Info
--------
    Field: `NDETYPE`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC node type
"""

ndemodel : Final[Field] = Field(
    name='ndemodel',
    origin='NDEMODEL',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""EBCDIC model number - this number is not guaranteed to be the current model number.

SMF Info
--------
    Field: `NDEMODEL`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC model number - this number is not guaranteed to be the current model number.
"""
ndemodel.__doc__ = """EBCDIC model number - this number is not guaranteed to be the current model number.

SMF Info
--------
    Field: `NDEMODEL`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC model number - this number is not guaranteed to be the current model number.
"""

ndemfg : Final[Field] = Field(
    name='ndemfg',
    origin='NDEMFG',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""EBCDIC node manufacturer

SMF Info
--------
    Field: `NDEMFG`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC node manufacturer
"""
ndemfg.__doc__ = """EBCDIC node manufacturer

SMF Info
--------
    Field: `NDEMFG`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC node manufacturer
"""

ndeplant : Final[Field] = Field(
    name='ndeplant',
    origin='NDEPLANT',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""EBCDIC manufacturer plant ID

SMF Info
--------
    Field: `NDEPLANT`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC manufacturer plant ID
"""
ndeplant.__doc__ = """EBCDIC manufacturer plant ID

SMF Info
--------
    Field: `NDEPLANT`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC manufacturer plant ID
"""

ndesequence : Final[Field] = Field(
    name='ndesequence',
    origin='NDESEQUENCE',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""EBCDIC sequence number

SMF Info
--------
    Field: `NDESEQUENCE`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC sequence number
"""
ndesequence.__doc__ = """EBCDIC sequence number

SMF Info
--------
    Field: `NDESEQUENCE`
    Record: `SMF74S4`
    Map: `R744CFRF`

EBCDIC sequence number
"""

ndetag : Final[Field] = Field(
    name='ndetag',
    origin='NDETAG',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
)
"""Tag field

SMF Info
--------
    Field: `NDETAG`
    Record: `SMF74S4`
    Map: `R744CFRF`

Tag field
"""
ndetag.__doc__ = """Tag field

SMF Info
--------
    Field: `NDETAG`
    Record: `SMF74S4`
    Map: `R744CFRF`

Tag field
"""

ndecpcid : Final[Field] = Field(
    name='ndecpcid',
    origin='NDECPCID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CFRF,
)
"""Central Processor Complex (CPC) identifier

SMF Info
--------
    Field: `NDECPCID`
    Record: `SMF74S4`
    Map: `R744CFRF`

Central Processor Complex (CPC) identifier
"""
ndecpcid.__doc__ = """Central Processor Complex (CPC) identifier

SMF Info
--------
    Field: `NDECPCID`
    Record: `SMF74S4`
    Map: `R744CFRF`

Central Processor Complex (CPC) identifier
"""

r744rtap : Final[Field] = Field(
    name='r744rtap',
    origin='R744RTAP',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 8,
)
"""CHPID array for channel path type acronyms. A CHPID type is provided for each active re- ceiver message path in the path group. The number of valid entries is equal to the receiver path group size.

SMF Info
--------
    Field: `R744RTAP`
    Record: `SMF74S4`
    Map: `R744CFRF`

CHPID array for channel path type acronyms. A CHPID type is provided for each active re- ceiver message path in the path group. The number of valid entries is equal to the receiver path group size.
"""
r744rtap.__doc__ = """CHPID array for channel path type acronyms. A CHPID type is provided for each active re- ceiver message path in the path group. The number of valid entries is equal to the receiver path group size.

SMF Info
--------
    Field: `R744RTAP`
    Record: `SMF74S4`
    Map: `R744CFRF`

CHPID array for channel path type acronyms. A CHPID type is provided for each active re- ceiver message path in the path group. The number of valid entries is equal to the receiver path group size.
"""

r744ridp : Final[Field] = Field(
    name='r744ridp',
    origin='R744RIDP',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 8,
)
"""Array for receiver/peer channel path IDs.

SMF Info
--------
    Field: `R744RIDP`
    Record: `SMF74S4`
    Map: `R744CFRF`

Array for receiver/peer channel path IDs.
"""
r744ridp.__doc__ = """Array for receiver/peer channel path IDs.

SMF Info
--------
    Field: `R744RIDP`
    Record: `SMF74S4`
    Map: `R744CFRF`

Array for receiver/peer channel path IDs.
"""

r744rsap : Final[Field] = Field(
    name='r744rsap',
    origin='R744RSAP',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 8,
)
"""CHPID array for channel path type acronyms. A CHPID type is provided for each active sender /peer message path in the path group. The number of valid entries is equal to the sender path group size.

SMF Info
--------
    Field: `R744RSAP`
    Record: `SMF74S4`
    Map: `R744CFRF`

CHPID array for channel path type acronyms. A CHPID type is provided for each active sender /peer message path in the path group. The number of valid entries is equal to the sender path group size.
"""
r744rsap.__doc__ = """CHPID array for channel path type acronyms. A CHPID type is provided for each active sender /peer message path in the path group. The number of valid entries is equal to the sender path group size.

SMF Info
--------
    Field: `R744RSAP`
    Record: `SMF74S4`
    Map: `R744CFRF`

CHPID array for channel path type acronyms. A CHPID type is provided for each active sender /peer message path in the path group. The number of valid entries is equal to the sender path group size.
"""

r744rsid : Final[Field] = Field(
    name='r744rsid',
    origin='R744RSID',
    type=FieldType.STRING,
    record=record,
    record_map=R744CFRF,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 8,
)
"""Array of sender/peer channel path IDs.

SMF Info
--------
    Field: `R744RSID`
    Record: `SMF74S4`
    Map: `R744CFRF`

Array of sender/peer channel path IDs.
"""
r744rsid.__doc__ = """Array of sender/peer channel path IDs.

SMF Info
--------
    Field: `R744RSID`
    Record: `SMF74S4`
    Map: `R744CFRF`

Array of sender/peer channel path IDs.
"""

r744hcpi : Final[Field] = Field(
    name='r744hcpi',
    origin='R744HCPI',
    type=FieldType.STRING,
    record=record,
    record_map=R744CHPA,
)
"""Channel path identifier. The range of values is x'00' to x'FF'.

SMF Info
--------
    Field: `R744HCPI`
    Record: `SMF74S4`
    Map: `R744CHPA`

Channel path identifier. The range of values is x'00' to x'FF'.
"""
r744hcpi.__doc__ = """Channel path identifier. The range of values is x'00' to x'FF'.

SMF Info
--------
    Field: `R744HCPI`
    Record: `SMF74S4`
    Map: `R744CHPA`

Channel path identifier. The range of values is x'00' to x'FF'.
"""

r744htap : Final[Field] = Field(
    name='r744htap',
    origin='R744HTAP',
    type=FieldType.STRING,
    record=record,
    record_map=R744CHPA,
)
"""Channel path type acronym

SMF Info
--------
    Field: `R744HTAP`
    Record: `SMF74S4`
    Map: `R744CHPA`

Channel path type acronym
"""
r744htap.__doc__ = """Channel path type acronym

SMF Info
--------
    Field: `R744HTAP`
    Record: `SMF74S4`
    Map: `R744CHPA`

Channel path type acronym
"""

r744hfl1 : Final[Field] = Field(
    name='r744hfl1',
    origin='R744HFL1',
    type=FieldType.STRING,
    record=record,
    record_map=R744CHPA,
)
"""Validity flag 1

SMF Info
--------
    Field: `R744HFL1`
    Record: `SMF74S4`
    Map: `R744CHPA`

Validity flag 1
"""
r744hfl1.__doc__ = """Validity flag 1

SMF Info
--------
    Field: `R744HFL1`
    Record: `SMF74S4`
    Map: `R744CHPA`

Validity flag 1
"""

r744hhca : Final[Field] = Field(
    name='r744hhca',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744hfl1,
    record=record,
    record_map=R744CHPA,
)
"""If set, coupling adapter ID and port number are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl1`(`R744HFL1`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, coupling adapter ID and port number are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744hhca.__doc__ = """If set, coupling adapter ID and port number are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl1`(`R744HFL1`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, coupling adapter ID and port number are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744hmov : Final[Field] = Field(
    name='r744hmov',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r744hfl1,
    record=record,
    record_map=R744CHPA,
)
"""If set, channel path operation mode is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl1`(`R744HFL1`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, channel path operation mode is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r744hmov.__doc__ = """If set, channel path operation mode is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl1`(`R744HFL1`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, channel path operation mode is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r744hlav : Final[Field] = Field(
    name='r744hlav',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r744hfl1,
    record=record,
    record_map=R744CHPA,
)
"""If set, latency is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl1`(`R744HFL1`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, latency is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r744hlav.__doc__ = """If set, latency is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl1`(`R744HFL1`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, latency is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r744hdev : Final[Field] = Field(
    name='r744hdev',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r744hfl1,
    record=record,
    record_map=R744CHPA,
)
"""If set, degraded flag is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl1`(`R744HFL1`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, degraded flag is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r744hdev.__doc__ = """If set, degraded flag is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl1`(`R744HFL1`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, degraded flag is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r744hsav : Final[Field] = Field(
    name='r744hsav',
    origin='R744HSAV',
    type=FieldType.STRING,
    record=record,
    record_map=R744CHPA,
)
"""If set, corresponding field of I/O processors is valid

SMF Info
--------
    Field: `R744HSAV`
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, corresponding field of I/O processors is valid
"""
r744hsav.__doc__ = """If set, corresponding field of I/O processors is valid

SMF Info
--------
    Field: `R744HSAV`
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, corresponding field of I/O processors is valid
"""

r744hfl2 : Final[Field] = Field(
    name='r744hfl2',
    origin='R744HFL2',
    type=FieldType.STRING,
    record=record,
    record_map=R744CHPA,
)
"""Validity flag 2

SMF Info
--------
    Field: `R744HFL2`
    Record: `SMF74S4`
    Map: `R744CHPA`

Validity flag 2
"""
r744hfl2.__doc__ = """Validity flag 2

SMF Info
--------
    Field: `R744HFL2`
    Record: `SMF74S4`
    Map: `R744CHPA`

Validity flag 2
"""

r744hpcv : Final[Field] = Field(
    name='r744hpcv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744hfl2,
    record=record,
    record_map=R744CHPA,
)
"""If set, Channel ID (CHID) is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl2`(`R744HFL2`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, Channel ID (CHID) is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744hpcv.__doc__ = """If set, Channel ID (CHID) is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hfl2`(`R744HFL2`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, Channel ID (CHID) is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744hopm : Final[Field] = Field(
    name='r744hopm',
    origin='R744HOPM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CHPA,
)
"""Channel path operation mode. It describes the channel path type, data rate, protocol and adapter type. x'01' - CFP path supporting a 1.0625 Gbit/sec data rate x'02' - CFP path supporting a 2.125 Gbit/sec data rate x'10' - CIB path operating at 1x bandwidth using the IFB protocol, adapter type HCA2-O LR x'11' - CIB path operating at 12x bandwidth using the IFB protocol, adapter type HCA2-O x'20' - CIB path operating at 1x bandwidth using the IFB protocol, adapter type HCA3-O LR x'21' - CIB path operating at 12x bandwidth using the IFB protocol, adapter type HCA3-O x'30' - CIB path operating at 12x bandwidth using the IFB3 protocol, adapter type HCA3-O x'40' - CS5 path operating at 8x bandwidth using the GEN3 protocol, adapter type PCIe-O x'50' - CL5 path supporting a 10 Gbit/sec data rate using the Converged Enhanced Ethernet protocol, adapter type RoCE LR

SMF Info
--------
    Field: `R744HOPM`
    Record: `SMF74S4`
    Map: `R744CHPA`

Channel path operation mode. It describes the channel path type, data rate, protocol and adapter type. x'01' - CFP path supporting a 1.0625 Gbit/sec data rate x'02' - CFP path supporting a 2.125 Gbit/sec data rate x'10' - CIB path operating at 1x bandwidth using the IFB protocol, adapter type HCA2-O LR x'11' - CIB path operating at 12x bandwidth using the IFB protocol, adapter type HCA2-O x'20' - CIB path operating at 1x bandwidth using the IFB protocol, adapter type HCA3-O LR x'21' - CIB path operating at 12x bandwidth using the IFB protocol, adapter type HCA3-O x'30' - CIB path operating at 12x bandwidth using the IFB3 protocol, adapter type HCA3-O x'40' - CS5 path operating at 8x bandwidth using the GEN3 protocol, adapter type PCIe-O x'50' - CL5 path supporting a 10 Gbit/sec data rate using the Converged Enhanced Ethernet protocol, adapter type RoCE LR
"""
r744hopm.__doc__ = """Channel path operation mode. It describes the channel path type, data rate, protocol and adapter type. x'01' - CFP path supporting a 1.0625 Gbit/sec data rate x'02' - CFP path supporting a 2.125 Gbit/sec data rate x'10' - CIB path operating at 1x bandwidth using the IFB protocol, adapter type HCA2-O LR x'11' - CIB path operating at 12x bandwidth using the IFB protocol, adapter type HCA2-O x'20' - CIB path operating at 1x bandwidth using the IFB protocol, adapter type HCA3-O LR x'21' - CIB path operating at 12x bandwidth using the IFB protocol, adapter type HCA3-O x'30' - CIB path operating at 12x bandwidth using the IFB3 protocol, adapter type HCA3-O x'40' - CS5 path operating at 8x bandwidth using the GEN3 protocol, adapter type PCIe-O x'50' - CL5 path supporting a 10 Gbit/sec data rate using the Converged Enhanced Ethernet protocol, adapter type RoCE LR

SMF Info
--------
    Field: `R744HOPM`
    Record: `SMF74S4`
    Map: `R744CHPA`

Channel path operation mode. It describes the channel path type, data rate, protocol and adapter type. x'01' - CFP path supporting a 1.0625 Gbit/sec data rate x'02' - CFP path supporting a 2.125 Gbit/sec data rate x'10' - CIB path operating at 1x bandwidth using the IFB protocol, adapter type HCA2-O LR x'11' - CIB path operating at 12x bandwidth using the IFB protocol, adapter type HCA2-O x'20' - CIB path operating at 1x bandwidth using the IFB protocol, adapter type HCA3-O LR x'21' - CIB path operating at 12x bandwidth using the IFB protocol, adapter type HCA3-O x'30' - CIB path operating at 12x bandwidth using the IFB3 protocol, adapter type HCA3-O x'40' - CS5 path operating at 8x bandwidth using the GEN3 protocol, adapter type PCIe-O x'50' - CL5 path supporting a 10 Gbit/sec data rate using the Converged Enhanced Ethernet protocol, adapter type RoCE LR
"""

r744hchf : Final[Field] = Field(
    name='r744hchf',
    origin='R744HCHF',
    type=FieldType.STRING,
    record=record,
    record_map=R744CHPA,
)
"""Status Flags

SMF Info
--------
    Field: `R744HCHF`
    Record: `SMF74S4`
    Map: `R744CHPA`

Status Flags
"""
r744hchf.__doc__ = """Status Flags

SMF Info
--------
    Field: `R744HCHF`
    Record: `SMF74S4`
    Map: `R744CHPA`

Status Flags
"""

r744hdeg : Final[Field] = Field(
    name='r744hdeg',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r744hchf,
    record=record,
    record_map=R744CHPA,
)
"""If set, channel path is operating at reduced capacity (degraded) or is not operating(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hchf`(`R744HCHF`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, channel path is operating at reduced capacity (degraded) or is not operating

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r744hdeg.__doc__ = """If set, channel path is operating at reduced capacity (degraded) or is not operating(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hchf`(`R744HCHF`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, channel path is operating at reduced capacity (degraded) or is not operating

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r744hsnd : Final[Field] = Field(
    name='r744hsnd',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r744hchf,
    record=record,
    record_map=R744CHPA,
)
"""If set, channel path is a sender path(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hchf`(`R744HCHF`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, channel path is a sender path

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r744hsnd.__doc__ = """If set, channel path is a sender path(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r744hchf`(`R744HCHF`)
    Record: `SMF74S4`
    Map: `R744CHPA`

If set, channel path is a sender path

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r744hlat : Final[Field] = Field(
    name='r744hlat',
    origin='R744HLAT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CHPA,
)
"""Channel path latency time. This is the average round-trip time in microseconds. A value of '0' means that the time was not measured. A value of '1' means a time less than or equal to one microsecond.

SMF Info
--------
    Field: `R744HLAT`
    Record: `SMF74S4`
    Map: `R744CHPA`

Channel path latency time. This is the average round-trip time in microseconds. A value of '0' means that the time was not measured. A value of '1' means a time less than or equal to one microsecond.
"""
r744hlat.__doc__ = """Channel path latency time. This is the average round-trip time in microseconds. A value of '0' means that the time was not measured. A value of '1' means a time less than or equal to one microsecond.

SMF Info
--------
    Field: `R744HLAT`
    Record: `SMF74S4`
    Map: `R744CHPA`

Channel path latency time. This is the average round-trip time in microseconds. A value of '0' means that the time was not measured. A value of '1' means a time less than or equal to one microsecond.
"""

r744hpcp : Final[Field] = Field(
    name='r744hpcp',
    origin='R744HPCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CHPA,
)
"""Physical channel path ID (CHID)

SMF Info
--------
    Field: `R744HPCP`
    Record: `SMF74S4`
    Map: `R744CHPA`

Physical channel path ID (CHID)
"""
r744hpcp.__doc__ = """Physical channel path ID (CHID)

SMF Info
--------
    Field: `R744HPCP`
    Record: `SMF74S4`
    Map: `R744CHPA`

Physical channel path ID (CHID)
"""

r744haid : Final[Field] = Field(
    name='r744haid',
    origin='R744HAID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CHPA,
)
"""Coupling adapter identifier associated with the CHPID

SMF Info
--------
    Field: `R744HAID`
    Record: `SMF74S4`
    Map: `R744CHPA`

Coupling adapter identifier associated with the CHPID
"""
r744haid.__doc__ = """Coupling adapter identifier associated with the CHPID

SMF Info
--------
    Field: `R744HAID`
    Record: `SMF74S4`
    Map: `R744CHPA`

Coupling adapter identifier associated with the CHPID
"""

r744hapn : Final[Field] = Field(
    name='r744hapn',
    origin='R744HAPN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CHPA,
)
"""Number of the port associated with the CHPID

SMF Info
--------
    Field: `R744HAPN`
    Record: `SMF74S4`
    Map: `R744CHPA`

Number of the port associated with the CHPID
"""
r744hapn.__doc__ = """Number of the port associated with the CHPID

SMF Info
--------
    Field: `R744HAPN`
    Record: `SMF74S4`
    Map: `R744CHPA`

Number of the port associated with the CHPID
"""

r744hsap : Final[Field] = Field(
    name='r744hsap',
    origin='R744HSAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744CHPA,
)
"""I/O processor to which this path is accessible. The range of values is x'00' to x'FF'.

SMF Info
--------
    Field: `R744HSAP`
    Record: `SMF74S4`
    Map: `R744CHPA`

I/O processor to which this path is accessible. The range of values is x'00' to x'FF'.
"""
r744hsap.__doc__ = """I/O processor to which this path is accessible. The range of values is x'00' to x'FF'.

SMF Info
--------
    Field: `R744HSAP`
    Record: `SMF74S4`
    Map: `R744CHPA`

I/O processor to which this path is accessible. The range of values is x'00' to x'FF'.
"""

r744hfla : Final[Field] = Field(
    name='r744hfla',
    origin='R744HFLA',
    type=FieldType.STRING,
    record=record,
    record_map=R744CHPA,
)
"""Validity bit mask. Each bit position represents the validity of a channel path attribute

SMF Info
--------
    Field: `R744HFLA`
    Record: `SMF74S4`
    Map: `R744CHPA`

Validity bit mask. Each bit position represents the validity of a channel path attribute
"""
r744hfla.__doc__ = """Validity bit mask. Each bit position represents the validity of a channel path attribute

SMF Info
--------
    Field: `R744HFLA`
    Record: `SMF74S4`
    Map: `R744CHPA`

Validity bit mask. Each bit position represents the validity of a channel path attribute
"""

r744msma : Final[Field] = Field(
    name='r744msma',
    origin='R744MSMA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Maximum amount of storage class memory the structure can use (4K-block units).

SMF Info
--------
    Field: `R744MSMA`
    Record: `SMF74S4`
    Map: `R744MSCM`

Maximum amount of storage class memory the structure can use (4K-block units).
"""
r744msma.__doc__ = """Maximum amount of storage class memory the structure can use (4K-block units).

SMF Info
--------
    Field: `R744MSMA`
    Record: `SMF74S4`
    Map: `R744MSCM`

Maximum amount of storage class memory the structure can use (4K-block units).
"""

r744malg : Final[Field] = Field(
    name='r744malg',
    origin='R744MALG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""SCM algorithm type

SMF Info
--------
    Field: `R744MALG`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM algorithm type
"""
r744malg.__doc__ = """SCM algorithm type

SMF Info
--------
    Field: `R744MALG`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM algorithm type
"""

r744mfau : Final[Field] = Field(
    name='r744mfau',
    origin='R744MFAU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Fixed augmented space (4K-block units).

SMF Info
--------
    Field: `R744MFAU`
    Record: `SMF74S4`
    Map: `R744MSCM`

Fixed augmented space (4K-block units).
"""
r744mfau.__doc__ = """Fixed augmented space (4K-block units).

SMF Info
--------
    Field: `R744MFAU`
    Record: `SMF74S4`
    Map: `R744MSCM`

Fixed augmented space (4K-block units).
"""

r744miua : Final[Field] = Field(
    name='r744miua',
    origin='R744MIUA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Amount of augmented space that is in use by this structure (4K-block units).

SMF Info
--------
    Field: `R744MIUA`
    Record: `SMF74S4`
    Map: `R744MSCM`

Amount of augmented space that is in use by this structure (4K-block units).
"""
r744miua.__doc__ = """Amount of augmented space that is in use by this structure (4K-block units).

SMF Info
--------
    Field: `R744MIUA`
    Record: `SMF74S4`
    Map: `R744MSCM`

Amount of augmented space that is in use by this structure (4K-block units).
"""

r744mius : Final[Field] = Field(
    name='r744mius',
    origin='R744MIUS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Amount of storage class memory that is in use by this structure (4K-block units).

SMF Info
--------
    Field: `R744MIUS`
    Record: `SMF74S4`
    Map: `R744MSCM`

Amount of storage class memory that is in use by this structure (4K-block units).
"""
r744mius.__doc__ = """Amount of storage class memory that is in use by this structure (4K-block units).

SMF Info
--------
    Field: `R744MIUS`
    Record: `SMF74S4`
    Map: `R744MSCM`

Amount of storage class memory that is in use by this structure (4K-block units).
"""

r744mema : Final[Field] = Field(
    name='r744mema',
    origin='R744MEMA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Estimated maximum amount of space that may be assigned as augmented space for this structure (4K-block units).

SMF Info
--------
    Field: `R744MEMA`
    Record: `SMF74S4`
    Map: `R744MSCM`

Estimated maximum amount of space that may be assigned as augmented space for this structure (4K-block units).
"""
r744mema.__doc__ = """Estimated maximum amount of space that may be assigned as augmented space for this structure (4K-block units).

SMF Info
--------
    Field: `R744MEMA`
    Record: `SMF74S4`
    Map: `R744MSCM`

Estimated maximum amount of space that may be assigned as augmented space for this structure (4K-block units).
"""

r744meml : Final[Field] = Field(
    name='r744meml',
    origin='R744MEML',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Estimated maximum number of list entries that may reside in storage class memory for this structure.

SMF Info
--------
    Field: `R744MEML`
    Record: `SMF74S4`
    Map: `R744MSCM`

Estimated maximum number of list entries that may reside in storage class memory for this structure.
"""
r744meml.__doc__ = """Estimated maximum number of list entries that may reside in storage class memory for this structure.

SMF Info
--------
    Field: `R744MEML`
    Record: `SMF74S4`
    Map: `R744MSCM`

Estimated maximum number of list entries that may reside in storage class memory for this structure.
"""

r744meme : Final[Field] = Field(
    name='r744meme',
    origin='R744MEME',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Estimated maximum number of list elements that may reside in storage class memory for this structure.

SMF Info
--------
    Field: `R744MEME`
    Record: `SMF74S4`
    Map: `R744MSCM`

Estimated maximum number of list elements that may reside in storage class memory for this structure.
"""
r744meme.__doc__ = """Estimated maximum number of list elements that may reside in storage class memory for this structure.

SMF Info
--------
    Field: `R744MEME`
    Record: `SMF74S4`
    Map: `R744MSCM`

Estimated maximum number of list elements that may reside in storage class memory for this structure.
"""

r744menl : Final[Field] = Field(
    name='r744menl',
    origin='R744MENL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Number of existing structure list entries that reside in storage class memory for this structure.

SMF Info
--------
    Field: `R744MENL`
    Record: `SMF74S4`
    Map: `R744MSCM`

Number of existing structure list entries that reside in storage class memory for this structure.
"""
r744menl.__doc__ = """Number of existing structure list entries that reside in storage class memory for this structure.

SMF Info
--------
    Field: `R744MENL`
    Record: `SMF74S4`
    Map: `R744MSCM`

Number of existing structure list entries that reside in storage class memory for this structure.
"""

r744mene : Final[Field] = Field(
    name='r744mene',
    origin='R744MENE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Number of existing structure list elements that reside in storage class memory for this structure.

SMF Info
--------
    Field: `R744MENE`
    Record: `SMF74S4`
    Map: `R744MSCM`

Number of existing structure list elements that reside in storage class memory for this structure.
"""
r744mene.__doc__ = """Number of existing structure list elements that reside in storage class memory for this structure.

SMF Info
--------
    Field: `R744MENE`
    Record: `SMF74S4`
    Map: `R744MSCM`

Number of existing structure list elements that reside in storage class memory for this structure.
"""

r744mslt : Final[Field] = Field(
    name='r744mslt',
    origin='R744MSLT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Percentage of the list entry and list element counts that determines the lower threshold for migration from storage class memory to CF storage.

SMF Info
--------
    Field: `R744MSLT`
    Record: `SMF74S4`
    Map: `R744MSCM`

Percentage of the list entry and list element counts that determines the lower threshold for migration from storage class memory to CF storage.
"""
r744mslt.__doc__ = """Percentage of the list entry and list element counts that determines the lower threshold for migration from storage class memory to CF storage.

SMF Info
--------
    Field: `R744MSLT`
    Record: `SMF74S4`
    Map: `R744MSCM`

Percentage of the list entry and list element counts that determines the lower threshold for migration from storage class memory to CF storage.
"""

r744msut : Final[Field] = Field(
    name='r744msut',
    origin='R744MSUT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Percentage of the list entry and list element counts that determines the upper threshold for migration from CF storage to storage class memory.

SMF Info
--------
    Field: `R744MSUT`
    Record: `SMF74S4`
    Map: `R744MSCM`

Percentage of the list entry and list element counts that determines the upper threshold for migration from CF storage to storage class memory.
"""
r744msut.__doc__ = """Percentage of the list entry and list element counts that determines the upper threshold for migration from CF storage to storage class memory.

SMF Info
--------
    Field: `R744MSUT`
    Record: `SMF74S4`
    Map: `R744MSCM`

Percentage of the list entry and list element counts that determines the upper threshold for migration from CF storage to storage class memory.
"""

r744mslr : Final[Field] = Field(
    name='r744mslr',
    origin='R744MSLR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Percentage of the list entry and list element counts that determines the lower threshold regulator for migration from CF storage class memory to CF real storage.

SMF Info
--------
    Field: `R744MSLR`
    Record: `SMF74S4`
    Map: `R744MSCM`

Percentage of the list entry and list element counts that determines the lower threshold regulator for migration from CF storage class memory to CF real storage.
"""
r744mslr.__doc__ = """Percentage of the list entry and list element counts that determines the lower threshold regulator for migration from CF storage class memory to CF real storage.

SMF Info
--------
    Field: `R744MSLR`
    Record: `SMF74S4`
    Map: `R744MSCM`

Percentage of the list entry and list element counts that determines the lower threshold regulator for migration from CF storage class memory to CF real storage.
"""

r744msur : Final[Field] = Field(
    name='r744msur',
    origin='R744MSUR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Percentage of the list entry and list element counts that determines the upper threshold regulator for migration from CF real storage to CF storage class memory.

SMF Info
--------
    Field: `R744MSUR`
    Record: `SMF74S4`
    Map: `R744MSCM`

Percentage of the list entry and list element counts that determines the upper threshold regulator for migration from CF real storage to CF storage class memory.
"""
r744msur.__doc__ = """Percentage of the list entry and list element counts that determines the upper threshold regulator for migration from CF real storage to CF storage class memory.

SMF Info
--------
    Field: `R744MSUR`
    Record: `SMF74S4`
    Map: `R744MSCM`

Percentage of the list entry and list element counts that determines the upper threshold regulator for migration from CF real storage to CF storage class memory.
"""

r744mswc : Final[Field] = Field(
    name='r744mswc',
    origin='R744MSWC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""SCM write count. The number of list write operations performed to storage class memory.

SMF Info
--------
    Field: `R744MSWC`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM write count. The number of list write operations performed to storage class memory.
"""
r744mswc.__doc__ = """SCM write count. The number of list write operations performed to storage class memory.

SMF Info
--------
    Field: `R744MSWC`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM write count. The number of list write operations performed to storage class memory.
"""

r744mrfc : Final[Field] = Field(
    name='r744mrfc',
    origin='R744MRFC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""SCM read after fault count. The number of read operations against storage class memory that were initiated by a reference to list structure objects residing in storage class memory.

SMF Info
--------
    Field: `R744MRFC`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM read after fault count. The number of read operations against storage class memory that were initiated by a reference to list structure objects residing in storage class memory.
"""
r744mrfc.__doc__ = """SCM read after fault count. The number of read operations against storage class memory that were initiated by a reference to list structure objects residing in storage class memory.

SMF Info
--------
    Field: `R744MRFC`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM read after fault count. The number of read operations against storage class memory that were initiated by a reference to list structure objects residing in storage class memory.
"""

r744mrpc : Final[Field] = Field(
    name='r744mrpc',
    origin='R744MRPC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""SCM read for prefetch count. The number of read operations against storage class memory that were initiated as a prefetch operation in order to retrieve list structure objects in storage class memory that are expected to be referenced.

SMF Info
--------
    Field: `R744MRPC`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM read for prefetch count. The number of read operations against storage class memory that were initiated as a prefetch operation in order to retrieve list structure objects in storage class memory that are expected to be referenced.
"""
r744mrpc.__doc__ = """SCM read for prefetch count. The number of read operations against storage class memory that were initiated as a prefetch operation in order to retrieve list structure objects in storage class memory that are expected to be referenced.

SMF Info
--------
    Field: `R744MRPC`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM read for prefetch count. The number of read operations against storage class memory that were initiated as a prefetch operation in order to retrieve list structure objects in storage class memory that are expected to be referenced.
"""

r744mrst : Final[Field] = Field(
    name='r744mrst',
    origin='R744MRST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Total amount of service times for read operations from storage class memory in microseconds.

SMF Info
--------
    Field: `R744MRST`
    Record: `SMF74S4`
    Map: `R744MSCM`

Total amount of service times for read operations from storage class memory in microseconds.
"""
r744mrst.__doc__ = """Total amount of service times for read operations from storage class memory in microseconds.

SMF Info
--------
    Field: `R744MRST`
    Record: `SMF74S4`
    Map: `R744MSCM`

Total amount of service times for read operations from storage class memory in microseconds.
"""

r744mrsq : Final[Field] = Field(
    name='r744mrsq',
    origin='R744MRSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Total amount of squares of service times for read operations from storage class memory in square-microseconds.

SMF Info
--------
    Field: `R744MRSQ`
    Record: `SMF74S4`
    Map: `R744MSCM`

Total amount of squares of service times for read operations from storage class memory in square-microseconds.
"""
r744mrsq.__doc__ = """Total amount of squares of service times for read operations from storage class memory in square-microseconds.

SMF Info
--------
    Field: `R744MRSQ`
    Record: `SMF74S4`
    Map: `R744MSCM`

Total amount of squares of service times for read operations from storage class memory in square-microseconds.
"""

r744mwst : Final[Field] = Field(
    name='r744mwst',
    origin='R744MWST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Total amount of service times for write operations to storage class memory in microseconds.

SMF Info
--------
    Field: `R744MWST`
    Record: `SMF74S4`
    Map: `R744MSCM`

Total amount of service times for write operations to storage class memory in microseconds.
"""
r744mwst.__doc__ = """Total amount of service times for write operations to storage class memory in microseconds.

SMF Info
--------
    Field: `R744MWST`
    Record: `SMF74S4`
    Map: `R744MSCM`

Total amount of service times for write operations to storage class memory in microseconds.
"""

r744mwsq : Final[Field] = Field(
    name='r744mwsq',
    origin='R744MWSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""Total amount of squares of service times for write operations to storage class memory in square-microseconds.

SMF Info
--------
    Field: `R744MWSQ`
    Record: `SMF74S4`
    Map: `R744MSCM`

Total amount of squares of service times for write operations to storage class memory in square-microseconds.
"""
r744mwsq.__doc__ = """Total amount of squares of service times for write operations to storage class memory in square-microseconds.

SMF Info
--------
    Field: `R744MWSQ`
    Record: `SMF74S4`
    Map: `R744MSCM`

Total amount of squares of service times for write operations to storage class memory in square-microseconds.
"""

r744mrbt : Final[Field] = Field(
    name='r744mrbt',
    origin='R744MRBT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""SCM read bytes transferred. This is the number of bytes in 4K units transferred from storage class memory to CF storage.

SMF Info
--------
    Field: `R744MRBT`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM read bytes transferred. This is the number of bytes in 4K units transferred from storage class memory to CF storage.
"""
r744mrbt.__doc__ = """SCM read bytes transferred. This is the number of bytes in 4K units transferred from storage class memory to CF storage.

SMF Info
--------
    Field: `R744MRBT`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM read bytes transferred. This is the number of bytes in 4K units transferred from storage class memory to CF storage.
"""

r744mwbt : Final[Field] = Field(
    name='r744mwbt',
    origin='R744MWBT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""SCM write bytes transferred. This is the number of bytes in 4K units transferred from CF storage to storage class memory

SMF Info
--------
    Field: `R744MWBT`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM write bytes transferred. This is the number of bytes in 4K units transferred from CF storage to storage class memory
"""
r744mwbt.__doc__ = """SCM write bytes transferred. This is the number of bytes in 4K units transferred from CF storage to storage class memory

SMF Info
--------
    Field: `R744MWBT`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM write bytes transferred. This is the number of bytes in 4K units transferred from CF storage to storage class memory
"""

r744maec : Final[Field] = Field(
    name='r744maec',
    origin='R744MAEC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""SCM auxiliary enabled command count. This is the number of commands that required the use of CF auxiliary frames.

SMF Info
--------
    Field: `R744MAEC`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM auxiliary enabled command count. This is the number of commands that required the use of CF auxiliary frames.
"""
r744maec.__doc__ = """SCM auxiliary enabled command count. This is the number of commands that required the use of CF auxiliary frames.

SMF Info
--------
    Field: `R744MAEC`
    Record: `SMF74S4`
    Map: `R744MSCM`

SCM auxiliary enabled command count. This is the number of commands that required the use of CF auxiliary frames.
"""

r744msrl : Final[Field] = Field(
    name='r744msrl',
    origin='R744MSRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""The number of references against storage class memory to locate list structure objects.

SMF Info
--------
    Field: `R744MSRL`
    Record: `SMF74S4`
    Map: `R744MSCM`

The number of references against storage class memory to locate list structure objects.
"""
r744msrl.__doc__ = """The number of references against storage class memory to locate list structure objects.

SMF Info
--------
    Field: `R744MSRL`
    Record: `SMF74S4`
    Map: `R744MSCM`

The number of references against storage class memory to locate list structure objects.
"""

r744msrr : Final[Field] = Field(
    name='r744msrr',
    origin='R744MSRR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""The number of references against storage class memory to resolve list entry key hashing.

SMF Info
--------
    Field: `R744MSRR`
    Record: `SMF74S4`
    Map: `R744MSCM`

The number of references against storage class memory to resolve list entry key hashing.
"""
r744msrr.__doc__ = """The number of references against storage class memory to resolve list entry key hashing.

SMF Info
--------
    Field: `R744MSRR`
    Record: `SMF74S4`
    Map: `R744MSCM`

The number of references against storage class memory to resolve list entry key hashing.
"""

r744msrm : Final[Field] = Field(
    name='r744msrm',
    origin='R744MSRM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""The number of references against storage class memory for the purpose of migrating list structure objects from CF storage to storage class memory to allow the creation of new list structure objects in CF storage.

SMF Info
--------
    Field: `R744MSRM`
    Record: `SMF74S4`
    Map: `R744MSCM`

The number of references against storage class memory for the purpose of migrating list structure objects from CF storage to storage class memory to allow the creation of new list structure objects in CF storage.
"""
r744msrm.__doc__ = """The number of references against storage class memory for the purpose of migrating list structure objects from CF storage to storage class memory to allow the creation of new list structure objects in CF storage.

SMF Info
--------
    Field: `R744MSRM`
    Record: `SMF74S4`
    Map: `R744MSCM`

The number of references against storage class memory for the purpose of migrating list structure objects from CF storage to storage class memory to allow the creation of new list structure objects in CF storage.
"""

r744mmbl : Final[Field] = Field(
    name='r744mmbl',
    origin='R744MMBL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""The maximum number of list entries that can be stored in a single storage class memory buffer.

SMF Info
--------
    Field: `R744MMBL`
    Record: `SMF74S4`
    Map: `R744MSCM`

The maximum number of list entries that can be stored in a single storage class memory buffer.
"""
r744mmbl.__doc__ = """The maximum number of list entries that can be stored in a single storage class memory buffer.

SMF Info
--------
    Field: `R744MMBL`
    Record: `SMF74S4`
    Map: `R744MSCM`

The maximum number of list entries that can be stored in a single storage class memory buffer.
"""

r744mmbe : Final[Field] = Field(
    name='r744mmbe',
    origin='R744MMBE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""The maximum number of list elements that can be stored in a single Storage Class Memory buffer.

SMF Info
--------
    Field: `R744MMBE`
    Record: `SMF74S4`
    Map: `R744MSCM`

The maximum number of list elements that can be stored in a single Storage Class Memory buffer.
"""
r744mmbe.__doc__ = """The maximum number of list elements that can be stored in a single Storage Class Memory buffer.

SMF Info
--------
    Field: `R744MMBE`
    Record: `SMF74S4`
    Map: `R744MSCM`

The maximum number of list elements that can be stored in a single Storage Class Memory buffer.
"""

r744mnel : Final[Field] = Field(
    name='r744mnel',
    origin='R744MNEL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""The minimum number of list elements that must be available for assignment after the specified allocation process completes.

SMF Info
--------
    Field: `R744MNEL`
    Record: `SMF74S4`
    Map: `R744MSCM`

The minimum number of list elements that must be available for assignment after the specified allocation process completes.
"""
r744mnel.__doc__ = """The minimum number of list elements that must be available for assignment after the specified allocation process completes.

SMF Info
--------
    Field: `R744MNEL`
    Record: `SMF74S4`
    Map: `R744MSCM`

The minimum number of list elements that must be available for assignment after the specified allocation process completes.
"""

r744mnec : Final[Field] = Field(
    name='r744mnec',
    origin='R744MNEC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""The minimum number of list entries that must be available for assignment after the specified allocation process completes.

SMF Info
--------
    Field: `R744MNEC`
    Record: `SMF74S4`
    Map: `R744MSCM`

The minimum number of list entries that must be available for assignment after the specified allocation process completes.
"""
r744mnec.__doc__ = """The minimum number of list entries that must be available for assignment after the specified allocation process completes.

SMF Info
--------
    Field: `R744MNEC`
    Record: `SMF74S4`
    Map: `R744MSCM`

The minimum number of list entries that must be available for assignment after the specified allocation process completes.
"""

r744msrk : Final[Field] = Field(
    name='r744msrk',
    origin='R744MSRK',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744MSCM,
)
"""The number of references against Storage Class Memory for the purpose of migrating list structure objects from Storage Class Memory to CF storage to allow for key-range initialization to complete.

SMF Info
--------
    Field: `R744MSRK`
    Record: `SMF74S4`
    Map: `R744MSCM`

The number of references against Storage Class Memory for the purpose of migrating list structure objects from Storage Class Memory to CF storage to allow for key-range initialization to complete.
"""
r744msrk.__doc__ = """The number of references against Storage Class Memory for the purpose of migrating list structure objects from Storage Class Memory to CF storage to allow for key-range initialization to complete.

SMF Info
--------
    Field: `R744MSRK`
    Record: `SMF74S4`
    Map: `R744MSCM`

The number of references against Storage Class Memory for the purpose of migrating list structure objects from Storage Class Memory to CF storage to allow for key-range initialization to complete.
"""

r744afo : Final[Field] = Field(
    name='r744afo',
    origin='R744AFO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""The most current failed operation sequence number.

SMF Info
--------
    Field: `R744AFO`
    Record: `SMF74S4`
    Map: `R744ADUP`

The most current failed operation sequence number.
"""
r744afo.__doc__ = """The most current failed operation sequence number.

SMF Info
--------
    Field: `R744AFO`
    Record: `SMF74S4`
    Map: `R744ADUP`

The most current failed operation sequence number.
"""

r744aheo : Final[Field] = Field(
    name='r744aheo',
    origin='R744AHEO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Highest operation sequence number that can be executed and completed in the secondary CF.

SMF Info
--------
    Field: `R744AHEO`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest operation sequence number that can be executed and completed in the secondary CF.
"""
r744aheo.__doc__ = """Highest operation sequence number that can be executed and completed in the secondary CF.

SMF Info
--------
    Field: `R744AHEO`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest operation sequence number that can be executed and completed in the secondary CF.
"""

r744alaoh : Final[Field] = Field(
    name='r744alaoh',
    origin='R744ALAOH',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Highest sequence number of the operation that has been exe cuted in the primary structure (Valid if bit 4 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ALAOH`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest sequence number of the operation that has been exe cuted in the primary structure (Valid if bit 4 of R744SFLG is set.)
"""
r744alaoh.__doc__ = """Highest sequence number of the operation that has been exe cuted in the primary structure (Valid if bit 4 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ALAOH`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest sequence number of the operation that has been exe cuted in the primary structure (Valid if bit 4 of R744SFLG is set.)
"""

r744alaosh : Final[Field] = Field(
    name='r744alaosh',
    origin='R744ALAOSH',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Highest sequence number of the operation that has completed in the primary structure and has been recognized by the secondary structure.

SMF Info
--------
    Field: `R744ALAOSH`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest sequence number of the operation that has completed in the primary structure and has been recognized by the secondary structure.
"""
r744alaosh.__doc__ = """Highest sequence number of the operation that has completed in the primary structure and has been recognized by the secondary structure.

SMF Info
--------
    Field: `R744ALAOSH`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest sequence number of the operation that has completed in the primary structure and has been recognized by the secondary structure.
"""

r744alcoh : Final[Field] = Field(
    name='r744alcoh',
    origin='R744ALCOH',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Highest sequence number of the operation that has completed in the secondary structure. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ALCOH`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest sequence number of the operation that has completed in the secondary structure. (Valid if bit 5 of R744SFLG is set.)
"""
r744alcoh.__doc__ = """Highest sequence number of the operation that has completed in the secondary structure. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ALCOH`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest sequence number of the operation that has completed in the secondary structure. (Valid if bit 5 of R744SFLG is set.)
"""

r744alcoph : Final[Field] = Field(
    name='r744alcoph',
    origin='R744ALCOPH',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Highest sequence number of the operation that has completed in the secondary structure and that has been recognized by the primary structure.

SMF Info
--------
    Field: `R744ALCOPH`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest sequence number of the operation that has completed in the secondary structure and that has been recognized by the primary structure.
"""
r744alcoph.__doc__ = """Highest sequence number of the operation that has completed in the secondary structure and that has been recognized by the primary structure.

SMF Info
--------
    Field: `R744ALCOPH`
    Record: `SMF74S4`
    Map: `R744ADUP`

Highest sequence number of the operation that has completed in the secondary structure and that has been recognized by the primary structure.
"""

r744alao : Final[Field] = Field(
    name='r744alao',
    origin='R744ALAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Number of asynchronous duplex operations that have been executed in the primary structure. (Valid if bit 4 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ALAO`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations that have been executed in the primary structure. (Valid if bit 4 of R744SFLG is set.)
"""
r744alao.__doc__ = """Number of asynchronous duplex operations that have been executed in the primary structure. (Valid if bit 4 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ALAO`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations that have been executed in the primary structure. (Valid if bit 4 of R744SFLG is set.)
"""

r744alaos : Final[Field] = Field(
    name='r744alaos',
    origin='R744ALAOS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Number of asynchronous duplex operations that have executed in the primary and have been recognized in the secondary structure.

SMF Info
--------
    Field: `R744ALAOS`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations that have executed in the primary and have been recognized in the secondary structure.
"""
r744alaos.__doc__ = """Number of asynchronous duplex operations that have executed in the primary and have been recognized in the secondary structure.

SMF Info
--------
    Field: `R744ALAOS`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations that have executed in the primary and have been recognized in the secondary structure.
"""

r744alco : Final[Field] = Field(
    name='r744alco',
    origin='R744ALCO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Number of asynchronous duplex operations transmitted from the primary to the secondary structure that completed in the secondary structure. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ALCO`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations transmitted from the primary to the secondary structure that completed in the secondary structure. (Valid if bit 5 of R744SFLG is set.)
"""
r744alco.__doc__ = """Number of asynchronous duplex operations transmitted from the primary to the secondary structure that completed in the secondary structure. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ALCO`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations transmitted from the primary to the secondary structure that completed in the secondary structure. (Valid if bit 5 of R744SFLG is set.)
"""

r744alcop : Final[Field] = Field(
    name='r744alcop',
    origin='R744ALCOP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Number of asynchronous duplex operations that have been completed both in the primary and in the secondary structure which has been recognized by the primary structure.

SMF Info
--------
    Field: `R744ALCOP`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations that have been completed both in the primary and in the secondary structure which has been recognized by the primary structure.
"""
r744alcop.__doc__ = """Number of asynchronous duplex operations that have been completed both in the primary and in the secondary structure which has been recognized by the primary structure.

SMF Info
--------
    Field: `R744ALCOP`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations that have been completed both in the primary and in the secondary structure which has been recognized by the primary structure.
"""

r744atpoct : Final[Field] = Field(
    name='r744atpoct',
    origin='R744ATPOCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total number of asynchronous duplex operations that have been transmitted from the primary to the secondary structure.

SMF Info
--------
    Field: `R744ATPOCT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total number of asynchronous duplex operations that have been transmitted from the primary to the secondary structure.
"""
r744atpoct.__doc__ = """Total number of asynchronous duplex operations that have been transmitted from the primary to the secondary structure.

SMF Info
--------
    Field: `R744ATPOCT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total number of asynchronous duplex operations that have been transmitted from the primary to the secondary structure.
"""

r744atpoc : Final[Field] = Field(
    name='r744atpoc',
    origin='R744ATPOC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Number of asynchronous duplex operations transmitted from the primary to the secondary structure in this interval.

SMF Info
--------
    Field: `R744ATPOC`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations transmitted from the primary to the secondary structure in this interval.
"""
r744atpoc.__doc__ = """Number of asynchronous duplex operations transmitted from the primary to the secondary structure in this interval.

SMF Info
--------
    Field: `R744ATPOC`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations transmitted from the primary to the secondary structure in this interval.
"""

r744arcpot : Final[Field] = Field(
    name='r744arcpot',
    origin='R744ARCPOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total number of asynchronous duplex operations that have completed in the secondary and have been recognized as complete to the primary structure.

SMF Info
--------
    Field: `R744ARCPOT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total number of asynchronous duplex operations that have completed in the secondary and have been recognized as complete to the primary structure.
"""
r744arcpot.__doc__ = """Total number of asynchronous duplex operations that have completed in the secondary and have been recognized as complete to the primary structure.

SMF Info
--------
    Field: `R744ARCPOT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total number of asynchronous duplex operations that have completed in the secondary and have been recognized as complete to the primary structure.
"""

r744arcpo : Final[Field] = Field(
    name='r744arcpo',
    origin='R744ARCPO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Number of asynchronous duplex operations transmitted from the primary to the secondary structure and recognized as complete to the primary structure in this interval.

SMF Info
--------
    Field: `R744ARCPO`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations transmitted from the primary to the secondary structure and recognized as complete to the primary structure in this interval.
"""
r744arcpo.__doc__ = """Number of asynchronous duplex operations transmitted from the primary to the secondary structure and recognized as complete to the primary structure in this interval.

SMF Info
--------
    Field: `R744ARCPO`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of asynchronous duplex operations transmitted from the primary to the secondary structure and recognized as complete to the primary structure in this interval.
"""

r744acqsc : Final[Field] = Field(
    name='r744acqsc',
    origin='R744ACQSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Number of stalls in the processing of the secondary operation queue.

SMF Info
--------
    Field: `R744ACQSC`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of stalls in the processing of the secondary operation queue.
"""
r744acqsc.__doc__ = """Number of stalls in the processing of the secondary operation queue.

SMF Info
--------
    Field: `R744ACQSC`
    Record: `SMF74S4`
    Map: `R744ADUP`

Number of stalls in the processing of the secondary operation queue.
"""

r744apdt : Final[Field] = Field(
    name='r744apdt',
    origin='R744APDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of primary delay time for asynchronous duplex operations, in microseconds. The primary delay time is the elapsed time in the primary CF between the assignment of the operation to the queue buffer and the first attempt to send the operation to the secondary CF.

SMF Info
--------
    Field: `R744APDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of primary delay time for asynchronous duplex operations, in microseconds. The primary delay time is the elapsed time in the primary CF between the assignment of the operation to the queue buffer and the first attempt to send the operation to the secondary CF.
"""
r744apdt.__doc__ = """Total amount of primary delay time for asynchronous duplex operations, in microseconds. The primary delay time is the elapsed time in the primary CF between the assignment of the operation to the queue buffer and the first attempt to send the operation to the secondary CF.

SMF Info
--------
    Field: `R744APDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of primary delay time for asynchronous duplex operations, in microseconds. The primary delay time is the elapsed time in the primary CF between the assignment of the operation to the queue buffer and the first attempt to send the operation to the secondary CF.
"""

r744apdq : Final[Field] = Field(
    name='r744apdq',
    origin='R744APDQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of squares of primary delay time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744APDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of primary delay time for asynchronous duplex operations in square of microseconds.
"""
r744apdq.__doc__ = """Total amount of squares of primary delay time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744APDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of primary delay time for asynchronous duplex operations in square of microseconds.
"""

r744amdt : Final[Field] = Field(
    name='r744amdt',
    origin='R744AMDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of message delay time for asynchronous duplex operations, in microseconds. This is the elapsed time from the first attempt to send the asynchronous duplex operation in the primary CF to the time that the secondary CF assigns the operation to a secondary queue entry.

SMF Info
--------
    Field: `R744AMDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of message delay time for asynchronous duplex operations, in microseconds. This is the elapsed time from the first attempt to send the asynchronous duplex operation in the primary CF to the time that the secondary CF assigns the operation to a secondary queue entry.
"""
r744amdt.__doc__ = """Total amount of message delay time for asynchronous duplex operations, in microseconds. This is the elapsed time from the first attempt to send the asynchronous duplex operation in the primary CF to the time that the secondary CF assigns the operation to a secondary queue entry.

SMF Info
--------
    Field: `R744AMDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of message delay time for asynchronous duplex operations, in microseconds. This is the elapsed time from the first attempt to send the asynchronous duplex operation in the primary CF to the time that the secondary CF assigns the operation to a secondary queue entry.
"""

r744amdq : Final[Field] = Field(
    name='r744amdq',
    origin='R744AMDQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of squares of message delay time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744AMDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of message delay time for asynchronous duplex operations in square of microseconds.
"""
r744amdq.__doc__ = """Total amount of squares of message delay time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744AMDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of message delay time for asynchronous duplex operations in square of microseconds.
"""

r744aqdt : Final[Field] = Field(
    name='r744aqdt',
    origin='R744AQDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of secondary queue delay time for asynchronous duplex operations in microseconds. The secondary queue delay time is the elapsed time from the time the asynchronous duplex operation is assigned to a secondary queue entry to the time of completion of the asynchronous duplex operation.

SMF Info
--------
    Field: `R744AQDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of secondary queue delay time for asynchronous duplex operations in microseconds. The secondary queue delay time is the elapsed time from the time the asynchronous duplex operation is assigned to a secondary queue entry to the time of completion of the asynchronous duplex operation.
"""
r744aqdt.__doc__ = """Total amount of secondary queue delay time for asynchronous duplex operations in microseconds. The secondary queue delay time is the elapsed time from the time the asynchronous duplex operation is assigned to a secondary queue entry to the time of completion of the asynchronous duplex operation.

SMF Info
--------
    Field: `R744AQDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of secondary queue delay time for asynchronous duplex operations in microseconds. The secondary queue delay time is the elapsed time from the time the asynchronous duplex operation is assigned to a secondary queue entry to the time of completion of the asynchronous duplex operation.
"""

r744aqdq : Final[Field] = Field(
    name='r744aqdq',
    origin='R744AQDQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of squares of secondary queue delay time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744AQDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of secondary queue delay time for asynchronous duplex operations in square of microseconds.
"""
r744aqdq.__doc__ = """Total amount of squares of secondary queue delay time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744AQDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of secondary queue delay time for asynchronous duplex operations in square of microseconds.
"""

r744aqst : Final[Field] = Field(
    name='r744aqst',
    origin='R744AQST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of secondary queue stall time for asynchronous duplex operations, in microseconds.

SMF Info
--------
    Field: `R744AQST`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of secondary queue stall time for asynchronous duplex operations, in microseconds.
"""
r744aqst.__doc__ = """Total amount of secondary queue stall time for asynchronous duplex operations, in microseconds.

SMF Info
--------
    Field: `R744AQST`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of secondary queue stall time for asynchronous duplex operations, in microseconds.
"""

r744aqsq : Final[Field] = Field(
    name='r744aqsq',
    origin='R744AQSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of squares of secondary queue stall time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744AQSQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of secondary queue stall time for asynchronous duplex operations in square of microseconds.
"""
r744aqsq.__doc__ = """Total amount of squares of secondary queue stall time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744AQSQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of secondary queue stall time for asynchronous duplex operations in square of microseconds.
"""

r744acdt : Final[Field] = Field(
    name='r744acdt',
    origin='R744ACDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of secondary reported completion delay time for asynchronous duplex operations, in microseconds. The secondary reported completion delay time is the elapsed time in the secondary CF, from the time the asynchronous duplex operation completes in the secondary to the time that the completion is reported to the primary.

SMF Info
--------
    Field: `R744ACDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of secondary reported completion delay time for asynchronous duplex operations, in microseconds. The secondary reported completion delay time is the elapsed time in the secondary CF, from the time the asynchronous duplex operation completes in the secondary to the time that the completion is reported to the primary.
"""
r744acdt.__doc__ = """Total amount of secondary reported completion delay time for asynchronous duplex operations, in microseconds. The secondary reported completion delay time is the elapsed time in the secondary CF, from the time the asynchronous duplex operation completes in the secondary to the time that the completion is reported to the primary.

SMF Info
--------
    Field: `R744ACDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of secondary reported completion delay time for asynchronous duplex operations, in microseconds. The secondary reported completion delay time is the elapsed time in the secondary CF, from the time the asynchronous duplex operation completes in the secondary to the time that the completion is reported to the primary.
"""

r744acdq : Final[Field] = Field(
    name='r744acdq',
    origin='R744ACDQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of squares of secondary reported completion delay time for asynchronous duplex operations, in square of microseconds.

SMF Info
--------
    Field: `R744ACDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of secondary reported completion delay time for asynchronous duplex operations, in square of microseconds.
"""
r744acdq.__doc__ = """Total amount of squares of secondary reported completion delay time for asynchronous duplex operations, in square of microseconds.

SMF Info
--------
    Field: `R744ACDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of secondary reported completion delay time for asynchronous duplex operations, in square of microseconds.
"""

r744ardt : Final[Field] = Field(
    name='r744ardt',
    origin='R744ARDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of response delay time for asynchronous duplex operations, in microseconds. The response delay time is the elapsed time from the launch of the operation response in the secondary CF to the time that the primary CF recognizes the reponse.

SMF Info
--------
    Field: `R744ARDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of response delay time for asynchronous duplex operations, in microseconds. The response delay time is the elapsed time from the launch of the operation response in the secondary CF to the time that the primary CF recognizes the reponse.
"""
r744ardt.__doc__ = """Total amount of response delay time for asynchronous duplex operations, in microseconds. The response delay time is the elapsed time from the launch of the operation response in the secondary CF to the time that the primary CF recognizes the reponse.

SMF Info
--------
    Field: `R744ARDT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of response delay time for asynchronous duplex operations, in microseconds. The response delay time is the elapsed time from the launch of the operation response in the secondary CF to the time that the primary CF recognizes the reponse.
"""

r744ardq : Final[Field] = Field(
    name='r744ardq',
    origin='R744ARDQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of squares of response delay time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744ARDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of response delay time for asynchronous duplex operations in square of microseconds.
"""
r744ardq.__doc__ = """Total amount of squares of response delay time for asynchronous duplex operations in square of microseconds.

SMF Info
--------
    Field: `R744ARDQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of response delay time for asynchronous duplex operations in square of microseconds.
"""

r744aott : Final[Field] = Field(
    name='r744aott',
    origin='R744AOTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of operation transmission time for operations sent from the primary to the secondary structure, in microseconds. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744AOTT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of operation transmission time for operations sent from the primary to the secondary structure, in microseconds. (Valid if bit 5 of R744SFLG is set.)
"""
r744aott.__doc__ = """Total amount of operation transmission time for operations sent from the primary to the secondary structure, in microseconds. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744AOTT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of operation transmission time for operations sent from the primary to the secondary structure, in microseconds. (Valid if bit 5 of R744SFLG is set.)
"""

r744aotq : Final[Field] = Field(
    name='r744aotq',
    origin='R744AOTQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of squares of operation transmission time, in square of microseconds. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744AOTQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of operation transmission time, in square of microseconds. (Valid if bit 5 of R744SFLG is set.)
"""
r744aotq.__doc__ = """Total amount of squares of operation transmission time, in square of microseconds. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744AOTQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of operation transmission time, in square of microseconds. (Valid if bit 5 of R744SFLG is set.)
"""

r744astt : Final[Field] = Field(
    name='r744astt',
    origin='R744ASTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of service time to transfer the asynchronous duplex operations to the secondary structure and complete the operations in the secondary structure, in microseconds. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ASTT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of service time to transfer the asynchronous duplex operations to the secondary structure and complete the operations in the secondary structure, in microseconds. (Valid if bit 5 of R744SFLG is set.)
"""
r744astt.__doc__ = """Total amount of service time to transfer the asynchronous duplex operations to the secondary structure and complete the operations in the secondary structure, in microseconds. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ASTT`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of service time to transfer the asynchronous duplex operations to the secondary structure and complete the operations in the secondary structure, in microseconds. (Valid if bit 5 of R744SFLG is set.)
"""

r744astq : Final[Field] = Field(
    name='r744astq',
    origin='R744ASTQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R744ADUP,
)
"""Total amount of squares of service time to transfer the asynchronous duplex operations to the secondary structure and complete the operations in the secondary structure, in square of microseconds. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ASTQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of service time to transfer the asynchronous duplex operations to the secondary structure and complete the operations in the secondary structure, in square of microseconds. (Valid if bit 5 of R744SFLG is set.)
"""
r744astq.__doc__ = """Total amount of squares of service time to transfer the asynchronous duplex operations to the secondary structure and complete the operations in the secondary structure, in square of microseconds. (Valid if bit 5 of R744SFLG is set.)

SMF Info
--------
    Field: `R744ASTQ`
    Record: `SMF74S4`
    Map: `R744ADUP`

Total amount of squares of service time to transfer the asynchronous duplex operations to the secondary structure and complete the operations in the secondary structure, in square of microseconds. (Valid if bit 5 of R744SFLG is set.)
"""
