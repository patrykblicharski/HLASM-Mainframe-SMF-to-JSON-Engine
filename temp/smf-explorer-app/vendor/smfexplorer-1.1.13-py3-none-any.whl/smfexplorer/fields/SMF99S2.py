# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 99 Subtype 2"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=99,
                                smf_subtype=2,
                                spec='SMF 99 Subtype 2',
                                post=None)
"""SMF 99 Subtype 2"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __class_period_inline_post(df):
    return df.srv_class_name +'.' + df.period_num.astype(str)



SMF99_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_SDEF_MAP',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 self defining Section',
    post=None,
    record_mapping=False)
"""SMF99 self defining Section"""
SMF99_PRODUCT_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_PRODUCT_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Product Information Section',
    post=None,
    record_mapping=False)
"""SMF99 Product Information Section"""
SMF99_S2_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S2_SDEF_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Subtype 2 self defining section',
    post=None,
    record_mapping=False)
"""SMF99 Subtype 2 self defining section"""
SMF99_S2_CLS_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S2_CLS_MAP',
    record=record,
    parent=SMF99_S2_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='Service class definition map',
    post=None,
    record_mapping=False)
"""Service class definition map"""
SMF99_S2_PER_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S2_PER_MAP',
    record=record,
    parent=SMF99_S2_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='Service class period map',
    post=None,
    record_mapping=False)
"""Service class period map"""
SMF99_S2_ECD_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S2_ECD_MAP',
    record=record,
    parent=SMF99_S2_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 2 EWLM Class data section - Contains information about a...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 2 EWLM Class data section - Contains information about a..."""
SMF99_XMEM_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_XMEM_MAP',
    record=record,
    parent=SMF99_S2_PER_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 2 xmem delay data BASED(addr(smf_hdr_MAP) + smf99_pxmem_...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 2 xmem delay data BASED(addr(smf_hdr_MAP) + smf99_pxmem_..."""
SMF99_SERVER_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_SERVER_MAP',
    record=record,
    parent=SMF99_S2_PER_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 2 server data BASED(addr(smf_hdr_MAP) + smf99_pserv_of)',
    post=None,
    record_mapping=False)
"""SMF99 subtype 2 server data BASED(addr(smf_hdr_MAP) + smf99_pserv_of)"""
SMF99_AS_ESP_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_AS_ESP_MAP',
    record=record,
    parent=SMF99_S2_PER_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 2 address space expanded storage access policy BASED(add...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 2 address space expanded storage access policy BASED(add..."""
SMF99_SDATA_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_SDATA_MAP',
    record=record,
    parent=SMF99_S2_PER_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 2 server sample data BASED(addr(smf_hdr_MAP) + smf99_ser...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 2 server sample data BASED(addr(smf_hdr_MAP) + smf99_ser..."""
SMF99_QDATA_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_QDATA_MAP',
    record=record,
    parent=SMF99_S2_PER_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 2 queue server data BASED(addr(smf_hdr_MAP) + smf99_serv...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 2 queue server data BASED(addr(smf_hdr_MAP) + smf99_serv..."""
SMF99_IOSUB_SAMPLES_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_IOSUB_SAMPLES_MAP',
    record=record,
    parent=SMF99_S2_PER_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 SUBTYPE 2 AND 8 I/O SUBSYSTEM SAMPLES DATA. SUBTYPE 2: BASED(ADD...',
    post=None,
    record_mapping=False)
"""SMF99 SUBTYPE 2 AND 8 I/O SUBSYSTEM SAMPLES DATA. SUBTYPE 2: BASED(ADD..."""
SMF99_SPECRPT: Final[RecordMap] = RecordMap(
    origin='SMF99_SPECRPT',
    record=record,
    parent=SMF99_S2_PER_MAP,
    is_multiple=True,
    is_compound=True,
    spec='Special reporting data',
    post=None,
    record_mapping=False)
"""Special reporting data"""
SMF99_S2_AI_DATA_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S2_AI_DATA_MAP',
    record=record,
    parent=SMF99_S2_PER_MAP,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
SMF99_RQDATA_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_RQDATA_MAP',
    record=record,
    parent=SMF99_QDATA_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 2 remote queue server data. Contains information on the ...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 2 remote queue server data. Contains information on the ..."""

date : Final[Field] = Field(
    name='date',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S2`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S2`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S2`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S2`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF99LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S2`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""
len.__doc__ = """Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S2`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF99SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S2`
    Map: Not part of a map

Segment descriptor (see record length field)
"""
seg.__doc__ = """Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S2`
    Map: Not part of a map

Segment descriptor (see record length field)
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF99FLG',
    type=FieldType.STRING,
    record=record,
)
"""System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S2`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""
flg.__doc__ = """System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S2`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""

stu : Final[Field] = Field(
    name='stu',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S2`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
stu.__doc__ = """Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S2`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF99RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S2`
    Map: Not part of a map

Record type 99
"""
rty.__doc__ = """Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S2`
    Map: Not part of a map

Record type 99
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S2`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""
tme.__doc__ = """Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S2`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S2`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""
dte.__doc__ = """Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S2`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF99SID',
    type=FieldType.STRING,
    record=record,
)
"""System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S2`
    Map: Not part of a map

System identification (from the SID parameter).
"""
sid.__doc__ = """System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S2`
    Map: Not part of a map

System identification (from the SID parameter).
"""

ssid : Final[Field] = Field(
    name='ssid',
    origin='SMF99SSID',
    type=FieldType.STRING,
    record=record,
)
"""Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S2`
    Map: Not part of a map

Sub System Identification
"""
ssid.__doc__ = """Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S2`
    Map: Not part of a map

Sub System Identification
"""

tid : Final[Field] = Field(
    name='tid',
    origin='SMF99TID',
    type=FieldType.INTEGER,
    record=record,
)
"""Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S2`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""
tid.__doc__ = """Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S2`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""

sdef_len : Final[Field] = Field(
    name='sdef_len',
    origin='SMF99_SDEF_LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S2`
    Map: Not part of a map

Length of self definition section
"""
sdef_len.__doc__ = """Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S2`
    Map: Not part of a map

Length of self definition section
"""

pof : Final[Field] = Field(
    name='pof',
    origin='SMF99POF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""
pof.__doc__ = """Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""

pln : Final[Field] = Field(
    name='pln',
    origin='SMF99PLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""
pln.__doc__ = """Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""

pon : Final[Field] = Field(
    name='pon',
    origin='SMF99PON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""
pon.__doc__ = """Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""

dof : Final[Field] = Field(
    name='dof',
    origin='SMF99DOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""
dof.__doc__ = """Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""

dln : Final[Field] = Field(
    name='dln',
    origin='SMF99DLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""
dln.__doc__ = """Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""

don : Final[Field] = Field(
    name='don',
    origin='SMF99DON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""
don.__doc__ = """Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S2`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""

vn2 : Final[Field] = Field(
    name='vn2',
    origin='SMF99VN2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""
vn2.__doc__ = """Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""

rvn : Final[Field] = Field(
    name='rvn',
    origin='SMF99RVN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""
rvn.__doc__ = """Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""

pnm : Final[Field] = Field(
    name='pnm',
    origin='SMF99PNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""
pnm.__doc__ = """Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""

slv : Final[Field] = Field(
    name='slv',
    origin='SMF99SLV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""
slv.__doc__ = """System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF99SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""
snm.__doc__ = """System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""

pflg : Final[Field] = Field(
    name='pflg',
    origin='SMF99PFLG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""
pflg.__doc__ = """Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""

record_incomplete : Final[Field] = Field(
    name='record_incomplete',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
record_incomplete.__doc__ = """Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

reasm_indicator : Final[Field] = Field(
    name='reasm_indicator',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
reasm_indicator.__doc__ = """Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S2`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

cof : Final[Field] = Field(
    name='cof',
    origin='SMF992COF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_SDEF_MAP,
)
"""Offset to class information from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF992COF`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Offset to class information from beginning of record (including RDW)
"""
cof.__doc__ = """Offset to class information from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF992COF`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Offset to class information from beginning of record (including RDW)
"""

cln : Final[Field] = Field(
    name='cln',
    origin='SMF992CLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_SDEF_MAP,
)
"""Length of class information

SMF Info
--------
    Field: `SMF992CLN`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Length of class information
"""
cln.__doc__ = """Length of class information

SMF Info
--------
    Field: `SMF992CLN`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Length of class information
"""

con : Final[Field] = Field(
    name='con',
    origin='SMF992CON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_SDEF_MAP,
)
"""Number of class information

SMF Info
--------
    Field: `SMF992CON`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Number of class information
"""
con.__doc__ = """Number of class information

SMF Info
--------
    Field: `SMF992CON`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Number of class information
"""

cpof : Final[Field] = Field(
    name='cpof',
    origin='SMF992CPOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_SDEF_MAP,
)
"""Offset to class period section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF992CPOF`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Offset to class period section from beginning of record (including RDW)
"""
cpof.__doc__ = """Offset to class period section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF992CPOF`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Offset to class period section from beginning of record (including RDW)
"""

cpln : Final[Field] = Field(
    name='cpln',
    origin='SMF992CPLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_SDEF_MAP,
)
"""Length of class period section

SMF Info
--------
    Field: `SMF992CPLN`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Length of class period section
"""
cpln.__doc__ = """Length of class period section

SMF Info
--------
    Field: `SMF992CPLN`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Length of class period section
"""

cpon : Final[Field] = Field(
    name='cpon',
    origin='SMF992CPON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_SDEF_MAP,
)
"""Number of class period section

SMF Info
--------
    Field: `SMF992CPON`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Number of class period section
"""
cpon.__doc__ = """Number of class period section

SMF Info
--------
    Field: `SMF992CPON`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Number of class period section
"""

ecof : Final[Field] = Field(
    name='ecof',
    origin='SMF992ECOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_SDEF_MAP,
)
"""Offset to EWLM class section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF992ECOF`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Offset to EWLM class section from beginning of record (including RDW)
"""
ecof.__doc__ = """Offset to EWLM class section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF992ECOF`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Offset to EWLM class section from beginning of record (including RDW)
"""

ecln : Final[Field] = Field(
    name='ecln',
    origin='SMF992ECLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_SDEF_MAP,
)
"""Length of EWLM class section.

SMF Info
--------
    Field: `SMF992ECLN`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Length of EWLM class section.
"""
ecln.__doc__ = """Length of EWLM class section.

SMF Info
--------
    Field: `SMF992ECLN`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Length of EWLM class section.
"""

econ : Final[Field] = Field(
    name='econ',
    origin='SMF992ECON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_SDEF_MAP,
)
"""Number of EWLM class section.

SMF Info
--------
    Field: `SMF992ECON`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Number of EWLM class section.
"""
econ.__doc__ = """Number of EWLM class section.

SMF Info
--------
    Field: `SMF992ECON`
    Record: `SMF99S2`
    Map: `SMF99_S2_SDEF_MAP`

Number of EWLM class section.
"""

srv_class_name : Final[Field] = Field(
    name='srv_class_name',
    origin='SMF99_CNAM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_CLS_MAP,
)
"""service class name

SMF Info
--------
    Field: `SMF99_CNAM`
    Record: `SMF99S2`
    Map: `SMF99_S2_CLS_MAP`

service class name
"""
srv_class_name.__doc__ = """service class name

SMF Info
--------
    Field: `SMF99_CNAM`
    Record: `SMF99S2`
    Map: `SMF99_S2_CLS_MAP`

service class name
"""

res_group_name : Final[Field] = Field(
    name='res_group_name',
    origin='SMF99_CGRN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_CLS_MAP,
)
"""group name or blank if class doesn't belong to a group

SMF Info
--------
    Field: `SMF99_CGRN`
    Record: `SMF99S2`
    Map: `SMF99_S2_CLS_MAP`

group name or blank if class doesn't belong to a group
"""
res_group_name.__doc__ = """group name or blank if class doesn't belong to a group

SMF Info
--------
    Field: `SMF99_CGRN`
    Record: `SMF99S2`
    Map: `SMF99_S2_CLS_MAP`

group name or blank if class doesn't belong to a group
"""

num_srv_period : Final[Field] = Field(
    name='num_srv_period',
    origin='SMF99_CNUMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_CLS_MAP,
)
"""number of periods in the class

SMF Info
--------
    Field: `SMF99_CNUMP`
    Record: `SMF99S2`
    Map: `SMF99_S2_CLS_MAP`

number of periods in the class
"""
num_srv_period.__doc__ = """number of periods in the class

SMF Info
--------
    Field: `SMF99_CNUMP`
    Record: `SMF99S2`
    Map: `SMF99_S2_CLS_MAP`

number of periods in the class
"""

srv_class_idx : Final[Field] = Field(
    name='srv_class_idx',
    origin='SMF99_CINDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_CLS_MAP,
)
"""service class index

SMF Info
--------
    Field: `SMF99_CINDEX`
    Record: `SMF99S2`
    Map: `SMF99_S2_CLS_MAP`

service class index
"""
srv_class_idx.__doc__ = """service class index

SMF Info
--------
    Field: `SMF99_CINDEX`
    Record: `SMF99S2`
    Map: `SMF99_S2_CLS_MAP`

service class index
"""

pcnm : Final[Field] = Field(
    name='pcnm',
    origin='SMF99_PCNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Internal service class name

SMF Info
--------
    Field: `SMF99_PCNM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Internal service class name
"""
pcnm.__doc__ = """Internal service class name

SMF Info
--------
    Field: `SMF99_PCNM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Internal service class name
"""

period_num : Final[Field] = Field(
    name='period_num',
    origin='SMF99_PNUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""period number

SMF Info
--------
    Field: `SMF99_PNUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

period number
"""
period_num.__doc__ = """period number

SMF Info
--------
    Field: `SMF99_PNUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

period number
"""

goal_type : Final[Field] = Field(
    name='goal_type',
    origin='SMF99_PGOALTYP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""goal type: 1 - short response time, 2 - long response time, 3 - velocity, 4 - discretionary

SMF Info
--------
    Field: `SMF99_PGOALTYP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

goal type: 1 - short response time, 2 - long response time, 3 - velocity, 4 - discretionary
"""
goal_type.__doc__ = """goal type: 1 - short response time, 2 - long response time, 3 - velocity, 4 - discretionary

SMF Info
--------
    Field: `SMF99_PGOALTYP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

goal type: 1 - short response time, 2 - long response time, 3 - velocity, 4 - discretionary
"""

goal_value : Final[Field] = Field(
    name='goal_value',
    origin='SMF99_PGOALVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""goal value: response time goal - goal in milliseconds, velocity - velocity, discretionary - zero

SMF Info
--------
    Field: `SMF99_PGOALVAL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

goal value: response time goal - goal in milliseconds, velocity - velocity, discretionary - zero
"""
goal_value.__doc__ = """goal value: response time goal - goal in milliseconds, velocity - velocity, discretionary - zero

SMF Info
--------
    Field: `SMF99_PGOALVAL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

goal value: response time goal - goal in milliseconds, velocity - velocity, discretionary - zero
"""

period_imp : Final[Field] = Field(
    name='period_imp',
    origin='SMF99_PIMPOR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""importance

SMF Info
--------
    Field: `SMF99_PIMPOR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

importance
"""
period_imp.__doc__ = """importance

SMF Info
--------
    Field: `SMF99_PIMPOR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

importance
"""

disp_prio : Final[Field] = Field(
    name='disp_prio',
    origin='SMF99_PBDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""base dispatching priority

SMF Info
--------
    Field: `SMF99_PBDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

base dispatching priority
"""
disp_prio.__doc__ = """base dispatching priority

SMF Info
--------
    Field: `SMF99_PBDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

base dispatching priority
"""

mpl_in : Final[Field] = Field(
    name='mpl_in',
    origin='SMF99_PMPLI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""MPL in-target

SMF Info
--------
    Field: `SMF99_PMPLI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

MPL in-target
"""
mpl_in.__doc__ = """MPL in-target

SMF Info
--------
    Field: `SMF99_PMPLI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

MPL in-target
"""

mpl_out : Final[Field] = Field(
    name='mpl_out',
    origin='SMF99_PMPLO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""MPL out-target

SMF Info
--------
    Field: `SMF99_PMPLO`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

MPL out-target
"""
mpl_out.__doc__ = """MPL out-target

SMF Info
--------
    Field: `SMF99_PMPLO`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

MPL out-target
"""

mpl_av : Final[Field] = Field(
    name='mpl_av',
    origin='SMF99_PAMTA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Average Maximum MPL Target achieved

SMF Info
--------
    Field: `SMF99_PAMTA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average Maximum MPL Target achieved
"""
mpl_av.__doc__ = """Average Maximum MPL Target achieved

SMF Info
--------
    Field: `SMF99_PAMTA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average Maximum MPL Target achieved
"""

ready_user_av : Final[Field] = Field(
    name='ready_user_av',
    origin='SMF99_PRUA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Ready user average

SMF Info
--------
    Field: `SMF99_PRUA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Ready user average
"""
ready_user_av.__doc__ = """Ready user average

SMF Info
--------
    Field: `SMF99_PRUA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Ready user average
"""

plrua : Final[Field] = Field(
    name='plrua',
    origin='SMF99_PLRUA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Long term Ready User Average times 16

SMF Info
--------
    Field: `SMF99_PLRUA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Long term Ready User Average times 16
"""
plrua.__doc__ = """Long term Ready User Average times 16

SMF Info
--------
    Field: `SMF99_PLRUA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Long term Ready User Average times 16
"""

ppspt : Final[Field] = Field(
    name='ppspt',
    origin='SMF99_PPSPT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""length of time swapped address spaces are protected in processor storage

SMF Info
--------
    Field: `SMF99_PPSPT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of time swapped address spaces are protected in processor storage
"""
ppspt.__doc__ = """length of time swapped address spaces are protected in processor storage

SMF Info
--------
    Field: `SMF99_PPSPT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of time swapped address spaces are protected in processor storage
"""

ppsitar : Final[Field] = Field(
    name='ppsitar',
    origin='SMF99_PPSITAR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""storage isolation target for each address space in period, valid only for work with short response time goals, zero otherwise

SMF Info
--------
    Field: `SMF99_PPSITAR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

storage isolation target for each address space in period, valid only for work with short response time goals, zero otherwise
"""
ppsitar.__doc__ = """storage isolation target for each address space in period, valid only for work with short response time goals, zero otherwise

SMF Info
--------
    Field: `SMF99_PPSITAR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

storage isolation target for each address space in period, valid only for work with short response time goals, zero otherwise
"""

pespol : Final[Field] = Field(
    name='pespol',
    origin='SMF99_PESPOL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""expanded storage access policy for demand pages - valid for periods with short resp time goals only

SMF Info
--------
    Field: `SMF99_PESPOL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

expanded storage access policy for demand pages - valid for periods with short resp time goals only
"""
pespol.__doc__ = """expanded storage access policy for demand pages - valid for periods with short resp time goals only

SMF Info
--------
    Field: `SMF99_PESPOL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

expanded storage access policy for demand pages - valid for periods with short resp time goals only
"""

pesvio : Final[Field] = Field(
    name='pesvio',
    origin='SMF99_PESVIO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""expanded storage access policy for VIO pages - valid for periods with short resp time goals only

SMF Info
--------
    Field: `SMF99_PESVIO`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

expanded storage access policy for VIO pages - valid for periods with short resp time goals only
"""
pesvio.__doc__ = """expanded storage access policy for VIO pages - valid for periods with short resp time goals only

SMF Info
--------
    Field: `SMF99_PESVIO`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

expanded storage access policy for VIO pages - valid for periods with short resp time goals only
"""

peshsp : Final[Field] = Field(
    name='peshsp',
    origin='SMF99_PESHSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""expanded storage access policy for hiperspace pages - valid for periods with short resp time goals only

SMF Info
--------
    Field: `SMF99_PESHSP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

expanded storage access policy for hiperspace pages - valid for periods with short resp time goals only
"""
peshsp.__doc__ = """expanded storage access policy for hiperspace pages - valid for periods with short resp time goals only

SMF Info
--------
    Field: `SMF99_PESHSP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

expanded storage access policy for hiperspace pages - valid for periods with short resp time goals only
"""

pesswap : Final[Field] = Field(
    name='pesswap',
    origin='SMF99_PESSWAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""expanded storage access policy for swap pages - valid for periods with short resp time goals only

SMF Info
--------
    Field: `SMF99_PESSWAP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

expanded storage access policy for swap pages - valid for periods with short resp time goals only
"""
pesswap.__doc__ = """expanded storage access policy for swap pages - valid for periods with short resp time goals only

SMF Info
--------
    Field: `SMF99_PESSWAP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

expanded storage access policy for swap pages - valid for periods with short resp time goals only
"""

pprot : Final[Field] = Field(
    name='pprot',
    origin='SMF99_PPROT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of address spaces with demand pages protected in processor storage - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PPROT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with demand pages protected in processor storage - NA for periods with short resp time goals
"""
pprot.__doc__ = """number of address spaces with demand pages protected in processor storage - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PPROT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with demand pages protected in processor storage - NA for periods with short resp time goals
"""

plru : Final[Field] = Field(
    name='plru',
    origin='SMF99_PLRU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of address spaces with demand pages subject to lru expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PLRU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with demand pages subject to lru expanded storage policy - NA for periods with short resp time goals
"""
plru.__doc__ = """number of address spaces with demand pages subject to lru expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PLRU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with demand pages subject to lru expanded storage policy - NA for periods with short resp time goals
"""

pspav : Final[Field] = Field(
    name='pspav',
    origin='SMF99_PSPAV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of address spaces with demand pages subject to space available expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PSPAV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with demand pages subject to space available expanded storage policy - NA for periods with short resp time goals
"""
pspav.__doc__ = """number of address spaces with demand pages subject to space available expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PSPAV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with demand pages subject to space available expanded storage policy - NA for periods with short resp time goals
"""

pviol : Final[Field] = Field(
    name='pviol',
    origin='SMF99_PVIOL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of address spaces with VIO pages subject to lru expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PVIOL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with VIO pages subject to lru expanded storage policy - NA for periods with short resp time goals
"""
pviol.__doc__ = """number of address spaces with VIO pages subject to lru expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PVIOL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with VIO pages subject to lru expanded storage policy - NA for periods with short resp time goals
"""

pvios : Final[Field] = Field(
    name='pvios',
    origin='SMF99_PVIOS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of address spaces with VIO pages subject to space available expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PVIOS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with VIO pages subject to space available expanded storage policy - NA for periods with short resp time goals
"""
pvios.__doc__ = """number of address spaces with VIO pages subject to space available expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PVIOS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with VIO pages subject to space available expanded storage policy - NA for periods with short resp time goals
"""

phspl : Final[Field] = Field(
    name='phspl',
    origin='SMF99_PHSPL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of address spaces with hiperspace pages subject to lru expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PHSPL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with hiperspace pages subject to lru expanded storage policy - NA for periods with short resp time goals
"""
phspl.__doc__ = """number of address spaces with hiperspace pages subject to lru expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PHSPL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with hiperspace pages subject to lru expanded storage policy - NA for periods with short resp time goals
"""

phsps : Final[Field] = Field(
    name='phsps',
    origin='SMF99_PHSPS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of address spaces with hiperspace pages subject to space available expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PHSPS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with hiperspace pages subject to space available expanded storage policy - NA for periods with short resp time goals
"""
phsps.__doc__ = """number of address spaces with hiperspace pages subject to space available expanded storage policy - NA for periods with short resp time goals

SMF Info
--------
    Field: `SMF99_PHSPS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of address spaces with hiperspace pages subject to space available expanded storage policy - NA for periods with short resp time goals
"""

pescs : Final[Field] = Field(
    name='pescs',
    origin='SMF99_PESCS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of explicit storage critical classified address spaces

SMF Info
--------
    Field: `SMF99_PESCS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of explicit storage critical classified address spaces
"""
pescs.__doc__ = """number of explicit storage critical classified address spaces

SMF Info
--------
    Field: `SMF99_PESCS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of explicit storage critical classified address spaces
"""

pi_local : Final[Field] = Field(
    name='pi_local',
    origin='SMF99_PLPI',
    post='core.scale',
    post_param=100.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""local performance index

SMF Info
--------
    Field: `SMF99_PLPI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

local performance index

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `100.0`
"""
pi_local.__doc__ = """local performance index

SMF Info
--------
    Field: `SMF99_PLPI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

local performance index

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `100.0`
"""

pi_sysplex : Final[Field] = Field(
    name='pi_sysplex',
    origin='SMF99_PSPI',
    post='core.scale',
    post_param=100.0,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""sysplex performance index

SMF Info
--------
    Field: `SMF99_PSPI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

sysplex performance index

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `100.0`
"""
pi_sysplex.__doc__ = """sysplex performance index

SMF Info
--------
    Field: `SMF99_PSPI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

sysplex performance index

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `100.0`
"""

srv_cp_service : Final[Field] = Field(
    name='srv_cp_service',
    origin='SMF99_PSERV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""service accumulated during interval

SMF Info
--------
    Field: `SMF99_PSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

service accumulated during interval
"""
srv_cp_service.__doc__ = """service accumulated during interval

SMF Info
--------
    Field: `SMF99_PSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

service accumulated during interval
"""

pmdp : Final[Field] = Field(
    name='pmdp',
    origin='SMF99_PMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""maximum percentage of processor time demanded

SMF Info
--------
    Field: `SMF99_PMDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

maximum percentage of processor time demanded
"""
pmdp.__doc__ = """maximum percentage of processor time demanded

SMF Info
--------
    Field: `SMF99_PMDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

maximum percentage of processor time demanded
"""

plcpuu : Final[Field] = Field(
    name='plcpuu',
    origin='SMF99_PLCPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""CPU using samples during last interval

SMF Info
--------
    Field: `SMF99_PLCPUU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

CPU using samples during last interval
"""
plcpuu.__doc__ = """CPU using samples during last interval

SMF Info
--------
    Field: `SMF99_PLCPUU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

CPU using samples during last interval
"""

plcpud : Final[Field] = Field(
    name='plcpud',
    origin='SMF99_PLCPUD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""CPU delay samples during last interval

SMF Info
--------
    Field: `SMF99_PLCPUD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

CPU delay samples during last interval
"""
plcpud.__doc__ = """CPU delay samples during last interval

SMF Info
--------
    Field: `SMF99_PLCPUD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

CPU delay samples during last interval
"""

pmttwa : Final[Field] = Field(
    name='pmttwa',
    origin='SMF99_PMTTWA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Mean time to wait adjusted

SMF Info
--------
    Field: `SMF99_PMTTWA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Mean time to wait adjusted
"""
pmttwa.__doc__ = """Mean time to wait adjusted

SMF Info
--------
    Field: `SMF99_PMTTWA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Mean time to wait adjusted
"""

padp : Final[Field] = Field(
    name='padp',
    origin='SMF99_PADP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""working variable for achievable demand percentage

SMF Info
--------
    Field: `SMF99_PADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

working variable for achievable demand percentage
"""
padp.__doc__ = """working variable for achievable demand percentage

SMF Info
--------
    Field: `SMF99_PADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

working variable for achievable demand percentage
"""

paserc : Final[Field] = Field(
    name='paserc',
    origin='SMF99_PASERC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Average service consumed over window

SMF Info
--------
    Field: `SMF99_PASERC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average service consumed over window
"""
paserc.__doc__ = """Average service consumed over window

SMF Info
--------
    Field: `SMF99_PASERC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average service consumed over window
"""

pprser : Final[Field] = Field(
    name='pprser',
    origin='SMF99_PPRSER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Projected service

SMF Info
--------
    Field: `SMF99_PPRSER`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Projected service
"""
pprser.__doc__ = """Projected service

SMF Info
--------
    Field: `SMF99_PPRSER`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Projected service
"""

idle : Final[Field] = Field(
    name='idle',
    origin='SMF99_PIDLE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""idle samples

SMF Info
--------
    Field: `SMF99_PIDLE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

idle samples
"""
idle.__doc__ = """idle samples

SMF Info
--------
    Field: `SMF99_PIDLE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

idle samples
"""

pothr : Final[Field] = Field(
    name='pothr',
    origin='SMF99_POTHR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""all other states

SMF Info
--------
    Field: `SMF99_POTHR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

all other states
"""
pothr.__doc__ = """all other states

SMF Info
--------
    Field: `SMF99_POTHR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

all other states
"""

cpu_using : Final[Field] = Field(
    name='cpu_using',
    origin='SMF99_PCPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""processor using samples

SMF Info
--------
    Field: `SMF99_PCPUU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

processor using samples
"""
cpu_using.__doc__ = """processor using samples

SMF Info
--------
    Field: `SMF99_PCPUU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

processor using samples
"""

cpu_delay : Final[Field] = Field(
    name='cpu_delay',
    origin='SMF99_PCPUD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""processor delay samples

SMF Info
--------
    Field: `SMF99_PCPUD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

processor delay samples
"""
cpu_delay.__doc__ = """processor delay samples

SMF Info
--------
    Field: `SMF99_PCPUD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

processor delay samples
"""

pauxp : Final[Field] = Field(
    name='pauxp',
    origin='SMF99_PAUXP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""primary private area paging delay aux

SMF Info
--------
    Field: `SMF99_PAUXP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

primary private area paging delay aux
"""
pauxp.__doc__ = """primary private area paging delay aux

SMF Info
--------
    Field: `SMF99_PAUXP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

primary private area paging delay aux
"""

pauxc : Final[Field] = Field(
    name='pauxc',
    origin='SMF99_PAUXC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Common area paging delay from aux

SMF Info
--------
    Field: `SMF99_PAUXC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Common area paging delay from aux
"""
pauxc.__doc__ = """Common area paging delay from aux

SMF Info
--------
    Field: `SMF99_PAUXC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Common area paging delay from aux
"""

pvio : Final[Field] = Field(
    name='pvio',
    origin='SMF99_PVIO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""VIO delay from aux

SMF Info
--------
    Field: `SMF99_PVIO`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

VIO delay from aux
"""
pvio.__doc__ = """VIO delay from aux

SMF Info
--------
    Field: `SMF99_PVIO`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

VIO delay from aux
"""

phss : Final[Field] = Field(
    name='phss',
    origin='SMF99_PHSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Scrolling hyperspace delay

SMF Info
--------
    Field: `SMF99_PHSS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Scrolling hyperspace delay
"""
phss.__doc__ = """Scrolling hyperspace delay

SMF Info
--------
    Field: `SMF99_PHSS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Scrolling hyperspace delay
"""

phsc : Final[Field] = Field(
    name='phsc',
    origin='SMF99_PHSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Cache hyperspace delay

SMF Info
--------
    Field: `SMF99_PHSC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Cache hyperspace delay
"""
phsc.__doc__ = """Cache hyperspace delay

SMF Info
--------
    Field: `SMF99_PHSC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Cache hyperspace delay
"""

paswp : Final[Field] = Field(
    name='paswp',
    origin='SMF99_PASWP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Aux swap delay

SMF Info
--------
    Field: `SMF99_PASWP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Aux swap delay
"""
paswp.__doc__ = """Aux swap delay

SMF Info
--------
    Field: `SMF99_PASWP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Aux swap delay
"""

mpl_delay : Final[Field] = Field(
    name='mpl_delay',
    origin='SMF99_PMPLD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""MPL Delay

SMF Info
--------
    Field: `SMF99_PMPLD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

MPL Delay
"""
mpl_delay.__doc__ = """MPL Delay

SMF Info
--------
    Field: `SMF99_PMPLD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

MPL Delay
"""

cap_delay : Final[Field] = Field(
    name='cap_delay',
    origin='SMF99_PCAPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""CPU CAP delay

SMF Info
--------
    Field: `SMF99_PCAPD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

CPU CAP delay
"""
cap_delay.__doc__ = """CPU CAP delay

SMF Info
--------
    Field: `SMF99_PCAPD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

CPU CAP delay
"""

cross_mem_delay : Final[Field] = Field(
    name='cross_mem_delay',
    origin='SMF99_PXMO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Cross memory other delays

SMF Info
--------
    Field: `SMF99_PXMO`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Cross memory other delays
"""
cross_mem_delay.__doc__ = """Cross memory other delays

SMF Info
--------
    Field: `SMF99_PXMO`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Cross memory other delays
"""

pxmem_of : Final[Field] = Field(
    name='pxmem_of',
    origin='SMF99_PXMEM_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""offset to cross memory delay samples from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PXMEM_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to cross memory delay samples from beginning of record (including RDW)
"""
pxmem_of.__doc__ = """offset to cross memory delay samples from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PXMEM_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to cross memory delay samples from beginning of record (including RDW)
"""

pxmem_ln : Final[Field] = Field(
    name='pxmem_ln',
    origin='SMF99_PXMEM_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""length of each cross memory delay entry

SMF Info
--------
    Field: `SMF99_PXMEM_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each cross memory delay entry
"""
pxmem_ln.__doc__ = """length of each cross memory delay entry

SMF Info
--------
    Field: `SMF99_PXMEM_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each cross memory delay entry
"""

pxmem_on : Final[Field] = Field(
    name='pxmem_on',
    origin='SMF99_PXMEM_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of cross memory delay samples

SMF Info
--------
    Field: `SMF99_PXMEM_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of cross memory delay samples
"""
pxmem_on.__doc__ = """number of cross memory delay samples

SMF Info
--------
    Field: `SMF99_PXMEM_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of cross memory delay samples
"""

pserv_of : Final[Field] = Field(
    name='pserv_of',
    origin='SMF99_PSERV_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""offset to server section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PSERV_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to server section from beginning of record (including RDW)
"""
pserv_of.__doc__ = """offset to server section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PSERV_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to server section from beginning of record (including RDW)
"""

pserv_ln : Final[Field] = Field(
    name='pserv_ln',
    origin='SMF99_PSERV_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""length of each server entry

SMF Info
--------
    Field: `SMF99_PSERV_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each server entry
"""
pserv_ln.__doc__ = """length of each server entry

SMF Info
--------
    Field: `SMF99_PSERV_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each server entry
"""

pserv_on : Final[Field] = Field(
    name='pserv_on',
    origin='SMF99_PSERV_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of server entries

SMF Info
--------
    Field: `SMF99_PSERV_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of server entries
"""
pserv_on.__doc__ = """number of server entries

SMF Info
--------
    Field: `SMF99_PSERV_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of server entries
"""

pesp_of : Final[Field] = Field(
    name='pesp_of',
    origin='SMF99_PESP_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""offset to address space expanded storage access policies section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PESP_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to address space expanded storage access policies section from beginning of record (including RDW)
"""
pesp_of.__doc__ = """offset to address space expanded storage access policies section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PESP_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to address space expanded storage access policies section from beginning of record (including RDW)
"""

pesp_ln : Final[Field] = Field(
    name='pesp_ln',
    origin='SMF99_PESP_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""length of each AS ESP entry

SMF Info
--------
    Field: `SMF99_PESP_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each AS ESP entry
"""
pesp_ln.__doc__ = """length of each AS ESP entry

SMF Info
--------
    Field: `SMF99_PESP_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each AS ESP entry
"""

pesp_on : Final[Field] = Field(
    name='pesp_on',
    origin='SMF99_PESP_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of AS ESP entries

SMF Info
--------
    Field: `SMF99_PESP_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of AS ESP entries
"""
pesp_on.__doc__ = """number of AS ESP entries

SMF Info
--------
    Field: `SMF99_PESP_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of AS ESP entries
"""

pcdclock : Final[Field] = Field(
    name='pcdclock',
    origin='SMF99_PCDCLOCK',
    post='core.hex2int',
    post_param=None,
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""policy adjustment count down clock, no policy action is taken until clock is zero

SMF Info
--------
    Field: `SMF99_PCDCLOCK`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

policy adjustment count down clock, no policy action is taken until clock is zero

Post Processing (`core.hex2int`)
---------------
No post-processing parameter defined
"""
pcdclock.__doc__ = """policy adjustment count down clock, no policy action is taken until clock is zero

SMF Info
--------
    Field: `SMF99_PCDCLOCK`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

policy adjustment count down clock, no policy action is taken until clock is zero

Post Processing (`core.hex2int`)
---------------
No post-processing parameter defined
"""

pnh : Final[Field] = Field(
    name='pnh',
    origin='SMF99_PNH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""period experienced processor access or storage delay during last policy adjustment interval

SMF Info
--------
    Field: `SMF99_PNH`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

period experienced processor access or storage delay during last policy adjustment interval
"""
pnh.__doc__ = """period experienced processor access or storage delay during last policy adjustment interval

SMF Info
--------
    Field: `SMF99_PNH`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

period experienced processor access or storage delay during last policy adjustment interval
"""

prtp : Final[Field] = Field(
    name='prtp',
    origin='SMF99_PRTP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Response time goal percentile. Zero if period does not have a percentile response time goal.

SMF Info
--------
    Field: `SMF99_PRTP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time goal percentile. Zero if period does not have a percentile response time goal.
"""
prtp.__doc__ = """Response time goal percentile. Zero if period does not have a percentile response time goal.

SMF Info
--------
    Field: `SMF99_PRTP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time goal percentile. Zero if period does not have a percentile response time goal.
"""

pauxs : Final[Field] = Field(
    name='pauxs',
    origin='SMF99_PAUXS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""shared storage paging samples from aux

SMF Info
--------
    Field: `SMF99_PAUXS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

shared storage paging samples from aux
"""
pauxs.__doc__ = """shared storage paging samples from aux

SMF Info
--------
    Field: `SMF99_PAUXS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

shared storage paging samples from aux
"""

io_using : Final[Field] = Field(
    name='io_using',
    origin='SMF99_PIOU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""I/O using samples

SMF Info
--------
    Field: `SMF99_PIOU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

I/O using samples
"""
io_using.__doc__ = """I/O using samples

SMF Info
--------
    Field: `SMF99_PIOU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

I/O using samples
"""

io_delay : Final[Field] = Field(
    name='io_delay',
    origin='SMF99_PIOD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""I/O delay samples

SMF Info
--------
    Field: `SMF99_PIOD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

I/O delay samples
"""
io_delay.__doc__ = """I/O delay samples

SMF Info
--------
    Field: `SMF99_PIOD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

I/O delay samples
"""

pio_mdp : Final[Field] = Field(
    name='pio_mdp',
    origin='SMF99_PIO_MDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""maximum percentage of time period could demand I/O. Percentage scaled by 10.

SMF Info
--------
    Field: `SMF99_PIO_MDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

maximum percentage of time period could demand I/O. Percentage scaled by 10.
"""
pio_mdp.__doc__ = """maximum percentage of time period could demand I/O. Percentage scaled by 10.

SMF Info
--------
    Field: `SMF99_PIO_MDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

maximum percentage of time period could demand I/O. Percentage scaled by 10.
"""

piodp : Final[Field] = Field(
    name='piodp',
    origin='SMF99_PIODP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""I/O priority

SMF Info
--------
    Field: `SMF99_PIODP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

I/O priority
"""
piodp.__doc__ = """I/O priority

SMF Info
--------
    Field: `SMF99_PIODP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

I/O priority
"""

flags : Final[Field] = Field(
    name='flags',
    origin='SMF99_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Flags

SMF Info
--------
    Field: `SMF99_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Flags
"""
flags.__doc__ = """Flags

SMF Info
--------
    Field: `SMF99_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Flags
"""

needs_sysplex_help : Final[Field] = Field(
    name='needs_sysplex_help',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Period experienced some type of delay within the sysplex during last policy adjustment interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period experienced some type of delay within the sysplex during last policy adjustment interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
needs_sysplex_help.__doc__ = """Period experienced some type of delay within the sysplex during last policy adjustment interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period experienced some type of delay within the sysplex during last policy adjustment interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cpu_critical : Final[Field] = Field(
    name='cpu_critical',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Period is cpu critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period is cpu critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cpu_critical.__doc__ = """Period is cpu critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period is cpu critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

stgcrit_implicit : Final[Field] = Field(
    name='stgcrit_implicit',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""period belongs to a service class that was assigned storage protection (stg critical) in the active service policy. The service class was used in subsystem type CICS or IMS and the rule specified storage critical = yes. Also on for transactionserver DISPs serving protected service classes.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

period belongs to a service class that was assigned storage protection (stg critical) in the active service policy. The service class was used in subsystem type CICS or IMS and the rule specified storage critical = yes. Also on for transactionserver DISPs serving protected service classes.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
stgcrit_implicit.__doc__ = """period belongs to a service class that was assigned storage protection (stg critical) in the active service policy. The service class was used in subsystem type CICS or IMS and the rule specified storage critical = yes. Also on for transactionserver DISPs serving protected service classes.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

period belongs to a service class that was assigned storage protection (stg critical) in the active service policy. The service class was used in subsystem type CICS or IMS and the rule specified storage critical = yes. Also on for transactionserver DISPs serving protected service classes.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

non_zos : Final[Field] = Field(
    name='non_zos',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Indicates that the period is non-z/OS (Linux)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Indicates that the period is non-z/OS (Linux)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
non_zos.__doc__ = """Indicates that the period is non-z/OS (Linux)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Indicates that the period is non-z/OS (Linux)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

has_near_blocked_as : Final[Field] = Field(
    name='has_near_blocked_as',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Period has an address space that is close to being blocked.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period has an address space that is close to being blocked.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
has_near_blocked_as.__doc__ = """Period has an address space that is close to being blocked.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period has an address space that is close to being blocked.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ewlm_managed : Final[Field] = Field(
    name='ewlm_managed',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Period is managed using EWLM performance data.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period is managed using EWLM performance data.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ewlm_managed.__doc__ = """Period is managed using EWLM performance data.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period is managed using EWLM performance data.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

io_priority_group : Final[Field] = Field(
    name='io_priority_group',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Period belongs to a service class that was assigned to I/O priority group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period belongs to a service class that was assigned to I/O priority group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
io_priority_group.__doc__ = """Period belongs to a service class that was assigned to I/O priority group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Period belongs to a service class that was assigned to I/O priority group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

trxspecrpt : Final[Field] = Field(
    name='trxspecrpt',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Special reporting data available for the period(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Special reporting data available for the period

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
trxspecrpt.__doc__ = """Special reporting data available for the period(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF99_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Special reporting data available for the period

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

per_io_mgmt_support_data : Final[Field] = Field(
    name='per_io_mgmt_support_data',
    origin='SMF99_PER_IO_MGMT_SUPPORT_DATA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""I/O Management Support Data

SMF Info
--------
    Field: `SMF99_PER_IO_MGMT_SUPPORT_DATA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

I/O Management Support Data
"""
per_io_mgmt_support_data.__doc__ = """I/O Management Support Data

SMF Info
--------
    Field: `SMF99_PER_IO_MGMT_SUPPORT_DATA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

I/O Management Support Data
"""

pdevcl : Final[Field] = Field(
    name='pdevcl',
    origin='SMF99_PDEVCL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Identifier of device cluster period belongs to. This identifier can be used to associated the period with device cluster data in the subtype 4 record. Zero if the period is not associated with a device cluster

SMF Info
--------
    Field: `SMF99_PDEVCL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Identifier of device cluster period belongs to. This identifier can be used to associated the period with device cluster data in the subtype 4 record. Zero if the period is not associated with a device cluster
"""
pdevcl.__doc__ = """Identifier of device cluster period belongs to. This identifier can be used to associated the period with device cluster data in the subtype 4 record. Zero if the period is not associated with a device cluster

SMF Info
--------
    Field: `SMF99_PDEVCL`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Identifier of device cluster period belongs to. This identifier can be used to associated the period with device cluster data in the subtype 4 record. Zero if the period is not associated with a device cluster
"""

pserver_type : Final[Field] = Field(
    name='pserver_type',
    origin='SMF99_PSERVER_TYPE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Server type. No bits will be on if period is not a server

SMF Info
--------
    Field: `SMF99_PSERVER_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Server type. No bits will be on if period is not a server
"""
pserver_type.__doc__ = """Server type. No bits will be on if period is not a server

SMF Info
--------
    Field: `SMF99_PSERVER_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Server type. No bits will be on if period is not a server
"""

ptrans_server : Final[Field] = Field(
    name='ptrans_server',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pserver_type,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Server is a transaction server(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pserver_type`(`SMF99_PSERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Server is a transaction server

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
ptrans_server.__doc__ = """Server is a transaction server(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pserver_type`(`SMF99_PSERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Server is a transaction server

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

penclave_server : Final[Field] = Field(
    name='penclave_server',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pserver_type,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Server is a enclave server(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pserver_type`(`SMF99_PSERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Server is a enclave server

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
penclave_server.__doc__ = """Server is a enclave server(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pserver_type`(`SMF99_PSERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Server is a enclave server

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

pqueue_server : Final[Field] = Field(
    name='pqueue_server',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=pserver_type,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Server is a queue server(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pserver_type`(`SMF99_PSERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Server is a queue server

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
pqueue_server.__doc__ = """Server is a queue server(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pserver_type`(`SMF99_PSERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Server is a queue server

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

psdata_of : Final[Field] = Field(
    name='psdata_of',
    origin='SMF99_PSDATA_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""offset to server samples section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PSDATA_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to server samples section from beginning of record (including RDW)
"""
psdata_of.__doc__ = """offset to server samples section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PSDATA_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to server samples section from beginning of record (including RDW)
"""

psdata_ln : Final[Field] = Field(
    name='psdata_ln',
    origin='SMF99_PSDATA_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""length of each server samples entry

SMF Info
--------
    Field: `SMF99_PSDATA_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each server samples entry
"""
psdata_ln.__doc__ = """length of each server samples entry

SMF Info
--------
    Field: `SMF99_PSDATA_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each server samples entry
"""

psdata_on : Final[Field] = Field(
    name='psdata_on',
    origin='SMF99_PSDATA_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of server samples entries

SMF Info
--------
    Field: `SMF99_PSDATA_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of server samples entries
"""
psdata_on.__doc__ = """number of server samples entries

SMF Info
--------
    Field: `SMF99_PSDATA_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of server samples entries
"""

pqdata_of : Final[Field] = Field(
    name='pqdata_of',
    origin='SMF99_PQDATA_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""offset to queue server section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PQDATA_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to queue server section from beginning of record (including RDW)
"""
pqdata_of.__doc__ = """offset to queue server section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_PQDATA_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

offset to queue server section from beginning of record (including RDW)
"""

pqdata_ln : Final[Field] = Field(
    name='pqdata_ln',
    origin='SMF99_PQDATA_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""length of each queue server entry

SMF Info
--------
    Field: `SMF99_PQDATA_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each queue server entry
"""
pqdata_ln.__doc__ = """length of each queue server entry

SMF Info
--------
    Field: `SMF99_PQDATA_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

length of each queue server entry
"""

pqdata_on : Final[Field] = Field(
    name='pqdata_on',
    origin='SMF99_PQDATA_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""number of queue server entries

SMF Info
--------
    Field: `SMF99_PQDATA_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of queue server entries
"""
pqdata_on.__doc__ = """number of queue server entries

SMF Info
--------
    Field: `SMF99_PQDATA_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

number of queue server entries
"""

pavg_size : Final[Field] = Field(
    name='pavg_size',
    origin='SMF99_PAVG_SIZE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Average size in processor storage (frame count) of address spaces in the period. zero otherwise

SMF Info
--------
    Field: `SMF99_PAVG_SIZE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average size in processor storage (frame count) of address spaces in the period. zero otherwise
"""
pavg_size.__doc__ = """Average size in processor storage (frame count) of address spaces in the period. zero otherwise

SMF Info
--------
    Field: `SMF99_PAVG_SIZE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average size in processor storage (frame count) of address spaces in the period. zero otherwise
"""

pgrn : Final[Field] = Field(
    name='pgrn',
    origin='SMF99_PGRN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""group name or blank if period doesn't belong to a group

SMF Info
--------
    Field: `SMF99_PGRN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

group name or blank if period doesn't belong to a group
"""
pgrn.__doc__ = """group name or blank if period doesn't belong to a group

SMF Info
--------
    Field: `SMF99_PGRN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

group name or blank if period doesn't belong to a group
"""

psys_cpuu : Final[Field] = Field(
    name='psys_cpuu',
    origin='SMF99_PSYS_CPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Sysplex wide CPU using samples

SMF Info
--------
    Field: `SMF99_PSYS_CPUU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide CPU using samples
"""
psys_cpuu.__doc__ = """Sysplex wide CPU using samples

SMF Info
--------
    Field: `SMF99_PSYS_CPUU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide CPU using samples
"""

psys_nonidle : Final[Field] = Field(
    name='psys_nonidle',
    origin='SMF99_PSYS_NONIDLE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Sysplex wide non-idle samples

SMF Info
--------
    Field: `SMF99_PSYS_NONIDLE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide non-idle samples
"""
psys_nonidle.__doc__ = """Sysplex wide non-idle samples

SMF Info
--------
    Field: `SMF99_PSYS_NONIDLE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide non-idle samples
"""

psys_idle : Final[Field] = Field(
    name='psys_idle',
    origin='SMF99_PSYS_IDLE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Sysplex wide idle samples

SMF Info
--------
    Field: `SMF99_PSYS_IDLE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide idle samples
"""
psys_idle.__doc__ = """Sysplex wide idle samples

SMF Info
--------
    Field: `SMF99_PSYS_IDLE`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide idle samples
"""

psys_other : Final[Field] = Field(
    name='psys_other',
    origin='SMF99_PSYS_OTHER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Sysplex wide other samples

SMF Info
--------
    Field: `SMF99_PSYS_OTHER`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide other samples
"""
psys_other.__doc__ = """Sysplex wide other samples

SMF Info
--------
    Field: `SMF99_PSYS_OTHER`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide other samples
"""

iosubsamof : Final[Field] = Field(
    name='iosubsamof',
    origin='SMF99_IOSUBSAMOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Offset to I/O subsystem samples data from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_IOSUBSAMOF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Offset to I/O subsystem samples data from beginning of record (including RDW)
"""
iosubsamof.__doc__ = """Offset to I/O subsystem samples data from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_IOSUBSAMOF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Offset to I/O subsystem samples data from beginning of record (including RDW)
"""

iosubsamln : Final[Field] = Field(
    name='iosubsamln',
    origin='SMF99_IOSUBSAMLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Length of a I/O subsystem samples data section

SMF Info
--------
    Field: `SMF99_IOSUBSAMLN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Length of a I/O subsystem samples data section
"""
iosubsamln.__doc__ = """Length of a I/O subsystem samples data section

SMF Info
--------
    Field: `SMF99_IOSUBSAMLN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Length of a I/O subsystem samples data section
"""

iosubsamon : Final[Field] = Field(
    name='iosubsamon',
    origin='SMF99_IOSUBSAMON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Number of I/O subsystem samples data sections

SMF Info
--------
    Field: `SMF99_IOSUBSAMON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Number of I/O subsystem samples data sections
"""
iosubsamon.__doc__ = """Number of I/O subsystem samples data sections

SMF Info
--------
    Field: `SMF99_IOSUBSAMON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Number of I/O subsystem samples data sections
"""

spmdp : Final[Field] = Field(
    name='spmdp',
    origin='SMF99_SPMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Saved copy of maximum percentage of processor time demanded

SMF Info
--------
    Field: `SMF99_SPMDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Saved copy of maximum percentage of processor time demanded
"""
spmdp.__doc__ = """Saved copy of maximum percentage of processor time demanded

SMF Info
--------
    Field: `SMF99_SPMDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Saved copy of maximum percentage of processor time demanded
"""

avg_num_tasks : Final[Field] = Field(
    name='avg_num_tasks',
    origin='SMF99_AVG_NUM_TASKS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""average number of tasks

SMF Info
--------
    Field: `SMF99_AVG_NUM_TASKS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

average number of tasks
"""
avg_num_tasks.__doc__ = """average number of tasks

SMF Info
--------
    Field: `SMF99_AVG_NUM_TASKS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

average number of tasks
"""

buffer_pool_delay : Final[Field] = Field(
    name='buffer_pool_delay',
    origin='SMF99_PBPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""buffer pool delay samples

SMF Info
--------
    Field: `SMF99_PBPD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

buffer pool delay samples
"""
buffer_pool_delay.__doc__ = """buffer pool delay samples

SMF Info
--------
    Field: `SMF99_PBPD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

buffer pool delay samples
"""

swct : Final[Field] = Field(
    name='swct',
    origin='SMF99_SWCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Short wait count accumulator

SMF Info
--------
    Field: `SMF99_SWCT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Short wait count accumulator
"""
swct.__doc__ = """Short wait count accumulator

SMF Info
--------
    Field: `SMF99_SWCT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Short wait count accumulator
"""

flags2 : Final[Field] = Field(
    name='flags2',
    origin='SMF99_FLAGS2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Flags

SMF Info
--------
    Field: `SMF99_FLAGS2`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Flags
"""
flags2.__doc__ = """Flags

SMF Info
--------
    Field: `SMF99_FLAGS2`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Flags
"""

inelighonorpriority : Final[Field] = Field(
    name='inelighonorpriority',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flags2,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Specialty engine work in this period is ineligible for "Honor Priority Processing", i.e. it will not be offloaded to CPs for help processing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags2`(`SMF99_FLAGS2`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Specialty engine work in this period is ineligible for "Honor Priority Processing", i.e. it will not be offloaded to CPs for help processing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
inelighonorpriority.__doc__ = """Specialty engine work in this period is ineligible for "Honor Priority Processing", i.e. it will not be offloaded to CPs for help processing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags2`(`SMF99_FLAGS2`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Specialty engine work in this period is ineligible for "Honor Priority Processing", i.e. it will not be offloaded to CPs for help processing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iscappedbytrg : Final[Field] = Field(
    name='iscappedbytrg',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flags2,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""At least one TRG with a capacity maximum is associated with this period(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags2`(`SMF99_FLAGS2`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

At least one TRG with a capacity maximum is associated with this period

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iscappedbytrg.__doc__ = """At least one TRG with a capacity maximum is associated with this period(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags2`(`SMF99_FLAGS2`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

At least one TRG with a capacity maximum is associated with this period

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

iscappedbysoletrg : Final[Field] = Field(
    name='iscappedbysoletrg',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=flags2,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Exactly one TRG with a capacity maximum is associated with this period(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags2`(`SMF99_FLAGS2`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Exactly one TRG with a capacity maximum is associated with this period

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
iscappedbysoletrg.__doc__ = """Exactly one TRG with a capacity maximum is associated with this period(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags2`(`SMF99_FLAGS2`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Exactly one TRG with a capacity maximum is associated with this period

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

cpucrit_implicit : Final[Field] = Field(
    name='cpucrit_implicit',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flags2,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Service class period implicitly designated CPU critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags2`(`SMF99_FLAGS2`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Service class period implicitly designated CPU critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
cpucrit_implicit.__doc__ = """Service class period implicitly designated CPU critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags2`(`SMF99_FLAGS2`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Service class period implicitly designated CPU critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

history_rows : Final[Field] = Field(
    name='history_rows',
    origin='SMF99_NUM_SAMP_HIST_ROWS_USED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Number of sample history rows used to build sample set

SMF Info
--------
    Field: `SMF99_NUM_SAMP_HIST_ROWS_USED`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Number of sample history rows used to build sample set
"""
history_rows.__doc__ = """Number of sample history rows used to build sample set

SMF Info
--------
    Field: `SMF99_NUM_SAMP_HIST_ROWS_USED`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Number of sample history rows used to build sample set
"""

cadp : Final[Field] = Field(
    name='cadp',
    origin='SMF99_CADP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Current Achievable demand percentage

SMF Info
--------
    Field: `SMF99_CADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Current Achievable demand percentage
"""
cadp.__doc__ = """Current Achievable demand percentage

SMF Info
--------
    Field: `SMF99_CADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Current Achievable demand percentage
"""

sbcpuu : Final[Field] = Field(
    name='sbcpuu',
    origin='SMF99_SBCPUU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Sample based CPU usings

SMF Info
--------
    Field: `SMF99_SBCPUU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sample based CPU usings
"""
sbcpuu.__doc__ = """Sample based CPU usings

SMF Info
--------
    Field: `SMF99_SBCPUU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sample based CPU usings
"""

sbcpud : Final[Field] = Field(
    name='sbcpud',
    origin='SMF99_SBCPUD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Sample based CPU delays

SMF Info
--------
    Field: `SMF99_SBCPUD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sample based CPU delays
"""
sbcpud.__doc__ = """Sample based CPU delays

SMF Info
--------
    Field: `SMF99_SBCPUD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sample based CPU delays
"""

psys_io_dly : Final[Field] = Field(
    name='psys_io_dly',
    origin='SMF99_PSYS_IO_DLY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Sysplex wide io delay

SMF Info
--------
    Field: `SMF99_PSYS_IO_DLY`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide io delay
"""
psys_io_dly.__doc__ = """Sysplex wide io delay

SMF Info
--------
    Field: `SMF99_PSYS_IO_DLY`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide io delay
"""

psys_non_io_dly : Final[Field] = Field(
    name='psys_non_io_dly',
    origin='SMF99_PSYS_NON_IO_DLY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Sysplex wide non io delay

SMF Info
--------
    Field: `SMF99_PSYS_NON_IO_DLY`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide non io delay
"""
psys_non_io_dly.__doc__ = """Sysplex wide non io delay

SMF Info
--------
    Field: `SMF99_PSYS_NON_IO_DLY`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Sysplex wide non io delay
"""

zaap_using : Final[Field] = Field(
    name='zaap_using',
    origin='SMF99_PIFAU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""IFA using samples

SMF Info
--------
    Field: `SMF99_PIFAU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA using samples
"""
zaap_using.__doc__ = """IFA using samples

SMF Info
--------
    Field: `SMF99_PIFAU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA using samples
"""

zaap_delay : Final[Field] = Field(
    name='zaap_delay',
    origin='SMF99_PIFAD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""IFA delay samples

SMF Info
--------
    Field: `SMF99_PIFAD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA delay samples
"""
zaap_delay.__doc__ = """IFA delay samples

SMF Info
--------
    Field: `SMF99_PIFAD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA delay samples
"""

srv_zaap_service : Final[Field] = Field(
    name='srv_zaap_service',
    origin='SMF99_PISERV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""IFA service accumulated during interval

SMF Info
--------
    Field: `SMF99_PISERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA service accumulated during interval
"""
srv_zaap_service.__doc__ = """IFA service accumulated during interval

SMF Info
--------
    Field: `SMF99_PISERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA service accumulated during interval
"""

pimdp : Final[Field] = Field(
    name='pimdp',
    origin='SMF99_PIMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""maximum percentage of IFA processor time demanded

SMF Info
--------
    Field: `SMF99_PIMDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

maximum percentage of IFA processor time demanded
"""
pimdp.__doc__ = """maximum percentage of IFA processor time demanded

SMF Info
--------
    Field: `SMF99_PIMDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

maximum percentage of IFA processor time demanded
"""

pimttwa : Final[Field] = Field(
    name='pimttwa',
    origin='SMF99_PIMTTWA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Mean time to wait adjusted (IFA)

SMF Info
--------
    Field: `SMF99_PIMTTWA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Mean time to wait adjusted (IFA)
"""
pimttwa.__doc__ = """Mean time to wait adjusted (IFA)

SMF Info
--------
    Field: `SMF99_PIMTTWA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Mean time to wait adjusted (IFA)
"""

piadp : Final[Field] = Field(
    name='piadp',
    origin='SMF99_PIADP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""working variable for achievable demand percentage (IFA)

SMF Info
--------
    Field: `SMF99_PIADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

working variable for achievable demand percentage (IFA)
"""
piadp.__doc__ = """working variable for achievable demand percentage (IFA)

SMF Info
--------
    Field: `SMF99_PIADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

working variable for achievable demand percentage (IFA)
"""

piaserc : Final[Field] = Field(
    name='piaserc',
    origin='SMF99_PIASERC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Average service consumed over window (IFA)

SMF Info
--------
    Field: `SMF99_PIASERC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average service consumed over window (IFA)
"""
piaserc.__doc__ = """Average service consumed over window (IFA)

SMF Info
--------
    Field: `SMF99_PIASERC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average service consumed over window (IFA)
"""

piprser : Final[Field] = Field(
    name='piprser',
    origin='SMF99_PIPRSER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Projected service (IFA)

SMF Info
--------
    Field: `SMF99_PIPRSER`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Projected service (IFA)
"""
piprser.__doc__ = """Projected service (IFA)

SMF Info
--------
    Field: `SMF99_PIPRSER`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Projected service (IFA)
"""

icadp : Final[Field] = Field(
    name='icadp',
    origin='SMF99_ICADP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Current Achievable demand percentage (IFA )

SMF Info
--------
    Field: `SMF99_ICADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Current Achievable demand percentage (IFA )
"""
icadp.__doc__ = """Current Achievable demand percentage (IFA )

SMF Info
--------
    Field: `SMF99_ICADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Current Achievable demand percentage (IFA )
"""

pifaoncp : Final[Field] = Field(
    name='pifaoncp',
    origin='SMF99_PIFAONCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""IFA On CP using samples

SMF Info
--------
    Field: `SMF99_PIFAONCP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA On CP using samples
"""
pifaoncp.__doc__ = """IFA On CP using samples

SMF Info
--------
    Field: `SMF99_PIFAONCP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA On CP using samples
"""

plifau : Final[Field] = Field(
    name='plifau',
    origin='SMF99_PLIFAU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""IFA using samples during last interval

SMF Info
--------
    Field: `SMF99_PLIFAU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA using samples during last interval
"""
plifau.__doc__ = """IFA using samples during last interval

SMF Info
--------
    Field: `SMF99_PLIFAU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA using samples during last interval
"""

plifad : Final[Field] = Field(
    name='plifad',
    origin='SMF99_PLIFAD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""IFA delay samples during last interval

SMF Info
--------
    Field: `SMF99_PLIFAD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA delay samples during last interval
"""
plifad.__doc__ = """IFA delay samples during last interval

SMF Info
--------
    Field: `SMF99_PLIFAD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

IFA delay samples during last interval
"""

ziip_using : Final[Field] = Field(
    name='ziip_using',
    origin='SMF99_PSUPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""SUP using samples

SMF Info
--------
    Field: `SMF99_PSUPU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP using samples
"""
ziip_using.__doc__ = """SUP using samples

SMF Info
--------
    Field: `SMF99_PSUPU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP using samples
"""

ziip_delay : Final[Field] = Field(
    name='ziip_delay',
    origin='SMF99_PSUPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""SUP delay samples

SMF Info
--------
    Field: `SMF99_PSUPD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP delay samples
"""
ziip_delay.__doc__ = """SUP delay samples

SMF Info
--------
    Field: `SMF99_PSUPD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP delay samples
"""

psuponcp : Final[Field] = Field(
    name='psuponcp',
    origin='SMF99_PSUPONCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""SUP_On_CP using samples

SMF Info
--------
    Field: `SMF99_PSUPONCP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP_On_CP using samples
"""
psuponcp.__doc__ = """SUP_On_CP using samples

SMF Info
--------
    Field: `SMF99_PSUPONCP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP_On_CP using samples
"""

plsupu : Final[Field] = Field(
    name='plsupu',
    origin='SMF99_PLSUPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""SUP using samples during last interval

SMF Info
--------
    Field: `SMF99_PLSUPU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP using samples during last interval
"""
plsupu.__doc__ = """SUP using samples during last interval

SMF Info
--------
    Field: `SMF99_PLSUPU`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP using samples during last interval
"""

plsupd : Final[Field] = Field(
    name='plsupd',
    origin='SMF99_PLSUPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""SUP delay samples during last interval

SMF Info
--------
    Field: `SMF99_PLSUPD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP delay samples during last interval
"""
plsupd.__doc__ = """SUP delay samples during last interval

SMF Info
--------
    Field: `SMF99_PLSUPD`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP delay samples during last interval
"""

srv_ziip_service : Final[Field] = Field(
    name='srv_ziip_service',
    origin='SMF99_PSSERV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Accumulated SUP service

SMF Info
--------
    Field: `SMF99_PSSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Accumulated SUP service
"""
srv_ziip_service.__doc__ = """Accumulated SUP service

SMF Info
--------
    Field: `SMF99_PSSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Accumulated SUP service
"""

time_at_pdp_using : Final[Field] = Field(
    name='time_at_pdp_using',
    origin='SMF99_TIME_AT_PDP_USING',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Time at PDP (promoted dispatch priority) using samples

SMF Info
--------
    Field: `SMF99_TIME_AT_PDP_USING`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Time at PDP (promoted dispatch priority) using samples
"""
time_at_pdp_using.__doc__ = """Time at PDP (promoted dispatch priority) using samples

SMF Info
--------
    Field: `SMF99_TIME_AT_PDP_USING`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Time at PDP (promoted dispatch priority) using samples
"""

time_at_pdp : Final[Field] = Field(
    name='time_at_pdp',
    origin='SMF99_TIME_AT_PDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Time at PDP (promoted dispatch priority) accumulator

SMF Info
--------
    Field: `SMF99_TIME_AT_PDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Time at PDP (promoted dispatch priority) accumulator
"""
time_at_pdp.__doc__ = """Time at PDP (promoted dispatch priority) accumulator

SMF Info
--------
    Field: `SMF99_TIME_AT_PDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Time at PDP (promoted dispatch priority) accumulator
"""

ewlm_local_pi : Final[Field] = Field(
    name='ewlm_local_pi',
    origin='SMF99_EWLM_LOCAL_PI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""EWLM local performance index(PI)

SMF Info
--------
    Field: `SMF99_EWLM_LOCAL_PI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

EWLM local performance index(PI)
"""
ewlm_local_pi.__doc__ = """EWLM local performance index(PI)

SMF Info
--------
    Field: `SMF99_EWLM_LOCAL_PI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

EWLM local performance index(PI)
"""

ewlm_global_pi : Final[Field] = Field(
    name='ewlm_global_pi',
    origin='SMF99_EWLM_GLOBAL_PI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""EWLM global performance index(PI)

SMF Info
--------
    Field: `SMF99_EWLM_GLOBAL_PI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

EWLM global performance index(PI)
"""
ewlm_global_pi.__doc__ = """EWLM global performance index(PI)

SMF Info
--------
    Field: `SMF99_EWLM_GLOBAL_PI`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

EWLM global performance index(PI)
"""

psmdp : Final[Field] = Field(
    name='psmdp',
    origin='SMF99_PSMDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Maximum percentage of SUP processor time demanded

SMF Info
--------
    Field: `SMF99_PSMDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Maximum percentage of SUP processor time demanded
"""
psmdp.__doc__ = """Maximum percentage of SUP processor time demanded

SMF Info
--------
    Field: `SMF99_PSMDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Maximum percentage of SUP processor time demanded
"""

psmttwa : Final[Field] = Field(
    name='psmttwa',
    origin='SMF99_PSMTTWA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Mean time to wait adjusted (SUP)

SMF Info
--------
    Field: `SMF99_PSMTTWA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Mean time to wait adjusted (SUP)
"""
psmttwa.__doc__ = """Mean time to wait adjusted (SUP)

SMF Info
--------
    Field: `SMF99_PSMTTWA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Mean time to wait adjusted (SUP)
"""

psadp : Final[Field] = Field(
    name='psadp',
    origin='SMF99_PSADP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Working variable for achievable demand percentage (SUP)

SMF Info
--------
    Field: `SMF99_PSADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Working variable for achievable demand percentage (SUP)
"""
psadp.__doc__ = """Working variable for achievable demand percentage (SUP)

SMF Info
--------
    Field: `SMF99_PSADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Working variable for achievable demand percentage (SUP)
"""

psaserc : Final[Field] = Field(
    name='psaserc',
    origin='SMF99_PSASERC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Average service consumed over window (SUP)

SMF Info
--------
    Field: `SMF99_PSASERC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average service consumed over window (SUP)
"""
psaserc.__doc__ = """Average service consumed over window (SUP)

SMF Info
--------
    Field: `SMF99_PSASERC`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Average service consumed over window (SUP)
"""

psprser : Final[Field] = Field(
    name='psprser',
    origin='SMF99_PSPRSER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Projected service (SUP)

SMF Info
--------
    Field: `SMF99_PSPRSER`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Projected service (SUP)
"""
psprser.__doc__ = """Projected service (SUP)

SMF Info
--------
    Field: `SMF99_PSPRSER`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Projected service (SUP)
"""

scadp : Final[Field] = Field(
    name='scadp',
    origin='SMF99_SCADP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Current Achievable demand percentage (SUP)

SMF Info
--------
    Field: `SMF99_SCADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Current Achievable demand percentage (SUP)
"""
scadp.__doc__ = """Current Achievable demand percentage (SUP)

SMF Info
--------
    Field: `SMF99_SCADP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Current Achievable demand percentage (SUP)
"""

hdlockpromotion_time_at_pdp : Final[Field] = Field(
    name='hdlockpromotion_time_at_pdp',
    origin='SMF99_HDLOCKPROMOTION_TIME_AT_PDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""HD lock time at PDP (promoted dispatch priority) accumulator

SMF Info
--------
    Field: `SMF99_HDLOCKPROMOTION_TIME_AT_PDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

HD lock time at PDP (promoted dispatch priority) accumulator
"""
hdlockpromotion_time_at_pdp.__doc__ = """HD lock time at PDP (promoted dispatch priority) accumulator

SMF Info
--------
    Field: `SMF99_HDLOCKPROMOTION_TIME_AT_PDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

HD lock time at PDP (promoted dispatch priority) accumulator
"""

hdlock_time_at_pdp_using : Final[Field] = Field(
    name='hdlock_time_at_pdp_using',
    origin='SMF99_HDLOCK_TIME_AT_PDP_USING',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""HD lock time at PDP using samples

SMF Info
--------
    Field: `SMF99_HDLOCK_TIME_AT_PDP_USING`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

HD lock time at PDP using samples
"""
hdlock_time_at_pdp_using.__doc__ = """HD lock time at PDP using samples

SMF Info
--------
    Field: `SMF99_HDLOCK_TIME_AT_PDP_USING`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

HD lock time at PDP using samples
"""

pns_pserv : Final[Field] = Field(
    name='pns_pserv',
    origin='SMF99_PNS_PSERV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units

SMF Info
--------
    Field: `SMF99_PNS_PSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units
"""
pns_pserv.__doc__ = """Service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units

SMF Info
--------
    Field: `SMF99_PNS_PSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units
"""

pns_ipserv : Final[Field] = Field(
    name='pns_ipserv',
    origin='SMF99_PNS_IPSERV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""zAAP service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units

SMF Info
--------
    Field: `SMF99_PNS_IPSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

zAAP service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units
"""
pns_ipserv.__doc__ = """zAAP service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units

SMF Info
--------
    Field: `SMF99_PNS_IPSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

zAAP service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units
"""

pns_spserv : Final[Field] = Field(
    name='pns_spserv',
    origin='SMF99_PNS_SPSERV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""SUP service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units

SMF Info
--------
    Field: `SMF99_PNS_SPSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units
"""
pns_spserv.__doc__ = """SUP service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units

SMF Info
--------
    Field: `SMF99_PNS_SPSERV`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

SUP service of enclave servers' non enclave work which was accumulated during policy adjustment interval in unweighted CPU service units
"""

vartime_at_pdp : Final[Field] = Field(
    name='vartime_at_pdp',
    origin='SMF99_VARTIME_AT_PDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Time at variable DP promoted by supervisor

SMF Info
--------
    Field: `SMF99_VARTIME_AT_PDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Time at variable DP promoted by supervisor
"""
vartime_at_pdp.__doc__ = """Time at variable DP promoted by supervisor

SMF Info
--------
    Field: `SMF99_VARTIME_AT_PDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Time at variable DP promoted by supervisor
"""

vartime_at_pdp_using : Final[Field] = Field(
    name='vartime_at_pdp_using',
    origin='SMF99_VARTIME_AT_PDP_USING',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Usings at variable DP promoted by supervisor

SMF Info
--------
    Field: `SMF99_VARTIME_AT_PDP_USING`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Usings at variable DP promoted by supervisor
"""
vartime_at_pdp_using.__doc__ = """Usings at variable DP promoted by supervisor

SMF Info
--------
    Field: `SMF99_VARTIME_AT_PDP_USING`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Usings at variable DP promoted by supervisor
"""

varweighted_time_at_pdp : Final[Field] = Field(
    name='varweighted_time_at_pdp',
    origin='SMF99_VARWEIGHTED_TIME_AT_PDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Time at variable DP promoted by supervisor weighted by DP

SMF Info
--------
    Field: `SMF99_VARWEIGHTED_TIME_AT_PDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Time at variable DP promoted by supervisor weighted by DP
"""
varweighted_time_at_pdp.__doc__ = """Time at variable DP promoted by supervisor weighted by DP

SMF Info
--------
    Field: `SMF99_VARWEIGHTED_TIME_AT_PDP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Time at variable DP promoted by supervisor weighted by DP
"""

rt_distri_mid_point : Final[Field] = Field(
    name='rt_distri_mid_point',
    origin='SMF99_RT_DISTRI_MID_POINT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Response time distribution mid-point (milliseconds)

SMF Info
--------
    Field: `SMF99_RT_DISTRI_MID_POINT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution mid-point (milliseconds)
"""
rt_distri_mid_point.__doc__ = """Response time distribution mid-point (milliseconds)

SMF Info
--------
    Field: `SMF99_RT_DISTRI_MID_POINT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution mid-point (milliseconds)
"""

rt_distri_time_stamp : Final[Field] = Field(
    name='rt_distri_time_stamp',
    origin='SMF99_RT_DISTRI_TIME_STAMP',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Response time distribution time stamp

SMF Info
--------
    Field: `SMF99_RT_DISTRI_TIME_STAMP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution time stamp
"""
rt_distri_time_stamp.__doc__ = """Response time distribution time stamp

SMF Info
--------
    Field: `SMF99_RT_DISTRI_TIME_STAMP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution time stamp
"""

rt_distri_avg_resp_time : Final[Field] = Field(
    name='rt_distri_avg_resp_time',
    origin='SMF99_RT_DISTRI_AVG_RESP_TIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Response time distribution average response time

SMF Info
--------
    Field: `SMF99_RT_DISTRI_AVG_RESP_TIME`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution average response time
"""
rt_distri_avg_resp_time.__doc__ = """Response time distribution average response time

SMF Info
--------
    Field: `SMF99_RT_DISTRI_AVG_RESP_TIME`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution average response time
"""

rt_distri_num_rows : Final[Field] = Field(
    name='rt_distri_num_rows',
    origin='SMF99_RT_DISTRI_NUM_ROWS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Response time distribution number of rows used to build

SMF Info
--------
    Field: `SMF99_RT_DISTRI_NUM_ROWS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution number of rows used to build
"""
rt_distri_num_rows.__doc__ = """Response time distribution number of rows used to build

SMF Info
--------
    Field: `SMF99_RT_DISTRI_NUM_ROWS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution number of rows used to build
"""

rt_distri_sum_trans : Final[Field] = Field(
    name='rt_distri_sum_trans',
    origin='SMF99_RT_DISTRI_SUM_TRANS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Response time distribution total number of transactions completed

SMF Info
--------
    Field: `SMF99_RT_DISTRI_SUM_TRANS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution total number of transactions completed
"""
rt_distri_sum_trans.__doc__ = """Response time distribution total number of transactions completed

SMF Info
--------
    Field: `SMF99_RT_DISTRI_SUM_TRANS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution total number of transactions completed
"""

rt_distri_running_count : Final[Field] = Field(
    name='rt_distri_running_count',
    origin='SMF99_RT_DISTRI_RUNNING_COUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Response time distribution total number of times the mid-point was changed

SMF Info
--------
    Field: `SMF99_RT_DISTRI_RUNNING_COUNT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution total number of times the mid-point was changed
"""
rt_distri_running_count.__doc__ = """Response time distribution total number of times the mid-point was changed

SMF Info
--------
    Field: `SMF99_RT_DISTRI_RUNNING_COUNT`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution total number of times the mid-point was changed
"""

rt_distri_int_sum_trans : Final[Field] = Field(
    name='rt_distri_int_sum_trans',
    origin='SMF99_RT_DISTRI_INT_SUM_TRANS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Response time distribution total number of transactions completed during last interval

SMF Info
--------
    Field: `SMF99_RT_DISTRI_INT_SUM_TRANS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution total number of transactions completed during last interval
"""
rt_distri_int_sum_trans.__doc__ = """Response time distribution total number of transactions completed during last interval

SMF Info
--------
    Field: `SMF99_RT_DISTRI_INT_SUM_TRANS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution total number of transactions completed during last interval
"""

gav_area : Final[Field] = Field(
    name='gav_area',
    origin='SMF99_GAV_AREA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_GAV_AREA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Not available
"""
gav_area.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_GAV_AREA`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Not available
"""

velo_using_states : Final[Field] = Field(
    name='velo_using_states',
    origin='SMF99_VELO_USING_STATES',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Total velocity using states

SMF Info
--------
    Field: `SMF99_VELO_USING_STATES`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Total velocity using states
"""
velo_using_states.__doc__ = """Total velocity using states

SMF Info
--------
    Field: `SMF99_VELO_USING_STATES`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Total velocity using states
"""

samp_io_using : Final[Field] = Field(
    name='samp_io_using',
    origin='SMF99_USING_IOSM_CURR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O using samples for the current interval

SMF Info
--------
    Field: `SMF99_USING_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O using samples for the current interval
"""
samp_io_using.__doc__ = """DASD I/O using samples for the current interval

SMF Info
--------
    Field: `SMF99_USING_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O using samples for the current interval
"""

samp_io_delay : Final[Field] = Field(
    name='samp_io_delay',
    origin='SMF99_DELAY_IOSM_CURR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O delay samples for the current interval

SMF Info
--------
    Field: `SMF99_DELAY_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O delay samples for the current interval
"""
samp_io_delay.__doc__ = """DASD I/O delay samples for the current interval

SMF Info
--------
    Field: `SMF99_DELAY_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O delay samples for the current interval
"""

samp_io_disconnected : Final[Field] = Field(
    name='samp_io_disconnected',
    origin='SMF99_DISC_IOSM_CURR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O disconnect samples for the current interval

SMF Info
--------
    Field: `SMF99_DISC_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O disconnect samples for the current interval
"""
samp_io_disconnected.__doc__ = """DASD I/O disconnect samples for the current interval

SMF Info
--------
    Field: `SMF99_DISC_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O disconnect samples for the current interval
"""

disc_iosm_accum : Final[Field] = Field(
    name='disc_iosm_accum',
    origin='SMF99_DISC_IOSM_ACCUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O disconnect samples accumulated over SMF99_Num_Samp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_DISC_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O disconnect samples accumulated over SMF99_Num_Samp_Hist_Rows_Used
"""
disc_iosm_accum.__doc__ = """DASD I/O disconnect samples accumulated over SMF99_Num_Samp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_DISC_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O disconnect samples accumulated over SMF99_Num_Samp_Hist_Rows_Used
"""

samp_io_unit_queue : Final[Field] = Field(
    name='samp_io_unit_queue',
    origin='SMF99_CUQT_IOSM_CURR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O control unit queue samples for the current interval

SMF Info
--------
    Field: `SMF99_CUQT_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O control unit queue samples for the current interval
"""
samp_io_unit_queue.__doc__ = """DASD I/O control unit queue samples for the current interval

SMF Info
--------
    Field: `SMF99_CUQT_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O control unit queue samples for the current interval
"""

cuqt_iosm_accum : Final[Field] = Field(
    name='cuqt_iosm_accum',
    origin='SMF99_CUQT_IOSM_ACCUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O control unit queue samples accumulated over SMF99_Num_Samp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_CUQT_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O control unit queue samples accumulated over SMF99_Num_Samp_Hist_Rows_Used
"""
cuqt_iosm_accum.__doc__ = """DASD I/O control unit queue samples accumulated over SMF99_Num_Samp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_CUQT_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O control unit queue samples accumulated over SMF99_Num_Samp_Hist_Rows_Used
"""

thro_iosm_curr : Final[Field] = Field(
    name='thro_iosm_curr',
    origin='SMF99_THRO_IOSM_CURR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O induced throttle samples for the current interval

SMF Info
--------
    Field: `SMF99_THRO_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O induced throttle samples for the current interval
"""
thro_iosm_curr.__doc__ = """DASD I/O induced throttle samples for the current interval

SMF Info
--------
    Field: `SMF99_THRO_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O induced throttle samples for the current interval
"""

thro_iosm_accum : Final[Field] = Field(
    name='thro_iosm_accum',
    origin='SMF99_THRO_IOSM_ACCUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O induced throttle samples accumulated over SMF99_Num_S amp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_THRO_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O induced throttle samples accumulated over SMF99_Num_S amp_Hist_Rows_Used
"""
thro_iosm_accum.__doc__ = """DASD I/O induced throttle samples accumulated over SMF99_Num_S amp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_THRO_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O induced throttle samples accumulated over SMF99_Num_S amp_Hist_Rows_Used
"""

cntd_iosm_curr : Final[Field] = Field(
    name='cntd_iosm_curr',
    origin='SMF99_CNTD_IOSM_CURR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O contention delta samples for the current interval

SMF Info
--------
    Field: `SMF99_CNTD_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O contention delta samples for the current interval
"""
cntd_iosm_curr.__doc__ = """DASD I/O contention delta samples for the current interval

SMF Info
--------
    Field: `SMF99_CNTD_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O contention delta samples for the current interval
"""

cntd_iosm_accum : Final[Field] = Field(
    name='cntd_iosm_accum',
    origin='SMF99_CNTD_IOSM_ACCUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O contention delta samples accumulated over SMF99_Num_Samp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_CNTD_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O contention delta samples accumulated over SMF99_Num_Samp_Hist_Rows_Used
"""
cntd_iosm_accum.__doc__ = """DASD I/O contention delta samples accumulated over SMF99_Num_Samp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_CNTD_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O contention delta samples accumulated over SMF99_Num_Samp_Hist_Rows_Used
"""

pend_iosm_curr : Final[Field] = Field(
    name='pend_iosm_curr',
    origin='SMF99_PEND_IOSM_CURR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O pending samples for the current interval

SMF Info
--------
    Field: `SMF99_PEND_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O pending samples for the current interval
"""
pend_iosm_curr.__doc__ = """DASD I/O pending samples for the current interval

SMF Info
--------
    Field: `SMF99_PEND_IOSM_CURR`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O pending samples for the current interval
"""

pend_iosm_accum : Final[Field] = Field(
    name='pend_iosm_accum',
    origin='SMF99_PEND_IOSM_ACCUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""DASD I/O pending samples accumulated over SMF99_Num_Samp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_PEND_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O pending samples accumulated over SMF99_Num_Samp_Hist_Rows_Used
"""
pend_iosm_accum.__doc__ = """DASD I/O pending samples accumulated over SMF99_Num_Samp_Hist_Rows_Used

SMF Info
--------
    Field: `SMF99_PEND_IOSM_ACCUM`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

DASD I/O pending samples accumulated over SMF99_Num_Samp_Hist_Rows_Used
"""

speczcbp : Final[Field] = Field(
    name='speczcbp',
    origin='SMF99_SPECZCBP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_SPECZCBP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Not available
"""
speczcbp.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_SPECZCBP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Not available
"""

speczcbponcp : Final[Field] = Field(
    name='speczcbponcp',
    origin='SMF99_SPECZCBPONCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99_SPECZCBPONCP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Not available
"""
speczcbponcp.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99_SPECZCBPONCP`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Not available
"""

trg_name : Final[Field] = Field(
    name='trg_name',
    origin='SMF99_TRG_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Name of tenant resource group if SMF99_IsCappedBySoleTRG is set

SMF Info
--------
    Field: `SMF99_TRG_NAME`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Name of tenant resource group if SMF99_IsCappedBySoleTRG is set
"""
trg_name.__doc__ = """Name of tenant resource group if SMF99_IsCappedBySoleTRG is set

SMF Info
--------
    Field: `SMF99_TRG_NAME`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Name of tenant resource group if SMF99_IsCappedBySoleTRG is set
"""

ai_of : Final[Field] = Field(
    name='ai_of',
    origin='SMF99_AI_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Offset to AI section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_AI_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Offset to AI section from beginning of record (including RDW)
"""
ai_of.__doc__ = """Offset to AI section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF99_AI_OF`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Offset to AI section from beginning of record (including RDW)
"""

ai_ln : Final[Field] = Field(
    name='ai_ln',
    origin='SMF99_AI_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Length of AI entry

SMF Info
--------
    Field: `SMF99_AI_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Length of AI entry
"""
ai_ln.__doc__ = """Length of AI entry

SMF Info
--------
    Field: `SMF99_AI_LN`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Length of AI entry
"""

ai_on : Final[Field] = Field(
    name='ai_on',
    origin='SMF99_AI_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Number of AI entries

SMF Info
--------
    Field: `SMF99_AI_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Number of AI entries
"""
ai_on.__doc__ = """Number of AI entries

SMF Info
--------
    Field: `SMF99_AI_ON`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Number of AI entries
"""

rt_distri_num_trans : Final[Field] = Field(
    name='rt_distri_num_trans',
    origin='SMF99_RT_DISTRI_NUM_TRANS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_PER_MAP,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 28,
)
"""Response time distribution, 28 buckets

SMF Info
--------
    Field: `SMF99_RT_DISTRI_NUM_TRANS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution, 28 buckets
"""
rt_distri_num_trans.__doc__ = """Response time distribution, 28 buckets

SMF Info
--------
    Field: `SMF99_RT_DISTRI_NUM_TRANS`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Response time distribution, 28 buckets
"""

gav_array : Final[Field] = Field(
    name='gav_array',
    origin='SMF99_GAV_ARRAY',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_PER_MAP,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 6,
)
"""Goal achievement array

SMF Info
--------
    Field: `SMF99_GAV_ARRAY`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Goal achievement array
"""
gav_array.__doc__ = """Goal achievement array

SMF Info
--------
    Field: `SMF99_GAV_ARRAY`
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Goal achievement array
"""

class_period : Final[Field] = Field(
    name='class_period',
    origin=None,
    post="core.inline",
    post_param=__class_period_inline_post,
    virtual=True,
    ref=[srv_class_name, period_num],
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""service class name and period(V)

SMF Info (Virtual Field)
--------
    Field: Based on `srv_class_name`(`SMF99_CNAM`), `period_num`(`SMF99_PNUM`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.srv_class_name +'.' + df.period_num.astype(str)

"""
class_period.__doc__ = """service class name and period(V)

SMF Info (Virtual Field)
--------
    Field: Based on `srv_class_name`(`SMF99_CNAM`), `period_num`(`SMF99_PNUM`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.srv_class_name +'.' + df.period_num.astype(str)

"""

goal_type_name : Final[Field] = Field(
    name='goal_type_name',
    origin=None,
    post='core.map',
    post_param={'default': 'Unknown', 'map': {0: 'System', 1: 'Short Response', 2: 'Long Response', 3: 'Velocity', 4: 'Discretionary'}},
    virtual=True,
    ref=goal_type,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Goal type name(V)

SMF Info (Virtual Field)
--------
    Field: Based on `goal_type`(`SMF99_PGOALTYP`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `Unknown`)::

    0 => System
    1 => Short Response
    2 => Long Response
    3 => Velocity
    4 => Discretionary
"""
goal_type_name.__doc__ = """Goal type name(V)

SMF Info (Virtual Field)
--------
    Field: Based on `goal_type`(`SMF99_PGOALTYP`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `Unknown`)::

    0 => System
    1 => Short Response
    2 => Long Response
    3 => Velocity
    4 => Discretionary
"""

pserver_type_name : Final[Field] = Field(
    name='pserver_type_name',
    origin=None,
    post='core.flagmap',
    post_param={'default': 'No Server', 'map': {0: 'T', 1: 'E', 2: 'Q'}},
    virtual=True,
    ref=pserver_type,
    record=record,
    record_map=SMF99_S2_PER_MAP,
)
"""Server type name(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pserver_type`(`SMF99_PSERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'No Server', 'map': {0: 'T', 1: 'E', 2: 'Q'}}
"""
pserver_type_name.__doc__ = """Server type name(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pserver_type`(`SMF99_PSERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_S2_PER_MAP`

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'No Server', 'map': {0: 'T', 1: 'E', 2: 'Q'}}
"""

ewlm_cnam : Final[Field] = Field(
    name='ewlm_cnam',
    origin='SMF99_EWLM_CNAM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_ECD_MAP,
)
"""EWLM service class long name taken from EWLM policy service class definition

SMF Info
--------
    Field: `SMF99_EWLM_CNAM`
    Record: `SMF99S2`
    Map: `SMF99_S2_ECD_MAP`

EWLM service class long name taken from EWLM policy service class definition
"""
ewlm_cnam.__doc__ = """EWLM service class long name taken from EWLM policy service class definition

SMF Info
--------
    Field: `SMF99_EWLM_CNAM`
    Record: `SMF99S2`
    Map: `SMF99_S2_ECD_MAP`

EWLM service class long name taken from EWLM policy service class definition
"""

ewlm_ckey : Final[Field] = Field(
    name='ewlm_ckey',
    origin='SMF99_EWLM_CKEY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_ECD_MAP,
)
"""EWLM service class key

SMF Info
--------
    Field: `SMF99_EWLM_CKEY`
    Record: `SMF99S2`
    Map: `SMF99_S2_ECD_MAP`

EWLM service class key
"""
ewlm_ckey.__doc__ = """EWLM service class key

SMF Info
--------
    Field: `SMF99_EWLM_CKEY`
    Record: `SMF99S2`
    Map: `SMF99_S2_ECD_MAP`

EWLM service class key
"""

xmem_jobn : Final[Field] = Field(
    name='xmem_jobn',
    origin='SMF99_XMEM_JOBN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_XMEM_MAP,
)
"""jobname of space we are delayed on

SMF Info
--------
    Field: `SMF99_XMEM_JOBN`
    Record: `SMF99S2`
    Map: `SMF99_XMEM_MAP`

jobname of space we are delayed on
"""
xmem_jobn.__doc__ = """jobname of space we are delayed on

SMF Info
--------
    Field: `SMF99_XMEM_JOBN`
    Record: `SMF99S2`
    Map: `SMF99_XMEM_MAP`

jobname of space we are delayed on
"""

xmem_samps : Final[Field] = Field(
    name='xmem_samps',
    origin='SMF99_XMEM_SAMPS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_XMEM_MAP,
)
"""number of xmem samples

SMF Info
--------
    Field: `SMF99_XMEM_SAMPS`
    Record: `SMF99S2`
    Map: `SMF99_XMEM_MAP`

number of xmem samples
"""
xmem_samps.__doc__ = """number of xmem samples

SMF Info
--------
    Field: `SMF99_XMEM_SAMPS`
    Record: `SMF99S2`
    Map: `SMF99_XMEM_MAP`

number of xmem samples
"""

server_cnm : Final[Field] = Field(
    name='server_cnm',
    origin='SMF99_SERVER_CNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_SERVER_MAP,
)
"""Class that period belongs to

SMF Info
--------
    Field: `SMF99_SERVER_CNM`
    Record: `SMF99S2`
    Map: `SMF99_SERVER_MAP`

Class that period belongs to
"""
server_cnm.__doc__ = """Class that period belongs to

SMF Info
--------
    Field: `SMF99_SERVER_CNM`
    Record: `SMF99S2`
    Map: `SMF99_SERVER_MAP`

Class that period belongs to
"""

server_pnum : Final[Field] = Field(
    name='server_pnum',
    origin='SMF99_SERVER_PNUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SERVER_MAP,
)
"""Period number

SMF Info
--------
    Field: `SMF99_SERVER_PNUM`
    Record: `SMF99S2`
    Map: `SMF99_SERVER_MAP`

Period number
"""
server_pnum.__doc__ = """Period number

SMF Info
--------
    Field: `SMF99_SERVER_PNUM`
    Record: `SMF99S2`
    Map: `SMF99_SERVER_MAP`

Period number
"""

server_obs : Final[Field] = Field(
    name='server_obs',
    origin='SMF99_SERVER_OBS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SERVER_MAP,
)
"""Percentage of time this server was serving the period

SMF Info
--------
    Field: `SMF99_SERVER_OBS`
    Record: `SMF99S2`
    Map: `SMF99_SERVER_MAP`

Percentage of time this server was serving the period
"""
server_obs.__doc__ = """Percentage of time this server was serving the period

SMF Info
--------
    Field: `SMF99_SERVER_OBS`
    Record: `SMF99S2`
    Map: `SMF99_SERVER_MAP`

Percentage of time this server was serving the period
"""

as_esp_anam : Final[Field] = Field(
    name='as_esp_anam',
    origin='SMF99_AS_ESP_ANAM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Address space name

SMF Info
--------
    Field: `SMF99_AS_ESP_ANAM`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space name
"""
as_esp_anam.__doc__ = """Address space name

SMF Info
--------
    Field: `SMF99_AS_ESP_ANAM`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space name
"""

as_esp_ap : Final[Field] = Field(
    name='as_esp_ap',
    origin='SMF99_AS_ESP_AP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""expanded storage access policy for demand

SMF Info
--------
    Field: `SMF99_AS_ESP_AP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

expanded storage access policy for demand
"""
as_esp_ap.__doc__ = """expanded storage access policy for demand

SMF Info
--------
    Field: `SMF99_AS_ESP_AP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

expanded storage access policy for demand
"""

as_esp_vp : Final[Field] = Field(
    name='as_esp_vp',
    origin='SMF99_AS_ESP_VP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""expanded storage access policy for VIO

SMF Info
--------
    Field: `SMF99_AS_ESP_VP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

expanded storage access policy for VIO
"""
as_esp_vp.__doc__ = """expanded storage access policy for VIO

SMF Info
--------
    Field: `SMF99_AS_ESP_VP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

expanded storage access policy for VIO
"""

as_esp_hp : Final[Field] = Field(
    name='as_esp_hp',
    origin='SMF99_AS_ESP_HP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""expanded storage access policy for hiperspace

SMF Info
--------
    Field: `SMF99_AS_ESP_HP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

expanded storage access policy for hiperspace
"""
as_esp_hp.__doc__ = """expanded storage access policy for hiperspace

SMF Info
--------
    Field: `SMF99_AS_ESP_HP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

expanded storage access policy for hiperspace
"""

as_esp_asid : Final[Field] = Field(
    name='as_esp_asid',
    origin='SMF99_AS_ESP_ASID',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Address Space ID number

SMF Info
--------
    Field: `SMF99_AS_ESP_ASID`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address Space ID number
"""
as_esp_asid.__doc__ = """Address Space ID number

SMF Info
--------
    Field: `SMF99_AS_ESP_ASID`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address Space ID number
"""

as_esp_flags : Final[Field] = Field(
    name='as_esp_flags',
    origin='SMF99_AS_ESP_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Flags

SMF Info
--------
    Field: `SMF99_AS_ESP_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Flags
"""
as_esp_flags.__doc__ = """Flags

SMF Info
--------
    Field: `SMF99_AS_ESP_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Flags
"""

as_stg_protected_now : Final[Field] = Field(
    name='as_stg_protected_now',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=as_esp_flags,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Storage is protected at this instant(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Storage is protected at this instant

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
as_stg_protected_now.__doc__ = """Storage is protected at this instant(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Storage is protected at this instant

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

as_stgcrit_explicit : Final[Field] = Field(
    name='as_stgcrit_explicit',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=as_esp_flags,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Storage protected assigned to space by classification rule(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Storage protected assigned to space by classification rule

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
as_stgcrit_explicit.__doc__ = """Storage protected assigned to space by classification rule(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Storage protected assigned to space by classification rule

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

as_managed_to_region_goals : Final[Field] = Field(
    name='as_managed_to_region_goals',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=as_esp_flags,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Address space is currently manged to region's goal rather than transaction server's goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space is currently manged to region's goal rather than transaction server's goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
as_managed_to_region_goals.__doc__ = """Address space is currently manged to region's goal rather than transaction server's goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space is currently manged to region's goal rather than transaction server's goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

as_non_swappable : Final[Field] = Field(
    name='as_non_swappable',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=as_esp_flags,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Address space is non swappable(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space is non swappable

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
as_non_swappable.__doc__ = """Address space is non swappable(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space is non swappable

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

as_managed_to_both_goals : Final[Field] = Field(
    name='as_managed_to_both_goals',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=as_esp_flags,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Address space is currently managed to both region's and transaction server's goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space is currently managed to both region's and transaction server's goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
as_managed_to_both_goals.__doc__ = """Address space is currently managed to both region's and transaction server's goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space is currently managed to both region's and transaction server's goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

as_inelighonorpriority : Final[Field] = Field(
    name='as_inelighonorpriority',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=as_esp_flags,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Address space is ineligible for "Honor Priority Processing", i.e. work will not be offloaded to CPs for help processing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space is ineligible for "Honor Priority Processing", i.e. work will not be offloaded to CPs for help processing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
as_inelighonorpriority.__doc__ = """Address space is ineligible for "Honor Priority Processing", i.e. work will not be offloaded to CPs for help processing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space is ineligible for "Honor Priority Processing", i.e. work will not be offloaded to CPs for help processing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

as_boost : Final[Field] = Field(
    name='as_boost',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=as_esp_flags,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Address space matched a classification rule in the active policy which enables for recovery process boost(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space matched a classification rule in the active policy which enables for recovery process boost

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
as_boost.__doc__ = """Address space matched a classification rule in the active policy which enables for recovery process boost(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space matched a classification rule in the active policy which enables for recovery process boost

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

as_zcontainer : Final[Field] = Field(
    name='as_zcontainer',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=as_esp_flags,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Address space was supplied with a container ID and is therefore a container address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space was supplied with a container ID and is therefore a container address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
as_zcontainer.__doc__ = """Address space was supplied with a container ID and is therefore a container address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_esp_flags`(`SMF99_AS_ESP_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space was supplied with a container ID and is therefore a container address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

as_esp_cs_fmct : Final[Field] = Field(
    name='as_esp_cs_fmct',
    origin='SMF99_AS_ESP_CS_FMCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Number of central storage frames the address spaces owns

SMF Info
--------
    Field: `SMF99_AS_ESP_CS_FMCT`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Number of central storage frames the address spaces owns
"""
as_esp_cs_fmct.__doc__ = """Number of central storage frames the address spaces owns

SMF Info
--------
    Field: `SMF99_AS_ESP_CS_FMCT`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Number of central storage frames the address spaces owns
"""

as_esp_es_fmct : Final[Field] = Field(
    name='as_esp_es_fmct',
    origin='SMF99_AS_ESP_ES_FMCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Number of expanded storage frames the address spaces owns

SMF Info
--------
    Field: `SMF99_AS_ESP_ES_FMCT`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Number of expanded storage frames the address spaces owns
"""
as_esp_es_fmct.__doc__ = """Number of expanded storage frames the address spaces owns

SMF Info
--------
    Field: `SMF99_AS_ESP_ES_FMCT`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Number of expanded storage frames the address spaces owns
"""

as_esp_pps_tar : Final[Field] = Field(
    name='as_esp_pps_tar',
    origin='SMF99_AS_ESP_PPS_TAR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Address space protective process storage target. Note see subtype 5 for other targets. This is the only target non-monitor address spaces can have.

SMF Info
--------
    Field: `SMF99_AS_ESP_PPS_TAR`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space protective process storage target. Note see subtype 5 for other targets. This is the only target non-monitor address spaces can have.
"""
as_esp_pps_tar.__doc__ = """Address space protective process storage target. Note see subtype 5 for other targets. This is the only target non-monitor address spaces can have.

SMF Info
--------
    Field: `SMF99_AS_ESP_PPS_TAR`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Address space protective process storage target. Note see subtype 5 for other targets. This is the only target non-monitor address spaces can have.
"""

as_cpsrp_samp : Final[Field] = Field(
    name='as_cpsrp_samp',
    origin='SMF99_AS_CPSRP_SAMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""One sample per IRACPSRP invocation (every 50ms)

SMF Info
--------
    Field: `SMF99_AS_CPSRP_SAMP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

One sample per IRACPSRP invocation (every 50ms)
"""
as_cpsrp_samp.__doc__ = """One sample per IRACPSRP invocation (every 50ms)

SMF Info
--------
    Field: `SMF99_AS_CPSRP_SAMP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

One sample per IRACPSRP invocation (every 50ms)
"""

as_cpsrp_cur_fp_samp : Final[Field] = Field(
    name='as_cpsrp_cur_fp_samp',
    origin='SMF99_AS_CPSRP_CUR_FP_SAMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Amount of IRACPSRP samples running with full preemption

SMF Info
--------
    Field: `SMF99_AS_CPSRP_CUR_FP_SAMP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Amount of IRACPSRP samples running with full preemption
"""
as_cpsrp_cur_fp_samp.__doc__ = """Amount of IRACPSRP samples running with full preemption

SMF Info
--------
    Field: `SMF99_AS_CPSRP_CUR_FP_SAMP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Amount of IRACPSRP samples running with full preemption
"""

as_cpsrp_prev_fp_samp : Final[Field] = Field(
    name='as_cpsrp_prev_fp_samp',
    origin='SMF99_AS_CPSRP_PREV_FP_SAMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Previous value of FULL_PRE1

SMF Info
--------
    Field: `SMF99_AS_CPSRP_PREV_FP_SAMP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Previous value of FULL_PRE1
"""
as_cpsrp_prev_fp_samp.__doc__ = """Previous value of FULL_PRE1

SMF Info
--------
    Field: `SMF99_AS_CPSRP_PREV_FP_SAMP`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Previous value of FULL_PRE1
"""

as_healthind : Final[Field] = Field(
    name='as_healthind',
    origin='SMF99_AS_HEALTHIND',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Health indicator

SMF Info
--------
    Field: `SMF99_AS_HEALTHIND`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Health indicator
"""
as_healthind.__doc__ = """Health indicator

SMF Info
--------
    Field: `SMF99_AS_HEALTHIND`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Health indicator
"""

as_total_service : Final[Field] = Field(
    name='as_total_service',
    origin='SMF99_AS_TOTAL_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total service units for the address space - OUCBWMS

SMF Info
--------
    Field: `SMF99_AS_TOTAL_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total service units for the address space - OUCBWMS
"""
as_total_service.__doc__ = """Total service units for the address space - OUCBWMS

SMF Info
--------
    Field: `SMF99_AS_TOTAL_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total service units for the address space - OUCBWMS
"""

as_cpu_service : Final[Field] = Field(
    name='as_cpu_service',
    origin='SMF99_AS_CPU_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total CPU service units for the address space - OUCBCPU

SMF Info
--------
    Field: `SMF99_AS_CPU_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total CPU service units for the address space - OUCBCPU
"""
as_cpu_service.__doc__ = """Total CPU service units for the address space - OUCBCPU

SMF Info
--------
    Field: `SMF99_AS_CPU_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total CPU service units for the address space - OUCBCPU
"""

as_srb_service : Final[Field] = Field(
    name='as_srb_service',
    origin='SMF99_AS_SRB_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total SRB service units for the address space - OUCBSRB

SMF Info
--------
    Field: `SMF99_AS_SRB_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SRB service units for the address space - OUCBSRB
"""
as_srb_service.__doc__ = """Total SRB service units for the address space - OUCBSRB

SMF Info
--------
    Field: `SMF99_AS_SRB_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SRB service units for the address space - OUCBSRB
"""

as_mso_service : Final[Field] = Field(
    name='as_mso_service',
    origin='SMF99_AS_MSO_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total MSO service units for the address space - OUCBMSO

SMF Info
--------
    Field: `SMF99_AS_MSO_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total MSO service units for the address space - OUCBMSO
"""
as_mso_service.__doc__ = """Total MSO service units for the address space - OUCBMSO

SMF Info
--------
    Field: `SMF99_AS_MSO_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total MSO service units for the address space - OUCBMSO
"""

as_trn_service : Final[Field] = Field(
    name='as_trn_service',
    origin='SMF99_AS_TRN_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Accumulated transaction service for the address space - OUCBTRS

SMF Info
--------
    Field: `SMF99_AS_TRN_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Accumulated transaction service for the address space - OUCBTRS
"""
as_trn_service.__doc__ = """Accumulated transaction service for the address space - OUCBTRS

SMF Info
--------
    Field: `SMF99_AS_TRN_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Accumulated transaction service for the address space - OUCBTRS
"""

as_io_service : Final[Field] = Field(
    name='as_io_service',
    origin='SMF99_AS_IO_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total IO service units for the address space - OUCBIOC

SMF Info
--------
    Field: `SMF99_AS_IO_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IO service units for the address space - OUCBIOC
"""
as_io_service.__doc__ = """Total IO service units for the address space - OUCBIOC

SMF Info
--------
    Field: `SMF99_AS_IO_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IO service units for the address space - OUCBIOC
"""

as_disp_count : Final[Field] = Field(
    name='as_disp_count',
    origin='SMF99_AS_DISP_COUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Dispatchable count: the number of times that this address space has been found in subroutine CPUTLCK to be dispatchable yet no CPU time has accumulated for it - OUXBDSCN

SMF Info
--------
    Field: `SMF99_AS_DISP_COUNT`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Dispatchable count: the number of times that this address space has been found in subroutine CPUTLCK to be dispatchable yet no CPU time has accumulated for it - OUXBDSCN
"""
as_disp_count.__doc__ = """Dispatchable count: the number of times that this address space has been found in subroutine CPUTLCK to be dispatchable yet no CPU time has accumulated for it - OUXBDSCN

SMF Info
--------
    Field: `SMF99_AS_DISP_COUNT`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Dispatchable count: the number of times that this address space has been found in subroutine CPUTLCK to be dispatchable yet no CPU time has accumulated for it - OUXBDSCN
"""

as_ifa_service : Final[Field] = Field(
    name='as_ifa_service',
    origin='SMF99_AS_IFA_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total IFA service units for the address space - Oucbx_Time_On_Pro(pro_ifa) descaled

SMF Info
--------
    Field: `SMF99_AS_IFA_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IFA service units for the address space - Oucbx_Time_On_Pro(pro_ifa) descaled
"""
as_ifa_service.__doc__ = """Total IFA service units for the address space - Oucbx_Time_On_Pro(pro_ifa) descaled

SMF Info
--------
    Field: `SMF99_AS_IFA_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IFA service units for the address space - Oucbx_Time_On_Pro(pro_ifa) descaled
"""

as_ifacp_service : Final[Field] = Field(
    name='as_ifacp_service',
    origin='SMF99_AS_IFACP_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total IFA service units spent on CP for the address space - Oucbx_Time_- Pro_On_CP(pro_ifa) descaled

SMF Info
--------
    Field: `SMF99_AS_IFACP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IFA service units spent on CP for the address space - Oucbx_Time_- Pro_On_CP(pro_ifa) descaled
"""
as_ifacp_service.__doc__ = """Total IFA service units spent on CP for the address space - Oucbx_Time_- Pro_On_CP(pro_ifa) descaled

SMF Info
--------
    Field: `SMF99_AS_IFACP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IFA service units spent on CP for the address space - Oucbx_Time_- Pro_On_CP(pro_ifa) descaled
"""

as_sup_service : Final[Field] = Field(
    name='as_sup_service',
    origin='SMF99_AS_SUP_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total SUP service units for the address space - Oucbx_Time_On_Pro(pro_sup) descaled

SMF Info
--------
    Field: `SMF99_AS_SUP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SUP service units for the address space - Oucbx_Time_On_Pro(pro_sup) descaled
"""
as_sup_service.__doc__ = """Total SUP service units for the address space - Oucbx_Time_On_Pro(pro_sup) descaled

SMF Info
--------
    Field: `SMF99_AS_SUP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SUP service units for the address space - Oucbx_Time_On_Pro(pro_sup) descaled
"""

as_supcp_service : Final[Field] = Field(
    name='as_supcp_service',
    origin='SMF99_AS_SUPCP_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total SUP service units spent on CP for the address space - Oucbx_Time_- Pro_On_CP(pro_sup) descaled

SMF Info
--------
    Field: `SMF99_AS_SUPCP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SUP service units spent on CP for the address space - Oucbx_Time_- Pro_On_CP(pro_sup) descaled
"""
as_supcp_service.__doc__ = """Total SUP service units spent on CP for the address space - Oucbx_Time_- Pro_On_CP(pro_sup) descaled

SMF Info
--------
    Field: `SMF99_AS_SUPCP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SUP service units spent on CP for the address space - Oucbx_Time_- Pro_On_CP(pro_sup) descaled
"""

as_pb_service : Final[Field] = Field(
    name='as_pb_service',
    origin='SMF99_AS_PB_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Transaction service units on standard CP reported for PBs running in this address space - OucbxPBCP

SMF Info
--------
    Field: `SMF99_AS_PB_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Transaction service units on standard CP reported for PBs running in this address space - OucbxPBCP
"""
as_pb_service.__doc__ = """Transaction service units on standard CP reported for PBs running in this address space - OucbxPBCP

SMF Info
--------
    Field: `SMF99_AS_PB_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Transaction service units on standard CP reported for PBs running in this address space - OucbxPBCP
"""

as_pb_offload_service : Final[Field] = Field(
    name='as_pb_offload_service',
    origin='SMF99_AS_PB_OFFLOAD_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Transaction service units on offload engines reported for PBs running in this address space - OucbxPBOffload

SMF Info
--------
    Field: `SMF99_AS_PB_OFFLOAD_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Transaction service units on offload engines reported for PBs running in this address space - OucbxPBOffload
"""
as_pb_offload_service.__doc__ = """Transaction service units on offload engines reported for PBs running in this address space - OucbxPBOffload

SMF Info
--------
    Field: `SMF99_AS_PB_OFFLOAD_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Transaction service units on offload engines reported for PBs running in this address space - OucbxPBOffload
"""

as_pb_offloadoncp_service : Final[Field] = Field(
    name='as_pb_offloadoncp_service',
    origin='SMF99_AS_PB_OFFLOADONCP_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Transaction service units on standard CP that were offload eligible reported for PBs running in this address space - OucbxPBOffloadOnCP

SMF Info
--------
    Field: `SMF99_AS_PB_OFFLOADONCP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Transaction service units on standard CP that were offload eligible reported for PBs running in this address space - OucbxPBOffloadOnCP
"""
as_pb_offloadoncp_service.__doc__ = """Transaction service units on standard CP that were offload eligible reported for PBs running in this address space - OucbxPBOffloadOnCP

SMF Info
--------
    Field: `SMF99_AS_PB_OFFLOADONCP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Transaction service units on standard CP that were offload eligible reported for PBs running in this address space - OucbxPBOffloadOnCP
"""

as_enclave_time : Final[Field] = Field(
    name='as_enclave_time',
    origin='SMF99_AS_ENCLAVE_TIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Accumulate tx active time of completed enclaves owned by this space - OUCBETIM

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Accumulate tx active time of completed enclaves owned by this space - OUCBETIM
"""
as_enclave_time.__doc__ = """Accumulate tx active time of completed enclaves owned by this space - OUCBETIM

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Accumulate tx active time of completed enclaves owned by this space - OUCBETIM
"""

as_enclave_cpu_service : Final[Field] = Field(
    name='as_enclave_cpu_service',
    origin='SMF99_AS_ENCLAVE_CPU_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Accumulated CPU service of completed enclaves owned by this space - OUCBECPU

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_CPU_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Accumulated CPU service of completed enclaves owned by this space - OUCBECPU
"""
as_enclave_cpu_service.__doc__ = """Accumulated CPU service of completed enclaves owned by this space - OUCBECPU

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_CPU_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Accumulated CPU service of completed enclaves owned by this space - OUCBECPU
"""

as_enclave_ifa_time : Final[Field] = Field(
    name='as_enclave_ifa_time',
    origin='SMF99_AS_ENCLAVE_IFA_TIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total IFA time for the enclaves owned by the address space  OucbxEncTim eOnPro(pro_ifa)

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_IFA_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IFA time for the enclaves owned by the address space  OucbxEncTim eOnPro(pro_ifa)
"""
as_enclave_ifa_time.__doc__ = """Total IFA time for the enclaves owned by the address space  OucbxEncTim eOnPro(pro_ifa)

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_IFA_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IFA time for the enclaves owned by the address space  OucbxEncTim eOnPro(pro_ifa)
"""

as_enclave_ifacp_time : Final[Field] = Field(
    name='as_enclave_ifacp_time',
    origin='SMF99_AS_ENCLAVE_IFACP_TIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total IFA time spent on CP for the enclaves owned by the address space - OucbxEncTimeProOnCP(pro_ifa)

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_IFACP_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IFA time spent on CP for the enclaves owned by the address space - OucbxEncTimeProOnCP(pro_ifa)
"""
as_enclave_ifacp_time.__doc__ = """Total IFA time spent on CP for the enclaves owned by the address space - OucbxEncTimeProOnCP(pro_ifa)

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_IFACP_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total IFA time spent on CP for the enclaves owned by the address space - OucbxEncTimeProOnCP(pro_ifa)
"""

as_enclave_sup_time : Final[Field] = Field(
    name='as_enclave_sup_time',
    origin='SMF99_AS_ENCLAVE_SUP_TIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total SUP time for the enclaves owned by the address space  OucbxEncTim eOnPro(pro_sup)

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_SUP_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SUP time for the enclaves owned by the address space  OucbxEncTim eOnPro(pro_sup)
"""
as_enclave_sup_time.__doc__ = """Total SUP time for the enclaves owned by the address space  OucbxEncTim eOnPro(pro_sup)

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_SUP_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SUP time for the enclaves owned by the address space  OucbxEncTim eOnPro(pro_sup)
"""

as_enclave_supcp_time : Final[Field] = Field(
    name='as_enclave_supcp_time',
    origin='SMF99_AS_ENCLAVE_SUPCP_TIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Total SUP time spent on CP for the enclaves owned by the address space - OucbxEncTimeProOnCP(pro_sup)

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_SUPCP_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SUP time spent on CP for the enclaves owned by the address space - OucbxEncTimeProOnCP(pro_sup)
"""
as_enclave_supcp_time.__doc__ = """Total SUP time spent on CP for the enclaves owned by the address space - OucbxEncTimeProOnCP(pro_sup)

SMF Info
--------
    Field: `SMF99_AS_ENCLAVE_SUPCP_TIME`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Total SUP time spent on CP for the enclaves owned by the address space - OucbxEncTimeProOnCP(pro_sup)
"""

as_ba_brkloc : Final[Field] = Field(
    name='as_ba_brkloc',
    origin='SMF99_AS_BA_BRKLOC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""HiperDispatch breakup location information

SMF Info
--------
    Field: `SMF99_AS_BA_BRKLOC`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

HiperDispatch breakup location information
"""
as_ba_brkloc.__doc__ = """HiperDispatch breakup location information

SMF Info
--------
    Field: `SMF99_AS_BA_BRKLOC`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

HiperDispatch breakup location information
"""

as_ba_loc : Final[Field] = Field(
    name='as_ba_loc',
    origin='SMF99_AS_BA_LOC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""HiperDispatch processor topology location information

SMF Info
--------
    Field: `SMF99_AS_BA_LOC`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

HiperDispatch processor topology location information
"""
as_ba_loc.__doc__ = """HiperDispatch processor topology location information

SMF Info
--------
    Field: `SMF99_AS_BA_LOC`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

HiperDispatch processor topology location information
"""

as_ba_memscore : Final[Field] = Field(
    name='as_ba_memscore',
    origin='SMF99_AS_BA_MEMSCORE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Memory score

SMF Info
--------
    Field: `SMF99_AS_BA_MEMSCORE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Memory score
"""
as_ba_memscore.__doc__ = """Memory score

SMF Info
--------
    Field: `SMF99_AS_BA_MEMSCORE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Memory score
"""

as_mp_actual_pool : Final[Field] = Field(
    name='as_mp_actual_pool',
    origin='SMF99_AS_MP_ACTUAL_POOL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""The actual memory pool of the address space

SMF Info
--------
    Field: `SMF99_AS_MP_ACTUAL_POOL`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

The actual memory pool of the address space
"""
as_mp_actual_pool.__doc__ = """The actual memory pool of the address space

SMF Info
--------
    Field: `SMF99_AS_MP_ACTUAL_POOL`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

The actual memory pool of the address space
"""

as_mp_requested_pool : Final[Field] = Field(
    name='as_mp_requested_pool',
    origin='SMF99_AS_MP_REQUESTED_POOL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""The user requested memory pool. Can differ from actual_pool due to RSM constraints

SMF Info
--------
    Field: `SMF99_AS_MP_REQUESTED_POOL`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

The user requested memory pool. Can differ from actual_pool due to RSM constraints
"""
as_mp_requested_pool.__doc__ = """The user requested memory pool. Can differ from actual_pool due to RSM constraints

SMF Info
--------
    Field: `SMF99_AS_MP_REQUESTED_POOL`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

The user requested memory pool. Can differ from actual_pool due to RSM constraints
"""

as_trc : Final[Field] = Field(
    name='as_trc',
    origin='SMF99_AS_TRC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Tenant report class of address space

SMF Info
--------
    Field: `SMF99_AS_TRC`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Tenant report class of address space
"""
as_trc.__doc__ = """Tenant report class of address space

SMF Info
--------
    Field: `SMF99_AS_TRC`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Tenant report class of address space
"""

as_trg : Final[Field] = Field(
    name='as_trg',
    origin='SMF99_AS_TRG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Tenant resource group of address space

SMF Info
--------
    Field: `SMF99_AS_TRG`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Tenant resource group of address space
"""
as_trg.__doc__ = """Tenant resource group of address space

SMF Info
--------
    Field: `SMF99_AS_TRG`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Tenant resource group of address space
"""

as_pb_zcbp_service : Final[Field] = Field(
    name='as_pb_zcbp_service',
    origin='SMF99_AS_PB_ZCBP_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_AS_PB_ZCBP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

For IBM use only
"""
as_pb_zcbp_service.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_AS_PB_ZCBP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

For IBM use only
"""

as_pb_zcbponcp_service : Final[Field] = Field(
    name='as_pb_zcbponcp_service',
    origin='SMF99_AS_PB_ZCBPONCP_SERVICE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99_AS_PB_ZCBPONCP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

For IBM use only
"""
as_pb_zcbponcp_service.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99_AS_PB_ZCBPONCP_SERVICE`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

For IBM use only
"""

as_ba_brklocelm : Final[Field] = Field(
    name='as_ba_brklocelm',
    origin='SMF99_AS_BA_BRKLOCELM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Location element for each processor type which describes the breakup environment or 0

SMF Info
--------
    Field: `SMF99_AS_BA_BRKLOCELM`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Location element for each processor type which describes the breakup environment or 0
"""
as_ba_brklocelm.__doc__ = """Location element for each processor type which describes the breakup environment or 0

SMF Info
--------
    Field: `SMF99_AS_BA_BRKLOCELM`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Location element for each processor type which describes the breakup environment or 0
"""

as_ba_locelm : Final[Field] = Field(
    name='as_ba_locelm',
    origin='SMF99_AS_BA_LOCELM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""Location element for each processor type or 0

SMF Info
--------
    Field: `SMF99_AS_BA_LOCELM`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Location element for each processor type or 0
"""
as_ba_locelm.__doc__ = """Location element for each processor type or 0

SMF Info
--------
    Field: `SMF99_AS_BA_LOCELM`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Location element for each processor type or 0
"""

as_ba_flags : Final[Field] = Field(
    name='as_ba_flags',
    origin='SMF99_AS_BA_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""HiperDispatch flag areaBit
Meaning
0
Address space is a high storage consumer.
1-7
Reserved

SMF Info
--------
    Field: `SMF99_AS_BA_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

HiperDispatch flag areaBit
Meaning
0
Address space is a high storage consumer.
1-7
Reserved
"""
as_ba_flags.__doc__ = """HiperDispatch flag areaBit
Meaning
0
Address space is a high storage consumer.
1-7
Reserved

SMF Info
--------
    Field: `SMF99_AS_BA_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

HiperDispatch flag areaBit
Meaning
0
Address space is a high storage consumer.
1-7
Reserved
"""

as_ba_highstorageconsumer : Final[Field] = Field(
    name='as_ba_highstorageconsumer',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=as_ba_flags,
    record=record,
    record_map=SMF99_AS_ESP_MAP,
)
"""ON: address space is high storage consumer(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_ba_flags`(`SMF99_AS_BA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
as_ba_highstorageconsumer.__doc__ = """ON: address space is high storage consumer(V)

SMF Info (Virtual Field)
--------
    Field: Based on `as_ba_flags`(`SMF99_AS_BA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_AS_ESP_MAP`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sdata_wqdel : Final[Field] = Field(
    name='sdata_wqdel',
    origin='SMF99_SDATA_WQDEL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""Delay samples waiting on WLM-managed work queue

SMF Info
--------
    Field: `SMF99_SDATA_WQDEL`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Delay samples waiting on WLM-managed work queue
"""
sdata_wqdel.__doc__ = """Delay samples waiting on WLM-managed work queue

SMF Info
--------
    Field: `SMF99_SDATA_WQDEL`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Delay samples waiting on WLM-managed work queue
"""

sdata_enc_auxp : Final[Field] = Field(
    name='sdata_enc_auxp',
    origin='SMF99_SDATA_ENC_AUXP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""aux private paging delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_AUXP`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

aux private paging delay samples experienced by enclave work units known to be associated with an address space
"""
sdata_enc_auxp.__doc__ = """aux private paging delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_AUXP`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

aux private paging delay samples experienced by enclave work units known to be associated with an address space
"""

sdata_enc_vio : Final[Field] = Field(
    name='sdata_enc_vio',
    origin='SMF99_SDATA_ENC_VIO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""aux VIO paging delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_VIO`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

aux VIO paging delay samples experienced by enclave work units known to be associated with an address space
"""
sdata_enc_vio.__doc__ = """aux VIO paging delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_VIO`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

aux VIO paging delay samples experienced by enclave work units known to be associated with an address space
"""

sdata_enc_hsp : Final[Field] = Field(
    name='sdata_enc_hsp',
    origin='SMF99_SDATA_ENC_HSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""aux standard hiperspace paging delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_HSP`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

aux standard hiperspace paging delay samples experienced by enclave work units known to be associated with an address space
"""
sdata_enc_hsp.__doc__ = """aux standard hiperspace paging delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_HSP`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

aux standard hiperspace paging delay samples experienced by enclave work units known to be associated with an address space
"""

sdata_enc_mpld : Final[Field] = Field(
    name='sdata_enc_mpld',
    origin='SMF99_SDATA_ENC_MPLD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""MPL delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_MPLD`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

MPL delay samples experienced by enclave work units known to be associated with an address space
"""
sdata_enc_mpld.__doc__ = """MPL delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_MPLD`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

MPL delay samples experienced by enclave work units known to be associated with an address space
"""

sdata_enc_aswp : Final[Field] = Field(
    name='sdata_enc_aswp',
    origin='SMF99_SDATA_ENC_ASWP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""aux swap delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_ASWP`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

aux swap delay samples experienced by enclave work units known to be associated with an address space
"""
sdata_enc_aswp.__doc__ = """aux swap delay samples experienced by enclave work units known to be associated with an address space

SMF Info
--------
    Field: `SMF99_SDATA_ENC_ASWP`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

aux swap delay samples experienced by enclave work units known to be associated with an address space
"""

sdata_server_class_name : Final[Field] = Field(
    name='sdata_server_class_name',
    origin='SMF99_SDATA_SERVER_CLASS_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""class name of disp serving this period or blank for batch

SMF Info
--------
    Field: `SMF99_SDATA_SERVER_CLASS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

class name of disp serving this period or blank for batch
"""
sdata_server_class_name.__doc__ = """class name of disp serving this period or blank for batch

SMF Info
--------
    Field: `SMF99_SDATA_SERVER_CLASS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

class name of disp serving this period or blank for batch
"""

sdata__server_type : Final[Field] = Field(
    name='sdata__server_type',
    origin='SMF99_SDATA__SERVER_TYPE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""Type byte

SMF Info
--------
    Field: `SMF99_SDATA__SERVER_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Type byte
"""
sdata__server_type.__doc__ = """Type byte

SMF Info
--------
    Field: `SMF99_SDATA__SERVER_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Type byte
"""

sdata_enc_or_q_server : Final[Field] = Field(
    name='sdata_enc_or_q_server',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=sdata__server_type,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""Server is an enclave or queue server(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sdata__server_type`(`SMF99_SDATA__SERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Server is an enclave or queue server

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
sdata_enc_or_q_server.__doc__ = """Server is an enclave or queue server(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sdata__server_type`(`SMF99_SDATA__SERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Server is an enclave or queue server

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sdata_batch : Final[Field] = Field(
    name='sdata_batch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=sdata__server_type,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""Server is a batch work queue(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sdata__server_type`(`SMF99_SDATA__SERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Server is a batch work queue

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sdata_batch.__doc__ = """Server is a batch work queue(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sdata__server_type`(`SMF99_SDATA__SERVER_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Server is a batch work queue

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

sdata_subsys_type : Final[Field] = Field(
    name='sdata_subsys_type',
    origin='SMF99_SDATA_SUBSYS_TYPE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""Subsystem type of owner of the queue. Only applies to batch queue servers.

SMF Info
--------
    Field: `SMF99_SDATA_SUBSYS_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Subsystem type of owner of the queue. Only applies to batch queue servers.
"""
sdata_subsys_type.__doc__ = """Subsystem type of owner of the queue. Only applies to batch queue servers.

SMF Info
--------
    Field: `SMF99_SDATA_SUBSYS_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Subsystem type of owner of the queue. Only applies to batch queue servers.
"""

sdata_subsys_name : Final[Field] = Field(
    name='sdata_subsys_name',
    origin='SMF99_SDATA_SUBSYS_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_SDATA_MAP,
)
"""Subsystem name of owner of the queue. Only applies to batch queue servers.

SMF Info
--------
    Field: `SMF99_SDATA_SUBSYS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Subsystem name of owner of the queue. Only applies to batch queue servers.
"""
sdata_subsys_name.__doc__ = """Subsystem name of owner of the queue. Only applies to batch queue servers.

SMF Info
--------
    Field: `SMF99_SDATA_SUBSYS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_SDATA_MAP`

Subsystem name of owner of the queue. Only applies to batch queue servers.
"""

qdata_env_name : Final[Field] = Field(
    name='qdata_env_name',
    origin='SMF99_QDATA_ENV_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""associated environment name for the queue

SMF Info
--------
    Field: `SMF99_QDATA_ENV_NAME`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

associated environment name for the queue
"""
qdata_env_name.__doc__ = """associated environment name for the queue

SMF Info
--------
    Field: `SMF99_QDATA_ENV_NAME`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

associated environment name for the queue
"""

qdata_server_class_name : Final[Field] = Field(
    name='qdata_server_class_name',
    origin='SMF99_QDATA_SERVER_CLASS_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""class name of disp serving the period represented by this subtype 2 record. Only applies to queue manager type servers.

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_CLASS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

class name of disp serving the period represented by this subtype 2 record. Only applies to queue manager type servers.
"""
qdata_server_class_name.__doc__ = """class name of disp serving the period represented by this subtype 2 record. Only applies to queue manager type servers.

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_CLASS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

class name of disp serving the period represented by this subtype 2 record. Only applies to queue manager type servers.
"""

qdata_server_want : Final[Field] = Field(
    name='qdata_server_want',
    origin='SMF99_QDATA_SERVER_WANT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Number of server instances needed to address queue delay according to policy adjustment. This is a queue wide count.

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_WANT`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of server instances needed to address queue delay according to policy adjustment. This is a queue wide count.
"""
qdata_server_want.__doc__ = """Number of server instances needed to address queue delay according to policy adjustment. This is a queue wide count.

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_WANT`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of server instances needed to address queue delay according to policy adjustment. This is a queue wide count.
"""

qdata_server_have : Final[Field] = Field(
    name='qdata_server_have',
    origin='SMF99_QDATA_SERVER_HAVE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Current actual number of server instances bound to the queue. This is a queue wide count.

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_HAVE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Current actual number of server instances bound to the queue. This is a queue wide count.
"""
qdata_server_have.__doc__ = """Current actual number of server instances bound to the queue. This is a queue wide count.

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_HAVE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Current actual number of server instances bound to the queue. This is a queue wide count.
"""

qdata_server_active : Final[Field] = Field(
    name='qdata_server_active',
    origin='SMF99_QDATA_SERVER_ACTIVE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Current actual number of server instances bound to the queue and between Begin and End. This is a subset of the Have count. Have minus Active equals Idle.

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_ACTIVE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Current actual number of server instances bound to the queue and between Begin and End. This is a subset of the Have count. Have minus Active equals Idle.
"""
qdata_server_active.__doc__ = """Current actual number of server instances bound to the queue and between Begin and End. This is a subset of the Have count. Have minus Active equals Idle.

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_ACTIVE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Current actual number of server instances bound to the queue and between Begin and End. This is a subset of the Have count. Have minus Active equals Idle.
"""

qdata_as_capacity : Final[Field] = Field(
    name='qdata_as_capacity',
    origin='SMF99_QDATA_AS_CAPACITY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Address space server instance capacity

SMF Info
--------
    Field: `SMF99_QDATA_AS_CAPACITY`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Address space server instance capacity
"""
qdata_as_capacity.__doc__ = """Address space server instance capacity

SMF Info
--------
    Field: `SMF99_QDATA_AS_CAPACITY`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Address space server instance capacity
"""

qdata_achieved_qmpl : Final[Field] = Field(
    name='qdata_achieved_qmpl',
    origin='SMF99_QDATA_ACHIEVED_QMPL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""average number (over policy interval) of server instances that are in swapped in spaces in the DISP. Only counts server instances serving the external service classs associated with the queue. Scaled by * 16. Not used for batch queue servers.

SMF Info
--------
    Field: `SMF99_QDATA_ACHIEVED_QMPL`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

average number (over policy interval) of server instances that are in swapped in spaces in the DISP. Only counts server instances serving the external service classs associated with the queue. Scaled by * 16. Not used for batch queue servers.
"""
qdata_achieved_qmpl.__doc__ = """average number (over policy interval) of server instances that are in swapped in spaces in the DISP. Only counts server instances serving the external service classs associated with the queue. Scaled by * 16. Not used for batch queue servers.

SMF Info
--------
    Field: `SMF99_QDATA_ACHIEVED_QMPL`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

average number (over policy interval) of server instances that are in swapped in spaces in the DISP. Only counts server instances serving the external service classs associated with the queue. Scaled by * 16. Not used for batch queue servers.
"""

qdata_active_qmpl : Final[Field] = Field(
    name='qdata_active_qmpl',
    origin='SMF99_QDATA_ACTIVE_QMPL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""average of numer of server instance between Begin and End during policy interval. Scaled by * 16. For batch queue servers this is the number of initiators with active jobs sysplex wide. @WLMCBAT.

SMF Info
--------
    Field: `SMF99_QDATA_ACTIVE_QMPL`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

average of numer of server instance between Begin and End during policy interval. Scaled by * 16. For batch queue servers this is the number of initiators with active jobs sysplex wide. @WLMCBAT.
"""
qdata_active_qmpl.__doc__ = """average of numer of server instance between Begin and End during policy interval. Scaled by * 16. For batch queue servers this is the number of initiators with active jobs sysplex wide. @WLMCBAT.

SMF Info
--------
    Field: `SMF99_QDATA_ACTIVE_QMPL`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

average of numer of server instance between Begin and End during policy interval. Scaled by * 16. For batch queue servers this is the number of initiators with active jobs sysplex wide. @WLMCBAT.
"""

qdata_qmpl_in_tar : Final[Field] = Field(
    name='qdata_qmpl_in_tar',
    origin='SMF99_QDATA_QMPL_IN_TAR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Number of address spaces suggested to be started in the DISP on behalf of the period represented by this subtype 2. Does not apply to batch queue servers.

SMF Info
--------
    Field: `SMF99_QDATA_QMPL_IN_TAR`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of address spaces suggested to be started in the DISP on behalf of the period represented by this subtype 2. Does not apply to batch queue servers.
"""
qdata_qmpl_in_tar.__doc__ = """Number of address spaces suggested to be started in the DISP on behalf of the period represented by this subtype 2. Does not apply to batch queue servers.

SMF Info
--------
    Field: `SMF99_QDATA_QMPL_IN_TAR`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of address spaces suggested to be started in the DISP on behalf of the period represented by this subtype 2. Does not apply to batch queue servers.
"""

qdata_avg_queued_requests : Final[Field] = Field(
    name='qdata_avg_queued_requests',
    origin='SMF99_QDATA_AVG_QUEUED_REQUESTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Average number of queued requests over a policy interval scaled by * 16

SMF Info
--------
    Field: `SMF99_QDATA_AVG_QUEUED_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Average number of queued requests over a policy interval scaled by * 16
"""
qdata_avg_queued_requests.__doc__ = """Average number of queued requests over a policy interval scaled by * 16

SMF Info
--------
    Field: `SMF99_QDATA_AVG_QUEUED_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Average number of queued requests over a policy interval scaled by * 16
"""

qdata_lt_total_requests : Final[Field] = Field(
    name='qdata_lt_total_requests',
    origin='SMF99_QDATA_LT_TOTAL_REQUESTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Long term average total requests (queued + active) scaled by

SMF Info
--------
    Field: `SMF99_QDATA_LT_TOTAL_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Long term average total requests (queued + active) scaled by
"""
qdata_lt_total_requests.__doc__ = """Long term average total requests (queued + active) scaled by

SMF Info
--------
    Field: `SMF99_QDATA_LT_TOTAL_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Long term average total requests (queued + active) scaled by
"""

qdata_server_idle : Final[Field] = Field(
    name='qdata_server_idle',
    origin='SMF99_QDATA_SERVER_IDLE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Average idle server instances over policy interval

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_IDLE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Average idle server instances over policy interval
"""
qdata_server_idle.__doc__ = """Average idle server instances over policy interval

SMF Info
--------
    Field: `SMF99_QDATA_SERVER_IDLE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Average idle server instances over policy interval
"""

qdata_q_type : Final[Field] = Field(
    name='qdata_q_type',
    origin='SMF99_QDATA_Q_TYPE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Type byte

SMF Info
--------
    Field: `SMF99_QDATA_Q_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Type byte
"""
qdata_q_type.__doc__ = """Type byte

SMF Info
--------
    Field: `SMF99_QDATA_Q_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Type byte
"""

qdata_queue_manager : Final[Field] = Field(
    name='qdata_queue_manager',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=qdata_q_type,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""queue manager type work queue(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_type`(`SMF99_QDATA_Q_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

queue manager type work queue

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qdata_queue_manager.__doc__ = """queue manager type work queue(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_type`(`SMF99_QDATA_Q_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

queue manager type work queue

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

qdata_batch : Final[Field] = Field(
    name='qdata_batch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=qdata_q_type,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Batch type work queue(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_type`(`SMF99_QDATA_Q_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Batch type work queue

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
qdata_batch.__doc__ = """Batch type work queue(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_type`(`SMF99_QDATA_Q_TYPE`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Batch type work queue

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

qdata_q_qualifier : Final[Field] = Field(
    name='qdata_q_qualifier',
    origin='SMF99_QDATA_Q_QUALIFIER',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Work Queue Qualifier

SMF Info
--------
    Field: `SMF99_QDATA_Q_QUALIFIER`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Work Queue Qualifier
"""
qdata_q_qualifier.__doc__ = """Work Queue Qualifier

SMF Info
--------
    Field: `SMF99_QDATA_Q_QUALIFIER`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Work Queue Qualifier
"""

qdata_tasks_managed : Final[Field] = Field(
    name='qdata_tasks_managed',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=qdata_q_qualifier,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Server instances are managed by WLM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_qualifier`(`SMF99_QDATA_Q_QUALIFIER`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Server instances are managed by WLM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qdata_tasks_managed.__doc__ = """Server instances are managed by WLM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_qualifier`(`SMF99_QDATA_Q_QUALIFIER`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Server instances are managed by WLM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

qdata_spaces_moved_by_hsk : Final[Field] = Field(
    name='qdata_spaces_moved_by_hsk',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=qdata_q_qualifier,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Address spaces have been moved from this work queue to enforce the minimum number of servers of another work queue of the same application environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_qualifier`(`SMF99_QDATA_Q_QUALIFIER`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Address spaces have been moved from this work queue to enforce the minimum number of servers of another work queue of the same application environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
qdata_spaces_moved_by_hsk.__doc__ = """Address spaces have been moved from this work queue to enforce the minimum number of servers of another work queue of the same application environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_qualifier`(`SMF99_QDATA_Q_QUALIFIER`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Address spaces have been moved from this work queue to enforce the minimum number of servers of another work queue of the same application environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

qdata_spaces_moved_by_pa : Final[Field] = Field(
    name='qdata_spaces_moved_by_pa',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=qdata_q_qualifier,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Address spaces have been moved during policy adjustment because the maximum number of servers has been already started for the application environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_qualifier`(`SMF99_QDATA_Q_QUALIFIER`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Address spaces have been moved during policy adjustment because the maximum number of servers has been already started for the application environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
qdata_spaces_moved_by_pa.__doc__ = """Address spaces have been moved during policy adjustment because the maximum number of servers has been already started for the application environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_qualifier`(`SMF99_QDATA_Q_QUALIFIER`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Address spaces have been moved during policy adjustment because the maximum number of servers has been already started for the application environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

qdata_ae_spreadmin : Final[Field] = Field(
    name='qdata_ae_spreadmin',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=qdata_q_qualifier,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Minimum number of address spaces must be ditributed across all work queues of the application environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_qualifier`(`SMF99_QDATA_Q_QUALIFIER`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Minimum number of address spaces must be ditributed across all work queues of the application environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
qdata_ae_spreadmin.__doc__ = """Minimum number of address spaces must be ditributed across all work queues of the application environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `qdata_q_qualifier`(`SMF99_QDATA_Q_QUALIFIER`)
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Minimum number of address spaces must be ditributed across all work queues of the application environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

qdata_active_rgnwork : Final[Field] = Field(
    name='qdata_active_rgnwork',
    origin='SMF99_QDATA_ACTIVE_RGNWORK',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Current active number of server processing work requests which have been. routed directly to the server region. This number is neither included in the idle nor the active server count.

SMF Info
--------
    Field: `SMF99_QDATA_ACTIVE_RGNWORK`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Current active number of server processing work requests which have been. routed directly to the server region. This number is neither included in the idle nor the active server count.
"""
qdata_active_rgnwork.__doc__ = """Current active number of server processing work requests which have been. routed directly to the server region. This number is neither included in the idle nor the active server count.

SMF Info
--------
    Field: `SMF99_QDATA_ACTIVE_RGNWORK`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Current active number of server processing work requests which have been. routed directly to the server region. This number is neither included in the idle nor the active server count.
"""

qdata_rqdata_of : Final[Field] = Field(
    name='qdata_rqdata_of',
    origin='SMF99_QDATA_RQDATA_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Offset to remote queue data section from beginning of record (including RDW). Only applies to batch queue server

SMF Info
--------
    Field: `SMF99_QDATA_RQDATA_OF`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Offset to remote queue data section from beginning of record (including RDW). Only applies to batch queue server
"""
qdata_rqdata_of.__doc__ = """Offset to remote queue data section from beginning of record (including RDW). Only applies to batch queue server

SMF Info
--------
    Field: `SMF99_QDATA_RQDATA_OF`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Offset to remote queue data section from beginning of record (including RDW). Only applies to batch queue server
"""

qdata_rqdata_ln : Final[Field] = Field(
    name='qdata_rqdata_ln',
    origin='SMF99_QDATA_RQDATA_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Length of remote queue data entries

SMF Info
--------
    Field: `SMF99_QDATA_RQDATA_LN`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Length of remote queue data entries
"""
qdata_rqdata_ln.__doc__ = """Length of remote queue data entries

SMF Info
--------
    Field: `SMF99_QDATA_RQDATA_LN`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Length of remote queue data entries
"""

qdata_rqdata_on : Final[Field] = Field(
    name='qdata_rqdata_on',
    origin='SMF99_QDATA_RQDATA_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Number of remote queue data entries

SMF Info
--------
    Field: `SMF99_QDATA_RQDATA_ON`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of remote queue data entries
"""
qdata_rqdata_on.__doc__ = """Number of remote queue data entries

SMF Info
--------
    Field: `SMF99_QDATA_RQDATA_ON`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of remote queue data entries
"""

qdata_subsys_type : Final[Field] = Field(
    name='qdata_subsys_type',
    origin='SMF99_QDATA_SUBSYS_TYPE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Subsystem type of owner of the queue. Only applies to batch queue servers.

SMF Info
--------
    Field: `SMF99_QDATA_SUBSYS_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Subsystem type of owner of the queue. Only applies to batch queue servers.
"""
qdata_subsys_type.__doc__ = """Subsystem type of owner of the queue. Only applies to batch queue servers.

SMF Info
--------
    Field: `SMF99_QDATA_SUBSYS_TYPE`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Subsystem type of owner of the queue. Only applies to batch queue servers.
"""

qdata_subsys_name : Final[Field] = Field(
    name='qdata_subsys_name',
    origin='SMF99_QDATA_SUBSYS_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Subsystem name of owner of the queue. Only applies to batch queue servers.

SMF Info
--------
    Field: `SMF99_QDATA_SUBSYS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Subsystem name of owner of the queue. Only applies to batch queue servers.
"""
qdata_subsys_name.__doc__ = """Subsystem name of owner of the queue. Only applies to batch queue servers.

SMF Info
--------
    Field: `SMF99_QDATA_SUBSYS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Subsystem name of owner of the queue. Only applies to batch queue servers.
"""

qdata_inst_per_server : Final[Field] = Field(
    name='qdata_inst_per_server',
    origin='SMF99_QDATA_INST_PER_SERVER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Number of server instances per server. Only applies if SMF99_QDATA _TASKS_MANAGED is set

SMF Info
--------
    Field: `SMF99_QDATA_INST_PER_SERVER`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of server instances per server. Only applies if SMF99_QDATA _TASKS_MANAGED is set
"""
qdata_inst_per_server.__doc__ = """Number of server instances per server. Only applies if SMF99_QDATA _TASKS_MANAGED is set

SMF Info
--------
    Field: `SMF99_QDATA_INST_PER_SERVER`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of server instances per server. Only applies if SMF99_QDATA _TASKS_MANAGED is set
"""

qdata_spaces_moved : Final[Field] = Field(
    name='qdata_spaces_moved',
    origin='SMF99_QDATA_SPACES_MOVED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Number of server address spaces moved away from this queue.

SMF Info
--------
    Field: `SMF99_QDATA_SPACES_MOVED`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of server address spaces moved away from this queue.
"""
qdata_spaces_moved.__doc__ = """Number of server address spaces moved away from this queue.

SMF Info
--------
    Field: `SMF99_QDATA_SPACES_MOVED`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Number of server address spaces moved away from this queue.
"""

qdata_ae_maxlimit : Final[Field] = Field(
    name='qdata_ae_maxlimit',
    origin='SMF99_QDATA_AE_MAXLIMIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Maximum number of servers for the application environment.

SMF Info
--------
    Field: `SMF99_QDATA_AE_MAXLIMIT`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Maximum number of servers for the application environment.
"""
qdata_ae_maxlimit.__doc__ = """Maximum number of servers for the application environment.

SMF Info
--------
    Field: `SMF99_QDATA_AE_MAXLIMIT`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Maximum number of servers for the application environment.
"""

qdata_ae_minlimit : Final[Field] = Field(
    name='qdata_ae_minlimit',
    origin='SMF99_QDATA_AE_MINLIMIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Minimum number of servers for the application environment.

SMF Info
--------
    Field: `SMF99_QDATA_AE_MINLIMIT`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Minimum number of servers for the application environment.
"""
qdata_ae_minlimit.__doc__ = """Minimum number of servers for the application environment.

SMF Info
--------
    Field: `SMF99_QDATA_AE_MINLIMIT`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Minimum number of servers for the application environment.
"""

qdata_avg_ineligible_requests : Final[Field] = Field(
    name='qdata_avg_ineligible_requests',
    origin='SMF99_QDATA_AVG_INELIGIBLE_REQUESTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_QDATA_MAP,
)
"""Average number of ineligible queued requests over a policy interval scaled by * 16. Currently applies to batch queues only.

SMF Info
--------
    Field: `SMF99_QDATA_AVG_INELIGIBLE_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Average number of ineligible queued requests over a policy interval scaled by * 16. Currently applies to batch queues only.
"""
qdata_avg_ineligible_requests.__doc__ = """Average number of ineligible queued requests over a policy interval scaled by * 16. Currently applies to batch queues only.

SMF Info
--------
    Field: `SMF99_QDATA_AVG_INELIGIBLE_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_QDATA_MAP`

Average number of ineligible queued requests over a policy interval scaled by * 16. Currently applies to batch queues only.
"""

iosub_index : Final[Field] = Field(
    name='iosub_index',
    origin='SMF99_IOSUB_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_IOSUB_SAMPLES_MAP,
)
"""Subsystem index. This correlates with SMF999_IOSUB_INDEX.

SMF Info
--------
    Field: `SMF99_IOSUB_INDEX`
    Record: `SMF99S2`
    Map: `SMF99_IOSUB_SAMPLES_MAP`

Subsystem index. This correlates with SMF999_IOSUB_INDEX.
"""
iosub_index.__doc__ = """Subsystem index. This correlates with SMF999_IOSUB_INDEX.

SMF Info
--------
    Field: `SMF99_IOSUB_INDEX`
    Record: `SMF99S2`
    Map: `SMF99_IOSUB_SAMPLES_MAP`

Subsystem index. This correlates with SMF999_IOSUB_INDEX.
"""

iosub_connectsamples : Final[Field] = Field(
    name='iosub_connectsamples',
    origin='SMF99_IOSUB_CONNECTSAMPLES',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_IOSUB_SAMPLES_MAP,
)
"""Connect samples

SMF Info
--------
    Field: `SMF99_IOSUB_CONNECTSAMPLES`
    Record: `SMF99S2`
    Map: `SMF99_IOSUB_SAMPLES_MAP`

Connect samples
"""
iosub_connectsamples.__doc__ = """Connect samples

SMF Info
--------
    Field: `SMF99_IOSUB_CONNECTSAMPLES`
    Record: `SMF99S2`
    Map: `SMF99_IOSUB_SAMPLES_MAP`

Connect samples
"""

iosub_pendingsamples : Final[Field] = Field(
    name='iosub_pendingsamples',
    origin='SMF99_IOSUB_PENDINGSAMPLES',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_IOSUB_SAMPLES_MAP,
)
"""Pending samples

SMF Info
--------
    Field: `SMF99_IOSUB_PENDINGSAMPLES`
    Record: `SMF99S2`
    Map: `SMF99_IOSUB_SAMPLES_MAP`

Pending samples
"""
iosub_pendingsamples.__doc__ = """Pending samples

SMF Info
--------
    Field: `SMF99_IOSUB_PENDINGSAMPLES`
    Record: `SMF99S2`
    Map: `SMF99_IOSUB_SAMPLES_MAP`

Pending samples
"""

speccp1 : Final[Field] = Field(
    name='speccp1',
    origin='SMF99_SPECCP1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SPECRPT,
)
"""word 1

SMF Info
--------
    Field: `SMF99_SPECCP1`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 1
"""
speccp1.__doc__ = """word 1

SMF Info
--------
    Field: `SMF99_SPECCP1`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 1
"""

speccp2 : Final[Field] = Field(
    name='speccp2',
    origin='SMF99_SPECCP2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SPECRPT,
)
"""word 2

SMF Info
--------
    Field: `SMF99_SPECCP2`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 2
"""
speccp2.__doc__ = """word 2

SMF Info
--------
    Field: `SMF99_SPECCP2`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 2
"""

specoffload1 : Final[Field] = Field(
    name='specoffload1',
    origin='SMF99_SPECOFFLOAD1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SPECRPT,
)
"""word 1

SMF Info
--------
    Field: `SMF99_SPECOFFLOAD1`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 1
"""
specoffload1.__doc__ = """word 1

SMF Info
--------
    Field: `SMF99_SPECOFFLOAD1`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 1
"""

specoffload2 : Final[Field] = Field(
    name='specoffload2',
    origin='SMF99_SPECOFFLOAD2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SPECRPT,
)
"""word 2

SMF Info
--------
    Field: `SMF99_SPECOFFLOAD2`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 2
"""
specoffload2.__doc__ = """word 2

SMF Info
--------
    Field: `SMF99_SPECOFFLOAD2`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 2
"""

specoffloadoncp1 : Final[Field] = Field(
    name='specoffloadoncp1',
    origin='SMF99_SPECOFFLOADONCP1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SPECRPT,
)
"""word 1

SMF Info
--------
    Field: `SMF99_SPECOFFLOADONCP1`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 1
"""
specoffloadoncp1.__doc__ = """word 1

SMF Info
--------
    Field: `SMF99_SPECOFFLOADONCP1`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 1
"""

specoffloadoncp2 : Final[Field] = Field(
    name='specoffloadoncp2',
    origin='SMF99_SPECOFFLOADONCP2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SPECRPT,
)
"""word 2

SMF Info
--------
    Field: `SMF99_SPECOFFLOADONCP2`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 2
"""
specoffloadoncp2.__doc__ = """word 2

SMF Info
--------
    Field: `SMF99_SPECOFFLOADONCP2`
    Record: `SMF99S2`
    Map: `SMF99_SPECRPT`

word 2
"""

ai_modelname : Final[Field] = Field(
    name='ai_modelname',
    origin='SMF99_S2_AI_MODELNAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""Model name identifier

SMF Info
--------
    Field: `SMF99_S2_AI_MODELNAME`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Model name identifier
"""
ai_modelname.__doc__ = """Model name identifier

SMF Info
--------
    Field: `SMF99_S2_AI_MODELNAME`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Model name identifier
"""

ai_modelversion : Final[Field] = Field(
    name='ai_modelversion',
    origin='SMF99_S2_AI_MODELVERSION',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""Model version

SMF Info
--------
    Field: `SMF99_S2_AI_MODELVERSION`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Model version
"""
ai_modelversion.__doc__ = """Model version

SMF Info
--------
    Field: `SMF99_S2_AI_MODELVERSION`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Model version
"""

ai_modelusecase : Final[Field] = Field(
    name='ai_modelusecase',
    origin='SMF99_S2_AI_MODELUSECASE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""Model use case identifier

SMF Info
--------
    Field: `SMF99_S2_AI_MODELUSECASE`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Model use case identifier
"""
ai_modelusecase.__doc__ = """Model use case identifier

SMF Info
--------
    Field: `SMF99_S2_AI_MODELUSECASE`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Model use case identifier
"""

ai_flags : Final[Field] = Field(
    name='ai_flags',
    origin='SMF99_S2_AI_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""AI flags

SMF Info
--------
    Field: `SMF99_S2_AI_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI flags
"""
ai_flags.__doc__ = """AI flags

SMF Info
--------
    Field: `SMF99_S2_AI_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI flags
"""

ai_inference_time : Final[Field] = Field(
    name='ai_inference_time',
    origin='SMF99_S2_AI_INFTIME',
    type=FieldType.TIME,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""Duration of last inference request in TOD format

SMF Info
--------
    Field: `SMF99_S2_AI_INFTIME`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Duration of last inference request in TOD format
"""
ai_inference_time.__doc__ = """Duration of last inference request in TOD format

SMF Info
--------
    Field: `SMF99_S2_AI_INFTIME`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Duration of last inference request in TOD format
"""

ai_data0 : Final[Field] = Field(
    name='ai_data0',
    origin='SMF99_S2_AI_DATA0',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""Timestamp of last inference result in TOD format

SMF Info
--------
    Field: `SMF99_S2_AI_DATA0`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Timestamp of last inference result in TOD format
"""
ai_data0.__doc__ = """Timestamp of last inference result in TOD format

SMF Info
--------
    Field: `SMF99_S2_AI_DATA0`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

Timestamp of last inference result in TOD format
"""

ai_prediction : Final[Field] = Field(
    name='ai_prediction',
    origin='SMF99_S2_AI_DATA1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""AI data: active server prediction

SMF Info
--------
    Field: `SMF99_S2_AI_DATA1`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: active server prediction
"""
ai_prediction.__doc__ = """AI data: active server prediction

SMF Info
--------
    Field: `SMF99_S2_AI_DATA1`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: active server prediction
"""

ai_data2 : Final[Field] = Field(
    name='ai_data2',
    origin='SMF99_S2_AI_DATA2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""AI data: active server prediction error

SMF Info
--------
    Field: `SMF99_S2_AI_DATA2`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: active server prediction error
"""
ai_data2.__doc__ = """AI data: active server prediction error

SMF Info
--------
    Field: `SMF99_S2_AI_DATA2`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: active server prediction error
"""

ai_data3 : Final[Field] = Field(
    name='ai_data3',
    origin='SMF99_S2_AI_DATA3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""AI data: cp service prediction

SMF Info
--------
    Field: `SMF99_S2_AI_DATA3`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: cp service prediction
"""
ai_data3.__doc__ = """AI data: cp service prediction

SMF Info
--------
    Field: `SMF99_S2_AI_DATA3`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: cp service prediction
"""

ai_data4 : Final[Field] = Field(
    name='ai_data4',
    origin='SMF99_S2_AI_DATA4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""AI data: cp service prediction error

SMF Info
--------
    Field: `SMF99_S2_AI_DATA4`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: cp service prediction error
"""
ai_data4.__doc__ = """AI data: cp service prediction error

SMF Info
--------
    Field: `SMF99_S2_AI_DATA4`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: cp service prediction error
"""

ai_data5 : Final[Field] = Field(
    name='ai_data5',
    origin='SMF99_S2_AI_DATA5',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""AI data: ziip service prediction

SMF Info
--------
    Field: `SMF99_S2_AI_DATA5`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: ziip service prediction
"""
ai_data5.__doc__ = """AI data: ziip service prediction

SMF Info
--------
    Field: `SMF99_S2_AI_DATA5`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: ziip service prediction
"""

ai_data6 : Final[Field] = Field(
    name='ai_data6',
    origin='SMF99_S2_AI_DATA6',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""AI data: ziip service prediction error

SMF Info
--------
    Field: `SMF99_S2_AI_DATA6`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: ziip service prediction error
"""
ai_data6.__doc__ = """AI data: ziip service prediction error

SMF Info
--------
    Field: `SMF99_S2_AI_DATA6`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: ziip service prediction error
"""

ai_data7 : Final[Field] = Field(
    name='ai_data7',
    origin='SMF99_S2_AI_DATA7',
    type=FieldType.TIME,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""AI data: model data fetch time

SMF Info
--------
    Field: `SMF99_S2_AI_DATA7`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: model data fetch time
"""
ai_data7.__doc__ = """AI data: model data fetch time

SMF Info
--------
    Field: `SMF99_S2_AI_DATA7`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: model data fetch time
"""

ai_data8 : Final[Field] = Field(
    name='ai_data8',
    origin='SMF99_S2_AI_DATA8',
    type=FieldType.TIME,
    record=record,
    record_map=SMF99_S2_AI_DATA_MAP,
)
"""AI data: model processing time

SMF Info
--------
    Field: `SMF99_S2_AI_DATA8`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: model processing time
"""
ai_data8.__doc__ = """AI data: model processing time

SMF Info
--------
    Field: `SMF99_S2_AI_DATA8`
    Record: `SMF99S2`
    Map: `SMF99_S2_AI_DATA_MAP`

AI data: model processing time
"""

rqdata_sys_name : Final[Field] = Field(
    name='rqdata_sys_name',
    origin='SMF99_RQDATA_SYS_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""name of system this RQDATA section represents

SMF Info
--------
    Field: `SMF99_RQDATA_SYS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

name of system this RQDATA section represents
"""
rqdata_sys_name.__doc__ = """name of system this RQDATA section represents

SMF Info
--------
    Field: `SMF99_RQDATA_SYS_NAME`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

name of system this RQDATA section represents
"""

rqdata_flags : Final[Field] = Field(
    name='rqdata_flags',
    origin='SMF99_RQDATA_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""flags

SMF Info
--------
    Field: `SMF99_RQDATA_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

flags
"""
rqdata_flags.__doc__ = """flags

SMF Info
--------
    Field: `SMF99_RQDATA_FLAGS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

flags
"""

rqdata_just_started_server : Final[Field] = Field(
    name='rqdata_just_started_server',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=rqdata_flags,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""This system started at least one server for this work queue in the policy interval that this data represents(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

This system started at least one server for this work queue in the policy interval that this data represents

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rqdata_just_started_server.__doc__ = """This system started at least one server for this work queue in the policy interval that this data represents(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

This system started at least one server for this work queue in the policy interval that this data represents

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

rqdata_cannot_start_server : Final[Field] = Field(
    name='rqdata_cannot_start_server',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=rqdata_flags,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""This system cannot start any servers for this work queue due to some constraint(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

This system cannot start any servers for this work queue due to some constraint

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
rqdata_cannot_start_server.__doc__ = """This system cannot start any servers for this work queue due to some constraint(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

This system cannot start any servers for this work queue due to some constraint

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rqdata_deferred_start_server : Final[Field] = Field(
    name='rqdata_deferred_start_server',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=rqdata_flags,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""This system wanted to add servers for this work queue on the just-completed policy interval, but deferred since another system appears to be a better candidate.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

This system wanted to add servers for this work queue on the just-completed policy interval, but deferred since another system appears to be a better candidate.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
rqdata_deferred_start_server.__doc__ = """This system wanted to add servers for this work queue on the just-completed policy interval, but deferred since another system appears to be a better candidate.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

This system wanted to add servers for this work queue on the just-completed policy interval, but deferred since another system appears to be a better candidate.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

rqdata_managed : Final[Field] = Field(
    name='rqdata_managed',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=rqdata_flags,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""Work queue is managed on this system(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Work queue is managed on this system

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
rqdata_managed.__doc__ = """Work queue is managed on this system(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Work queue is managed on this system

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rqdata_assess_data_valid : Final[Field] = Field(
    name='rqdata_assess_data_valid',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=rqdata_flags,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""Originator sent valid assess data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Originator sent valid assess data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rqdata_assess_data_valid.__doc__ = """Originator sent valid assess data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rqdata_flags`(`SMF99_RQDATA_FLAGS`)
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Originator sent valid assess data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rqdata_active_servers : Final[Field] = Field(
    name='rqdata_active_servers',
    origin='SMF99_RQDATA_ACTIVE_SERVERS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""10-second average number of active servers scaled by * 16

SMF Info
--------
    Field: `SMF99_RQDATA_ACTIVE_SERVERS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

10-second average number of active servers scaled by * 16
"""
rqdata_active_servers.__doc__ = """10-second average number of active servers scaled by * 16

SMF Info
--------
    Field: `SMF99_RQDATA_ACTIVE_SERVERS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

10-second average number of active servers scaled by * 16
"""

rqdata_total_servers : Final[Field] = Field(
    name='rqdata_total_servers',
    origin='SMF99_RQDATA_TOTAL_SERVERS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""10-second average total servers. Includes active and idle servers.

SMF Info
--------
    Field: `SMF99_RQDATA_TOTAL_SERVERS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

10-second average total servers. Includes active and idle servers.
"""
rqdata_total_servers.__doc__ = """10-second average total servers. Includes active and idle servers.

SMF Info
--------
    Field: `SMF99_RQDATA_TOTAL_SERVERS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

10-second average total servers. Includes active and idle servers.
"""

rqdata_avg_total_req : Final[Field] = Field(
    name='rqdata_avg_total_req',
    origin='SMF99_RQDATA_AVG_TOTAL_REQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""Average total requests for the queue eligible to run on the system respresented by this RQDATA entry. This corresponds to the last point plotted on the queue delay plot. Scaled by * 16.

SMF Info
--------
    Field: `SMF99_RQDATA_AVG_TOTAL_REQ`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Average total requests for the queue eligible to run on the system respresented by this RQDATA entry. This corresponds to the last point plotted on the queue delay plot. Scaled by * 16.
"""
rqdata_avg_total_req.__doc__ = """Average total requests for the queue eligible to run on the system respresented by this RQDATA entry. This corresponds to the last point plotted on the queue delay plot. Scaled by * 16.

SMF Info
--------
    Field: `SMF99_RQDATA_AVG_TOTAL_REQ`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Average total requests for the queue eligible to run on the system respresented by this RQDATA entry. This corresponds to the last point plotted on the queue delay plot. Scaled by * 16.
"""

rqdata_count_servers : Final[Field] = Field(
    name='rqdata_count_servers',
    origin='SMF99_RQDATA_#_SERVERS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""Number of servers required for receiver value

SMF Info
--------
    Field: `SMF99_RQDATA_#_SERVERS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Number of servers required for receiver value
"""
rqdata_count_servers.__doc__ = """Number of servers required for receiver value

SMF Info
--------
    Field: `SMF99_RQDATA_#_SERVERS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Number of servers required for receiver value
"""

rqdata_pi_delta : Final[Field] = Field(
    name='rqdata_pi_delta',
    origin='SMF99_RQDATA_PI_DELTA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""PI delta for donor period of highest importance if servers are started

SMF Info
--------
    Field: `SMF99_RQDATA_PI_DELTA`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

PI delta for donor period of highest importance if servers are started
"""
rqdata_pi_delta.__doc__ = """PI delta for donor period of highest importance if servers are started

SMF Info
--------
    Field: `SMF99_RQDATA_PI_DELTA`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

PI delta for donor period of highest importance if servers are started
"""

rqdata_highest_imp : Final[Field] = Field(
    name='rqdata_highest_imp',
    origin='SMF99_RQDATA_HIGHEST_IMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""Highest importance of donor periods negatively affected if servers are started

SMF Info
--------
    Field: `SMF99_RQDATA_HIGHEST_IMP`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Highest importance of donor periods negatively affected if servers are started
"""
rqdata_highest_imp.__doc__ = """Highest importance of donor periods negatively affected if servers are started

SMF Info
--------
    Field: `SMF99_RQDATA_HIGHEST_IMP`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Highest importance of donor periods negatively affected if servers are started
"""

rqdata_waiting_for_sysname : Final[Field] = Field(
    name='rqdata_waiting_for_sysname',
    origin='SMF99_RQDATA_WAITING_FOR_SYSNAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""System name sender is deferring to. Blank if deferring only to collect data from other systems.

SMF Info
--------
    Field: `SMF99_RQDATA_WAITING_FOR_SYSNAME`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

System name sender is deferring to. Blank if deferring only to collect data from other systems.
"""
rqdata_waiting_for_sysname.__doc__ = """System name sender is deferring to. Blank if deferring only to collect data from other systems.

SMF Info
--------
    Field: `SMF99_RQDATA_WAITING_FOR_SYSNAME`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

System name sender is deferring to. Blank if deferring only to collect data from other systems.
"""

rqdata_donor_class : Final[Field] = Field(
    name='rqdata_donor_class',
    origin='SMF99_RQDATA_DONOR_CLASS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""Class name for donor period most impacted by starting servers

SMF Info
--------
    Field: `SMF99_RQDATA_DONOR_CLASS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Class name for donor period most impacted by starting servers
"""
rqdata_donor_class.__doc__ = """Class name for donor period most impacted by starting servers

SMF Info
--------
    Field: `SMF99_RQDATA_DONOR_CLASS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Class name for donor period most impacted by starting servers
"""

rqdata_percount : Final[Field] = Field(
    name='rqdata_percount',
    origin='SMF99_RQDATA_PER#',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""Period number with in class of donor

SMF Info
--------
    Field: `SMF99_RQDATA_PER#`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Period number with in class of donor
"""
rqdata_percount.__doc__ = """Period number with in class of donor

SMF Info
--------
    Field: `SMF99_RQDATA_PER#`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

Period number with in class of donor
"""

rqdata_donor_rgroup : Final[Field] = Field(
    name='rqdata_donor_rgroup',
    origin='SMF99_RQDATA_DONOR_RGROUP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""resource group name for donor period most impacted by starting servers

SMF Info
--------
    Field: `SMF99_RQDATA_DONOR_RGROUP`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

resource group name for donor period most impacted by starting servers
"""
rqdata_donor_rgroup.__doc__ = """resource group name for donor period most impacted by starting servers

SMF Info
--------
    Field: `SMF99_RQDATA_DONOR_RGROUP`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

resource group name for donor period most impacted by starting servers
"""

rqdata_pa_skip : Final[Field] = Field(
    name='rqdata_pa_skip',
    origin='SMF99_RQDATA_PA_SKIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""policy adjustment skip clock

SMF Info
--------
    Field: `SMF99_RQDATA_PA_SKIP`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

policy adjustment skip clock
"""
rqdata_pa_skip.__doc__ = """policy adjustment skip clock

SMF Info
--------
    Field: `SMF99_RQDATA_PA_SKIP`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

policy adjustment skip clock
"""

rqdata_q_skip : Final[Field] = Field(
    name='rqdata_q_skip',
    origin='SMF99_RQDATA_Q_SKIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""defer processing skip clock

SMF Info
--------
    Field: `SMF99_RQDATA_Q_SKIP`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

defer processing skip clock
"""
rqdata_q_skip.__doc__ = """defer processing skip clock

SMF Info
--------
    Field: `SMF99_RQDATA_Q_SKIP`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

defer processing skip clock
"""

rqdata_q_skip_reason : Final[Field] = Field(
    name='rqdata_q_skip_reason',
    origin='SMF99_RQDATA_Q_SKIP_REASON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""reason defer processing skip clock was set

SMF Info
--------
    Field: `SMF99_RQDATA_Q_SKIP_REASON`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

reason defer processing skip clock was set
"""
rqdata_q_skip_reason.__doc__ = """reason defer processing skip clock was set

SMF Info
--------
    Field: `SMF99_RQDATA_Q_SKIP_REASON`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

reason defer processing skip clock was set
"""

rqdata_avg_queued_requests : Final[Field] = Field(
    name='rqdata_avg_queued_requests',
    origin='SMF99_RQDATA_AVG_QUEUED_REQUESTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""average number of queued requests over a policy interval scaled by * 16

SMF Info
--------
    Field: `SMF99_RQDATA_AVG_QUEUED_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

average number of queued requests over a policy interval scaled by * 16
"""
rqdata_avg_queued_requests.__doc__ = """average number of queued requests over a policy interval scaled by * 16

SMF Info
--------
    Field: `SMF99_RQDATA_AVG_QUEUED_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

average number of queued requests over a policy interval scaled by * 16
"""

rqdata_avg_ineligible_requests : Final[Field] = Field(
    name='rqdata_avg_ineligible_requests',
    origin='SMF99_RQDATA_AVG_INELIGIBLE_REQUESTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""average number of ineligible queued requests over a policy interval scaled by * 16

SMF Info
--------
    Field: `SMF99_RQDATA_AVG_INELIGIBLE_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

average number of ineligible queued requests over a policy interval scaled by * 16
"""
rqdata_avg_ineligible_requests.__doc__ = """average number of ineligible queued requests over a policy interval scaled by * 16

SMF Info
--------
    Field: `SMF99_RQDATA_AVG_INELIGIBLE_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

average number of ineligible queued requests over a policy interval scaled by * 16
"""

rqdata_avg_constraint_requests : Final[Field] = Field(
    name='rqdata_avg_constraint_requests',
    origin='SMF99_RQDATA_AVG_CONSTRAINT_REQUESTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_RQDATA_MAP,
)
"""average number of queued requests with affinity to constraint systems only scaled by * 16

SMF Info
--------
    Field: `SMF99_RQDATA_AVG_CONSTRAINT_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

average number of queued requests with affinity to constraint systems only scaled by * 16
"""
rqdata_avg_constraint_requests.__doc__ = """average number of queued requests with affinity to constraint systems only scaled by * 16

SMF Info
--------
    Field: `SMF99_RQDATA_AVG_CONSTRAINT_REQUESTS`
    Record: `SMF99S2`
    Map: `SMF99_RQDATA_MAP`

average number of queued requests with affinity to constraint systems only scaled by * 16
"""
