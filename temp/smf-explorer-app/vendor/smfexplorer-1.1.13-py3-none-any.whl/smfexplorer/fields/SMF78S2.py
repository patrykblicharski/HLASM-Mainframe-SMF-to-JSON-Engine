# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 78 Suptype 2"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=78,
                                smf_subtype=2,
                                spec='SMF 78 Suptype 2',
                                post=None)
"""SMF 78 Suptype 2"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF78PRO: Final[RecordMap] = RecordMap(
    origin='SMF78PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R782COMN: Final[RecordMap] = RecordMap(
    origin='R782COMN',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Common storage data section',
    post=None,
    record_mapping=False)
"""Common storage data section"""
R782PVT: Final[RecordMap] = RecordMap(
    origin='R782PVT',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='VIRTUAL STORAGE PRIVATE DATA',
    post=None,
    record_mapping=False)
"""VIRTUAL STORAGE PRIVATE DATA"""
R782PVSP: Final[RecordMap] = RecordMap(
    origin='R782PVSP',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Private area subpool section',
    post=None,
    record_mapping=False)
"""Private area subpool section"""
R782SQAU: Final[RecordMap] = RecordMap(
    origin='R782SQAU',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='System queue area (SQA) usage both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""System queue area (SQA) usage both above and below 16 megabytes"""
R782CSAU: Final[RecordMap] = RecordMap(
    origin='R782CSAU',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='CSA usage both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""CSA usage both above and below 16 megabytes"""
R782CSAF: Final[RecordMap] = RecordMap(
    origin='R782CSAF',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='Free CSA both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""Free CSA both above and below 16 megabytes"""
R782CSLF: Final[RecordMap] = RecordMap(
    origin='R782CSLF',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='Largest free block of CSA both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""Largest free block of CSA both above and below 16 megabytes"""
R782CSAL: Final[RecordMap] = RecordMap(
    origin='R782CSAL',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='CSA allocated area size (in bytes) both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""CSA allocated area size (in bytes) both above and below 16 megabytes"""
R782SQAF: Final[RecordMap] = RecordMap(
    origin='R782SQAF',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='Free system queue area (SQA) both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""Free system queue area (SQA) both above and below 16 megabytes"""
R782SQLF: Final[RecordMap] = RecordMap(
    origin='R782SQLF',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='Largest free block of system queue area (SQA) both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""Largest free block of system queue area (SQA) both above and below 16 megabytes"""
R782SQAL: Final[RecordMap] = RecordMap(
    origin='R782SQAL',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='System queue area (SQA) allocated area size (in bytes) both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""System queue area (SQA) allocated area size (in bytes) both above and below 16 megabytes"""
R782SQEX: Final[RecordMap] = RecordMap(
    origin='R782SQEX',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='System queue area (SQA) expansion into CSA both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""System queue area (SQA) expansion into CSA both above and below 16 megabytes"""
R782226: Final[RecordMap] = RecordMap(
    origin='R782226',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='System queue area (SQA) subpool 226 (below 16 megabytes)',
    post=None,
    record_mapping=False)
"""System queue area (SQA) subpool 226 (below 16 megabytes)"""
R782239: Final[RecordMap] = RecordMap(
    origin='R782239',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='System queue area (SQA) subpool 239 (below 16 megabytes)',
    post=None,
    record_mapping=False)
"""System queue area (SQA) subpool 239 (below 16 megabytes)"""
R782245: Final[RecordMap] = RecordMap(
    origin='R782245',
    record=record,
    parent=R782COMN,
    is_multiple=False,
    is_compound=False,
    spec='System queue area (SQA) subpool 245 (below 16 megabytes)',
    post=None,
    record_mapping=False)
"""System queue area (SQA) subpool 245 (below 16 megabytes)"""
R782CSAK: Final[RecordMap] = RecordMap(
    origin='R782CSAK',
    record=record,
    parent=R782COMN,
    is_multiple=True,
    is_compound=False,
    spec='CSA used both above and below 16 megabytes by subpool key.',
    post=None,
    record_mapping=False)
"""CSA used both above and below 16 megabytes by subpool key."""
R782227K: Final[RecordMap] = RecordMap(
    origin='R782227K',
    record=record,
    parent=R782COMN,
    is_multiple=True,
    is_compound=False,
    spec='CSA subpool 227 (below 16 megabytes) by key',
    post=None,
    record_mapping=False)
"""CSA subpool 227 (below 16 megabytes) by key"""
R782228K: Final[RecordMap] = RecordMap(
    origin='R782228K',
    record=record,
    parent=R782COMN,
    is_multiple=True,
    is_compound=False,
    spec='CSA subpool 228 (below 16 megabytes) by key',
    post=None,
    record_mapping=False)
"""CSA subpool 228 (below 16 megabytes) by key"""
R782231K: Final[RecordMap] = RecordMap(
    origin='R782231K',
    record=record,
    parent=R782COMN,
    is_multiple=True,
    is_compound=False,
    spec='CSA subpool 231 (below 16 megabytes) by key',
    post=None,
    record_mapping=False)
"""CSA subpool 231 (below 16 megabytes) by key"""
R782241K: Final[RecordMap] = RecordMap(
    origin='R782241K',
    record=record,
    parent=R782COMN,
    is_multiple=True,
    is_compound=False,
    spec='CSA subpool 241 (below 16 megabytes) by key',
    post=None,
    record_mapping=False)
"""CSA subpool 241 (below 16 megabytes) by key"""
R782LSFP: Final[RecordMap] = RecordMap(
    origin='R782LSFP',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='LSQA/SWA/229/230/249 free pages both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""LSQA/SWA/229/230/249 free pages both above and below 16 megabytes"""
R782LSFB: Final[RecordMap] = RecordMap(
    origin='R782LSFB',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='LSQA/SWA/229/230/249 largest free block both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""LSQA/SWA/229/230/249 largest free block both above and below 16 megabytes"""
R782LSAL: Final[RecordMap] = RecordMap(
    origin='R782LSAL',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='LSQA/SWA/229/230/249 allocated area size (in bytes) both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""LSQA/SWA/229/230/249 allocated area size (in bytes) both above and below 16 megabytes"""
R782LSPA: Final[RecordMap] = RecordMap(
    origin='R782LSPA',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='LSQA/SWA/229/230/249 allocated pages both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""LSQA/SWA/229/230/249 allocated pages both above and below 16 megabytes"""
R782USFP: Final[RecordMap] = RecordMap(
    origin='R782USFP',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='User region free pages both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""User region free pages both above and below 16 megabytes"""
R782USFB: Final[RecordMap] = RecordMap(
    origin='R782USFB',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='User region largest free block both above and below 16 megabytes',
    post=None,
    record_mapping=False)
"""User region largest free block both above and below 16 megabytes"""
R782USAL: Final[RecordMap] = RecordMap(
    origin='R782USAL',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='User region allocated area size (in bytes) above 16 megabytes',
    post=None,
    record_mapping=False)
"""User region allocated area size (in bytes) above 16 megabytes"""
R782USPA: Final[RecordMap] = RecordMap(
    origin='R782USPA',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='User region pages allocated both below and above 16 megabytes',
    post=None,
    record_mapping=False)
"""User region pages allocated both below and above 16 megabytes"""
R782TOBY: Final[RecordMap] = RecordMap(
    origin='R782TOBY',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Number of bytes allocated in storage above the 2-GB-line',
    post=None,
    record_mapping=False)
"""Number of bytes allocated in storage above the 2-GB-line"""
R782SHBY: Final[RecordMap] = RecordMap(
    origin='R782SHBY',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Number of shared bytes allocated in storage above the 2-GB-line',
    post=None,
    record_mapping=False)
"""Number of shared bytes allocated in storage above the 2-GB-line"""
R782COBY: Final[RecordMap] = RecordMap(
    origin='R782COBY',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Number of high virtual common bytes allocated',
    post=None,
    record_mapping=False)
"""Number of high virtual common bytes allocated"""
R782TOMO: Final[RecordMap] = RecordMap(
    origin='R782TOMO',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Total number of memory objects allocated in high virtual storage',
    post=None,
    record_mapping=False)
"""Total number of memory objects allocated in high virtual storage"""
R782SHMO: Final[RecordMap] = RecordMap(
    origin='R782SHMO',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Number of memory objects allocated in high virtual shared storage',
    post=None,
    record_mapping=False)
"""Number of memory objects allocated in high virtual shared storage"""
R782COMO: Final[RecordMap] = RecordMap(
    origin='R782COMO',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Number of memory objects allocated in high virtual common storage',
    post=None,
    record_mapping=False)
"""Number of memory objects allocated in high virtual common storage"""
R782LGMO: Final[RecordMap] = RecordMap(
    origin='R782LGMO',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Number of memory objects that can be backed in 1 MB frames',
    post=None,
    record_mapping=False)
"""Number of memory objects that can be backed in 1 MB frames"""
R782TOFR: Final[RecordMap] = RecordMap(
    origin='R782TOFR',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Number of 1 MB pages that are backed in central storage',
    post=None,
    record_mapping=False)
"""Number of 1 MB pages that are backed in central storage"""
R782FIFR: Final[RecordMap] = RecordMap(
    origin='R782FIFR',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Number of 1 MB frames that can be used by fixed memory objects',
    post=None,
    record_mapping=False)
"""Number of 1 MB frames that can be used by fixed memory objects"""
R782PAFR: Final[RecordMap] = RecordMap(
    origin='R782PAFR',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='Number of 1 MB frames that are used by pageable/DREF memory objects',
    post=None,
    record_mapping=False)
"""Number of 1 MB frames that are used by pageable/DREF memory objects"""
R782LSMO: Final[RecordMap] = RecordMap(
    origin='R782LSMO',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='MIN/MAX/AVG DATA FOR MEMORY OBJECTS',
    post=None,
    record_mapping=False)
"""MIN/MAX/AVG DATA FOR MEMORY OBJECTS"""
R782GFMO: Final[RecordMap] = RecordMap(
    origin='R782GFMO',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='MIN/MAX/AVG DATA FOR MEMORY OBJECTS',
    post=None,
    record_mapping=False)
"""MIN/MAX/AVG DATA FOR MEMORY OBJECTS"""
R782GFFR: Final[RecordMap] = RecordMap(
    origin='R782GFFR',
    record=record,
    parent=R782PVT,
    is_multiple=False,
    is_compound=False,
    spec='MIN/MAX/AVG DATA FOR MEMORY OBJECTS',
    post=None,
    record_mapping=False)
"""MIN/MAX/AVG DATA FOR MEMORY OBJECTS"""
R782SPD: Final[RecordMap] = RecordMap(
    origin='R782SPD',
    record=record,
    parent=R782PVSP,
    is_multiple=False,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""

date : Final[Field] = Field(
    name='date',
    origin='SMF78DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF78DTE`
    Record: `SMF78S2`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF78DTE`
    Record: `SMF78S2`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF78TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF78TME`
    Record: `SMF78S2`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF78TME`
    Record: `SMF78S2`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF78DTE`), `time`(`SMF78TME`)
    Record: `SMF78S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF78DTE`), `time`(`SMF78TME`)
    Record: `SMF78S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF78LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF78LEN`
    Record: `SMF78S2`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF78LEN`
    Record: `SMF78S2`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF78SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF78SEG`
    Record: `SMF78S2`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF78SEG`
    Record: `SMF78S2`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF78FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF78FLG`
    Record: `SMF78S2`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF78FLG`
    Record: `SMF78S2`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S2`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF78RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF78RTY`
    Record: `SMF78S2`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF78RTY`
    Record: `SMF78S2`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF78TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF78TME`
    Record: `SMF78S2`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF78TME`
    Record: `SMF78S2`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF78DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF78DTE`
    Record: `SMF78S2`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF78DTE`
    Record: `SMF78S2`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF78SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF78SID`
    Record: `SMF78S2`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF78SID`
    Record: `SMF78S2`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF78SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF78SSI`
    Record: `SMF78S2`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF78SSI`
    Record: `SMF78S2`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF78STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF78STY`
    Record: `SMF78S2`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF78STY`
    Record: `SMF78S2`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF78TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF78TRN`
    Record: `SMF78S2`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF78TRN`
    Record: `SMF78S2`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF78PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF78PRS`
    Record: `SMF78S2`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF78PRS`
    Record: `SMF78S2`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF78PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF78PRL`
    Record: `SMF78S2`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF78PRL`
    Record: `SMF78S2`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF78PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF78PRN`
    Record: `SMF78S2`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF78PRN`
    Record: `SMF78S2`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

dcs : Final[Field] = Field(
    name='dcs',
    origin='SMF78DCS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to configuration section R781CS (subtype 1), data section R782COMN (subtype 2) or configuration section R783CS (subtype 3)

SMF Info
--------
    Field: `SMF78DCS`
    Record: `SMF78S2`
    Map: Not part of a map

Offset to configuration section R781CS (subtype 1), data section R782COMN (subtype 2) or configuration section R783CS (subtype 3)
"""
dcs.__doc__ = """Offset to configuration section R781CS (subtype 1), data section R782COMN (subtype 2) or configuration section R783CS (subtype 3)

SMF Info
--------
    Field: `SMF78DCS`
    Record: `SMF78S2`
    Map: Not part of a map

Offset to configuration section R781CS (subtype 1), data section R782COMN (subtype 2) or configuration section R783CS (subtype 3)
"""

dcl : Final[Field] = Field(
    name='dcl',
    origin='SMF78DCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF SECTION

SMF Info
--------
    Field: `SMF78DCL`
    Record: `SMF78S2`
    Map: Not part of a map

LENGTH OF SECTION
"""
dcl.__doc__ = """LENGTH OF SECTION

SMF Info
--------
    Field: `SMF78DCL`
    Record: `SMF78S2`
    Map: Not part of a map

LENGTH OF SECTION
"""

dcn : Final[Field] = Field(
    name='dcn',
    origin='SMF78DCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF SECTIONS

SMF Info
--------
    Field: `SMF78DCN`
    Record: `SMF78S2`
    Map: Not part of a map

NUMBER OF SECTIONS
"""
dcn.__doc__ = """NUMBER OF SECTIONS

SMF Info
--------
    Field: `SMF78DCN`
    Record: `SMF78S2`
    Map: Not part of a map

NUMBER OF SECTIONS
"""

ass : Final[Field] = Field(
    name='ass',
    origin='SMF78ASS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to data section R781DS (subtype 1) R782PVT (subtype 2) R783DS (subtype 3)

SMF Info
--------
    Field: `SMF78ASS`
    Record: `SMF78S2`
    Map: Not part of a map

Offset to data section R781DS (subtype 1) R782PVT (subtype 2) R783DS (subtype 3)
"""
ass.__doc__ = """Offset to data section R781DS (subtype 1) R782PVT (subtype 2) R783DS (subtype 3)

SMF Info
--------
    Field: `SMF78ASS`
    Record: `SMF78S2`
    Map: Not part of a map

Offset to data section R781DS (subtype 1) R782PVT (subtype 2) R783DS (subtype 3)
"""

asl : Final[Field] = Field(
    name='asl',
    origin='SMF78ASL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF78ASL`
    Record: `SMF78S2`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""
asl.__doc__ = """LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF78ASL`
    Record: `SMF78S2`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""

asn : Final[Field] = Field(
    name='asn',
    origin='SMF78ASN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DATA SECTIONS

SMF Info
--------
    Field: `SMF78ASN`
    Record: `SMF78S2`
    Map: Not part of a map

NUMBER OF DATA SECTIONS
"""
asn.__doc__ = """NUMBER OF DATA SECTIONS

SMF Info
--------
    Field: `SMF78ASN`
    Record: `SMF78S2`
    Map: Not part of a map

NUMBER OF DATA SECTIONS
"""

qds : Final[Field] = Field(
    name='qds',
    origin='SMF78QDS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to IOQ global section

SMF Info
--------
    Field: `SMF78QDS`
    Record: `SMF78S2`
    Map: Not part of a map

Offset to IOQ global section
"""
qds.__doc__ = """Offset to IOQ global section

SMF Info
--------
    Field: `SMF78QDS`
    Record: `SMF78S2`
    Map: Not part of a map

Offset to IOQ global section
"""

qdl : Final[Field] = Field(
    name='qdl',
    origin='SMF78QDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of IOQ global section

SMF Info
--------
    Field: `SMF78QDL`
    Record: `SMF78S2`
    Map: Not part of a map

Length of IOQ global section
"""
qdl.__doc__ = """Length of IOQ global section

SMF Info
--------
    Field: `SMF78QDL`
    Record: `SMF78S2`
    Map: Not part of a map

Length of IOQ global section
"""

qdn : Final[Field] = Field(
    name='qdn',
    origin='SMF78QDN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of IOQ global section

SMF Info
--------
    Field: `SMF78QDN`
    Record: `SMF78S2`
    Map: Not part of a map

Number of IOQ global section
"""
qdn.__doc__ = """Number of IOQ global section

SMF Info
--------
    Field: `SMF78QDN`
    Record: `SMF78S2`
    Map: Not part of a map

Number of IOQ global section
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF78MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF78MFV`
    Record: `SMF78S2`
    Map: `SMF78PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF78MFV`
    Record: `SMF78S2`
    Map: `SMF78PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF78PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF78PRD`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF78PRD`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF78IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF78PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF78IST`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF78IST`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF78DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF78PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF78DAT`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF78DAT`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF78INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF78PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF78INT`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF78INT`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF78SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF78SAM`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF78SAM`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF78FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF78FLA`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF78FLA`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF78CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF78PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF78CYC`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF78CYC`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF78MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF78MVS`
    Record: `SMF78S2`
    Map: `SMF78PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF78MVS`
    Record: `SMF78S2`
    Map: `SMF78PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF78IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF78IML`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF78IML`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF78PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF78PRF`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF78PRF`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S2`
    Map: `SMF78PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF78PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF78PTN`
    Record: `SMF78S2`
    Map: `SMF78PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF78PTN`
    Record: `SMF78S2`
    Map: `SMF78PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF78SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF78SRL`
    Record: `SMF78S2`
    Map: `SMF78PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF78SRL`
    Record: `SMF78S2`
    Map: `SMF78PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF78IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF78PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF78IET`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF78IET`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF78LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF78LGO`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF78LGO`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF78RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF78RAO`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF78RAO`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF78RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF78RAL`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF78RAL`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF78RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF78RAN`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF78RAN`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF78OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF78OIL`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF78OIL`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF78SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF78SYN`
    Record: `SMF78S2`
    Map: `SMF78PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF78SYN`
    Record: `SMF78S2`
    Map: `SMF78PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF78GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF78PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF78GIE`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF78GIE`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF78XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF78XNM`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF78XNM`
    Record: `SMF78S2`
    Map: `SMF78PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF78SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF78SNM`
    Record: `SMF78S2`
    Map: `SMF78PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF78SNM`
    Record: `SMF78S2`
    Map: `SMF78PRO`

System name for current system as defined in CVTSNAME
"""

r782pa : Final[Field] = Field(
    name='r782pa',
    origin='R782PA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""PRIVATE AREA ADDRESS

SMF Info
--------
    Field: `R782PA`
    Record: `SMF78S2`
    Map: `R782COMN`

PRIVATE AREA ADDRESS
"""
r782pa.__doc__ = """PRIVATE AREA ADDRESS

SMF Info
--------
    Field: `R782PA`
    Record: `SMF78S2`
    Map: `R782COMN`

PRIVATE AREA ADDRESS
"""

r782ps : Final[Field] = Field(
    name='r782ps',
    origin='R782PS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""PRIVATE AREA SIZE

SMF Info
--------
    Field: `R782PS`
    Record: `SMF78S2`
    Map: `R782COMN`

PRIVATE AREA SIZE
"""
r782ps.__doc__ = """PRIVATE AREA SIZE

SMF Info
--------
    Field: `R782PS`
    Record: `SMF78S2`
    Map: `R782COMN`

PRIVATE AREA SIZE
"""

r782epa : Final[Field] = Field(
    name='r782epa',
    origin='R782EPA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED PRIVATE AREA ADDRESS

SMF Info
--------
    Field: `R782EPA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED PRIVATE AREA ADDRESS
"""
r782epa.__doc__ = """EXTENDED PRIVATE AREA ADDRESS

SMF Info
--------
    Field: `R782EPA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED PRIVATE AREA ADDRESS
"""

r782eps : Final[Field] = Field(
    name='r782eps',
    origin='R782EPS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED PRIVATE AREA SIZE

SMF Info
--------
    Field: `R782EPS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED PRIVATE AREA SIZE
"""
r782eps.__doc__ = """EXTENDED PRIVATE AREA SIZE

SMF Info
--------
    Field: `R782EPS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED PRIVATE AREA SIZE
"""

r782ca : Final[Field] = Field(
    name='r782ca',
    origin='R782CA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""CSA ADDRESS

SMF Info
--------
    Field: `R782CA`
    Record: `SMF78S2`
    Map: `R782COMN`

CSA ADDRESS
"""
r782ca.__doc__ = """CSA ADDRESS

SMF Info
--------
    Field: `R782CA`
    Record: `SMF78S2`
    Map: `R782COMN`

CSA ADDRESS
"""

r782cs : Final[Field] = Field(
    name='r782cs',
    origin='R782CS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""CSA SIZE

SMF Info
--------
    Field: `R782CS`
    Record: `SMF78S2`
    Map: `R782COMN`

CSA SIZE
"""
r782cs.__doc__ = """CSA SIZE

SMF Info
--------
    Field: `R782CS`
    Record: `SMF78S2`
    Map: `R782COMN`

CSA SIZE
"""

r782eca : Final[Field] = Field(
    name='r782eca',
    origin='R782ECA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED CSA ADDRESS

SMF Info
--------
    Field: `R782ECA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED CSA ADDRESS
"""
r782eca.__doc__ = """EXTENDED CSA ADDRESS

SMF Info
--------
    Field: `R782ECA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED CSA ADDRESS
"""

r782ecs : Final[Field] = Field(
    name='r782ecs',
    origin='R782ECS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED CSA SIZE

SMF Info
--------
    Field: `R782ECS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED CSA SIZE
"""
r782ecs.__doc__ = """EXTENDED CSA SIZE

SMF Info
--------
    Field: `R782ECS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED CSA SIZE
"""

r782flg : Final[Field] = Field(
    name='r782flg',
    origin='R782FLG',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""FLAGS

SMF Info
--------
    Field: `R782FLG`
    Record: `SMF78S2`
    Map: `R782COMN`

FLAGS
"""
r782flg.__doc__ = """FLAGS

SMF Info
--------
    Field: `R782FLG`
    Record: `SMF78S2`
    Map: `R782COMN`

FLAGS
"""

r782rucd : Final[Field] = Field(
    name='r782rucd',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r782flg,
    record=record,
    record_map=R782COMN,
)
"""=1 Restricted Use CSA (RUCSA) is defined(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flg`(`R782FLG`)
    Record: `SMF78S2`
    Map: `R782COMN`

=1 Restricted Use CSA (RUCSA) is defined

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r782rucd.__doc__ = """=1 Restricted Use CSA (RUCSA) is defined(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flg`(`R782FLG`)
    Record: `SMF78S2`
    Map: `R782COMN`

=1 Restricted Use CSA (RUCSA) is defined

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r782mla : Final[Field] = Field(
    name='r782mla',
    origin='R782MLA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""MLPA ADDRESS

SMF Info
--------
    Field: `R782MLA`
    Record: `SMF78S2`
    Map: `R782COMN`

MLPA ADDRESS
"""
r782mla.__doc__ = """MLPA ADDRESS

SMF Info
--------
    Field: `R782MLA`
    Record: `SMF78S2`
    Map: `R782COMN`

MLPA ADDRESS
"""

r782mls : Final[Field] = Field(
    name='r782mls',
    origin='R782MLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""MLPA SIZE

SMF Info
--------
    Field: `R782MLS`
    Record: `SMF78S2`
    Map: `R782COMN`

MLPA SIZE
"""
r782mls.__doc__ = """MLPA SIZE

SMF Info
--------
    Field: `R782MLS`
    Record: `SMF78S2`
    Map: `R782COMN`

MLPA SIZE
"""

r782emla : Final[Field] = Field(
    name='r782emla',
    origin='R782EMLA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED MLPA ADDRESS

SMF Info
--------
    Field: `R782EMLA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED MLPA ADDRESS
"""
r782emla.__doc__ = """EXTENDED MLPA ADDRESS

SMF Info
--------
    Field: `R782EMLA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED MLPA ADDRESS
"""

r782emls : Final[Field] = Field(
    name='r782emls',
    origin='R782EMLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED MLPA SIZE

SMF Info
--------
    Field: `R782EMLS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED MLPA SIZE
"""
r782emls.__doc__ = """EXTENDED MLPA SIZE

SMF Info
--------
    Field: `R782EMLS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED MLPA SIZE
"""

r782fla : Final[Field] = Field(
    name='r782fla',
    origin='R782FLA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""FLPA ADDRESS

SMF Info
--------
    Field: `R782FLA`
    Record: `SMF78S2`
    Map: `R782COMN`

FLPA ADDRESS
"""
r782fla.__doc__ = """FLPA ADDRESS

SMF Info
--------
    Field: `R782FLA`
    Record: `SMF78S2`
    Map: `R782COMN`

FLPA ADDRESS
"""

r782fls : Final[Field] = Field(
    name='r782fls',
    origin='R782FLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""FLPA SIZE

SMF Info
--------
    Field: `R782FLS`
    Record: `SMF78S2`
    Map: `R782COMN`

FLPA SIZE
"""
r782fls.__doc__ = """FLPA SIZE

SMF Info
--------
    Field: `R782FLS`
    Record: `SMF78S2`
    Map: `R782COMN`

FLPA SIZE
"""

r782efla : Final[Field] = Field(
    name='r782efla',
    origin='R782EFLA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""EFLPA ADDRESS

SMF Info
--------
    Field: `R782EFLA`
    Record: `SMF78S2`
    Map: `R782COMN`

EFLPA ADDRESS
"""
r782efla.__doc__ = """EFLPA ADDRESS

SMF Info
--------
    Field: `R782EFLA`
    Record: `SMF78S2`
    Map: `R782COMN`

EFLPA ADDRESS
"""

r782efls : Final[Field] = Field(
    name='r782efls',
    origin='R782EFLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""EFLPA SIZE

SMF Info
--------
    Field: `R782EFLS`
    Record: `SMF78S2`
    Map: `R782COMN`

EFLPA SIZE
"""
r782efls.__doc__ = """EFLPA SIZE

SMF Info
--------
    Field: `R782EFLS`
    Record: `SMF78S2`
    Map: `R782COMN`

EFLPA SIZE
"""

r782pla : Final[Field] = Field(
    name='r782pla',
    origin='R782PLA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""PLPA ADDRESS

SMF Info
--------
    Field: `R782PLA`
    Record: `SMF78S2`
    Map: `R782COMN`

PLPA ADDRESS
"""
r782pla.__doc__ = """PLPA ADDRESS

SMF Info
--------
    Field: `R782PLA`
    Record: `SMF78S2`
    Map: `R782COMN`

PLPA ADDRESS
"""

r782pls : Final[Field] = Field(
    name='r782pls',
    origin='R782PLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""PLPA SIZE

SMF Info
--------
    Field: `R782PLS`
    Record: `SMF78S2`
    Map: `R782COMN`

PLPA SIZE
"""
r782pls.__doc__ = """PLPA SIZE

SMF Info
--------
    Field: `R782PLS`
    Record: `SMF78S2`
    Map: `R782COMN`

PLPA SIZE
"""

r782elpa : Final[Field] = Field(
    name='r782elpa',
    origin='R782ELPA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED PLPA ADDRESS

SMF Info
--------
    Field: `R782ELPA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED PLPA ADDRESS
"""
r782elpa.__doc__ = """EXTENDED PLPA ADDRESS

SMF Info
--------
    Field: `R782ELPA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED PLPA ADDRESS
"""

r782elps : Final[Field] = Field(
    name='r782elps',
    origin='R782ELPS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED PLPA ASIZE

SMF Info
--------
    Field: `R782ELPS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED PLPA ASIZE
"""
r782elps.__doc__ = """EXTENDED PLPA ASIZE

SMF Info
--------
    Field: `R782ELPS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED PLPA ASIZE
"""

r782sa : Final[Field] = Field(
    name='r782sa',
    origin='R782SA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""SQA ADDRESS

SMF Info
--------
    Field: `R782SA`
    Record: `SMF78S2`
    Map: `R782COMN`

SQA ADDRESS
"""
r782sa.__doc__ = """SQA ADDRESS

SMF Info
--------
    Field: `R782SA`
    Record: `SMF78S2`
    Map: `R782COMN`

SQA ADDRESS
"""

r782ss : Final[Field] = Field(
    name='r782ss',
    origin='R782SS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""SQA SIZE

SMF Info
--------
    Field: `R782SS`
    Record: `SMF78S2`
    Map: `R782COMN`

SQA SIZE
"""
r782ss.__doc__ = """SQA SIZE

SMF Info
--------
    Field: `R782SS`
    Record: `SMF78S2`
    Map: `R782COMN`

SQA SIZE
"""

r782esa : Final[Field] = Field(
    name='r782esa',
    origin='R782ESA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED SQA ADDRESS

SMF Info
--------
    Field: `R782ESA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED SQA ADDRESS
"""
r782esa.__doc__ = """EXTENDED SQA ADDRESS

SMF Info
--------
    Field: `R782ESA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED SQA ADDRESS
"""

r782ess : Final[Field] = Field(
    name='r782ess',
    origin='R782ESS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED SQA SIZE

SMF Info
--------
    Field: `R782ESS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED SQA SIZE
"""
r782ess.__doc__ = """EXTENDED SQA SIZE

SMF Info
--------
    Field: `R782ESS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED SQA SIZE
"""

r782na : Final[Field] = Field(
    name='r782na',
    origin='R782NA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""NUCLEUS ADDRESS

SMF Info
--------
    Field: `R782NA`
    Record: `SMF78S2`
    Map: `R782COMN`

NUCLEUS ADDRESS
"""
r782na.__doc__ = """NUCLEUS ADDRESS

SMF Info
--------
    Field: `R782NA`
    Record: `SMF78S2`
    Map: `R782COMN`

NUCLEUS ADDRESS
"""

r782ns : Final[Field] = Field(
    name='r782ns',
    origin='R782NS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""NUCLEUS SIZE

SMF Info
--------
    Field: `R782NS`
    Record: `SMF78S2`
    Map: `R782COMN`

NUCLEUS SIZE
"""
r782ns.__doc__ = """NUCLEUS SIZE

SMF Info
--------
    Field: `R782NS`
    Record: `SMF78S2`
    Map: `R782COMN`

NUCLEUS SIZE
"""

r782ena : Final[Field] = Field(
    name='r782ena',
    origin='R782ENA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED NUCLEUS ADDRESS

SMF Info
--------
    Field: `R782ENA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED NUCLEUS ADDRESS
"""
r782ena.__doc__ = """EXTENDED NUCLEUS ADDRESS

SMF Info
--------
    Field: `R782ENA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED NUCLEUS ADDRESS
"""

r782ens : Final[Field] = Field(
    name='r782ens',
    origin='R782ENS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED NUCLEUS SIZE

SMF Info
--------
    Field: `R782ENS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED NUCLEUS SIZE
"""
r782ens.__doc__ = """EXTENDED NUCLEUS SIZE

SMF Info
--------
    Field: `R782ENS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED NUCLEUS SIZE
"""

r782nl : Final[Field] = Field(
    name='r782nl',
    origin='R782NL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""NON-ACCESSIBLE PLPA SIZE

SMF Info
--------
    Field: `R782NL`
    Record: `SMF78S2`
    Map: `R782COMN`

NON-ACCESSIBLE PLPA SIZE
"""
r782nl.__doc__ = """NON-ACCESSIBLE PLPA SIZE

SMF Info
--------
    Field: `R782NL`
    Record: `SMF78S2`
    Map: `R782COMN`

NON-ACCESSIBLE PLPA SIZE
"""

r782enl : Final[Field] = Field(
    name='r782enl',
    origin='R782ENL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""NON-ACCESSIBLE EPLPA SIZE

SMF Info
--------
    Field: `R782ENL`
    Record: `SMF78S2`
    Map: `R782COMN`

NON-ACCESSIBLE EPLPA SIZE
"""
r782enl.__doc__ = """NON-ACCESSIBLE EPLPA SIZE

SMF Info
--------
    Field: `R782ENL`
    Record: `SMF78S2`
    Map: `R782COMN`

NON-ACCESSIBLE EPLPA SIZE
"""

r782lpai : Final[Field] = Field(
    name='r782lpai',
    origin='R782LPAI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""INTERMODULE SPACE IN LPA

SMF Info
--------
    Field: `R782LPAI`
    Record: `SMF78S2`
    Map: `R782COMN`

INTERMODULE SPACE IN LPA
"""
r782lpai.__doc__ = """INTERMODULE SPACE IN LPA

SMF Info
--------
    Field: `R782LPAI`
    Record: `SMF78S2`
    Map: `R782COMN`

INTERMODULE SPACE IN LPA
"""

r782elpi : Final[Field] = Field(
    name='r782elpi',
    origin='R782ELPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""INTERMODULE SPACE IN ELPA

SMF Info
--------
    Field: `R782ELPI`
    Record: `SMF78S2`
    Map: `R782COMN`

INTERMODULE SPACE IN ELPA
"""
r782elpi.__doc__ = """INTERMODULE SPACE IN ELPA

SMF Info
--------
    Field: `R782ELPI`
    Record: `SMF78S2`
    Map: `R782COMN`

INTERMODULE SPACE IN ELPA
"""

r782mr : Final[Field] = Field(
    name='r782mr',
    origin='R782MR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""MAXIMUM USER REGION BELOW 16M

SMF Info
--------
    Field: `R782MR`
    Record: `SMF78S2`
    Map: `R782COMN`

MAXIMUM USER REGION BELOW 16M
"""
r782mr.__doc__ = """MAXIMUM USER REGION BELOW 16M

SMF Info
--------
    Field: `R782MR`
    Record: `SMF78S2`
    Map: `R782COMN`

MAXIMUM USER REGION BELOW 16M
"""

r782emr : Final[Field] = Field(
    name='r782emr',
    origin='R782EMR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""MAXIMUM USER REGION ABOVE 16M

SMF Info
--------
    Field: `R782EMR`
    Record: `SMF78S2`
    Map: `R782COMN`

MAXIMUM USER REGION ABOVE 16M
"""
r782emr.__doc__ = """MAXIMUM USER REGION ABOVE 16M

SMF Info
--------
    Field: `R782EMR`
    Record: `SMF78S2`
    Map: `R782COMN`

MAXIMUM USER REGION ABOVE 16M
"""

r782ruca : Final[Field] = Field(
    name='r782ruca',
    origin='R782RUCA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""RUCSA ADDRESS

SMF Info
--------
    Field: `R782RUCA`
    Record: `SMF78S2`
    Map: `R782COMN`

RUCSA ADDRESS
"""
r782ruca.__doc__ = """RUCSA ADDRESS

SMF Info
--------
    Field: `R782RUCA`
    Record: `SMF78S2`
    Map: `R782COMN`

RUCSA ADDRESS
"""

r782rucs : Final[Field] = Field(
    name='r782rucs',
    origin='R782RUCS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""RUCSA SIZE

SMF Info
--------
    Field: `R782RUCS`
    Record: `SMF78S2`
    Map: `R782COMN`

RUCSA SIZE
"""
r782rucs.__doc__ = """RUCSA SIZE

SMF Info
--------
    Field: `R782RUCS`
    Record: `SMF78S2`
    Map: `R782COMN`

RUCSA SIZE
"""

r782eruca : Final[Field] = Field(
    name='r782eruca',
    origin='R782ERUCA',
    type=FieldType.STRING,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED RUCSA ADDRESS

SMF Info
--------
    Field: `R782ERUCA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED RUCSA ADDRESS
"""
r782eruca.__doc__ = """EXTENDED RUCSA ADDRESS

SMF Info
--------
    Field: `R782ERUCA`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED RUCSA ADDRESS
"""

r782erucs : Final[Field] = Field(
    name='r782erucs',
    origin='R782ERUCS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782COMN,
)
"""EXTENDED RUCSA SIZE

SMF Info
--------
    Field: `R782ERUCS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED RUCSA SIZE
"""
r782erucs.__doc__ = """EXTENDED RUCSA SIZE

SMF Info
--------
    Field: `R782ERUCS`
    Record: `SMF78S2`
    Map: `R782COMN`

EXTENDED RUCSA SIZE
"""

r782jobn : Final[Field] = Field(
    name='r782jobn',
    origin='R782JOBN',
    type=FieldType.STRING,
    record=record,
    record_map=R782PVT,
)
"""NAME OF JOB BEING MONITORED

SMF Info
--------
    Field: `R782JOBN`
    Record: `SMF78S2`
    Map: `R782PVT`

NAME OF JOB BEING MONITORED
"""
r782jobn.__doc__ = """NAME OF JOB BEING MONITORED

SMF Info
--------
    Field: `R782JOBN`
    Record: `SMF78S2`
    Map: `R782PVT`

NAME OF JOB BEING MONITORED
"""

r782rdtm : Final[Field] = Field(
    name='r782rdtm',
    origin='R782RDTM',
    type=FieldType.TIME,
    record=record,
    record_map=R782PVT,
)
"""READER START TIME

SMF Info
--------
    Field: `R782RDTM`
    Record: `SMF78S2`
    Map: `R782PVT`

READER START TIME
"""
r782rdtm.__doc__ = """READER START TIME

SMF Info
--------
    Field: `R782RDTM`
    Record: `SMF78S2`
    Map: `R782PVT`

READER START TIME
"""

r782rddt : Final[Field] = Field(
    name='r782rddt',
    origin='R782RDDT',
    type=FieldType.DATE,
    record=record,
    record_map=R782PVT,
)
"""READER START DATE

SMF Info
--------
    Field: `R782RDDT`
    Record: `SMF78S2`
    Map: `R782PVT`

READER START DATE
"""
r782rddt.__doc__ = """READER START DATE

SMF Info
--------
    Field: `R782RDDT`
    Record: `SMF78S2`
    Map: `R782PVT`

READER START DATE
"""

r782subi : Final[Field] = Field(
    name='r782subi',
    origin='R782SUBI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""INDEX OF FIRST SUBPOOL ENTRY (R782PVSP) FOR THIS JOB

SMF Info
--------
    Field: `R782SUBI`
    Record: `SMF78S2`
    Map: `R782PVT`

INDEX OF FIRST SUBPOOL ENTRY (R782PVSP) FOR THIS JOB
"""
r782subi.__doc__ = """INDEX OF FIRST SUBPOOL ENTRY (R782PVSP) FOR THIS JOB

SMF Info
--------
    Field: `R782SUBI`
    Record: `SMF78S2`
    Map: `R782PVT`

INDEX OF FIRST SUBPOOL ENTRY (R782PVSP) FOR THIS JOB
"""

r782subn : Final[Field] = Field(
    name='r782subn',
    origin='R782SUBN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""INDEX OF LAST SUBPOOL ENTRY FOR THIS JOB

SMF Info
--------
    Field: `R782SUBN`
    Record: `SMF78S2`
    Map: `R782PVT`

INDEX OF LAST SUBPOOL ENTRY FOR THIS JOB
"""
r782subn.__doc__ = """INDEX OF LAST SUBPOOL ENTRY FOR THIS JOB

SMF Info
--------
    Field: `R782SUBN`
    Record: `SMF78S2`
    Map: `R782PVT`

INDEX OF LAST SUBPOOL ENTRY FOR THIS JOB
"""

r782step : Final[Field] = Field(
    name='r782step',
    origin='R782STEP',
    type=FieldType.STRING,
    record=record,
    record_map=R782PVT,
)
"""NAME OF STEP ACTIVE WHEN MONITORING BEGAN

SMF Info
--------
    Field: `R782STEP`
    Record: `SMF78S2`
    Map: `R782PVT`

NAME OF STEP ACTIVE WHEN MONITORING BEGAN
"""
r782step.__doc__ = """NAME OF STEP ACTIVE WHEN MONITORING BEGAN

SMF Info
--------
    Field: `R782STEP`
    Record: `SMF78S2`
    Map: `R782PVT`

NAME OF STEP ACTIVE WHEN MONITORING BEGAN
"""

r782pgmn : Final[Field] = Field(
    name='r782pgmn',
    origin='R782PGMN',
    type=FieldType.STRING,
    record=record,
    record_map=R782PVT,
)
"""PROGRAM NAME OF JOB BEING MONITORED

SMF Info
--------
    Field: `R782PGMN`
    Record: `SMF78S2`
    Map: `R782PVT`

PROGRAM NAME OF JOB BEING MONITORED
"""
r782pgmn.__doc__ = """PROGRAM NAME OF JOB BEING MONITORED

SMF Info
--------
    Field: `R782PGMN`
    Record: `SMF78S2`
    Map: `R782PVT`

PROGRAM NAME OF JOB BEING MONITORED
"""

r782flgs : Final[Field] = Field(
    name='r782flgs',
    origin='R782FLGS',
    type=FieldType.STRING,
    record=record,
    record_map=R782PVT,
)
"""Not available

SMF Info
--------
    Field: `R782FLGS`
    Record: `SMF78S2`
    Map: `R782PVT`

Not available
"""
r782flgs.__doc__ = """Not available

SMF Info
--------
    Field: `R782FLGS`
    Record: `SMF78S2`
    Map: `R782PVT`

Not available
"""

r782actv : Final[Field] = Field(
    name='r782actv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r782flgs,
    record=record,
    record_map=R782PVT,
)
"""1: JOB ACTIVE AT START OF INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: JOB ACTIVE AT START OF INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r782actv.__doc__ = """1: JOB ACTIVE AT START OF INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: JOB ACTIVE AT START OF INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r782term : Final[Field] = Field(
    name='r782term',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r782flgs,
    record=record,
    record_map=R782PVT,
)
"""1: JOB TERMINATED DURING INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: JOB TERMINATED DURING INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r782term.__doc__ = """1: JOB TERMINATED DURING INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: JOB TERMINATED DURING INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r782glch : Final[Field] = Field(
    name='r782glch',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r782flgs,
    record=record,
    record_map=R782PVT,
)
"""1: GETMAIN LIMIT CHANGED DURING INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: GETMAIN LIMIT CHANGED DURING INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r782glch.__doc__ = """1: GETMAIN LIMIT CHANGED DURING INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: GETMAIN LIMIT CHANGED DURING INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r782invl : Final[Field] = Field(
    name='r782invl',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r782flgs,
    record=record,
    record_map=R782PVT,
)
"""1: DATA INVALID DUE TO RMF ABEND WHILE SAMPLING(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: DATA INVALID DUE TO RMF ABEND WHILE SAMPLING

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r782invl.__doc__ = """1: DATA INVALID DUE TO RMF ABEND WHILE SAMPLING(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: DATA INVALID DUE TO RMF ABEND WHILE SAMPLING

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r782shra : Final[Field] = Field(
    name='r782shra',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r782flgs,
    record=record,
    record_map=R782PVT,
)
"""1: SHARED VALUES ABOVE 2G AVAILABLE (z/OS V1R5 or above)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: SHARED VALUES ABOVE 2G AVAILABLE (z/OS V1R5 or above)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r782shra.__doc__ = """1: SHARED VALUES ABOVE 2G AVAILABLE (z/OS V1R5 or above)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r782flgs`(`R782FLGS`)
    Record: `SMF78S2`
    Map: `R782PVT`

1: SHARED VALUES ABOVE 2G AVAILABLE (z/OS V1R5 or above)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r782samp : Final[Field] = Field(
    name='r782samp',
    origin='R782SAMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""NUMBER OF SAMPLES

SMF Info
--------
    Field: `R782SAMP`
    Record: `SMF78S2`
    Map: `R782PVT`

NUMBER OF SAMPLES
"""
r782samp.__doc__ = """NUMBER OF SAMPLES

SMF Info
--------
    Field: `R782SAMP`
    Record: `SMF78S2`
    Map: `R782PVT`

NUMBER OF SAMPLES
"""

r782regr : Final[Field] = Field(
    name='r782regr',
    origin='R782REGR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""REGION REQUESTED BY JCL (BYTES)

SMF Info
--------
    Field: `R782REGR`
    Record: `SMF78S2`
    Map: `R782PVT`

REGION REQUESTED BY JCL (BYTES)
"""
r782regr.__doc__ = """REGION REQUESTED BY JCL (BYTES)

SMF Info
--------
    Field: `R782REGR`
    Record: `SMF78S2`
    Map: `R782PVT`

REGION REQUESTED BY JCL (BYTES)
"""

r782rgab : Final[Field] = Field(
    name='r782rgab',
    origin='R782RGAB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""BELOW 16M REGION ASSIGNED BY EXITS (BYTES)

SMF Info
--------
    Field: `R782RGAB`
    Record: `SMF78S2`
    Map: `R782PVT`

BELOW 16M REGION ASSIGNED BY EXITS (BYTES)
"""
r782rgab.__doc__ = """BELOW 16M REGION ASSIGNED BY EXITS (BYTES)

SMF Info
--------
    Field: `R782RGAB`
    Record: `SMF78S2`
    Map: `R782PVT`

BELOW 16M REGION ASSIGNED BY EXITS (BYTES)
"""

r782rgaa : Final[Field] = Field(
    name='r782rgaa',
    origin='R782RGAA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""ABOVE 16M REGION ASSIGNED BY EXITS (BYTES)

SMF Info
--------
    Field: `R782RGAA`
    Record: `SMF78S2`
    Map: `R782PVT`

ABOVE 16M REGION ASSIGNED BY EXITS (BYTES)
"""
r782rgaa.__doc__ = """ABOVE 16M REGION ASSIGNED BY EXITS (BYTES)

SMF Info
--------
    Field: `R782RGAA`
    Record: `SMF78S2`
    Map: `R782PVT`

ABOVE 16M REGION ASSIGNED BY EXITS (BYTES)
"""

r782gmlb : Final[Field] = Field(
    name='r782gmlb',
    origin='R782GMLB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""GETMAIN LIMIT BELOW 16M (BYTES)

SMF Info
--------
    Field: `R782GMLB`
    Record: `SMF78S2`
    Map: `R782PVT`

GETMAIN LIMIT BELOW 16M (BYTES)
"""
r782gmlb.__doc__ = """GETMAIN LIMIT BELOW 16M (BYTES)

SMF Info
--------
    Field: `R782GMLB`
    Record: `SMF78S2`
    Map: `R782PVT`

GETMAIN LIMIT BELOW 16M (BYTES)
"""

r782gmla : Final[Field] = Field(
    name='r782gmla',
    origin='R782GMLA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""GETMAIN LIMIT ABOVE 16M (BYTES)

SMF Info
--------
    Field: `R782GMLA`
    Record: `SMF78S2`
    Map: `R782PVT`

GETMAIN LIMIT ABOVE 16M (BYTES)
"""
r782gmla.__doc__ = """GETMAIN LIMIT ABOVE 16M (BYTES)

SMF Info
--------
    Field: `R782GMLA`
    Record: `SMF78S2`
    Map: `R782PVT`

GETMAIN LIMIT ABOVE 16M (BYTES)
"""

r782urab : Final[Field] = Field(
    name='r782urab',
    origin='R782URAB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""USER REGION ADDRESS (below 16M)

SMF Info
--------
    Field: `R782URAB`
    Record: `SMF78S2`
    Map: `R782PVT`

USER REGION ADDRESS (below 16M)
"""
r782urab.__doc__ = """USER REGION ADDRESS (below 16M)

SMF Info
--------
    Field: `R782URAB`
    Record: `SMF78S2`
    Map: `R782PVT`

USER REGION ADDRESS (below 16M)
"""

r782uraa : Final[Field] = Field(
    name='r782uraa',
    origin='R782URAA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""USER REGION ADDRESS (above 16M)

SMF Info
--------
    Field: `R782URAA`
    Record: `SMF78S2`
    Map: `R782PVT`

USER REGION ADDRESS (above 16M)
"""
r782uraa.__doc__ = """USER REGION ADDRESS (above 16M)

SMF Info
--------
    Field: `R782URAA`
    Record: `SMF78S2`
    Map: `R782PVT`

USER REGION ADDRESS (above 16M)
"""

r782meml : Final[Field] = Field(
    name='r782meml',
    origin='R782MEML',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVT,
)
"""Address space memory limit (in MB)

SMF Info
--------
    Field: `R782MEML`
    Record: `SMF78S2`
    Map: `R782PVT`

Address space memory limit (in MB)
"""
r782meml.__doc__ = """Address space memory limit (in MB)

SMF Info
--------
    Field: `R782MEML`
    Record: `SMF78S2`
    Map: `R782PVT`

Address space memory limit (in MB)
"""

r782spn : Final[Field] = Field(
    name='r782spn',
    origin='R782SPN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782PVSP,
)
"""SUBPOOL NUMBER

SMF Info
--------
    Field: `R782SPN`
    Record: `SMF78S2`
    Map: `R782PVSP`

SUBPOOL NUMBER
"""
r782spn.__doc__ = """SUBPOOL NUMBER

SMF Info
--------
    Field: `R782SPN`
    Record: `SMF78S2`
    Map: `R782PVSP`

SUBPOOL NUMBER
"""

sqau_vsdbmin_R782sqau : Final[Field] = Field(
    name='sqau_vsdbmin_R782sqau',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAU,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQAU`

MINIMUM VALUE FOR BELOW 16M
"""
sqau_vsdbmin_R782sqau.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQAU`

MINIMUM VALUE FOR BELOW 16M
"""

sqau_vsdbntme_R782sqau : Final[Field] = Field(
    name='sqau_vsdbntme_R782sqau',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAU,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQAU`

TIME STAMP FOR MINIMUM VALUE
"""
sqau_vsdbntme_R782sqau.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQAU`

TIME STAMP FOR MINIMUM VALUE
"""

sqau_vsdbmax_R782sqau : Final[Field] = Field(
    name='sqau_vsdbmax_R782sqau',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAU,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQAU`

MAXIMUM VALUE FOR BELOW 16M
"""
sqau_vsdbmax_R782sqau.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQAU`

MAXIMUM VALUE FOR BELOW 16M
"""

sqau_vsdbxtme_R782sqau : Final[Field] = Field(
    name='sqau_vsdbxtme_R782sqau',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAU,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQAU`

TIME STAMP FOR MAXIMUM VALUE
"""
sqau_vsdbxtme_R782sqau.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQAU`

TIME STAMP FOR MAXIMUM VALUE
"""

sqau_vsdbtotl_R782sqau : Final[Field] = Field(
    name='sqau_vsdbtotl_R782sqau',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQAU,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQAU`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
sqau_vsdbtotl_R782sqau.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQAU`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

sqau_vsdamin_R782sqau : Final[Field] = Field(
    name='sqau_vsdamin_R782sqau',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAU,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQAU`

MINIMUM VALUE FOR ABOVE 16M
"""
sqau_vsdamin_R782sqau.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQAU`

MINIMUM VALUE FOR ABOVE 16M
"""

sqau_vsdantme_R782sqau : Final[Field] = Field(
    name='sqau_vsdantme_R782sqau',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAU,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQAU`

TIME STAMP FOR MINIMUM VALUE
"""
sqau_vsdantme_R782sqau.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQAU`

TIME STAMP FOR MINIMUM VALUE
"""

sqau_vsdamax_R782sqau : Final[Field] = Field(
    name='sqau_vsdamax_R782sqau',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAU,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQAU`

MAXIMUM VALUE FOR ABOVE 16M
"""
sqau_vsdamax_R782sqau.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQAU`

MAXIMUM VALUE FOR ABOVE 16M
"""

sqau_vsdaxtme_R782sqau : Final[Field] = Field(
    name='sqau_vsdaxtme_R782sqau',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAU,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQAU`

TIME STAMP FOR MAXIMUM VALUE
"""
sqau_vsdaxtme_R782sqau.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQAU`

TIME STAMP FOR MAXIMUM VALUE
"""

sqau_vsdatotl_R782sqau : Final[Field] = Field(
    name='sqau_vsdatotl_R782sqau',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQAU,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQAU`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
sqau_vsdatotl_R782sqau.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQAU`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

csau_vsdbmin_R782csau : Final[Field] = Field(
    name='csau_vsdbmin_R782csau',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAU,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSAU`

MINIMUM VALUE FOR BELOW 16M
"""
csau_vsdbmin_R782csau.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSAU`

MINIMUM VALUE FOR BELOW 16M
"""

csau_vsdbntme_R782csau : Final[Field] = Field(
    name='csau_vsdbntme_R782csau',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAU,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSAU`

TIME STAMP FOR MINIMUM VALUE
"""
csau_vsdbntme_R782csau.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSAU`

TIME STAMP FOR MINIMUM VALUE
"""

csau_vsdbmax_R782csau : Final[Field] = Field(
    name='csau_vsdbmax_R782csau',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAU,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSAU`

MAXIMUM VALUE FOR BELOW 16M
"""
csau_vsdbmax_R782csau.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSAU`

MAXIMUM VALUE FOR BELOW 16M
"""

csau_vsdbxtme_R782csau : Final[Field] = Field(
    name='csau_vsdbxtme_R782csau',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAU,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSAU`

TIME STAMP FOR MAXIMUM VALUE
"""
csau_vsdbxtme_R782csau.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSAU`

TIME STAMP FOR MAXIMUM VALUE
"""

csau_vsdbtotl_R782csau : Final[Field] = Field(
    name='csau_vsdbtotl_R782csau',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSAU,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSAU`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
csau_vsdbtotl_R782csau.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSAU`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

csau_vsdamin_R782csau : Final[Field] = Field(
    name='csau_vsdamin_R782csau',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAU,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSAU`

MINIMUM VALUE FOR ABOVE 16M
"""
csau_vsdamin_R782csau.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSAU`

MINIMUM VALUE FOR ABOVE 16M
"""

csau_vsdantme_R782csau : Final[Field] = Field(
    name='csau_vsdantme_R782csau',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAU,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSAU`

TIME STAMP FOR MINIMUM VALUE
"""
csau_vsdantme_R782csau.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSAU`

TIME STAMP FOR MINIMUM VALUE
"""

csau_vsdamax_R782csau : Final[Field] = Field(
    name='csau_vsdamax_R782csau',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAU,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSAU`

MAXIMUM VALUE FOR ABOVE 16M
"""
csau_vsdamax_R782csau.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSAU`

MAXIMUM VALUE FOR ABOVE 16M
"""

csau_vsdaxtme_R782csau : Final[Field] = Field(
    name='csau_vsdaxtme_R782csau',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAU,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSAU`

TIME STAMP FOR MAXIMUM VALUE
"""
csau_vsdaxtme_R782csau.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSAU`

TIME STAMP FOR MAXIMUM VALUE
"""

csau_vsdatotl_R782csau : Final[Field] = Field(
    name='csau_vsdatotl_R782csau',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSAU,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSAU`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
csau_vsdatotl_R782csau.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSAU`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

csaf_vsdbmin_R782csaf : Final[Field] = Field(
    name='csaf_vsdbmin_R782csaf',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAF,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSAF`

MINIMUM VALUE FOR BELOW 16M
"""
csaf_vsdbmin_R782csaf.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSAF`

MINIMUM VALUE FOR BELOW 16M
"""

csaf_vsdbntme_R782csaf : Final[Field] = Field(
    name='csaf_vsdbntme_R782csaf',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAF,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSAF`

TIME STAMP FOR MINIMUM VALUE
"""
csaf_vsdbntme_R782csaf.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSAF`

TIME STAMP FOR MINIMUM VALUE
"""

csaf_vsdbmax_R782csaf : Final[Field] = Field(
    name='csaf_vsdbmax_R782csaf',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAF,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSAF`

MAXIMUM VALUE FOR BELOW 16M
"""
csaf_vsdbmax_R782csaf.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSAF`

MAXIMUM VALUE FOR BELOW 16M
"""

csaf_vsdbxtme_R782csaf : Final[Field] = Field(
    name='csaf_vsdbxtme_R782csaf',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAF,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSAF`

TIME STAMP FOR MAXIMUM VALUE
"""
csaf_vsdbxtme_R782csaf.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSAF`

TIME STAMP FOR MAXIMUM VALUE
"""

csaf_vsdbtotl_R782csaf : Final[Field] = Field(
    name='csaf_vsdbtotl_R782csaf',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSAF,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSAF`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
csaf_vsdbtotl_R782csaf.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSAF`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

csaf_vsdamin_R782csaf : Final[Field] = Field(
    name='csaf_vsdamin_R782csaf',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAF,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSAF`

MINIMUM VALUE FOR ABOVE 16M
"""
csaf_vsdamin_R782csaf.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSAF`

MINIMUM VALUE FOR ABOVE 16M
"""

csaf_vsdantme_R782csaf : Final[Field] = Field(
    name='csaf_vsdantme_R782csaf',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAF,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSAF`

TIME STAMP FOR MINIMUM VALUE
"""
csaf_vsdantme_R782csaf.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSAF`

TIME STAMP FOR MINIMUM VALUE
"""

csaf_vsdamax_R782csaf : Final[Field] = Field(
    name='csaf_vsdamax_R782csaf',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAF,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSAF`

MAXIMUM VALUE FOR ABOVE 16M
"""
csaf_vsdamax_R782csaf.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSAF`

MAXIMUM VALUE FOR ABOVE 16M
"""

csaf_vsdaxtme_R782csaf : Final[Field] = Field(
    name='csaf_vsdaxtme_R782csaf',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAF,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSAF`

TIME STAMP FOR MAXIMUM VALUE
"""
csaf_vsdaxtme_R782csaf.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSAF`

TIME STAMP FOR MAXIMUM VALUE
"""

csaf_vsdatotl_R782csaf : Final[Field] = Field(
    name='csaf_vsdatotl_R782csaf',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSAF,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSAF`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
csaf_vsdatotl_R782csaf.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSAF`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

comn_vsdbmin_R782cslf : Final[Field] = Field(
    name='comn_vsdbmin_R782cslf',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSLF,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSLF`

MINIMUM VALUE FOR BELOW 16M
"""
comn_vsdbmin_R782cslf.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSLF`

MINIMUM VALUE FOR BELOW 16M
"""

comn_vsdbntme_R782cslf : Final[Field] = Field(
    name='comn_vsdbntme_R782cslf',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSLF,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSLF`

TIME STAMP FOR MINIMUM VALUE
"""
comn_vsdbntme_R782cslf.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSLF`

TIME STAMP FOR MINIMUM VALUE
"""

comn_vsdbmax_R782cslf : Final[Field] = Field(
    name='comn_vsdbmax_R782cslf',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSLF,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSLF`

MAXIMUM VALUE FOR BELOW 16M
"""
comn_vsdbmax_R782cslf.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSLF`

MAXIMUM VALUE FOR BELOW 16M
"""

comn_vsdbxtme_R782cslf : Final[Field] = Field(
    name='comn_vsdbxtme_R782cslf',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSLF,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSLF`

TIME STAMP FOR MAXIMUM VALUE
"""
comn_vsdbxtme_R782cslf.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSLF`

TIME STAMP FOR MAXIMUM VALUE
"""

comn_vsdbtotl_R782cslf : Final[Field] = Field(
    name='comn_vsdbtotl_R782cslf',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSLF,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSLF`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
comn_vsdbtotl_R782cslf.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSLF`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

comn_vsdamin_R782cslf : Final[Field] = Field(
    name='comn_vsdamin_R782cslf',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSLF,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSLF`

MINIMUM VALUE FOR ABOVE 16M
"""
comn_vsdamin_R782cslf.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSLF`

MINIMUM VALUE FOR ABOVE 16M
"""

comn_vsdantme_R782cslf : Final[Field] = Field(
    name='comn_vsdantme_R782cslf',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSLF,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSLF`

TIME STAMP FOR MINIMUM VALUE
"""
comn_vsdantme_R782cslf.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSLF`

TIME STAMP FOR MINIMUM VALUE
"""

comn_vsdamax_R782cslf : Final[Field] = Field(
    name='comn_vsdamax_R782cslf',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSLF,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSLF`

MAXIMUM VALUE FOR ABOVE 16M
"""
comn_vsdamax_R782cslf.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSLF`

MAXIMUM VALUE FOR ABOVE 16M
"""

comn_vsdaxtme_R782cslf : Final[Field] = Field(
    name='comn_vsdaxtme_R782cslf',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSLF,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSLF`

TIME STAMP FOR MAXIMUM VALUE
"""
comn_vsdaxtme_R782cslf.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSLF`

TIME STAMP FOR MAXIMUM VALUE
"""

comn_vsdatotl_R782cslf : Final[Field] = Field(
    name='comn_vsdatotl_R782cslf',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSLF,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSLF`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
comn_vsdatotl_R782cslf.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSLF`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

csal_vsdbmin_R782csal : Final[Field] = Field(
    name='csal_vsdbmin_R782csal',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAL,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSAL`

MINIMUM VALUE FOR BELOW 16M
"""
csal_vsdbmin_R782csal.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSAL`

MINIMUM VALUE FOR BELOW 16M
"""

csal_vsdbntme_R782csal : Final[Field] = Field(
    name='csal_vsdbntme_R782csal',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAL,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSAL`

TIME STAMP FOR MINIMUM VALUE
"""
csal_vsdbntme_R782csal.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSAL`

TIME STAMP FOR MINIMUM VALUE
"""

csal_vsdbmax_R782csal : Final[Field] = Field(
    name='csal_vsdbmax_R782csal',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAL,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSAL`

MAXIMUM VALUE FOR BELOW 16M
"""
csal_vsdbmax_R782csal.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSAL`

MAXIMUM VALUE FOR BELOW 16M
"""

csal_vsdbxtme_R782csal : Final[Field] = Field(
    name='csal_vsdbxtme_R782csal',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAL,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSAL`

TIME STAMP FOR MAXIMUM VALUE
"""
csal_vsdbxtme_R782csal.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSAL`

TIME STAMP FOR MAXIMUM VALUE
"""

csal_vsdbtotl_R782csal : Final[Field] = Field(
    name='csal_vsdbtotl_R782csal',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSAL,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSAL`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
csal_vsdbtotl_R782csal.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSAL`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

csal_vsdamin_R782csal : Final[Field] = Field(
    name='csal_vsdamin_R782csal',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAL,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSAL`

MINIMUM VALUE FOR ABOVE 16M
"""
csal_vsdamin_R782csal.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSAL`

MINIMUM VALUE FOR ABOVE 16M
"""

csal_vsdantme_R782csal : Final[Field] = Field(
    name='csal_vsdantme_R782csal',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAL,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSAL`

TIME STAMP FOR MINIMUM VALUE
"""
csal_vsdantme_R782csal.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSAL`

TIME STAMP FOR MINIMUM VALUE
"""

csal_vsdamax_R782csal : Final[Field] = Field(
    name='csal_vsdamax_R782csal',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAL,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSAL`

MAXIMUM VALUE FOR ABOVE 16M
"""
csal_vsdamax_R782csal.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSAL`

MAXIMUM VALUE FOR ABOVE 16M
"""

csal_vsdaxtme_R782csal : Final[Field] = Field(
    name='csal_vsdaxtme_R782csal',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAL,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSAL`

TIME STAMP FOR MAXIMUM VALUE
"""
csal_vsdaxtme_R782csal.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSAL`

TIME STAMP FOR MAXIMUM VALUE
"""

csal_vsdatotl_R782csal : Final[Field] = Field(
    name='csal_vsdatotl_R782csal',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSAL,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSAL`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
csal_vsdatotl_R782csal.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSAL`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

sqaf_vsdbmin_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdbmin_R782sqaf',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAF,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQAF`

MINIMUM VALUE FOR BELOW 16M
"""
sqaf_vsdbmin_R782sqaf.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQAF`

MINIMUM VALUE FOR BELOW 16M
"""

sqaf_vsdbntme_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdbntme_R782sqaf',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAF,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQAF`

TIME STAMP FOR MINIMUM VALUE
"""
sqaf_vsdbntme_R782sqaf.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQAF`

TIME STAMP FOR MINIMUM VALUE
"""

sqaf_vsdbmax_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdbmax_R782sqaf',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAF,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQAF`

MAXIMUM VALUE FOR BELOW 16M
"""
sqaf_vsdbmax_R782sqaf.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQAF`

MAXIMUM VALUE FOR BELOW 16M
"""

sqaf_vsdbxtme_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdbxtme_R782sqaf',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAF,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQAF`

TIME STAMP FOR MAXIMUM VALUE
"""
sqaf_vsdbxtme_R782sqaf.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQAF`

TIME STAMP FOR MAXIMUM VALUE
"""

sqaf_vsdbtotl_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdbtotl_R782sqaf',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQAF,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQAF`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
sqaf_vsdbtotl_R782sqaf.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQAF`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

sqaf_vsdamin_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdamin_R782sqaf',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAF,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQAF`

MINIMUM VALUE FOR ABOVE 16M
"""
sqaf_vsdamin_R782sqaf.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQAF`

MINIMUM VALUE FOR ABOVE 16M
"""

sqaf_vsdantme_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdantme_R782sqaf',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAF,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQAF`

TIME STAMP FOR MINIMUM VALUE
"""
sqaf_vsdantme_R782sqaf.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQAF`

TIME STAMP FOR MINIMUM VALUE
"""

sqaf_vsdamax_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdamax_R782sqaf',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAF,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQAF`

MAXIMUM VALUE FOR ABOVE 16M
"""
sqaf_vsdamax_R782sqaf.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQAF`

MAXIMUM VALUE FOR ABOVE 16M
"""

sqaf_vsdaxtme_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdaxtme_R782sqaf',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAF,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQAF`

TIME STAMP FOR MAXIMUM VALUE
"""
sqaf_vsdaxtme_R782sqaf.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQAF`

TIME STAMP FOR MAXIMUM VALUE
"""

sqaf_vsdatotl_R782sqaf : Final[Field] = Field(
    name='sqaf_vsdatotl_R782sqaf',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQAF,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQAF`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
sqaf_vsdatotl_R782sqaf.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQAF`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

sqlf_vsdbmin_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdbmin_R782sqlf',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQLF,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQLF`

MINIMUM VALUE FOR BELOW 16M
"""
sqlf_vsdbmin_R782sqlf.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQLF`

MINIMUM VALUE FOR BELOW 16M
"""

sqlf_vsdbntme_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdbntme_R782sqlf',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQLF,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQLF`

TIME STAMP FOR MINIMUM VALUE
"""
sqlf_vsdbntme_R782sqlf.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQLF`

TIME STAMP FOR MINIMUM VALUE
"""

sqlf_vsdbmax_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdbmax_R782sqlf',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQLF,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQLF`

MAXIMUM VALUE FOR BELOW 16M
"""
sqlf_vsdbmax_R782sqlf.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQLF`

MAXIMUM VALUE FOR BELOW 16M
"""

sqlf_vsdbxtme_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdbxtme_R782sqlf',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQLF,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQLF`

TIME STAMP FOR MAXIMUM VALUE
"""
sqlf_vsdbxtme_R782sqlf.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQLF`

TIME STAMP FOR MAXIMUM VALUE
"""

sqlf_vsdbtotl_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdbtotl_R782sqlf',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQLF,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQLF`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
sqlf_vsdbtotl_R782sqlf.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQLF`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

sqlf_vsdamin_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdamin_R782sqlf',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQLF,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQLF`

MINIMUM VALUE FOR ABOVE 16M
"""
sqlf_vsdamin_R782sqlf.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQLF`

MINIMUM VALUE FOR ABOVE 16M
"""

sqlf_vsdantme_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdantme_R782sqlf',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQLF,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQLF`

TIME STAMP FOR MINIMUM VALUE
"""
sqlf_vsdantme_R782sqlf.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQLF`

TIME STAMP FOR MINIMUM VALUE
"""

sqlf_vsdamax_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdamax_R782sqlf',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQLF,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQLF`

MAXIMUM VALUE FOR ABOVE 16M
"""
sqlf_vsdamax_R782sqlf.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQLF`

MAXIMUM VALUE FOR ABOVE 16M
"""

sqlf_vsdaxtme_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdaxtme_R782sqlf',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQLF,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQLF`

TIME STAMP FOR MAXIMUM VALUE
"""
sqlf_vsdaxtme_R782sqlf.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQLF`

TIME STAMP FOR MAXIMUM VALUE
"""

sqlf_vsdatotl_R782sqlf : Final[Field] = Field(
    name='sqlf_vsdatotl_R782sqlf',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQLF,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQLF`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
sqlf_vsdatotl_R782sqlf.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQLF`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

sqal_vsdbmin_R782sqal : Final[Field] = Field(
    name='sqal_vsdbmin_R782sqal',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAL,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQAL`

MINIMUM VALUE FOR BELOW 16M
"""
sqal_vsdbmin_R782sqal.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQAL`

MINIMUM VALUE FOR BELOW 16M
"""

sqal_vsdbntme_R782sqal : Final[Field] = Field(
    name='sqal_vsdbntme_R782sqal',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAL,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQAL`

TIME STAMP FOR MINIMUM VALUE
"""
sqal_vsdbntme_R782sqal.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQAL`

TIME STAMP FOR MINIMUM VALUE
"""

sqal_vsdbmax_R782sqal : Final[Field] = Field(
    name='sqal_vsdbmax_R782sqal',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAL,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQAL`

MAXIMUM VALUE FOR BELOW 16M
"""
sqal_vsdbmax_R782sqal.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQAL`

MAXIMUM VALUE FOR BELOW 16M
"""

sqal_vsdbxtme_R782sqal : Final[Field] = Field(
    name='sqal_vsdbxtme_R782sqal',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAL,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQAL`

TIME STAMP FOR MAXIMUM VALUE
"""
sqal_vsdbxtme_R782sqal.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQAL`

TIME STAMP FOR MAXIMUM VALUE
"""

sqal_vsdbtotl_R782sqal : Final[Field] = Field(
    name='sqal_vsdbtotl_R782sqal',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQAL,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQAL`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
sqal_vsdbtotl_R782sqal.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQAL`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

sqal_vsdamin_R782sqal : Final[Field] = Field(
    name='sqal_vsdamin_R782sqal',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAL,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQAL`

MINIMUM VALUE FOR ABOVE 16M
"""
sqal_vsdamin_R782sqal.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQAL`

MINIMUM VALUE FOR ABOVE 16M
"""

sqal_vsdantme_R782sqal : Final[Field] = Field(
    name='sqal_vsdantme_R782sqal',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAL,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQAL`

TIME STAMP FOR MINIMUM VALUE
"""
sqal_vsdantme_R782sqal.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQAL`

TIME STAMP FOR MINIMUM VALUE
"""

sqal_vsdamax_R782sqal : Final[Field] = Field(
    name='sqal_vsdamax_R782sqal',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQAL,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQAL`

MAXIMUM VALUE FOR ABOVE 16M
"""
sqal_vsdamax_R782sqal.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQAL`

MAXIMUM VALUE FOR ABOVE 16M
"""

sqal_vsdaxtme_R782sqal : Final[Field] = Field(
    name='sqal_vsdaxtme_R782sqal',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQAL,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQAL`

TIME STAMP FOR MAXIMUM VALUE
"""
sqal_vsdaxtme_R782sqal.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQAL`

TIME STAMP FOR MAXIMUM VALUE
"""

sqal_vsdatotl_R782sqal : Final[Field] = Field(
    name='sqal_vsdatotl_R782sqal',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQAL,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQAL`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
sqal_vsdatotl_R782sqal.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQAL`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

sqex_vsdbmin_R782sqex : Final[Field] = Field(
    name='sqex_vsdbmin_R782sqex',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQEX,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQEX`

MINIMUM VALUE FOR BELOW 16M
"""
sqex_vsdbmin_R782sqex.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SQEX`

MINIMUM VALUE FOR BELOW 16M
"""

sqex_vsdbntme_R782sqex : Final[Field] = Field(
    name='sqex_vsdbntme_R782sqex',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQEX,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQEX`

TIME STAMP FOR MINIMUM VALUE
"""
sqex_vsdbntme_R782sqex.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SQEX`

TIME STAMP FOR MINIMUM VALUE
"""

sqex_vsdbmax_R782sqex : Final[Field] = Field(
    name='sqex_vsdbmax_R782sqex',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQEX,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQEX`

MAXIMUM VALUE FOR BELOW 16M
"""
sqex_vsdbmax_R782sqex.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SQEX`

MAXIMUM VALUE FOR BELOW 16M
"""

sqex_vsdbxtme_R782sqex : Final[Field] = Field(
    name='sqex_vsdbxtme_R782sqex',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQEX,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQEX`

TIME STAMP FOR MAXIMUM VALUE
"""
sqex_vsdbxtme_R782sqex.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SQEX`

TIME STAMP FOR MAXIMUM VALUE
"""

sqex_vsdbtotl_R782sqex : Final[Field] = Field(
    name='sqex_vsdbtotl_R782sqex',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQEX,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQEX`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
sqex_vsdbtotl_R782sqex.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SQEX`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

sqex_vsdamin_R782sqex : Final[Field] = Field(
    name='sqex_vsdamin_R782sqex',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQEX,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQEX`

MINIMUM VALUE FOR ABOVE 16M
"""
sqex_vsdamin_R782sqex.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SQEX`

MINIMUM VALUE FOR ABOVE 16M
"""

sqex_vsdantme_R782sqex : Final[Field] = Field(
    name='sqex_vsdantme_R782sqex',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQEX,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQEX`

TIME STAMP FOR MINIMUM VALUE
"""
sqex_vsdantme_R782sqex.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SQEX`

TIME STAMP FOR MINIMUM VALUE
"""

sqex_vsdamax_R782sqex : Final[Field] = Field(
    name='sqex_vsdamax_R782sqex',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SQEX,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQEX`

MAXIMUM VALUE FOR ABOVE 16M
"""
sqex_vsdamax_R782sqex.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SQEX`

MAXIMUM VALUE FOR ABOVE 16M
"""

sqex_vsdaxtme_R782sqex : Final[Field] = Field(
    name='sqex_vsdaxtme_R782sqex',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SQEX,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQEX`

TIME STAMP FOR MAXIMUM VALUE
"""
sqex_vsdaxtme_R782sqex.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SQEX`

TIME STAMP FOR MAXIMUM VALUE
"""

sqex_vsdatotl_R782sqex : Final[Field] = Field(
    name='sqex_vsdatotl_R782sqex',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SQEX,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQEX`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
sqex_vsdatotl_R782sqex.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SQEX`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

s226_vsdbmin_R782226 : Final[Field] = Field(
    name='s226_vsdbmin_R782226',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782226,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782226`

MINIMUM VALUE FOR BELOW 16M
"""
s226_vsdbmin_R782226.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782226`

MINIMUM VALUE FOR BELOW 16M
"""

s226_vsdbntme_R782226 : Final[Field] = Field(
    name='s226_vsdbntme_R782226',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782226,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782226`

TIME STAMP FOR MINIMUM VALUE
"""
s226_vsdbntme_R782226.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782226`

TIME STAMP FOR MINIMUM VALUE
"""

s226_vsdbmax_R782226 : Final[Field] = Field(
    name='s226_vsdbmax_R782226',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782226,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782226`

MAXIMUM VALUE FOR BELOW 16M
"""
s226_vsdbmax_R782226.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782226`

MAXIMUM VALUE FOR BELOW 16M
"""

s226_vsdbxtme_R782226 : Final[Field] = Field(
    name='s226_vsdbxtme_R782226',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782226,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782226`

TIME STAMP FOR MAXIMUM VALUE
"""
s226_vsdbxtme_R782226.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782226`

TIME STAMP FOR MAXIMUM VALUE
"""

s226_vsdbtotl_R782226 : Final[Field] = Field(
    name='s226_vsdbtotl_R782226',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782226,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782226`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
s226_vsdbtotl_R782226.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782226`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

s226_vsdamin_R782226 : Final[Field] = Field(
    name='s226_vsdamin_R782226',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782226,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782226`

MINIMUM VALUE FOR ABOVE 16M
"""
s226_vsdamin_R782226.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782226`

MINIMUM VALUE FOR ABOVE 16M
"""

s226_vsdantme_R782226 : Final[Field] = Field(
    name='s226_vsdantme_R782226',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782226,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782226`

TIME STAMP FOR MINIMUM VALUE
"""
s226_vsdantme_R782226.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782226`

TIME STAMP FOR MINIMUM VALUE
"""

s226_vsdamax_R782226 : Final[Field] = Field(
    name='s226_vsdamax_R782226',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782226,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782226`

MAXIMUM VALUE FOR ABOVE 16M
"""
s226_vsdamax_R782226.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782226`

MAXIMUM VALUE FOR ABOVE 16M
"""

s226_vsdaxtme_R782226 : Final[Field] = Field(
    name='s226_vsdaxtme_R782226',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782226,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782226`

TIME STAMP FOR MAXIMUM VALUE
"""
s226_vsdaxtme_R782226.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782226`

TIME STAMP FOR MAXIMUM VALUE
"""

s226_vsdatotl_R782226 : Final[Field] = Field(
    name='s226_vsdatotl_R782226',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782226,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782226`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
s226_vsdatotl_R782226.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782226`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

s239_vsdbmin_R782239 : Final[Field] = Field(
    name='s239_vsdbmin_R782239',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782239,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782239`

MINIMUM VALUE FOR BELOW 16M
"""
s239_vsdbmin_R782239.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782239`

MINIMUM VALUE FOR BELOW 16M
"""

s239_vsdbntme_R782239 : Final[Field] = Field(
    name='s239_vsdbntme_R782239',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782239,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782239`

TIME STAMP FOR MINIMUM VALUE
"""
s239_vsdbntme_R782239.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782239`

TIME STAMP FOR MINIMUM VALUE
"""

s239_vsdbmax_R782239 : Final[Field] = Field(
    name='s239_vsdbmax_R782239',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782239,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782239`

MAXIMUM VALUE FOR BELOW 16M
"""
s239_vsdbmax_R782239.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782239`

MAXIMUM VALUE FOR BELOW 16M
"""

s239_vsdbxtme_R782239 : Final[Field] = Field(
    name='s239_vsdbxtme_R782239',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782239,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782239`

TIME STAMP FOR MAXIMUM VALUE
"""
s239_vsdbxtme_R782239.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782239`

TIME STAMP FOR MAXIMUM VALUE
"""

s239_vsdbtotl_R782239 : Final[Field] = Field(
    name='s239_vsdbtotl_R782239',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782239,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782239`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
s239_vsdbtotl_R782239.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782239`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

s239_vsdamin_R782239 : Final[Field] = Field(
    name='s239_vsdamin_R782239',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782239,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782239`

MINIMUM VALUE FOR ABOVE 16M
"""
s239_vsdamin_R782239.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782239`

MINIMUM VALUE FOR ABOVE 16M
"""

s239_vsdantme_R782239 : Final[Field] = Field(
    name='s239_vsdantme_R782239',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782239,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782239`

TIME STAMP FOR MINIMUM VALUE
"""
s239_vsdantme_R782239.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782239`

TIME STAMP FOR MINIMUM VALUE
"""

s239_vsdamax_R782239 : Final[Field] = Field(
    name='s239_vsdamax_R782239',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782239,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782239`

MAXIMUM VALUE FOR ABOVE 16M
"""
s239_vsdamax_R782239.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782239`

MAXIMUM VALUE FOR ABOVE 16M
"""

s239_vsdaxtme_R782239 : Final[Field] = Field(
    name='s239_vsdaxtme_R782239',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782239,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782239`

TIME STAMP FOR MAXIMUM VALUE
"""
s239_vsdaxtme_R782239.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782239`

TIME STAMP FOR MAXIMUM VALUE
"""

s239_vsdatotl_R782239 : Final[Field] = Field(
    name='s239_vsdatotl_R782239',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782239,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782239`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
s239_vsdatotl_R782239.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782239`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

s245_vsdbmin_R782245 : Final[Field] = Field(
    name='s245_vsdbmin_R782245',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782245,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782245`

MINIMUM VALUE FOR BELOW 16M
"""
s245_vsdbmin_R782245.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782245`

MINIMUM VALUE FOR BELOW 16M
"""

s245_vsdbntme_R782245 : Final[Field] = Field(
    name='s245_vsdbntme_R782245',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782245,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782245`

TIME STAMP FOR MINIMUM VALUE
"""
s245_vsdbntme_R782245.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782245`

TIME STAMP FOR MINIMUM VALUE
"""

s245_vsdbmax_R782245 : Final[Field] = Field(
    name='s245_vsdbmax_R782245',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782245,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782245`

MAXIMUM VALUE FOR BELOW 16M
"""
s245_vsdbmax_R782245.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782245`

MAXIMUM VALUE FOR BELOW 16M
"""

s245_vsdbxtme_R782245 : Final[Field] = Field(
    name='s245_vsdbxtme_R782245',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782245,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782245`

TIME STAMP FOR MAXIMUM VALUE
"""
s245_vsdbxtme_R782245.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782245`

TIME STAMP FOR MAXIMUM VALUE
"""

s245_vsdbtotl_R782245 : Final[Field] = Field(
    name='s245_vsdbtotl_R782245',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782245,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782245`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
s245_vsdbtotl_R782245.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782245`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

s245_vsdamin_R782245 : Final[Field] = Field(
    name='s245_vsdamin_R782245',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782245,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782245`

MINIMUM VALUE FOR ABOVE 16M
"""
s245_vsdamin_R782245.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782245`

MINIMUM VALUE FOR ABOVE 16M
"""

s245_vsdantme_R782245 : Final[Field] = Field(
    name='s245_vsdantme_R782245',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782245,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782245`

TIME STAMP FOR MINIMUM VALUE
"""
s245_vsdantme_R782245.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782245`

TIME STAMP FOR MINIMUM VALUE
"""

s245_vsdamax_R782245 : Final[Field] = Field(
    name='s245_vsdamax_R782245',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782245,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782245`

MAXIMUM VALUE FOR ABOVE 16M
"""
s245_vsdamax_R782245.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782245`

MAXIMUM VALUE FOR ABOVE 16M
"""

s245_vsdaxtme_R782245 : Final[Field] = Field(
    name='s245_vsdaxtme_R782245',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782245,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782245`

TIME STAMP FOR MAXIMUM VALUE
"""
s245_vsdaxtme_R782245.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782245`

TIME STAMP FOR MAXIMUM VALUE
"""

s245_vsdatotl_R782245 : Final[Field] = Field(
    name='s245_vsdatotl_R782245',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782245,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782245`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
s245_vsdatotl_R782245.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782245`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

csak_vsdbmin_R782csaks : Final[Field] = Field(
    name='csak_vsdbmin_R782csaks',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAK,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSAK`

MINIMUM VALUE FOR BELOW 16M
"""
csak_vsdbmin_R782csaks.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782CSAK`

MINIMUM VALUE FOR BELOW 16M
"""

csak_vsdbntme_R782csaks : Final[Field] = Field(
    name='csak_vsdbntme_R782csaks',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAK,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSAK`

TIME STAMP FOR MINIMUM VALUE
"""
csak_vsdbntme_R782csaks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782CSAK`

TIME STAMP FOR MINIMUM VALUE
"""

csak_vsdbmax_R782csaks : Final[Field] = Field(
    name='csak_vsdbmax_R782csaks',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAK,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSAK`

MAXIMUM VALUE FOR BELOW 16M
"""
csak_vsdbmax_R782csaks.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782CSAK`

MAXIMUM VALUE FOR BELOW 16M
"""

csak_vsdbxtme_R782csaks : Final[Field] = Field(
    name='csak_vsdbxtme_R782csaks',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAK,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSAK`

TIME STAMP FOR MAXIMUM VALUE
"""
csak_vsdbxtme_R782csaks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782CSAK`

TIME STAMP FOR MAXIMUM VALUE
"""

csak_vsdbtotl_R782csaks : Final[Field] = Field(
    name='csak_vsdbtotl_R782csaks',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSAK,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSAK`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
csak_vsdbtotl_R782csaks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782CSAK`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

csak_vsdamin_R782csaks : Final[Field] = Field(
    name='csak_vsdamin_R782csaks',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAK,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSAK`

MINIMUM VALUE FOR ABOVE 16M
"""
csak_vsdamin_R782csaks.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782CSAK`

MINIMUM VALUE FOR ABOVE 16M
"""

csak_vsdantme_R782csaks : Final[Field] = Field(
    name='csak_vsdantme_R782csaks',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAK,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSAK`

TIME STAMP FOR MINIMUM VALUE
"""
csak_vsdantme_R782csaks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782CSAK`

TIME STAMP FOR MINIMUM VALUE
"""

csak_vsdamax_R782csaks : Final[Field] = Field(
    name='csak_vsdamax_R782csaks',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782CSAK,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSAK`

MAXIMUM VALUE FOR ABOVE 16M
"""
csak_vsdamax_R782csaks.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782CSAK`

MAXIMUM VALUE FOR ABOVE 16M
"""

csak_vsdaxtme_R782csaks : Final[Field] = Field(
    name='csak_vsdaxtme_R782csaks',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782CSAK,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSAK`

TIME STAMP FOR MAXIMUM VALUE
"""
csak_vsdaxtme_R782csaks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782CSAK`

TIME STAMP FOR MAXIMUM VALUE
"""

csak_vsdatotl_R782csaks : Final[Field] = Field(
    name='csak_vsdatotl_R782csaks',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782CSAK,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSAK`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
csak_vsdatotl_R782csaks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782CSAK`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

s227k_vsdbmin_R782227ks : Final[Field] = Field(
    name='s227k_vsdbmin_R782227ks',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782227K,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782227K`

MINIMUM VALUE FOR BELOW 16M
"""
s227k_vsdbmin_R782227ks.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782227K`

MINIMUM VALUE FOR BELOW 16M
"""

s227k_vsdbntme_R782227ks : Final[Field] = Field(
    name='s227k_vsdbntme_R782227ks',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782227K,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782227K`

TIME STAMP FOR MINIMUM VALUE
"""
s227k_vsdbntme_R782227ks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782227K`

TIME STAMP FOR MINIMUM VALUE
"""

s227k_vsdbmax_R782227ks : Final[Field] = Field(
    name='s227k_vsdbmax_R782227ks',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782227K,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782227K`

MAXIMUM VALUE FOR BELOW 16M
"""
s227k_vsdbmax_R782227ks.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782227K`

MAXIMUM VALUE FOR BELOW 16M
"""

s227k_vsdbxtme_R782227ks : Final[Field] = Field(
    name='s227k_vsdbxtme_R782227ks',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782227K,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782227K`

TIME STAMP FOR MAXIMUM VALUE
"""
s227k_vsdbxtme_R782227ks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782227K`

TIME STAMP FOR MAXIMUM VALUE
"""

s227k_vsdbtotl_R782227ks : Final[Field] = Field(
    name='s227k_vsdbtotl_R782227ks',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782227K,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782227K`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
s227k_vsdbtotl_R782227ks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782227K`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

s227k_vsdamin_R782227ks : Final[Field] = Field(
    name='s227k_vsdamin_R782227ks',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782227K,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782227K`

MINIMUM VALUE FOR ABOVE 16M
"""
s227k_vsdamin_R782227ks.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782227K`

MINIMUM VALUE FOR ABOVE 16M
"""

s227k_vsdantme_R782227ks : Final[Field] = Field(
    name='s227k_vsdantme_R782227ks',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782227K,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782227K`

TIME STAMP FOR MINIMUM VALUE
"""
s227k_vsdantme_R782227ks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782227K`

TIME STAMP FOR MINIMUM VALUE
"""

s227k_vsdamax_R782227ks : Final[Field] = Field(
    name='s227k_vsdamax_R782227ks',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782227K,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782227K`

MAXIMUM VALUE FOR ABOVE 16M
"""
s227k_vsdamax_R782227ks.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782227K`

MAXIMUM VALUE FOR ABOVE 16M
"""

s227k_vsdaxtme_R782227ks : Final[Field] = Field(
    name='s227k_vsdaxtme_R782227ks',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782227K,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782227K`

TIME STAMP FOR MAXIMUM VALUE
"""
s227k_vsdaxtme_R782227ks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782227K`

TIME STAMP FOR MAXIMUM VALUE
"""

s227k_vsdatotl_R782227ks : Final[Field] = Field(
    name='s227k_vsdatotl_R782227ks',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782227K,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782227K`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
s227k_vsdatotl_R782227ks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782227K`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

s228k_vsdbmin_R782228ks : Final[Field] = Field(
    name='s228k_vsdbmin_R782228ks',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782228K,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782228K`

MINIMUM VALUE FOR BELOW 16M
"""
s228k_vsdbmin_R782228ks.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782228K`

MINIMUM VALUE FOR BELOW 16M
"""

s228k_vsdbntme_R782228ks : Final[Field] = Field(
    name='s228k_vsdbntme_R782228ks',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782228K,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782228K`

TIME STAMP FOR MINIMUM VALUE
"""
s228k_vsdbntme_R782228ks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782228K`

TIME STAMP FOR MINIMUM VALUE
"""

s228k_vsdbmax_R782228ks : Final[Field] = Field(
    name='s228k_vsdbmax_R782228ks',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782228K,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782228K`

MAXIMUM VALUE FOR BELOW 16M
"""
s228k_vsdbmax_R782228ks.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782228K`

MAXIMUM VALUE FOR BELOW 16M
"""

s228k_vsdbxtme_R782228ks : Final[Field] = Field(
    name='s228k_vsdbxtme_R782228ks',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782228K,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782228K`

TIME STAMP FOR MAXIMUM VALUE
"""
s228k_vsdbxtme_R782228ks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782228K`

TIME STAMP FOR MAXIMUM VALUE
"""

s228k_vsdbtotl_R782228ks : Final[Field] = Field(
    name='s228k_vsdbtotl_R782228ks',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782228K,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782228K`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
s228k_vsdbtotl_R782228ks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782228K`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

s228k_vsdamin_R782228ks : Final[Field] = Field(
    name='s228k_vsdamin_R782228ks',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782228K,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782228K`

MINIMUM VALUE FOR ABOVE 16M
"""
s228k_vsdamin_R782228ks.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782228K`

MINIMUM VALUE FOR ABOVE 16M
"""

s228k_vsdantme_R782228ks : Final[Field] = Field(
    name='s228k_vsdantme_R782228ks',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782228K,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782228K`

TIME STAMP FOR MINIMUM VALUE
"""
s228k_vsdantme_R782228ks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782228K`

TIME STAMP FOR MINIMUM VALUE
"""

s228k_vsdamax_R782228ks : Final[Field] = Field(
    name='s228k_vsdamax_R782228ks',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782228K,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782228K`

MAXIMUM VALUE FOR ABOVE 16M
"""
s228k_vsdamax_R782228ks.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782228K`

MAXIMUM VALUE FOR ABOVE 16M
"""

s228k_vsdaxtme_R782228ks : Final[Field] = Field(
    name='s228k_vsdaxtme_R782228ks',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782228K,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782228K`

TIME STAMP FOR MAXIMUM VALUE
"""
s228k_vsdaxtme_R782228ks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782228K`

TIME STAMP FOR MAXIMUM VALUE
"""

s228k_vsdatotl_R782228ks : Final[Field] = Field(
    name='s228k_vsdatotl_R782228ks',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782228K,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782228K`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
s228k_vsdatotl_R782228ks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782228K`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

s231k_vsdbmin_R782231ks : Final[Field] = Field(
    name='s231k_vsdbmin_R782231ks',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782231K,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782231K`

MINIMUM VALUE FOR BELOW 16M
"""
s231k_vsdbmin_R782231ks.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782231K`

MINIMUM VALUE FOR BELOW 16M
"""

s231k_vsdbntme_R782231ks : Final[Field] = Field(
    name='s231k_vsdbntme_R782231ks',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782231K,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782231K`

TIME STAMP FOR MINIMUM VALUE
"""
s231k_vsdbntme_R782231ks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782231K`

TIME STAMP FOR MINIMUM VALUE
"""

s231k_vsdbmax_R782231ks : Final[Field] = Field(
    name='s231k_vsdbmax_R782231ks',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782231K,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782231K`

MAXIMUM VALUE FOR BELOW 16M
"""
s231k_vsdbmax_R782231ks.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782231K`

MAXIMUM VALUE FOR BELOW 16M
"""

s231k_vsdbxtme_R782231ks : Final[Field] = Field(
    name='s231k_vsdbxtme_R782231ks',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782231K,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782231K`

TIME STAMP FOR MAXIMUM VALUE
"""
s231k_vsdbxtme_R782231ks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782231K`

TIME STAMP FOR MAXIMUM VALUE
"""

s231k_vsdbtotl_R782231ks : Final[Field] = Field(
    name='s231k_vsdbtotl_R782231ks',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782231K,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782231K`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
s231k_vsdbtotl_R782231ks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782231K`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

s231k_vsdamin_R782231ks : Final[Field] = Field(
    name='s231k_vsdamin_R782231ks',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782231K,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782231K`

MINIMUM VALUE FOR ABOVE 16M
"""
s231k_vsdamin_R782231ks.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782231K`

MINIMUM VALUE FOR ABOVE 16M
"""

s231k_vsdantme_R782231ks : Final[Field] = Field(
    name='s231k_vsdantme_R782231ks',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782231K,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782231K`

TIME STAMP FOR MINIMUM VALUE
"""
s231k_vsdantme_R782231ks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782231K`

TIME STAMP FOR MINIMUM VALUE
"""

s231k_vsdamax_R782231ks : Final[Field] = Field(
    name='s231k_vsdamax_R782231ks',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782231K,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782231K`

MAXIMUM VALUE FOR ABOVE 16M
"""
s231k_vsdamax_R782231ks.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782231K`

MAXIMUM VALUE FOR ABOVE 16M
"""

s231k_vsdaxtme_R782231ks : Final[Field] = Field(
    name='s231k_vsdaxtme_R782231ks',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782231K,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782231K`

TIME STAMP FOR MAXIMUM VALUE
"""
s231k_vsdaxtme_R782231ks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782231K`

TIME STAMP FOR MAXIMUM VALUE
"""

s231k_vsdatotl_R782231ks : Final[Field] = Field(
    name='s231k_vsdatotl_R782231ks',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782231K,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782231K`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
s231k_vsdatotl_R782231ks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782231K`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

s241k_vsdbmin_R782241ks : Final[Field] = Field(
    name='s241k_vsdbmin_R782241ks',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782241K,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782241K`

MINIMUM VALUE FOR BELOW 16M
"""
s241k_vsdbmin_R782241ks.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782241K`

MINIMUM VALUE FOR BELOW 16M
"""

s241k_vsdbntme_R782241ks : Final[Field] = Field(
    name='s241k_vsdbntme_R782241ks',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782241K,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782241K`

TIME STAMP FOR MINIMUM VALUE
"""
s241k_vsdbntme_R782241ks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782241K`

TIME STAMP FOR MINIMUM VALUE
"""

s241k_vsdbmax_R782241ks : Final[Field] = Field(
    name='s241k_vsdbmax_R782241ks',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782241K,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782241K`

MAXIMUM VALUE FOR BELOW 16M
"""
s241k_vsdbmax_R782241ks.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782241K`

MAXIMUM VALUE FOR BELOW 16M
"""

s241k_vsdbxtme_R782241ks : Final[Field] = Field(
    name='s241k_vsdbxtme_R782241ks',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782241K,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782241K`

TIME STAMP FOR MAXIMUM VALUE
"""
s241k_vsdbxtme_R782241ks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782241K`

TIME STAMP FOR MAXIMUM VALUE
"""

s241k_vsdbtotl_R782241ks : Final[Field] = Field(
    name='s241k_vsdbtotl_R782241ks',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782241K,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782241K`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
s241k_vsdbtotl_R782241ks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782241K`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

s241k_vsdamin_R782241ks : Final[Field] = Field(
    name='s241k_vsdamin_R782241ks',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782241K,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782241K`

MINIMUM VALUE FOR ABOVE 16M
"""
s241k_vsdamin_R782241ks.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782241K`

MINIMUM VALUE FOR ABOVE 16M
"""

s241k_vsdantme_R782241ks : Final[Field] = Field(
    name='s241k_vsdantme_R782241ks',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782241K,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782241K`

TIME STAMP FOR MINIMUM VALUE
"""
s241k_vsdantme_R782241ks.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782241K`

TIME STAMP FOR MINIMUM VALUE
"""

s241k_vsdamax_R782241ks : Final[Field] = Field(
    name='s241k_vsdamax_R782241ks',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782241K,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782241K`

MAXIMUM VALUE FOR ABOVE 16M
"""
s241k_vsdamax_R782241ks.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782241K`

MAXIMUM VALUE FOR ABOVE 16M
"""

s241k_vsdaxtme_R782241ks : Final[Field] = Field(
    name='s241k_vsdaxtme_R782241ks',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782241K,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782241K`

TIME STAMP FOR MAXIMUM VALUE
"""
s241k_vsdaxtme_R782241ks.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782241K`

TIME STAMP FOR MAXIMUM VALUE
"""

s241k_vsdatotl_R782241ks : Final[Field] = Field(
    name='s241k_vsdatotl_R782241ks',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782241K,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782241K`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
s241k_vsdatotl_R782241ks.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782241K`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

lsfp_vsdbmin_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdbmin_R782lsfp',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSFP,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782LSFP`

MINIMUM VALUE FOR BELOW 16M
"""
lsfp_vsdbmin_R782lsfp.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782LSFP`

MINIMUM VALUE FOR BELOW 16M
"""

lsfp_vsdbntme_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdbntme_R782lsfp',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSFP,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782LSFP`

TIME STAMP FOR MINIMUM VALUE
"""
lsfp_vsdbntme_R782lsfp.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782LSFP`

TIME STAMP FOR MINIMUM VALUE
"""

lsfp_vsdbmax_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdbmax_R782lsfp',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSFP,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782LSFP`

MAXIMUM VALUE FOR BELOW 16M
"""
lsfp_vsdbmax_R782lsfp.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782LSFP`

MAXIMUM VALUE FOR BELOW 16M
"""

lsfp_vsdbxtme_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdbxtme_R782lsfp',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSFP,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782LSFP`

TIME STAMP FOR MAXIMUM VALUE
"""
lsfp_vsdbxtme_R782lsfp.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782LSFP`

TIME STAMP FOR MAXIMUM VALUE
"""

lsfp_vsdbtotl_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdbtotl_R782lsfp',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSFP,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782LSFP`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
lsfp_vsdbtotl_R782lsfp.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782LSFP`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

lsfp_vsdamin_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdamin_R782lsfp',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSFP,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782LSFP`

MINIMUM VALUE FOR ABOVE 16M
"""
lsfp_vsdamin_R782lsfp.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782LSFP`

MINIMUM VALUE FOR ABOVE 16M
"""

lsfp_vsdantme_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdantme_R782lsfp',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSFP,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782LSFP`

TIME STAMP FOR MINIMUM VALUE
"""
lsfp_vsdantme_R782lsfp.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782LSFP`

TIME STAMP FOR MINIMUM VALUE
"""

lsfp_vsdamax_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdamax_R782lsfp',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSFP,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782LSFP`

MAXIMUM VALUE FOR ABOVE 16M
"""
lsfp_vsdamax_R782lsfp.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782LSFP`

MAXIMUM VALUE FOR ABOVE 16M
"""

lsfp_vsdaxtme_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdaxtme_R782lsfp',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSFP,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782LSFP`

TIME STAMP FOR MAXIMUM VALUE
"""
lsfp_vsdaxtme_R782lsfp.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782LSFP`

TIME STAMP FOR MAXIMUM VALUE
"""

lsfp_vsdatotl_R782lsfp : Final[Field] = Field(
    name='lsfp_vsdatotl_R782lsfp',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSFP,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782LSFP`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
lsfp_vsdatotl_R782lsfp.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782LSFP`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

lsfb_vsdbmin_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdbmin_R782lsfb',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSFB,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782LSFB`

MINIMUM VALUE FOR BELOW 16M
"""
lsfb_vsdbmin_R782lsfb.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782LSFB`

MINIMUM VALUE FOR BELOW 16M
"""

lsfb_vsdbntme_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdbntme_R782lsfb',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSFB,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782LSFB`

TIME STAMP FOR MINIMUM VALUE
"""
lsfb_vsdbntme_R782lsfb.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782LSFB`

TIME STAMP FOR MINIMUM VALUE
"""

lsfb_vsdbmax_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdbmax_R782lsfb',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSFB,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782LSFB`

MAXIMUM VALUE FOR BELOW 16M
"""
lsfb_vsdbmax_R782lsfb.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782LSFB`

MAXIMUM VALUE FOR BELOW 16M
"""

lsfb_vsdbxtme_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdbxtme_R782lsfb',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSFB,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782LSFB`

TIME STAMP FOR MAXIMUM VALUE
"""
lsfb_vsdbxtme_R782lsfb.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782LSFB`

TIME STAMP FOR MAXIMUM VALUE
"""

lsfb_vsdbtotl_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdbtotl_R782lsfb',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSFB,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782LSFB`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
lsfb_vsdbtotl_R782lsfb.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782LSFB`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

lsfb_vsdamin_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdamin_R782lsfb',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSFB,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782LSFB`

MINIMUM VALUE FOR ABOVE 16M
"""
lsfb_vsdamin_R782lsfb.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782LSFB`

MINIMUM VALUE FOR ABOVE 16M
"""

lsfb_vsdantme_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdantme_R782lsfb',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSFB,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782LSFB`

TIME STAMP FOR MINIMUM VALUE
"""
lsfb_vsdantme_R782lsfb.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782LSFB`

TIME STAMP FOR MINIMUM VALUE
"""

lsfb_vsdamax_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdamax_R782lsfb',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSFB,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782LSFB`

MAXIMUM VALUE FOR ABOVE 16M
"""
lsfb_vsdamax_R782lsfb.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782LSFB`

MAXIMUM VALUE FOR ABOVE 16M
"""

lsfb_vsdaxtme_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdaxtme_R782lsfb',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSFB,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782LSFB`

TIME STAMP FOR MAXIMUM VALUE
"""
lsfb_vsdaxtme_R782lsfb.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782LSFB`

TIME STAMP FOR MAXIMUM VALUE
"""

lsfb_vsdatotl_R782lsfb : Final[Field] = Field(
    name='lsfb_vsdatotl_R782lsfb',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSFB,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782LSFB`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
lsfb_vsdatotl_R782lsfb.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782LSFB`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

lsal_vsdbmin_R782lsal : Final[Field] = Field(
    name='lsal_vsdbmin_R782lsal',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSAL,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782LSAL`

MINIMUM VALUE FOR BELOW 16M
"""
lsal_vsdbmin_R782lsal.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782LSAL`

MINIMUM VALUE FOR BELOW 16M
"""

lsal_vsdbntme_R782lsal : Final[Field] = Field(
    name='lsal_vsdbntme_R782lsal',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSAL,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782LSAL`

TIME STAMP FOR MINIMUM VALUE
"""
lsal_vsdbntme_R782lsal.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782LSAL`

TIME STAMP FOR MINIMUM VALUE
"""

lsal_vsdbmax_R782lsal : Final[Field] = Field(
    name='lsal_vsdbmax_R782lsal',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSAL,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782LSAL`

MAXIMUM VALUE FOR BELOW 16M
"""
lsal_vsdbmax_R782lsal.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782LSAL`

MAXIMUM VALUE FOR BELOW 16M
"""

lsal_vsdbxtme_R782lsal : Final[Field] = Field(
    name='lsal_vsdbxtme_R782lsal',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSAL,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782LSAL`

TIME STAMP FOR MAXIMUM VALUE
"""
lsal_vsdbxtme_R782lsal.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782LSAL`

TIME STAMP FOR MAXIMUM VALUE
"""

lsal_vsdbtotl_R782lsal : Final[Field] = Field(
    name='lsal_vsdbtotl_R782lsal',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSAL,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782LSAL`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
lsal_vsdbtotl_R782lsal.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782LSAL`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

lsal_vsdamin_R782lsal : Final[Field] = Field(
    name='lsal_vsdamin_R782lsal',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSAL,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782LSAL`

MINIMUM VALUE FOR ABOVE 16M
"""
lsal_vsdamin_R782lsal.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782LSAL`

MINIMUM VALUE FOR ABOVE 16M
"""

lsal_vsdantme_R782lsal : Final[Field] = Field(
    name='lsal_vsdantme_R782lsal',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSAL,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782LSAL`

TIME STAMP FOR MINIMUM VALUE
"""
lsal_vsdantme_R782lsal.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782LSAL`

TIME STAMP FOR MINIMUM VALUE
"""

lsal_vsdamax_R782lsal : Final[Field] = Field(
    name='lsal_vsdamax_R782lsal',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSAL,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782LSAL`

MAXIMUM VALUE FOR ABOVE 16M
"""
lsal_vsdamax_R782lsal.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782LSAL`

MAXIMUM VALUE FOR ABOVE 16M
"""

lsal_vsdaxtme_R782lsal : Final[Field] = Field(
    name='lsal_vsdaxtme_R782lsal',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSAL,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782LSAL`

TIME STAMP FOR MAXIMUM VALUE
"""
lsal_vsdaxtme_R782lsal.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782LSAL`

TIME STAMP FOR MAXIMUM VALUE
"""

lsal_vsdatotl_R782lsal : Final[Field] = Field(
    name='lsal_vsdatotl_R782lsal',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSAL,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782LSAL`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
lsal_vsdatotl_R782lsal.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782LSAL`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

lspa_vsdbmin_R782lspa : Final[Field] = Field(
    name='lspa_vsdbmin_R782lspa',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSPA,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782LSPA`

MINIMUM VALUE FOR BELOW 16M
"""
lspa_vsdbmin_R782lspa.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782LSPA`

MINIMUM VALUE FOR BELOW 16M
"""

lspa_vsdbntme_R782lspa : Final[Field] = Field(
    name='lspa_vsdbntme_R782lspa',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSPA,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782LSPA`

TIME STAMP FOR MINIMUM VALUE
"""
lspa_vsdbntme_R782lspa.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782LSPA`

TIME STAMP FOR MINIMUM VALUE
"""

lspa_vsdbmax_R782lspa : Final[Field] = Field(
    name='lspa_vsdbmax_R782lspa',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSPA,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782LSPA`

MAXIMUM VALUE FOR BELOW 16M
"""
lspa_vsdbmax_R782lspa.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782LSPA`

MAXIMUM VALUE FOR BELOW 16M
"""

lspa_vsdbxtme_R782lspa : Final[Field] = Field(
    name='lspa_vsdbxtme_R782lspa',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSPA,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782LSPA`

TIME STAMP FOR MAXIMUM VALUE
"""
lspa_vsdbxtme_R782lspa.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782LSPA`

TIME STAMP FOR MAXIMUM VALUE
"""

lspa_vsdbtotl_R782lspa : Final[Field] = Field(
    name='lspa_vsdbtotl_R782lspa',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSPA,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782LSPA`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
lspa_vsdbtotl_R782lspa.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782LSPA`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

lspa_vsdamin_R782lspa : Final[Field] = Field(
    name='lspa_vsdamin_R782lspa',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSPA,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782LSPA`

MINIMUM VALUE FOR ABOVE 16M
"""
lspa_vsdamin_R782lspa.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782LSPA`

MINIMUM VALUE FOR ABOVE 16M
"""

lspa_vsdantme_R782lspa : Final[Field] = Field(
    name='lspa_vsdantme_R782lspa',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSPA,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782LSPA`

TIME STAMP FOR MINIMUM VALUE
"""
lspa_vsdantme_R782lspa.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782LSPA`

TIME STAMP FOR MINIMUM VALUE
"""

lspa_vsdamax_R782lspa : Final[Field] = Field(
    name='lspa_vsdamax_R782lspa',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782LSPA,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782LSPA`

MAXIMUM VALUE FOR ABOVE 16M
"""
lspa_vsdamax_R782lspa.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782LSPA`

MAXIMUM VALUE FOR ABOVE 16M
"""

lspa_vsdaxtme_R782lspa : Final[Field] = Field(
    name='lspa_vsdaxtme_R782lspa',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSPA,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782LSPA`

TIME STAMP FOR MAXIMUM VALUE
"""
lspa_vsdaxtme_R782lspa.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782LSPA`

TIME STAMP FOR MAXIMUM VALUE
"""

lspa_vsdatotl_R782lspa : Final[Field] = Field(
    name='lspa_vsdatotl_R782lspa',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSPA,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782LSPA`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
lspa_vsdatotl_R782lspa.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782LSPA`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

usfp_vsdbmin_R782usfp : Final[Field] = Field(
    name='usfp_vsdbmin_R782usfp',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USFP,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782USFP`

MINIMUM VALUE FOR BELOW 16M
"""
usfp_vsdbmin_R782usfp.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782USFP`

MINIMUM VALUE FOR BELOW 16M
"""

usfp_vsdbntme_R782usfp : Final[Field] = Field(
    name='usfp_vsdbntme_R782usfp',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USFP,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782USFP`

TIME STAMP FOR MINIMUM VALUE
"""
usfp_vsdbntme_R782usfp.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782USFP`

TIME STAMP FOR MINIMUM VALUE
"""

usfp_vsdbmax_R782usfp : Final[Field] = Field(
    name='usfp_vsdbmax_R782usfp',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USFP,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782USFP`

MAXIMUM VALUE FOR BELOW 16M
"""
usfp_vsdbmax_R782usfp.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782USFP`

MAXIMUM VALUE FOR BELOW 16M
"""

usfp_vsdbxtme_R782usfp : Final[Field] = Field(
    name='usfp_vsdbxtme_R782usfp',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USFP,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782USFP`

TIME STAMP FOR MAXIMUM VALUE
"""
usfp_vsdbxtme_R782usfp.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782USFP`

TIME STAMP FOR MAXIMUM VALUE
"""

usfp_vsdbtotl_R782usfp : Final[Field] = Field(
    name='usfp_vsdbtotl_R782usfp',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782USFP,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782USFP`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
usfp_vsdbtotl_R782usfp.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782USFP`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

usfp_vsdamin_R782usfp : Final[Field] = Field(
    name='usfp_vsdamin_R782usfp',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USFP,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782USFP`

MINIMUM VALUE FOR ABOVE 16M
"""
usfp_vsdamin_R782usfp.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782USFP`

MINIMUM VALUE FOR ABOVE 16M
"""

usfp_vsdantme_R782usfp : Final[Field] = Field(
    name='usfp_vsdantme_R782usfp',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USFP,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782USFP`

TIME STAMP FOR MINIMUM VALUE
"""
usfp_vsdantme_R782usfp.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782USFP`

TIME STAMP FOR MINIMUM VALUE
"""

usfp_vsdamax_R782usfp : Final[Field] = Field(
    name='usfp_vsdamax_R782usfp',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USFP,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782USFP`

MAXIMUM VALUE FOR ABOVE 16M
"""
usfp_vsdamax_R782usfp.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782USFP`

MAXIMUM VALUE FOR ABOVE 16M
"""

usfp_vsdaxtme_R782usfp : Final[Field] = Field(
    name='usfp_vsdaxtme_R782usfp',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USFP,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782USFP`

TIME STAMP FOR MAXIMUM VALUE
"""
usfp_vsdaxtme_R782usfp.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782USFP`

TIME STAMP FOR MAXIMUM VALUE
"""

usfp_vsdatotl_R782usfp : Final[Field] = Field(
    name='usfp_vsdatotl_R782usfp',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782USFP,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782USFP`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
usfp_vsdatotl_R782usfp.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782USFP`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

usfp_vsdbmin_R782usfb : Final[Field] = Field(
    name='usfp_vsdbmin_R782usfb',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USFB,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782USFB`

MINIMUM VALUE FOR BELOW 16M
"""
usfp_vsdbmin_R782usfb.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782USFB`

MINIMUM VALUE FOR BELOW 16M
"""

usfp_vsdbntme_R782usfb : Final[Field] = Field(
    name='usfp_vsdbntme_R782usfb',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USFB,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782USFB`

TIME STAMP FOR MINIMUM VALUE
"""
usfp_vsdbntme_R782usfb.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782USFB`

TIME STAMP FOR MINIMUM VALUE
"""

usfp_vsdbmax_R782usfb : Final[Field] = Field(
    name='usfp_vsdbmax_R782usfb',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USFB,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782USFB`

MAXIMUM VALUE FOR BELOW 16M
"""
usfp_vsdbmax_R782usfb.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782USFB`

MAXIMUM VALUE FOR BELOW 16M
"""

usfp_vsdbxtme_R782usfb : Final[Field] = Field(
    name='usfp_vsdbxtme_R782usfb',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USFB,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782USFB`

TIME STAMP FOR MAXIMUM VALUE
"""
usfp_vsdbxtme_R782usfb.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782USFB`

TIME STAMP FOR MAXIMUM VALUE
"""

usfp_vsdbtotl_R782usfb : Final[Field] = Field(
    name='usfp_vsdbtotl_R782usfb',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782USFB,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782USFB`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
usfp_vsdbtotl_R782usfb.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782USFB`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

usfp_vsdamin_R782usfb : Final[Field] = Field(
    name='usfp_vsdamin_R782usfb',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USFB,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782USFB`

MINIMUM VALUE FOR ABOVE 16M
"""
usfp_vsdamin_R782usfb.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782USFB`

MINIMUM VALUE FOR ABOVE 16M
"""

usfp_vsdantme_R782usfb : Final[Field] = Field(
    name='usfp_vsdantme_R782usfb',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USFB,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782USFB`

TIME STAMP FOR MINIMUM VALUE
"""
usfp_vsdantme_R782usfb.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782USFB`

TIME STAMP FOR MINIMUM VALUE
"""

usfp_vsdamax_R782usfb : Final[Field] = Field(
    name='usfp_vsdamax_R782usfb',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USFB,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782USFB`

MAXIMUM VALUE FOR ABOVE 16M
"""
usfp_vsdamax_R782usfb.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782USFB`

MAXIMUM VALUE FOR ABOVE 16M
"""

usfp_vsdaxtme_R782usfb : Final[Field] = Field(
    name='usfp_vsdaxtme_R782usfb',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USFB,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782USFB`

TIME STAMP FOR MAXIMUM VALUE
"""
usfp_vsdaxtme_R782usfb.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782USFB`

TIME STAMP FOR MAXIMUM VALUE
"""

usfp_vsdatotl_R782usfb : Final[Field] = Field(
    name='usfp_vsdatotl_R782usfb',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782USFB,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782USFB`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
usfp_vsdatotl_R782usfb.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782USFB`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

usal_vsdbmin_R782usal : Final[Field] = Field(
    name='usal_vsdbmin_R782usal',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USAL,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782USAL`

MINIMUM VALUE FOR BELOW 16M
"""
usal_vsdbmin_R782usal.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782USAL`

MINIMUM VALUE FOR BELOW 16M
"""

usal_vsdbntme_R782usal : Final[Field] = Field(
    name='usal_vsdbntme_R782usal',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USAL,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782USAL`

TIME STAMP FOR MINIMUM VALUE
"""
usal_vsdbntme_R782usal.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782USAL`

TIME STAMP FOR MINIMUM VALUE
"""

usal_vsdbmax_R782usal : Final[Field] = Field(
    name='usal_vsdbmax_R782usal',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USAL,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782USAL`

MAXIMUM VALUE FOR BELOW 16M
"""
usal_vsdbmax_R782usal.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782USAL`

MAXIMUM VALUE FOR BELOW 16M
"""

usal_vsdbxtme_R782usal : Final[Field] = Field(
    name='usal_vsdbxtme_R782usal',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USAL,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782USAL`

TIME STAMP FOR MAXIMUM VALUE
"""
usal_vsdbxtme_R782usal.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782USAL`

TIME STAMP FOR MAXIMUM VALUE
"""

usal_vsdbtotl_R782usal : Final[Field] = Field(
    name='usal_vsdbtotl_R782usal',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782USAL,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782USAL`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
usal_vsdbtotl_R782usal.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782USAL`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

usal_vsdamin_R782usal : Final[Field] = Field(
    name='usal_vsdamin_R782usal',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USAL,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782USAL`

MINIMUM VALUE FOR ABOVE 16M
"""
usal_vsdamin_R782usal.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782USAL`

MINIMUM VALUE FOR ABOVE 16M
"""

usal_vsdantme_R782usal : Final[Field] = Field(
    name='usal_vsdantme_R782usal',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USAL,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782USAL`

TIME STAMP FOR MINIMUM VALUE
"""
usal_vsdantme_R782usal.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782USAL`

TIME STAMP FOR MINIMUM VALUE
"""

usal_vsdamax_R782usal : Final[Field] = Field(
    name='usal_vsdamax_R782usal',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USAL,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782USAL`

MAXIMUM VALUE FOR ABOVE 16M
"""
usal_vsdamax_R782usal.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782USAL`

MAXIMUM VALUE FOR ABOVE 16M
"""

usal_vsdaxtme_R782usal : Final[Field] = Field(
    name='usal_vsdaxtme_R782usal',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USAL,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782USAL`

TIME STAMP FOR MAXIMUM VALUE
"""
usal_vsdaxtme_R782usal.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782USAL`

TIME STAMP FOR MAXIMUM VALUE
"""

usal_vsdatotl_R782usal : Final[Field] = Field(
    name='usal_vsdatotl_R782usal',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782USAL,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782USAL`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
usal_vsdatotl_R782usal.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782USAL`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

uspa_vsdbmin_R782uspa : Final[Field] = Field(
    name='uspa_vsdbmin_R782uspa',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USPA,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782USPA`

MINIMUM VALUE FOR BELOW 16M
"""
uspa_vsdbmin_R782uspa.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782USPA`

MINIMUM VALUE FOR BELOW 16M
"""

uspa_vsdbntme_R782uspa : Final[Field] = Field(
    name='uspa_vsdbntme_R782uspa',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USPA,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782USPA`

TIME STAMP FOR MINIMUM VALUE
"""
uspa_vsdbntme_R782uspa.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782USPA`

TIME STAMP FOR MINIMUM VALUE
"""

uspa_vsdbmax_R782uspa : Final[Field] = Field(
    name='uspa_vsdbmax_R782uspa',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USPA,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782USPA`

MAXIMUM VALUE FOR BELOW 16M
"""
uspa_vsdbmax_R782uspa.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782USPA`

MAXIMUM VALUE FOR BELOW 16M
"""

uspa_vsdbxtme_R782uspa : Final[Field] = Field(
    name='uspa_vsdbxtme_R782uspa',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USPA,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782USPA`

TIME STAMP FOR MAXIMUM VALUE
"""
uspa_vsdbxtme_R782uspa.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782USPA`

TIME STAMP FOR MAXIMUM VALUE
"""

uspa_vsdbtotl_R782uspa : Final[Field] = Field(
    name='uspa_vsdbtotl_R782uspa',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782USPA,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782USPA`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
uspa_vsdbtotl_R782uspa.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782USPA`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

uspa_vsdamin_R782uspa : Final[Field] = Field(
    name='uspa_vsdamin_R782uspa',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USPA,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782USPA`

MINIMUM VALUE FOR ABOVE 16M
"""
uspa_vsdamin_R782uspa.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782USPA`

MINIMUM VALUE FOR ABOVE 16M
"""

uspa_vsdantme_R782uspa : Final[Field] = Field(
    name='uspa_vsdantme_R782uspa',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USPA,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782USPA`

TIME STAMP FOR MINIMUM VALUE
"""
uspa_vsdantme_R782uspa.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782USPA`

TIME STAMP FOR MINIMUM VALUE
"""

uspa_vsdamax_R782uspa : Final[Field] = Field(
    name='uspa_vsdamax_R782uspa',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782USPA,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782USPA`

MAXIMUM VALUE FOR ABOVE 16M
"""
uspa_vsdamax_R782uspa.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782USPA`

MAXIMUM VALUE FOR ABOVE 16M
"""

uspa_vsdaxtme_R782uspa : Final[Field] = Field(
    name='uspa_vsdaxtme_R782uspa',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782USPA,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782USPA`

TIME STAMP FOR MAXIMUM VALUE
"""
uspa_vsdaxtme_R782uspa.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782USPA`

TIME STAMP FOR MAXIMUM VALUE
"""

uspa_vsdatotl_R782uspa : Final[Field] = Field(
    name='uspa_vsdatotl_R782uspa',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782USPA,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782USPA`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
uspa_vsdatotl_R782uspa.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782USPA`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""

toby_vsdgmin_R782toby : Final[Field] = Field(
    name='toby_vsdgmin_R782toby',
    origin='VSDGMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOBY,
)
"""MIN VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMIN`
    Record: `SMF78S2`
    Map: `R782TOBY`

MIN VALUE FOR ABOVE 2G
"""
toby_vsdgmin_R782toby.__doc__ = """MIN VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMIN`
    Record: `SMF78S2`
    Map: `R782TOBY`

MIN VALUE FOR ABOVE 2G
"""

toby_vsdgntme_R782toby : Final[Field] = Field(
    name='toby_vsdgntme_R782toby',
    origin='VSDGNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782TOBY,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDGNTME`
    Record: `SMF78S2`
    Map: `R782TOBY`

TIMESTAMP FOR MIN VALUE
"""
toby_vsdgntme_R782toby.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDGNTME`
    Record: `SMF78S2`
    Map: `R782TOBY`

TIMESTAMP FOR MIN VALUE
"""

toby_vsdgmax_R782toby : Final[Field] = Field(
    name='toby_vsdgmax_R782toby',
    origin='VSDGMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOBY,
)
"""MAX VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMAX`
    Record: `SMF78S2`
    Map: `R782TOBY`

MAX VALUE FOR ABOVE 2G
"""
toby_vsdgmax_R782toby.__doc__ = """MAX VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMAX`
    Record: `SMF78S2`
    Map: `R782TOBY`

MAX VALUE FOR ABOVE 2G
"""

toby_vsdgxtme_R782toby : Final[Field] = Field(
    name='toby_vsdgxtme_R782toby',
    origin='VSDGXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782TOBY,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDGXTME`
    Record: `SMF78S2`
    Map: `R782TOBY`

TIMESTAMP FOR MAX VALUE
"""
toby_vsdgxtme_R782toby.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDGXTME`
    Record: `SMF78S2`
    Map: `R782TOBY`

TIMESTAMP FOR MAX VALUE
"""

toby_vsdgtotl_R782toby : Final[Field] = Field(
    name='toby_vsdgtotl_R782toby',
    origin='VSDGTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOBY,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDGTOTL`
    Record: `SMF78S2`
    Map: `R782TOBY`

TOTAL FOR ALL SAMPLES
"""
toby_vsdgtotl_R782toby.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDGTOTL`
    Record: `SMF78S2`
    Map: `R782TOBY`

TOTAL FOR ALL SAMPLES
"""

toby_vsdghwm_R782toby : Final[Field] = Field(
    name='toby_vsdghwm_R782toby',
    origin='VSDGHWM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOBY,
)
"""HIGH MARK ABOVE 2G

SMF Info
--------
    Field: `VSDGHWM`
    Record: `SMF78S2`
    Map: `R782TOBY`

HIGH MARK ABOVE 2G
"""
toby_vsdghwm_R782toby.__doc__ = """HIGH MARK ABOVE 2G

SMF Info
--------
    Field: `VSDGHWM`
    Record: `SMF78S2`
    Map: `R782TOBY`

HIGH MARK ABOVE 2G
"""

shby_vsdgmin_R782shby : Final[Field] = Field(
    name='shby_vsdgmin_R782shby',
    origin='VSDGMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SHBY,
)
"""MIN VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMIN`
    Record: `SMF78S2`
    Map: `R782SHBY`

MIN VALUE FOR ABOVE 2G
"""
shby_vsdgmin_R782shby.__doc__ = """MIN VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMIN`
    Record: `SMF78S2`
    Map: `R782SHBY`

MIN VALUE FOR ABOVE 2G
"""

shby_vsdgntme_R782shby : Final[Field] = Field(
    name='shby_vsdgntme_R782shby',
    origin='VSDGNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SHBY,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDGNTME`
    Record: `SMF78S2`
    Map: `R782SHBY`

TIMESTAMP FOR MIN VALUE
"""
shby_vsdgntme_R782shby.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDGNTME`
    Record: `SMF78S2`
    Map: `R782SHBY`

TIMESTAMP FOR MIN VALUE
"""

shby_vsdgmax_R782shby : Final[Field] = Field(
    name='shby_vsdgmax_R782shby',
    origin='VSDGMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SHBY,
)
"""MAX VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMAX`
    Record: `SMF78S2`
    Map: `R782SHBY`

MAX VALUE FOR ABOVE 2G
"""
shby_vsdgmax_R782shby.__doc__ = """MAX VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMAX`
    Record: `SMF78S2`
    Map: `R782SHBY`

MAX VALUE FOR ABOVE 2G
"""

shby_vsdgxtme_R782shby : Final[Field] = Field(
    name='shby_vsdgxtme_R782shby',
    origin='VSDGXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SHBY,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDGXTME`
    Record: `SMF78S2`
    Map: `R782SHBY`

TIMESTAMP FOR MAX VALUE
"""
shby_vsdgxtme_R782shby.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDGXTME`
    Record: `SMF78S2`
    Map: `R782SHBY`

TIMESTAMP FOR MAX VALUE
"""

shby_vsdgtotl_R782shby : Final[Field] = Field(
    name='shby_vsdgtotl_R782shby',
    origin='VSDGTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SHBY,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDGTOTL`
    Record: `SMF78S2`
    Map: `R782SHBY`

TOTAL FOR ALL SAMPLES
"""
shby_vsdgtotl_R782shby.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDGTOTL`
    Record: `SMF78S2`
    Map: `R782SHBY`

TOTAL FOR ALL SAMPLES
"""

shby_vsdghwm_R782shby : Final[Field] = Field(
    name='shby_vsdghwm_R782shby',
    origin='VSDGHWM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SHBY,
)
"""HIGH MARK ABOVE 2G

SMF Info
--------
    Field: `VSDGHWM`
    Record: `SMF78S2`
    Map: `R782SHBY`

HIGH MARK ABOVE 2G
"""
shby_vsdghwm_R782shby.__doc__ = """HIGH MARK ABOVE 2G

SMF Info
--------
    Field: `VSDGHWM`
    Record: `SMF78S2`
    Map: `R782SHBY`

HIGH MARK ABOVE 2G
"""

coby_vsdgmin_R782coby : Final[Field] = Field(
    name='coby_vsdgmin_R782coby',
    origin='VSDGMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782COBY,
)
"""MIN VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMIN`
    Record: `SMF78S2`
    Map: `R782COBY`

MIN VALUE FOR ABOVE 2G
"""
coby_vsdgmin_R782coby.__doc__ = """MIN VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMIN`
    Record: `SMF78S2`
    Map: `R782COBY`

MIN VALUE FOR ABOVE 2G
"""

coby_vsdgntme_R782coby : Final[Field] = Field(
    name='coby_vsdgntme_R782coby',
    origin='VSDGNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782COBY,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDGNTME`
    Record: `SMF78S2`
    Map: `R782COBY`

TIMESTAMP FOR MIN VALUE
"""
coby_vsdgntme_R782coby.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDGNTME`
    Record: `SMF78S2`
    Map: `R782COBY`

TIMESTAMP FOR MIN VALUE
"""

coby_vsdgmax_R782coby : Final[Field] = Field(
    name='coby_vsdgmax_R782coby',
    origin='VSDGMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782COBY,
)
"""MAX VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMAX`
    Record: `SMF78S2`
    Map: `R782COBY`

MAX VALUE FOR ABOVE 2G
"""
coby_vsdgmax_R782coby.__doc__ = """MAX VALUE FOR ABOVE 2G

SMF Info
--------
    Field: `VSDGMAX`
    Record: `SMF78S2`
    Map: `R782COBY`

MAX VALUE FOR ABOVE 2G
"""

coby_vsdgxtme_R782coby : Final[Field] = Field(
    name='coby_vsdgxtme_R782coby',
    origin='VSDGXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782COBY,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDGXTME`
    Record: `SMF78S2`
    Map: `R782COBY`

TIMESTAMP FOR MAX VALUE
"""
coby_vsdgxtme_R782coby.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDGXTME`
    Record: `SMF78S2`
    Map: `R782COBY`

TIMESTAMP FOR MAX VALUE
"""

coby_vsdgtotl_R782coby : Final[Field] = Field(
    name='coby_vsdgtotl_R782coby',
    origin='VSDGTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782COBY,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDGTOTL`
    Record: `SMF78S2`
    Map: `R782COBY`

TOTAL FOR ALL SAMPLES
"""
coby_vsdgtotl_R782coby.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDGTOTL`
    Record: `SMF78S2`
    Map: `R782COBY`

TOTAL FOR ALL SAMPLES
"""

coby_vsdghwm_R782coby : Final[Field] = Field(
    name='coby_vsdghwm_R782coby',
    origin='VSDGHWM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782COBY,
)
"""HIGH MARK ABOVE 2G

SMF Info
--------
    Field: `VSDGHWM`
    Record: `SMF78S2`
    Map: `R782COBY`

HIGH MARK ABOVE 2G
"""
coby_vsdghwm_R782coby.__doc__ = """HIGH MARK ABOVE 2G

SMF Info
--------
    Field: `VSDGHWM`
    Record: `SMF78S2`
    Map: `R782COBY`

HIGH MARK ABOVE 2G
"""

tomo_vsdcmin_R782tomo : Final[Field] = Field(
    name='tomo_vsdcmin_R782tomo',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOMO,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782TOMO`

MIN VALUE
"""
tomo_vsdcmin_R782tomo.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782TOMO`

MIN VALUE
"""

tomo_vsdcntme_R782tomo : Final[Field] = Field(
    name='tomo_vsdcntme_R782tomo',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782TOMO,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782TOMO`

TIMESTAMP FOR MIN VALUE
"""
tomo_vsdcntme_R782tomo.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782TOMO`

TIMESTAMP FOR MIN VALUE
"""

tomo_vsdcmax_R782tomo : Final[Field] = Field(
    name='tomo_vsdcmax_R782tomo',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOMO,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782TOMO`

MAX VALUE
"""
tomo_vsdcmax_R782tomo.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782TOMO`

MAX VALUE
"""

tomo_vsdcxtme_R782tomo : Final[Field] = Field(
    name='tomo_vsdcxtme_R782tomo',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782TOMO,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782TOMO`

TIMESTAMP FOR MAX VALUE
"""
tomo_vsdcxtme_R782tomo.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782TOMO`

TIMESTAMP FOR MAX VALUE
"""

tomo_vsdctotl_R782tomo : Final[Field] = Field(
    name='tomo_vsdctotl_R782tomo',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOMO,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782TOMO`

TOTAL FOR ALL SAMPLES
"""
tomo_vsdctotl_R782tomo.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782TOMO`

TOTAL FOR ALL SAMPLES
"""

shmo_vsdcmin_R782shmo : Final[Field] = Field(
    name='shmo_vsdcmin_R782shmo',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SHMO,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782SHMO`

MIN VALUE
"""
shmo_vsdcmin_R782shmo.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782SHMO`

MIN VALUE
"""

shmo_vsdcntme_R782shmo : Final[Field] = Field(
    name='shmo_vsdcntme_R782shmo',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SHMO,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782SHMO`

TIMESTAMP FOR MIN VALUE
"""
shmo_vsdcntme_R782shmo.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782SHMO`

TIMESTAMP FOR MIN VALUE
"""

shmo_vsdcmax_R782shmo : Final[Field] = Field(
    name='shmo_vsdcmax_R782shmo',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SHMO,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782SHMO`

MAX VALUE
"""
shmo_vsdcmax_R782shmo.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782SHMO`

MAX VALUE
"""

shmo_vsdcxtme_R782shmo : Final[Field] = Field(
    name='shmo_vsdcxtme_R782shmo',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SHMO,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782SHMO`

TIMESTAMP FOR MAX VALUE
"""
shmo_vsdcxtme_R782shmo.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782SHMO`

TIMESTAMP FOR MAX VALUE
"""

shmo_vsdctotl_R782shmo : Final[Field] = Field(
    name='shmo_vsdctotl_R782shmo',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SHMO,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782SHMO`

TOTAL FOR ALL SAMPLES
"""
shmo_vsdctotl_R782shmo.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782SHMO`

TOTAL FOR ALL SAMPLES
"""

como_vsdcmin_R782como : Final[Field] = Field(
    name='como_vsdcmin_R782como',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782COMO,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782COMO`

MIN VALUE
"""
como_vsdcmin_R782como.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782COMO`

MIN VALUE
"""

como_vsdcntme_R782como : Final[Field] = Field(
    name='como_vsdcntme_R782como',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782COMO,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782COMO`

TIMESTAMP FOR MIN VALUE
"""
como_vsdcntme_R782como.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782COMO`

TIMESTAMP FOR MIN VALUE
"""

como_vsdcmax_R782como : Final[Field] = Field(
    name='como_vsdcmax_R782como',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782COMO,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782COMO`

MAX VALUE
"""
como_vsdcmax_R782como.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782COMO`

MAX VALUE
"""

como_vsdcxtme_R782como : Final[Field] = Field(
    name='como_vsdcxtme_R782como',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782COMO,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782COMO`

TIMESTAMP FOR MAX VALUE
"""
como_vsdcxtme_R782como.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782COMO`

TIMESTAMP FOR MAX VALUE
"""

como_vsdctotl_R782como : Final[Field] = Field(
    name='como_vsdctotl_R782como',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782COMO,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782COMO`

TOTAL FOR ALL SAMPLES
"""
como_vsdctotl_R782como.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782COMO`

TOTAL FOR ALL SAMPLES
"""

lgmo_vsdcmin_R782lgmo : Final[Field] = Field(
    name='lgmo_vsdcmin_R782lgmo',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LGMO,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782LGMO`

MIN VALUE
"""
lgmo_vsdcmin_R782lgmo.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782LGMO`

MIN VALUE
"""

lgmo_vsdcntme_R782lgmo : Final[Field] = Field(
    name='lgmo_vsdcntme_R782lgmo',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LGMO,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782LGMO`

TIMESTAMP FOR MIN VALUE
"""
lgmo_vsdcntme_R782lgmo.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782LGMO`

TIMESTAMP FOR MIN VALUE
"""

lgmo_vsdcmax_R782lgmo : Final[Field] = Field(
    name='lgmo_vsdcmax_R782lgmo',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LGMO,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782LGMO`

MAX VALUE
"""
lgmo_vsdcmax_R782lgmo.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782LGMO`

MAX VALUE
"""

lgmo_vsdcxtme_R782lgmo : Final[Field] = Field(
    name='lgmo_vsdcxtme_R782lgmo',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LGMO,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782LGMO`

TIMESTAMP FOR MAX VALUE
"""
lgmo_vsdcxtme_R782lgmo.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782LGMO`

TIMESTAMP FOR MAX VALUE
"""

lgmo_vsdctotl_R782lgmo : Final[Field] = Field(
    name='lgmo_vsdctotl_R782lgmo',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LGMO,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782LGMO`

TOTAL FOR ALL SAMPLES
"""
lgmo_vsdctotl_R782lgmo.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782LGMO`

TOTAL FOR ALL SAMPLES
"""

tofr_vsdcmin_R782tofr : Final[Field] = Field(
    name='tofr_vsdcmin_R782tofr',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOFR,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782TOFR`

MIN VALUE
"""
tofr_vsdcmin_R782tofr.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782TOFR`

MIN VALUE
"""

tofr_vsdcntme_R782tofr : Final[Field] = Field(
    name='tofr_vsdcntme_R782tofr',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782TOFR,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782TOFR`

TIMESTAMP FOR MIN VALUE
"""
tofr_vsdcntme_R782tofr.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782TOFR`

TIMESTAMP FOR MIN VALUE
"""

tofr_vsdcmax_R782tofr : Final[Field] = Field(
    name='tofr_vsdcmax_R782tofr',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOFR,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782TOFR`

MAX VALUE
"""
tofr_vsdcmax_R782tofr.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782TOFR`

MAX VALUE
"""

tofr_vsdcxtme_R782tofr : Final[Field] = Field(
    name='tofr_vsdcxtme_R782tofr',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782TOFR,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782TOFR`

TIMESTAMP FOR MAX VALUE
"""
tofr_vsdcxtme_R782tofr.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782TOFR`

TIMESTAMP FOR MAX VALUE
"""

tofr_vsdctotl_R782tofr : Final[Field] = Field(
    name='tofr_vsdctotl_R782tofr',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782TOFR,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782TOFR`

TOTAL FOR ALL SAMPLES
"""
tofr_vsdctotl_R782tofr.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782TOFR`

TOTAL FOR ALL SAMPLES
"""

fifr_vsdcmin_R782fifr : Final[Field] = Field(
    name='fifr_vsdcmin_R782fifr',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782FIFR,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782FIFR`

MIN VALUE
"""
fifr_vsdcmin_R782fifr.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782FIFR`

MIN VALUE
"""

fifr_vsdcntme_R782fifr : Final[Field] = Field(
    name='fifr_vsdcntme_R782fifr',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782FIFR,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782FIFR`

TIMESTAMP FOR MIN VALUE
"""
fifr_vsdcntme_R782fifr.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782FIFR`

TIMESTAMP FOR MIN VALUE
"""

fifr_vsdcmax_R782fifr : Final[Field] = Field(
    name='fifr_vsdcmax_R782fifr',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782FIFR,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782FIFR`

MAX VALUE
"""
fifr_vsdcmax_R782fifr.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782FIFR`

MAX VALUE
"""

fifr_vsdcxtme_R782fifr : Final[Field] = Field(
    name='fifr_vsdcxtme_R782fifr',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782FIFR,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782FIFR`

TIMESTAMP FOR MAX VALUE
"""
fifr_vsdcxtme_R782fifr.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782FIFR`

TIMESTAMP FOR MAX VALUE
"""

fifr_vsdctotl_R782fifr : Final[Field] = Field(
    name='fifr_vsdctotl_R782fifr',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782FIFR,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782FIFR`

TOTAL FOR ALL SAMPLES
"""
fifr_vsdctotl_R782fifr.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782FIFR`

TOTAL FOR ALL SAMPLES
"""

pafr_vsdcmin_R782pafr : Final[Field] = Field(
    name='pafr_vsdcmin_R782pafr',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782PAFR,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782PAFR`

MIN VALUE
"""
pafr_vsdcmin_R782pafr.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782PAFR`

MIN VALUE
"""

pafr_vsdcntme_R782pafr : Final[Field] = Field(
    name='pafr_vsdcntme_R782pafr',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782PAFR,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782PAFR`

TIMESTAMP FOR MIN VALUE
"""
pafr_vsdcntme_R782pafr.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782PAFR`

TIMESTAMP FOR MIN VALUE
"""

pafr_vsdcmax_R782pafr : Final[Field] = Field(
    name='pafr_vsdcmax_R782pafr',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782PAFR,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782PAFR`

MAX VALUE
"""
pafr_vsdcmax_R782pafr.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782PAFR`

MAX VALUE
"""

pafr_vsdcxtme_R782pafr : Final[Field] = Field(
    name='pafr_vsdcxtme_R782pafr',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782PAFR,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782PAFR`

TIMESTAMP FOR MAX VALUE
"""
pafr_vsdcxtme_R782pafr.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782PAFR`

TIMESTAMP FOR MAX VALUE
"""

pafr_vsdctotl_R782pafr : Final[Field] = Field(
    name='pafr_vsdctotl_R782pafr',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782PAFR,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782PAFR`

TOTAL FOR ALL SAMPLES
"""
pafr_vsdctotl_R782pafr.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782PAFR`

TOTAL FOR ALL SAMPLES
"""

lsmo_vsdcmin_R782lsmo : Final[Field] = Field(
    name='lsmo_vsdcmin_R782lsmo',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSMO,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782LSMO`

MIN VALUE
"""
lsmo_vsdcmin_R782lsmo.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782LSMO`

MIN VALUE
"""

lsmo_vsdcntme_R782lsmo : Final[Field] = Field(
    name='lsmo_vsdcntme_R782lsmo',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSMO,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782LSMO`

TIMESTAMP FOR MIN VALUE
"""
lsmo_vsdcntme_R782lsmo.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782LSMO`

TIMESTAMP FOR MIN VALUE
"""

lsmo_vsdcmax_R782lsmo : Final[Field] = Field(
    name='lsmo_vsdcmax_R782lsmo',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSMO,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782LSMO`

MAX VALUE
"""
lsmo_vsdcmax_R782lsmo.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782LSMO`

MAX VALUE
"""

lsmo_vsdcxtme_R782lsmo : Final[Field] = Field(
    name='lsmo_vsdcxtme_R782lsmo',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782LSMO,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782LSMO`

TIMESTAMP FOR MAX VALUE
"""
lsmo_vsdcxtme_R782lsmo.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782LSMO`

TIMESTAMP FOR MAX VALUE
"""

lsmo_vsdctotl_R782lsmo : Final[Field] = Field(
    name='lsmo_vsdctotl_R782lsmo',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782LSMO,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782LSMO`

TOTAL FOR ALL SAMPLES
"""
lsmo_vsdctotl_R782lsmo.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782LSMO`

TOTAL FOR ALL SAMPLES
"""

GFMO_vsdcmin_R782gfmo : Final[Field] = Field(
    name='GFMO_vsdcmin_R782gfmo',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782GFMO,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782GFMO`

MIN VALUE
"""
GFMO_vsdcmin_R782gfmo.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782GFMO`

MIN VALUE
"""

GFMO_vsdcntme_R782gfmo : Final[Field] = Field(
    name='GFMO_vsdcntme_R782gfmo',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782GFMO,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782GFMO`

TIMESTAMP FOR MIN VALUE
"""
GFMO_vsdcntme_R782gfmo.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782GFMO`

TIMESTAMP FOR MIN VALUE
"""

GFMO_vsdcmax_R782gfmo : Final[Field] = Field(
    name='GFMO_vsdcmax_R782gfmo',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782GFMO,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782GFMO`

MAX VALUE
"""
GFMO_vsdcmax_R782gfmo.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782GFMO`

MAX VALUE
"""

GFMO_vsdcxtme_R782gfmo : Final[Field] = Field(
    name='GFMO_vsdcxtme_R782gfmo',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782GFMO,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782GFMO`

TIMESTAMP FOR MAX VALUE
"""
GFMO_vsdcxtme_R782gfmo.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782GFMO`

TIMESTAMP FOR MAX VALUE
"""

GFMO_vsdctotl_R782gfmo : Final[Field] = Field(
    name='GFMO_vsdctotl_R782gfmo',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782GFMO,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782GFMO`

TOTAL FOR ALL SAMPLES
"""
GFMO_vsdctotl_R782gfmo.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782GFMO`

TOTAL FOR ALL SAMPLES
"""

gffr_vsdcmin_R782gffr : Final[Field] = Field(
    name='gffr_vsdcmin_R782gffr',
    origin='VSDCMIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782GFFR,
)
"""MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782GFFR`

MIN VALUE
"""
gffr_vsdcmin_R782gffr.__doc__ = """MIN VALUE

SMF Info
--------
    Field: `VSDCMIN`
    Record: `SMF78S2`
    Map: `R782GFFR`

MIN VALUE
"""

gffr_vsdcntme_R782gffr : Final[Field] = Field(
    name='gffr_vsdcntme_R782gffr',
    origin='VSDCNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782GFFR,
)
"""TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782GFFR`

TIMESTAMP FOR MIN VALUE
"""
gffr_vsdcntme_R782gffr.__doc__ = """TIMESTAMP FOR MIN VALUE

SMF Info
--------
    Field: `VSDCNTME`
    Record: `SMF78S2`
    Map: `R782GFFR`

TIMESTAMP FOR MIN VALUE
"""

gffr_vsdcmax_R782gffr : Final[Field] = Field(
    name='gffr_vsdcmax_R782gffr',
    origin='VSDCMAX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782GFFR,
)
"""MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782GFFR`

MAX VALUE
"""
gffr_vsdcmax_R782gffr.__doc__ = """MAX VALUE

SMF Info
--------
    Field: `VSDCMAX`
    Record: `SMF78S2`
    Map: `R782GFFR`

MAX VALUE
"""

gffr_vsdcxtme_R782gffr : Final[Field] = Field(
    name='gffr_vsdcxtme_R782gffr',
    origin='VSDCXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782GFFR,
)
"""TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782GFFR`

TIMESTAMP FOR MAX VALUE
"""
gffr_vsdcxtme_R782gffr.__doc__ = """TIMESTAMP FOR MAX VALUE

SMF Info
--------
    Field: `VSDCXTME`
    Record: `SMF78S2`
    Map: `R782GFFR`

TIMESTAMP FOR MAX VALUE
"""

gffr_vsdctotl_R782gffr : Final[Field] = Field(
    name='gffr_vsdctotl_R782gffr',
    origin='VSDCTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782GFFR,
)
"""TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782GFFR`

TOTAL FOR ALL SAMPLES
"""
gffr_vsdctotl_R782gffr.__doc__ = """TOTAL FOR ALL SAMPLES

SMF Info
--------
    Field: `VSDCTOTL`
    Record: `SMF78S2`
    Map: `R782GFFR`

TOTAL FOR ALL SAMPLES
"""

vsdbmin_R782spd : Final[Field] = Field(
    name='vsdbmin_R782spd',
    origin='VSDBMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SPD,
)
"""MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SPD`

MINIMUM VALUE FOR BELOW 16M
"""
vsdbmin_R782spd.__doc__ = """MINIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMIN`
    Record: `SMF78S2`
    Map: `R782SPD`

MINIMUM VALUE FOR BELOW 16M
"""

vsdbntme_R782spd : Final[Field] = Field(
    name='vsdbntme_R782spd',
    origin='VSDBNTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SPD,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SPD`

TIME STAMP FOR MINIMUM VALUE
"""
vsdbntme_R782spd.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDBNTME`
    Record: `SMF78S2`
    Map: `R782SPD`

TIME STAMP FOR MINIMUM VALUE
"""

vsdbmax_R782spd : Final[Field] = Field(
    name='vsdbmax_R782spd',
    origin='VSDBMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SPD,
)
"""MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SPD`

MAXIMUM VALUE FOR BELOW 16M
"""
vsdbmax_R782spd.__doc__ = """MAXIMUM VALUE FOR BELOW 16M

SMF Info
--------
    Field: `VSDBMAX`
    Record: `SMF78S2`
    Map: `R782SPD`

MAXIMUM VALUE FOR BELOW 16M
"""

vsdbxtme_R782spd : Final[Field] = Field(
    name='vsdbxtme_R782spd',
    origin='VSDBXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SPD,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SPD`

TIME STAMP FOR MAXIMUM VALUE
"""
vsdbxtme_R782spd.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDBXTME`
    Record: `SMF78S2`
    Map: `R782SPD`

TIME STAMP FOR MAXIMUM VALUE
"""

vsdbtotl_R782spd : Final[Field] = Field(
    name='vsdbtotl_R782spd',
    origin='VSDBTOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SPD,
)
"""RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SPD`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""
vsdbtotl_R782spd.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDBTOTL`
    Record: `SMF78S2`
    Map: `R782SPD`

RUNNING TOTAL FOR ALL SAMPLES BELOW 16M, IN FLOATING POINT
"""

vsdamin_R782spd : Final[Field] = Field(
    name='vsdamin_R782spd',
    origin='VSDAMIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SPD,
)
"""MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SPD`

MINIMUM VALUE FOR ABOVE 16M
"""
vsdamin_R782spd.__doc__ = """MINIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMIN`
    Record: `SMF78S2`
    Map: `R782SPD`

MINIMUM VALUE FOR ABOVE 16M
"""

vsdantme_R782spd : Final[Field] = Field(
    name='vsdantme_R782spd',
    origin='VSDANTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SPD,
)
"""TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SPD`

TIME STAMP FOR MINIMUM VALUE
"""
vsdantme_R782spd.__doc__ = """TIME STAMP FOR MINIMUM VALUE

SMF Info
--------
    Field: `VSDANTME`
    Record: `SMF78S2`
    Map: `R782SPD`

TIME STAMP FOR MINIMUM VALUE
"""

vsdamax_R782spd : Final[Field] = Field(
    name='vsdamax_R782spd',
    origin='VSDAMAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R782SPD,
)
"""MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SPD`

MAXIMUM VALUE FOR ABOVE 16M
"""
vsdamax_R782spd.__doc__ = """MAXIMUM VALUE FOR ABOVE 16M

SMF Info
--------
    Field: `VSDAMAX`
    Record: `SMF78S2`
    Map: `R782SPD`

MAXIMUM VALUE FOR ABOVE 16M
"""

vsdaxtme_R782spd : Final[Field] = Field(
    name='vsdaxtme_R782spd',
    origin='VSDAXTME',
    type=FieldType.DATETIME,
    record=record,
    record_map=R782SPD,
)
"""TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SPD`

TIME STAMP FOR MAXIMUM VALUE
"""
vsdaxtme_R782spd.__doc__ = """TIME STAMP FOR MAXIMUM VALUE

SMF Info
--------
    Field: `VSDAXTME`
    Record: `SMF78S2`
    Map: `R782SPD`

TIME STAMP FOR MAXIMUM VALUE
"""

vsdatotl_R782spd : Final[Field] = Field(
    name='vsdatotl_R782spd',
    origin='VSDATOTL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R782SPD,
)
"""RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SPD`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
vsdatotl_R782spd.__doc__ = """RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT

SMF Info
--------
    Field: `VSDATOTL`
    Record: `SMF78S2`
    Map: `R782SPD`

RUNNING TOTAL FOR ALL SAMPLES ABOVE 16M, IN FLOATING POINT
"""
