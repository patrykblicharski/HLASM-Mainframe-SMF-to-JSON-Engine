# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 10"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=10,
                                spec='SMF 74 Subtype 10',
                                post=None)
"""SMF 74 Subtype 10"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R7410DI: Final[RecordMap] = RecordMap(
    origin='R7410DI',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='EADM Device Information Section',
    post=None,
    record_mapping=False)
"""EADM Device Information Section"""
R7410CM: Final[RecordMap] = RecordMap(
    origin='R7410CM',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='SCM Configuration Measurement Section',
    post=None,
    record_mapping=False)
"""SCM Configuration Measurement Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S10`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S10`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S10`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S10`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S10`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S10`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S10`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S10`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S10`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S10`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S10`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S10`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S10`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S10`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S10`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S10`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S10`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S10`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S10`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S10`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S10`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S10`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S10`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S10`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S10`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S10`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S10`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S10`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S10`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S10`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S10`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S10`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S10`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

do : Final[Field] = Field(
    name='do',
    origin='SMF7410DO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to SCM EADM device information section

SMF Info
--------
    Field: `SMF7410DO`
    Record: `SMF74S10`
    Map: Not part of a map

Offset to SCM EADM device information section
"""
do.__doc__ = """Offset to SCM EADM device information section

SMF Info
--------
    Field: `SMF7410DO`
    Record: `SMF74S10`
    Map: Not part of a map

Offset to SCM EADM device information section
"""

dl : Final[Field] = Field(
    name='dl',
    origin='SMF7410DL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of SCM EADM device information section

SMF Info
--------
    Field: `SMF7410DL`
    Record: `SMF74S10`
    Map: Not part of a map

Length of SCM EADM device information section
"""
dl.__doc__ = """Length of SCM EADM device information section

SMF Info
--------
    Field: `SMF7410DL`
    Record: `SMF74S10`
    Map: Not part of a map

Length of SCM EADM device information section
"""

dn : Final[Field] = Field(
    name='dn',
    origin='SMF7410DN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of SCM EADM device information sections

SMF Info
--------
    Field: `SMF7410DN`
    Record: `SMF74S10`
    Map: Not part of a map

Number of SCM EADM device information sections
"""
dn.__doc__ = """Number of SCM EADM device information sections

SMF Info
--------
    Field: `SMF7410DN`
    Record: `SMF74S10`
    Map: Not part of a map

Number of SCM EADM device information sections
"""

co : Final[Field] = Field(
    name='co',
    origin='SMF7410CO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to SCM configuration measurement sections

SMF Info
--------
    Field: `SMF7410CO`
    Record: `SMF74S10`
    Map: Not part of a map

Offset to SCM configuration measurement sections
"""
co.__doc__ = """Offset to SCM configuration measurement sections

SMF Info
--------
    Field: `SMF7410CO`
    Record: `SMF74S10`
    Map: Not part of a map

Offset to SCM configuration measurement sections
"""

cl : Final[Field] = Field(
    name='cl',
    origin='SMF7410CL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of SCM configuration measurement section

SMF Info
--------
    Field: `SMF7410CL`
    Record: `SMF74S10`
    Map: Not part of a map

Length of SCM configuration measurement section
"""
cl.__doc__ = """Length of SCM configuration measurement section

SMF Info
--------
    Field: `SMF7410CL`
    Record: `SMF74S10`
    Map: Not part of a map

Length of SCM configuration measurement section
"""

cn : Final[Field] = Field(
    name='cn',
    origin='SMF7410CN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of SCM configuration measurement sections

SMF Info
--------
    Field: `SMF7410CN`
    Record: `SMF74S10`
    Map: Not part of a map

Number of SCM configuration measurement sections
"""
cn.__doc__ = """Number of SCM configuration measurement sections

SMF Info
--------
    Field: `SMF7410CN`
    Record: `SMF74S10`
    Map: Not part of a map

Number of SCM configuration measurement sections
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S10`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S10`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S10`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S10`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S10`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S10`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S10`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S10`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S10`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S10`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S10`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S10`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S10`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S10`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

r7410dsct : Final[Field] = Field(
    name='r7410dsct',
    origin='R7410DSCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""SSCH count across all devices

SMF Info
--------
    Field: `R7410DSCT`
    Record: `SMF74S10`
    Map: `R7410DI`

SSCH count across all devices
"""
r7410dsct.__doc__ = """SSCH count across all devices

SMF Info
--------
    Field: `R7410DSCT`
    Record: `SMF74S10`
    Map: `R7410DI`

SSCH count across all devices
"""

r7410dnum : Final[Field] = Field(
    name='r7410dnum',
    origin='R7410DNUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Number of updates to the time accumulation fields

SMF Info
--------
    Field: `R7410DNUM`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of updates to the time accumulation fields
"""
r7410dnum.__doc__ = """Number of updates to the time accumulation fields

SMF Info
--------
    Field: `R7410DNUM`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of updates to the time accumulation fields
"""

r7410dfpt : Final[Field] = Field(
    name='r7410dfpt',
    origin='R7410DFPT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Sum of function pending times across all devices in units of 128 microseconds (doubleword format). The time lapse between the SSCH being issued and the acceptance of the first command of the channel program at the device.

SMF Info
--------
    Field: `R7410DFPT`
    Record: `SMF74S10`
    Map: `R7410DI`

Sum of function pending times across all devices in units of 128 microseconds (doubleword format). The time lapse between the SSCH being issued and the acceptance of the first command of the channel program at the device.
"""
r7410dfpt.__doc__ = """Sum of function pending times across all devices in units of 128 microseconds (doubleword format). The time lapse between the SSCH being issued and the acceptance of the first command of the channel program at the device.

SMF Info
--------
    Field: `R7410DFPT`
    Record: `SMF74S10`
    Map: `R7410DI`

Sum of function pending times across all devices in units of 128 microseconds (doubleword format). The time lapse between the SSCH being issued and the acceptance of the first command of the channel program at the device.
"""

r7410diqt : Final[Field] = Field(
    name='r7410diqt',
    origin='R7410DIQT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Sum of IOP queue times across all devices in units of 128 microseconds (doubleword format). The amount of time the request is not accepted at the SCM resource because it would exceed its maximum capacity.

SMF Info
--------
    Field: `R7410DIQT`
    Record: `SMF74S10`
    Map: `R7410DI`

Sum of IOP queue times across all devices in units of 128 microseconds (doubleword format). The amount of time the request is not accepted at the SCM resource because it would exceed its maximum capacity.
"""
r7410diqt.__doc__ = """Sum of IOP queue times across all devices in units of 128 microseconds (doubleword format). The amount of time the request is not accepted at the SCM resource because it would exceed its maximum capacity.

SMF Info
--------
    Field: `R7410DIQT`
    Record: `SMF74S10`
    Map: `R7410DI`

Sum of IOP queue times across all devices in units of 128 microseconds (doubleword format). The amount of time the request is not accepted at the SCM resource because it would exceed its maximum capacity.
"""

r7410dcrt : Final[Field] = Field(
    name='r7410dcrt',
    origin='R7410DCRT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Sum of initial command response times across all devices in units of 128 microseconds (doubleword format). The time from when the first command does not immediately proceed to execute until the successful start of execution at the SCM resource part.

SMF Info
--------
    Field: `R7410DCRT`
    Record: `SMF74S10`
    Map: `R7410DI`

Sum of initial command response times across all devices in units of 128 microseconds (doubleword format). The time from when the first command does not immediately proceed to execute until the successful start of execution at the SCM resource part.
"""
r7410dcrt.__doc__ = """Sum of initial command response times across all devices in units of 128 microseconds (doubleword format). The time from when the first command does not immediately proceed to execute until the successful start of execution at the SCM resource part.

SMF Info
--------
    Field: `R7410DCRT`
    Record: `SMF74S10`
    Map: `R7410DI`

Sum of initial command response times across all devices in units of 128 microseconds (doubleword format). The time from when the first command does not immediately proceed to execute until the successful start of execution at the SCM resource part.
"""

r7410dflg : Final[Field] = Field(
    name='r7410dflg',
    origin='R7410DFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R7410DI,
)
"""Device information flags

SMF Info
--------
    Field: `R7410DFLG`
    Record: `SMF74S10`
    Map: `R7410DI`

Device information flags
"""
r7410dflg.__doc__ = """Device information flags

SMF Info
--------
    Field: `R7410DFLG`
    Record: `SMF74S10`
    Map: `R7410DI`

Device information flags
"""

r7410ecpr : Final[Field] = Field(
    name='r7410ecpr',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r7410dflg,
    record=record,
    record_map=R7410DI,
)
"""EADM-compression-measurements facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7410dflg`(`R7410DFLG`)
    Record: `SMF74S10`
    Map: `R7410DI`

EADM-compression-measurements facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r7410ecpr.__doc__ = """EADM-compression-measurements facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7410dflg`(`R7410DFLG`)
    Record: `SMF74S10`
    Map: `R7410DI`

EADM-compression-measurements facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r7410docc : Final[Field] = Field(
    name='r7410docc',
    origin='R7410DOCC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Number of compression operations

SMF Info
--------
    Field: `R7410DOCC`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of compression operations
"""
r7410docc.__doc__ = """Number of compression operations

SMF Info
--------
    Field: `R7410DOCC`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of compression operations
"""

r7410docd : Final[Field] = Field(
    name='r7410docd',
    origin='R7410DOCD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Number of decompression operations

SMF Info
--------
    Field: `R7410DOCD`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of decompression operations
"""
r7410docd.__doc__ = """Number of decompression operations

SMF Info
--------
    Field: `R7410DOCD`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of decompression operations
"""

r7410disc : Final[Field] = Field(
    name='r7410disc',
    origin='R7410DISC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Number of 1M input blocks consumed for compression

SMF Info
--------
    Field: `R7410DISC`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of 1M input blocks consumed for compression
"""
r7410disc.__doc__ = """Number of 1M input blocks consumed for compression

SMF Info
--------
    Field: `R7410DISC`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of 1M input blocks consumed for compression
"""

r7410dosc : Final[Field] = Field(
    name='r7410dosc',
    origin='R7410DOSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Number of 1M output blocks consumed for compression

SMF Info
--------
    Field: `R7410DOSC`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of 1M output blocks consumed for compression
"""
r7410dosc.__doc__ = """Number of 1M output blocks consumed for compression

SMF Info
--------
    Field: `R7410DOSC`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of 1M output blocks consumed for compression
"""

r7410disd : Final[Field] = Field(
    name='r7410disd',
    origin='R7410DISD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Number of 1M input blocks consumed for decompression

SMF Info
--------
    Field: `R7410DISD`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of 1M input blocks consumed for decompression
"""
r7410disd.__doc__ = """Number of 1M input blocks consumed for decompression

SMF Info
--------
    Field: `R7410DISD`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of 1M input blocks consumed for decompression
"""

r7410dosd : Final[Field] = Field(
    name='r7410dosd',
    origin='R7410DOSD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410DI,
)
"""Number of 1M output blocks consumed for decompression

SMF Info
--------
    Field: `R7410DOSD`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of 1M output blocks consumed for decompression
"""
r7410dosd.__doc__ = """Number of 1M output blocks consumed for decompression

SMF Info
--------
    Field: `R7410DOSD`
    Record: `SMF74S10`
    Map: `R7410DI`

Number of 1M output blocks consumed for decompression
"""

r7410crid : Final[Field] = Field(
    name='r7410crid',
    origin='R7410CRID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""SCM resource identifier

SMF Info
--------
    Field: `R7410CRID`
    Record: `SMF74S10`
    Map: `R7410CM`

SCM resource identifier
"""
r7410crid.__doc__ = """SCM resource identifier

SMF Info
--------
    Field: `R7410CRID`
    Record: `SMF74S10`
    Map: `R7410CM`

SCM resource identifier
"""

r7410cpid : Final[Field] = Field(
    name='r7410cpid',
    origin='R7410CPID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Part identifier

SMF Info
--------
    Field: `R7410CPID`
    Record: `SMF74S10`
    Map: `R7410CM`

Part identifier
"""
r7410cpid.__doc__ = """Part identifier

SMF Info
--------
    Field: `R7410CPID`
    Record: `SMF74S10`
    Map: `R7410CM`

Part identifier
"""

r7410cdus : Final[Field] = Field(
    name='r7410cdus',
    origin='R7410CDUS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Data unit size in bytes

SMF Info
--------
    Field: `R7410CDUS`
    Record: `SMF74S10`
    Map: `R7410CM`

Data unit size in bytes
"""
r7410cdus.__doc__ = """Data unit size in bytes

SMF Info
--------
    Field: `R7410CDUS`
    Record: `SMF74S10`
    Map: `R7410CM`

Data unit size in bytes
"""

r7410crqc : Final[Field] = Field(
    name='r7410crqc',
    origin='R7410CRQC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Internal requests processed at CPC level

SMF Info
--------
    Field: `R7410CRQC`
    Record: `SMF74S10`
    Map: `R7410CM`

Internal requests processed at CPC level
"""
r7410crqc.__doc__ = """Internal requests processed at CPC level

SMF Info
--------
    Field: `R7410CRQC`
    Record: `SMF74S10`
    Map: `R7410CM`

Internal requests processed at CPC level
"""

r7410crq : Final[Field] = Field(
    name='r7410crq',
    origin='R7410CRQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Internal requests processed at LPAR level

SMF Info
--------
    Field: `R7410CRQ`
    Record: `SMF74S10`
    Map: `R7410CM`

Internal requests processed at LPAR level
"""
r7410crq.__doc__ = """Internal requests processed at LPAR level

SMF Info
--------
    Field: `R7410CRQ`
    Record: `SMF74S10`
    Map: `R7410CM`

Internal requests processed at LPAR level
"""

r7410cdwc : Final[Field] = Field(
    name='r7410cdwc',
    origin='R7410CDWC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Data units written at CPC level

SMF Info
--------
    Field: `R7410CDWC`
    Record: `SMF74S10`
    Map: `R7410CM`

Data units written at CPC level
"""
r7410cdwc.__doc__ = """Data units written at CPC level

SMF Info
--------
    Field: `R7410CDWC`
    Record: `SMF74S10`
    Map: `R7410CM`

Data units written at CPC level
"""

r7410cdw : Final[Field] = Field(
    name='r7410cdw',
    origin='R7410CDW',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Data units written at LPAR level

SMF Info
--------
    Field: `R7410CDW`
    Record: `SMF74S10`
    Map: `R7410CM`

Data units written at LPAR level
"""
r7410cdw.__doc__ = """Data units written at LPAR level

SMF Info
--------
    Field: `R7410CDW`
    Record: `SMF74S10`
    Map: `R7410CM`

Data units written at LPAR level
"""

r7410cdrc : Final[Field] = Field(
    name='r7410cdrc',
    origin='R7410CDRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Data units read at CPC level

SMF Info
--------
    Field: `R7410CDRC`
    Record: `SMF74S10`
    Map: `R7410CM`

Data units read at CPC level
"""
r7410cdrc.__doc__ = """Data units read at CPC level

SMF Info
--------
    Field: `R7410CDRC`
    Record: `SMF74S10`
    Map: `R7410CM`

Data units read at CPC level
"""

r7410cdr : Final[Field] = Field(
    name='r7410cdr',
    origin='R7410CDR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Data units read at LPAR level

SMF Info
--------
    Field: `R7410CDR`
    Record: `SMF74S10`
    Map: `R7410CM`

Data units read at LPAR level
"""
r7410cdr.__doc__ = """Data units read at LPAR level

SMF Info
--------
    Field: `R7410CDR`
    Record: `SMF74S10`
    Map: `R7410CM`

Data units read at LPAR level
"""

r7410crtc : Final[Field] = Field(
    name='r7410crtc',
    origin='R7410CRTC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Aggregate time spent on execution of requests involving resource part in units of 128 microseconds at CPC level

SMF Info
--------
    Field: `R7410CRTC`
    Record: `SMF74S10`
    Map: `R7410CM`

Aggregate time spent on execution of requests involving resource part in units of 128 microseconds at CPC level
"""
r7410crtc.__doc__ = """Aggregate time spent on execution of requests involving resource part in units of 128 microseconds at CPC level

SMF Info
--------
    Field: `R7410CRTC`
    Record: `SMF74S10`
    Map: `R7410CM`

Aggregate time spent on execution of requests involving resource part in units of 128 microseconds at CPC level
"""

r7410crt : Final[Field] = Field(
    name='r7410crt',
    origin='R7410CRT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Aggregate time spent on execution of requests involving resource part in units of 128 microseconds at LPAR level

SMF Info
--------
    Field: `R7410CRT`
    Record: `SMF74S10`
    Map: `R7410CM`

Aggregate time spent on execution of requests involving resource part in units of 128 microseconds at LPAR level
"""
r7410crt.__doc__ = """Aggregate time spent on execution of requests involving resource part in units of 128 microseconds at LPAR level

SMF Info
--------
    Field: `R7410CRT`
    Record: `SMF74S10`
    Map: `R7410CM`

Aggregate time spent on execution of requests involving resource part in units of 128 microseconds at LPAR level
"""

r7410ciqc : Final[Field] = Field(
    name='r7410ciqc',
    origin='R7410CIQC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Accumulated IOP queue time in units of 128 microseconds at CPC level

SMF Info
--------
    Field: `R7410CIQC`
    Record: `SMF74S10`
    Map: `R7410CM`

Accumulated IOP queue time in units of 128 microseconds at CPC level
"""
r7410ciqc.__doc__ = """Accumulated IOP queue time in units of 128 microseconds at CPC level

SMF Info
--------
    Field: `R7410CIQC`
    Record: `SMF74S10`
    Map: `R7410CM`

Accumulated IOP queue time in units of 128 microseconds at CPC level
"""

r7410cwuc : Final[Field] = Field(
    name='r7410cwuc',
    origin='R7410CWUC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Utilization at CPC level. This value designates the sum of the average CPC utilization per second in percent multiplied by the number of seconds of this interval

SMF Info
--------
    Field: `R7410CWUC`
    Record: `SMF74S10`
    Map: `R7410CM`

Utilization at CPC level. This value designates the sum of the average CPC utilization per second in percent multiplied by the number of seconds of this interval
"""
r7410cwuc.__doc__ = """Utilization at CPC level. This value designates the sum of the average CPC utilization per second in percent multiplied by the number of seconds of this interval

SMF Info
--------
    Field: `R7410CWUC`
    Record: `SMF74S10`
    Map: `R7410CM`

Utilization at CPC level. This value designates the sum of the average CPC utilization per second in percent multiplied by the number of seconds of this interval
"""

r7410cwu : Final[Field] = Field(
    name='r7410cwu',
    origin='R7410CWU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7410CM,
)
"""Utilization at LPAR level. This value designates the sum of the average LPAR utilization per second in percent multiplied by the number of seconds of this interval

SMF Info
--------
    Field: `R7410CWU`
    Record: `SMF74S10`
    Map: `R7410CM`

Utilization at LPAR level. This value designates the sum of the average LPAR utilization per second in percent multiplied by the number of seconds of this interval
"""
r7410cwu.__doc__ = """Utilization at LPAR level. This value designates the sum of the average LPAR utilization per second in percent multiplied by the number of seconds of this interval

SMF Info
--------
    Field: `R7410CWU`
    Record: `SMF74S10`
    Map: `R7410CM`

Utilization at LPAR level. This value designates the sum of the average LPAR utilization per second in percent multiplied by the number of seconds of this interval
"""

r7410flg : Final[Field] = Field(
    name='r7410flg',
    origin='R7410FLG',
    type=FieldType.STRING,
    record=record,
    record_map=R7410CM,
)
"""Flag byte

SMF Info
--------
    Field: `R7410FLG`
    Record: `SMF74S10`
    Map: `R7410CM`

Flag byte
"""
r7410flg.__doc__ = """Flag byte

SMF Info
--------
    Field: `R7410FLG`
    Record: `SMF74S10`
    Map: `R7410CM`

Flag byte
"""

r7410vfm : Final[Field] = Field(
    name='r7410vfm',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r7410flg,
    record=record,
    record_map=R7410CM,
)
"""SCM resource type is VFM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7410flg`(`R7410FLG`)
    Record: `SMF74S10`
    Map: `R7410CM`

SCM resource type is VFM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r7410vfm.__doc__ = """SCM resource type is VFM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7410flg`(`R7410FLG`)
    Record: `SMF74S10`
    Map: `R7410CM`

SCM resource type is VFM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
