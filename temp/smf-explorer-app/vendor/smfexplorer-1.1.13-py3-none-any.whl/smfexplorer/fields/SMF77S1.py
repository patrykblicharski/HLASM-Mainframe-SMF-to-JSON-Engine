# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 77 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=77,
                                smf_subtype=1,
                                spec='SMF 77 Subtype 1',
                                post=None)
"""SMF 77 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF77PRO: Final[RecordMap] = RecordMap(
    origin='SMF77PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
SMF77CTL: Final[RecordMap] = RecordMap(
    origin='SMF77CTL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Enque Control Section',
    post=None,
    record_mapping=False)
"""Enque Control Section"""
SMF77ENQ: Final[RecordMap] = RecordMap(
    origin='SMF77ENQ',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Enqueue Data Section',
    post=None,
    record_mapping=False)
"""Enqueue Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF77DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF77DTE`
    Record: `SMF77S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF77DTE`
    Record: `SMF77S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF77TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF77TME`
    Record: `SMF77S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF77TME`
    Record: `SMF77S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF77DTE`), `time`(`SMF77TME`)
    Record: `SMF77S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF77DTE`), `time`(`SMF77TME`)
    Record: `SMF77S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF77LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF77LEN`
    Record: `SMF77S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF77LEN`
    Record: `SMF77S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF77SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF77SEG`
    Record: `SMF77S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF77SEG`
    Record: `SMF77S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF77FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF77FLG`
    Record: `SMF77S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF77FLG`
    Record: `SMF77S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF77FLG`)
    Record: `SMF77S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF77RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF77RTY`
    Record: `SMF77S1`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF77RTY`
    Record: `SMF77S1`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF77TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF77TME`
    Record: `SMF77S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF77TME`
    Record: `SMF77S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF77DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF77DTE`
    Record: `SMF77S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF77DTE`
    Record: `SMF77S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF77SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF77SID`
    Record: `SMF77S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF77SID`
    Record: `SMF77S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF77SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF77SSI`
    Record: `SMF77S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF77SSI`
    Record: `SMF77S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF77STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF77STY`
    Record: `SMF77S1`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF77STY`
    Record: `SMF77S1`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF77TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF77TRN`
    Record: `SMF77S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF77TRN`
    Record: `SMF77S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF77PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF77PRS`
    Record: `SMF77S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF77PRS`
    Record: `SMF77S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF77PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF77PRL`
    Record: `SMF77S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF77PRL`
    Record: `SMF77S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF77PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF77PRN`
    Record: `SMF77S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF77PRN`
    Record: `SMF77S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

eqs : Final[Field] = Field(
    name='eqs',
    origin='SMF77EQS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO ENQUEUE CONTROL SECTION

SMF Info
--------
    Field: `SMF77EQS`
    Record: `SMF77S1`
    Map: Not part of a map

OFFSET TO ENQUEUE CONTROL SECTION
"""
eqs.__doc__ = """OFFSET TO ENQUEUE CONTROL SECTION

SMF Info
--------
    Field: `SMF77EQS`
    Record: `SMF77S1`
    Map: Not part of a map

OFFSET TO ENQUEUE CONTROL SECTION
"""

eql : Final[Field] = Field(
    name='eql',
    origin='SMF77EQL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF ENQUEUE CONTROL SECTION

SMF Info
--------
    Field: `SMF77EQL`
    Record: `SMF77S1`
    Map: Not part of a map

LENGTH OF ENQUEUE CONTROL SECTION
"""
eql.__doc__ = """LENGTH OF ENQUEUE CONTROL SECTION

SMF Info
--------
    Field: `SMF77EQL`
    Record: `SMF77S1`
    Map: Not part of a map

LENGTH OF ENQUEUE CONTROL SECTION
"""

eqn : Final[Field] = Field(
    name='eqn',
    origin='SMF77EQN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF ENQUEUE CONTROL SECTIONS

SMF Info
--------
    Field: `SMF77EQN`
    Record: `SMF77S1`
    Map: Not part of a map

NUMBER OF ENQUEUE CONTROL SECTIONS
"""
eqn.__doc__ = """NUMBER OF ENQUEUE CONTROL SECTIONS

SMF Info
--------
    Field: `SMF77EQN`
    Record: `SMF77S1`
    Map: Not part of a map

NUMBER OF ENQUEUE CONTROL SECTIONS
"""

eds : Final[Field] = Field(
    name='eds',
    origin='SMF77EDS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO ENQUEUE DATA SECTION

SMF Info
--------
    Field: `SMF77EDS`
    Record: `SMF77S1`
    Map: Not part of a map

OFFSET TO ENQUEUE DATA SECTION
"""
eds.__doc__ = """OFFSET TO ENQUEUE DATA SECTION

SMF Info
--------
    Field: `SMF77EDS`
    Record: `SMF77S1`
    Map: Not part of a map

OFFSET TO ENQUEUE DATA SECTION
"""

edl : Final[Field] = Field(
    name='edl',
    origin='SMF77EDL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF ENQUEUE DATA SECTION

SMF Info
--------
    Field: `SMF77EDL`
    Record: `SMF77S1`
    Map: Not part of a map

LENGTH OF ENQUEUE DATA SECTION
"""
edl.__doc__ = """LENGTH OF ENQUEUE DATA SECTION

SMF Info
--------
    Field: `SMF77EDL`
    Record: `SMF77S1`
    Map: Not part of a map

LENGTH OF ENQUEUE DATA SECTION
"""

edn : Final[Field] = Field(
    name='edn',
    origin='SMF77EDN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF ENQUEUE DATA SECTIONS

SMF Info
--------
    Field: `SMF77EDN`
    Record: `SMF77S1`
    Map: Not part of a map

NUMBER OF ENQUEUE DATA SECTIONS
"""
edn.__doc__ = """NUMBER OF ENQUEUE DATA SECTIONS

SMF Info
--------
    Field: `SMF77EDN`
    Record: `SMF77S1`
    Map: Not part of a map

NUMBER OF ENQUEUE DATA SECTIONS
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF77MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF77MFV`
    Record: `SMF77S1`
    Map: `SMF77PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF77MFV`
    Record: `SMF77S1`
    Map: `SMF77PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF77PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF77PRD`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF77PRD`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF77IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF77PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF77IST`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF77IST`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF77DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF77PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF77DAT`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF77DAT`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF77INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF77PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF77INT`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF77INT`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF77SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF77SAM`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF77SAM`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF77FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF77FLA`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF77FLA`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

lower_service_level : Final[Field] = Field(
    name='lower_service_level',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
lower_service_level.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

higher_service_level : Final[Field] = Field(
    name='higher_service_level',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
higher_service_level.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF77PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF77FLA`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF77CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF77PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF77CYC`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF77CYC`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF77MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF77MVS`
    Record: `SMF77S1`
    Map: `SMF77PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF77MVS`
    Record: `SMF77S1`
    Map: `SMF77PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF77IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF77IML`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF77IML`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF77PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF77PRF`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF77PRF`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF77PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF77PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF77PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF77PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF77PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF77PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF77PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF77PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF77PRF`)
    Record: `SMF77S1`
    Map: `SMF77PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF77PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF77PTN`
    Record: `SMF77S1`
    Map: `SMF77PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF77PTN`
    Record: `SMF77S1`
    Map: `SMF77PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF77SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF77SRL`
    Record: `SMF77S1`
    Map: `SMF77PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF77SRL`
    Record: `SMF77S1`
    Map: `SMF77PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF77IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF77PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF77IET`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF77IET`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF77LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF77LGO`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF77LGO`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF77RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF77RAO`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF77RAO`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF77RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF77RAL`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF77RAL`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF77RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF77RAN`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF77RAN`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF77OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF77OIL`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF77OIL`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF77SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF77SYN`
    Record: `SMF77S1`
    Map: `SMF77PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF77SYN`
    Record: `SMF77S1`
    Map: `SMF77PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF77GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF77PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF77GIE`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF77GIE`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF77XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF77XNM`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF77XNM`
    Record: `SMF77S1`
    Map: `SMF77PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF77SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF77SNM`
    Record: `SMF77S1`
    Map: `SMF77PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF77SNM`
    Record: `SMF77S1`
    Map: `SMF77PRO`

System name for current system as defined in CVTSNAME
"""

fg1 : Final[Field] = Field(
    name='fg1',
    origin='SMF77FG1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77CTL,
)
"""ENQUEUE STATUS INDICATOR

SMF Info
--------
    Field: `SMF77FG1`
    Record: `SMF77S1`
    Map: `SMF77CTL`

ENQUEUE STATUS INDICATOR
"""
fg1.__doc__ = """ENQUEUE STATUS INDICATOR

SMF Info
--------
    Field: `SMF77FG1`
    Record: `SMF77S1`
    Map: `SMF77CTL`

ENQUEUE STATUS INDICATOR
"""

resource_no_contention : Final[Field] = Field(
    name='resource_no_contention',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fg1,
    record=record,
    record_map=SMF77CTL,
)
"""SPECIFIED RESOURCE HAD NO CONTENTION(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

SPECIFIED RESOURCE HAD NO CONTENTION

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
resource_no_contention.__doc__ = """SPECIFIED RESOURCE HAD NO CONTENTION(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

SPECIFIED RESOURCE HAD NO CONTENTION

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

enqueue_bad_cpu_clock : Final[Field] = Field(
    name='enqueue_bad_cpu_clock',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fg1,
    record=record,
    record_map=SMF77CTL,
)
"""ENQUEUE HAD BAD CPU CLOCK(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

ENQUEUE HAD BAD CPU CLOCK

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
enqueue_bad_cpu_clock.__doc__ = """ENQUEUE HAD BAD CPU CLOCK(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

ENQUEUE HAD BAD CPU CLOCK

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

enqueue_processing_abend : Final[Field] = Field(
    name='enqueue_processing_abend',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fg1,
    record=record,
    record_map=SMF77CTL,
)
"""ENQUEUE EVENT PROCESSING ABEND(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

ENQUEUE EVENT PROCESSING ABEND

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
enqueue_processing_abend.__doc__ = """ENQUEUE EVENT PROCESSING ABEND(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

ENQUEUE EVENT PROCESSING ABEND

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

detail_data_req : Final[Field] = Field(
    name='detail_data_req',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fg1,
    record=record,
    record_map=SMF77CTL,
)
"""DETAIL DATA REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

DETAIL DATA REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
detail_data_req.__doc__ = """DETAIL DATA REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

DETAIL DATA REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

grs_none : Final[Field] = Field(
    name='grs_none',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fg1,
    record=record,
    record_map=SMF77CTL,
)
"""GRS=NONE mode or local SYSPLEX if set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

GRS=NONE mode or local SYSPLEX if set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
grs_none.__doc__ = """GRS=NONE mode or local SYSPLEX if set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

GRS=NONE mode or local SYSPLEX if set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

grs_ring : Final[Field] = Field(
    name='grs_ring',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fg1,
    record=record,
    record_map=SMF77CTL,
)
"""GRS=RING, if not set and SMF77NON off(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

GRS=RING, if not set and SMF77NON off

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
grs_ring.__doc__ = """GRS=RING, if not set and SMF77NON off(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

GRS=RING, if not set and SMF77NON off

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

grs_mode : Final[Field] = Field(
    name='grs_mode',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=fg1,
    record=record,
    record_map=SMF77CTL,
)
"""GRS mode flags SMF77NON and SMF77STR are valid, if set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

GRS mode flags SMF77NON and SMF77STR are valid, if set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
grs_mode.__doc__ = """GRS mode flags SMF77NON and SMF77STR are valid, if set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg1`(`SMF77FG1`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

GRS mode flags SMF77NON and SMF77STR are valid, if set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rf2 : Final[Field] = Field(
    name='rf2',
    origin='SMF77RF2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77CTL,
)
"""Additional status flags

SMF Info
--------
    Field: `SMF77RF2`
    Record: `SMF77S1`
    Map: `SMF77CTL`

Additional status flags
"""
rf2.__doc__ = """Additional status flags

SMF Info
--------
    Field: `SMF77RF2`
    Record: `SMF77S1`
    Map: `SMF77CTL`

Additional status flags
"""

grs_sys_problem : Final[Field] = Field(
    name='grs_sys_problem',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=rf2,
    record=record,
    record_map=SMF77CTL,
)
"""GRS system problems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rf2`(`SMF77RF2`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

GRS system problems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
grs_sys_problem.__doc__ = """GRS system problems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rf2`(`SMF77RF2`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

GRS system problems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

grs_interface_problem : Final[Field] = Field(
    name='grs_interface_problem',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=rf2,
    record=record,
    record_map=SMF77CTL,
)
"""RMF/GRS interface problem(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rf2`(`SMF77RF2`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

RMF/GRS interface problem

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
grs_interface_problem.__doc__ = """RMF/GRS interface problem(V)

SMF Info (Virtual Field)
--------
    Field: Based on `rf2`(`SMF77RF2`)
    Record: `SMF77S1`
    Map: `SMF77CTL`

RMF/GRS interface problem

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

qnm : Final[Field] = Field(
    name='qnm',
    origin='SMF77QNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""RESOURCE MAJOR NAME

SMF Info
--------
    Field: `SMF77QNM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

RESOURCE MAJOR NAME
"""
qnm.__doc__ = """RESOURCE MAJOR NAME

SMF Info
--------
    Field: `SMF77QNM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

RESOURCE MAJOR NAME
"""

rnm : Final[Field] = Field(
    name='rnm',
    origin='SMF77RNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""RESOURCE MINOR NAME

SMF Info
--------
    Field: `SMF77RNM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

RESOURCE MINOR NAME
"""
rnm.__doc__ = """RESOURCE MINOR NAME

SMF Info
--------
    Field: `SMF77RNM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

RESOURCE MINOR NAME
"""

wtm : Final[Field] = Field(
    name='wtm',
    origin='SMF77WTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""RESOURCE MINIMUM WAITING TIME IN 1024 MICROSECOND UNIT

SMF Info
--------
    Field: `SMF77WTM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

RESOURCE MINIMUM WAITING TIME IN 1024 MICROSECOND UNIT
"""
wtm.__doc__ = """RESOURCE MINIMUM WAITING TIME IN 1024 MICROSECOND UNIT

SMF Info
--------
    Field: `SMF77WTM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

RESOURCE MINIMUM WAITING TIME IN 1024 MICROSECOND UNIT
"""

wtx : Final[Field] = Field(
    name='wtx',
    origin='SMF77WTX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""MAXIMUM WAITING TIME

SMF Info
--------
    Field: `SMF77WTX`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MAXIMUM WAITING TIME
"""
wtx.__doc__ = """MAXIMUM WAITING TIME

SMF Info
--------
    Field: `SMF77WTX`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MAXIMUM WAITING TIME
"""

wtt : Final[Field] = Field(
    name='wtt',
    origin='SMF77WTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""TOTAL WAITING TIME

SMF Info
--------
    Field: `SMF77WTT`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

TOTAL WAITING TIME
"""
wtt.__doc__ = """TOTAL WAITING TIME

SMF Info
--------
    Field: `SMF77WTT`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

TOTAL WAITING TIME
"""

ql1 : Final[Field] = Field(
    name='ql1',
    origin='SMF77QL1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""COUNTER FOR QUEUE LENGTH OF 1

SMF Info
--------
    Field: `SMF77QL1`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

COUNTER FOR QUEUE LENGTH OF 1
"""
ql1.__doc__ = """COUNTER FOR QUEUE LENGTH OF 1

SMF Info
--------
    Field: `SMF77QL1`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

COUNTER FOR QUEUE LENGTH OF 1
"""

ql2 : Final[Field] = Field(
    name='ql2',
    origin='SMF77QL2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""COUNTER FOR QUEUE LENGTH OF 2

SMF Info
--------
    Field: `SMF77QL2`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

COUNTER FOR QUEUE LENGTH OF 2
"""
ql2.__doc__ = """COUNTER FOR QUEUE LENGTH OF 2

SMF Info
--------
    Field: `SMF77QL2`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

COUNTER FOR QUEUE LENGTH OF 2
"""

ql3 : Final[Field] = Field(
    name='ql3',
    origin='SMF77QL3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""COUNTER FOR QUEUE LENGTH OF 3

SMF Info
--------
    Field: `SMF77QL3`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

COUNTER FOR QUEUE LENGTH OF 3
"""
ql3.__doc__ = """COUNTER FOR QUEUE LENGTH OF 3

SMF Info
--------
    Field: `SMF77QL3`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

COUNTER FOR QUEUE LENGTH OF 3
"""

ql4 : Final[Field] = Field(
    name='ql4',
    origin='SMF77QL4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""COUNTER FOR QUEUE LENGTH OF 4

SMF Info
--------
    Field: `SMF77QL4`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

COUNTER FOR QUEUE LENGTH OF 4
"""
ql4.__doc__ = """COUNTER FOR QUEUE LENGTH OF 4

SMF Info
--------
    Field: `SMF77QL4`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

COUNTER FOR QUEUE LENGTH OF 4
"""

exm : Final[Field] = Field(
    name='exm',
    origin='SMF77EXM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""MINIMUM NUMBER OF EXCLUSIVE REQUESTS

SMF Info
--------
    Field: `SMF77EXM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MINIMUM NUMBER OF EXCLUSIVE REQUESTS
"""
exm.__doc__ = """MINIMUM NUMBER OF EXCLUSIVE REQUESTS

SMF Info
--------
    Field: `SMF77EXM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MINIMUM NUMBER OF EXCLUSIVE REQUESTS
"""

exx : Final[Field] = Field(
    name='exx',
    origin='SMF77EXX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""MAXIMUM NUMBER OF EXCLUSIVE REQUESTS

SMF Info
--------
    Field: `SMF77EXX`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MAXIMUM NUMBER OF EXCLUSIVE REQUESTS
"""
exx.__doc__ = """MAXIMUM NUMBER OF EXCLUSIVE REQUESTS

SMF Info
--------
    Field: `SMF77EXX`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MAXIMUM NUMBER OF EXCLUSIVE REQUESTS
"""

shm : Final[Field] = Field(
    name='shm',
    origin='SMF77SHM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""MINIMUM NUMBER OF SHARE REQUESTS

SMF Info
--------
    Field: `SMF77SHM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MINIMUM NUMBER OF SHARE REQUESTS
"""
shm.__doc__ = """MINIMUM NUMBER OF SHARE REQUESTS

SMF Info
--------
    Field: `SMF77SHM`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MINIMUM NUMBER OF SHARE REQUESTS
"""

shx : Final[Field] = Field(
    name='shx',
    origin='SMF77SHX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""MAXIMUM NUMBER OF SHARE REQUESTS

SMF Info
--------
    Field: `SMF77SHX`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MAXIMUM NUMBER OF SHARE REQUESTS
"""
shx.__doc__ = """MAXIMUM NUMBER OF SHARE REQUESTS

SMF Info
--------
    Field: `SMF77SHX`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MAXIMUM NUMBER OF SHARE REQUESTS
"""

evt : Final[Field] = Field(
    name='evt',
    origin='SMF77EVT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""Total number of contention events that occurred during the measurement interval. A contention event is the period starting from the time when the resource has contention until the resource no longer has contention.

SMF Info
--------
    Field: `SMF77EVT`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

Total number of contention events that occurred during the measurement interval. A contention event is the period starting from the time when the resource has contention until the resource no longer has contention.
"""
evt.__doc__ = """Total number of contention events that occurred during the measurement interval. A contention event is the period starting from the time when the resource has contention until the resource no longer has contention.

SMF Info
--------
    Field: `SMF77EVT`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

Total number of contention events that occurred during the measurement interval. A contention event is the period starting from the time when the resource has contention until the resource no longer has contention.
"""

rln : Final[Field] = Field(
    name='rln',
    origin='SMF77RLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""MINOR NAME LENGTH

SMF Info
--------
    Field: `SMF77RLN`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MINOR NAME LENGTH
"""
rln.__doc__ = """MINOR NAME LENGTH

SMF Info
--------
    Field: `SMF77RLN`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

MINOR NAME LENGTH
"""

dfg : Final[Field] = Field(
    name='dfg',
    origin='SMF77DFG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""ENQ DETAIL DATA STATUS

SMF Info
--------
    Field: `SMF77DFG`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ENQ DETAIL DATA STATUS
"""
dfg.__doc__ = """ENQ DETAIL DATA STATUS

SMF Info
--------
    Field: `SMF77DFG`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ENQ DETAIL DATA STATUS
"""

resource_contention : Final[Field] = Field(
    name='resource_contention',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=dfg,
    record=record,
    record_map=SMF77ENQ,
)
"""RESOURCE IN CONTENTION(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

RESOURCE IN CONTENTION

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
resource_contention.__doc__ = """RESOURCE IN CONTENTION(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

RESOURCE IN CONTENTION

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

system_scope : Final[Field] = Field(
    name='system_scope',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=dfg,
    record=record,
    record_map=SMF77ENQ,
)
"""ON = SCOPE OF SYSTEMS OFF = SCOPE OF SYSTEM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = SCOPE OF SYSTEMS OFF = SCOPE OF SYSTEM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
system_scope.__doc__ = """ON = SCOPE OF SYSTEMS OFF = SCOPE OF SYSTEM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = SCOPE OF SYSTEMS OFF = SCOPE OF SYSTEM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

exclusive_owner : Final[Field] = Field(
    name='exclusive_owner',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=dfg,
    record=record,
    record_map=SMF77ENQ,
)
"""ON = EXCLUSIVE OWNER, OFF = OWNER SHARES RESOURCE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = EXCLUSIVE OWNER, OFF = OWNER SHARES RESOURCE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
exclusive_owner.__doc__ = """ON = EXCLUSIVE OWNER, OFF = OWNER SHARES RESOURCE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = EXCLUSIVE OWNER, OFF = OWNER SHARES RESOURCE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

job_wait_for_exc_usage : Final[Field] = Field(
    name='job_wait_for_exc_usage',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=dfg,
    record=record,
    record_map=SMF77ENQ,
)
"""ON = WAITING JOB 1 FOR EXCLUSIVE USAGE, OFF = WAITING JOB 1 FOR SHARED USE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = WAITING JOB 1 FOR EXCLUSIVE USAGE, OFF = WAITING JOB 1 FOR SHARED USE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
job_wait_for_exc_usage.__doc__ = """ON = WAITING JOB 1 FOR EXCLUSIVE USAGE, OFF = WAITING JOB 1 FOR SHARED USE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = WAITING JOB 1 FOR EXCLUSIVE USAGE, OFF = WAITING JOB 1 FOR SHARED USE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

job_wait_for_2exc_usage : Final[Field] = Field(
    name='job_wait_for_2exc_usage',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=dfg,
    record=record,
    record_map=SMF77ENQ,
)
"""ON = WAITING JOB 2 FOR EXCLUSIVE USAGE, OFF = WAITING JOB 2 FOR SHARED USE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = WAITING JOB 2 FOR EXCLUSIVE USAGE, OFF = WAITING JOB 2 FOR SHARED USE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
job_wait_for_2exc_usage.__doc__ = """ON = WAITING JOB 2 FOR EXCLUSIVE USAGE, OFF = WAITING JOB 2 FOR SHARED USE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = WAITING JOB 2 FOR EXCLUSIVE USAGE, OFF = WAITING JOB 2 FOR SHARED USE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

global_resource : Final[Field] = Field(
    name='global_resource',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=dfg,
    record=record,
    record_map=SMF77ENQ,
)
"""ON = GLOBAL RESOURCE, OFF = LOCAL RESOURCE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = GLOBAL RESOURCE, OFF = LOCAL RESOURCE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
global_resource.__doc__ = """ON = GLOBAL RESOURCE, OFF = LOCAL RESOURCE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dfg`(`SMF77DFG`)
    Record: `SMF77S1`
    Map: `SMF77ENQ`

ON = GLOBAL RESOURCE, OFF = LOCAL RESOURCE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

current_owner_number : Final[Field] = Field(
    name='current_owner_number',
    origin='SMF77DOW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""NUMBER OF CURRENT OWNER

SMF Info
--------
    Field: `SMF77DOW`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

NUMBER OF CURRENT OWNER
"""
current_owner_number.__doc__ = """NUMBER OF CURRENT OWNER

SMF Info
--------
    Field: `SMF77DOW`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

NUMBER OF CURRENT OWNER
"""

jobs_waiting : Final[Field] = Field(
    name='jobs_waiting',
    origin='SMF77DWR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""NUMBER OF WAITING JOBS

SMF Info
--------
    Field: `SMF77DWR`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

NUMBER OF WAITING JOBS
"""
jobs_waiting.__doc__ = """NUMBER OF WAITING JOBS

SMF Info
--------
    Field: `SMF77DWR`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

NUMBER OF WAITING JOBS
"""

resource_owner1 : Final[Field] = Field(
    name='resource_owner1',
    origin='SMF77DO1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""CURRENT RESOURCE OWNER 1

SMF Info
--------
    Field: `SMF77DO1`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

CURRENT RESOURCE OWNER 1
"""
resource_owner1.__doc__ = """CURRENT RESOURCE OWNER 1

SMF Info
--------
    Field: `SMF77DO1`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

CURRENT RESOURCE OWNER 1
"""

resource_owner2 : Final[Field] = Field(
    name='resource_owner2',
    origin='SMF77DO2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""CURRENT RESOURCE OWNER 2

SMF Info
--------
    Field: `SMF77DO2`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

CURRENT RESOURCE OWNER 2
"""
resource_owner2.__doc__ = """CURRENT RESOURCE OWNER 2

SMF Info
--------
    Field: `SMF77DO2`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

CURRENT RESOURCE OWNER 2
"""

resource_waiter1 : Final[Field] = Field(
    name='resource_waiter1',
    origin='SMF77DW1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""CURRENT RESOURCE WAITER 1

SMF Info
--------
    Field: `SMF77DW1`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

CURRENT RESOURCE WAITER 1
"""
resource_waiter1.__doc__ = """CURRENT RESOURCE WAITER 1

SMF Info
--------
    Field: `SMF77DW1`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

CURRENT RESOURCE WAITER 1
"""

resource_waiter2 : Final[Field] = Field(
    name='resource_waiter2',
    origin='SMF77DW2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""CURRENT RESOURCE WAITER 2

SMF Info
--------
    Field: `SMF77DW2`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

CURRENT RESOURCE WAITER 2
"""
resource_waiter2.__doc__ = """CURRENT RESOURCE WAITER 2

SMF Info
--------
    Field: `SMF77DW2`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

CURRENT RESOURCE WAITER 2
"""

sys_owner1 : Final[Field] = Field(
    name='sys_owner1',
    origin='SMF77SY1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""SYSTEM ID OF OWNER 1

SMF Info
--------
    Field: `SMF77SY1`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

SYSTEM ID OF OWNER 1
"""
sys_owner1.__doc__ = """SYSTEM ID OF OWNER 1

SMF Info
--------
    Field: `SMF77SY1`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

SYSTEM ID OF OWNER 1
"""

sys_owner2 : Final[Field] = Field(
    name='sys_owner2',
    origin='SMF77SY2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""SYSTEM ID OF OWNER 2

SMF Info
--------
    Field: `SMF77SY2`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

SYSTEM ID OF OWNER 2
"""
sys_owner2.__doc__ = """SYSTEM ID OF OWNER 2

SMF Info
--------
    Field: `SMF77SY2`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

SYSTEM ID OF OWNER 2
"""

sys_waiter1 : Final[Field] = Field(
    name='sys_waiter1',
    origin='SMF77SY3',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""SYSTEM ID OF WAITER 1

SMF Info
--------
    Field: `SMF77SY3`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

SYSTEM ID OF WAITER 1
"""
sys_waiter1.__doc__ = """SYSTEM ID OF WAITER 1

SMF Info
--------
    Field: `SMF77SY3`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

SYSTEM ID OF WAITER 1
"""

sys_waiter2 : Final[Field] = Field(
    name='sys_waiter2',
    origin='SMF77SY4',
    type=FieldType.STRING,
    record=record,
    record_map=SMF77ENQ,
)
"""SYSTEM ID OF WAITER 2

SMF Info
--------
    Field: `SMF77SY4`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

SYSTEM ID OF WAITER 2
"""
sys_waiter2.__doc__ = """SYSTEM ID OF WAITER 2

SMF Info
--------
    Field: `SMF77SY4`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

SYSTEM ID OF WAITER 2
"""

aql : Final[Field] = Field(
    name='aql',
    origin='SMF77AQL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""Accumulated Q length, same as SMF77QLT

SMF Info
--------
    Field: `SMF77AQL`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

Accumulated Q length, same as SMF77QLT
"""
aql.__doc__ = """Accumulated Q length, same as SMF77QLT

SMF Info
--------
    Field: `SMF77AQL`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

Accumulated Q length, same as SMF77QLT
"""

csc : Final[Field] = Field(
    name='csc',
    origin='SMF77CSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""Total number of contention status change events that occurred during the measurement interval.

SMF Info
--------
    Field: `SMF77CSC`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

Total number of contention status change events that occurred during the measurement interval.
"""
csc.__doc__ = """Total number of contention status change events that occurred during the measurement interval.

SMF Info
--------
    Field: `SMF77CSC`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

Total number of contention status change events that occurred during the measurement interval.
"""

nod : Final[Field] = Field(
    name='nod',
    origin='SMF77NOD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF77ENQ,
)
"""Total number of contention status change events, accumulated during the measurement interval which did not provide specific contention detail data.

SMF Info
--------
    Field: `SMF77NOD`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

Total number of contention status change events, accumulated during the measurement interval which did not provide specific contention detail data.
"""
nod.__doc__ = """Total number of contention status change events, accumulated during the measurement interval which did not provide specific contention detail data.

SMF Info
--------
    Field: `SMF77NOD`
    Record: `SMF77S1`
    Map: `SMF77ENQ`

Total number of contention status change events, accumulated during the measurement interval which did not provide specific contention detail data.
"""
