# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 79 Subtype 12"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=79,
                                smf_subtype=12,
                                spec='SMF 79 Subtype 12',
                                post=None)
"""SMF 79 Subtype 12"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF79PRO: Final[RecordMap] = RecordMap(
    origin='SMF79PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R79CHL: Final[RecordMap] = RecordMap(
    origin='R79CHL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Common record 79 header',
    post=None,
    record_mapping=False)
"""Common record 79 header"""
R79CCNTL: Final[RecordMap] = RecordMap(
    origin='R79CCNTL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Channel Path Control Section',
    post=None,
    record_mapping=False)
"""Channel Path Control Section"""
R79CCHNL: Final[RecordMap] = RecordMap(
    origin='R79CCHNL',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Channel Path Data Section',
    post=None,
    record_mapping=False)
"""Channel Path Data Section"""
R79CCM1: Final[RecordMap] = RecordMap(
    origin='R79CCM1',
    record=record,
    parent=R79CCHNL,
    is_multiple=False,
    is_compound=False,
    spec='Channel data Measurement group 1',
    post=None,
    record_mapping=False)
"""Channel data Measurement group 1"""
R79CCM2: Final[RecordMap] = RecordMap(
    origin='R79CCM2',
    record=record,
    parent=R79CCHNL,
    is_multiple=False,
    is_compound=False,
    spec='Channel Measurement group 2',
    post=None,
    record_mapping=False)
"""Channel Measurement group 2"""
R79CCM3: Final[RecordMap] = RecordMap(
    origin='R79CCM3',
    record=record,
    parent=R79CCHNL,
    is_multiple=False,
    is_compound=False,
    spec='Channel Measurement group 3',
    post=None,
    record_mapping=False)
"""Channel Measurement group 3"""
R79CXCM2: Final[RecordMap] = RecordMap(
    origin='R79CXCM2',
    record=record,
    parent=R79CCHNL,
    is_multiple=False,
    is_compound=False,
    spec='CPMF Extended channel measurement group 2 data',
    post=None,
    record_mapping=False)
"""CPMF Extended channel measurement group 2 data"""

date : Final[Field] = Field(
    name='date',
    origin='SMF79DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S12`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S12`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF79TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S12`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S12`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF79DTE`), `time`(`SMF79TME`)
    Record: `SMF79S12`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF79DTE`), `time`(`SMF79TME`)
    Record: `SMF79S12`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF79LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF79LEN`
    Record: `SMF79S12`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF79LEN`
    Record: `SMF79S12`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF79SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF79SEG`
    Record: `SMF79S12`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF79SEG`
    Record: `SMF79S12`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF79FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF79FLG`
    Record: `SMF79S12`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF79FLG`
    Record: `SMF79S12`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S12`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF79RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF79RTY`
    Record: `SMF79S12`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF79RTY`
    Record: `SMF79S12`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF79TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S12`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S12`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF79DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S12`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S12`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF79SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF79SID`
    Record: `SMF79S12`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF79SID`
    Record: `SMF79S12`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF79SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF79SSI`
    Record: `SMF79S12`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF79SSI`
    Record: `SMF79S12`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF79STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF79STY`
    Record: `SMF79S12`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF79STY`
    Record: `SMF79S12`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF79TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF79TRN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF79TRN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF79PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF79PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF79PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF79PRN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF79PRN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

mcs : Final[Field] = Field(
    name='mcs',
    origin='SMF79MCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET TO MONITOR II CONTROL SECTION
"""
mcs.__doc__ = """OFFSET TO MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET TO MONITOR II CONTROL SECTION
"""

mcl : Final[Field] = Field(
    name='mcl',
    origin='SMF79MCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH OF MONITOR II CONTROL SECTION
"""
mcl.__doc__ = """LENGTH OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH OF MONITOR II CONTROL SECTION
"""

mcn : Final[Field] = Field(
    name='mcn',
    origin='SMF79MCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF MONITOR II CONTROL SECTION
"""
mcn.__doc__ = """NUMBER OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF MONITOR II CONTROL SECTION
"""

ass : Final[Field] = Field(
    name='ass',
    origin='SMF79ASS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO DATA SECTION

SMF Info
--------
    Field: `SMF79ASS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET TO DATA SECTION
"""
ass.__doc__ = """OFFSET TO DATA SECTION

SMF Info
--------
    Field: `SMF79ASS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET TO DATA SECTION
"""

asl : Final[Field] = Field(
    name='asl',
    origin='SMF79ASL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""
asl.__doc__ = """LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""

asn : Final[Field] = Field(
    name='asn',
    origin='SMF79ASN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF DATA SECTION
"""
asn.__doc__ = """NUMBER OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF DATA SECTION
"""

dcs : Final[Field] = Field(
    name='dcs',
    origin='SMF79DCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET TO DATA CONTROL SECTION
"""
dcs.__doc__ = """OFFSET TO DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET TO DATA CONTROL SECTION
"""

dcl : Final[Field] = Field(
    name='dcl',
    origin='SMF79DCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH OF DATA CONTROL SECTION
"""
dcl.__doc__ = """LENGTH OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH OF DATA CONTROL SECTION
"""

dcn : Final[Field] = Field(
    name='dcn',
    origin='SMF79DCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF DATA CONTROL SECTION
"""
dcn.__doc__ = """NUMBER OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER OF DATA CONTROL SECTION
"""

qss : Final[Field] = Field(
    name='qss',
    origin='SMF79QSS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET IOQ GLOBAL SECTION
"""
qss.__doc__ = """OFFSET IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSS`
    Record: `SMF79S12`
    Map: Not part of a map

OFFSET IOQ GLOBAL SECTION
"""

qsl : Final[Field] = Field(
    name='qsl',
    origin='SMF79QSL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH IOQ GLOBAL SECTION
"""
qsl.__doc__ = """LENGTH IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSL`
    Record: `SMF79S12`
    Map: Not part of a map

LENGTH IOQ GLOBAL SECTION
"""

qsn : Final[Field] = Field(
    name='qsn',
    origin='SMF79QSN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER IOQ GLOBAL SECTION
"""
qsn.__doc__ = """NUMBER IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSN`
    Record: `SMF79S12`
    Map: Not part of a map

NUMBER IOQ GLOBAL SECTION
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF79MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF79MFV`
    Record: `SMF79S12`
    Map: `SMF79PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF79MFV`
    Record: `SMF79S12`
    Map: `SMF79PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF79PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF79PRD`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF79PRD`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF79IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF79PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF79IST`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF79IST`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF79DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF79PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF79DAT`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF79DAT`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF79INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF79PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF79INT`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF79INT`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF79SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF79SAM`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF79SAM`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF79FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF79FLA`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF79FLA`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF79CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF79PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF79CYC`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF79CYC`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF79MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF79MVS`
    Record: `SMF79S12`
    Map: `SMF79PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF79MVS`
    Record: `SMF79S12`
    Map: `SMF79PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF79IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF79IML`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF79IML`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF79PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF79PRF`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF79PRF`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S12`
    Map: `SMF79PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF79PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF79PTN`
    Record: `SMF79S12`
    Map: `SMF79PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF79PTN`
    Record: `SMF79S12`
    Map: `SMF79PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF79SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF79SRL`
    Record: `SMF79S12`
    Map: `SMF79PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF79SRL`
    Record: `SMF79S12`
    Map: `SMF79PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF79IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF79PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF79IET`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF79IET`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF79LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF79LGO`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF79LGO`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF79RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF79RAO`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF79RAO`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF79RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF79RAL`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF79RAL`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF79RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF79RAN`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF79RAN`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF79OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF79OIL`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF79OIL`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF79SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF79SYN`
    Record: `SMF79S12`
    Map: `SMF79PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF79SYN`
    Record: `SMF79S12`
    Map: `SMF79PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF79GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF79PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF79GIE`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF79GIE`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF79XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF79XNM`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF79XNM`
    Record: `SMF79S12`
    Map: `SMF79PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF79SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF79SNM`
    Record: `SMF79S12`
    Map: `SMF79PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF79SNM`
    Record: `SMF79S12`
    Map: `SMF79PRO`

System name for current system as defined in CVTSNAME
"""

r79gtod : Final[Field] = Field(
    name='r79gtod',
    origin='R79GTOD',
    type=FieldType.TIME,
    record=record,
    record_map=R79CHL,
)
"""Time when the call to data gatherer was issued

SMF Info
--------
    Field: `R79GTOD`
    Record: `SMF79S12`
    Map: `R79CHL`

Time when the call to data gatherer was issued
"""
r79gtod.__doc__ = """Time when the call to data gatherer was issued

SMF Info
--------
    Field: `R79GTOD`
    Record: `SMF79S12`
    Map: `R79CHL`

Time when the call to data gatherer was issued
"""

r79lf2 : Final[Field] = Field(
    name='r79lf2',
    origin='R79LF2',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Flag byte

SMF Info
--------
    Field: `R79LF2`
    Record: `SMF79S12`
    Map: `R79CHL`

Flag byte
"""
r79lf2.__doc__ = """Flag byte

SMF Info
--------
    Field: `R79LF2`
    Record: `SMF79S12`
    Map: `R79CHL`

Flag byte
"""

r79par : Final[Field] = Field(
    name='r79par',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Not enough relocate section to complete data gathering(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Not enough relocate section to complete data gathering

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r79par.__doc__ = """Not enough relocate section to complete data gathering(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Not enough relocate section to complete data gathering

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r79sg : Final[Field] = Field(
    name='r79sg',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Report sorted by SG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Report sorted by SG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79sg.__doc__ = """Report sorted by SG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Report sorted by SG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79rsm : Final[Field] = Field(
    name='r79rsm',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Invalid RSM data obtained(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Invalid RSM data obtained

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r79rsm.__doc__ = """Invalid RSM data obtained(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Invalid RSM data obtained

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r79goal : Final[Field] = Field(
    name='r79goal',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""System is in GOAL mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

System is in GOAL mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r79goal.__doc__ = """System is in GOAL mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

System is in GOAL mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r79trxi : Final[Field] = Field(
    name='r79trxi',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Invalid transaction data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Invalid transaction data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79trxi.__doc__ = """Invalid transaction data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Invalid transaction data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79srmc : Final[Field] = Field(
    name='r79srmc',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""SRM mode changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

SRM mode changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r79srmc.__doc__ = """SRM mode changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

SRM mode changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r79inv : Final[Field] = Field(
    name='r79inv',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""inval. data fr. Mon I (DEV PGSP IOQ)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

inval. data fr. Mon I (DEV PGSP IOQ)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r79inv.__doc__ = """inval. data fr. Mon I (DEV PGSP IOQ)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

inval. data fr. Mon I (DEV PGSP IOQ)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r79maxd : Final[Field] = Field(
    name='r79maxd',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Incomplete device data due to too many devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Incomplete device data due to too many devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r79maxd.__doc__ = """Incomplete device data due to too many devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S12`
    Map: `R79CHL`

Incomplete device data due to too many devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r79ses : Final[Field] = Field(
    name='r79ses',
    origin='R79SES',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Session name

SMF Info
--------
    Field: `R79SES`
    Record: `SMF79S12`
    Map: `R79CHL`

Session name
"""
r79ses.__doc__ = """Session name

SMF Info
--------
    Field: `R79SES`
    Record: `SMF79S12`
    Map: `R79CHL`

Session name
"""

r79user : Final[Field] = Field(
    name='r79user',
    origin='R79USER',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""User field

SMF Info
--------
    Field: `R79USER`
    Record: `SMF79S12`
    Map: `R79CHL`

User field
"""
r79user.__doc__ = """User field

SMF Info
--------
    Field: `R79USER`
    Record: `SMF79S12`
    Map: `R79CHL`

User field
"""

r79rid : Final[Field] = Field(
    name='r79rid',
    origin='R79RID',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Measurement name

SMF Info
--------
    Field: `R79RID`
    Record: `SMF79S12`
    Map: `R79CHL`

Measurement name
"""
r79rid.__doc__ = """Measurement name

SMF Info
--------
    Field: `R79RID`
    Record: `SMF79S12`
    Map: `R79CHL`

Measurement name
"""

r79ctxtl : Final[Field] = Field(
    name='r79ctxtl',
    origin='R79CTXTL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Length of command text

SMF Info
--------
    Field: `R79CTXTL`
    Record: `SMF79S12`
    Map: `R79CHL`

Length of command text
"""
r79ctxtl.__doc__ = """Length of command text

SMF Info
--------
    Field: `R79CTXTL`
    Record: `SMF79S12`
    Map: `R79CHL`

Length of command text
"""

r79ctext : Final[Field] = Field(
    name='r79ctext',
    origin='R79CTEXT',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Command text

SMF Info
--------
    Field: `R79CTEXT`
    Record: `SMF79S12`
    Map: `R79CHL`

Command text
"""
r79ctext.__doc__ = """Command text

SMF Info
--------
    Field: `R79CTEXT`
    Record: `SMF79S12`
    Map: `R79CHL`

Command text
"""

r79dtxtl : Final[Field] = Field(
    name='r79dtxtl',
    origin='R79DTXTL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Length default DR text

SMF Info
--------
    Field: `R79DTXTL`
    Record: `SMF79S12`
    Map: `R79CHL`

Length default DR text
"""
r79dtxtl.__doc__ = """Length default DR text

SMF Info
--------
    Field: `R79DTXTL`
    Record: `SMF79S12`
    Map: `R79CHL`

Length default DR text
"""

r79dtext : Final[Field] = Field(
    name='r79dtext',
    origin='R79DTEXT',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Default DR text

SMF Info
--------
    Field: `R79DTEXT`
    Record: `SMF79S12`
    Map: `R79CHL`

Default DR text
"""
r79dtext.__doc__ = """Default DR text

SMF Info
--------
    Field: `R79DTEXT`
    Record: `SMF79S12`
    Map: `R79CHL`

Default DR text
"""

r79ist : Final[Field] = Field(
    name='r79ist',
    origin='R79IST',
    type=FieldType.TIME,
    record=record,
    record_map=R79CHL,
)
"""Monitor I interval start time

SMF Info
--------
    Field: `R79IST`
    Record: `SMF79S12`
    Map: `R79CHL`

Monitor I interval start time
"""
r79ist.__doc__ = """Monitor I interval start time

SMF Info
--------
    Field: `R79IST`
    Record: `SMF79S12`
    Map: `R79CHL`

Monitor I interval start time
"""

r79tsr : Final[Field] = Field(
    name='r79tsr',
    origin='R79TSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Total number of small records

SMF Info
--------
    Field: `R79TSR`
    Record: `SMF79S12`
    Map: `R79CHL`

Total number of small records
"""
r79tsr.__doc__ = """Total number of small records

SMF Info
--------
    Field: `R79TSR`
    Record: `SMF79S12`
    Map: `R79CHL`

Total number of small records
"""

r79tot : Final[Field] = Field(
    name='r79tot',
    origin='R79TOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Total number of data sections in large record

SMF Info
--------
    Field: `R79TOT`
    Record: `SMF79S12`
    Map: `R79CHL`

Total number of data sections in large record
"""
r79tot.__doc__ = """Total number of data sections in large record

SMF Info
--------
    Field: `R79TOT`
    Record: `SMF79S12`
    Map: `R79CHL`

Total number of data sections in large record
"""

r79nxt : Final[Field] = Field(
    name='r79nxt',
    origin='R79NXT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Number of data sections in following small records

SMF Info
--------
    Field: `R79NXT`
    Record: `SMF79S12`
    Map: `R79CHL`

Number of data sections in following small records
"""
r79nxt.__doc__ = """Number of data sections in following small records

SMF Info
--------
    Field: `R79NXT`
    Record: `SMF79S12`
    Map: `R79CHL`

Number of data sections in following small records
"""

r79iwmtk : Final[Field] = Field(
    name='r79iwmtk',
    origin='R79IWMTK',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Token returned from IWMRCOLL service

SMF Info
--------
    Field: `R79IWMTK`
    Record: `SMF79S12`
    Map: `R79CHL`

Token returned from IWMRCOLL service
"""
r79iwmtk.__doc__ = """Token returned from IWMRCOLL service

SMF Info
--------
    Field: `R79IWMTK`
    Record: `SMF79S12`
    Map: `R79CHL`

Token returned from IWMRCOLL service
"""

r79csmp : Final[Field] = Field(
    name='r79csmp',
    origin='R79CSMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCNTL,
)
"""Number of samples weighted by SRM, only valid if R79CMCS = OFF

SMF Info
--------
    Field: `R79CSMP`
    Record: `SMF79S12`
    Map: `R79CCNTL`

Number of samples weighted by SRM, only valid if R79CMCS = OFF
"""
r79csmp.__doc__ = """Number of samples weighted by SRM, only valid if R79CMCS = OFF

SMF Info
--------
    Field: `R79CSMP`
    Record: `SMF79S12`
    Map: `R79CCNTL`

Number of samples weighted by SRM, only valid if R79CMCS = OFF
"""

r79cflg1 : Final[Field] = Field(
    name='r79cflg1',
    origin='R79CFLG1',
    type=FieldType.STRING,
    record=record,
    record_map=R79CCNTL,
)
"""Flags 1

SMF Info
--------
    Field: `R79CFLG1`
    Record: `SMF79S12`
    Map: `R79CCNTL`

Flags 1
"""
r79cflg1.__doc__ = """Flags 1

SMF Info
--------
    Field: `R79CFLG1`
    Record: `SMF79S12`
    Map: `R79CCNTL`

Flags 1
"""

r79ccpmf : Final[Field] = Field(
    name='r79ccpmf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r79cflg1,
    record=record,
    record_map=R79CCNTL,
)
"""CPMF available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

CPMF available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r79ccpmf.__doc__ = """CPMF available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

CPMF available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r79ccfgc : Final[Field] = Field(
    name='r79ccfgc',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79cflg1,
    record=record,
    record_map=R79CCNTL,
)
"""Configuration change(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

Configuration change

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79ccfgc.__doc__ = """Configuration change(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

Configuration change

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79ccmh : Final[Field] = Field(
    name='r79ccmh',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r79cflg1,
    record=record,
    record_map=R79CCNTL,
)
"""DCM supported by hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

DCM supported by hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r79ccmh.__doc__ = """DCM supported by hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

DCM supported by hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r79ccmd : Final[Field] = Field(
    name='r79ccmd',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r79cflg1,
    record=record,
    record_map=R79CCNTL,
)
"""Configuration contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

Configuration contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r79ccmd.__doc__ = """Configuration contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

Configuration contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r79crna : Final[Field] = Field(
    name='r79crna',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79cflg1,
    record=record,
    record_map=R79CCNTL,
)
"""RMF address space not active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

RMF address space not active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79crna.__doc__ = """RMF address space not active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

RMF address space not active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79cmcs : Final[Field] = Field(
    name='r79cmcs',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r79cflg1,
    record=record,
    record_map=R79CCNTL,
)
"""HW allows multiple channel subsystems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

HW allows multiple channel subsystems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r79cmcs.__doc__ = """HW allows multiple channel subsystems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

HW allows multiple channel subsystems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r79cecm : Final[Field] = Field(
    name='r79cecm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r79cflg1,
    record=record,
    record_map=R79CCNTL,
)
"""Enhanced channel measurement facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

Enhanced channel measurement facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r79cecm.__doc__ = """Enhanced channel measurement facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cflg1`(`R79CFLG1`)
    Record: `SMF79S12`
    Map: `R79CCNTL`

Enhanced channel measurement facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r79ccmi : Final[Field] = Field(
    name='r79ccmi',
    origin='R79CCMI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCNTL,
)
"""CPMF mode info 0 - CPMF not active 1 - Compatibility mode 2 - Extended mode

SMF Info
--------
    Field: `R79CCMI`
    Record: `SMF79S12`
    Map: `R79CCNTL`

CPMF mode info 0 - CPMF not active 1 - Compatibility mode 2 - Extended mode
"""
r79ccmi.__doc__ = """CPMF mode info 0 - CPMF not active 1 - Compatibility mode 2 - Extended mode

SMF Info
--------
    Field: `R79CCMI`
    Record: `SMF79S12`
    Map: `R79CCNTL`

CPMF mode info 0 - CPMF not active 1 - Compatibility mode 2 - Extended mode
"""

r79ccfrc : Final[Field] = Field(
    name='r79ccfrc',
    origin='R79CCFRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCNTL,
)
"""CPMF restart count

SMF Info
--------
    Field: `R79CCFRC`
    Record: `SMF79S12`
    Map: `R79CCNTL`

CPMF restart count
"""
r79ccfrc.__doc__ = """CPMF restart count

SMF Info
--------
    Field: `R79CCFRC`
    Record: `SMF79S12`
    Map: `R79CCNTL`

CPMF restart count
"""

r79ccfsc : Final[Field] = Field(
    name='r79ccfsc',
    origin='R79CCFSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCNTL,
)
"""CPMF sample count

SMF Info
--------
    Field: `R79CCFSC`
    Record: `SMF79S12`
    Map: `R79CCNTL`

CPMF sample count
"""
r79ccfsc.__doc__ = """CPMF sample count

SMF Info
--------
    Field: `R79CCFSC`
    Record: `SMF79S12`
    Map: `R79CCNTL`

CPMF sample count
"""

r79ccss : Final[Field] = Field(
    name='r79ccss',
    origin='R79CCSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCNTL,
)
"""Channel Subsystem Id, only valid if R79CMCS = ON

SMF Info
--------
    Field: `R79CCSS`
    Record: `SMF79S12`
    Map: `R79CCNTL`

Channel Subsystem Id, only valid if R79CMCS = ON
"""
r79ccss.__doc__ = """Channel Subsystem Id, only valid if R79CMCS = ON

SMF Info
--------
    Field: `R79CCSS`
    Record: `SMF79S12`
    Map: `R79CCNTL`

Channel Subsystem Id, only valid if R79CMCS = ON
"""

r79ccpid : Final[Field] = Field(
    name='r79ccpid',
    origin='R79CCPID',
    type=FieldType.STRING,
    record=record,
    record_map=R79CCHNL,
)
"""CHANNEL PATH IDENTIFICATIONS. THE RANGE OF VALUES IS X'00' TO X'FF'

SMF Info
--------
    Field: `R79CCPID`
    Record: `SMF79S12`
    Map: `R79CCHNL`

CHANNEL PATH IDENTIFICATIONS. THE RANGE OF VALUES IS X'00' TO X'FF'
"""
r79ccpid.__doc__ = """CHANNEL PATH IDENTIFICATIONS. THE RANGE OF VALUES IS X'00' TO X'FF'

SMF Info
--------
    Field: `R79CCPID`
    Record: `SMF79S12`
    Map: `R79CCHNL`

CHANNEL PATH IDENTIFICATIONS. THE RANGE OF VALUES IS X'00' TO X'FF'
"""

r79cfg2 : Final[Field] = Field(
    name='r79cfg2',
    origin='R79CFG2',
    type=FieldType.STRING,
    record=record,
    record_map=R79CCHNL,
)
"""CHANNEL FLAGS

SMF Info
--------
    Field: `R79CFG2`
    Record: `SMF79S12`
    Map: `R79CCHNL`

CHANNEL FLAGS
"""
r79cfg2.__doc__ = """CHANNEL FLAGS

SMF Info
--------
    Field: `R79CFG2`
    Record: `SMF79S12`
    Map: `R79CCHNL`

CHANNEL FLAGS
"""

r79cbl : Final[Field] = Field(
    name='r79cbl',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r79cfg2,
    record=record,
    record_map=R79CCHNL,
)
"""BLOCK MULTIPLEXOR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

BLOCK MULTIPLEXOR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r79cbl.__doc__ = """BLOCK MULTIPLEXOR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

BLOCK MULTIPLEXOR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r79cby : Final[Field] = Field(
    name='r79cby',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r79cfg2,
    record=record,
    record_map=R79CCHNL,
)
"""BYTE MULTIPLEXOR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

BYTE MULTIPLEXOR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r79cby.__doc__ = """BYTE MULTIPLEXOR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

BYTE MULTIPLEXOR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r79ccvc : Final[Field] = Field(
    name='r79ccvc',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79cfg2,
    record=record,
    record_map=R79CCHNL,
)
"""ES Conversion Channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

ES Conversion Channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79ccvc.__doc__ = """ES Conversion Channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

ES Conversion Channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79ccnc : Final[Field] = Field(
    name='r79ccnc',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r79cfg2,
    record=record,
    record_map=R79CCHNL,
)
"""ES Connection Channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

ES Connection Channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r79ccnc.__doc__ = """ES Connection Channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

ES Connection Channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r79cdoc : Final[Field] = Field(
    name='r79cdoc',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r79cfg2,
    record=record,
    record_map=R79CCHNL,
)
"""ESCON Director on Channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

ESCON Director on Channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r79cdoc.__doc__ = """ESCON Director on Channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

ESCON Director on Channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r79ccc : Final[Field] = Field(
    name='r79ccc',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r79cfg2,
    record=record,
    record_map=R79CCHNL,
)
"""Channel to Channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel to Channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r79ccc.__doc__ = """Channel to Channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg2`(`R79CFG2`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel to Channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r79cfg3 : Final[Field] = Field(
    name='r79cfg3',
    origin='R79CFG3',
    type=FieldType.STRING,
    record=record,
    record_map=R79CCHNL,
)
"""Channel flags continued

SMF Info
--------
    Field: `R79CFG3`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel flags continued
"""
r79cfg3.__doc__ = """Channel flags continued

SMF Info
--------
    Field: `R79CFG3`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel flags continued
"""

r79cshr : Final[Field] = Field(
    name='r79cshr',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r79cfg3,
    record=record,
    record_map=R79CCHNL,
)
"""Channel path is shared between logical partitions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel path is shared between logical partitions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r79cshr.__doc__ = """Channel path is shared between logical partitions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel path is shared between logical partitions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r79cnvl : Final[Field] = Field(
    name='r79cnvl',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79cfg3,
    record=record,
    record_map=R79CCHNL,
)
"""CPMF indication, this entry is invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF indication, this entry is invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79cnvl.__doc__ = """CPMF indication, this entry is invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF indication, this entry is invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79cfxt : Final[Field] = Field(
    name='r79cfxt',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r79cfg3,
    record=record,
    record_map=R79CCHNL,
)
"""Channel converter 3090(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel converter 3090

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r79cfxt.__doc__ = """Channel converter 3090(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel converter 3090

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r79ccpm : Final[Field] = Field(
    name='r79ccpm',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79cfg3,
    record=record,
    record_map=R79CCHNL,
)
"""Channel path is DCM managed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel path is DCM managed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79ccpm.__doc__ = """Channel path is DCM managed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel path is DCM managed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79ccdc : Final[Field] = Field(
    name='r79ccdc',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r79cfg3,
    record=record,
    record_map=R79CCHNL,
)
"""Channel characteristics changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel characteristics changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r79ccdc.__doc__ = """Channel characteristics changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel characteristics changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r79cxcm : Final[Field] = Field(
    name='r79cxcm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r79cfg3,
    record=record,
    record_map=R79CCHNL,
)
"""Extended channel measurements / supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Extended channel measurements / supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r79cxcm.__doc__ = """Extended channel measurements / supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg3`(`R79CFG3`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

Extended channel measurements / supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r79ccpd : Final[Field] = Field(
    name='r79ccpd',
    origin='R79CCPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCHNL,
)
"""Channel path description. For an explanation, you can issue the command D M=CHP.

SMF Info
--------
    Field: `R79CCPD`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel path description. For an explanation, you can issue the command D M=CHP.
"""
r79ccpd.__doc__ = """Channel path description. For an explanation, you can issue the command D M=CHP.

SMF Info
--------
    Field: `R79CCPD`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel path description. For an explanation, you can issue the command D M=CHP.
"""

r79cbsy : Final[Field] = Field(
    name='r79cbsy',
    origin='R79CBSY',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCHNL,
)
"""Number of samples the channel path was busy, weighted by SRM.

SMF Info
--------
    Field: `R79CBSY`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Number of samples the channel path was busy, weighted by SRM.
"""
r79cbsy.__doc__ = """Number of samples the channel path was busy, weighted by SRM.

SMF Info
--------
    Field: `R79CBSY`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Number of samples the channel path was busy, weighted by SRM.
"""

r79cpby : Final[Field] = Field(
    name='r79cpby',
    origin='R79CPBY',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCHNL,
)
"""Partitions channel-path-busy time in units of 128 micro seconds

SMF Info
--------
    Field: `R79CPBY`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Partitions channel-path-busy time in units of 128 micro seconds
"""
r79cpby.__doc__ = """Partitions channel-path-busy time in units of 128 micro seconds

SMF Info
--------
    Field: `R79CPBY`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Partitions channel-path-busy time in units of 128 micro seconds
"""

r79ccpts : Final[Field] = Field(
    name='r79ccpts',
    origin='R79CCPTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCHNL,
)
"""Last CPMB entry time stamp in units of 128 microseconds (be aware that this time value wraps about every 35.79 minutes)

SMF Info
--------
    Field: `R79CCPTS`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Last CPMB entry time stamp in units of 128 microseconds (be aware that this time value wraps about every 35.79 minutes)
"""
r79ccpts.__doc__ = """Last CPMB entry time stamp in units of 128 microseconds (be aware that this time value wraps about every 35.79 minutes)

SMF Info
--------
    Field: `R79CCPTS`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Last CPMB entry time stamp in units of 128 microseconds (be aware that this time value wraps about every 35.79 minutes)
"""

r79cacr : Final[Field] = Field(
    name='r79cacr',
    origin='R79CACR',
    type=FieldType.STRING,
    record=record,
    record_map=R79CCHNL,
)
"""Channel Path acronym

SMF Info
--------
    Field: `R79CACR`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel Path acronym
"""
r79cacr.__doc__ = """Channel Path acronym

SMF Info
--------
    Field: `R79CACR`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel Path acronym
"""

r79ccmg : Final[Field] = Field(
    name='r79ccmg',
    origin='R79CCMG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCHNL,
)
"""CPMF Channel Measurement Group

SMF Info
--------
    Field: `R79CCMG`
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel Measurement Group
"""
r79ccmg.__doc__ = """CPMF Channel Measurement Group

SMF Info
--------
    Field: `R79CCMG`
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel Measurement Group
"""

r79cfg4 : Final[Field] = Field(
    name='r79cfg4',
    origin='R79CFG4',
    type=FieldType.STRING,
    record=record,
    record_map=R79CCHNL,
)
"""Channel Path Flags

SMF Info
--------
    Field: `R79CFG4`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel Path Flags
"""
r79cfg4.__doc__ = """Channel Path Flags

SMF Info
--------
    Field: `R79CFG4`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel Path Flags
"""

r79cwd1 : Final[Field] = Field(
    name='r79cwd1',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r79cfg4,
    record=record,
    record_map=R79CCHNL,
)
"""CPMF Channel characteristics word 1 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 1 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r79cwd1.__doc__ = """CPMF Channel characteristics word 1 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 1 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r79cwd2 : Final[Field] = Field(
    name='r79cwd2',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79cfg4,
    record=record,
    record_map=R79CCHNL,
)
"""CPMF Channel characteristics word 2 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 2 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79cwd2.__doc__ = """CPMF Channel characteristics word 2 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 2 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79cwd3 : Final[Field] = Field(
    name='r79cwd3',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r79cfg4,
    record=record,
    record_map=R79CCHNL,
)
"""CPMF Channel characteristics word 3 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 3 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r79cwd3.__doc__ = """CPMF Channel characteristics word 3 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 3 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r79cwd4 : Final[Field] = Field(
    name='r79cwd4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r79cfg4,
    record=record,
    record_map=R79CCHNL,
)
"""CPMF Channel characteristics word 4 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 4 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r79cwd4.__doc__ = """CPMF Channel characteristics word 4 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 4 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r79cwd5 : Final[Field] = Field(
    name='r79cwd5',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79cfg4,
    record=record,
    record_map=R79CCHNL,
)
"""CPMF Channel characteristics word 5 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 5 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79cwd5.__doc__ = """CPMF Channel characteristics word 5 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79cfg4`(`R79CFG4`)
    Record: `SMF79S12`
    Map: `R79CCHNL`

CPMF Channel characteristics word 5 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79ccpp : Final[Field] = Field(
    name='r79ccpp',
    origin='R79CCPP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCHNL,
)
"""Channel path parameter

SMF Info
--------
    Field: `R79CCPP`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel path parameter
"""
r79ccpp.__doc__ = """Channel path parameter

SMF Info
--------
    Field: `R79CCPP`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel path parameter
"""

r79cgen : Final[Field] = Field(
    name='r79cgen',
    origin='R79CGEN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCHNL,
)
"""Channel type generation

SMF Info
--------
    Field: `R79CGEN`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel type generation
"""
r79cgen.__doc__ = """Channel type generation

SMF Info
--------
    Field: `R79CGEN`
    Record: `SMF79S12`
    Map: `R79CCHNL`

Channel type generation
"""

r79ctut : Final[Field] = Field(
    name='r79ctut',
    origin='R79CTUT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM1,
)
"""CPMF Total channel path busy Time in units of 128 microseconds

SMF Info
--------
    Field: `R79CTUT`
    Record: `SMF79S12`
    Map: `R79CCM1`

CPMF Total channel path busy Time in units of 128 microseconds
"""
r79ctut.__doc__ = """CPMF Total channel path busy Time in units of 128 microseconds

SMF Info
--------
    Field: `R79CTUT`
    Record: `SMF79S12`
    Map: `R79CCM1`

CPMF Total channel path busy Time in units of 128 microseconds
"""

r79cput : Final[Field] = Field(
    name='r79cput',
    origin='R79CPUT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM1,
)
"""CPMF LPAR channel path busy Time in units of 128 microseconds

SMF Info
--------
    Field: `R79CPUT`
    Record: `SMF79S12`
    Map: `R79CCM1`

CPMF LPAR channel path busy Time in units of 128 microseconds
"""
r79cput.__doc__ = """CPMF LPAR channel path busy Time in units of 128 microseconds

SMF Info
--------
    Field: `R79CPUT`
    Record: `SMF79S12`
    Map: `R79CCM1`

CPMF LPAR channel path busy Time in units of 128 microseconds
"""

r79cmbc : Final[Field] = Field(
    name='r79cmbc',
    origin='R79CMBC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF Maximum Bus Cycles per second (word 1)

SMF Info
--------
    Field: `R79CMBC`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Maximum Bus Cycles per second (word 1)
"""
r79cmbc.__doc__ = """CPMF Maximum Bus Cycles per second (word 1)

SMF Info
--------
    Field: `R79CMBC`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Maximum Bus Cycles per second (word 1)
"""

r79cmcu : Final[Field] = Field(
    name='r79cmcu',
    origin='R79CMCU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF Maximum Channel work Units per second (word 2)

SMF Info
--------
    Field: `R79CMCU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Maximum Channel work Units per second (word 2)
"""
r79cmcu.__doc__ = """CPMF Maximum Channel work Units per second (word 2)

SMF Info
--------
    Field: `R79CMCU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Maximum Channel work Units per second (word 2)
"""

r79cmwu : Final[Field] = Field(
    name='r79cmwu',
    origin='R79CMWU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF Maximum Write data Units per second (word 3)

SMF Info
--------
    Field: `R79CMWU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Maximum Write data Units per second (word 3)
"""
r79cmwu.__doc__ = """CPMF Maximum Write data Units per second (word 3)

SMF Info
--------
    Field: `R79CMWU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Maximum Write data Units per second (word 3)
"""

r79cmru : Final[Field] = Field(
    name='r79cmru',
    origin='R79CMRU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF Maximum Read data Units per second (word 4)

SMF Info
--------
    Field: `R79CMRU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Maximum Read data Units per second (word 4)
"""
r79cmru.__doc__ = """CPMF Maximum Read data Units per second (word 4)

SMF Info
--------
    Field: `R79CMRU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Maximum Read data Units per second (word 4)
"""

r79cus : Final[Field] = Field(
    name='r79cus',
    origin='R79CUS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF data Unit Size in bytes (word 5)

SMF Info
--------
    Field: `R79CUS`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF data Unit Size in bytes (word 5)
"""
r79cus.__doc__ = """CPMF data Unit Size in bytes (word 5)

SMF Info
--------
    Field: `R79CUS`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF data Unit Size in bytes (word 5)
"""

r79ctbc : Final[Field] = Field(
    name='r79ctbc',
    origin='R79CTBC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF Total Bus Cycles Count

SMF Info
--------
    Field: `R79CTBC`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Total Bus Cycles Count
"""
r79ctbc.__doc__ = """CPMF Total Bus Cycles Count

SMF Info
--------
    Field: `R79CTBC`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Total Bus Cycles Count
"""

r79ctuc : Final[Field] = Field(
    name='r79ctuc',
    origin='R79CTUC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF Total channel work Unit Count

SMF Info
--------
    Field: `R79CTUC`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Total channel work Unit Count
"""
r79ctuc.__doc__ = """CPMF Total channel work Unit Count

SMF Info
--------
    Field: `R79CTUC`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Total channel work Unit Count
"""

r79cpuc : Final[Field] = Field(
    name='r79cpuc',
    origin='R79CPUC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF LPAR channel work Unit Count

SMF Info
--------
    Field: `R79CPUC`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF LPAR channel work Unit Count
"""
r79cpuc.__doc__ = """CPMF LPAR channel work Unit Count

SMF Info
--------
    Field: `R79CPUC`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF LPAR channel work Unit Count
"""

r79ctwu : Final[Field] = Field(
    name='r79ctwu',
    origin='R79CTWU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF Total Write data Units

SMF Info
--------
    Field: `R79CTWU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Total Write data Units
"""
r79ctwu.__doc__ = """CPMF Total Write data Units

SMF Info
--------
    Field: `R79CTWU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Total Write data Units
"""

r79cpwu : Final[Field] = Field(
    name='r79cpwu',
    origin='R79CPWU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF LPAR Write data Units

SMF Info
--------
    Field: `R79CPWU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF LPAR Write data Units
"""
r79cpwu.__doc__ = """CPMF LPAR Write data Units

SMF Info
--------
    Field: `R79CPWU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF LPAR Write data Units
"""

r79ctru : Final[Field] = Field(
    name='r79ctru',
    origin='R79CTRU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF Total Read data Units

SMF Info
--------
    Field: `R79CTRU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Total Read data Units
"""
r79ctru.__doc__ = """CPMF Total Read data Units

SMF Info
--------
    Field: `R79CTRU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF Total Read data Units
"""

r79cpru : Final[Field] = Field(
    name='r79cpru',
    origin='R79CPRU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM2,
)
"""CPMF LPAR Read data Units

SMF Info
--------
    Field: `R79CPRU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF LPAR Read data Units
"""
r79cpru.__doc__ = """CPMF LPAR Read data Units

SMF Info
--------
    Field: `R79CPRU`
    Record: `SMF79S12`
    Map: `R79CCM2`

CPMF LPAR Read data Units
"""

r79cpdu : Final[Field] = Field(
    name='r79cpdu',
    origin='R79CPDU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF LPAR Data Unit size in bytes (word 1)

SMF Info
--------
    Field: `R79CPDU`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR Data Unit size in bytes (word 1)
"""
r79cpdu.__doc__ = """CPMF LPAR Data Unit size in bytes (word 1)

SMF Info
--------
    Field: `R79CPDU`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR Data Unit size in bytes (word 1)
"""

r79ctdu : Final[Field] = Field(
    name='r79ctdu',
    origin='R79CTDU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF Total Data Unit size in bytes (word 2)

SMF Info
--------
    Field: `R79CTDU`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total Data Unit size in bytes (word 2)
"""
r79ctdu.__doc__ = """CPMF Total Data Unit size in bytes (word 2)

SMF Info
--------
    Field: `R79CTDU`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total Data Unit size in bytes (word 2)
"""

r79cpum : Final[Field] = Field(
    name='r79cpum',
    origin='R79CPUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF LPAR Message sent Unit size (word 3)

SMF Info
--------
    Field: `R79CPUM`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR Message sent Unit size (word 3)
"""
r79cpum.__doc__ = """CPMF LPAR Message sent Unit size (word 3)

SMF Info
--------
    Field: `R79CPUM`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR Message sent Unit size (word 3)
"""

r79ctum : Final[Field] = Field(
    name='r79ctum',
    origin='R79CTUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF Total Message sent Unit size (word 4)

SMF Info
--------
    Field: `R79CTUM`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total Message sent Unit size (word 4)
"""
r79ctum.__doc__ = """CPMF Total Message sent Unit size (word 4)

SMF Info
--------
    Field: `R79CTUM`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total Message sent Unit size (word 4)
"""

r79cpms : Final[Field] = Field(
    name='r79cpms',
    origin='R79CPMS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF LPAR Message Sent units count

SMF Info
--------
    Field: `R79CPMS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR Message Sent units count
"""
r79cpms.__doc__ = """CPMF LPAR Message Sent units count

SMF Info
--------
    Field: `R79CPMS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR Message Sent units count
"""

r79ctms : Final[Field] = Field(
    name='r79ctms',
    origin='R79CTMS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF Total Message Sent units count

SMF Info
--------
    Field: `R79CTMS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total Message Sent units count
"""
r79ctms.__doc__ = """CPMF Total Message Sent units count

SMF Info
--------
    Field: `R79CTMS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total Message Sent units count
"""

r79cpus : Final[Field] = Field(
    name='r79cpus',
    origin='R79CPUS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF LPAR count of Unsuccessful attempts to Send messages

SMF Info
--------
    Field: `R79CPUS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR count of Unsuccessful attempts to Send messages
"""
r79cpus.__doc__ = """CPMF LPAR count of Unsuccessful attempts to Send messages

SMF Info
--------
    Field: `R79CPUS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR count of Unsuccessful attempts to Send messages
"""

r79cpub : Final[Field] = Field(
    name='r79cpub',
    origin='R79CPUB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF LPAR count of Unsuccessful attempts to receive messages due to unavailable Buffers

SMF Info
--------
    Field: `R79CPUB`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR count of Unsuccessful attempts to receive messages due to unavailable Buffers
"""
r79cpub.__doc__ = """CPMF LPAR count of Unsuccessful attempts to receive messages due to unavailable Buffers

SMF Info
--------
    Field: `R79CPUB`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR count of Unsuccessful attempts to receive messages due to unavailable Buffers
"""

r79ctub : Final[Field] = Field(
    name='r79ctub',
    origin='R79CTUB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF Total count of Unsuccessful attempts to receive messages due to unavailable Buffers

SMF Info
--------
    Field: `R79CTUB`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total count of Unsuccessful attempts to receive messages due to unavailable Buffers
"""
r79ctub.__doc__ = """CPMF Total count of Unsuccessful attempts to receive messages due to unavailable Buffers

SMF Info
--------
    Field: `R79CTUB`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total count of Unsuccessful attempts to receive messages due to unavailable Buffers
"""

r79cpds : Final[Field] = Field(
    name='r79cpds',
    origin='R79CPDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF LPAR Data units Sent count

SMF Info
--------
    Field: `R79CPDS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR Data units Sent count
"""
r79cpds.__doc__ = """CPMF LPAR Data units Sent count

SMF Info
--------
    Field: `R79CPDS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF LPAR Data units Sent count
"""

r79ctds : Final[Field] = Field(
    name='r79ctds',
    origin='R79CTDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CCM3,
)
"""CPMF Total Data units Sent count

SMF Info
--------
    Field: `R79CTDS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total Data units Sent count
"""
r79ctds.__doc__ = """CPMF Total Data units Sent count

SMF Info
--------
    Field: `R79CTDS`
    Record: `SMF79S12`
    Map: `R79CCM3`

CPMF Total Data units Sent count
"""

r79cxoc : Final[Field] = Field(
    name='r79cxoc',
    origin='R79CXOC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CXCM2,
)
"""Total number of FICON command mode operations (CPC) that have been attempted by the channel

SMF Info
--------
    Field: `R79CXOC`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Total number of FICON command mode operations (CPC) that have been attempted by the channel
"""
r79cxoc.__doc__ = """Total number of FICON command mode operations (CPC) that have been attempted by the channel

SMF Info
--------
    Field: `R79CXOC`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Total number of FICON command mode operations (CPC) that have been attempted by the channel
"""

r79cxod : Final[Field] = Field(
    name='r79cxod',
    origin='R79CXOD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CXCM2,
)
"""Total number of FICON command mode operations (CPC) that could not be initiated by the channel due to a lack of available resources

SMF Info
--------
    Field: `R79CXOD`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Total number of FICON command mode operations (CPC) that could not be initiated by the channel due to a lack of available resources
"""
r79cxod.__doc__ = """Total number of FICON command mode operations (CPC) that could not be initiated by the channel due to a lack of available resources

SMF Info
--------
    Field: `R79CXOD`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Total number of FICON command mode operations (CPC) that could not be initiated by the channel due to a lack of available resources
"""

r79cxos : Final[Field] = Field(
    name='r79cxos',
    origin='R79CXOS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CXCM2,
)
"""Summation count of FICON command-mode operations (CPC). Each time the number of FICON command-mode operations is incremented, the number of FICON command-mode operations active at the channel, including the one being initiated, is added to this field. (doubleword format)

SMF Info
--------
    Field: `R79CXOS`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Summation count of FICON command-mode operations (CPC). Each time the number of FICON command-mode operations is incremented, the number of FICON command-mode operations active at the channel, including the one being initiated, is added to this field. (doubleword format)
"""
r79cxos.__doc__ = """Summation count of FICON command-mode operations (CPC). Each time the number of FICON command-mode operations is incremented, the number of FICON command-mode operations active at the channel, including the one being initiated, is added to this field. (doubleword format)

SMF Info
--------
    Field: `R79CXOS`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Summation count of FICON command-mode operations (CPC). Each time the number of FICON command-mode operations is incremented, the number of FICON command-mode operations active at the channel, including the one being initiated, is added to this field. (doubleword format)
"""

r79cxtc : Final[Field] = Field(
    name='r79cxtc',
    origin='R79CXTC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CXCM2,
)
"""Total number of FICON transport mode operations (CPC) that have been attempted by the channel. Zero when no zHPF.

SMF Info
--------
    Field: `R79CXTC`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Total number of FICON transport mode operations (CPC) that have been attempted by the channel. Zero when no zHPF.
"""
r79cxtc.__doc__ = """Total number of FICON transport mode operations (CPC) that have been attempted by the channel. Zero when no zHPF.

SMF Info
--------
    Field: `R79CXTC`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Total number of FICON transport mode operations (CPC) that have been attempted by the channel. Zero when no zHPF.
"""

r79cxtd : Final[Field] = Field(
    name='r79cxtd',
    origin='R79CXTD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CXCM2,
)
"""Total number of FICON transport mode operations (CPC) that could not be initiated by the channel due to a lack of available resources. Zero when no zHPF.

SMF Info
--------
    Field: `R79CXTD`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Total number of FICON transport mode operations (CPC) that could not be initiated by the channel due to a lack of available resources. Zero when no zHPF.
"""
r79cxtd.__doc__ = """Total number of FICON transport mode operations (CPC) that could not be initiated by the channel due to a lack of available resources. Zero when no zHPF.

SMF Info
--------
    Field: `R79CXTD`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Total number of FICON transport mode operations (CPC) that could not be initiated by the channel due to a lack of available resources. Zero when no zHPF.
"""

r79cxts : Final[Field] = Field(
    name='r79cxts',
    origin='R79CXTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CXCM2,
)
"""Summation count of FICON transport-mode operations (CPC). Each time the number of FICON transport-mode operations is incremented, the number of transport-mode operations active at the channel, including the one being initiated, is added to this field. Zero when no zHPF. (doubleword format)

SMF Info
--------
    Field: `R79CXTS`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Summation count of FICON transport-mode operations (CPC). Each time the number of FICON transport-mode operations is incremented, the number of transport-mode operations active at the channel, including the one being initiated, is added to this field. Zero when no zHPF. (doubleword format)
"""
r79cxts.__doc__ = """Summation count of FICON transport-mode operations (CPC). Each time the number of FICON transport-mode operations is incremented, the number of transport-mode operations active at the channel, including the one being initiated, is added to this field. Zero when no zHPF. (doubleword format)

SMF Info
--------
    Field: `R79CXTS`
    Record: `SMF79S12`
    Map: `R79CXCM2`

Summation count of FICON transport-mode operations (CPC). Each time the number of FICON transport-mode operations is incremented, the number of transport-mode operations active at the channel, including the one being initiated, is added to this field. Zero when no zHPF. (doubleword format)
"""
