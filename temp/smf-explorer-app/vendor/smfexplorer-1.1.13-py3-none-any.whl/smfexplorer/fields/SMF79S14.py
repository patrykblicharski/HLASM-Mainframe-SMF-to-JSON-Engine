# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 79 Subtype 14"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=79,
                                smf_subtype=14,
                                spec='SMF 79 Subtype 14',
                                post=None)
"""SMF 79 Subtype 14"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF79PRO: Final[RecordMap] = RecordMap(
    origin='SMF79PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R79CHL: Final[RecordMap] = RecordMap(
    origin='R79CHL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Common record 79 header',
    post=None,
    record_mapping=False)
"""Common record 79 header"""
R79EGD: Final[RecordMap] = RecordMap(
    origin='R79EGD',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='GLBL.',
    post=None,
    record_mapping=False)
"""GLBL."""
R79ECS: Final[RecordMap] = RecordMap(
    origin='R79ECS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='CONFIGURATION CONTROL SECTION',
    post=None,
    record_mapping=False)
"""CONFIGURATION CONTROL SECTION"""
R79EDS: Final[RecordMap] = RecordMap(
    origin='R79EDS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='I/O QUEUING DATA SECTION',
    post=None,
    record_mapping=False)
"""I/O QUEUING DATA SECTION"""
R79ECPD: Final[RecordMap] = RecordMap(
    origin='R79ECPD',
    record=record,
    parent=R79ECS,
    is_multiple=True,
    is_compound=False,
    spec='CONFIGURATION DATA SECT.',
    post=None,
    record_mapping=False)
"""CONFIGURATION DATA SECT."""

date : Final[Field] = Field(
    name='date',
    origin='SMF79DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S14`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S14`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF79TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S14`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S14`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF79DTE`), `time`(`SMF79TME`)
    Record: `SMF79S14`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF79DTE`), `time`(`SMF79TME`)
    Record: `SMF79S14`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF79LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF79LEN`
    Record: `SMF79S14`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF79LEN`
    Record: `SMF79S14`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF79SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF79SEG`
    Record: `SMF79S14`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF79SEG`
    Record: `SMF79S14`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF79FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF79FLG`
    Record: `SMF79S14`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF79FLG`
    Record: `SMF79S14`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S14`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF79RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF79RTY`
    Record: `SMF79S14`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF79RTY`
    Record: `SMF79S14`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF79TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S14`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S14`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF79DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S14`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S14`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF79SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF79SID`
    Record: `SMF79S14`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF79SID`
    Record: `SMF79S14`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF79SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF79SSI`
    Record: `SMF79S14`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF79SSI`
    Record: `SMF79S14`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF79STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF79STY`
    Record: `SMF79S14`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF79STY`
    Record: `SMF79S14`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF79TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF79TRN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF79TRN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF79PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF79PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF79PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF79PRN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF79PRN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

mcs : Final[Field] = Field(
    name='mcs',
    origin='SMF79MCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET TO MONITOR II CONTROL SECTION
"""
mcs.__doc__ = """OFFSET TO MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET TO MONITOR II CONTROL SECTION
"""

mcl : Final[Field] = Field(
    name='mcl',
    origin='SMF79MCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH OF MONITOR II CONTROL SECTION
"""
mcl.__doc__ = """LENGTH OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH OF MONITOR II CONTROL SECTION
"""

mcn : Final[Field] = Field(
    name='mcn',
    origin='SMF79MCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF MONITOR II CONTROL SECTION
"""
mcn.__doc__ = """NUMBER OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF MONITOR II CONTROL SECTION
"""

ass : Final[Field] = Field(
    name='ass',
    origin='SMF79ASS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO DATA SECTION

SMF Info
--------
    Field: `SMF79ASS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET TO DATA SECTION
"""
ass.__doc__ = """OFFSET TO DATA SECTION

SMF Info
--------
    Field: `SMF79ASS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET TO DATA SECTION
"""

asl : Final[Field] = Field(
    name='asl',
    origin='SMF79ASL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""
asl.__doc__ = """LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""

asn : Final[Field] = Field(
    name='asn',
    origin='SMF79ASN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF DATA SECTION
"""
asn.__doc__ = """NUMBER OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF DATA SECTION
"""

dcs : Final[Field] = Field(
    name='dcs',
    origin='SMF79DCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET TO DATA CONTROL SECTION
"""
dcs.__doc__ = """OFFSET TO DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET TO DATA CONTROL SECTION
"""

dcl : Final[Field] = Field(
    name='dcl',
    origin='SMF79DCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH OF DATA CONTROL SECTION
"""
dcl.__doc__ = """LENGTH OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH OF DATA CONTROL SECTION
"""

dcn : Final[Field] = Field(
    name='dcn',
    origin='SMF79DCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF DATA CONTROL SECTION
"""
dcn.__doc__ = """NUMBER OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER OF DATA CONTROL SECTION
"""

qss : Final[Field] = Field(
    name='qss',
    origin='SMF79QSS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET IOQ GLOBAL SECTION
"""
qss.__doc__ = """OFFSET IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSS`
    Record: `SMF79S14`
    Map: Not part of a map

OFFSET IOQ GLOBAL SECTION
"""

qsl : Final[Field] = Field(
    name='qsl',
    origin='SMF79QSL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH IOQ GLOBAL SECTION
"""
qsl.__doc__ = """LENGTH IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSL`
    Record: `SMF79S14`
    Map: Not part of a map

LENGTH IOQ GLOBAL SECTION
"""

qsn : Final[Field] = Field(
    name='qsn',
    origin='SMF79QSN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER IOQ GLOBAL SECTION
"""
qsn.__doc__ = """NUMBER IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSN`
    Record: `SMF79S14`
    Map: Not part of a map

NUMBER IOQ GLOBAL SECTION
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF79MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF79MFV`
    Record: `SMF79S14`
    Map: `SMF79PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF79MFV`
    Record: `SMF79S14`
    Map: `SMF79PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF79PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF79PRD`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF79PRD`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF79IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF79PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF79IST`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF79IST`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF79DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF79PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF79DAT`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF79DAT`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF79INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF79PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF79INT`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF79INT`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF79SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF79SAM`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF79SAM`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF79FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF79FLA`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF79FLA`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF79CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF79PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF79CYC`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF79CYC`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF79MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF79MVS`
    Record: `SMF79S14`
    Map: `SMF79PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF79MVS`
    Record: `SMF79S14`
    Map: `SMF79PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF79IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF79IML`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF79IML`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF79PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF79PRF`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF79PRF`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S14`
    Map: `SMF79PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF79PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF79PTN`
    Record: `SMF79S14`
    Map: `SMF79PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF79PTN`
    Record: `SMF79S14`
    Map: `SMF79PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF79SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF79SRL`
    Record: `SMF79S14`
    Map: `SMF79PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF79SRL`
    Record: `SMF79S14`
    Map: `SMF79PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF79IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF79PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF79IET`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF79IET`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF79LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF79LGO`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF79LGO`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF79RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF79RAO`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF79RAO`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF79RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF79RAL`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF79RAL`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF79RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF79RAN`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF79RAN`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF79OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF79OIL`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF79OIL`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF79SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF79SYN`
    Record: `SMF79S14`
    Map: `SMF79PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF79SYN`
    Record: `SMF79S14`
    Map: `SMF79PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF79GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF79PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF79GIE`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF79GIE`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF79XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF79XNM`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF79XNM`
    Record: `SMF79S14`
    Map: `SMF79PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF79SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF79SNM`
    Record: `SMF79S14`
    Map: `SMF79PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF79SNM`
    Record: `SMF79S14`
    Map: `SMF79PRO`

System name for current system as defined in CVTSNAME
"""

r79gtod : Final[Field] = Field(
    name='r79gtod',
    origin='R79GTOD',
    type=FieldType.TIME,
    record=record,
    record_map=R79CHL,
)
"""Time when the call to data gatherer was issued

SMF Info
--------
    Field: `R79GTOD`
    Record: `SMF79S14`
    Map: `R79CHL`

Time when the call to data gatherer was issued
"""
r79gtod.__doc__ = """Time when the call to data gatherer was issued

SMF Info
--------
    Field: `R79GTOD`
    Record: `SMF79S14`
    Map: `R79CHL`

Time when the call to data gatherer was issued
"""

r79lf2 : Final[Field] = Field(
    name='r79lf2',
    origin='R79LF2',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Flag byte

SMF Info
--------
    Field: `R79LF2`
    Record: `SMF79S14`
    Map: `R79CHL`

Flag byte
"""
r79lf2.__doc__ = """Flag byte

SMF Info
--------
    Field: `R79LF2`
    Record: `SMF79S14`
    Map: `R79CHL`

Flag byte
"""

r79par : Final[Field] = Field(
    name='r79par',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Not enough relocate section to complete data gathering(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Not enough relocate section to complete data gathering

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r79par.__doc__ = """Not enough relocate section to complete data gathering(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Not enough relocate section to complete data gathering

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r79sg : Final[Field] = Field(
    name='r79sg',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Report sorted by SG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Report sorted by SG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79sg.__doc__ = """Report sorted by SG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Report sorted by SG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79rsm : Final[Field] = Field(
    name='r79rsm',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Invalid RSM data obtained(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Invalid RSM data obtained

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r79rsm.__doc__ = """Invalid RSM data obtained(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Invalid RSM data obtained

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r79goal : Final[Field] = Field(
    name='r79goal',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""System is in GOAL mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

System is in GOAL mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r79goal.__doc__ = """System is in GOAL mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

System is in GOAL mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r79trxi : Final[Field] = Field(
    name='r79trxi',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Invalid transaction data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Invalid transaction data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79trxi.__doc__ = """Invalid transaction data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Invalid transaction data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79srmc : Final[Field] = Field(
    name='r79srmc',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""SRM mode changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

SRM mode changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r79srmc.__doc__ = """SRM mode changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

SRM mode changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r79inv : Final[Field] = Field(
    name='r79inv',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""inval. data fr. Mon I (DEV PGSP IOQ)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

inval. data fr. Mon I (DEV PGSP IOQ)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r79inv.__doc__ = """inval. data fr. Mon I (DEV PGSP IOQ)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

inval. data fr. Mon I (DEV PGSP IOQ)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r79maxd : Final[Field] = Field(
    name='r79maxd',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Incomplete device data due to too many devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Incomplete device data due to too many devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r79maxd.__doc__ = """Incomplete device data due to too many devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S14`
    Map: `R79CHL`

Incomplete device data due to too many devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r79ses : Final[Field] = Field(
    name='r79ses',
    origin='R79SES',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Session name

SMF Info
--------
    Field: `R79SES`
    Record: `SMF79S14`
    Map: `R79CHL`

Session name
"""
r79ses.__doc__ = """Session name

SMF Info
--------
    Field: `R79SES`
    Record: `SMF79S14`
    Map: `R79CHL`

Session name
"""

r79user : Final[Field] = Field(
    name='r79user',
    origin='R79USER',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""User field

SMF Info
--------
    Field: `R79USER`
    Record: `SMF79S14`
    Map: `R79CHL`

User field
"""
r79user.__doc__ = """User field

SMF Info
--------
    Field: `R79USER`
    Record: `SMF79S14`
    Map: `R79CHL`

User field
"""

r79rid : Final[Field] = Field(
    name='r79rid',
    origin='R79RID',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Measurement name

SMF Info
--------
    Field: `R79RID`
    Record: `SMF79S14`
    Map: `R79CHL`

Measurement name
"""
r79rid.__doc__ = """Measurement name

SMF Info
--------
    Field: `R79RID`
    Record: `SMF79S14`
    Map: `R79CHL`

Measurement name
"""

r79ctxtl : Final[Field] = Field(
    name='r79ctxtl',
    origin='R79CTXTL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Length of command text

SMF Info
--------
    Field: `R79CTXTL`
    Record: `SMF79S14`
    Map: `R79CHL`

Length of command text
"""
r79ctxtl.__doc__ = """Length of command text

SMF Info
--------
    Field: `R79CTXTL`
    Record: `SMF79S14`
    Map: `R79CHL`

Length of command text
"""

r79ctext : Final[Field] = Field(
    name='r79ctext',
    origin='R79CTEXT',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Command text

SMF Info
--------
    Field: `R79CTEXT`
    Record: `SMF79S14`
    Map: `R79CHL`

Command text
"""
r79ctext.__doc__ = """Command text

SMF Info
--------
    Field: `R79CTEXT`
    Record: `SMF79S14`
    Map: `R79CHL`

Command text
"""

r79dtxtl : Final[Field] = Field(
    name='r79dtxtl',
    origin='R79DTXTL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Length default DR text

SMF Info
--------
    Field: `R79DTXTL`
    Record: `SMF79S14`
    Map: `R79CHL`

Length default DR text
"""
r79dtxtl.__doc__ = """Length default DR text

SMF Info
--------
    Field: `R79DTXTL`
    Record: `SMF79S14`
    Map: `R79CHL`

Length default DR text
"""

r79dtext : Final[Field] = Field(
    name='r79dtext',
    origin='R79DTEXT',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Default DR text

SMF Info
--------
    Field: `R79DTEXT`
    Record: `SMF79S14`
    Map: `R79CHL`

Default DR text
"""
r79dtext.__doc__ = """Default DR text

SMF Info
--------
    Field: `R79DTEXT`
    Record: `SMF79S14`
    Map: `R79CHL`

Default DR text
"""

r79ist : Final[Field] = Field(
    name='r79ist',
    origin='R79IST',
    type=FieldType.TIME,
    record=record,
    record_map=R79CHL,
)
"""Monitor I interval start time

SMF Info
--------
    Field: `R79IST`
    Record: `SMF79S14`
    Map: `R79CHL`

Monitor I interval start time
"""
r79ist.__doc__ = """Monitor I interval start time

SMF Info
--------
    Field: `R79IST`
    Record: `SMF79S14`
    Map: `R79CHL`

Monitor I interval start time
"""

r79tsr : Final[Field] = Field(
    name='r79tsr',
    origin='R79TSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Total number of small records

SMF Info
--------
    Field: `R79TSR`
    Record: `SMF79S14`
    Map: `R79CHL`

Total number of small records
"""
r79tsr.__doc__ = """Total number of small records

SMF Info
--------
    Field: `R79TSR`
    Record: `SMF79S14`
    Map: `R79CHL`

Total number of small records
"""

r79tot : Final[Field] = Field(
    name='r79tot',
    origin='R79TOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Total number of data sections in large record

SMF Info
--------
    Field: `R79TOT`
    Record: `SMF79S14`
    Map: `R79CHL`

Total number of data sections in large record
"""
r79tot.__doc__ = """Total number of data sections in large record

SMF Info
--------
    Field: `R79TOT`
    Record: `SMF79S14`
    Map: `R79CHL`

Total number of data sections in large record
"""

r79nxt : Final[Field] = Field(
    name='r79nxt',
    origin='R79NXT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Number of data sections in following small records

SMF Info
--------
    Field: `R79NXT`
    Record: `SMF79S14`
    Map: `R79CHL`

Number of data sections in following small records
"""
r79nxt.__doc__ = """Number of data sections in following small records

SMF Info
--------
    Field: `R79NXT`
    Record: `SMF79S14`
    Map: `R79CHL`

Number of data sections in following small records
"""

r79iwmtk : Final[Field] = Field(
    name='r79iwmtk',
    origin='R79IWMTK',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Token returned from IWMRCOLL service

SMF Info
--------
    Field: `R79IWMTK`
    Record: `SMF79S14`
    Map: `R79CHL`

Token returned from IWMRCOLL service
"""
r79iwmtk.__doc__ = """Token returned from IWMRCOLL service

SMF Info
--------
    Field: `R79IWMTK`
    Record: `SMF79S14`
    Map: `R79CHL`

Token returned from IWMRCOLL service
"""

r79egflg : Final[Field] = Field(
    name='r79egflg',
    origin='R79EGFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R79EGD,
)
"""GLOBAL IOQ STATUS

SMF Info
--------
    Field: `R79EGFLG`
    Record: `SMF79S14`
    Map: `R79EGD`

GLOBAL IOQ STATUS
"""
r79egflg.__doc__ = """GLOBAL IOQ STATUS

SMF Info
--------
    Field: `R79EGFLG`
    Record: `SMF79S14`
    Map: `R79EGD`

GLOBAL IOQ STATUS
"""

r79egcmf : Final[Field] = Field(
    name='r79egcmf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r79egflg,
    record=record,
    record_map=R79EGD,
)
"""=1 DATA IS INVALID DUE TO FAILURE OF THE CHANNEL MESUREMENT FACILITY(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 DATA IS INVALID DUE TO FAILURE OF THE CHANNEL MESUREMENT FACILITY

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r79egcmf.__doc__ = """=1 DATA IS INVALID DUE TO FAILURE OF THE CHANNEL MESUREMENT FACILITY(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 DATA IS INVALID DUE TO FAILURE OF THE CHANNEL MESUREMENT FACILITY

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r79egdif : Final[Field] = Field(
    name='r79egdif',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79egflg,
    record=record,
    record_map=R79EGD,
)
"""=1 DIAGNOSE INTERFACE FAILURE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 DIAGNOSE INTERFACE FAILURE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79egdif.__doc__ = """=1 DIAGNOSE INTERFACE FAILURE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 DIAGNOSE INTERFACE FAILURE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79egdir : Final[Field] = Field(
    name='r79egdir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r79egflg,
    record=record,
    record_map=R79EGD,
)
"""=1 ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r79egdir.__doc__ = """=1 ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r79egssq : Final[Field] = Field(
    name='r79egssq',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r79egflg,
    record=record,
    record_map=R79EGD,
)
"""=1 CHSC store secondary queue data not supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 CHSC store secondary queue data not supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r79egssq.__doc__ = """=1 CHSC store secondary queue data not supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 CHSC store secondary queue data not supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r79egcmh : Final[Field] = Field(
    name='r79egcmh',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79egflg,
    record=record,
    record_map=R79EGD,
)
"""=1 DCM is supported by hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 DCM is supported by hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79egcmh.__doc__ = """=1 DCM is supported by hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 DCM is supported by hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79egcmd : Final[Field] = Field(
    name='r79egcmd',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r79egflg,
    record=record,
    record_map=R79EGD,
)
"""=1 Configuration contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 Configuration contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r79egcmd.__doc__ = """=1 Configuration contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 Configuration contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r79egcmr : Final[Field] = Field(
    name='r79egcmr',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r79egflg,
    record=record,
    record_map=R79EGD,
)
"""=1 initial-command-response time supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 initial-command-response time supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r79egcmr.__doc__ = """=1 initial-command-response time supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

=1 initial-command-response time supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r79egtrd : Final[Field] = Field(
    name='r79egtrd',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r79egflg,
    record=record,
    record_map=R79EGD,
)
"""First-transfer-ready disabled write data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

First-transfer-ready disabled write data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r79egtrd.__doc__ = """First-transfer-ready disabled write data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79egflg`(`R79EGFLG`)
    Record: `SMF79S14`
    Map: `R79EGD`

First-transfer-ready disabled write data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r79egsmp : Final[Field] = Field(
    name='r79egsmp',
    origin='R79EGSMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EGD,
)
"""Number of samples for store secondary queue measurement data

SMF Info
--------
    Field: `R79EGSMP`
    Record: `SMF79S14`
    Map: `R79EGD`

Number of samples for store secondary queue measurement data
"""
r79egsmp.__doc__ = """Number of samples for store secondary queue measurement data

SMF Info
--------
    Field: `R79EGSMP`
    Record: `SMF79S14`
    Map: `R79EGD`

Number of samples for store secondary queue measurement data
"""

r79eid1 : Final[Field] = Field(
    name='r79eid1',
    origin='R79EID1',
    type=FieldType.STRING,
    record=record,
    record_map=R79ECS,
)
"""LOGICAL CONTROL UNIT IDENTIFIER

SMF Info
--------
    Field: `R79EID1`
    Record: `SMF79S14`
    Map: `R79ECS`

LOGICAL CONTROL UNIT IDENTIFIER
"""
r79eid1.__doc__ = """LOGICAL CONTROL UNIT IDENTIFIER

SMF Info
--------
    Field: `R79EID1`
    Record: `SMF79S14`
    Map: `R79ECS`

LOGICAL CONTROL UNIT IDENTIFIER
"""

r79entr : Final[Field] = Field(
    name='r79entr',
    origin='R79ENTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECS,
)
"""NUMBER OF DESCRIPTOR TRIPLETS

SMF Info
--------
    Field: `R79ENTR`
    Record: `SMF79S14`
    Map: `R79ECS`

NUMBER OF DESCRIPTOR TRIPLETS
"""
r79entr.__doc__ = """NUMBER OF DESCRIPTOR TRIPLETS

SMF Info
--------
    Field: `R79ENTR`
    Record: `SMF79S14`
    Map: `R79ECS`

NUMBER OF DESCRIPTOR TRIPLETS
"""

r79ecpds : Final[Field] = Field(
    name='r79ecpds',
    origin='R79ECPDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECS,
)
"""OFFSET TO CONFIGURATION DATA SECTION

SMF Info
--------
    Field: `R79ECPDS`
    Record: `SMF79S14`
    Map: `R79ECS`

OFFSET TO CONFIGURATION DATA SECTION
"""
r79ecpds.__doc__ = """OFFSET TO CONFIGURATION DATA SECTION

SMF Info
--------
    Field: `R79ECPDS`
    Record: `SMF79S14`
    Map: `R79ECS`

OFFSET TO CONFIGURATION DATA SECTION
"""

r79ecpdl : Final[Field] = Field(
    name='r79ecpdl',
    origin='R79ECPDL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECS,
)
"""LENGTH OF CONFIGURATION DATA SECTION

SMF Info
--------
    Field: `R79ECPDL`
    Record: `SMF79S14`
    Map: `R79ECS`

LENGTH OF CONFIGURATION DATA SECTION
"""
r79ecpdl.__doc__ = """LENGTH OF CONFIGURATION DATA SECTION

SMF Info
--------
    Field: `R79ECPDL`
    Record: `SMF79S14`
    Map: `R79ECS`

LENGTH OF CONFIGURATION DATA SECTION
"""

r79ecpdn : Final[Field] = Field(
    name='r79ecpdn',
    origin='R79ECPDN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECS,
)
"""NUMBER OF CONFIGURATION DATA SECTIONS

SMF Info
--------
    Field: `R79ECPDN`
    Record: `SMF79S14`
    Map: `R79ECS`

NUMBER OF CONFIGURATION DATA SECTIONS
"""
r79ecpdn.__doc__ = """NUMBER OF CONFIGURATION DATA SECTIONS

SMF Info
--------
    Field: `R79ECPDN`
    Record: `SMF79S14`
    Map: `R79ECS`

NUMBER OF CONFIGURATION DATA SECTIONS
"""

r79eid2 : Final[Field] = Field(
    name='r79eid2',
    origin='R79EID2',
    type=FieldType.STRING,
    record=record,
    record_map=R79EDS,
)
"""LOGICAL CONTROL UNIT IDENTIFIER

SMF Info
--------
    Field: `R79EID2`
    Record: `SMF79S14`
    Map: `R79EDS`

LOGICAL CONTROL UNIT IDENTIFIER
"""
r79eid2.__doc__ = """LOGICAL CONTROL UNIT IDENTIFIER

SMF Info
--------
    Field: `R79EID2`
    Record: `SMF79S14`
    Map: `R79EDS`

LOGICAL CONTROL UNIT IDENTIFIER
"""

r79edst : Final[Field] = Field(
    name='r79edst',
    origin='R79EDST',
    type=FieldType.STRING,
    record=record,
    record_map=R79EDS,
)
"""DATA STATUS

SMF Info
--------
    Field: `R79EDST`
    Record: `SMF79S14`
    Map: `R79EDS`

DATA STATUS
"""
r79edst.__doc__ = """DATA STATUS

SMF Info
--------
    Field: `R79EDST`
    Record: `SMF79S14`
    Map: `R79EDS`

DATA STATUS
"""

r79enhma : Final[Field] = Field(
    name='r79enhma',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79edst,
    record=record,
    record_map=R79EDS,
)
"""=1 IF NO HARDWARE MEASUREMENTS AVAILABLE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79edst`(`R79EDST`)
    Record: `SMF79S14`
    Map: `R79EDS`

=1 IF NO HARDWARE MEASUREMENTS AVAILABLE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79enhma.__doc__ = """=1 IF NO HARDWARE MEASUREMENTS AVAILABLE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79edst`(`R79EDST`)
    Record: `SMF79S14`
    Map: `R79EDS`

=1 IF NO HARDWARE MEASUREMENTS AVAILABLE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79eldcm : Final[Field] = Field(
    name='r79eldcm',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79edst,
    record=record,
    record_map=R79EDS,
)
"""=1 LCU contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79edst`(`R79EDST`)
    Record: `SMF79S14`
    Map: `R79EDS`

=1 LCU contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79eldcm.__doc__ = """=1 LCU contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79edst`(`R79EDST`)
    Record: `SMF79S14`
    Map: `R79EDS`

=1 LCU contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79elpat : Final[Field] = Field(
    name='r79elpat',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r79edst,
    record=record,
    record_map=R79EDS,
)
"""X'04' Path attributes are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79edst`(`R79EDST`)
    Record: `SMF79S14`
    Map: `R79EDS`

X'04' Path attributes are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r79elpat.__doc__ = """X'04' Path attributes are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79edst`(`R79EDST`)
    Record: `SMF79S14`
    Map: `R79EDS`

X'04' Path attributes are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r79eqsm : Final[Field] = Field(
    name='r79eqsm',
    origin='R79EQSM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""ACCUMULATION OF CU-HDR Q LENGTH

SMF Info
--------
    Field: `R79EQSM`
    Record: `SMF79S14`
    Map: `R79EDS`

ACCUMULATION OF CU-HDR Q LENGTH
"""
r79eqsm.__doc__ = """ACCUMULATION OF CU-HDR Q LENGTH

SMF Info
--------
    Field: `R79EQSM`
    Record: `SMF79S14`
    Map: `R79EDS`

ACCUMULATION OF CU-HDR Q LENGTH
"""

r79eqct : Final[Field] = Field(
    name='r79eqct',
    origin='R79EQCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Count of entries placed on the CU-HDR queue

SMF Info
--------
    Field: `R79EQCT`
    Record: `SMF79S14`
    Map: `R79EDS`

Count of entries placed on the CU-HDR queue
"""
r79eqct.__doc__ = """Count of entries placed on the CU-HDR queue

SMF Info
--------
    Field: `R79EQCT`
    Record: `SMF79S14`
    Map: `R79EDS`

Count of entries placed on the CU-HDR queue
"""

r79emcmn : Final[Field] = Field(
    name='r79emcmn',
    origin='R79EMCMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Minimum number of DCM managed channels used

SMF Info
--------
    Field: `R79EMCMN`
    Record: `SMF79S14`
    Map: `R79EDS`

Minimum number of DCM managed channels used
"""
r79emcmn.__doc__ = """Minimum number of DCM managed channels used

SMF Info
--------
    Field: `R79EMCMN`
    Record: `SMF79S14`
    Map: `R79EDS`

Minimum number of DCM managed channels used
"""

r79emcmx : Final[Field] = Field(
    name='r79emcmx',
    origin='R79EMCMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Maximum number of DCM managed channels used

SMF Info
--------
    Field: `R79EMCMX`
    Record: `SMF79S14`
    Map: `R79EDS`

Maximum number of DCM managed channels used
"""
r79emcmx.__doc__ = """Maximum number of DCM managed channels used

SMF Info
--------
    Field: `R79EMCMX`
    Record: `SMF79S14`
    Map: `R79EDS`

Maximum number of DCM managed channels used
"""

r79emcdf : Final[Field] = Field(
    name='r79emcdf',
    origin='R79EMCDF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Defined number of DCM managed channels

SMF Info
--------
    Field: `R79EMCDF`
    Record: `SMF79S14`
    Map: `R79EDS`

Defined number of DCM managed channels
"""
r79emcdf.__doc__ = """Defined number of DCM managed channels

SMF Info
--------
    Field: `R79EMCDF`
    Record: `SMF79S14`
    Map: `R79EDS`

Defined number of DCM managed channels
"""

r79eptm : Final[Field] = Field(
    name='r79eptm',
    origin='R79EPTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Accumulated path taken count for DCM managed channels

SMF Info
--------
    Field: `R79EPTM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated path taken count for DCM managed channels
"""
r79eptm.__doc__ = """Accumulated path taken count for DCM managed channels

SMF Info
--------
    Field: `R79EPTM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated path taken count for DCM managed channels
"""

r79edpbm : Final[Field] = Field(
    name='r79edpbm',
    origin='R79EDPBM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Accumulated director port busy count for DCM managed channels

SMF Info
--------
    Field: `R79EDPBM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated director port busy count for DCM managed channels
"""
r79edpbm.__doc__ = """Accumulated director port busy count for DCM managed channels

SMF Info
--------
    Field: `R79EDPBM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated director port busy count for DCM managed channels
"""

r79ecubm : Final[Field] = Field(
    name='r79ecubm',
    origin='R79ECUBM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Accumulated control unit busy count for DCM managed channels

SMF Info
--------
    Field: `R79ECUBM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated control unit busy count for DCM managed channels
"""
r79ecubm.__doc__ = """Accumulated control unit busy count for DCM managed channels

SMF Info
--------
    Field: `R79ECUBM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated control unit busy count for DCM managed channels
"""

r79ecbtm : Final[Field] = Field(
    name='r79ecbtm',
    origin='R79ECBTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Accumulated control unit busy delay time for DCM managed channels

SMF Info
--------
    Field: `R79ECBTM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated control unit busy delay time for DCM managed channels
"""
r79ecbtm.__doc__ = """Accumulated control unit busy delay time for DCM managed channels

SMF Info
--------
    Field: `R79ECBTM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated control unit busy delay time for DCM managed channels
"""

r79ecmrm : Final[Field] = Field(
    name='r79ecmrm',
    origin='R79ECMRM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Accumulated initial CoMmand Response time for DCM managed channels

SMF Info
--------
    Field: `R79ECMRM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated initial CoMmand Response time for DCM managed channels
"""
r79ecmrm.__doc__ = """Accumulated initial CoMmand Response time for DCM managed channels

SMF Info
--------
    Field: `R79ECMRM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated initial CoMmand Response time for DCM managed channels
"""

r79esbsm : Final[Field] = Field(
    name='r79esbsm',
    origin='R79ESBSM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Accumulated switch busy count summation for DCM managed channels

SMF Info
--------
    Field: `R79ESBSM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated switch busy count summation for DCM managed channels
"""
r79esbsm.__doc__ = """Accumulated switch busy count summation for DCM managed channels

SMF Info
--------
    Field: `R79ESBSM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated switch busy count summation for DCM managed channels
"""

r79etmwm : Final[Field] = Field(
    name='r79etmwm',
    origin='R79ETMWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Accumulated transport mode write count for DCM managed channels valid if R79ECPTD=1

SMF Info
--------
    Field: `R79ETMWM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated transport mode write count for DCM managed channels valid if R79ECPTD=1
"""
r79etmwm.__doc__ = """Accumulated transport mode write count for DCM managed channels valid if R79ECPTD=1

SMF Info
--------
    Field: `R79ETMWM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated transport mode write count for DCM managed channels valid if R79ECPTD=1
"""

r79etrdm : Final[Field] = Field(
    name='r79etrdm',
    origin='R79ETRDM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Accumulated first-transfer ready-disabled write count for DCM managed channels valid if R79ECPTD=1

SMF Info
--------
    Field: `R79ETRDM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated first-transfer ready-disabled write count for DCM managed channels valid if R79ECPTD=1
"""
r79etrdm.__doc__ = """Accumulated first-transfer ready-disabled write count for DCM managed channels valid if R79ECPTD=1

SMF Info
--------
    Field: `R79ETRDM`
    Record: `SMF79S14`
    Map: `R79EDS`

Accumulated first-transfer ready-disabled write count for DCM managed channels valid if R79ECPTD=1
"""

r79ecsst : Final[Field] = Field(
    name='r79ecsst',
    origin='R79ECSST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79EDS,
)
"""Channel subsystem wait time in units of 128 microseconds

SMF Info
--------
    Field: `R79ECSST`
    Record: `SMF79S14`
    Map: `R79EDS`

Channel subsystem wait time in units of 128 microseconds
"""
r79ecsst.__doc__ = """Channel subsystem wait time in units of 128 microseconds

SMF Info
--------
    Field: `R79ECSST`
    Record: `SMF79S14`
    Map: `R79EDS`

Channel subsystem wait time in units of 128 microseconds
"""

r79ecpid : Final[Field] = Field(
    name='r79ecpid',
    origin='R79ECPID',
    type=FieldType.STRING,
    record=record,
    record_map=R79ECPD,
)
"""CHANNEL PATH IDENTIFIER

SMF Info
--------
    Field: `R79ECPID`
    Record: `SMF79S14`
    Map: `R79ECPD`

CHANNEL PATH IDENTIFIER
"""
r79ecpid.__doc__ = """CHANNEL PATH IDENTIFIER

SMF Info
--------
    Field: `R79ECPID`
    Record: `SMF79S14`
    Map: `R79ECPD`

CHANNEL PATH IDENTIFIER
"""

r79ecpst : Final[Field] = Field(
    name='r79ecpst',
    origin='R79ECPST',
    type=FieldType.STRING,
    record=record,
    record_map=R79ECPD,
)
"""CHANNEL PATH STATUS

SMF Info
--------
    Field: `R79ECPST`
    Record: `SMF79S14`
    Map: `R79ECPD`

CHANNEL PATH STATUS
"""
r79ecpst.__doc__ = """CHANNEL PATH STATUS

SMF Info
--------
    Field: `R79ECPST`
    Record: `SMF79S14`
    Map: `R79ECPD`

CHANNEL PATH STATUS
"""

r79ecpi : Final[Field] = Field(
    name='r79ecpi',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r79ecpst,
    record=record,
    record_map=R79ECPD,
)
"""=1 IF CHANNEL PATH INST.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF CHANNEL PATH INST.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r79ecpi.__doc__ = """=1 IF CHANNEL PATH INST.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF CHANNEL PATH INST.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r79ecpo : Final[Field] = Field(
    name='r79ecpo',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79ecpst,
    record=record,
    record_map=R79ECPD,
)
"""=1 IF CHANNEL PATH ONLINE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF CHANNEL PATH ONLINE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79ecpo.__doc__ = """=1 IF CHANNEL PATH ONLINE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF CHANNEL PATH ONLINE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79ecpv : Final[Field] = Field(
    name='r79ecpv',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r79ecpst,
    record=record,
    record_map=R79ECPD,
)
"""=1 IF CHANNEL PATH VARIED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF CHANNEL PATH VARIED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r79ecpv.__doc__ = """=1 IF CHANNEL PATH VARIED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF CHANNEL PATH VARIED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r79evpof : Final[Field] = Field(
    name='r79evpof',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r79ecpst,
    record=record,
    record_map=R79ECPD,
)
"""=1 IF PATH OFFLINE TO ALL DEVICES TO THE LCU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF PATH OFFLINE TO ALL DEVICES TO THE LCU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r79evpof.__doc__ = """=1 IF PATH OFFLINE TO ALL DEVICES TO THE LCU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF PATH OFFLINE TO ALL DEVICES TO THE LCU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r79evp : Final[Field] = Field(
    name='r79evp',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79ecpst,
    record=record,
    record_map=R79ECPD,
)
"""=1 IF PATH CONNECTIVITY TO DEVICES OF THE LCU HAS MANIPULATED VIA VARY PATH(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF PATH CONNECTIVITY TO DEVICES OF THE LCU HAS MANIPULATED VIA VARY PATH

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79evp.__doc__ = """=1 IF PATH CONNECTIVITY TO DEVICES OF THE LCU HAS MANIPULATED VIA VARY PATH(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 IF PATH CONNECTIVITY TO DEVICES OF THE LCU HAS MANIPULATED VIA VARY PATH

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79ecpm : Final[Field] = Field(
    name='r79ecpm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r79ecpst,
    record=record,
    record_map=R79ECPD,
)
"""=1 Channel path is DCM managed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 Channel path is DCM managed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r79ecpm.__doc__ = """=1 Channel path is DCM managed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 Channel path is DCM managed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r79ecpmr : Final[Field] = Field(
    name='r79ecpmr',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r79ecpst,
    record=record,
    record_map=R79ECPD,
)
"""=1 CHPID manipulated, requiring data reset(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 CHPID manipulated, requiring data reset

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r79ecpmr.__doc__ = """=1 CHPID manipulated, requiring data reset(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpst`(`R79ECPST`)
    Record: `SMF79S14`
    Map: `R79ECPD`

=1 CHPID manipulated, requiring data reset

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r79ecun : Final[Field] = Field(
    name='r79ecun',
    origin='R79ECUN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""NUMBER OF CONTROL UNITS ATTACHED

SMF Info
--------
    Field: `R79ECUN`
    Record: `SMF79S14`
    Map: `R79ECPD`

NUMBER OF CONTROL UNITS ATTACHED
"""
r79ecun.__doc__ = """NUMBER OF CONTROL UNITS ATTACHED

SMF Info
--------
    Field: `R79ECUN`
    Record: `SMF79S14`
    Map: `R79ECPD`

NUMBER OF CONTROL UNITS ATTACHED
"""

r79ecu1 : Final[Field] = Field(
    name='r79ecu1',
    origin='R79ECU1',
    type=FieldType.STRING,
    record=record,
    record_map=R79ECPD,
)
"""1ST CONTROL UNIT ID.

SMF Info
--------
    Field: `R79ECU1`
    Record: `SMF79S14`
    Map: `R79ECPD`

1ST CONTROL UNIT ID.
"""
r79ecu1.__doc__ = """1ST CONTROL UNIT ID.

SMF Info
--------
    Field: `R79ECU1`
    Record: `SMF79S14`
    Map: `R79ECPD`

1ST CONTROL UNIT ID.
"""

r79ecu2 : Final[Field] = Field(
    name='r79ecu2',
    origin='R79ECU2',
    type=FieldType.STRING,
    record=record,
    record_map=R79ECPD,
)
"""2ND CONTROL UNIT ID.

SMF Info
--------
    Field: `R79ECU2`
    Record: `SMF79S14`
    Map: `R79ECPD`

2ND CONTROL UNIT ID.
"""
r79ecu2.__doc__ = """2ND CONTROL UNIT ID.

SMF Info
--------
    Field: `R79ECU2`
    Record: `SMF79S14`
    Map: `R79ECPD`

2ND CONTROL UNIT ID.
"""

r79ecu3 : Final[Field] = Field(
    name='r79ecu3',
    origin='R79ECU3',
    type=FieldType.STRING,
    record=record,
    record_map=R79ECPD,
)
"""3RD CONTROL UNIT ID.

SMF Info
--------
    Field: `R79ECU3`
    Record: `SMF79S14`
    Map: `R79ECPD`

3RD CONTROL UNIT ID.
"""
r79ecu3.__doc__ = """3RD CONTROL UNIT ID.

SMF Info
--------
    Field: `R79ECU3`
    Record: `SMF79S14`
    Map: `R79ECPD`

3RD CONTROL UNIT ID.
"""

r79ecu4 : Final[Field] = Field(
    name='r79ecu4',
    origin='R79ECU4',
    type=FieldType.STRING,
    record=record,
    record_map=R79ECPD,
)
"""4TH CONTROL UNIT ID.

SMF Info
--------
    Field: `R79ECU4`
    Record: `SMF79S14`
    Map: `R79ECPD`

4TH CONTROL UNIT ID.
"""
r79ecu4.__doc__ = """4TH CONTROL UNIT ID.

SMF Info
--------
    Field: `R79ECU4`
    Record: `SMF79S14`
    Map: `R79ECPD`

4TH CONTROL UNIT ID.
"""

r79ecub : Final[Field] = Field(
    name='r79ecub',
    origin='R79ECUB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""COUNT OF CU BUSY

SMF Info
--------
    Field: `R79ECUB`
    Record: `SMF79S14`
    Map: `R79ECPD`

COUNT OF CU BUSY
"""
r79ecub.__doc__ = """COUNT OF CU BUSY

SMF Info
--------
    Field: `R79ECUB`
    Record: `SMF79S14`
    Map: `R79ECPD`

COUNT OF CU BUSY
"""

r79ept : Final[Field] = Field(
    name='r79ept',
    origin='R79EPT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""COUNT OF OPERATION ACCEPTED ON THIS CHANNEL PATH

SMF Info
--------
    Field: `R79EPT`
    Record: `SMF79S14`
    Map: `R79ECPD`

COUNT OF OPERATION ACCEPTED ON THIS CHANNEL PATH
"""
r79ept.__doc__ = """COUNT OF OPERATION ACCEPTED ON THIS CHANNEL PATH

SMF Info
--------
    Field: `R79EPT`
    Record: `SMF79S14`
    Map: `R79ECPD`

COUNT OF OPERATION ACCEPTED ON THIS CHANNEL PATH
"""

r79edpbc : Final[Field] = Field(
    name='r79edpbc',
    origin='R79EDPBC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""Number of initial selection attempts that were unsuccessful because ESCON Director port busy

SMF Info
--------
    Field: `R79EDPBC`
    Record: `SMF79S14`
    Map: `R79ECPD`

Number of initial selection attempts that were unsuccessful because ESCON Director port busy
"""
r79edpbc.__doc__ = """Number of initial selection attempts that were unsuccessful because ESCON Director port busy

SMF Info
--------
    Field: `R79EDPBC`
    Record: `SMF79S14`
    Map: `R79ECPD`

Number of initial selection attempts that were unsuccessful because ESCON Director port busy
"""

r79ecbt : Final[Field] = Field(
    name='r79ecbt',
    origin='R79ECBT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""Control unit busy delay time

SMF Info
--------
    Field: `R79ECBT`
    Record: `SMF79S14`
    Map: `R79ECPD`

Control unit busy delay time
"""
r79ecbt.__doc__ = """Control unit busy delay time

SMF Info
--------
    Field: `R79ECBT`
    Record: `SMF79S14`
    Map: `R79ECPD`

Control unit busy delay time
"""

r79ecmr : Final[Field] = Field(
    name='r79ecmr',
    origin='R79ECMR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""Initial CoMmand Response time

SMF Info
--------
    Field: `R79ECMR`
    Record: `SMF79S14`
    Map: `R79ECPD`

Initial CoMmand Response time
"""
r79ecmr.__doc__ = """Initial CoMmand Response time

SMF Info
--------
    Field: `R79ECMR`
    Record: `SMF79S14`
    Map: `R79ECPD`

Initial CoMmand Response time
"""

r79esbs : Final[Field] = Field(
    name='r79esbs',
    origin='R79ESBS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""Switch busy count summation

SMF Info
--------
    Field: `R79ESBS`
    Record: `SMF79S14`
    Map: `R79ECPD`

Switch busy count summation
"""
r79esbs.__doc__ = """Switch busy count summation

SMF Info
--------
    Field: `R79ESBS`
    Record: `SMF79S14`
    Map: `R79ECPD`

Switch busy count summation
"""

r79ecpxf : Final[Field] = Field(
    name='r79ecpxf',
    origin='R79ECPXF',
    type=FieldType.STRING,
    record=record,
    record_map=R79ECPD,
)
"""Channel Path extended flags

SMF Info
--------
    Field: `R79ECPXF`
    Record: `SMF79S14`
    Map: `R79ECPD`

Channel Path extended flags
"""
r79ecpxf.__doc__ = """Channel Path extended flags

SMF Info
--------
    Field: `R79ECPXF`
    Record: `SMF79S14`
    Map: `R79ECPD`

Channel Path extended flags
"""

r79ecpxm : Final[Field] = Field(
    name='r79ecpxm',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r79ecpxf,
    record=record,
    record_map=R79ECPD,
)
"""1 = extended I/O measurement-block format-1 data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpxf`(`R79ECPXF`)
    Record: `SMF79S14`
    Map: `R79ECPD`

1 = extended I/O measurement-block format-1 data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r79ecpxm.__doc__ = """1 = extended I/O measurement-block format-1 data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpxf`(`R79ECPXF`)
    Record: `SMF79S14`
    Map: `R79ECPD`

1 = extended I/O measurement-block format-1 data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r79ecpx2 : Final[Field] = Field(
    name='r79ecpx2',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79ecpxf,
    record=record,
    record_map=R79ECPD,
)
"""1 = extended I/O measurement-block format-2 data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpxf`(`R79ECPXF`)
    Record: `SMF79S14`
    Map: `R79ECPD`

1 = extended I/O measurement-block format-2 data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79ecpx2.__doc__ = """1 = extended I/O measurement-block format-2 data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpxf`(`R79ECPXF`)
    Record: `SMF79S14`
    Map: `R79ECPD`

1 = extended I/O measurement-block format-2 data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79ecptd : Final[Field] = Field(
    name='r79ecptd',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r79ecpxf,
    record=record,
    record_map=R79ECPD,
)
"""1 = First-transfer-ready disabled supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpxf`(`R79ECPXF`)
    Record: `SMF79S14`
    Map: `R79ECPD`

1 = First-transfer-ready disabled supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r79ecptd.__doc__ = """1 = First-transfer-ready disabled supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79ecpxf`(`R79ECPXF`)
    Record: `SMF79S14`
    Map: `R79ECPD`

1 = First-transfer-ready disabled supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r79ecpat : Final[Field] = Field(
    name='r79ecpat',
    origin='R79ECPAT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""Path attribute: 0 = No attributes specified, 1 = Preferred path, 2 = Non-preferred path

SMF Info
--------
    Field: `R79ECPAT`
    Record: `SMF79S14`
    Map: `R79ECPD`

Path attribute: 0 = No attributes specified, 1 = Preferred path, 2 = Non-preferred path
"""
r79ecpat.__doc__ = """Path attribute: 0 = No attributes specified, 1 = Preferred path, 2 = Non-preferred path

SMF Info
--------
    Field: `R79ECPAT`
    Record: `SMF79S14`
    Map: `R79ECPD`

Path attribute: 0 = No attributes specified, 1 = Preferred path, 2 = Non-preferred path
"""

r79ectmw : Final[Field] = Field(
    name='r79ectmw',
    origin='R79ECTMW',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""Transport mode write count valid if R79ECPTD=1

SMF Info
--------
    Field: `R79ECTMW`
    Record: `SMF79S14`
    Map: `R79ECPD`

Transport mode write count valid if R79ECPTD=1
"""
r79ectmw.__doc__ = """Transport mode write count valid if R79ECPTD=1

SMF Info
--------
    Field: `R79ECTMW`
    Record: `SMF79S14`
    Map: `R79ECPD`

Transport mode write count valid if R79ECPTD=1
"""

r79ectrd : Final[Field] = Field(
    name='r79ectrd',
    origin='R79ECTRD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79ECPD,
)
"""First-transfer-ready disabled write count valid if R79ECPTD=1

SMF Info
--------
    Field: `R79ECTRD`
    Record: `SMF79S14`
    Map: `R79ECPD`

First-transfer-ready disabled write count valid if R79ECPTD=1
"""
r79ectrd.__doc__ = """First-transfer-ready disabled write count valid if R79ECPTD=1

SMF Info
--------
    Field: `R79ECTRD`
    Record: `SMF79S14`
    Map: `R79ECPD`

First-transfer-ready disabled write count valid if R79ECPTD=1
"""
