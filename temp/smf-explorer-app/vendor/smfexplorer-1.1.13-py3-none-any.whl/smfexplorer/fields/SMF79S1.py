# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 79 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=79,
                                smf_subtype=1,
                                spec='SMF 79 Subtype 1',
                                post=None)
"""SMF 79 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF79PRO: Final[RecordMap] = RecordMap(
    origin='SMF79PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R79CHL: Final[RecordMap] = RecordMap(
    origin='R79CHL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Common record 79 header',
    post=None,
    record_mapping=False)
"""Common record 79 header"""
R791ELEM: Final[RecordMap] = RecordMap(
    origin='R791ELEM',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Mapping of element',
    post=None,
    record_mapping=False)
"""Mapping of element"""

date : Final[Field] = Field(
    name='date',
    origin='SMF79DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF79TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF79DTE`), `time`(`SMF79TME`)
    Record: `SMF79S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF79DTE`), `time`(`SMF79TME`)
    Record: `SMF79S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF79LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF79LEN`
    Record: `SMF79S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF79LEN`
    Record: `SMF79S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF79SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF79SEG`
    Record: `SMF79S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF79SEG`
    Record: `SMF79S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF79FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF79FLG`
    Record: `SMF79S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF79FLG`
    Record: `SMF79S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF79RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF79RTY`
    Record: `SMF79S1`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF79RTY`
    Record: `SMF79S1`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF79TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF79DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF79SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF79SID`
    Record: `SMF79S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF79SID`
    Record: `SMF79S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF79SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF79SSI`
    Record: `SMF79S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF79SSI`
    Record: `SMF79S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF79STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF79STY`
    Record: `SMF79S1`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF79STY`
    Record: `SMF79S1`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF79TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF79TRN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF79TRN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF79PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF79PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF79PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF79PRN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF79PRN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

mcs : Final[Field] = Field(
    name='mcs',
    origin='SMF79MCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET TO MONITOR II CONTROL SECTION
"""
mcs.__doc__ = """OFFSET TO MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET TO MONITOR II CONTROL SECTION
"""

mcl : Final[Field] = Field(
    name='mcl',
    origin='SMF79MCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH OF MONITOR II CONTROL SECTION
"""
mcl.__doc__ = """LENGTH OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH OF MONITOR II CONTROL SECTION
"""

mcn : Final[Field] = Field(
    name='mcn',
    origin='SMF79MCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF MONITOR II CONTROL SECTION
"""
mcn.__doc__ = """NUMBER OF MONITOR II CONTROL SECTION

SMF Info
--------
    Field: `SMF79MCN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF MONITOR II CONTROL SECTION
"""

ass : Final[Field] = Field(
    name='ass',
    origin='SMF79ASS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO DATA SECTION

SMF Info
--------
    Field: `SMF79ASS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET TO DATA SECTION
"""
ass.__doc__ = """OFFSET TO DATA SECTION

SMF Info
--------
    Field: `SMF79ASS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET TO DATA SECTION
"""

asl : Final[Field] = Field(
    name='asl',
    origin='SMF79ASL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""
asl.__doc__ = """LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""

asn : Final[Field] = Field(
    name='asn',
    origin='SMF79ASN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF DATA SECTION
"""
asn.__doc__ = """NUMBER OF DATA SECTION

SMF Info
--------
    Field: `SMF79ASN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF DATA SECTION
"""

dcs : Final[Field] = Field(
    name='dcs',
    origin='SMF79DCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET TO DATA CONTROL SECTION
"""
dcs.__doc__ = """OFFSET TO DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET TO DATA CONTROL SECTION
"""

dcl : Final[Field] = Field(
    name='dcl',
    origin='SMF79DCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH OF DATA CONTROL SECTION
"""
dcl.__doc__ = """LENGTH OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH OF DATA CONTROL SECTION
"""

dcn : Final[Field] = Field(
    name='dcn',
    origin='SMF79DCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF DATA CONTROL SECTION
"""
dcn.__doc__ = """NUMBER OF DATA CONTROL SECTION

SMF Info
--------
    Field: `SMF79DCN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER OF DATA CONTROL SECTION
"""

qss : Final[Field] = Field(
    name='qss',
    origin='SMF79QSS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET IOQ GLOBAL SECTION
"""
qss.__doc__ = """OFFSET IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSS`
    Record: `SMF79S1`
    Map: Not part of a map

OFFSET IOQ GLOBAL SECTION
"""

qsl : Final[Field] = Field(
    name='qsl',
    origin='SMF79QSL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH IOQ GLOBAL SECTION
"""
qsl.__doc__ = """LENGTH IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSL`
    Record: `SMF79S1`
    Map: Not part of a map

LENGTH IOQ GLOBAL SECTION
"""

qsn : Final[Field] = Field(
    name='qsn',
    origin='SMF79QSN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER IOQ GLOBAL SECTION
"""
qsn.__doc__ = """NUMBER IOQ GLOBAL SECTION

SMF Info
--------
    Field: `SMF79QSN`
    Record: `SMF79S1`
    Map: Not part of a map

NUMBER IOQ GLOBAL SECTION
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF79MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF79MFV`
    Record: `SMF79S1`
    Map: `SMF79PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF79MFV`
    Record: `SMF79S1`
    Map: `SMF79PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF79PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF79PRD`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF79PRD`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF79IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF79PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF79IST`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF79IST`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF79DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF79PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF79DAT`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF79DAT`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF79INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF79PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF79INT`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF79INT`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF79SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF79SAM`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF79SAM`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF79FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF79FLA`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF79FLA`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF79PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF79FLA`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF79CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF79PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF79CYC`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF79CYC`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF79MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF79MVS`
    Record: `SMF79S1`
    Map: `SMF79PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF79MVS`
    Record: `SMF79S1`
    Map: `SMF79PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF79IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF79IML`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF79IML`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF79PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF79PRF`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF79PRF`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF79PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF79PRF`)
    Record: `SMF79S1`
    Map: `SMF79PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF79PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF79PTN`
    Record: `SMF79S1`
    Map: `SMF79PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF79PTN`
    Record: `SMF79S1`
    Map: `SMF79PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF79SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF79SRL`
    Record: `SMF79S1`
    Map: `SMF79PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF79SRL`
    Record: `SMF79S1`
    Map: `SMF79PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF79IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF79PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF79IET`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF79IET`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF79LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF79LGO`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF79LGO`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF79RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF79RAO`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF79RAO`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF79RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF79RAL`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF79RAL`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF79RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF79RAN`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF79RAN`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF79OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF79OIL`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF79OIL`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF79SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF79PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF79SYN`
    Record: `SMF79S1`
    Map: `SMF79PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF79SYN`
    Record: `SMF79S1`
    Map: `SMF79PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF79GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF79PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF79GIE`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF79GIE`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF79XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF79XNM`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF79XNM`
    Record: `SMF79S1`
    Map: `SMF79PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF79SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF79PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF79SNM`
    Record: `SMF79S1`
    Map: `SMF79PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF79SNM`
    Record: `SMF79S1`
    Map: `SMF79PRO`

System name for current system as defined in CVTSNAME
"""

r79gtod : Final[Field] = Field(
    name='r79gtod',
    origin='R79GTOD',
    type=FieldType.TIME,
    record=record,
    record_map=R79CHL,
)
"""Time when the call to data gatherer was issued

SMF Info
--------
    Field: `R79GTOD`
    Record: `SMF79S1`
    Map: `R79CHL`

Time when the call to data gatherer was issued
"""
r79gtod.__doc__ = """Time when the call to data gatherer was issued

SMF Info
--------
    Field: `R79GTOD`
    Record: `SMF79S1`
    Map: `R79CHL`

Time when the call to data gatherer was issued
"""

r79lf2 : Final[Field] = Field(
    name='r79lf2',
    origin='R79LF2',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Flag byte

SMF Info
--------
    Field: `R79LF2`
    Record: `SMF79S1`
    Map: `R79CHL`

Flag byte
"""
r79lf2.__doc__ = """Flag byte

SMF Info
--------
    Field: `R79LF2`
    Record: `SMF79S1`
    Map: `R79CHL`

Flag byte
"""

r79par : Final[Field] = Field(
    name='r79par',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Not enough relocate section to complete data gathering(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Not enough relocate section to complete data gathering

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r79par.__doc__ = """Not enough relocate section to complete data gathering(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Not enough relocate section to complete data gathering

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r79sg : Final[Field] = Field(
    name='r79sg',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Report sorted by SG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Report sorted by SG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r79sg.__doc__ = """Report sorted by SG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Report sorted by SG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r79rsm : Final[Field] = Field(
    name='r79rsm',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Invalid RSM data obtained(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Invalid RSM data obtained

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r79rsm.__doc__ = """Invalid RSM data obtained(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Invalid RSM data obtained

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r79goal : Final[Field] = Field(
    name='r79goal',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""System is in GOAL mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

System is in GOAL mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r79goal.__doc__ = """System is in GOAL mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

System is in GOAL mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r79trxi : Final[Field] = Field(
    name='r79trxi',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Invalid transaction data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Invalid transaction data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r79trxi.__doc__ = """Invalid transaction data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Invalid transaction data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r79srmc : Final[Field] = Field(
    name='r79srmc',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""SRM mode changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

SRM mode changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r79srmc.__doc__ = """SRM mode changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

SRM mode changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r79inv : Final[Field] = Field(
    name='r79inv',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""inval. data fr. Mon I (DEV PGSP IOQ)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

inval. data fr. Mon I (DEV PGSP IOQ)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r79inv.__doc__ = """inval. data fr. Mon I (DEV PGSP IOQ)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

inval. data fr. Mon I (DEV PGSP IOQ)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r79maxd : Final[Field] = Field(
    name='r79maxd',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r79lf2,
    record=record,
    record_map=R79CHL,
)
"""Incomplete device data due to too many devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Incomplete device data due to too many devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r79maxd.__doc__ = """Incomplete device data due to too many devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r79lf2`(`R79LF2`)
    Record: `SMF79S1`
    Map: `R79CHL`

Incomplete device data due to too many devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r79ses : Final[Field] = Field(
    name='r79ses',
    origin='R79SES',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Session name

SMF Info
--------
    Field: `R79SES`
    Record: `SMF79S1`
    Map: `R79CHL`

Session name
"""
r79ses.__doc__ = """Session name

SMF Info
--------
    Field: `R79SES`
    Record: `SMF79S1`
    Map: `R79CHL`

Session name
"""

r79user : Final[Field] = Field(
    name='r79user',
    origin='R79USER',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""User field

SMF Info
--------
    Field: `R79USER`
    Record: `SMF79S1`
    Map: `R79CHL`

User field
"""
r79user.__doc__ = """User field

SMF Info
--------
    Field: `R79USER`
    Record: `SMF79S1`
    Map: `R79CHL`

User field
"""

r79rid : Final[Field] = Field(
    name='r79rid',
    origin='R79RID',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Measurement name

SMF Info
--------
    Field: `R79RID`
    Record: `SMF79S1`
    Map: `R79CHL`

Measurement name
"""
r79rid.__doc__ = """Measurement name

SMF Info
--------
    Field: `R79RID`
    Record: `SMF79S1`
    Map: `R79CHL`

Measurement name
"""

r79ctxtl : Final[Field] = Field(
    name='r79ctxtl',
    origin='R79CTXTL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Length of command text

SMF Info
--------
    Field: `R79CTXTL`
    Record: `SMF79S1`
    Map: `R79CHL`

Length of command text
"""
r79ctxtl.__doc__ = """Length of command text

SMF Info
--------
    Field: `R79CTXTL`
    Record: `SMF79S1`
    Map: `R79CHL`

Length of command text
"""

r79ctext : Final[Field] = Field(
    name='r79ctext',
    origin='R79CTEXT',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Command text

SMF Info
--------
    Field: `R79CTEXT`
    Record: `SMF79S1`
    Map: `R79CHL`

Command text
"""
r79ctext.__doc__ = """Command text

SMF Info
--------
    Field: `R79CTEXT`
    Record: `SMF79S1`
    Map: `R79CHL`

Command text
"""

r79dtxtl : Final[Field] = Field(
    name='r79dtxtl',
    origin='R79DTXTL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Length default DR text

SMF Info
--------
    Field: `R79DTXTL`
    Record: `SMF79S1`
    Map: `R79CHL`

Length default DR text
"""
r79dtxtl.__doc__ = """Length default DR text

SMF Info
--------
    Field: `R79DTXTL`
    Record: `SMF79S1`
    Map: `R79CHL`

Length default DR text
"""

r79dtext : Final[Field] = Field(
    name='r79dtext',
    origin='R79DTEXT',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Default DR text

SMF Info
--------
    Field: `R79DTEXT`
    Record: `SMF79S1`
    Map: `R79CHL`

Default DR text
"""
r79dtext.__doc__ = """Default DR text

SMF Info
--------
    Field: `R79DTEXT`
    Record: `SMF79S1`
    Map: `R79CHL`

Default DR text
"""

r79ist : Final[Field] = Field(
    name='r79ist',
    origin='R79IST',
    type=FieldType.TIME,
    record=record,
    record_map=R79CHL,
)
"""Monitor I interval start time

SMF Info
--------
    Field: `R79IST`
    Record: `SMF79S1`
    Map: `R79CHL`

Monitor I interval start time
"""
r79ist.__doc__ = """Monitor I interval start time

SMF Info
--------
    Field: `R79IST`
    Record: `SMF79S1`
    Map: `R79CHL`

Monitor I interval start time
"""

r79tsr : Final[Field] = Field(
    name='r79tsr',
    origin='R79TSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Total number of small records

SMF Info
--------
    Field: `R79TSR`
    Record: `SMF79S1`
    Map: `R79CHL`

Total number of small records
"""
r79tsr.__doc__ = """Total number of small records

SMF Info
--------
    Field: `R79TSR`
    Record: `SMF79S1`
    Map: `R79CHL`

Total number of small records
"""

r79tot : Final[Field] = Field(
    name='r79tot',
    origin='R79TOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Total number of data sections in large record

SMF Info
--------
    Field: `R79TOT`
    Record: `SMF79S1`
    Map: `R79CHL`

Total number of data sections in large record
"""
r79tot.__doc__ = """Total number of data sections in large record

SMF Info
--------
    Field: `R79TOT`
    Record: `SMF79S1`
    Map: `R79CHL`

Total number of data sections in large record
"""

r79nxt : Final[Field] = Field(
    name='r79nxt',
    origin='R79NXT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79CHL,
)
"""Number of data sections in following small records

SMF Info
--------
    Field: `R79NXT`
    Record: `SMF79S1`
    Map: `R79CHL`

Number of data sections in following small records
"""
r79nxt.__doc__ = """Number of data sections in following small records

SMF Info
--------
    Field: `R79NXT`
    Record: `SMF79S1`
    Map: `R79CHL`

Number of data sections in following small records
"""

r79iwmtk : Final[Field] = Field(
    name='r79iwmtk',
    origin='R79IWMTK',
    type=FieldType.STRING,
    record=record,
    record_map=R79CHL,
)
"""Token returned from IWMRCOLL service

SMF Info
--------
    Field: `R79IWMTK`
    Record: `SMF79S1`
    Map: `R79CHL`

Token returned from IWMRCOLL service
"""
r79iwmtk.__doc__ = """Token returned from IWMRCOLL service

SMF Info
--------
    Field: `R79IWMTK`
    Record: `SMF79S1`
    Map: `R79CHL`

Token returned from IWMRCOLL service
"""

r791asid : Final[Field] = Field(
    name='r791asid',
    origin='R791ASID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""ASID number

SMF Info
--------
    Field: `R791ASID`
    Record: `SMF79S1`
    Map: `R791ELEM`

ASID number
"""
r791asid.__doc__ = """ASID number

SMF Info
--------
    Field: `R791ASID`
    Record: `SMF79S1`
    Map: `R791ELEM`

ASID number
"""

r791jbn : Final[Field] = Field(
    name='r791jbn',
    origin='R791JBN',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Name of job

SMF Info
--------
    Field: `R791JBN`
    Record: `SMF79S1`
    Map: `R791ELEM`

Name of job
"""
r791jbn.__doc__ = """Name of job

SMF Info
--------
    Field: `R791JBN`
    Record: `SMF79S1`
    Map: `R791ELEM`

Name of job
"""

r791ttod : Final[Field] = Field(
    name='r791ttod',
    origin='R791TTOD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Real time into transaction (milliseconds)

SMF Info
--------
    Field: `R791TTOD`
    Record: `SMF79S1`
    Map: `R791ELEM`

Real time into transaction (milliseconds)
"""
r791ttod.__doc__ = """Real time into transaction (milliseconds)

SMF Info
--------
    Field: `R791TTOD`
    Record: `SMF79S1`
    Map: `R791ELEM`

Real time into transaction (milliseconds)
"""

r791cl : Final[Field] = Field(
    name='r791cl',
    origin='R791CL',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Current location IN - In storage, OT - Swapped out and ready, LO - Logically swapped out, NS - Non swappable, WM - Wait queue/MSO, WL - Wait queue/long wait, WT - Wait queue/term wait, WO - Wait queue/others, DL - TSO user delayed by SRM to meet response time objective, PR - Privileged, >> - Transitioning out, << - Transitioning in

SMF Info
--------
    Field: `R791CL`
    Record: `SMF79S1`
    Map: `R791ELEM`

Current location IN - In storage, OT - Swapped out and ready, LO - Logically swapped out, NS - Non swappable, WM - Wait queue/MSO, WL - Wait queue/long wait, WT - Wait queue/term wait, WO - Wait queue/others, DL - TSO user delayed by SRM to meet response time objective, PR - Privileged, >> - Transitioning out, << - Transitioning in
"""
r791cl.__doc__ = """Current location IN - In storage, OT - Swapped out and ready, LO - Logically swapped out, NS - Non swappable, WM - Wait queue/MSO, WL - Wait queue/long wait, WT - Wait queue/term wait, WO - Wait queue/others, DL - TSO user delayed by SRM to meet response time objective, PR - Privileged, >> - Transitioning out, << - Transitioning in

SMF Info
--------
    Field: `R791CL`
    Record: `SMF79S1`
    Map: `R791ELEM`

Current location IN - In storage, OT - Swapped out and ready, LO - Logically swapped out, NS - Non swappable, WM - Wait queue/MSO, WL - Wait queue/long wait, WT - Wait queue/term wait, WO - Wait queue/others, DL - TSO user delayed by SRM to meet response time objective, PR - Privileged, >> - Transitioning out, << - Transitioning in
"""

r791tas : Final[Field] = Field(
    name='r791tas',
    origin='R791TAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Type of user 0 - Batch, 1 - Started task, 2 - Mount task, 3 - TSO, 4 - ASCH, 5 - OMVS

SMF Info
--------
    Field: `R791TAS`
    Record: `SMF79S1`
    Map: `R791ELEM`

Type of user 0 - Batch, 1 - Started task, 2 - Mount task, 3 - TSO, 4 - ASCH, 5 - OMVS
"""
r791tas.__doc__ = """Type of user 0 - Batch, 1 - Started task, 2 - Mount task, 3 - TSO, 4 - ASCH, 5 - OMVS

SMF Info
--------
    Field: `R791TAS`
    Record: `SMF79S1`
    Map: `R791ELEM`

Type of user 0 - Batch, 1 - Started task, 2 - Mount task, 3 - TSO, 4 - ASCH, 5 - OMVS
"""

r791src : Final[Field] = Field(
    name='r791src',
    origin='R791SRC',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Reason last swap out TO - Terminal output, TI - Terminal input, LW - LONG WAIT, XS - AUX storage short, RS - Real storage short, DW - Detected wait, MP - MEMORY POOL SHORTAGE, NQ - CAP enqueue, EX - CAP exchange, US - CAP uni-swap, TS - Transition, IC - Improve central storage usage, IP - Improve system paging rate, MR - Make room to swap in an out-too-long user, AW - APPC wait, IW - OMVS input wait, OW - OMVS output wait, SR - In-real swap, 00 - Unknown

SMF Info
--------
    Field: `R791SRC`
    Record: `SMF79S1`
    Map: `R791ELEM`

Reason last swap out TO - Terminal output, TI - Terminal input, LW - LONG WAIT, XS - AUX storage short, RS - Real storage short, DW - Detected wait, MP - MEMORY POOL SHORTAGE, NQ - CAP enqueue, EX - CAP exchange, US - CAP uni-swap, TS - Transition, IC - Improve central storage usage, IP - Improve system paging rate, MR - Make room to swap in an out-too-long user, AW - APPC wait, IW - OMVS input wait, OW - OMVS output wait, SR - In-real swap, 00 - Unknown
"""
r791src.__doc__ = """Reason last swap out TO - Terminal output, TI - Terminal input, LW - LONG WAIT, XS - AUX storage short, RS - Real storage short, DW - Detected wait, MP - MEMORY POOL SHORTAGE, NQ - CAP enqueue, EX - CAP exchange, US - CAP uni-swap, TS - Transition, IC - Improve central storage usage, IP - Improve system paging rate, MR - Make room to swap in an out-too-long user, AW - APPC wait, IW - OMVS input wait, OW - OMVS output wait, SR - In-real swap, 00 - Unknown

SMF Info
--------
    Field: `R791SRC`
    Record: `SMF79S1`
    Map: `R791ELEM`

Reason last swap out TO - Terminal output, TI - Terminal input, LW - LONG WAIT, XS - AUX storage short, RS - Real storage short, DW - Detected wait, MP - MEMORY POOL SHORTAGE, NQ - CAP enqueue, EX - CAP exchange, US - CAP uni-swap, TS - Transition, IC - Improve central storage usage, IP - Improve system paging rate, MR - Make room to swap in an out-too-long user, AW - APPC wait, IW - OMVS input wait, OW - OMVS output wait, SR - In-real swap, 00 - Unknown
"""

r791dp : Final[Field] = Field(
    name='r791dp',
    origin='R791DP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Dispatcher priority

SMF Info
--------
    Field: `R791DP`
    Record: `SMF79S1`
    Map: `R791ELEM`

Dispatcher priority
"""
r791dp.__doc__ = """Dispatcher priority

SMF Info
--------
    Field: `R791DP`
    Record: `SMF79S1`
    Map: `R791ELEM`

Dispatcher priority
"""

r791swc : Final[Field] = Field(
    name='r791swc',
    origin='R791SWC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Transaction swap count

SMF Info
--------
    Field: `R791SWC`
    Record: `SMF79S1`
    Map: `R791ELEM`

Transaction swap count
"""
r791swc.__doc__ = """Transaction swap count

SMF Info
--------
    Field: `R791SWC`
    Record: `SMF79S1`
    Map: `R791ELEM`

Transaction swap count
"""

r791swmr : Final[Field] = Field(
    name='r791swmr',
    origin='R791SWMR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""SRM workload recom value

SMF Info
--------
    Field: `R791SWMR`
    Record: `SMF79S1`
    Map: `R791ELEM`

SRM workload recom value
"""
r791swmr.__doc__ = """SRM workload recom value

SMF Info
--------
    Field: `R791SWMR`
    Record: `SMF79S1`
    Map: `R791ELEM`

SRM workload recom value
"""

r791wms : Final[Field] = Field(
    name='r791wms',
    origin='R791WMS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""SRM service for the current transaction since the last swap in

SMF Info
--------
    Field: `R791WMS`
    Record: `SMF79S1`
    Map: `R791ELEM`

SRM service for the current transaction since the last swap in
"""
r791wms.__doc__ = """SRM service for the current transaction since the last swap in

SMF Info
--------
    Field: `R791WMS`
    Record: `SMF79S1`
    Map: `R791ELEM`

SRM service for the current transaction since the last swap in
"""

r791tcpu : Final[Field] = Field(
    name='r791tcpu',
    origin='R791TCPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Total CPU time consumed on behalf of this address space in milliseconds (ascbejst+ascbsrbt+assbasst). Wraps after 4 Giga millisec

SMF Info
--------
    Field: `R791TCPU`
    Record: `SMF79S1`
    Map: `R791ELEM`

Total CPU time consumed on behalf of this address space in milliseconds (ascbejst+ascbsrbt+assbasst). Wraps after 4 Giga millisec
"""
r791tcpu.__doc__ = """Total CPU time consumed on behalf of this address space in milliseconds (ascbejst+ascbsrbt+assbasst). Wraps after 4 Giga millisec

SMF Info
--------
    Field: `R791TCPU`
    Record: `SMF79S1`
    Map: `R791ELEM`

Total CPU time consumed on behalf of this address space in milliseconds (ascbejst+ascbsrbt+assbasst). Wraps after 4 Giga millisec
"""

r791esct : Final[Field] = Field(
    name='r791esct',
    origin='R791ESCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of expanded storage frames used by job

SMF Info
--------
    Field: `R791ESCT`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of expanded storage frames used by job
"""
r791esct.__doc__ = """Number of expanded storage frames used by job

SMF Info
--------
    Field: `R791ESCT`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of expanded storage frames used by job
"""

r791pin : Final[Field] = Field(
    name='r791pin',
    origin='R791PIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Page in count

SMF Info
--------
    Field: `R791PIN`
    Record: `SMF79S1`
    Map: `R791ELEM`

Page in count
"""
r791pin.__doc__ = """Page in count

SMF Info
--------
    Field: `R791PIN`
    Record: `SMF79S1`
    Map: `R791ELEM`

Page in count
"""

r791trtm : Final[Field] = Field(
    name='r791trtm',
    origin='R791TRTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Transaction residency time

SMF Info
--------
    Field: `R791TRTM`
    Record: `SMF79S1`
    Map: `R791ELEM`

Transaction residency time
"""
r791trtm.__doc__ = """Transaction residency time

SMF Info
--------
    Field: `R791TRTM`
    Record: `SMF79S1`
    Map: `R791ELEM`

Transaction residency time
"""

r791flg : Final[Field] = Field(
    name='r791flg',
    origin='R791FLG',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Flags

SMF Info
--------
    Field: `R791FLG`
    Record: `SMF79S1`
    Map: `R791ELEM`

Flags
"""
r791flg.__doc__ = """Flags

SMF Info
--------
    Field: `R791FLG`
    Record: `SMF79S1`
    Map: `R791ELEM`

Flags
"""

r791xm : Final[Field] = Field(
    name='r791xm',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r791flg,
    record=record,
    record_map=R791ELEM,
)
"""Cross memory address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Cross memory address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r791xm.__doc__ = """Cross memory address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Cross memory address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r791pmon : Final[Field] = Field(
    name='r791pmon',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r791flg,
    record=record,
    record_map=R791ELEM,
)
"""On = data in R791CTAR is valid. Off = not valid.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = data in R791CTAR is valid. Off = not valid.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r791pmon.__doc__ = """On = data in R791CTAR is valid. Off = not valid.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = data in R791CTAR is valid. Off = not valid.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r791valv : Final[Field] = Field(
    name='r791valv',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r791flg,
    record=record,
    record_map=R791ELEM,
)
"""On = data in R791VAL is valid. Off = not valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = data in R791VAL is valid. Off = not valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r791valv.__doc__ = """On = data in R791VAL is valid. Off = not valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = data in R791VAL is valid. Off = not valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r791goal : Final[Field] = Field(
    name='r791goal',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r791flg,
    record=record,
    record_map=R791ELEM,
)
"""On = system is in GOAL mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = system is in GOAL mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r791goal.__doc__ = """On = system is in GOAL mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = system is in GOAL mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r791srv : Final[Field] = Field(
    name='r791srv',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r791flg,
    record=record,
    record_map=R791ELEM,
)
"""On = this address space is a server address space Off = GOAL specified for this address space is being honored by wlm(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = this address space is a server address space Off = GOAL specified for this address space is being honored by wlm

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r791srv.__doc__ = """On = this address space is a server address space Off = GOAL specified for this address space is being honored by wlm(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = this address space is a server address space Off = GOAL specified for this address space is being honored by wlm

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r791qsc : Final[Field] = Field(
    name='r791qsc',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r791flg,
    record=record,
    record_map=R791ELEM,
)
"""On = address space has been quiesced by a RESET command(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = address space has been quiesced by a RESET command

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r791qsc.__doc__ = """On = address space has been quiesced by a RESET command(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = address space has been quiesced by a RESET command

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r791txme : Final[Field] = Field(
    name='r791txme',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r791flg,
    record=record,
    record_map=R791ELEM,
)
"""Address space matched a classification rule in the active policy which prevents managing the region based on the response time goals of its served transactions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space matched a classification rule in the active policy which prevents managing the region based on the response time goals of its served transactions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r791txme.__doc__ = """Address space matched a classification rule in the active policy which prevents managing the region based on the response time goals of its served transactions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space matched a classification rule in the active policy which prevents managing the region based on the response time goals of its served transactions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r791taff : Final[Field] = Field(
    name='r791taff',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r791flg,
    record=record,
    record_map=R791ELEM,
)
"""On = address space has temporal affinities, same as RASDTAF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = address space has temporal affinities, same as RASDTAF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r791taff.__doc__ = """On = address space has temporal affinities, same as RASDTAF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg`(`R791FLG`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = address space has temporal affinities, same as RASDTAF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r791flg2 : Final[Field] = Field(
    name='r791flg2',
    origin='R791FLG2',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Additional flags

SMF Info
--------
    Field: `R791FLG2`
    Record: `SMF79S1`
    Map: `R791ELEM`

Additional flags
"""
r791flg2.__doc__ = """Additional flags

SMF Info
--------
    Field: `R791FLG2`
    Record: `SMF79S1`
    Map: `R791ELEM`

Additional flags
"""

r791cprc : Final[Field] = Field(
    name='r791cprc',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r791flg2,
    record=record,
    record_map=R791ELEM,
)
"""Service class assigned by classification or RESET SRVCLASS was designated CPU-critical in the active policy(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Service class assigned by classification or RESET SRVCLASS was designated CPU-critical in the active policy

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r791cprc.__doc__ = """Service class assigned by classification or RESET SRVCLASS was designated CPU-critical in the active policy(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Service class assigned by classification or RESET SRVCLASS was designated CPU-critical in the active policy

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r791cpre : Final[Field] = Field(
    name='r791cpre',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r791flg2,
    record=record,
    record_map=R791ELEM,
)
"""Address space matched a classification rule in the active policy which was designated storage-critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space matched a classification rule in the active policy which was designated storage-critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r791cpre.__doc__ = """Address space matched a classification rule in the active policy which was designated storage-critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space matched a classification rule in the active policy which was designated storage-critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r791cpri : Final[Field] = Field(
    name='r791cpri',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r791flg2,
    record=record,
    record_map=R791ELEM,
)
"""Address space is serving transactions which belong to a service class that was designated storage-critical in the active policy's classification rule, or is running in SYSTEM/SYSSTC(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space is serving transactions which belong to a service class that was designated storage-critical in the active policy's classification rule, or is running in SYSTEM/SYSSTC

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r791cpri.__doc__ = """Address space is serving transactions which belong to a service class that was designated storage-critical in the active policy's classification rule, or is running in SYSTEM/SYSSTC(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space is serving transactions which belong to a service class that was designated storage-critical in the active policy's classification rule, or is running in SYSTEM/SYSSTC

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r791cpup : Final[Field] = Field(
    name='r791cpup',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r791flg2,
    record=record,
    record_map=R791ELEM,
)
"""CPU protection was assigned either to the address space or to transaction service classes being served by the space or implicitly(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU protection was assigned either to the address space or to transaction service classes being served by the space or implicitly

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r791cpup.__doc__ = """CPU protection was assigned either to the address space or to transaction service classes being served by the space or implicitly(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU protection was assigned either to the address space or to transaction service classes being served by the space or implicitly

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r791stop : Final[Field] = Field(
    name='r791stop',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r791flg2,
    record=record,
    record_map=R791ELEM,
)
"""Storage protection was assigned either to the address space or to transaction service classes being served by the space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Storage protection was assigned either to the address space or to transaction service classes being served by the space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r791stop.__doc__ = """Storage protection was assigned either to the address space or to transaction service classes being served by the space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Storage protection was assigned either to the address space or to transaction service classes being served by the space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r791crmp : Final[Field] = Field(
    name='r791crmp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r791flg2,
    record=record,
    record_map=R791ELEM,
)
"""The dispatch priority of the address space is currently promoted due to a chronic resource contention(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

The dispatch priority of the address space is currently promoted due to a chronic resource contention

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r791crmp.__doc__ = """The dispatch priority of the address space is currently promoted due to a chronic resource contention(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

The dispatch priority of the address space is currently promoted due to a chronic resource contention

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r791txmb : Final[Field] = Field(
    name='r791txmb',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r791flg2,
    record=record,
    record_map=R791ELEM,
)
"""Address space is a CICS TOR that matched a classification rule in the active policy which allows managing the region based on the region goals but also ensures that completed transactions are reported and used for management of the CICS AORs(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space is a CICS TOR that matched a classification rule in the active policy which allows managing the region based on the region goals but also ensures that completed transactions are reported and used for management of the CICS AORs

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r791txmb.__doc__ = """Address space is a CICS TOR that matched a classification rule in the active policy which allows managing the region based on the region goals but also ensures that completed transactions are reported and used for management of the CICS AORs(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space is a CICS TOR that matched a classification rule in the active policy which allows managing the region based on the region goals but also ensures that completed transactions are reported and used for management of the CICS AORs

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r791nohp : Final[Field] = Field(
    name='r791nohp',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r791flg2,
    record=record,
    record_map=R791ELEM,
)
"""Honor priority ineligibility was assigned either to the address space or to transaction service classes being served by the space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Honor priority ineligibility was assigned either to the address space or to transaction service classes being served by the space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r791nohp.__doc__ = """Honor priority ineligibility was assigned either to the address space or to transaction service classes being served by the space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg2`(`R791FLG2`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Honor priority ineligibility was assigned either to the address space or to transaction service classes being served by the space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r791fmct : Final[Field] = Field(
    name='r791fmct',
    origin='R791FMCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of real storage frames

SMF Info
--------
    Field: `R791FMCT`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of real storage frames
"""
r791fmct.__doc__ = """Number of real storage frames

SMF Info
--------
    Field: `R791FMCT`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of real storage frames
"""

r791wss : Final[Field] = Field(
    name='r791wss',
    origin='R791WSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Working set at last swap in

SMF Info
--------
    Field: `R791WSS`
    Record: `SMF79S1`
    Map: `R791ELEM`

Working set at last swap in
"""
r791wss.__doc__ = """Working set at last swap in

SMF Info
--------
    Field: `R791WSS`
    Record: `SMF79S1`
    Map: `R791ELEM`

Working set at last swap in
"""

r791twss : Final[Field] = Field(
    name='r791twss',
    origin='R791TWSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""SRM target working set set site

SMF Info
--------
    Field: `R791TWSS`
    Record: `SMF79S1`
    Map: `R791ELEM`

SRM target working set set site
"""
r791twss.__doc__ = """SRM target working set set site

SMF Info
--------
    Field: `R791TWSS`
    Record: `SMF79S1`
    Map: `R791ELEM`

SRM target working set set site
"""

r791eshp : Final[Field] = Field(
    name='r791eshp',
    origin='R791ESHP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of hiperspace ES pages used by job

SMF Info
--------
    Field: `R791ESHP`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of hiperspace ES pages used by job
"""
r791eshp.__doc__ = """Number of hiperspace ES pages used by job

SMF Info
--------
    Field: `R791ESHP`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of hiperspace ES pages used by job
"""

r791esvi : Final[Field] = Field(
    name='r791esvi',
    origin='R791ESVI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of VIO ES pages used by job

SMF Info
--------
    Field: `R791ESVI`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of VIO ES pages used by job
"""
r791esvi.__doc__ = """Number of VIO ES pages used by job

SMF Info
--------
    Field: `R791ESVI`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of VIO ES pages used by job
"""

r791hin : Final[Field] = Field(
    name='r791hin',
    origin='R791HIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of hiperspace page ins by job

SMF Info
--------
    Field: `R791HIN`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of hiperspace page ins by job
"""
r791hin.__doc__ = """Number of hiperspace page ins by job

SMF Info
--------
    Field: `R791HIN`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of hiperspace page ins by job
"""

r791hrms : Final[Field] = Field(
    name='r791hrms',
    origin='R791HRMS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of hiperspace read misses by job

SMF Info
--------
    Field: `R791HRMS`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of hiperspace read misses by job
"""
r791hrms.__doc__ = """Number of hiperspace read misses by job

SMF Info
--------
    Field: `R791HRMS`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of hiperspace read misses by job
"""

r791bpin : Final[Field] = Field(
    name='r791bpin',
    origin='R791BPIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of blocked pages brought in from DASD

SMF Info
--------
    Field: `R791BPIN`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of blocked pages brought in from DASD
"""
r791bpin.__doc__ = """Number of blocked pages brought in from DASD

SMF Info
--------
    Field: `R791BPIN`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of blocked pages brought in from DASD
"""

r791pine : Final[Field] = Field(
    name='r791pine',
    origin='R791PINE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of single pages brought in from expanded storage

SMF Info
--------
    Field: `R791PINE`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of single pages brought in from expanded storage
"""
r791pine.__doc__ = """Number of single pages brought in from expanded storage

SMF Info
--------
    Field: `R791PINE`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of single pages brought in from expanded storage
"""

r791bpne : Final[Field] = Field(
    name='r791bpne',
    origin='R791BPNE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of blocked pages brought in from expanded storage

SMF Info
--------
    Field: `R791BPNE`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of blocked pages brought in from expanded storage
"""
r791bpne.__doc__ = """Number of blocked pages brought in from expanded storage

SMF Info
--------
    Field: `R791BPNE`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of blocked pages brought in from expanded storage
"""

r791ctar : Final[Field] = Field(
    name='r791ctar',
    origin='R791CTAR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Central storage target number of frames

SMF Info
--------
    Field: `R791CTAR`
    Record: `SMF79S1`
    Map: `R791ELEM`

Central storage target number of frames
"""
r791ctar.__doc__ = """Central storage target number of frames

SMF Info
--------
    Field: `R791CTAR`
    Record: `SMF79S1`
    Map: `R791ELEM`

Central storage target number of frames
"""

r791val : Final[Field] = Field(
    name='r791val',
    origin='R791VAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Recommendation value for WSM managed address spaces.

SMF Info
--------
    Field: `R791VAL`
    Record: `SMF79S1`
    Map: `R791ELEM`

Recommendation value for WSM managed address spaces.
"""
r791val.__doc__ = """Recommendation value for WSM managed address spaces.

SMF Info
--------
    Field: `R791VAL`
    Record: `SMF79S1`
    Map: `R791ELEM`

Recommendation value for WSM managed address spaces.
"""

r791scl : Final[Field] = Field(
    name='r791scl',
    origin='R791SCL',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Service class name

SMF Info
--------
    Field: `R791SCL`
    Record: `SMF79S1`
    Map: `R791ELEM`

Service class name
"""
r791scl.__doc__ = """Service class name

SMF Info
--------
    Field: `R791SCL`
    Record: `SMF79S1`
    Map: `R791ELEM`

Service class name
"""

r791scp : Final[Field] = Field(
    name='r791scp',
    origin='R791SCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Service class period

SMF Info
--------
    Field: `R791SCP`
    Record: `SMF79S1`
    Map: `R791ELEM`

Service class period
"""
r791scp.__doc__ = """Service class period

SMF Info
--------
    Field: `R791SCP`
    Record: `SMF79S1`
    Map: `R791ELEM`

Service class period
"""

r791wkld : Final[Field] = Field(
    name='r791wkld',
    origin='R791WKLD',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Workload name

SMF Info
--------
    Field: `R791WKLD`
    Record: `SMF79S1`
    Map: `R791ELEM`

Workload name
"""
r791wkld.__doc__ = """Workload name

SMF Info
--------
    Field: `R791WKLD`
    Record: `SMF79S1`
    Map: `R791ELEM`

Workload name
"""

r791rgrp : Final[Field] = Field(
    name='r791rgrp',
    origin='R791RGRP',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Resource group name

SMF Info
--------
    Field: `R791RGRP`
    Record: `SMF79S1`
    Map: `R791ELEM`

Resource group name
"""
r791rgrp.__doc__ = """Resource group name

SMF Info
--------
    Field: `R791RGRP`
    Record: `SMF79S1`
    Map: `R791ELEM`

Resource group name
"""

r791spi : Final[Field] = Field(
    name='r791spi',
    origin='R791SPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of page-ins from auxiliary storage for shared page groups

SMF Info
--------
    Field: `R791SPI`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of page-ins from auxiliary storage for shared page groups
"""
r791spi.__doc__ = """Number of page-ins from auxiliary storage for shared page groups

SMF Info
--------
    Field: `R791SPI`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of page-ins from auxiliary storage for shared page groups
"""

r791cmni : Final[Field] = Field(
    name='r791cmni',
    origin='R791CMNI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of common pages for current transaction

SMF Info
--------
    Field: `R791CMNI`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of common pages for current transaction
"""
r791cmni.__doc__ = """Number of common pages for current transaction

SMF Info
--------
    Field: `R791CMNI`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of common pages for current transaction
"""

r791pnv : Final[Field] = Field(
    name='r791pnv',
    origin='R791PNV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of non-VIO pages for current transaction

SMF Info
--------
    Field: `R791PNV`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of non-VIO pages for current transaction
"""
r791pnv.__doc__ = """Number of non-VIO pages for current transaction

SMF Info
--------
    Field: `R791PNV`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of non-VIO pages for current transaction
"""

r791pvio : Final[Field] = Field(
    name='r791pvio',
    origin='R791PVIO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Number of VIO pages for current transaction

SMF Info
--------
    Field: `R791PVIO`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of VIO pages for current transaction
"""
r791pvio.__doc__ = """Number of VIO pages for current transaction

SMF Info
--------
    Field: `R791PVIO`
    Record: `SMF79S1`
    Map: `R791ELEM`

Number of VIO pages for current transaction
"""

r791exct : Final[Field] = Field(
    name='r791exct',
    origin='R791EXCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""EXCP count for this step

SMF Info
--------
    Field: `R791EXCT`
    Record: `SMF79S1`
    Map: `R791ELEM`

EXCP count for this step
"""
r791exct.__doc__ = """EXCP count for this step

SMF Info
--------
    Field: `R791EXCT`
    Record: `SMF79S1`
    Map: `R791ELEM`

EXCP count for this step
"""

r791tcpc : Final[Field] = Field(
    name='r791tcpc',
    origin='R791TCPC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Total CPU time consumed in this address space in milliseconds. (ascbejst+ascbsrbt+assbphtm) +(assbphtm-assbphtm_base))

SMF Info
--------
    Field: `R791TCPC`
    Record: `SMF79S1`
    Map: `R791ELEM`

Total CPU time consumed in this address space in milliseconds. (ascbejst+ascbsrbt+assbphtm) +(assbphtm-assbphtm_base))
"""
r791tcpc.__doc__ = """Total CPU time consumed in this address space in milliseconds. (ascbejst+ascbsrbt+assbphtm) +(assbphtm-assbphtm_base))

SMF Info
--------
    Field: `R791TCPC`
    Record: `SMF79S1`
    Map: `R791ELEM`

Total CPU time consumed in this address space in milliseconds. (ascbejst+ascbsrbt+assbphtm) +(assbphtm-assbphtm_base))
"""

r791asst : Final[Field] = Field(
    name='r791asst',
    origin='R791ASST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""CPU time consumed by preemptible class SRBs running on behalf of this AS in milliseconds. (assbasst)

SMF Info
--------
    Field: `R791ASST`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed by preemptible class SRBs running on behalf of this AS in milliseconds. (assbasst)
"""
r791asst.__doc__ = """CPU time consumed by preemptible class SRBs running on behalf of this AS in milliseconds. (assbasst)

SMF Info
--------
    Field: `R791ASST`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed by preemptible class SRBs running on behalf of this AS in milliseconds. (assbasst)
"""

r791phtm : Final[Field] = Field(
    name='r791phtm',
    origin='R791PHTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""CPU time consumed by preemptible class SRBs running in this AS in millisecs. (assbphtm)

SMF Info
--------
    Field: `R791PHTM`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed by preemptible class SRBs running in this AS in millisecs. (assbphtm)
"""
r791phtm.__doc__ = """CPU time consumed by preemptible class SRBs running in this AS in millisecs. (assbphtm)

SMF Info
--------
    Field: `R791PHTM`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed by preemptible class SRBs running in this AS in millisecs. (assbphtm)
"""

r791rcl : Final[Field] = Field(
    name='r791rcl',
    origin='R791RCL',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Report class name

SMF Info
--------
    Field: `R791RCL`
    Record: `SMF79S1`
    Map: `R791ELEM`

Report class name
"""
r791rcl.__doc__ = """Report class name

SMF Info
--------
    Field: `R791RCL`
    Record: `SMF79S1`
    Map: `R791ELEM`

Report class name
"""

r791mlim : Final[Field] = Field(
    name='r791mlim',
    origin='R791MLIM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Address space memory limit in units of MB

SMF Info
--------
    Field: `R791MLIM`
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space memory limit in units of MB
"""
r791mlim.__doc__ = """Address space memory limit in units of MB

SMF Info
--------
    Field: `R791MLIM`
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space memory limit in units of MB
"""

r791tifa : Final[Field] = Field(
    name='r791tifa',
    origin='R791TIFA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""CPU time consumed on zAAPs (ASSB_TIME_ON_IFA)

SMF Info
--------
    Field: `R791TIFA`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on zAAPs (ASSB_TIME_ON_IFA)
"""
r791tifa.__doc__ = """CPU time consumed on zAAPs (ASSB_TIME_ON_IFA)

SMF Info
--------
    Field: `R791TIFA`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on zAAPs (ASSB_TIME_ON_IFA)
"""

r791tcp : Final[Field] = Field(
    name='r791tcp',
    origin='R791TCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""CPU time consumed on standard CPs (ASSB_TIME_ON_CP). Only valid if zAAPs or zIIPs in configuration

SMF Info
--------
    Field: `R791TCP`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on standard CPs (ASSB_TIME_ON_CP). Only valid if zAAPs or zIIPs in configuration
"""
r791tcp.__doc__ = """CPU time consumed on standard CPs (ASSB_TIME_ON_CP). Only valid if zAAPs or zIIPs in configuration

SMF Info
--------
    Field: `R791TCP`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on standard CPs (ASSB_TIME_ON_CP). Only valid if zAAPs or zIIPs in configuration
"""

r791tifc : Final[Field] = Field(
    name='r791tifc',
    origin='R791TIFC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""CPU time consumed on standard CPs by zAAP eligible work (ASSB_TIME_IFA_ON_CP)

SMF Info
--------
    Field: `R791TIFC`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on standard CPs by zAAP eligible work (ASSB_TIME_IFA_ON_CP)
"""
r791tifc.__doc__ = """CPU time consumed on standard CPs by zAAP eligible work (ASSB_TIME_IFA_ON_CP)

SMF Info
--------
    Field: `R791TIFC`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on standard CPs by zAAP eligible work (ASSB_TIME_IFA_ON_CP)
"""

r791nffi : Final[Field] = Field(
    name='r791nffi',
    origin='R791NFFI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Normalization factor for zAAP service time. Used to convert between real zAAP times and "normalized" zAAP times, i.e. the equivalent time on a standard CP. Multiply R791TIFA by this value and divide by 256 to calculate the normalized zAAP time

SMF Info
--------
    Field: `R791NFFI`
    Record: `SMF79S1`
    Map: `R791ELEM`

Normalization factor for zAAP service time. Used to convert between real zAAP times and "normalized" zAAP times, i.e. the equivalent time on a standard CP. Multiply R791TIFA by this value and divide by 256 to calculate the normalized zAAP time
"""
r791nffi.__doc__ = """Normalization factor for zAAP service time. Used to convert between real zAAP times and "normalized" zAAP times, i.e. the equivalent time on a standard CP. Multiply R791TIFA by this value and divide by 256 to calculate the normalized zAAP time

SMF Info
--------
    Field: `R791NFFI`
    Record: `SMF79S1`
    Map: `R791ELEM`

Normalization factor for zAAP service time. Used to convert between real zAAP times and "normalized" zAAP times, i.e. the equivalent time on a standard CP. Multiply R791TIFA by this value and divide by 256 to calculate the normalized zAAP time
"""

r791tsup : Final[Field] = Field(
    name='r791tsup',
    origin='R791TSUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""CPU time consumed on zIIPs (ASSB_TIME_ON_zIIP)

SMF Info
--------
    Field: `R791TSUP`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on zIIPs (ASSB_TIME_ON_zIIP)
"""
r791tsup.__doc__ = """CPU time consumed on zIIPs (ASSB_TIME_ON_zIIP)

SMF Info
--------
    Field: `R791TSUP`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on zIIPs (ASSB_TIME_ON_zIIP)
"""

r791tsuc : Final[Field] = Field(
    name='r791tsuc',
    origin='R791TSUC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""CPU time consumed on standard CPs by zIIP eligible work (ASSB_TIME_zIIP_ON_CP)

SMF Info
--------
    Field: `R791TSUC`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on standard CPs by zIIP eligible work (ASSB_TIME_zIIP_ON_CP)
"""
r791tsuc.__doc__ = """CPU time consumed on standard CPs by zIIP eligible work (ASSB_TIME_zIIP_ON_CP)

SMF Info
--------
    Field: `R791TSUC`
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU time consumed on standard CPs by zIIP eligible work (ASSB_TIME_zIIP_ON_CP)
"""

r791nffs : Final[Field] = Field(
    name='r791nffs',
    origin='R791NFFS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""Normalization factor for zIIP service time. Used to convert between real zIIP times and "normalized" zIIP times, i.e. the equivalent time on a standard CP. Multiply R791TSUP by this value and divide by 256 to calculate the normalized zIIP time.

SMF Info
--------
    Field: `R791NFFS`
    Record: `SMF79S1`
    Map: `R791ELEM`

Normalization factor for zIIP service time. Used to convert between real zIIP times and "normalized" zIIP times, i.e. the equivalent time on a standard CP. Multiply R791TSUP by this value and divide by 256 to calculate the normalized zIIP time.
"""
r791nffs.__doc__ = """Normalization factor for zIIP service time. Used to convert between real zIIP times and "normalized" zIIP times, i.e. the equivalent time on a standard CP. Multiply R791TSUP by this value and divide by 256 to calculate the normalized zIIP time.

SMF Info
--------
    Field: `R791NFFS`
    Record: `SMF79S1`
    Map: `R791ELEM`

Normalization factor for zIIP service time. Used to convert between real zIIP times and "normalized" zIIP times, i.e. the equivalent time on a standard CP. Multiply R791TSUP by this value and divide by 256 to calculate the normalized zIIP time.
"""

r791excw : Final[Field] = Field(
    name='r791excw',
    origin='R791EXCW',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""EXCP Count ( DWord )

SMF Info
--------
    Field: `R791EXCW`
    Record: `SMF79S1`
    Map: `R791ELEM`

EXCP Count ( DWord )
"""
r791excw.__doc__ = """EXCP Count ( DWord )

SMF Info
--------
    Field: `R791EXCW`
    Record: `SMF79S1`
    Map: `R791ELEM`

EXCP Count ( DWord )
"""

r791phta : Final[Field] = Field(
    name='r791phta',
    origin='R791PHTA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""zAAP-only equivalent of R791PHTM (ASSB_IFA_PHTM). This is normalized time

SMF Info
--------
    Field: `R791PHTA`
    Record: `SMF79S1`
    Map: `R791ELEM`

zAAP-only equivalent of R791PHTM (ASSB_IFA_PHTM). This is normalized time
"""
r791phta.__doc__ = """zAAP-only equivalent of R791PHTM (ASSB_IFA_PHTM). This is normalized time

SMF Info
--------
    Field: `R791PHTA`
    Record: `SMF79S1`
    Map: `R791ELEM`

zAAP-only equivalent of R791PHTM (ASSB_IFA_PHTM). This is normalized time
"""

r791phti : Final[Field] = Field(
    name='r791phti',
    origin='R791PHTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R791ELEM,
)
"""zIIP-only equivalent of R791PHTM (ASSB_zIIP_PHTM). This is normalized time

SMF Info
--------
    Field: `R791PHTI`
    Record: `SMF79S1`
    Map: `R791ELEM`

zIIP-only equivalent of R791PHTM (ASSB_zIIP_PHTM). This is normalized time
"""
r791phti.__doc__ = """zIIP-only equivalent of R791PHTM (ASSB_zIIP_PHTM). This is normalized time

SMF Info
--------
    Field: `R791PHTI`
    Record: `SMF79S1`
    Map: `R791ELEM`

zIIP-only equivalent of R791PHTM (ASSB_zIIP_PHTM). This is normalized time
"""

r791flg3 : Final[Field] = Field(
    name='r791flg3',
    origin='R791FLG3',
    type=FieldType.STRING,
    record=record,
    record_map=R791ELEM,
)
"""Additional flags

SMF Info
--------
    Field: `R791FLG3`
    Record: `SMF79S1`
    Map: `R791ELEM`

Additional flags
"""
r791flg3.__doc__ = """Additional flags

SMF Info
--------
    Field: `R791FLG3`
    Record: `SMF79S1`
    Map: `R791ELEM`

Additional flags
"""

r791cipg : Final[Field] = Field(
    name='r791cipg',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r791flg3,
    record=record,
    record_map=R791ELEM,
)
"""Service class was assigned by classification, or RESET SRVCLASS belongs to I/O priority group HIGH in the active policy(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Service class was assigned by classification, or RESET SRVCLASS belongs to I/O priority group HIGH in the active policy

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r791cipg.__doc__ = """Service class was assigned by classification, or RESET SRVCLASS belongs to I/O priority group HIGH in the active policy(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Service class was assigned by classification, or RESET SRVCLASS belongs to I/O priority group HIGH in the active policy

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r791iopg : Final[Field] = Field(
    name='r791iopg',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r791flg3,
    record=record,
    record_map=R791ELEM,
)
"""I/O priority group HIGH was assigned either to the address space or to transaction service classes served by the address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

I/O priority group HIGH was assigned either to the address space or to transaction service classes served by the address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r791iopg.__doc__ = """I/O priority group HIGH was assigned either to the address space or to transaction service classes served by the address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

I/O priority group HIGH was assigned either to the address space or to transaction service classes served by the address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r791itrg : Final[Field] = Field(
    name='r791itrg',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r791flg3,
    record=record,
    record_map=R791ELEM,
)
"""R791RGRP is the name of a tenant resource group and R791RCL is the name of a tenant report class(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

R791RGRP is the name of a tenant resource group and R791RCL is the name of a tenant report class

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r791itrg.__doc__ = """R791RGRP is the name of a tenant resource group and R791RCL is the name of a tenant report class(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

R791RGRP is the name of a tenant resource group and R791RCL is the name of a tenant report class

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r791iisp : Final[Field] = Field(
    name='r791iisp',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r791flg3,
    record=record,
    record_map=R791ELEM,
)
"""General purpose and specialty processor consumption is considered by WLM capping algorithms for this address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

General purpose and specialty processor consumption is considered by WLM capping algorithms for this address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r791iisp.__doc__ = """General purpose and specialty processor consumption is considered by WLM capping algorithms for this address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

General purpose and specialty processor consumption is considered by WLM capping algorithms for this address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r791irpb : Final[Field] = Field(
    name='r791irpb',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r791flg3,
    record=record,
    record_map=R791ELEM,
)
"""On = data in R791RPBoost is valid. Off = not valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = data in R791RPBoost is valid. Off = not valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r791irpb.__doc__ = """On = data in R791RPBoost is valid. Off = not valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

On = data in R791RPBoost is valid. Off = not valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r791rpboost : Final[Field] = Field(
    name='r791rpboost',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r791flg3,
    record=record,
    record_map=R791ELEM,
)
"""Address space matched a classification rule in the active policy which enables for recovery process boost. Only valid if R791IRPB = On.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space matched a classification rule in the active policy which enables for recovery process boost. Only valid if R791IRPB = On.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r791rpboost.__doc__ = """Address space matched a classification rule in the active policy which enables for recovery process boost. Only valid if R791IRPB = On.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

Address space matched a classification rule in the active policy which enables for recovery process boost. Only valid if R791IRPB = On.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r791ccimp : Final[Field] = Field(
    name='r791ccimp',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r791flg3,
    record=record,
    record_map=R791ELEM,
)
"""CPU protection was implicitly assigned(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU protection was implicitly assigned

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r791ccimp.__doc__ = """CPU protection was implicitly assigned(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r791flg3`(`R791FLG3`)
    Record: `SMF79S1`
    Map: `R791ELEM`

CPU protection was implicitly assigned

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
