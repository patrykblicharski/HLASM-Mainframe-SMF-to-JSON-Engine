# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 99 Subtype 12"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=99,
                                smf_subtype=12,
                                spec='SMF 99 Subtype 12',
                                post=['wlm.smf99s12.timestamp_correction'])
"""SMF 99 Subtype 12"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __vcm_lparcpshare_inline_post(df):
    return df.vcm_lparflags.str[0:3]


def __hd_action_no_unparking_no_free_capacity_inline_post(df):
    condition1 = df.mvs_busy >= df.vcm_mvsbusythrunpark
    condition2 = df.cec_free_capacity <= (2e6 * df.vcm_mvsbusythrunpark / 1600)
    return condition1 & condition2


def __hd_action_no_unparking_no_vl_inline_post(df):
    return df.vcm_diagincrdiscruprequ & (df.vl_parked == 0)


def __hd_action_unpark_inline_post(df):
    return df.vcm_diagincrdiscruprequ & df.vcm_diagincrdiscrunpark


def __hd_action_unpark_no_free_capacity_inline_post(df):
    return df.vcm_diagincrunusedcap & df.vcm_diagincrdiscruprequ & df.vcm_diagincrdiscrunpark


def __hd_action_unpark_no_free_capacity_capping_inline_post(df):
    return df.vcm_diagincrunusedcap & df.vcm_diagdecrprsmcapvhutil & df.vcm_diagincrdiscrunpark


def __hd_action_unpark_capping_inline_post(df):
    return df.vcm_diagdecrprsmcapvhutil & df.vcm_diagincrdiscrunpark


def __hd_action_park_mvs_busy_low_inline_post(df):
    return df.vcm_diagdecrbusythr & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ


def __hd_action_park_mvs_busy_low_capping_inline_post(df):
    return df.vcm_diagdecrprsmcapbusythr & df.vcm_diagdecrdiscrparequ


def __hd_action_park_less4_guaranteed_used_inline_post(df):
    return df.vcm_diagdecreffectnone & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ


def __hd_action_park_less10_guaranteed_used_inline_post(df):
    return df.vcm_diagdecreffectsmall & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ


def __hd_action_park_small_utilization_inline_post(df):
    return df.vcm_diagdecreffectthr & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ


def __hd_action_park_small_utilization_capping_inline_post(df):
    return df.vcm_diagdecrprsmcapeffectthr & df.vcm_diagdecrprsmcap & df.vcm_diagdecrdiscrparequ


def __hd_action_park_inline_post(df):
    return df.vcm_diagdecrefflowthr & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ


def __hd_action_park_capping_inline_post(df):
    return df.vcm_diagdecrprsmcapvhutil & df.vcm_diagdecrprsmcapeffectthr & df.vcm_diagdecrdiscrparequ


def __hd_action_explanation_inline_post(df):
    hd_action_unpark_filter = ~df.hd_action_unpark
    hd_action_unpark_capping_filter= ~df.hd_action_unpark_capping
    hd_action_park_filter= ~df.hd_action_park
    hd_action_park_capping_filter= ~df.hd_action_park_capping
    hd_action_no_unparking_no_free_capacity_filter= ~df.hd_action_no_unparking_no_free_capacity
    hd_action_no_unparking_no_vl_filter= ~df.hd_action_no_unparking_no_vl
    hd_action_unpark_no_free_capacity_filter= ~df.hd_action_unpark_no_free_capacity
    hd_action_unpark_no_free_capacity_capping_filter= ~df.hd_action_unpark_no_free_capacity_capping
    hd_action_park_mvs_busy_low_filter= ~df.hd_action_park_mvs_busy_low
    hd_action_park_mvs_busy_low_capping_filter= ~df.hd_action_park_mvs_busy_low_capping
    hd_action_park_less4_guaranteed_used_filter= ~df.hd_action_park_less4_guaranteed_used
    hd_action_park_less10_guaranteed_used_filter= ~df.hd_action_park_less10_guaranteed_used
    hd_action_park_small_utilization_filter= ~df.hd_action_park_small_utilization
    hd_action_park_small_utilization_capping_filter= ~df.hd_action_park_small_utilization_capping
    hd_action_explanation = df.hd_action_unpark.where(df.hd_action_unpark, '')
    hd_action_explanation =  hd_action_explanation.where(hd_action_unpark_filter, 'Unpark')
    hd_action_explanation =  hd_action_explanation.where( hd_action_unpark_capping_filter, 'Unpark / capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_filter, 'Park')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_capping_filter, 'Park /  capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_no_unparking_no_free_capacity_filter, 'no free capacity')
    hd_action_explanation =  hd_action_explanation.where( hd_action_no_unparking_no_vl_filter, 'no VLs')
    hd_action_explanation =  hd_action_explanation.where( hd_action_unpark_no_free_capacity_filter, 'no free capacity')
    hd_action_explanation =  hd_action_explanation.where( hd_action_unpark_no_free_capacity_capping_filter, 'no free capacity / capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_mvs_busy_low_filter, 'Low MVS busy')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_mvs_busy_low_capping_filter, 'Low MVS busy low / capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_less4_guaranteed_used_filter, '< 4% of guaranteed used')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_less10_guaranteed_used_filter, '< 10% of guaranteed used')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_small_utilization_filter, 'Small utilization')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_small_utilization_capping_filter, 'Small utilization / capping')
    return hd_action_explanation


def __hd_request_inline_post(df):
    hd_action_unpark_filter = ~df.hd_action_unpark
    hd_action_unpark_capping_filter= ~df.hd_action_unpark_capping
    hd_action_park_filter= ~df.hd_action_park
    hd_action_park_capping_filter= ~df.hd_action_park_capping
    hd_action_no_unparking_no_free_capacity_filter= ~df.hd_action_no_unparking_no_free_capacity
    hd_action_no_unparking_no_vl_filter= ~df.hd_action_no_unparking_no_vl
    hd_action_unpark_no_free_capacity_filter= ~df.hd_action_unpark_no_free_capacity
    hd_action_unpark_no_free_capacity_capping_filter= ~df.hd_action_unpark_no_free_capacity_capping
    hd_action_park_mvs_busy_low_filter= ~df.hd_action_park_mvs_busy_low
    hd_action_park_mvs_busy_low_capping_filter= ~df.hd_action_park_mvs_busy_low_capping
    hd_action_park_less4_guaranteed_used_filter= ~df.hd_action_park_less4_guaranteed_used
    hd_action_park_less10_guaranteed_used_filter= ~df.hd_action_park_less10_guaranteed_used
    hd_action_park_small_utilization_filter= ~df.hd_action_park_small_utilization
    hd_action_park_small_utilization_capping_filter= ~df.hd_action_park_small_utilization_capping
    hd_request  = df.hd_action_unpark.where(df.hd_action_unpark, '')
    hd_request  = hd_request.where(hd_action_unpark_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_unpark_capping_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_park_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_capping_filter, 'Park')
    hd_request  = hd_request.where( hd_action_no_unparking_no_free_capacity_filter, 'No unparking')
    hd_request  = hd_request.where( hd_action_no_unparking_no_vl_filter, 'No unparking')
    hd_request  = hd_request.where( hd_action_unpark_no_free_capacity_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_unpark_no_free_capacity_capping_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_park_mvs_busy_low_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_mvs_busy_low_capping_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_less4_guaranteed_used_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_less10_guaranteed_used_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_small_utilization_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_small_utilization_capping_filter, 'Park')
    return hd_request


def __cpu_total_inline_post(df):
    return df.cpu_vh + df.cpu_vm + df.cpu_vl


def __lpar_busy_inline_post(df):
    return df.lpar_capacity_used / df.cpu_total / 20000



SMF99_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_SDEF_MAP',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 self defining Section',
    post=None,
    record_mapping=False)
"""SMF99 self defining Section"""
SMF99_PRODUCT_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_PRODUCT_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Product Information Section',
    post=None,
    record_mapping=False)
"""SMF99 Product Information Section"""
SMF99_S12_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S12_SDEF_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Subtype 12 self defining section',
    post=None,
    record_mapping=False)
"""SMF99 Subtype 12 self defining section"""
SMF99_S12_HD_INT_HDR_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S12_HD_INT_HDR_MAP',
    record=record,
    parent=SMF99_S12_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 12 Header Data Section BASED(addr(smf_hdr_map) + SMF9912...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 12 Header Data Section BASED(addr(smf_hdr_map) + SMF9912..."""
SMF99_S12_HD_INT_CAP_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S12_HD_INT_CAP_MAP',
    record=record,
    parent=SMF99_S12_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 12 Capacity Data Section BASED(addr(smf_hdr_map) + SMF99...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 12 Capacity Data Section BASED(addr(smf_hdr_map) + SMF99..."""
SMF99_S12_HD_INT_PROC_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S12_HD_INT_PROC_MAP',
    record=record,
    parent=SMF99_S12_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 12 Processor Data Section BASED(addr(smf_hdr_map) + SMF9...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 12 Processor Data Section BASED(addr(smf_hdr_map) + SMF9..."""

date : Final[Field] = Field(
    name='date',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S12`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S12`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S12`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S12`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S12`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S12`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF99LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S12`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""
len.__doc__ = """Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S12`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF99SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S12`
    Map: Not part of a map

Segment descriptor (see record length field)
"""
seg.__doc__ = """Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S12`
    Map: Not part of a map

Segment descriptor (see record length field)
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF99FLG',
    type=FieldType.STRING,
    record=record,
)
"""System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S12`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""
flg.__doc__ = """System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S12`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""

stu : Final[Field] = Field(
    name='stu',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S12`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
stu.__doc__ = """Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S12`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF99RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S12`
    Map: Not part of a map

Record type 99
"""
rty.__doc__ = """Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S12`
    Map: Not part of a map

Record type 99
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S12`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""
tme.__doc__ = """Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S12`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S12`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""
dte.__doc__ = """Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S12`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF99SID',
    type=FieldType.STRING,
    record=record,
)
"""System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S12`
    Map: Not part of a map

System identification (from the SID parameter).
"""
sid.__doc__ = """System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S12`
    Map: Not part of a map

System identification (from the SID parameter).
"""

ssid : Final[Field] = Field(
    name='ssid',
    origin='SMF99SSID',
    type=FieldType.STRING,
    record=record,
)
"""Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S12`
    Map: Not part of a map

Sub System Identification
"""
ssid.__doc__ = """Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S12`
    Map: Not part of a map

Sub System Identification
"""

tid : Final[Field] = Field(
    name='tid',
    origin='SMF99TID',
    type=FieldType.INTEGER,
    record=record,
)
"""Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S12`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""
tid.__doc__ = """Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S12`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""

sdef_len : Final[Field] = Field(
    name='sdef_len',
    origin='SMF99_SDEF_LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S12`
    Map: Not part of a map

Length of self definition section
"""
sdef_len.__doc__ = """Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S12`
    Map: Not part of a map

Length of self definition section
"""

pof : Final[Field] = Field(
    name='pof',
    origin='SMF99POF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""
pof.__doc__ = """Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""

pln : Final[Field] = Field(
    name='pln',
    origin='SMF99PLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""
pln.__doc__ = """Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""

pon : Final[Field] = Field(
    name='pon',
    origin='SMF99PON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""
pon.__doc__ = """Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""

dof : Final[Field] = Field(
    name='dof',
    origin='SMF99DOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""
dof.__doc__ = """Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""

dln : Final[Field] = Field(
    name='dln',
    origin='SMF99DLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""
dln.__doc__ = """Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""

don : Final[Field] = Field(
    name='don',
    origin='SMF99DON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""
don.__doc__ = """Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S12`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""

vn2 : Final[Field] = Field(
    name='vn2',
    origin='SMF99VN2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""
vn2.__doc__ = """Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""

rvn : Final[Field] = Field(
    name='rvn',
    origin='SMF99RVN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""
rvn.__doc__ = """Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""

pnm : Final[Field] = Field(
    name='pnm',
    origin='SMF99PNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""
pnm.__doc__ = """Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""

slv : Final[Field] = Field(
    name='slv',
    origin='SMF99SLV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""
slv.__doc__ = """System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF99SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""
snm.__doc__ = """System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""

pflg : Final[Field] = Field(
    name='pflg',
    origin='SMF99PFLG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""
pflg.__doc__ = """Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""

record_incomplete : Final[Field] = Field(
    name='record_incomplete',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
record_incomplete.__doc__ = """Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

reasm_indicator : Final[Field] = Field(
    name='reasm_indicator',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
reasm_indicator.__doc__ = """Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S12`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

hd_int_hdr_offset : Final[Field] = Field(
    name='hd_int_hdr_offset',
    origin='SMF9912_HD_INT_HDR_OFFSET',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_SDEF_MAP,
)
"""Offset to header data section

SMF Info
--------
    Field: `SMF9912_HD_INT_HDR_OFFSET`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Offset to header data section
"""
hd_int_hdr_offset.__doc__ = """Offset to header data section

SMF Info
--------
    Field: `SMF9912_HD_INT_HDR_OFFSET`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Offset to header data section
"""

hd_int_hdr_length : Final[Field] = Field(
    name='hd_int_hdr_length',
    origin='SMF9912_HD_INT_HDR_LENGTH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_SDEF_MAP,
)
"""Length of header data section

SMF Info
--------
    Field: `SMF9912_HD_INT_HDR_LENGTH`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Length of header data section
"""
hd_int_hdr_length.__doc__ = """Length of header data section

SMF Info
--------
    Field: `SMF9912_HD_INT_HDR_LENGTH`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Length of header data section
"""

hd_int_hdr_number : Final[Field] = Field(
    name='hd_int_hdr_number',
    origin='SMF9912_HD_INT_HDR_NUMBER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_SDEF_MAP,
)
"""Number of header data sections

SMF Info
--------
    Field: `SMF9912_HD_INT_HDR_NUMBER`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Number of header data sections
"""
hd_int_hdr_number.__doc__ = """Number of header data sections

SMF Info
--------
    Field: `SMF9912_HD_INT_HDR_NUMBER`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Number of header data sections
"""

hd_int_cap_offset : Final[Field] = Field(
    name='hd_int_cap_offset',
    origin='SMF9912_HD_INT_CAP_OFFSET',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_SDEF_MAP,
)
"""Offset to capacity data section

SMF Info
--------
    Field: `SMF9912_HD_INT_CAP_OFFSET`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Offset to capacity data section
"""
hd_int_cap_offset.__doc__ = """Offset to capacity data section

SMF Info
--------
    Field: `SMF9912_HD_INT_CAP_OFFSET`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Offset to capacity data section
"""

hd_int_cap_length : Final[Field] = Field(
    name='hd_int_cap_length',
    origin='SMF9912_HD_INT_CAP_LENGTH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_SDEF_MAP,
)
"""Length of capacity data section

SMF Info
--------
    Field: `SMF9912_HD_INT_CAP_LENGTH`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Length of capacity data section
"""
hd_int_cap_length.__doc__ = """Length of capacity data section

SMF Info
--------
    Field: `SMF9912_HD_INT_CAP_LENGTH`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Length of capacity data section
"""

hd_int_cap_number : Final[Field] = Field(
    name='hd_int_cap_number',
    origin='SMF9912_HD_INT_CAP_NUMBER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_SDEF_MAP,
)
"""Number of capacity data sections

SMF Info
--------
    Field: `SMF9912_HD_INT_CAP_NUMBER`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Number of capacity data sections
"""
hd_int_cap_number.__doc__ = """Number of capacity data sections

SMF Info
--------
    Field: `SMF9912_HD_INT_CAP_NUMBER`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Number of capacity data sections
"""

hd_int_proc_offset : Final[Field] = Field(
    name='hd_int_proc_offset',
    origin='SMF9912_HD_INT_PROC_OFFSET',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_SDEF_MAP,
)
"""Offset to processor data section

SMF Info
--------
    Field: `SMF9912_HD_INT_PROC_OFFSET`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Offset to processor data section
"""
hd_int_proc_offset.__doc__ = """Offset to processor data section

SMF Info
--------
    Field: `SMF9912_HD_INT_PROC_OFFSET`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Offset to processor data section
"""

hd_int_proc_length : Final[Field] = Field(
    name='hd_int_proc_length',
    origin='SMF9912_HD_INT_PROC_LENGTH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_SDEF_MAP,
)
"""Length of processor data section

SMF Info
--------
    Field: `SMF9912_HD_INT_PROC_LENGTH`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Length of processor data section
"""
hd_int_proc_length.__doc__ = """Length of processor data section

SMF Info
--------
    Field: `SMF9912_HD_INT_PROC_LENGTH`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Length of processor data section
"""

hd_int_proc_number : Final[Field] = Field(
    name='hd_int_proc_number',
    origin='SMF9912_HD_INT_PROC_NUMBER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_SDEF_MAP,
)
"""Number of processor data sections

SMF Info
--------
    Field: `SMF9912_HD_INT_PROC_NUMBER`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Number of processor data sections
"""
hd_int_proc_number.__doc__ = """Number of processor data sections

SMF Info
--------
    Field: `SMF9912_HD_INT_PROC_NUMBER`
    Record: `SMF99S12`
    Map: `SMF99_S12_SDEF_MAP`

Number of processor data sections
"""

vcm_smf_sequ : Final[Field] = Field(
    name='vcm_smf_sequ',
    origin='SMF99C_VCM_SMF_SEQU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""HiperDispatch SMF sequence number

SMF Info
--------
    Field: `SMF99C_VCM_SMF_SEQU`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HiperDispatch SMF sequence number
"""
vcm_smf_sequ.__doc__ = """HiperDispatch SMF sequence number

SMF Info
--------
    Field: `SMF99C_VCM_SMF_SEQU`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HiperDispatch SMF sequence number
"""

vcm_errorcode : Final[Field] = Field(
    name='vcm_errorcode',
    origin='SMF99C_VCM_ERRORCODE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""HiperDispatch Error Code

SMF Info
--------
    Field: `SMF99C_VCM_ERRORCODE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HiperDispatch Error Code
"""
vcm_errorcode.__doc__ = """HiperDispatch Error Code

SMF Info
--------
    Field: `SMF99C_VCM_ERRORCODE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HiperDispatch Error Code
"""

vcm_diag204_flags : Final[Field] = Field(
    name='vcm_diag204_flags',
    origin='SMF99C_VCM_DIAG204_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Flags

SMF Info
--------
    Field: `SMF99C_VCM_DIAG204_FLAGS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Flags
"""
vcm_diag204_flags.__doc__ = """Flags

SMF Info
--------
    Field: `SMF99C_VCM_DIAG204_FLAGS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Flags
"""

vcm_d204_wlmcapping : Final[Field] = Field(
    name='vcm_d204_wlmcapping',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_diag204_flags,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""LPAR capped by WLM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diag204_flags`(`SMF99C_VCM_DIAG204_FLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR capped by WLM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_d204_wlmcapping.__doc__ = """LPAR capped by WLM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diag204_flags`(`SMF99C_VCM_DIAG204_FLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR capped by WLM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_d204_lparcapping : Final[Field] = Field(
    name='vcm_d204_lparcapping',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_diag204_flags,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""LPAR capped by customer(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diag204_flags`(`SMF99C_VCM_DIAG204_FLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR capped by customer

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_d204_lparcapping.__doc__ = """LPAR capped by customer(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diag204_flags`(`SMF99C_VCM_DIAG204_FLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR capped by customer

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_d204_waitcompletion : Final[Field] = Field(
    name='vcm_d204_waitcompletion',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_diag204_flags,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""WaitCompletion(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diag204_flags`(`SMF99C_VCM_DIAG204_FLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

WaitCompletion

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vcm_d204_waitcompletion.__doc__ = """WaitCompletion(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diag204_flags`(`SMF99C_VCM_DIAG204_FLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

WaitCompletion

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

vcm_d204_phwgtisneg : Final[Field] = Field(
    name='vcm_d204_phwgtisneg',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=vcm_diag204_flags,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Phantom weight type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diag204_flags`(`SMF99C_VCM_DIAG204_FLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Phantom weight type

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
vcm_d204_phwgtisneg.__doc__ = """Phantom weight type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diag204_flags`(`SMF99C_VCM_DIAG204_FLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Phantom weight type

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

vcm_interval_len : Final[Field] = Field(
    name='vcm_interval_len',
    origin='SMF99C_VCM_INTERVAL_LEN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Measured interval length in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_INTERVAL_LEN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Measured interval length in microseconds
"""
vcm_interval_len.__doc__ = """Measured interval length in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_INTERVAL_LEN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Measured interval length in microseconds
"""

vcm_lparphysprocshr : Final[Field] = Field(
    name='vcm_lparphysprocshr',
    origin='SMF99C_VCM_LPARPHYSPROCSHR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""LPAR physical processor share for general CPUs/Core scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_LPARPHYSPROCSHR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR physical processor share for general CPUs/Core scaled by 256
"""
vcm_lparphysprocshr.__doc__ = """LPAR physical processor share for general CPUs/Core scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_LPARPHYSPROCSHR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR physical processor share for general CPUs/Core scaled by 256
"""

vcm_interval_tod : Final[Field] = Field(
    name='vcm_interval_tod',
    origin='SMF99C_VCM_INTERVAL_TOD',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Date and time when HiperDispatch code got control

SMF Info
--------
    Field: `SMF99C_VCM_INTERVAL_TOD`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Date and time when HiperDispatch code got control
"""
vcm_interval_tod.__doc__ = """Date and time when HiperDispatch code got control

SMF Info
--------
    Field: `SMF99C_VCM_INTERVAL_TOD`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Date and time when HiperDispatch code got control
"""

vcm_flag1 : Final[Field] = Field(
    name='vcm_flag1',
    origin='SMF99C_VCM_FLAG1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""HD 1st flag byte

SMF Info
--------
    Field: `SMF99C_VCM_FLAG1`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HD 1st flag byte
"""
vcm_flag1.__doc__ = """HD 1st flag byte

SMF Info
--------
    Field: `SMF99C_VCM_FLAG1`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HD 1st flag byte
"""

vcm_topochanged : Final[Field] = Field(
    name='vcm_topochanged',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""topology has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

topology has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_topochanged.__doc__ = """topology has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

topology has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_rebuildans : Final[Field] = Field(
    name='vcm_rebuildans',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""rebuild affinity nodes(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

rebuild affinity nodes

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_rebuildans.__doc__ = """rebuild affinity nodes(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

rebuild affinity nodes

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_topochg_hp : Final[Field] = Field(
    name='vcm_topochg_hp',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""honor priority has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

honor priority has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vcm_topochg_hp.__doc__ = """honor priority has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

honor priority has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

vcm_topochg_wuqe : Final[Field] = Field(
    name='vcm_topochg_wuqe',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""dispatcher WUQ error(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

dispatcher WUQ error

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
vcm_topochg_wuqe.__doc__ = """dispatcher WUQ error(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

dispatcher WUQ error

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

vcm_procspeedchg : Final[Field] = Field(
    name='vcm_procspeedchg',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""processor speed change(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

processor speed change

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
vcm_procspeedchg.__doc__ = """processor speed change(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99C_VCM_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

processor speed change

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vcm_flag2 : Final[Field] = Field(
    name='vcm_flag2',
    origin='SMF99C_VCM_FLAG2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""HD 2nd flag byte

SMF Info
--------
    Field: `SMF99C_VCM_FLAG2`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HD 2nd flag byte
"""
vcm_flag2.__doc__ = """HD 2nd flag byte

SMF Info
--------
    Field: `SMF99C_VCM_FLAG2`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HD 2nd flag byte
"""

vcm_ceccapvalid : Final[Field] = Field(
    name='vcm_ceccapvalid',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""CEC capacities are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

CEC capacities are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_ceccapvalid.__doc__ = """CEC capacities are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

CEC capacities are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_lparcapvalid : Final[Field] = Field(
    name='vcm_lparcapvalid',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""LPAR capacities are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR capacities are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_lparcapvalid.__doc__ = """LPAR capacities are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR capacities are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_old_state : Final[Field] = Field(
    name='vcm_old_state',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""old VCM state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

old VCM state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vcm_old_state.__doc__ = """old VCM state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

old VCM state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

vcm_mpwq_updated : Final[Field] = Field(
    name='vcm_mpwq_updated',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""dispatcher affinity was updated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

dispatcher affinity was updated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
vcm_mpwq_updated.__doc__ = """dispatcher affinity was updated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

dispatcher affinity was updated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vcm_ptf_switched : Final[Field] = Field(
    name='vcm_ptf_switched',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""PTF was issued to initiate a switch into the opposite mode. However, the PTF return info tells us that we are already in the requested mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

PTF was issued to initiate a switch into the opposite mode. However, the PTF return info tells us that we are already in the requested mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vcm_ptf_switched.__doc__ = """PTF was issued to initiate a switch into the opposite mode. However, the PTF return info tells us that we are already in the requested mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

PTF was issued to initiate a switch into the opposite mode. However, the PTF return info tells us that we are already in the requested mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

vcm_transition : Final[Field] = Field(
    name='vcm_transition',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""VCM is transitioning to/from vertical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

VCM is transitioning to/from vertical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
vcm_transition.__doc__ = """VCM is transitioning to/from vertical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99C_VCM_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

VCM is transitioning to/from vertical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

vcm_flag3 : Final[Field] = Field(
    name='vcm_flag3',
    origin='SMF99C_VCM_FLAG3',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""HD 3rd flag byte

SMF Info
--------
    Field: `SMF99C_VCM_FLAG3`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HD 3rd flag byte
"""
vcm_flag3.__doc__ = """HD 3rd flag byte

SMF Info
--------
    Field: `SMF99C_VCM_FLAG3`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HD 3rd flag byte
"""

vcm_topofac : Final[Field] = Field(
    name='vcm_topofac',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_flag3,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""topology facility installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

topology facility installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_topofac.__doc__ = """topology facility installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

topology facility installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_ifafac : Final[Field] = Field(
    name='vcm_ifafac',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_flag3,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""IFA facility installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

IFA facility installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_ifafac.__doc__ = """IFA facility installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

IFA facility installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_lpardedicps : Final[Field] = Field(
    name='vcm_lpardedicps',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_flag3,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""LPAR has only dedicated CPUs/Cores(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR has only dedicated CPUs/Cores

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vcm_lpardedicps.__doc__ = """LPAR has only dedicated CPUs/Cores(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

LPAR has only dedicated CPUs/Cores

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

vcm_cmset_active : Final[Field] = Field(
    name='vcm_cmset_active',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=vcm_flag3,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Cross memory set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Cross memory set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
vcm_cmset_active.__doc__ = """Cross memory set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Cross memory set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

vcm_newconttle : Final[Field] = Field(
    name='vcm_newconttle',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=vcm_flag3,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""new container TLE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

new container TLE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
vcm_newconttle.__doc__ = """new container TLE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

new container TLE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vcm_smf_topochg : Final[Field] = Field(
    name='vcm_smf_topochg',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=vcm_flag3,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Write TopoChg section(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Write TopoChg section

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
vcm_smf_topochg.__doc__ = """Write TopoChg section(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag3`(`SMF99C_VCM_FLAG3`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Write TopoChg section

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

vcm_flag4 : Final[Field] = Field(
    name='vcm_flag4',
    origin='SMF99C_VCM_FLAG4',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""HD 4th flag byte

SMF Info
--------
    Field: `SMF99C_VCM_FLAG4`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HD 4th flag byte
"""
vcm_flag4.__doc__ = """HD 4th flag byte

SMF Info
--------
    Field: `SMF99C_VCM_FLAG4`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HD 4th flag byte
"""

vcm_old_ifa_hp : Final[Field] = Field(
    name='vcm_old_ifa_hp',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_flag4,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""IFA honor priority state of previous interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag4`(`SMF99C_VCM_FLAG4`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

IFA honor priority state of previous interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_old_ifa_hp.__doc__ = """IFA honor priority state of previous interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag4`(`SMF99C_VCM_FLAG4`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

IFA honor priority state of previous interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_old_sup_hp : Final[Field] = Field(
    name='vcm_old_sup_hp',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_flag4,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""SUP honor priority state of previous interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag4`(`SMF99C_VCM_FLAG4`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

SUP honor priority state of previous interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_old_sup_hp.__doc__ = """SUP honor priority state of previous interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag4`(`SMF99C_VCM_FLAG4`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

SUP honor priority state of previous interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

mt_flag1 : Final[Field] = Field(
    name='mt_flag1',
    origin='SMF99C_MT_FLAG1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""1st MT flag byte

SMF Info
--------
    Field: `SMF99C_MT_FLAG1`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

1st MT flag byte
"""
mt_flag1.__doc__ = """1st MT flag byte

SMF Info
--------
    Field: `SMF99C_MT_FLAG1`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

1st MT flag byte
"""

mt_procascore : Final[Field] = Field(
    name='mt_procascore',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=mt_flag1,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Processor resource is viewed as a CPU core(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag1`(`SMF99C_MT_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Processor resource is viewed as a CPU core

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
mt_procascore.__doc__ = """Processor resource is viewed as a CPU core(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag1`(`SMF99C_MT_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Processor resource is viewed as a CPU core

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

mt_multicpuspercore : Final[Field] = Field(
    name='mt_multicpuspercore',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=mt_flag1,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Multiple CPUs defined within a CPU Core(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag1`(`SMF99C_MT_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Multiple CPUs defined within a CPU Core

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
mt_multicpuspercore.__doc__ = """Multiple CPUs defined within a CPU Core(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag1`(`SMF99C_MT_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Multiple CPUs defined within a CPU Core

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

mt_badrv_ready_for_mt : Final[Field] = Field(
    name='mt_badrv_ready_for_mt',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=mt_flag1,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""HiperDispatch is now ready for MT mode switches(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag1`(`SMF99C_MT_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HiperDispatch is now ready for MT mode switches

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
mt_badrv_ready_for_mt.__doc__ = """HiperDispatch is now ready for MT mode switches(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag1`(`SMF99C_MT_FLAG1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HiperDispatch is now ready for MT mode switches

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

mt_flag2 : Final[Field] = Field(
    name='mt_flag2',
    origin='SMF99C_MT_FLAG2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""2nd MT flag byte

SMF Info
--------
    Field: `SMF99C_MT_FLAG2`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

2nd MT flag byte
"""
mt_flag2.__doc__ = """2nd MT flag byte

SMF Info
--------
    Field: `SMF99C_MT_FLAG2`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

2nd MT flag byte
"""

mt_modechgduetostsi_pend : Final[Field] = Field(
    name='mt_modechgduetostsi_pend',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=mt_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""MT mode change is pending due to STSI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

MT mode change is pending due to STSI

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
mt_modechgduetostsi_pend.__doc__ = """MT mode change is pending due to STSI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

MT mode change is pending due to STSI

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

mt_sup_recovery_pend : Final[Field] = Field(
    name='mt_sup_recovery_pend',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=mt_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""The supervisor requested MT reconfiguration is pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

The supervisor requested MT reconfiguration is pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
mt_sup_recovery_pend.__doc__ = """The supervisor requested MT reconfiguration is pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

The supervisor requested MT reconfiguration is pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

mt_modechgduetohismt_pend : Final[Field] = Field(
    name='mt_modechgduetohismt_pend',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=mt_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""MT mode change is pending due to HISMT recovery(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

MT mode change is pending due to HISMT recovery

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
mt_modechgduetohismt_pend.__doc__ = """MT mode change is pending due to HISMT recovery(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

MT mode change is pending due to HISMT recovery

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

mt_modechgduetowaitcmp_pend : Final[Field] = Field(
    name='mt_modechgduetowaitcmp_pend',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=mt_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""MT mode change is pending due to Wait completion status change(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

MT mode change is pending due to Wait completion status change

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
mt_modechgduetowaitcmp_pend.__doc__ = """MT mode change is pending due to Wait completion status change(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

MT mode change is pending due to Wait completion status change

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

mt_modechgduetosupmt1_pend : Final[Field] = Field(
    name='mt_modechgduetosupmt1_pend',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=mt_flag2,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""MT mode change is pending due to supervisor request(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

MT mode change is pending due to supervisor request

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
mt_modechgduetosupmt1_pend.__doc__ = """MT mode change is pending due to supervisor request(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mt_flag2`(`SMF99C_MT_FLAG2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

MT mode change is pending due to supervisor request

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vcm_current_state : Final[Field] = Field(
    name='vcm_current_state',
    origin='SMF99C_VCM_CURRENT_STATE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Current HiperDispatch state

SMF Info
--------
    Field: `SMF99C_VCM_CURRENT_STATE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Current HiperDispatch state
"""
vcm_current_state.__doc__ = """Current HiperDispatch state

SMF Info
--------
    Field: `SMF99C_VCM_CURRENT_STATE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Current HiperDispatch state
"""

vcm_previous_state : Final[Field] = Field(
    name='vcm_previous_state',
    origin='SMF99C_VCM_PREVIOUS_STATE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Previous HiperDispatch state

SMF Info
--------
    Field: `SMF99C_VCM_PREVIOUS_STATE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Previous HiperDispatch state
"""
vcm_previous_state.__doc__ = """Previous HiperDispatch state

SMF Info
--------
    Field: `SMF99C_VCM_PREVIOUS_STATE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Previous HiperDispatch state
"""

vcm_restart_ctr : Final[Field] = Field(
    name='vcm_restart_ctr',
    origin='SMF99C_VCM_RESTART_CTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Recovery restart counter

SMF Info
--------
    Field: `SMF99C_VCM_RESTART_CTR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Recovery restart counter
"""
vcm_restart_ctr.__doc__ = """Recovery restart counter

SMF Info
--------
    Field: `SMF99C_VCM_RESTART_CTR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Recovery restart counter
"""

vcm_hardwaregroupname : Final[Field] = Field(
    name='vcm_hardwaregroupname',
    origin='SMF99C_VCM_HARDWAREGROUPNAME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""HardwareGroupname

SMF Info
--------
    Field: `SMF99C_VCM_HARDWAREGROUPNAME`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HardwareGroupname
"""
vcm_hardwaregroupname.__doc__ = """HardwareGroupname

SMF Info
--------
    Field: `SMF99C_VCM_HARDWAREGROUPNAME`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

HardwareGroupname
"""

c_vcm_srb_flags : Final[Field] = Field(
    name='c_vcm_srb_flags',
    origin='SMF99C_VCM_SRB_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99C_VCM_SRB_FLAGS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

For IBM use only
"""
c_vcm_srb_flags.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99C_VCM_SRB_FLAGS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

For IBM use only
"""

vcm_diagmpwq : Final[Field] = Field(
    name='vcm_diagmpwq',
    origin='SMF99C_VCM_DIAGMPWQ',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Data element of diagnostic MPWQ data array

SMF Info
--------
    Field: `SMF99C_VCM_DIAGMPWQ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Data element of diagnostic MPWQ data array
"""
vcm_diagmpwq.__doc__ = """Data element of diagnostic MPWQ data array

SMF Info
--------
    Field: `SMF99C_VCM_DIAGMPWQ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Data element of diagnostic MPWQ data array
"""

vcm_diagecpx : Final[Field] = Field(
    name='vcm_diagecpx',
    origin='SMF99C_VCM_DIAGECPX',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_HDR_MAP,
)
"""Data element of diagnostic ECPX data array

SMF Info
--------
    Field: `SMF99C_VCM_DIAGECPX`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Data element of diagnostic ECPX data array
"""
vcm_diagecpx.__doc__ = """Data element of diagnostic ECPX data array

SMF Info
--------
    Field: `SMF99C_VCM_DIAGECPX`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_HDR_MAP`

Data element of diagnostic ECPX data array
"""

hd_int_cap_proctype : Final[Field] = Field(
    name='hd_int_cap_proctype',
    origin='SMF99C_HD_INT_CAP_PROCTYPE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""SMF99.12 capacity data processor type

SMF Info
--------
    Field: `SMF99C_HD_INT_CAP_PROCTYPE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

SMF99.12 capacity data processor type
"""
hd_int_cap_proctype.__doc__ = """SMF99.12 capacity data processor type

SMF Info
--------
    Field: `SMF99C_HD_INT_CAP_PROCTYPE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

SMF99.12 capacity data processor type
"""

vcm_lparflags : Final[Field] = Field(
    name='vcm_lparflags',
    origin='SMF99C_VCM_LPARFLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""LPAR Status Flags

SMF Info
--------
    Field: `SMF99C_VCM_LPARFLAGS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

LPAR Status Flags
"""
vcm_lparflags.__doc__ = """LPAR Status Flags

SMF Info
--------
    Field: `SMF99C_VCM_LPARFLAGS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

LPAR Status Flags
"""

vcm_lparcpshareok : Final[Field] = Field(
    name='vcm_lparcpshareok',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_lparflags,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""The physical CPU/Core share matches the number and polarization of the CPUs/Cores passed by the topology information(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_lparflags`(`SMF99C_VCM_LPARFLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

The physical CPU/Core share matches the number and polarization of the CPUs/Cores passed by the topology information

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_lparcpshareok.__doc__ = """The physical CPU/Core share matches the number and polarization of the CPUs/Cores passed by the topology information(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_lparflags`(`SMF99C_VCM_LPARFLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

The physical CPU/Core share matches the number and polarization of the CPUs/Cores passed by the topology information

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_lparcpsharehi : Final[Field] = Field(
    name='vcm_lparcpsharehi',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_lparflags,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""The physical CPU/Core share is higher than the number of VHs and VMs passed by the topology info(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_lparflags`(`SMF99C_VCM_LPARFLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

The physical CPU/Core share is higher than the number of VHs and VMs passed by the topology info

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_lparcpsharehi.__doc__ = """The physical CPU/Core share is higher than the number of VHs and VMs passed by the topology info(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_lparflags`(`SMF99C_VCM_LPARFLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

The physical CPU/Core share is higher than the number of VHs and VMs passed by the topology info

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_lparcpsharelo : Final[Field] = Field(
    name='vcm_lparcpsharelo',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_lparflags,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""The physical CPU/Core share is lower than the number of VHs and VMs passed by the topology info(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_lparflags`(`SMF99C_VCM_LPARFLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

The physical CPU/Core share is lower than the number of VHs and VMs passed by the topology info

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vcm_lparcpsharelo.__doc__ = """The physical CPU/Core share is lower than the number of VHs and VMs passed by the topology info(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_lparflags`(`SMF99C_VCM_LPARFLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

The physical CPU/Core share is lower than the number of VHs and VMs passed by the topology info

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

vcm_mvsbusydynathrunpark : Final[Field] = Field(
    name='vcm_mvsbusydynathrunpark',
    origin='SMF99C_VCM_MVSBUSYDYNATHRUNPARK',
    post='core.scale',
    post_param=16,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Dynamic MvsBusy threshhold for unparking scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYDYNATHRUNPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Dynamic MvsBusy threshhold for unparking scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""
vcm_mvsbusydynathrunpark.__doc__ = """Dynamic MvsBusy threshhold for unparking scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYDYNATHRUNPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Dynamic MvsBusy threshhold for unparking scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""

vcm_mvsbusydynathrpark : Final[Field] = Field(
    name='vcm_mvsbusydynathrpark',
    origin='SMF99C_VCM_MVSBUSYDYNATHRPARK',
    post='core.scale',
    post_param=16,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Dynamic MvsBusy threshhold for parking scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYDYNATHRPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Dynamic MvsBusy threshhold for parking scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""
vcm_mvsbusydynathrpark.__doc__ = """Dynamic MvsBusy threshhold for parking scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYDYNATHRPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Dynamic MvsBusy threshhold for parking scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""

vcm_mvsbusythrunpark : Final[Field] = Field(
    name='vcm_mvsbusythrunpark',
    origin='SMF99C_VCM_MVSBUSYTHRUNPARK',
    post='core.scale',
    post_param=16,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MvsBusy threshhold for unparking scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYTHRUNPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MvsBusy threshhold for unparking scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""
vcm_mvsbusythrunpark.__doc__ = """MvsBusy threshhold for unparking scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYTHRUNPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MvsBusy threshhold for unparking scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""

vcm_mvsbusythrpark : Final[Field] = Field(
    name='vcm_mvsbusythrpark',
    origin='SMF99C_VCM_MVSBUSYTHRPARK',
    post='core.scale',
    post_param=16,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MvsBusy threshhold for parking scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYTHRPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MvsBusy threshhold for parking scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""
vcm_mvsbusythrpark.__doc__ = """MvsBusy threshhold for parking scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYTHRPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MvsBusy threshhold for parking scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""

mvs_busy : Final[Field] = Field(
    name='mvs_busy',
    origin='SMF99C_VCM_MVSBUSY',
    post='core.scale',
    post_param=16,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Average CPU usage scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSY`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Average CPU usage scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""
mvs_busy.__doc__ = """Average CPU usage scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSY`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Average CPU usage scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""

lpar_capacity_used : Final[Field] = Field(
    name='lpar_capacity_used',
    origin='SMF99C_VCM_LPARCAPUSEDADJ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Used LPAR capacity in microseconds, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used LPAR capacity in microseconds, adjusted to the scheduled VCM interval length
"""
lpar_capacity_used.__doc__ = """Used LPAR capacity in microseconds, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used LPAR capacity in microseconds, adjusted to the scheduled VCM interval length
"""

vcm_lparcapused : Final[Field] = Field(
    name='vcm_lparcapused',
    origin='SMF99C_VCM_LPARCAPUSED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Used LPAR capacity in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used LPAR capacity in microseconds
"""
vcm_lparcapused.__doc__ = """Used LPAR capacity in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used LPAR capacity in microseconds
"""

lpar_cap_used_non_guaranteed : Final[Field] = Field(
    name='lpar_cap_used_non_guaranteed',
    origin='SMF99C_VCM_LPARCAPUSEDDISCR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Used capacity of the non-guaranteed capacity (partially VM and unparked VLs) in microseconds, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDDISCR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used capacity of the non-guaranteed capacity (partially VM and unparked VLs) in microseconds, adjusted to the scheduled VCM interval length
"""
lpar_cap_used_non_guaranteed.__doc__ = """Used capacity of the non-guaranteed capacity (partially VM and unparked VLs) in microseconds, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDDISCR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used capacity of the non-guaranteed capacity (partially VM and unparked VLs) in microseconds, adjusted to the scheduled VCM interval length
"""

lpar_capacity_used_vm_vl : Final[Field] = Field(
    name='lpar_capacity_used_vm_vl',
    origin='SMF99C_VCM_LPARCAPUSEDVMVL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Used capacity on VMs and VLs, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDVMVL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used capacity on VMs and VLs, adjusted to the scheduled VCM interval length
"""
lpar_capacity_used_vm_vl.__doc__ = """Used capacity on VMs and VLs, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDVMVL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used capacity on VMs and VLs, adjusted to the scheduled VCM interval length
"""

vcm_lowcecmaxup : Final[Field] = Field(
    name='vcm_lowcecmaxup',
    origin='SMF99C_VCM_LOWCECMAXUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Maximum number of VLs unparked if low CEC utilization

SMF Info
--------
    Field: `SMF99C_VCM_LOWCECMAXUP`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Maximum number of VLs unparked if low CEC utilization
"""
vcm_lowcecmaxup.__doc__ = """Maximum number of VLs unparked if low CEC utilization

SMF Info
--------
    Field: `SMF99C_VCM_LOWCECMAXUP`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Maximum number of VLs unparked if low CEC utilization
"""

vcm_lowcecmvsbusy : Final[Field] = Field(
    name='vcm_lowcecmvsbusy',
    origin='SMF99C_VCM_LOWCECMVSBUSY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Park threshold for low CEC utilization scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_LOWCECMVSBUSY`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park threshold for low CEC utilization scaled by 16
"""
vcm_lowcecmvsbusy.__doc__ = """Park threshold for low CEC utilization scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_LOWCECMVSBUSY`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park threshold for low CEC utilization scaled by 16
"""

vm_vl_capacity_of_allocated : Final[Field] = Field(
    name='vm_vl_capacity_of_allocated',
    origin='SMF99C_VCM_LPARCAPVMVLUSEDOFALLOC',
    post='core.scale',
    post_param=256,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Percentage used of allocated VM + VL capacity, scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPVMVLUSEDOFALLOC`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Percentage used of allocated VM + VL capacity, scaled by 256

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `256`
"""
vm_vl_capacity_of_allocated.__doc__ = """Percentage used of allocated VM + VL capacity, scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPVMVLUSEDOFALLOC`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Percentage used of allocated VM + VL capacity, scaled by 256

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `256`
"""

vm_vl_cap_above_guaranteed : Final[Field] = Field(
    name='vm_vl_cap_above_guaranteed',
    origin='SMF99C_VCM_LPARCAPVMVLUSEDOVERGUARAN',
    post='core.scale',
    post_param=256,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Percentage of guaranteed VM capacity used by VM + VL, scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPVMVLUSEDOVERGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Percentage of guaranteed VM capacity used by VM + VL, scaled by 256

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `256`
"""
vm_vl_cap_above_guaranteed.__doc__ = """Percentage of guaranteed VM capacity used by VM + VL, scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPVMVLUSEDOVERGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Percentage of guaranteed VM capacity used by VM + VL, scaled by 256

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `256`
"""

vm_vl_allocated_capacity : Final[Field] = Field(
    name='vm_vl_allocated_capacity',
    origin='SMF99C_VCM_LPARCAPALLOCVMVL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Allocated LPAR capacity on VMs and VLs in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPALLOCVMVL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Allocated LPAR capacity on VMs and VLs in microseconds
"""
vm_vl_allocated_capacity.__doc__ = """Allocated LPAR capacity on VMs and VLs in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPALLOCVMVL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Allocated LPAR capacity on VMs and VLs in microseconds
"""

lpar_capacity_allocated : Final[Field] = Field(
    name='lpar_capacity_allocated',
    origin='SMF99C_VCM_LPARCAPALLOC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Allocated LPAR capcacity in microseconds. The allocated capacity is provided by the guaranteed capacity on VHs and VMs, plus extra capacity on VMs and unparked VLs

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPALLOC`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Allocated LPAR capcacity in microseconds. The allocated capacity is provided by the guaranteed capacity on VHs and VMs, plus extra capacity on VMs and unparked VLs
"""
lpar_capacity_allocated.__doc__ = """Allocated LPAR capcacity in microseconds. The allocated capacity is provided by the guaranteed capacity on VHs and VMs, plus extra capacity on VMs and unparked VLs

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPALLOC`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Allocated LPAR capcacity in microseconds. The allocated capacity is provided by the guaranteed capacity on VHs and VMs, plus extra capacity on VMs and unparked VLs
"""

lpar_capacity_non_guaranteed : Final[Field] = Field(
    name='lpar_capacity_non_guaranteed',
    origin='SMF99C_VCM_LPARCAPNONGUARAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Non guaranteed LPAR capacity in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPNONGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Non guaranteed LPAR capacity in microseconds
"""
lpar_capacity_non_guaranteed.__doc__ = """Non guaranteed LPAR capacity in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPNONGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Non guaranteed LPAR capacity in microseconds
"""

lpar_capacity_guaranteed_vm : Final[Field] = Field(
    name='lpar_capacity_guaranteed_vm',
    origin='SMF99C_VCM_LPARCAPMEDGUARAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Guaranteed LPAR capacity on VMs in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPMEDGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Guaranteed LPAR capacity on VMs in microseconds
"""
lpar_capacity_guaranteed_vm.__doc__ = """Guaranteed LPAR capacity on VMs in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPMEDGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Guaranteed LPAR capacity on VMs in microseconds
"""

lpar_capacity_guaranteed : Final[Field] = Field(
    name='lpar_capacity_guaranteed',
    origin='SMF99C_VCM_LPARCAPGUARAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Guaranteed LPAR capcacity in microseconds. This value is calculated from the physical processor share of this LPAR.

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Guaranteed LPAR capcacity in microseconds. This value is calculated from the physical processor share of this LPAR.
"""
lpar_capacity_guaranteed.__doc__ = """Guaranteed LPAR capcacity in microseconds. This value is calculated from the physical processor share of this LPAR.

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Guaranteed LPAR capcacity in microseconds. This value is calculated from the physical processor share of this LPAR.
"""

lpar_busy_projected : Final[Field] = Field(
    name='lpar_busy_projected',
    origin='SMF99C_VCM_MVSBUSYPROJECTED',
    post='core.scale',
    post_param=16,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Projected MvsBusy, scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYPROJECTED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Projected MvsBusy, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""
lpar_busy_projected.__doc__ = """Projected MvsBusy, scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_MVSBUSYPROJECTED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Projected MvsBusy, scaled by 16

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `16`
"""

lpar_capacity_share_unused : Final[Field] = Field(
    name='lpar_capacity_share_unused',
    origin='SMF99C_VCM_LPARUNUSEDCAPSHARE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Unused capacity share for this LPAR in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARUNUSEDCAPSHARE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Unused capacity share for this LPAR in microseconds
"""
lpar_capacity_share_unused.__doc__ = """Unused capacity share for this LPAR in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARUNUSEDCAPSHARE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Unused capacity share for this LPAR in microseconds
"""

lpar_capacity_unused : Final[Field] = Field(
    name='lpar_capacity_unused',
    origin='SMF99C_VCM_LPARUNUSEDCAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Unused LPAR capacity in microseconds, including the unused capacity share for this LPAR

SMF Info
--------
    Field: `SMF99C_VCM_LPARUNUSEDCAP`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Unused LPAR capacity in microseconds, including the unused capacity share for this LPAR
"""
lpar_capacity_unused.__doc__ = """Unused LPAR capacity in microseconds, including the unused capacity share for this LPAR

SMF Info
--------
    Field: `SMF99C_VCM_LPARUNUSEDCAP`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Unused LPAR capacity in microseconds, including the unused capacity share for this LPAR
"""

vcm_cecutilthrpark : Final[Field] = Field(
    name='vcm_cecutilthrpark',
    origin='SMF99C_VCM_CECUTILTHRPARK',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""CEC utilization threshold for parking scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_CECUTILTHRPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

CEC utilization threshold for parking scaled by 256
"""
vcm_cecutilthrpark.__doc__ = """CEC utilization threshold for parking scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_CECUTILTHRPARK`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

CEC utilization threshold for parking scaled by 256
"""

vcm_pupdispl : Final[Field] = Field(
    name='vcm_pupdispl',
    origin='SMF99C_VCM_PUPDISPL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Park / Unpark displacement. Scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_PUPDISPL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park / Unpark displacement. Scaled by 16
"""
vcm_pupdispl.__doc__ = """Park / Unpark displacement. Scaled by 16

SMF Info
--------
    Field: `SMF99C_VCM_PUPDISPL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park / Unpark displacement. Scaled by 16
"""

vcm_d204_totalw : Final[Field] = Field(
    name='vcm_d204_totalw',
    origin='SMF99C_VCM_D204_TOTALW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Total LPAR weight

SMF Info
--------
    Field: `SMF99C_VCM_D204_TOTALW`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total LPAR weight
"""
vcm_d204_totalw.__doc__ = """Total LPAR weight

SMF Info
--------
    Field: `SMF99C_VCM_D204_TOTALW`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total LPAR weight
"""

vcm_d204_currentw : Final[Field] = Field(
    name='vcm_d204_currentw',
    origin='SMF99C_VCM_D204_CURRENTW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Current LPAR weight

SMF Info
--------
    Field: `SMF99C_VCM_D204_CURRENTW`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Current LPAR weight
"""
vcm_d204_currentw.__doc__ = """Current LPAR weight

SMF Info
--------
    Field: `SMF99C_VCM_D204_CURRENTW`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Current LPAR weight
"""

vcm_d204_wrkcurrw : Final[Field] = Field(
    name='vcm_d204_wrkcurrw',
    origin='SMF99C_VCM_D204_WRKCURRW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Accumulated current LPAR weight

SMF Info
--------
    Field: `SMF99C_VCM_D204_WRKCURRW`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Accumulated current LPAR weight
"""
vcm_d204_wrkcurrw.__doc__ = """Accumulated current LPAR weight

SMF Info
--------
    Field: `SMF99C_VCM_D204_WRKCURRW`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Accumulated current LPAR weight
"""

vcm_d204_lcpus : Final[Field] = Field(
    name='vcm_d204_lcpus',
    origin='SMF99C_VCM_D204_LCPUS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Number of logical CPUs/Cores for this LPAR.

SMF Info
--------
    Field: `SMF99C_VCM_D204_LCPUS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of logical CPUs/Cores for this LPAR.
"""
vcm_d204_lcpus.__doc__ = """Number of logical CPUs/Cores for this LPAR.

SMF Info
--------
    Field: `SMF99C_VCM_D204_LCPUS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of logical CPUs/Cores for this LPAR.
"""

vcm_d204_flags1 : Final[Field] = Field(
    name='vcm_d204_flags1',
    origin='SMF99C_VCM_D204_FLAGS1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Flags

SMF Info
--------
    Field: `SMF99C_VCM_D204_FLAGS1`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Flags
"""
vcm_d204_flags1.__doc__ = """Flags

SMF Info
--------
    Field: `SMF99C_VCM_D204_FLAGS1`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Flags
"""

vcm_d204_lparcappingpt : Final[Field] = Field(
    name='vcm_d204_lparcappingpt',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_d204_flags1,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""LPAR capped by customer, per processor type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_d204_flags1`(`SMF99C_VCM_D204_FLAGS1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

LPAR capped by customer, per processor type

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_d204_lparcappingpt.__doc__ = """LPAR capped by customer, per processor type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_d204_flags1`(`SMF99C_VCM_D204_FLAGS1`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

LPAR capped by customer, per processor type

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cpu_vh : Final[Field] = Field(
    name='cpu_vh',
    origin='SMF99C_VCM_CPUHI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Number VHs

SMF Info
--------
    Field: `SMF99C_VCM_CPUHI`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number VHs
"""
cpu_vh.__doc__ = """Number VHs

SMF Info
--------
    Field: `SMF99C_VCM_CPUHI`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number VHs
"""

cpu_vm : Final[Field] = Field(
    name='cpu_vm',
    origin='SMF99C_VCM_CPUMED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Number of VMs

SMF Info
--------
    Field: `SMF99C_VCM_CPUMED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of VMs
"""
cpu_vm.__doc__ = """Number of VMs

SMF Info
--------
    Field: `SMF99C_VCM_CPUMED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of VMs
"""

cpu_vl : Final[Field] = Field(
    name='cpu_vl',
    origin='SMF99C_VCM_CPULO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Number VLs

SMF Info
--------
    Field: `SMF99C_VCM_CPULO`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number VLs
"""
cpu_vl.__doc__ = """Number VLs

SMF Info
--------
    Field: `SMF99C_VCM_CPULO`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number VLs
"""

vl_unparked : Final[Field] = Field(
    name='vl_unparked',
    origin='SMF99C_VCM_CPULOUNPARKED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Number of unparked VLs

SMF Info
--------
    Field: `SMF99C_VCM_CPULOUNPARKED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of unparked VLs
"""
vl_unparked.__doc__ = """Number of unparked VLs

SMF Info
--------
    Field: `SMF99C_VCM_CPULOUNPARKED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of unparked VLs
"""

vl_parked : Final[Field] = Field(
    name='vl_parked',
    origin='SMF99C_VCM_CPULOPARKED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Number of parked VLs

SMF Info
--------
    Field: `SMF99C_VCM_CPULOPARKED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of parked VLs
"""
vl_parked.__doc__ = """Number of parked VLs

SMF Info
--------
    Field: `SMF99C_VCM_CPULOPARKED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of parked VLs
"""

vcm_diagcapincr : Final[Field] = Field(
    name='vcm_diagcapincr',
    origin='SMF99C_VCM_DIAGCAPINCR',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Capacity increase flags

SMF Info
--------
    Field: `SMF99C_VCM_DIAGCAPINCR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Capacity increase flags
"""
vcm_diagcapincr.__doc__ = """Capacity increase flags

SMF Info
--------
    Field: `SMF99C_VCM_DIAGCAPINCR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Capacity increase flags
"""

vcm_diagincr : Final[Field] = Field(
    name='vcm_diagincr',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_diagcapincr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Adjust capacity increase(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Adjust capacity increase

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_diagincr.__doc__ = """Adjust capacity increase(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Adjust capacity increase

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_diagincrdiscrunpark : Final[Field] = Field(
    name='vcm_diagincrdiscrunpark',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_diagcapincr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Adjust capacity increase by unparking a processor(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Adjust capacity increase by unparking a processor

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_diagincrdiscrunpark.__doc__ = """Adjust capacity increase by unparking a processor(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Adjust capacity increase by unparking a processor

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_diagincrdiscruprequ : Final[Field] = Field(
    name='vcm_diagincrdiscruprequ',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_diagcapincr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Unpark request(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Unpark request

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vcm_diagincrdiscruprequ.__doc__ = """Unpark request(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Unpark request

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

vcm_diagincrdiscrupallrq : Final[Field] = Field(
    name='vcm_diagincrdiscrupallrq',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=vcm_diagcapincr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Unpark all request(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Unpark all request

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
vcm_diagincrdiscrupallrq.__doc__ = """Unpark all request(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Unpark all request

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

vcm_diagincrunusedcap : Final[Field] = Field(
    name='vcm_diagincrunusedcap',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=vcm_diagcapincr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""unpark requested because the LPAR capacity is below the guaranteed capacity + unused capacity share(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

unpark requested because the LPAR capacity is below the guaranteed capacity + unused capacity share

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vcm_diagincrunusedcap.__doc__ = """unpark requested because the LPAR capacity is below the guaranteed capacity + unused capacity share(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

unpark requested because the LPAR capacity is below the guaranteed capacity + unused capacity share

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

vcm_diagincrprsmcapvhutil : Final[Field] = Field(
    name='vcm_diagincrprsmcapvhutil',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=vcm_diagcapincr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capped LPAR: Unpark requested because of high VH utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: Unpark requested because of high VH utilization

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
vcm_diagincrprsmcapvhutil.__doc__ = """PR/SM capped LPAR: Unpark requested because of high VH utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapincr`(`SMF99C_VCM_DIAGCAPINCR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: Unpark requested because of high VH utilization

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

vcm_diagcapdecr : Final[Field] = Field(
    name='vcm_diagcapdecr',
    origin='SMF99C_VCM_DIAGCAPDECR',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Capacity decrease flags

SMF Info
--------
    Field: `SMF99C_VCM_DIAGCAPDECR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Capacity decrease flags
"""
vcm_diagcapdecr.__doc__ = """Capacity decrease flags

SMF Info
--------
    Field: `SMF99C_VCM_DIAGCAPDECR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Capacity decrease flags
"""

vcm_diagdecr : Final[Field] = Field(
    name='vcm_diagdecr',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Adjust capacity decrease(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Adjust capacity decrease

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_diagdecr.__doc__ = """Adjust capacity decrease(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Adjust capacity decrease

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_diagdecrdiscrpark : Final[Field] = Field(
    name='vcm_diagdecrdiscrpark',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Adjust capacity decrease by parking a processor(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Adjust capacity decrease by parking a processor

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_diagdecrdiscrpark.__doc__ = """Adjust capacity decrease by parking a processor(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Adjust capacity decrease by parking a processor

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_diagdecrdiscrparequ : Final[Field] = Field(
    name='vcm_diagdecrdiscrparequ',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Park requested(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park requested

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vcm_diagdecrdiscrparequ.__doc__ = """Park requested(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park requested

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

vcm_diagdecrdiscrpaallrq : Final[Field] = Field(
    name='vcm_diagdecrdiscrpaallrq',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Park all request(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park all request

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
vcm_diagdecrdiscrpaallrq.__doc__ = """Park all request(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park all request

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

vcm_diagdecrbusythr : Final[Field] = Field(
    name='vcm_diagdecrbusythr',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MvsBusy too low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MvsBusy too low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
vcm_diagdecrbusythr.__doc__ = """MvsBusy too low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MvsBusy too low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vcm_diagdecreffectthr : Final[Field] = Field(
    name='vcm_diagdecreffectthr',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""VL effect too low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

VL effect too low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vcm_diagdecreffectthr.__doc__ = """VL effect too low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

VL effect too low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

vcm_diagdecreffectsmall : Final[Field] = Field(
    name='vcm_diagdecreffectsmall',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""small VM/VL effectiveness(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

small VM/VL effectiveness

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
vcm_diagdecreffectsmall.__doc__ = """small VM/VL effectiveness(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

small VM/VL effectiveness

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

vcm_diagdecreffectnone : Final[Field] = Field(
    name='vcm_diagdecreffectnone',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""no VM/VL effectiveness(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

no VM/VL effectiveness

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
vcm_diagdecreffectnone.__doc__ = """no VM/VL effectiveness(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

no VM/VL effectiveness

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

vcm_diagdecrefflowthr : Final[Field] = Field(
    name='vcm_diagdecrefflowthr',
    origin=None,
    post='core.flags',
    post_param=8,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""if no VH exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

if no VH exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `8`
"""
vcm_diagdecrefflowthr.__doc__ = """if no VH exists(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

if no VH exists

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `8`
"""

vcm_diagnodecrlowutil : Final[Field] = Field(
    name='vcm_diagnodecrlowutil',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""No capacity decrease adjustment. Reason: Low CEC utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

No capacity decrease adjustment. Reason: Low CEC utilization

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
vcm_diagnodecrlowutil.__doc__ = """No capacity decrease adjustment. Reason: Low CEC utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

No capacity decrease adjustment. Reason: Low CEC utilization

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

vcm_diagdecrprsmcapparkallhw : Final[Field] = Field(
    name='vcm_diagdecrprsmcapparkallhw',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capped LPAR. Park all. Below zEC12 hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR. Park all. Below zEC12 hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
vcm_diagdecrprsmcapparkallhw.__doc__ = """PR/SM capped LPAR. Park all. Below zEC12 hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR. Park all. Below zEC12 hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

vcm_diagdecrprsmcapcecutil : Final[Field] = Field(
    name='vcm_diagdecrprsmcapcecutil',
    origin=None,
    post='core.flags',
    post_param=11,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capped LPAR: Park all. High CEC utilization and there is no unused LPAR cap(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: Park all. High CEC utilization and there is no unused LPAR cap

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `11`
"""
vcm_diagdecrprsmcapcecutil.__doc__ = """PR/SM capped LPAR: Park all. High CEC utilization and there is no unused LPAR cap(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: Park all. High CEC utilization and there is no unused LPAR cap

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `11`
"""

vcm_diagdecrprsmcapvhutil : Final[Field] = Field(
    name='vcm_diagdecrprsmcapvhutil',
    origin=None,
    post='core.flags',
    post_param=12,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capped LPAR: Vh utilization is low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: Vh utilization is low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `12`
"""
vcm_diagdecrprsmcapvhutil.__doc__ = """PR/SM capped LPAR: Vh utilization is low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: Vh utilization is low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `12`
"""

vcm_diagdecrprsmcapeffectthr : Final[Field] = Field(
    name='vcm_diagdecrprsmcapeffectthr',
    origin=None,
    post='core.flags',
    post_param=13,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capped LPAR: VL effect too low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: VL effect too low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `13`
"""
vcm_diagdecrprsmcapeffectthr.__doc__ = """PR/SM capped LPAR: VL effect too low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: VL effect too low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `13`
"""

vcm_diagdecrprsmcapbusythr : Final[Field] = Field(
    name='vcm_diagdecrprsmcapbusythr',
    origin=None,
    post='core.flags',
    post_param=14,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capped LPAR: MVS busy too low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: MVS busy too low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `14`
"""
vcm_diagdecrprsmcapbusythr.__doc__ = """PR/SM capped LPAR: MVS busy too low(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: MVS busy too low

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `14`
"""

vcm_diagdecrprsmcap : Final[Field] = Field(
    name='vcm_diagdecrprsmcap',
    origin=None,
    post='core.flags',
    post_param=15,
    virtual=True,
    ref=vcm_diagcapdecr,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capped LPAR: Adjust capacity decrease(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: Adjust capacity decrease

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `15`
"""
vcm_diagdecrprsmcap.__doc__ = """PR/SM capped LPAR: Adjust capacity decrease(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr`(`SMF99C_VCM_DIAGCAPDECR`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: Adjust capacity decrease

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `15`
"""

vcm_diagcapdecr_cont : Final[Field] = Field(
    name='vcm_diagcapdecr_cont',
    origin='SMF99C_VCM_DIAGCAPDECR_CONT',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Capacity decrease flags continuation

SMF Info
--------
    Field: `SMF99C_VCM_DIAGCAPDECR_CONT`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Capacity decrease flags continuation
"""
vcm_diagcapdecr_cont.__doc__ = """Capacity decrease flags continuation

SMF Info
--------
    Field: `SMF99C_VCM_DIAGCAPDECR_CONT`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Capacity decrease flags continuation
"""

vcm_diagdecrparkallful : Final[Field] = Field(
    name='vcm_diagdecrparkallful',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_diagcapdecr_cont,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Park all request. Free capacity unpark threshold at or above upper limit(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr_cont`(`SMF99C_VCM_DIAGCAPDECR_CONT`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park all request. Free capacity unpark threshold at or above upper limit

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_diagdecrparkallful.__doc__ = """Park all request. Free capacity unpark threshold at or above upper limit(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr_cont`(`SMF99C_VCM_DIAGCAPDECR_CONT`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Park all request. Free capacity unpark threshold at or above upper limit

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_diagnodecrprsmcaplowutil : Final[Field] = Field(
    name='vcm_diagnodecrprsmcaplowutil',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_diagcapdecr_cont,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capped LPAR: No capacity decrease adjustment. Reason: Low CEC utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr_cont`(`SMF99C_VCM_DIAGCAPDECR_CONT`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: No capacity decrease adjustment. Reason: Low CEC utilization

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_diagnodecrprsmcaplowutil.__doc__ = """PR/SM capped LPAR: No capacity decrease adjustment. Reason: Low CEC utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagcapdecr_cont`(`SMF99C_VCM_DIAGCAPDECR_CONT`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capped LPAR: No capacity decrease adjustment. Reason: Low CEC utilization

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_ceccaptotal : Final[Field] = Field(
    name='vcm_ceccaptotal',
    origin='SMF99C_VCM_CECCAPTOTAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Total CEC capacity in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPTOTAL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total CEC capacity in microseconds
"""
vcm_ceccaptotal.__doc__ = """Total CEC capacity in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPTOTAL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total CEC capacity in microseconds
"""

cec_capacity_used : Final[Field] = Field(
    name='cec_capacity_used',
    origin='SMF99C_VCM_CECCAPUSEDADJ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""CEC capacity used in microseconds, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPUSEDADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

CEC capacity used in microseconds, adjusted to the scheduled VCM interval length
"""
cec_capacity_used.__doc__ = """CEC capacity used in microseconds, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPUSEDADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

CEC capacity used in microseconds, adjusted to the scheduled VCM interval length
"""

cec_capacity_used_ms : Final[Field] = Field(
    name='cec_capacity_used_ms',
    origin='SMF99C_VCM_CECCAPUSED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""CEC capacity used in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPUSED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

CEC capacity used in microseconds
"""
cec_capacity_used_ms.__doc__ = """CEC capacity used in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPUSED`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

CEC capacity used in microseconds
"""

cec_free_capacity : Final[Field] = Field(
    name='cec_free_capacity',
    origin='SMF99C_VCM_CECCAPFREE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Free CEC capacity in microseconds, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPFREE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Free CEC capacity in microseconds, adjusted to the scheduled VCM interval length
"""
cec_free_capacity.__doc__ = """Free CEC capacity in microseconds, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPFREE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Free CEC capacity in microseconds, adjusted to the scheduled VCM interval length
"""

vcm_cecsharedcps : Final[Field] = Field(
    name='vcm_cecsharedcps',
    origin='SMF99C_VCM_CECSHAREDCPS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Number of shared CPUs/Cores

SMF Info
--------
    Field: `SMF99C_VCM_CECSHAREDCPS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of shared CPUs/Cores
"""
vcm_cecsharedcps.__doc__ = """Number of shared CPUs/Cores

SMF Info
--------
    Field: `SMF99C_VCM_CECSHAREDCPS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Number of shared CPUs/Cores
"""

vcm_ceccapfreelimit : Final[Field] = Field(
    name='vcm_ceccapfreelimit',
    origin='SMF99C_VCM_CECCAPFREELIMIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""CEC free limit for unparking, scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPFREELIMIT`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

CEC free limit for unparking, scaled by 256
"""
vcm_ceccapfreelimit.__doc__ = """CEC free limit for unparking, scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_CECCAPFREELIMIT`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

CEC free limit for unparking, scaled by 256
"""

cec_utilization : Final[Field] = Field(
    name='cec_utilization',
    origin='SMF99C_VCM_CECUTIL',
    post='core.scale',
    post_param=25600,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Total CEC utilization, scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_CECUTIL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total CEC utilization, scaled by 256

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `25600`
"""
cec_utilization.__doc__ = """Total CEC utilization, scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_CECUTIL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total CEC utilization, scaled by 256

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `25600`
"""

vcm_cectotunusedcap : Final[Field] = Field(
    name='vcm_cectotunusedcap',
    origin='SMF99C_VCM_CECTOTUNUSEDCAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Total unused capacity of all LPARs in CEC in microseconds. The unused capacity of the requesting LPAR is not included

SMF Info
--------
    Field: `SMF99C_VCM_CECTOTUNUSEDCAP`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total unused capacity of all LPARs in CEC in microseconds. The unused capacity of the requesting LPAR is not included
"""
vcm_cectotunusedcap.__doc__ = """Total unused capacity of all LPARs in CEC in microseconds. The unused capacity of the requesting LPAR is not included

SMF Info
--------
    Field: `SMF99C_VCM_CECTOTUNUSEDCAP`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total unused capacity of all LPARs in CEC in microseconds. The unused capacity of the requesting LPAR is not included
"""

vcm_cectotlparwgtaboveguaran : Final[Field] = Field(
    name='vcm_cectotlparwgtaboveguaran',
    origin='SMF99C_VCM_CECTOTLPARWGTABOVEGUARAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Total weight of all LPARs with a processor demand above guaranteed capacity. The weight of the requesting LPAR is always included

SMF Info
--------
    Field: `SMF99C_VCM_CECTOTLPARWGTABOVEGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total weight of all LPARs with a processor demand above guaranteed capacity. The weight of the requesting LPAR is always included
"""
vcm_cectotlparwgtaboveguaran.__doc__ = """Total weight of all LPARs with a processor demand above guaranteed capacity. The weight of the requesting LPAR is always included

SMF Info
--------
    Field: `SMF99C_VCM_CECTOTLPARWGTABOVEGUARAN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Total weight of all LPARs with a processor demand above guaranteed capacity. The weight of the requesting LPAR is always included
"""

vcm_cecphysmgmtime : Final[Field] = Field(
    name='vcm_cecphysmgmtime',
    origin='SMF99C_VCM_CECPHYSMGMTIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Physical LPAR management time of all CPUs in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_CECPHYSMGMTIME`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Physical LPAR management time of all CPUs in microseconds
"""
vcm_cecphysmgmtime.__doc__ = """Physical LPAR management time of all CPUs in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_CECPHYSMGMTIME`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Physical LPAR management time of all CPUs in microseconds
"""

vcm_cecphysmgmtimeadj : Final[Field] = Field(
    name='vcm_cecphysmgmtimeadj',
    origin='SMF99C_VCM_CECPHYSMGMTIMEADJ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Physical LPAR management time of all CPUs, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_CECPHYSMGMTIMEADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Physical LPAR management time of all CPUs, adjusted to the scheduled VCM interval length
"""
vcm_cecphysmgmtimeadj.__doc__ = """Physical LPAR management time of all CPUs, adjusted to the scheduled VCM interval length

SMF Info
--------
    Field: `SMF99C_VCM_CECPHYSMGMTIMEADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Physical LPAR management time of all CPUs, adjusted to the scheduled VCM interval length
"""

mt_cf : Final[Field] = Field(
    name='mt_cf',
    origin='SMF99C_MT_CF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Capacity factor of processor class. Scaled by 1024

SMF Info
--------
    Field: `SMF99C_MT_CF`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Capacity factor of processor class. Scaled by 1024
"""
mt_cf.__doc__ = """Capacity factor of processor class. Scaled by 1024

SMF Info
--------
    Field: `SMF99C_MT_CF`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Capacity factor of processor class. Scaled by 1024
"""

mt_mcf : Final[Field] = Field(
    name='mt_mcf',
    origin='SMF99C_MT_MCF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Maximum capacity factor of processor class. Scaled by 1024

SMF Info
--------
    Field: `SMF99C_MT_MCF`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Maximum capacity factor of processor class. Scaled by 1024
"""
mt_mcf.__doc__ = """Maximum capacity factor of processor class. Scaled by 1024

SMF Info
--------
    Field: `SMF99C_MT_MCF`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Maximum capacity factor of processor class. Scaled by 1024
"""

mt_opt_orig : Final[Field] = Field(
    name='mt_opt_orig',
    origin='SMF99C_MT_OPT_ORIG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MT mode value

SMF Info
--------
    Field: `SMF99C_MT_OPT_ORIG`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MT mode value
"""
mt_opt_orig.__doc__ = """MT mode value

SMF Info
--------
    Field: `SMF99C_MT_OPT_ORIG`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MT mode value
"""

mt_opt_inuse : Final[Field] = Field(
    name='mt_opt_inuse',
    origin='SMF99C_MT_OPT_INUSE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MT mode value as forced by environment

SMF Info
--------
    Field: `SMF99C_MT_OPT_INUSE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MT mode value as forced by environment
"""
mt_opt_inuse.__doc__ = """MT mode value as forced by environment

SMF Info
--------
    Field: `SMF99C_MT_OPT_INUSE`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MT mode value as forced by environment
"""

mt_curr : Final[Field] = Field(
    name='mt_curr',
    origin='SMF99C_MT_CURR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MT mode currently in use

SMF Info
--------
    Field: `SMF99C_MT_CURR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MT mode currently in use
"""
mt_curr.__doc__ = """MT mode currently in use

SMF Info
--------
    Field: `SMF99C_MT_CURR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MT mode currently in use
"""

mt_tgt : Final[Field] = Field(
    name='mt_tgt',
    origin='SMF99C_MT_TGT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MT mode target value

SMF Info
--------
    Field: `SMF99C_MT_TGT`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MT mode target value
"""
mt_tgt.__doc__ = """MT mode target value

SMF Info
--------
    Field: `SMF99C_MT_TGT`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MT mode target value
"""

vcm_d204cputypecapval : Final[Field] = Field(
    name='vcm_d204cputypecapval',
    origin='SMF99C_VCM_D204CPUTYPECAPVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capping limit. Count of hundredths of CPU/Core units

SMF Info
--------
    Field: `SMF99C_VCM_D204CPUTYPECAPVAL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capping limit. Count of hundredths of CPU/Core units
"""
vcm_d204cputypecapval.__doc__ = """PR/SM capping limit. Count of hundredths of CPU/Core units

SMF Info
--------
    Field: `SMF99C_VCM_D204CPUTYPECAPVAL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capping limit. Count of hundredths of CPU/Core units
"""

vcm_d204hardwaregroupcputypecap : Final[Field] = Field(
    name='vcm_d204hardwaregroupcputypecap',
    origin='SMF99C_VCM_D204HARDWAREGROUPCPUTYPECAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""HWGroup capping limit. Count of 100ths of procs units

SMF Info
--------
    Field: `SMF99C_VCM_D204HARDWAREGROUPCPUTYPECAP`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

HWGroup capping limit. Count of 100ths of procs units
"""
vcm_d204hardwaregroupcputypecap.__doc__ = """HWGroup capping limit. Count of 100ths of procs units

SMF Info
--------
    Field: `SMF99C_VCM_D204HARDWAREGROUPCPUTYPECAP`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

HWGroup capping limit. Count of 100ths of procs units
"""

vcm_prsmcapcecutilparkallthr : Final[Field] = Field(
    name='vcm_prsmcapcecutilparkallthr',
    origin='SMF99C_VCM_PRSMCAPCECUTILPARKALLTHR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capping: CEC utilization park all threshold scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_PRSMCAPCECUTILPARKALLTHR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capping: CEC utilization park all threshold scaled by 256
"""
vcm_prsmcapcecutilparkallthr.__doc__ = """PR/SM capping: CEC utilization park all threshold scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_PRSMCAPCECUTILPARKALLTHR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capping: CEC utilization park all threshold scaled by 256
"""

vcm_prsmcapvhutilthr_max : Final[Field] = Field(
    name='vcm_prsmcapvhutilthr_max',
    origin='SMF99C_VCM_PRSMCAPVHUTILTHR_MAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capping: VH/VM utilization unpark threshold scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_PRSMCAPVHUTILTHR_MAX`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capping: VH/VM utilization unpark threshold scaled by 256
"""
vcm_prsmcapvhutilthr_max.__doc__ = """PR/SM capping: VH/VM utilization unpark threshold scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_PRSMCAPVHUTILTHR_MAX`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capping: VH/VM utilization unpark threshold scaled by 256
"""

vcm_prsmcapvhutilthr_min : Final[Field] = Field(
    name='vcm_prsmcapvhutilthr_min',
    origin='SMF99C_VCM_PRSMCAPVHUTILTHR_MIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""PR/SM capping: VH/VM utilization park threshold scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_PRSMCAPVHUTILTHR_MIN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capping: VH/VM utilization park threshold scaled by 256
"""
vcm_prsmcapvhutilthr_min.__doc__ = """PR/SM capping: VH/VM utilization park threshold scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_PRSMCAPVHUTILTHR_MIN`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

PR/SM capping: VH/VM utilization park threshold scaled by 256
"""

lpar_capacity_used_vh : Final[Field] = Field(
    name='lpar_capacity_used_vh',
    origin='SMF99C_VCM_LPARCAPUSEDVHADJ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Used VH capacity of previous interval in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDVHADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used VH capacity of previous interval in microseconds
"""
lpar_capacity_used_vh.__doc__ = """Used VH capacity of previous interval in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDVHADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used VH capacity of previous interval in microseconds
"""

vcm_lparcapusedvmadj : Final[Field] = Field(
    name='vcm_lparcapusedvmadj',
    origin='SMF99C_VCM_LPARCAPUSEDVMADJ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Used VM capacity of previous interval in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDVMADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used VM capacity of previous interval in microseconds
"""
vcm_lparcapusedvmadj.__doc__ = """Used VM capacity of previous interval in microseconds

SMF Info
--------
    Field: `SMF99C_VCM_LPARCAPUSEDVMADJ`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used VM capacity of previous interval in microseconds
"""

vcm_vhutil : Final[Field] = Field(
    name='vcm_vhutil',
    origin='SMF99C_VCM_VHUTIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""VH utilization of previous interval scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_VHUTIL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

VH utilization of previous interval scaled by 256
"""
vcm_vhutil.__doc__ = """VH utilization of previous interval scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_VHUTIL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

VH utilization of previous interval scaled by 256
"""

vcm_vmutil : Final[Field] = Field(
    name='vcm_vmutil',
    origin='SMF99C_VCM_VMUTIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""VM utilization of previous interval scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_VMUTIL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

VM utilization of previous interval scaled by 256
"""
vcm_vmutil.__doc__ = """VM utilization of previous interval scaled by 256

SMF Info
--------
    Field: `SMF99C_VCM_VMUTIL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

VM utilization of previous interval scaled by 256
"""

vcm_projvhmutil : Final[Field] = Field(
    name='vcm_projvhmutil',
    origin='SMF99C_VCM_PROJVHMUTIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Projected VH utilization (or projected VM utilization if there is no VH in the topology) if one VL would have been parked

SMF Info
--------
    Field: `SMF99C_VCM_PROJVHMUTIL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Projected VH utilization (or projected VM utilization if there is no VH in the topology) if one VL would have been parked
"""
vcm_projvhmutil.__doc__ = """Projected VH utilization (or projected VM utilization if there is no VH in the topology) if one VL would have been parked

SMF Info
--------
    Field: `SMF99C_VCM_PROJVHMUTIL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Projected VH utilization (or projected VM utilization if there is no VH in the topology) if one VL would have been parked
"""

vcm_ma_flgs : Final[Field] = Field(
    name='vcm_ma_flgs',
    origin='SMF99C_VCM_MA_FLGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Memory affinity status indicators

SMF Info
--------
    Field: `SMF99C_VCM_MA_FLGS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Memory affinity status indicators
"""
vcm_ma_flgs.__doc__ = """Memory affinity status indicators

SMF Info
--------
    Field: `SMF99C_VCM_MA_FLGS`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Memory affinity status indicators
"""

vcm_stop_brk_bal : Final[Field] = Field(
    name='vcm_stop_brk_bal',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_ma_flgs,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Broken up address spaces are not balanced in consideration of memory affinity aspects(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Broken up address spaces are not balanced in consideration of memory affinity aspects

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_stop_brk_bal.__doc__ = """Broken up address spaces are not balanced in consideration of memory affinity aspects(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Broken up address spaces are not balanced in consideration of memory affinity aspects

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_nocros : Final[Field] = Field(
    name='vcm_nocros',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_ma_flgs,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""No processor topology location crossing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

No processor topology location crossing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_nocros.__doc__ = """No processor topology location crossing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

No processor topology location crossing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_oneafn : Final[Field] = Field(
    name='vcm_oneafn',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_ma_flgs,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Single AFN(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Single AFN

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vcm_oneafn.__doc__ = """Single AFN(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Single AFN

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

vcm_hwlevel : Final[Field] = Field(
    name='vcm_hwlevel',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=vcm_ma_flgs,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Memory affinity not supported for this hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Memory affinity not supported for this hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
vcm_hwlevel.__doc__ = """Memory affinity not supported for this hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Memory affinity not supported for this hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

vcm_stop_memaff_bal : Final[Field] = Field(
    name='vcm_stop_memaff_bal',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=vcm_ma_flgs,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""High storage consumer address spaces are not balanced in consideration of memory affinity aspects(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

High storage consumer address spaces are not balanced in consideration of memory affinity aspects

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
vcm_stop_memaff_bal.__doc__ = """High storage consumer address spaces are not balanced in consideration of memory affinity aspects(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_ma_flgs`(`SMF99C_VCM_MA_FLGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

High storage consumer address spaces are not balanced in consideration of memory affinity aspects

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vcm_hscdynmvsbusythr : Final[Field] = Field(
    name='vcm_hscdynmvsbusythr',
    origin='SMF99C_VCM_HSCDYNMVSBUSYTHR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Dynamic MVS busy threshold

SMF Info
--------
    Field: `SMF99C_VCM_HSCDYNMVSBUSYTHR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Dynamic MVS busy threshold
"""
vcm_hscdynmvsbusythr.__doc__ = """Dynamic MVS busy threshold

SMF Info
--------
    Field: `SMF99C_VCM_HSCDYNMVSBUSYTHR`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Dynamic MVS busy threshold
"""

vcm_hdmahsct : Final[Field] = Field(
    name='vcm_hdmahsct',
    origin='SMF99C_VCM_HDMAHSCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""High storage consumer threshold

SMF Info
--------
    Field: `SMF99C_VCM_HDMAHSCT`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

High storage consumer threshold
"""
vcm_hdmahsct.__doc__ = """High storage consumer threshold

SMF Info
--------
    Field: `SMF99C_VCM_HDMAHSCT`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

High storage consumer threshold
"""

vcm_hdtdmu : Final[Field] = Field(
    name='vcm_hdtdmu',
    origin='SMF99C_VCM_HDTDMU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Maximum topology distance value

SMF Info
--------
    Field: `SMF99C_VCM_HDTDMU`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Maximum topology distance value
"""
vcm_hdtdmu.__doc__ = """Maximum topology distance value

SMF Info
--------
    Field: `SMF99C_VCM_HDTDMU`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Maximum topology distance value
"""

vcm_srb_blurring : Final[Field] = Field(
    name='vcm_srb_blurring',
    origin='SMF99C_VCM_SRB_BLURRING',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""For IBM use only

SMF Info
--------
    Field: `SMF99C_VCM_SRB_BLURRING`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

For IBM use only
"""
vcm_srb_blurring.__doc__ = """For IBM use only

SMF Info
--------
    Field: `SMF99C_VCM_SRB_BLURRING`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

For IBM use only
"""

cpu_type : Final[Field] = Field(
    name='cpu_type',
    origin=None,
    post='core.map',
    post_param={'default': 'No Processor', 'map': {1: 'CP', 2: 'zAAP', 3: 'zIIP'}},
    virtual=True,
    ref=hd_int_cap_proctype,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""SMF99.12 capacity data processor type @ME14601A(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hd_int_cap_proctype`(`SMF99C_HD_INT_CAP_PROCTYPE`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `No Processor`)::

    1 => CP
    2 => zAAP
    3 => zIIP
"""
cpu_type.__doc__ = """SMF99.12 capacity data processor type @ME14601A(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hd_int_cap_proctype`(`SMF99C_HD_INT_CAP_PROCTYPE`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `No Processor`)::

    1 => CP
    2 => zAAP
    3 => zIIP
"""

vcm_lparcpshare : Final[Field] = Field(
    name='vcm_lparcpshare',
    origin=None,
    post="core.inline",
    post_param=__vcm_lparcpshare_inline_post,
    virtual=True,
    ref=vcm_lparflags,
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""These flags represent the status of the physical CPU/Core share compar...(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_lparflags`(`SMF99C_VCM_LPARFLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

These flags represent the status of the physical CPU/Core share compared to the available VHs and VMs

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_lparflags.str[0:3]

"""
vcm_lparcpshare.__doc__ = """These flags represent the status of the physical CPU/Core share compar...(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_lparflags`(`SMF99C_VCM_LPARFLAGS`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

These flags represent the status of the physical CPU/Core share compared to the available VHs and VMs

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_lparflags.str[0:3]

"""

hd_action_no_unparking_no_free_capacity : Final[Field] = Field(
    name='hd_action_no_unparking_no_free_capacity',
    origin=None,
    post="core.inline",
    post_param=__hd_action_no_unparking_no_free_capacity_inline_post,
    virtual=True,
    ref=[mvs_busy, vcm_mvsbusythrunpark, cec_free_capacity],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Less than 25% of CP free, no unparking(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mvs_busy`(`SMF99C_VCM_MVSBUSY`), `vcm_mvsbusythrunpark`(`SMF99C_VCM_MVSBUSYTHRUNPARK`), `cec_free_capacity`(`SMF99C_VCM_CECCAPFREE`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    condition1 = df.mvs_busy >= df.vcm_mvsbusythrunpark
    condition2 = df.cec_free_capacity <= (2e6 * df.vcm_mvsbusythrunpark / 1600)
    return condition1 & condition2

"""
hd_action_no_unparking_no_free_capacity.__doc__ = """Less than 25% of CP free, no unparking(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mvs_busy`(`SMF99C_VCM_MVSBUSY`), `vcm_mvsbusythrunpark`(`SMF99C_VCM_MVSBUSYTHRUNPARK`), `cec_free_capacity`(`SMF99C_VCM_CECCAPFREE`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    condition1 = df.mvs_busy >= df.vcm_mvsbusythrunpark
    condition2 = df.cec_free_capacity <= (2e6 * df.vcm_mvsbusythrunpark / 1600)
    return condition1 & condition2

"""

hd_action_no_unparking_no_vl : Final[Field] = Field(
    name='hd_action_no_unparking_no_vl',
    origin=None,
    post="core.inline",
    post_param=__hd_action_no_unparking_no_vl_inline_post,
    virtual=True,
    ref=[vcm_diagincrdiscruprequ, vl_parked],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""no vertical low processors available, no unparking(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagincrdiscruprequ`(Virtual), `vl_parked`(`SMF99C_VCM_CPULOPARKED`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagincrdiscruprequ & (df.vl_parked == 0)

"""
hd_action_no_unparking_no_vl.__doc__ = """no vertical low processors available, no unparking(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagincrdiscruprequ`(Virtual), `vl_parked`(`SMF99C_VCM_CPULOPARKED`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagincrdiscruprequ & (df.vl_parked == 0)

"""

hd_action_unpark : Final[Field] = Field(
    name='hd_action_unpark',
    origin=None,
    post="core.inline",
    post_param=__hd_action_unpark_inline_post,
    virtual=True,
    ref=[vcm_diagincrdiscruprequ, vcm_diagincrdiscrunpark],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MVS busy is higer than threshold, unparking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagincrdiscruprequ`(Virtual), `vcm_diagincrdiscrunpark`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MVS busy is higer than threshold and free capacity is available, unparking done

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagincrdiscruprequ & df.vcm_diagincrdiscrunpark

"""
hd_action_unpark.__doc__ = """MVS busy is higer than threshold, unparking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagincrdiscruprequ`(Virtual), `vcm_diagincrdiscrunpark`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MVS busy is higer than threshold and free capacity is available, unparking done

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagincrdiscruprequ & df.vcm_diagincrdiscrunpark

"""

hd_action_unpark_no_free_capacity : Final[Field] = Field(
    name='hd_action_unpark_no_free_capacity',
    origin=None,
    post="core.inline",
    post_param=__hd_action_unpark_no_free_capacity_inline_post,
    virtual=True,
    ref=[vcm_diagincrunusedcap, vcm_diagincrdiscruprequ, vcm_diagincrdiscrunpark],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MVS busy is higer than threshold, unparking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagincrunusedcap`(Virtual), `vcm_diagincrdiscruprequ`(Virtual), `vcm_diagincrdiscrunpark`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MVS busy is higer than threshold and not enough free capacity available. Partiotions white space is used, unparking done

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagincrunusedcap & df.vcm_diagincrdiscruprequ & df.vcm_diagincrdiscrunpark

"""
hd_action_unpark_no_free_capacity.__doc__ = """MVS busy is higer than threshold, unparking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagincrunusedcap`(Virtual), `vcm_diagincrdiscruprequ`(Virtual), `vcm_diagincrdiscrunpark`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MVS busy is higer than threshold and not enough free capacity available. Partiotions white space is used, unparking done

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagincrunusedcap & df.vcm_diagincrdiscruprequ & df.vcm_diagincrdiscrunpark

"""

hd_action_unpark_no_free_capacity_capping : Final[Field] = Field(
    name='hd_action_unpark_no_free_capacity_capping',
    origin=None,
    post="core.inline",
    post_param=__hd_action_unpark_no_free_capacity_capping_inline_post,
    virtual=True,
    ref=[vcm_diagincrunusedcap, vcm_diagdecrprsmcapvhutil, vcm_diagincrdiscrunpark],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MVS busy is higer than threshold, unparking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagincrunusedcap`(Virtual), `vcm_diagdecrprsmcapvhutil`(Virtual), `vcm_diagincrdiscrunpark`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MVS busy is higer than threshold and not enough free capacity available. Partiotions white space is used, unparking done during capping

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagincrunusedcap & df.vcm_diagdecrprsmcapvhutil & df.vcm_diagincrdiscrunpark

"""
hd_action_unpark_no_free_capacity_capping.__doc__ = """MVS busy is higer than threshold, unparking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagincrunusedcap`(Virtual), `vcm_diagdecrprsmcapvhutil`(Virtual), `vcm_diagincrdiscrunpark`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MVS busy is higer than threshold and not enough free capacity available. Partiotions white space is used, unparking done during capping

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagincrunusedcap & df.vcm_diagdecrprsmcapvhutil & df.vcm_diagincrdiscrunpark

"""

hd_action_unpark_capping : Final[Field] = Field(
    name='hd_action_unpark_capping',
    origin=None,
    post="core.inline",
    post_param=__hd_action_unpark_capping_inline_post,
    virtual=True,
    ref=[vcm_diagdecrprsmcapvhutil, vcm_diagincrdiscrunpark],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MVS busy is higer than threshold, unparking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrprsmcapvhutil`(Virtual), `vcm_diagincrdiscrunpark`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MVS busy is higer than threshold and free capacity is available, unparking done during capping

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrprsmcapvhutil & df.vcm_diagincrdiscrunpark

"""
hd_action_unpark_capping.__doc__ = """MVS busy is higer than threshold, unparking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrprsmcapvhutil`(Virtual), `vcm_diagincrdiscrunpark`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

MVS busy is higer than threshold and free capacity is available, unparking done during capping

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrprsmcapvhutil & df.vcm_diagincrdiscrunpark

"""

hd_action_park_mvs_busy_low : Final[Field] = Field(
    name='hd_action_park_mvs_busy_low',
    origin=None,
    post="core.inline",
    post_param=__hd_action_park_mvs_busy_low_inline_post,
    virtual=True,
    ref=[vcm_diagdecrbusythr, vcm_diagdecrdiscrpark, vcm_diagdecrdiscrparequ],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MVS busy threshold is low, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrbusythr`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrbusythr & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""
hd_action_park_mvs_busy_low.__doc__ = """MVS busy threshold is low, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrbusythr`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrbusythr & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""

hd_action_park_mvs_busy_low_capping : Final[Field] = Field(
    name='hd_action_park_mvs_busy_low_capping',
    origin=None,
    post="core.inline",
    post_param=__hd_action_park_mvs_busy_low_capping_inline_post,
    virtual=True,
    ref=[vcm_diagdecrprsmcapbusythr, vcm_diagdecrdiscrparequ],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""MVS busy threshold is low, parking done during capping(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrprsmcapbusythr`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrprsmcapbusythr & df.vcm_diagdecrdiscrparequ

"""
hd_action_park_mvs_busy_low_capping.__doc__ = """MVS busy threshold is low, parking done during capping(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrprsmcapbusythr`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrprsmcapbusythr & df.vcm_diagdecrdiscrparequ

"""

hd_action_park_less4_guaranteed_used : Final[Field] = Field(
    name='hd_action_park_less4_guaranteed_used',
    origin=None,
    post="core.inline",
    post_param=__hd_action_park_less4_guaranteed_used_inline_post,
    virtual=True,
    ref=[vcm_diagdecreffectnone, vcm_diagdecrdiscrpark, vcm_diagdecrdiscrparequ],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Only 4% above guaranteed capacity is used, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecreffectnone`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Only 4% above guaranteed capacity is used. 50% of VLs are parked, at least one VL is parked

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecreffectnone & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""
hd_action_park_less4_guaranteed_used.__doc__ = """Only 4% above guaranteed capacity is used, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecreffectnone`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Only 4% above guaranteed capacity is used. 50% of VLs are parked, at least one VL is parked

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecreffectnone & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""

hd_action_park_less10_guaranteed_used : Final[Field] = Field(
    name='hd_action_park_less10_guaranteed_used',
    origin=None,
    post="core.inline",
    post_param=__hd_action_park_less10_guaranteed_used_inline_post,
    virtual=True,
    ref=[vcm_diagdecreffectsmall, vcm_diagdecrdiscrpark, vcm_diagdecrdiscrparequ],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Only 10% above guaranteed is used, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecreffectsmall`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Only 10% above guaranteed is used. One VL is parked

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecreffectsmall & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""
hd_action_park_less10_guaranteed_used.__doc__ = """Only 10% above guaranteed is used, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecreffectsmall`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Only 10% above guaranteed is used. One VL is parked

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecreffectsmall & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""

hd_action_park_small_utilization : Final[Field] = Field(
    name='hd_action_park_small_utilization',
    origin=None,
    post="core.inline",
    post_param=__hd_action_park_small_utilization_inline_post,
    virtual=True,
    ref=[vcm_diagdecreffectthr, vcm_diagdecrdiscrpark, vcm_diagdecrdiscrparequ],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Less than 20% of VM/VL capacity is used, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecreffectthr`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Less than 20% of VM/VL capacity is used, parking done, VH exists

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecreffectthr & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""
hd_action_park_small_utilization.__doc__ = """Less than 20% of VM/VL capacity is used, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecreffectthr`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Less than 20% of VM/VL capacity is used, parking done, VH exists

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecreffectthr & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""

hd_action_park_small_utilization_capping : Final[Field] = Field(
    name='hd_action_park_small_utilization_capping',
    origin=None,
    post="core.inline",
    post_param=__hd_action_park_small_utilization_capping_inline_post,
    virtual=True,
    ref=[vcm_diagdecrprsmcapeffectthr, vcm_diagdecrprsmcap, vcm_diagdecrdiscrparequ],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Less than 20% of VM/VL capacity is used, parking done during capping(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrprsmcapeffectthr`(Virtual), `vcm_diagdecrprsmcap`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Less than 20% of VM/VL capacity is used, parking done during capping, VH exists

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrprsmcapeffectthr & df.vcm_diagdecrprsmcap & df.vcm_diagdecrdiscrparequ

"""
hd_action_park_small_utilization_capping.__doc__ = """Less than 20% of VM/VL capacity is used, parking done during capping(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrprsmcapeffectthr`(Virtual), `vcm_diagdecrprsmcap`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Less than 20% of VM/VL capacity is used, parking done during capping, VH exists

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrprsmcapeffectthr & df.vcm_diagdecrprsmcap & df.vcm_diagdecrdiscrparequ

"""

hd_action_park : Final[Field] = Field(
    name='hd_action_park',
    origin=None,
    post="core.inline",
    post_param=__hd_action_park_inline_post,
    virtual=True,
    ref=[vcm_diagdecrefflowthr, vcm_diagdecrdiscrpark, vcm_diagdecrdiscrparequ],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Allow at least 2 VL that have effectiveness, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrefflowthr`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrefflowthr & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""
hd_action_park.__doc__ = """Allow at least 2 VL that have effectiveness, parking done(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrefflowthr`(Virtual), `vcm_diagdecrdiscrpark`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrefflowthr & df.vcm_diagdecrdiscrpark & df.vcm_diagdecrdiscrparequ

"""

hd_action_park_capping : Final[Field] = Field(
    name='hd_action_park_capping',
    origin=None,
    post="core.inline",
    post_param=__hd_action_park_capping_inline_post,
    virtual=True,
    ref=[vcm_diagdecrprsmcapvhutil, vcm_diagdecrprsmcapeffectthr, vcm_diagdecrdiscrparequ],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Allow at least 2 VL that have effectiveness, parking done during capping(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrprsmcapvhutil`(Virtual), `vcm_diagdecrprsmcapeffectthr`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrprsmcapvhutil & df.vcm_diagdecrprsmcapeffectthr & df.vcm_diagdecrdiscrparequ

"""
hd_action_park_capping.__doc__ = """Allow at least 2 VL that have effectiveness, parking done during capping(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_diagdecrprsmcapvhutil`(Virtual), `vcm_diagdecrprsmcapeffectthr`(Virtual), `vcm_diagdecrdiscrparequ`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.vcm_diagdecrprsmcapvhutil & df.vcm_diagdecrprsmcapeffectthr & df.vcm_diagdecrdiscrparequ

"""

hd_action_explanation : Final[Field] = Field(
    name='hd_action_explanation',
    origin=None,
    post="core.inline",
    post_param=__hd_action_explanation_inline_post,
    virtual=True,
    ref=[hd_action_no_unparking_no_free_capacity, hd_action_no_unparking_no_vl, hd_action_unpark, hd_action_unpark_no_free_capacity, hd_action_unpark_no_free_capacity_capping, hd_action_unpark_capping, hd_action_park_mvs_busy_low, hd_action_park_mvs_busy_low_capping, hd_action_park_less4_guaranteed_used, hd_action_park_less10_guaranteed_used, hd_action_park_small_utilization, hd_action_park_small_utilization_capping, hd_action_park, hd_action_park_capping],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Action taken by HiperDispatch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hd_action_no_unparking_no_free_capacity`(Virtual), `hd_action_no_unparking_no_vl`(Virtual), `hd_action_unpark`(Virtual), `hd_action_unpark_no_free_capacity`(Virtual), `hd_action_unpark_no_free_capacity_capping`(Virtual), `hd_action_unpark_capping`(Virtual), `hd_action_park_mvs_busy_low`(Virtual), `hd_action_park_mvs_busy_low_capping`(Virtual), `hd_action_park_less4_guaranteed_used`(Virtual), `hd_action_park_less10_guaranteed_used`(Virtual), `hd_action_park_small_utilization`(Virtual), `hd_action_park_small_utilization_capping`(Virtual), `hd_action_park`(Virtual), `hd_action_park_capping`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    hd_action_unpark_filter = ~df.hd_action_unpark
    hd_action_unpark_capping_filter= ~df.hd_action_unpark_capping
    hd_action_park_filter= ~df.hd_action_park
    hd_action_park_capping_filter= ~df.hd_action_park_capping
    hd_action_no_unparking_no_free_capacity_filter= ~df.hd_action_no_unparking_no_free_capacity
    hd_action_no_unparking_no_vl_filter= ~df.hd_action_no_unparking_no_vl
    hd_action_unpark_no_free_capacity_filter= ~df.hd_action_unpark_no_free_capacity
    hd_action_unpark_no_free_capacity_capping_filter= ~df.hd_action_unpark_no_free_capacity_capping
    hd_action_park_mvs_busy_low_filter= ~df.hd_action_park_mvs_busy_low
    hd_action_park_mvs_busy_low_capping_filter= ~df.hd_action_park_mvs_busy_low_capping
    hd_action_park_less4_guaranteed_used_filter= ~df.hd_action_park_less4_guaranteed_used
    hd_action_park_less10_guaranteed_used_filter= ~df.hd_action_park_less10_guaranteed_used
    hd_action_park_small_utilization_filter= ~df.hd_action_park_small_utilization
    hd_action_park_small_utilization_capping_filter= ~df.hd_action_park_small_utilization_capping
    hd_action_explanation = df.hd_action_unpark.where(df.hd_action_unpark, '')
    hd_action_explanation =  hd_action_explanation.where(hd_action_unpark_filter, 'Unpark')
    hd_action_explanation =  hd_action_explanation.where( hd_action_unpark_capping_filter, 'Unpark / capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_filter, 'Park')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_capping_filter, 'Park /  capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_no_unparking_no_free_capacity_filter, 'no free capacity')
    hd_action_explanation =  hd_action_explanation.where( hd_action_no_unparking_no_vl_filter, 'no VLs')
    hd_action_explanation =  hd_action_explanation.where( hd_action_unpark_no_free_capacity_filter, 'no free capacity')
    hd_action_explanation =  hd_action_explanation.where( hd_action_unpark_no_free_capacity_capping_filter, 'no free capacity / capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_mvs_busy_low_filter, 'Low MVS busy')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_mvs_busy_low_capping_filter, 'Low MVS busy low / capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_less4_guaranteed_used_filter, '< 4% of guaranteed used')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_less10_guaranteed_used_filter, '< 10% of guaranteed used')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_small_utilization_filter, 'Small utilization')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_small_utilization_capping_filter, 'Small utilization / capping')
    return hd_action_explanation

"""
hd_action_explanation.__doc__ = """Action taken by HiperDispatch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hd_action_no_unparking_no_free_capacity`(Virtual), `hd_action_no_unparking_no_vl`(Virtual), `hd_action_unpark`(Virtual), `hd_action_unpark_no_free_capacity`(Virtual), `hd_action_unpark_no_free_capacity_capping`(Virtual), `hd_action_unpark_capping`(Virtual), `hd_action_park_mvs_busy_low`(Virtual), `hd_action_park_mvs_busy_low_capping`(Virtual), `hd_action_park_less4_guaranteed_used`(Virtual), `hd_action_park_less10_guaranteed_used`(Virtual), `hd_action_park_small_utilization`(Virtual), `hd_action_park_small_utilization_capping`(Virtual), `hd_action_park`(Virtual), `hd_action_park_capping`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    hd_action_unpark_filter = ~df.hd_action_unpark
    hd_action_unpark_capping_filter= ~df.hd_action_unpark_capping
    hd_action_park_filter= ~df.hd_action_park
    hd_action_park_capping_filter= ~df.hd_action_park_capping
    hd_action_no_unparking_no_free_capacity_filter= ~df.hd_action_no_unparking_no_free_capacity
    hd_action_no_unparking_no_vl_filter= ~df.hd_action_no_unparking_no_vl
    hd_action_unpark_no_free_capacity_filter= ~df.hd_action_unpark_no_free_capacity
    hd_action_unpark_no_free_capacity_capping_filter= ~df.hd_action_unpark_no_free_capacity_capping
    hd_action_park_mvs_busy_low_filter= ~df.hd_action_park_mvs_busy_low
    hd_action_park_mvs_busy_low_capping_filter= ~df.hd_action_park_mvs_busy_low_capping
    hd_action_park_less4_guaranteed_used_filter= ~df.hd_action_park_less4_guaranteed_used
    hd_action_park_less10_guaranteed_used_filter= ~df.hd_action_park_less10_guaranteed_used
    hd_action_park_small_utilization_filter= ~df.hd_action_park_small_utilization
    hd_action_park_small_utilization_capping_filter= ~df.hd_action_park_small_utilization_capping
    hd_action_explanation = df.hd_action_unpark.where(df.hd_action_unpark, '')
    hd_action_explanation =  hd_action_explanation.where(hd_action_unpark_filter, 'Unpark')
    hd_action_explanation =  hd_action_explanation.where( hd_action_unpark_capping_filter, 'Unpark / capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_filter, 'Park')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_capping_filter, 'Park /  capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_no_unparking_no_free_capacity_filter, 'no free capacity')
    hd_action_explanation =  hd_action_explanation.where( hd_action_no_unparking_no_vl_filter, 'no VLs')
    hd_action_explanation =  hd_action_explanation.where( hd_action_unpark_no_free_capacity_filter, 'no free capacity')
    hd_action_explanation =  hd_action_explanation.where( hd_action_unpark_no_free_capacity_capping_filter, 'no free capacity / capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_mvs_busy_low_filter, 'Low MVS busy')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_mvs_busy_low_capping_filter, 'Low MVS busy low / capping')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_less4_guaranteed_used_filter, '< 4% of guaranteed used')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_less10_guaranteed_used_filter, '< 10% of guaranteed used')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_small_utilization_filter, 'Small utilization')
    hd_action_explanation =  hd_action_explanation.where( hd_action_park_small_utilization_capping_filter, 'Small utilization / capping')
    return hd_action_explanation

"""

hd_request : Final[Field] = Field(
    name='hd_request',
    origin=None,
    post="core.inline",
    post_param=__hd_request_inline_post,
    virtual=True,
    ref=[hd_action_no_unparking_no_free_capacity, hd_action_no_unparking_no_vl, hd_action_unpark, hd_action_unpark_no_free_capacity, hd_action_unpark_no_free_capacity_capping, hd_action_unpark_capping, hd_action_park_mvs_busy_low, hd_action_park_mvs_busy_low_capping, hd_action_park_less4_guaranteed_used, hd_action_park_less10_guaranteed_used, hd_action_park_small_utilization, hd_action_park_small_utilization_capping, hd_action_park, hd_action_park_capping],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Action taken by HiperDispatch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hd_action_no_unparking_no_free_capacity`(Virtual), `hd_action_no_unparking_no_vl`(Virtual), `hd_action_unpark`(Virtual), `hd_action_unpark_no_free_capacity`(Virtual), `hd_action_unpark_no_free_capacity_capping`(Virtual), `hd_action_unpark_capping`(Virtual), `hd_action_park_mvs_busy_low`(Virtual), `hd_action_park_mvs_busy_low_capping`(Virtual), `hd_action_park_less4_guaranteed_used`(Virtual), `hd_action_park_less10_guaranteed_used`(Virtual), `hd_action_park_small_utilization`(Virtual), `hd_action_park_small_utilization_capping`(Virtual), `hd_action_park`(Virtual), `hd_action_park_capping`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    hd_action_unpark_filter = ~df.hd_action_unpark
    hd_action_unpark_capping_filter= ~df.hd_action_unpark_capping
    hd_action_park_filter= ~df.hd_action_park
    hd_action_park_capping_filter= ~df.hd_action_park_capping
    hd_action_no_unparking_no_free_capacity_filter= ~df.hd_action_no_unparking_no_free_capacity
    hd_action_no_unparking_no_vl_filter= ~df.hd_action_no_unparking_no_vl
    hd_action_unpark_no_free_capacity_filter= ~df.hd_action_unpark_no_free_capacity
    hd_action_unpark_no_free_capacity_capping_filter= ~df.hd_action_unpark_no_free_capacity_capping
    hd_action_park_mvs_busy_low_filter= ~df.hd_action_park_mvs_busy_low
    hd_action_park_mvs_busy_low_capping_filter= ~df.hd_action_park_mvs_busy_low_capping
    hd_action_park_less4_guaranteed_used_filter= ~df.hd_action_park_less4_guaranteed_used
    hd_action_park_less10_guaranteed_used_filter= ~df.hd_action_park_less10_guaranteed_used
    hd_action_park_small_utilization_filter= ~df.hd_action_park_small_utilization
    hd_action_park_small_utilization_capping_filter= ~df.hd_action_park_small_utilization_capping
    hd_request  = df.hd_action_unpark.where(df.hd_action_unpark, '')
    hd_request  = hd_request.where(hd_action_unpark_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_unpark_capping_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_park_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_capping_filter, 'Park')
    hd_request  = hd_request.where( hd_action_no_unparking_no_free_capacity_filter, 'No unparking')
    hd_request  = hd_request.where( hd_action_no_unparking_no_vl_filter, 'No unparking')
    hd_request  = hd_request.where( hd_action_unpark_no_free_capacity_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_unpark_no_free_capacity_capping_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_park_mvs_busy_low_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_mvs_busy_low_capping_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_less4_guaranteed_used_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_less10_guaranteed_used_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_small_utilization_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_small_utilization_capping_filter, 'Park')
    return hd_request

"""
hd_request.__doc__ = """Action taken by HiperDispatch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hd_action_no_unparking_no_free_capacity`(Virtual), `hd_action_no_unparking_no_vl`(Virtual), `hd_action_unpark`(Virtual), `hd_action_unpark_no_free_capacity`(Virtual), `hd_action_unpark_no_free_capacity_capping`(Virtual), `hd_action_unpark_capping`(Virtual), `hd_action_park_mvs_busy_low`(Virtual), `hd_action_park_mvs_busy_low_capping`(Virtual), `hd_action_park_less4_guaranteed_used`(Virtual), `hd_action_park_less10_guaranteed_used`(Virtual), `hd_action_park_small_utilization`(Virtual), `hd_action_park_small_utilization_capping`(Virtual), `hd_action_park`(Virtual), `hd_action_park_capping`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    hd_action_unpark_filter = ~df.hd_action_unpark
    hd_action_unpark_capping_filter= ~df.hd_action_unpark_capping
    hd_action_park_filter= ~df.hd_action_park
    hd_action_park_capping_filter= ~df.hd_action_park_capping
    hd_action_no_unparking_no_free_capacity_filter= ~df.hd_action_no_unparking_no_free_capacity
    hd_action_no_unparking_no_vl_filter= ~df.hd_action_no_unparking_no_vl
    hd_action_unpark_no_free_capacity_filter= ~df.hd_action_unpark_no_free_capacity
    hd_action_unpark_no_free_capacity_capping_filter= ~df.hd_action_unpark_no_free_capacity_capping
    hd_action_park_mvs_busy_low_filter= ~df.hd_action_park_mvs_busy_low
    hd_action_park_mvs_busy_low_capping_filter= ~df.hd_action_park_mvs_busy_low_capping
    hd_action_park_less4_guaranteed_used_filter= ~df.hd_action_park_less4_guaranteed_used
    hd_action_park_less10_guaranteed_used_filter= ~df.hd_action_park_less10_guaranteed_used
    hd_action_park_small_utilization_filter= ~df.hd_action_park_small_utilization
    hd_action_park_small_utilization_capping_filter= ~df.hd_action_park_small_utilization_capping
    hd_request  = df.hd_action_unpark.where(df.hd_action_unpark, '')
    hd_request  = hd_request.where(hd_action_unpark_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_unpark_capping_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_park_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_capping_filter, 'Park')
    hd_request  = hd_request.where( hd_action_no_unparking_no_free_capacity_filter, 'No unparking')
    hd_request  = hd_request.where( hd_action_no_unparking_no_vl_filter, 'No unparking')
    hd_request  = hd_request.where( hd_action_unpark_no_free_capacity_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_unpark_no_free_capacity_capping_filter, 'Unpark')
    hd_request  = hd_request.where( hd_action_park_mvs_busy_low_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_mvs_busy_low_capping_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_less4_guaranteed_used_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_less10_guaranteed_used_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_small_utilization_filter, 'Park')
    hd_request  = hd_request.where( hd_action_park_small_utilization_capping_filter, 'Park')
    return hd_request

"""

cpu_total : Final[Field] = Field(
    name='cpu_total',
    origin=None,
    post="core.inline",
    post_param=__cpu_total_inline_post,
    virtual=True,
    ref=[cpu_vh, cpu_vm, cpu_vl],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""number of VH, VM and VL processors(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_vh`(`SMF99C_VCM_CPUHI`), `cpu_vm`(`SMF99C_VCM_CPUMED`), `cpu_vl`(`SMF99C_VCM_CPULO`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_vh + df.cpu_vm + df.cpu_vl

"""
cpu_total.__doc__ = """number of VH, VM and VL processors(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_vh`(`SMF99C_VCM_CPUHI`), `cpu_vm`(`SMF99C_VCM_CPUMED`), `cpu_vl`(`SMF99C_VCM_CPULO`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_vh + df.cpu_vm + df.cpu_vl

"""

lpar_busy : Final[Field] = Field(
    name='lpar_busy',
    origin=None,
    post="core.inline",
    post_param=__lpar_busy_inline_post,
    virtual=True,
    ref=[lpar_capacity_used, cpu_total],
    record=record,
    record_map=SMF99_S12_HD_INT_CAP_MAP,
)
"""Used LPAR capacity in microseconds, adjusted to the scheduled VCM inte...(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lpar_capacity_used`(`SMF99C_VCM_LPARCAPUSEDADJ`), `cpu_total`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used LPAR capacity in microseconds, adjusted to the scheduled VCM interval length

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.lpar_capacity_used / df.cpu_total / 20000

"""
lpar_busy.__doc__ = """Used LPAR capacity in microseconds, adjusted to the scheduled VCM inte...(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lpar_capacity_used`(`SMF99C_VCM_LPARCAPUSEDADJ`), `cpu_total`(Virtual)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_CAP_MAP`

Used LPAR capacity in microseconds, adjusted to the scheduled VCM interval length

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.lpar_capacity_used / df.cpu_total / 20000

"""

hd_int_proc_idx : Final[Field] = Field(
    name='hd_int_proc_idx',
    origin='SMF99C_HD_INT_PROC_IDX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S12_HD_INT_PROC_MAP,
)
"""HiperDispatch interval processor index

SMF Info
--------
    Field: `SMF99C_HD_INT_PROC_IDX`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

HiperDispatch interval processor index
"""
hd_int_proc_idx.__doc__ = """HiperDispatch interval processor index

SMF Info
--------
    Field: `SMF99C_HD_INT_PROC_IDX`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

HiperDispatch interval processor index
"""

lccadsf2 : Final[Field] = Field(
    name='lccadsf2',
    origin='SMF99C_LCCADSF2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_PROC_MAP,
)
"""Processor Flag 1

SMF Info
--------
    Field: `SMF99C_LCCADSF2`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

Processor Flag 1
"""
lccadsf2.__doc__ = """Processor Flag 1

SMF Info
--------
    Field: `SMF99C_LCCADSF2`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

Processor Flag 1
"""

lccapark : Final[Field] = Field(
    name='lccapark',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=lccadsf2,
    record=record,
    record_map=SMF99_S12_HD_INT_PROC_MAP,
)
"""Processor parked(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lccadsf2`(`SMF99C_LCCADSF2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

Processor parked

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
lccapark.__doc__ = """Processor parked(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lccadsf2`(`SMF99C_LCCADSF2`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

Processor parked

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

lccascfl : Final[Field] = Field(
    name='lccascfl',
    origin='SMF99C_LCCASCFL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S12_HD_INT_PROC_MAP,
)
"""Processor Flag 2

SMF Info
--------
    Field: `SMF99C_LCCASCFL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

Processor Flag 2
"""
lccascfl.__doc__ = """Processor Flag 2

SMF Info
--------
    Field: `SMF99C_LCCASCFL`
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

Processor Flag 2
"""

lccappnd : Final[Field] = Field(
    name='lccappnd',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=lccascfl,
    record=record,
    record_map=SMF99_S12_HD_INT_PROC_MAP,
)
"""Processor park request pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lccascfl`(`SMF99C_LCCASCFL`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

Processor park request pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
lccappnd.__doc__ = """Processor park request pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lccascfl`(`SMF99C_LCCASCFL`)
    Record: `SMF99S12`
    Map: `SMF99_S12_HD_INT_PROC_MAP`

Processor park request pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
