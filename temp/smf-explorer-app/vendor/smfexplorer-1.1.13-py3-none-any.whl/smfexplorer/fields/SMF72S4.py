# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 72 Subtype 4"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=72,
                                smf_subtype=4,
                                spec='SMF 72 Subtype 4',
                                post=None)
"""SMF 72 Subtype 4"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __interval_in_milliseconds_inline_post(df):
    return df.interval.dt.total_seconds() * 1e3



SMF72PRO: Final[RecordMap] = RecordMap(
    origin='SMF72PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=True)
"""RMF Product Section"""
R724DATA: Final[RecordMap] = RecordMap(
    origin='R724DATA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Service Class Period Data Section (Subtype 4)',
    post=None,
    record_mapping=False)
"""Service Class Period Data Section (Subtype 4)"""
R724SWRE: Final[RecordMap] = RecordMap(
    origin='R724SWRE',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Swap Reason Data Section (Subtype 4)',
    post=None,
    record_mapping=False)
"""Swap Reason Data Section (Subtype 4)"""

date : Final[Field] = Field(
    name='date',
    origin='SMF72DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S4`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S4`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF72TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S4`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S4`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF72DTE`), `time`(`SMF72TME`)
    Record: `SMF72S4`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF72DTE`), `time`(`SMF72TME`)
    Record: `SMF72S4`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF72LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF72LEN`
    Record: `SMF72S4`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF72LEN`
    Record: `SMF72S4`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF72SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF72SEG`
    Record: `SMF72S4`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF72SEG`
    Record: `SMF72S4`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF72FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF72FLG`
    Record: `SMF72S4`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF72FLG`
    Record: `SMF72S4`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

new_record : Final[Field] = Field(
    name='new_record',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
new_record.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

subtypes_used : Final[Field] = Field(
    name='subtypes_used',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
subtypes_used.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

prsm_mode : Final[Field] = Field(
    name='prsm_mode',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
prsm_mode.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S4`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF72RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF72RTY`
    Record: `SMF72S4`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF72RTY`
    Record: `SMF72S4`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF72TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S4`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S4`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF72DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S4`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S4`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF72SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF72SID`
    Record: `SMF72S4`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF72SID`
    Record: `SMF72S4`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF72SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF72SSI`
    Record: `SMF72S4`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF72SSI`
    Record: `SMF72S4`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF72STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF72STY`
    Record: `SMF72S4`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF72STY`
    Record: `SMF72S4`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF72TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF72TRN`
    Record: `SMF72S4`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF72TRN`
    Record: `SMF72S4`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF72PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRS`
    Record: `SMF72S4`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRS`
    Record: `SMF72S4`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF72PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRL`
    Record: `SMF72S4`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRL`
    Record: `SMF72S4`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF72PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF72PRN`
    Record: `SMF72S4`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF72PRN`
    Record: `SMF72S4`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

cps : Final[Field] = Field(
    name='cps',
    origin='SMF72CPS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to service class period data sections (subtype4)

SMF Info
--------
    Field: `SMF72CPS`
    Record: `SMF72S4`
    Map: Not part of a map

Offset to service class period data sections (subtype4)
"""
cps.__doc__ = """Offset to service class period data sections (subtype4)

SMF Info
--------
    Field: `SMF72CPS`
    Record: `SMF72S4`
    Map: Not part of a map

Offset to service class period data sections (subtype4)
"""

cpl : Final[Field] = Field(
    name='cpl',
    origin='SMF72CPL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of service class period data sections (subtype4)

SMF Info
--------
    Field: `SMF72CPL`
    Record: `SMF72S4`
    Map: Not part of a map

Length of service class period data sections (subtype4)
"""
cpl.__doc__ = """Length of service class period data sections (subtype4)

SMF Info
--------
    Field: `SMF72CPL`
    Record: `SMF72S4`
    Map: Not part of a map

Length of service class period data sections (subtype4)
"""

cpn : Final[Field] = Field(
    name='cpn',
    origin='SMF72CPN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of service class period data sections (subtype4)

SMF Info
--------
    Field: `SMF72CPN`
    Record: `SMF72S4`
    Map: Not part of a map

Number of service class period data sections (subtype4)
"""
cpn.__doc__ = """Number of service class period data sections (subtype4)

SMF Info
--------
    Field: `SMF72CPN`
    Record: `SMF72S4`
    Map: Not part of a map

Number of service class period data sections (subtype4)
"""

sps : Final[Field] = Field(
    name='sps',
    origin='SMF72SPS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to swap reason data sections (subtype 4)

SMF Info
--------
    Field: `SMF72SPS`
    Record: `SMF72S4`
    Map: Not part of a map

Offset to swap reason data sections (subtype 4)
"""
sps.__doc__ = """Offset to swap reason data sections (subtype 4)

SMF Info
--------
    Field: `SMF72SPS`
    Record: `SMF72S4`
    Map: Not part of a map

Offset to swap reason data sections (subtype 4)
"""

spl : Final[Field] = Field(
    name='spl',
    origin='SMF72SPL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of swap reason data sections (subtype 4)

SMF Info
--------
    Field: `SMF72SPL`
    Record: `SMF72S4`
    Map: Not part of a map

Length of swap reason data sections (subtype 4)
"""
spl.__doc__ = """Length of swap reason data sections (subtype 4)

SMF Info
--------
    Field: `SMF72SPL`
    Record: `SMF72S4`
    Map: Not part of a map

Length of swap reason data sections (subtype 4)
"""

spn : Final[Field] = Field(
    name='spn',
    origin='SMF72SPN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of swap reason data sections (subtype 4)

SMF Info
--------
    Field: `SMF72SPN`
    Record: `SMF72S4`
    Map: Not part of a map

Number of swap reason data sections (subtype 4)
"""
spn.__doc__ = """Number of swap reason data sections (subtype 4)

SMF Info
--------
    Field: `SMF72SPN`
    Record: `SMF72S4`
    Map: Not part of a map

Number of swap reason data sections (subtype 4)
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF72MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF72MFV`
    Record: `SMF72S4`
    Map: `SMF72PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF72MFV`
    Record: `SMF72S4`
    Map: `SMF72PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF72PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF72PRD`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF72PRD`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF72IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF72PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF72IST`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF72IST`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF72DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF72PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF72DAT`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF72DAT`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Date monitor interval start
"""

interval : Final[Field] = Field(
    name='interval',
    origin='SMF72INT',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF72PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF72INT`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Duration of monitor interval
"""
interval.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF72INT`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF72SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF72SAM`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF72SAM`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF72FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF72FLA`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF72FLA`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF72CYC',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF72PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF72CYC`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF72CYC`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF72MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF72MVS`
    Record: `SMF72S4`
    Map: `SMF72PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF72MVS`
    Record: `SMF72S4`
    Map: `SMF72PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF72IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF72IML`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF72IML`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF72PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF72PRF`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF72PRF`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF72PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF72PTN`
    Record: `SMF72S4`
    Map: `SMF72PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF72PTN`
    Record: `SMF72S4`
    Map: `SMF72PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF72SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF72SRL`
    Record: `SMF72S4`
    Map: `SMF72PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF72SRL`
    Record: `SMF72S4`
    Map: `SMF72PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF72IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF72PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF72IET`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF72IET`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF72LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF72LGO`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF72LGO`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF72RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF72RAO`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF72RAO`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF72RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF72RAL`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF72RAL`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF72RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF72RAN`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF72RAN`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF72OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF72OIL`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF72OIL`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF72SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF72SYN`
    Record: `SMF72S4`
    Map: `SMF72PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF72SYN`
    Record: `SMF72S4`
    Map: `SMF72PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF72GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF72PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF72GIE`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF72GIE`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF72XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF72XNM`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF72XNM`
    Record: `SMF72S4`
    Map: `SMF72PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF72SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF72SNM`
    Record: `SMF72S4`
    Map: `SMF72PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF72SNM`
    Record: `SMF72S4`
    Map: `SMF72PRO`

System name for current system as defined in CVTSNAME
"""

interval_in_milliseconds : Final[Field] = Field(
    name='interval_in_milliseconds',
    origin=None,
    post="core.inline",
    post_param=__interval_in_milliseconds_inline_post,
    virtual=True,
    ref=interval,
    record=record,
    record_map=SMF72PRO,
)
"""Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF72INT`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""
interval_in_milliseconds.__doc__ = """Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF72INT`)
    Record: `SMF72S4`
    Map: `SMF72PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""

r724pnam : Final[Field] = Field(
    name='r724pnam',
    origin='R724PNAM',
    type=FieldType.STRING,
    record=record,
    record_map=R724DATA,
)
"""Name of active service policy

SMF Info
--------
    Field: `R724PNAM`
    Record: `SMF72S4`
    Map: `R724DATA`

Name of active service policy
"""
r724pnam.__doc__ = """Name of active service policy

SMF Info
--------
    Field: `R724PNAM`
    Record: `SMF72S4`
    Map: `R724DATA`

Name of active service policy
"""

r724ptm : Final[Field] = Field(
    name='r724ptm',
    origin='R724PTM',
    type=FieldType.TIME,
    record=record,
    record_map=R724DATA,
)
"""Time policy was activated (Format: STORE CLOCK Unit: local time)

SMF Info
--------
    Field: `R724PTM`
    Record: `SMF72S4`
    Map: `R724DATA`

Time policy was activated (Format: STORE CLOCK Unit: local time)
"""
r724ptm.__doc__ = """Time policy was activated (Format: STORE CLOCK Unit: local time)

SMF Info
--------
    Field: `R724PTM`
    Record: `SMF72S4`
    Map: `R724DATA`

Time policy was activated (Format: STORE CLOCK Unit: local time)
"""

r724lcnm : Final[Field] = Field(
    name='r724lcnm',
    origin='R724LCNM',
    type=FieldType.STRING,
    record=record,
    record_map=R724DATA,
)
"""Service class name

SMF Info
--------
    Field: `R724LCNM`
    Record: `SMF72S4`
    Map: `R724DATA`

Service class name
"""
r724lcnm.__doc__ = """Service class name

SMF Info
--------
    Field: `R724LCNM`
    Record: `SMF72S4`
    Map: `R724DATA`

Service class name
"""

r724percount : Final[Field] = Field(
    name='r724percount',
    origin='R724PER#',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Service class period number

SMF Info
--------
    Field: `R724PER#`
    Record: `SMF72S4`
    Map: `R724DATA`

Service class period number
"""
r724percount.__doc__ = """Service class period number

SMF Info
--------
    Field: `R724PER#`
    Record: `SMF72S4`
    Map: `R724DATA`

Service class period number
"""

r724user : Final[Field] = Field(
    name='r724user',
    origin='R724USER',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Sum of all users found

SMF Info
--------
    Field: `R724USER`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all users found
"""
r724user.__doc__ = """Sum of all users found

SMF Info
--------
    Field: `R724USER`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all users found
"""

r724actv : Final[Field] = Field(
    name='r724actv',
    origin='R724ACTV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Sum of all active users found

SMF Info
--------
    Field: `R724ACTV`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all active users found
"""
r724actv.__doc__ = """Sum of all active users found

SMF Info
--------
    Field: `R724ACTV`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all active users found
"""

r724acts : Final[Field] = Field(
    name='r724acts',
    origin='R724ACTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Sum of all active samples (except OUTR)

SMF Info
--------
    Field: `R724ACTS`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all active samples (except OUTR)
"""
r724acts.__doc__ = """Sum of all active samples (except OUTR)

SMF Info
--------
    Field: `R724ACTS`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all active samples (except OUTR)
"""

r724idls : Final[Field] = Field(
    name='r724idls',
    origin='R724IDLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Sum of all idle samples

SMF Info
--------
    Field: `R724IDLS`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all idle samples
"""
r724idls.__doc__ = """Sum of all idle samples

SMF Info
--------
    Field: `R724IDLS`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all idle samples
"""

r724page : Final[Field] = Field(
    name='r724page',
    origin='R724PAGE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Sum of all users delayed for paging at all samples

SMF Info
--------
    Field: `R724PAGE`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all users delayed for paging at all samples
"""
r724page.__doc__ = """Sum of all users delayed for paging at all samples

SMF Info
--------
    Field: `R724PAGE`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all users delayed for paging at all samples
"""

r724swap : Final[Field] = Field(
    name='r724swap',
    origin='R724SWAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Sum of all users delayed for swapping at all samples

SMF Info
--------
    Field: `R724SWAP`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all users delayed for swapping at all samples
"""
r724swap.__doc__ = """Sum of all users delayed for swapping at all samples

SMF Info
--------
    Field: `R724SWAP`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all users delayed for swapping at all samples
"""

r724outr : Final[Field] = Field(
    name='r724outr',
    origin='R724OUTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Sum of all out and ready users at all samples

SMF Info
--------
    Field: `R724OUTR`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all out and ready users at all samples
"""
r724outr.__doc__ = """Sum of all out and ready users at all samples

SMF Info
--------
    Field: `R724OUTR`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all out and ready users at all samples
"""

r724pgin : Final[Field] = Field(
    name='r724pgin',
    origin='R724PGIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Sum of all page-ins

SMF Info
--------
    Field: `R724PGIN`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all page-ins
"""
r724pgin.__doc__ = """Sum of all page-ins

SMF Info
--------
    Field: `R724PGIN`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all page-ins
"""

r724divs : Final[Field] = Field(
    name='r724divs',
    origin='R724DIVS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Sum of all DIV samples

SMF Info
--------
    Field: `R724DIVS`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all DIV samples
"""
r724divs.__doc__ = """Sum of all DIV samples

SMF Info
--------
    Field: `R724DIVS`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all DIV samples
"""

r724lssa : Final[Field] = Field(
    name='r724lssa',
    origin='R724LSSA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total logically swapped samples for the group

SMF Info
--------
    Field: `R724LSSA`
    Record: `SMF72S4`
    Map: `R724DATA`

Total logically swapped samples for the group
"""
r724lssa.__doc__ = """Total logically swapped samples for the group

SMF Info
--------
    Field: `R724LSSA`
    Record: `SMF72S4`
    Map: `R724DATA`

Total logically swapped samples for the group
"""

r724pssa : Final[Field] = Field(
    name='r724pssa',
    origin='R724PSSA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total swapped samples for the group (except logical)

SMF Info
--------
    Field: `R724PSSA`
    Record: `SMF72S4`
    Map: `R724DATA`

Total swapped samples for the group (except logical)
"""
r724pssa.__doc__ = """Total swapped samples for the group (except logical)

SMF Info
--------
    Field: `R724PSSA`
    Record: `SMF72S4`
    Map: `R724DATA`

Total swapped samples for the group (except logical)
"""

r724upro : Final[Field] = Field(
    name='r724upro',
    origin='R724UPRO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total processor using samples for the group

SMF Info
--------
    Field: `R724UPRO`
    Record: `SMF72S4`
    Map: `R724DATA`

Total processor using samples for the group
"""
r724upro.__doc__ = """Total processor using samples for the group

SMF Info
--------
    Field: `R724UPRO`
    Record: `SMF72S4`
    Map: `R724DATA`

Total processor using samples for the group
"""

r724udev : Final[Field] = Field(
    name='r724udev',
    origin='R724UDEV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total device using samples for the group

SMF Info
--------
    Field: `R724UDEV`
    Record: `SMF72S4`
    Map: `R724DATA`

Total device using samples for the group
"""
r724udev.__doc__ = """Total device using samples for the group

SMF Info
--------
    Field: `R724UDEV`
    Record: `SMF72S4`
    Map: `R724DATA`

Total device using samples for the group
"""

r724dpro : Final[Field] = Field(
    name='r724dpro',
    origin='R724DPRO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total processor delay samples for the group

SMF Info
--------
    Field: `R724DPRO`
    Record: `SMF72S4`
    Map: `R724DATA`

Total processor delay samples for the group
"""
r724dpro.__doc__ = """Total processor delay samples for the group

SMF Info
--------
    Field: `R724DPRO`
    Record: `SMF72S4`
    Map: `R724DATA`

Total processor delay samples for the group
"""

r724ddev : Final[Field] = Field(
    name='r724ddev',
    origin='R724DDEV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total device delay samples for the group

SMF Info
--------
    Field: `R724DDEV`
    Record: `SMF72S4`
    Map: `R724DATA`

Total device delay samples for the group
"""
r724ddev.__doc__ = """Total device delay samples for the group

SMF Info
--------
    Field: `R724DDEV`
    Record: `SMF72S4`
    Map: `R724DATA`

Total device delay samples for the group
"""

r724dsto : Final[Field] = Field(
    name='r724dsto',
    origin='R724DSTO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total storage delay samples for the group

SMF Info
--------
    Field: `R724DSTO`
    Record: `SMF72S4`
    Map: `R724DATA`

Total storage delay samples for the group
"""
r724dsto.__doc__ = """Total storage delay samples for the group

SMF Info
--------
    Field: `R724DSTO`
    Record: `SMF72S4`
    Map: `R724DATA`

Total storage delay samples for the group
"""

r724djes : Final[Field] = Field(
    name='r724djes',
    origin='R724DJES',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total JES delay samples for the group

SMF Info
--------
    Field: `R724DJES`
    Record: `SMF72S4`
    Map: `R724DATA`

Total JES delay samples for the group
"""
r724djes.__doc__ = """Total JES delay samples for the group

SMF Info
--------
    Field: `R724DJES`
    Record: `SMF72S4`
    Map: `R724DATA`

Total JES delay samples for the group
"""

r724dhsm : Final[Field] = Field(
    name='r724dhsm',
    origin='R724DHSM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total HSM delay samples for the group

SMF Info
--------
    Field: `R724DHSM`
    Record: `SMF72S4`
    Map: `R724DATA`

Total HSM delay samples for the group
"""
r724dhsm.__doc__ = """Total HSM delay samples for the group

SMF Info
--------
    Field: `R724DHSM`
    Record: `SMF72S4`
    Map: `R724DATA`

Total HSM delay samples for the group
"""

r724dxcf : Final[Field] = Field(
    name='r724dxcf',
    origin='R724DXCF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total XCF delay samples for the group

SMF Info
--------
    Field: `R724DXCF`
    Record: `SMF72S4`
    Map: `R724DATA`

Total XCF delay samples for the group
"""
r724dxcf.__doc__ = """Total XCF delay samples for the group

SMF Info
--------
    Field: `R724DXCF`
    Record: `SMF72S4`
    Map: `R724DATA`

Total XCF delay samples for the group
"""

r724denq : Final[Field] = Field(
    name='r724denq',
    origin='R724DENQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total ENQ delay samples for the group

SMF Info
--------
    Field: `R724DENQ`
    Record: `SMF72S4`
    Map: `R724DATA`

Total ENQ delay samples for the group
"""
r724denq.__doc__ = """Total ENQ delay samples for the group

SMF Info
--------
    Field: `R724DENQ`
    Record: `SMF72S4`
    Map: `R724DATA`

Total ENQ delay samples for the group
"""

r724dmnt : Final[Field] = Field(
    name='r724dmnt',
    origin='R724DMNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total mount delay samples for the group

SMF Info
--------
    Field: `R724DMNT`
    Record: `SMF72S4`
    Map: `R724DATA`

Total mount delay samples for the group
"""
r724dmnt.__doc__ = """Total mount delay samples for the group

SMF Info
--------
    Field: `R724DMNT`
    Record: `SMF72S4`
    Map: `R724DATA`

Total mount delay samples for the group
"""

r724dmsg : Final[Field] = Field(
    name='r724dmsg',
    origin='R724DMSG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total message delay samples for the group

SMF Info
--------
    Field: `R724DMSG`
    Record: `SMF72S4`
    Map: `R724DATA`

Total message delay samples for the group
"""
r724dmsg.__doc__ = """Total message delay samples for the group

SMF Info
--------
    Field: `R724DMSG`
    Record: `SMF72S4`
    Map: `R724DATA`

Total message delay samples for the group
"""

r724unkn : Final[Field] = Field(
    name='r724unkn',
    origin='R724UNKN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total unknown state samples for the group

SMF Info
--------
    Field: `R724UNKN`
    Record: `SMF72S4`
    Map: `R724DATA`

Total unknown state samples for the group
"""
r724unkn.__doc__ = """Total unknown state samples for the group

SMF Info
--------
    Field: `R724UNKN`
    Record: `SMF72S4`
    Map: `R724DATA`

Total unknown state samples for the group
"""

r724vald : Final[Field] = Field(
    name='r724vald',
    origin='R724VALD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Total valid samples for the group (single state sum of all using, delay, idle, and unknown)

SMF Info
--------
    Field: `R724VALD`
    Record: `SMF72S4`
    Map: `R724DATA`

Total valid samples for the group (single state sum of all using, delay, idle, and unknown)
"""
r724vald.__doc__ = """Total valid samples for the group (single state sum of all using, delay, idle, and unknown)

SMF Info
--------
    Field: `R724VALD`
    Record: `SMF72S4`
    Map: `R724DATA`

Total valid samples for the group (single state sum of all using, delay, idle, and unknown)
"""

r724lsct : Final[Field] = Field(
    name='r724lsct',
    origin='R724LSCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Count of "long" logical swaps for the group

SMF Info
--------
    Field: `R724LSCT`
    Record: `SMF72S4`
    Map: `R724DATA`

Count of "long" logical swaps for the group
"""
r724lsct.__doc__ = """Count of "long" logical swaps for the group

SMF Info
--------
    Field: `R724LSCT`
    Record: `SMF72S4`
    Map: `R724DATA`

Count of "long" logical swaps for the group
"""

r724esct : Final[Field] = Field(
    name='r724esct',
    origin='R724ESCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Count of "long" swaps to expanded storage for the group

SMF Info
--------
    Field: `R724ESCT`
    Record: `SMF72S4`
    Map: `R724DATA`

Count of "long" swaps to expanded storage for the group
"""
r724esct.__doc__ = """Count of "long" swaps to expanded storage for the group

SMF Info
--------
    Field: `R724ESCT`
    Record: `SMF72S4`
    Map: `R724DATA`

Count of "long" swaps to expanded storage for the group
"""

r724psct : Final[Field] = Field(
    name='r724psct',
    origin='R724PSCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724DATA,
)
"""Count of "long" physical swaps for the group

SMF Info
--------
    Field: `R724PSCT`
    Record: `SMF72S4`
    Map: `R724DATA`

Count of "long" physical swaps for the group
"""
r724psct.__doc__ = """Count of "long" physical swaps for the group

SMF Info
--------
    Field: `R724PSCT`
    Record: `SMF72S4`
    Map: `R724DATA`

Count of "long" physical swaps for the group
"""

r724actf : Final[Field] = Field(
    name='r724actf',
    origin='R724ACTF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of all active frames (long floating point)

SMF Info
--------
    Field: `R724ACTF`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all active frames (long floating point)
"""
r724actf.__doc__ = """Sum of all active frames (long floating point)

SMF Info
--------
    Field: `R724ACTF`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all active frames (long floating point)
"""

r724idle : Final[Field] = Field(
    name='r724idle',
    origin='R724IDLE',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of all idle frames (long floating point)

SMF Info
--------
    Field: `R724IDLE`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all idle frames (long floating point)
"""
r724idle.__doc__ = """Sum of all idle frames (long floating point)

SMF Info
--------
    Field: `R724IDLE`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all idle frames (long floating point)
"""

r724slot : Final[Field] = Field(
    name='r724slot',
    origin='R724SLOT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of all slots used (long floating point)

SMF Info
--------
    Field: `R724SLOT`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all slots used (long floating point)
"""
r724slot.__doc__ = """Sum of all slots used (long floating point)

SMF Info
--------
    Field: `R724SLOT`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all slots used (long floating point)
"""

r724div : Final[Field] = Field(
    name='r724div',
    origin='R724DIV',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of all DIV frames (long floating point)

SMF Info
--------
    Field: `R724DIV`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all DIV frames (long floating point)
"""
r724div.__doc__ = """Sum of all DIV frames (long floating point)

SMF Info
--------
    Field: `R724DIV`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all DIV frames (long floating point)
"""

r724fix : Final[Field] = Field(
    name='r724fix',
    origin='R724FIX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of all fixed frames (long floating point)

SMF Info
--------
    Field: `R724FIX`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all fixed frames (long floating point)
"""
r724fix.__doc__ = """Sum of all fixed frames (long floating point)

SMF Info
--------
    Field: `R724FIX`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all fixed frames (long floating point)
"""

r724lscf : Final[Field] = Field(
    name='r724lscf',
    origin='R724LSCF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of all central frames for all logically swapped users at all samples (long floating point)

SMF Info
--------
    Field: `R724LSCF`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all central frames for all logically swapped users at all samples (long floating point)
"""
r724lscf.__doc__ = """Sum of all central frames for all logically swapped users at all samples (long floating point)

SMF Info
--------
    Field: `R724LSCF`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all central frames for all logically swapped users at all samples (long floating point)
"""

r724lsef : Final[Field] = Field(
    name='r724lsef',
    origin='R724LSEF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of all expanded frames for all logically swapped users at all samples (long floating point)

SMF Info
--------
    Field: `R724LSEF`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all expanded frames for all logically swapped users at all samples (long floating point)
"""
r724lsef.__doc__ = """Sum of all expanded frames for all logically swapped users at all samples (long floating point)

SMF Info
--------
    Field: `R724LSEF`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all expanded frames for all logically swapped users at all samples (long floating point)
"""

r724psef : Final[Field] = Field(
    name='r724psef',
    origin='R724PSEF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of all expanded frames for all swapped users (except logical) at all samples (long floating point)

SMF Info
--------
    Field: `R724PSEF`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all expanded frames for all swapped users (except logical) at all samples (long floating point)
"""
r724psef.__doc__ = """Sum of all expanded frames for all swapped users (except logical) at all samples (long floating point)

SMF Info
--------
    Field: `R724PSEF`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of all expanded frames for all swapped users (except logical) at all samples (long floating point)
"""

r724vect : Final[Field] = Field(
    name='r724vect',
    origin='R724VECT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Total vector utilization time for the group (Format: long floating point Unit: microseconds)

SMF Info
--------
    Field: `R724VECT`
    Record: `SMF72S4`
    Map: `R724DATA`

Total vector utilization time for the group (Format: long floating point Unit: microseconds)
"""
r724vect.__doc__ = """Total vector utilization time for the group (Format: long floating point Unit: microseconds)

SMF Info
--------
    Field: `R724VECT`
    Record: `SMF72S4`
    Map: `R724DATA`

Total vector utilization time for the group (Format: long floating point Unit: microseconds)
"""

r724et : Final[Field] = Field(
    name='r724et',
    origin='R724ET',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Total execution time for all transactions that ended in the group. Does not include queued time. (Format: long floating point Unit: 1024-microseconds)

SMF Info
--------
    Field: `R724ET`
    Record: `SMF72S4`
    Map: `R724DATA`

Total execution time for all transactions that ended in the group. Does not include queued time. (Format: long floating point Unit: 1024-microseconds)
"""
r724et.__doc__ = """Total execution time for all transactions that ended in the group. Does not include queued time. (Format: long floating point Unit: 1024-microseconds)

SMF Info
--------
    Field: `R724ET`
    Record: `SMF72S4`
    Map: `R724DATA`

Total execution time for all transactions that ended in the group. Does not include queued time. (Format: long floating point Unit: 1024-microseconds)
"""

r724qt : Final[Field] = Field(
    name='r724qt',
    origin='R724QT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Total time spent on JES or APPC queues by all transactions that ended in the group (Format: long floating point Unit: 1024-microseconds)

SMF Info
--------
    Field: `R724QT`
    Record: `SMF72S4`
    Map: `R724DATA`

Total time spent on JES or APPC queues by all transactions that ended in the group (Format: long floating point Unit: 1024-microseconds)
"""
r724qt.__doc__ = """Total time spent on JES or APPC queues by all transactions that ended in the group (Format: long floating point Unit: 1024-microseconds)

SMF Info
--------
    Field: `R724QT`
    Record: `SMF72S4`
    Map: `R724DATA`

Total time spent on JES or APPC queues by all transactions that ended in the group (Format: long floating point Unit: 1024-microseconds)
"""

r724end : Final[Field] = Field(
    name='r724end',
    origin='R724END',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""The number of transactions that ended in the group (Format: long floating point Unit: microseconds)

SMF Info
--------
    Field: `R724END`
    Record: `SMF72S4`
    Map: `R724DATA`

The number of transactions that ended in the group (Format: long floating point Unit: microseconds)
"""
r724end.__doc__ = """The number of transactions that ended in the group (Format: long floating point Unit: microseconds)

SMF Info
--------
    Field: `R724END`
    Record: `SMF72S4`
    Map: `R724DATA`

The number of transactions that ended in the group (Format: long floating point Unit: microseconds)
"""

r724tsv : Final[Field] = Field(
    name='r724tsv',
    origin='R724TSV',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of shared page views (long floating point)

SMF Info
--------
    Field: `R724TSV`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of shared page views (long floating point)
"""
r724tsv.__doc__ = """Sum of shared page views (long floating point)

SMF Info
--------
    Field: `R724TSV`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of shared page views (long floating point)
"""

r724vin : Final[Field] = Field(
    name='r724vin',
    origin='R724VIN',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of shared pages in central storage, that are valid (long floating point)

SMF Info
--------
    Field: `R724VIN`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of shared pages in central storage, that are valid (long floating point)
"""
r724vin.__doc__ = """Sum of shared pages in central storage, that are valid (long floating point)

SMF Info
--------
    Field: `R724VIN`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of shared pages in central storage, that are valid (long floating point)
"""

r724vlc : Final[Field] = Field(
    name='r724vlc',
    origin='R724VLC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of shared page validations (long floating point)

SMF Info
--------
    Field: `R724VLC`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of shared page validations (long floating point)
"""
r724vlc.__doc__ = """Sum of shared page validations (long floating point)

SMF Info
--------
    Field: `R724VLC`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of shared page validations (long floating point)
"""

r724gpi : Final[Field] = Field(
    name='r724gpi',
    origin='R724GPI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Sum of shared page-ins from auxiliary storage (long floating point)

SMF Info
--------
    Field: `R724GPI`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of shared page-ins from auxiliary storage (long floating point)
"""
r724gpi.__doc__ = """Sum of shared page-ins from auxiliary storage (long floating point)

SMF Info
--------
    Field: `R724GPI`
    Record: `SMF72S4`
    Map: `R724DATA`

Sum of shared page-ins from auxiliary storage (long floating point)
"""

r724etx : Final[Field] = Field(
    name='r724etx',
    origin='R724ETX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Total execution time for all transactions that ended in the group. Same as R724ET, but in microseconds.

SMF Info
--------
    Field: `R724ETX`
    Record: `SMF72S4`
    Map: `R724DATA`

Total execution time for all transactions that ended in the group. Same as R724ET, but in microseconds.
"""
r724etx.__doc__ = """Total execution time for all transactions that ended in the group. Same as R724ET, but in microseconds.

SMF Info
--------
    Field: `R724ETX`
    Record: `SMF72S4`
    Map: `R724DATA`

Total execution time for all transactions that ended in the group. Same as R724ET, but in microseconds.
"""

r724qtx : Final[Field] = Field(
    name='r724qtx',
    origin='R724QTX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R724DATA,
)
"""Total time spent on JES or APPC queues by all transactions that ended in the group. Same as R724QT, but in microseconds.

SMF Info
--------
    Field: `R724QTX`
    Record: `SMF72S4`
    Map: `R724DATA`

Total time spent on JES or APPC queues by all transactions that ended in the group. Same as R724QT, but in microseconds.
"""
r724qtx.__doc__ = """Total time spent on JES or APPC queues by all transactions that ended in the group. Same as R724QT, but in microseconds.

SMF Info
--------
    Field: `R724QTX`
    Record: `SMF72S4`
    Map: `R724DATA`

Total time spent on JES or APPC queues by all transactions that ended in the group. Same as R724QT, but in microseconds.
"""

r724or1 : Final[Field] = Field(
    name='r724or1',
    origin='R724OR1',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 1: Terminal output wait

SMF Info
--------
    Field: `R724OR1`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 1: Terminal output wait
"""
r724or1.__doc__ = """STOR/OUTR delay samples for swap reason 1: Terminal output wait

SMF Info
--------
    Field: `R724OR1`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 1: Terminal output wait
"""

r724or2 : Final[Field] = Field(
    name='r724or2',
    origin='R724OR2',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 2: Terminal input wait

SMF Info
--------
    Field: `R724OR2`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 2: Terminal input wait
"""
r724or2.__doc__ = """STOR/OUTR delay samples for swap reason 2: Terminal input wait

SMF Info
--------
    Field: `R724OR2`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 2: Terminal input wait
"""

r724or3 : Final[Field] = Field(
    name='r724or3',
    origin='R724OR3',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 3: Long wait

SMF Info
--------
    Field: `R724OR3`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 3: Long wait
"""
r724or3.__doc__ = """STOR/OUTR delay samples for swap reason 3: Long wait

SMF Info
--------
    Field: `R724OR3`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 3: Long wait
"""

r724or4 : Final[Field] = Field(
    name='r724or4',
    origin='R724OR4',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 4: Auxiliary storage shortage

SMF Info
--------
    Field: `R724OR4`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 4: Auxiliary storage shortage
"""
r724or4.__doc__ = """STOR/OUTR delay samples for swap reason 4: Auxiliary storage shortage

SMF Info
--------
    Field: `R724OR4`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 4: Auxiliary storage shortage
"""

r724or5 : Final[Field] = Field(
    name='r724or5',
    origin='R724OR5',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 5: Real storage shortage

SMF Info
--------
    Field: `R724OR5`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 5: Real storage shortage
"""
r724or5.__doc__ = """STOR/OUTR delay samples for swap reason 5: Real storage shortage

SMF Info
--------
    Field: `R724OR5`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 5: Real storage shortage
"""

r724or6 : Final[Field] = Field(
    name='r724or6',
    origin='R724OR6',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 6: Detected long wait

SMF Info
--------
    Field: `R724OR6`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 6: Detected long wait
"""
r724or6.__doc__ = """STOR/OUTR delay samples for swap reason 6: Detected long wait

SMF Info
--------
    Field: `R724OR6`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 6: Detected long wait
"""

r724or8 : Final[Field] = Field(
    name='r724or8',
    origin='R724OR8',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 8: Enqueue exchange swap

SMF Info
--------
    Field: `R724OR8`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 8: Enqueue exchange swap
"""
r724or8.__doc__ = """STOR/OUTR delay samples for swap reason 8: Enqueue exchange swap

SMF Info
--------
    Field: `R724OR8`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 8: Enqueue exchange swap
"""

r724or9 : Final[Field] = Field(
    name='r724or9',
    origin='R724OR9',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 9: Exchange swap

SMF Info
--------
    Field: `R724OR9`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 9: Exchange swap
"""
r724or9.__doc__ = """STOR/OUTR delay samples for swap reason 9: Exchange swap

SMF Info
--------
    Field: `R724OR9`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 9: Exchange swap
"""

r724or10 : Final[Field] = Field(
    name='r724or10',
    origin='R724OR10',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 10: Unilateral swap

SMF Info
--------
    Field: `R724OR10`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 10: Unilateral swap
"""
r724or10.__doc__ = """STOR/OUTR delay samples for swap reason 10: Unilateral swap

SMF Info
--------
    Field: `R724OR10`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 10: Unilateral swap
"""

r724or11 : Final[Field] = Field(
    name='r724or11',
    origin='R724OR11',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 11: Transition swap

SMF Info
--------
    Field: `R724OR11`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 11: Transition swap
"""
r724or11.__doc__ = """STOR/OUTR delay samples for swap reason 11: Transition swap

SMF Info
--------
    Field: `R724OR11`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 11: Transition swap
"""

r724or12 : Final[Field] = Field(
    name='r724or12',
    origin='R724OR12',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 12: Improve central storage usage

SMF Info
--------
    Field: `R724OR12`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 12: Improve central storage usage
"""
r724or12.__doc__ = """STOR/OUTR delay samples for swap reason 12: Improve central storage usage

SMF Info
--------
    Field: `R724OR12`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 12: Improve central storage usage
"""

r724or13 : Final[Field] = Field(
    name='r724or13',
    origin='R724OR13',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 13: Improve system paging rate

SMF Info
--------
    Field: `R724OR13`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 13: Improve system paging rate
"""
r724or13.__doc__ = """STOR/OUTR delay samples for swap reason 13: Improve system paging rate

SMF Info
--------
    Field: `R724OR13`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 13: Improve system paging rate
"""

r724or14 : Final[Field] = Field(
    name='r724or14',
    origin='R724OR14',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 14: Make room for an out too long user

SMF Info
--------
    Field: `R724OR14`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 14: Make room for an out too long user
"""
r724or14.__doc__ = """STOR/OUTR delay samples for swap reason 14: Make room for an out too long user

SMF Info
--------
    Field: `R724OR14`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 14: Make room for an out too long user
"""

r724or15 : Final[Field] = Field(
    name='r724or15',
    origin='R724OR15',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 15: APPC wait

SMF Info
--------
    Field: `R724OR15`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 15: APPC wait
"""
r724or15.__doc__ = """STOR/OUTR delay samples for swap reason 15: APPC wait

SMF Info
--------
    Field: `R724OR15`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 15: APPC wait
"""

r724or16 : Final[Field] = Field(
    name='r724or16',
    origin='R724OR16',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 16: OMVS input wait

SMF Info
--------
    Field: `R724OR16`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 16: OMVS input wait
"""
r724or16.__doc__ = """STOR/OUTR delay samples for swap reason 16: OMVS input wait

SMF Info
--------
    Field: `R724OR16`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 16: OMVS input wait
"""

r724or17 : Final[Field] = Field(
    name='r724or17',
    origin='R724OR17',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 17: OMVS output wait

SMF Info
--------
    Field: `R724OR17`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 17: OMVS output wait
"""
r724or17.__doc__ = """STOR/OUTR delay samples for swap reason 17: OMVS output wait

SMF Info
--------
    Field: `R724OR17`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 17: OMVS output wait
"""

r724or18 : Final[Field] = Field(
    name='r724or18',
    origin='R724OR18',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 18: In-real swap

SMF Info
--------
    Field: `R724OR18`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 18: In-real swap
"""
r724or18.__doc__ = """STOR/OUTR delay samples for swap reason 18: In-real swap

SMF Info
--------
    Field: `R724OR18`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 18: In-real swap
"""

r724or7a : Final[Field] = Field(
    name='r724or7a',
    origin='R724OR7A',
    type=FieldType.INTEGER,
    record=record,
    record_map=R724SWRE,
)
"""STOR/OUTR delay samples for swap reason 7: Memory pool shortage

SMF Info
--------
    Field: `R724OR7A`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 7: Memory pool shortage
"""
r724or7a.__doc__ = """STOR/OUTR delay samples for swap reason 7: Memory pool shortage

SMF Info
--------
    Field: `R724OR7A`
    Record: `SMF72S4`
    Map: `R724SWRE`

STOR/OUTR delay samples for swap reason 7: Memory pool shortage
"""
