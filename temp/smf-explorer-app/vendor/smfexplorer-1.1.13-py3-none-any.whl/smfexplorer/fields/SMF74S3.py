# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 3"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=3,
                                spec='SMF 74 Subtype 3',
                                post=None)
"""SMF 74 Subtype 3"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R743DATA: Final[RecordMap] = RecordMap(
    origin='R743DATA',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Data Section',
    post=None,
    record_mapping=False)
"""Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S3`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S3`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S3`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S3`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S3`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S3`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S3`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S3`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S3`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S3`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S3`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S3`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S3`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S3`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S3`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S3`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S3`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S3`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S3`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S3`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S3`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S3`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S3`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S3`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S3`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S3`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S3`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S3`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S3`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S3`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S3`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S3`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S3`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

po : Final[Field] = Field(
    name='po',
    origin='SMF743PO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to data section

SMF Info
--------
    Field: `SMF743PO`
    Record: `SMF74S3`
    Map: Not part of a map

Offset to data section
"""
po.__doc__ = """Offset to data section

SMF Info
--------
    Field: `SMF743PO`
    Record: `SMF74S3`
    Map: Not part of a map

Offset to data section
"""

pl : Final[Field] = Field(
    name='pl',
    origin='SMF743PL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of data section

SMF Info
--------
    Field: `SMF743PL`
    Record: `SMF74S3`
    Map: Not part of a map

Length of data section
"""
pl.__doc__ = """Length of data section

SMF Info
--------
    Field: `SMF743PL`
    Record: `SMF74S3`
    Map: Not part of a map

Length of data section
"""

pn : Final[Field] = Field(
    name='pn',
    origin='SMF743PN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of data sections

SMF Info
--------
    Field: `SMF743PN`
    Record: `SMF74S3`
    Map: Not part of a map

Number of data sections
"""
pn.__doc__ = """Number of data sections

SMF Info
--------
    Field: `SMF743PN`
    Record: `SMF74S3`
    Map: Not part of a map

Number of data sections
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S3`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S3`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S3`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S3`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S3`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S3`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S3`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S3`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S3`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S3`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S3`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S3`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S3`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S3`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

r743cycu : Final[Field] = Field(
    name='r743cycu',
    origin='R743CYCU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Number of cycle units elapsed between first and last measured sample

SMF Info
--------
    Field: `R743CYCU`
    Record: `SMF74S3`
    Map: `R743DATA`

Number of cycle units elapsed between first and last measured sample
"""
r743cycu.__doc__ = """Number of cycle units elapsed between first and last measured sample

SMF Info
--------
    Field: `R743CYCU`
    Record: `SMF74S3`
    Map: `R743DATA`

Number of cycle units elapsed between first and last measured sample
"""

r743cyct : Final[Field] = Field(
    name='r743cyct',
    origin='R743CYCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Cycle time value obtained from Monitor III options

SMF Info
--------
    Field: `R743CYCT`
    Record: `SMF74S3`
    Map: `R743DATA`

Cycle time value obtained from Monitor III options
"""
r743cyct.__doc__ = """Cycle time value obtained from Monitor III options

SMF Info
--------
    Field: `R743CYCT`
    Record: `SMF74S3`
    Map: `R743DATA`

Cycle time value obtained from Monitor III options
"""

r743flg : Final[Field] = Field(
    name='r743flg',
    origin='R743FLG',
    type=FieldType.STRING,
    record=record,
    record_map=R743DATA,
)
"""Processing flags

SMF Info
--------
    Field: `R743FLG`
    Record: `SMF74S3`
    Map: `R743DATA`

Processing flags
"""
r743flg.__doc__ = """Processing flags

SMF Info
--------
    Field: `R743FLG`
    Record: `SMF74S3`
    Map: `R743DATA`

Processing flags
"""

r743ter : Final[Field] = Field(
    name='r743ter',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""OMVS terminated or reinstated this intervall when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

OMVS terminated or reinstated this intervall when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r743ter.__doc__ = """OMVS terminated or reinstated this intervall when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

OMVS terminated or reinstated this intervall when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r743chpr : Final[Field] = Field(
    name='r743chpr',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of processes changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of processes changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r743chpr.__doc__ = """Max. number of processes changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of processes changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r743chus : Final[Field] = Field(
    name='r743chus',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of users changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of users changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r743chus.__doc__ = """Max. number of users changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of users changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r743chpu : Final[Field] = Field(
    name='r743chpu',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of processes per user changed during reporting intervall when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of processes per user changed during reporting intervall when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r743chpu.__doc__ = """Max. number of processes per user changed during reporting intervall when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of processes per user changed during reporting intervall when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r743chms : Final[Field] = Field(
    name='r743chms',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of message queue ids changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of message queue ids changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r743chms.__doc__ = """Max. number of message queue ids changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of message queue ids changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r743chse : Final[Field] = Field(
    name='r743chse',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of semaphore ids changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of semaphore ids changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r743chse.__doc__ = """Max. number of semaphore ids changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of semaphore ids changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r743chsh : Final[Field] = Field(
    name='r743chsh',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of shared memory ids changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of shared memory ids changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r743chsh.__doc__ = """Max. number of shared memory ids changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of shared memory ids changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r743chsp : Final[Field] = Field(
    name='r743chsp',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of shared memory pages changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of shared memory pages changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r743chsp.__doc__ = """Max. number of shared memory pages changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of shared memory pages changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r743chma : Final[Field] = Field(
    name='r743chma',
    origin=None,
    post='core.flags',
    post_param=8,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of memory map st pages changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of memory map st pages changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `8`
"""
r743chma.__doc__ = """Max. number of memory map st pages changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of memory map st pages changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `8`
"""

r743chpa : Final[Field] = Field(
    name='r743chpa',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of shared storage pages changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of shared storage pages changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
r743chpa.__doc__ = """Max. number of shared storage pages changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of shared storage pages changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

r743chlr : Final[Field] = Field(
    name='r743chlr',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. size of shared library region changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. size of shared library region changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
r743chlr.__doc__ = """Max. size of shared library region changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. size of shared library region changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

r743cqsg : Final[Field] = Field(
    name='r743cqsg',
    origin=None,
    post='core.flags',
    post_param=11,
    virtual=True,
    ref=r743flg,
    record=record,
    record_map=R743DATA,
)
"""Max. number of queued signals per process changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of queued signals per process changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `11`
"""
r743cqsg.__doc__ = """Max. number of queued signals per process changed during reporting interval when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r743flg`(`R743FLG`)
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of queued signals per process changed during reporting interval when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `11`
"""

r743sysc : Final[Field] = Field(
    name='r743sysc',
    origin='R743SYSC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Total number of OMVS system calls invoked during the interval (short floating point)

SMF Info
--------
    Field: `R743SYSC`
    Record: `SMF74S3`
    Map: `R743DATA`

Total number of OMVS system calls invoked during the interval (short floating point)
"""
r743sysc.__doc__ = """Total number of OMVS system calls invoked during the interval (short floating point)

SMF Info
--------
    Field: `R743SYSC`
    Record: `SMF74S3`
    Map: `R743DATA`

Total number of OMVS system calls invoked during the interval (short floating point)
"""

r743scmn : Final[Field] = Field(
    name='r743scmn',
    origin='R743SCMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Min. number of OMVS system calls invoked during one cycle

SMF Info
--------
    Field: `R743SCMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. number of OMVS system calls invoked during one cycle
"""
r743scmn.__doc__ = """Min. number of OMVS system calls invoked during one cycle

SMF Info
--------
    Field: `R743SCMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. number of OMVS system calls invoked during one cycle
"""

r743scmx : Final[Field] = Field(
    name='r743scmx',
    origin='R743SCMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. number of OMVS system calls invoked during one cycle

SMF Info
--------
    Field: `R743SCMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS system calls invoked during one cycle
"""
r743scmx.__doc__ = """Max. number of OMVS system calls invoked during one cycle

SMF Info
--------
    Field: `R743SCMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS system calls invoked during one cycle
"""

r743cpu : Final[Field] = Field(
    name='r743cpu',
    origin='R743CPU',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Total CPU time spent processing syscalls in OMVS during the interval (short floating point)

SMF Info
--------
    Field: `R743CPU`
    Record: `SMF74S3`
    Map: `R743DATA`

Total CPU time spent processing syscalls in OMVS during the interval (short floating point)
"""
r743cpu.__doc__ = """Total CPU time spent processing syscalls in OMVS during the interval (short floating point)

SMF Info
--------
    Field: `R743CPU`
    Record: `SMF74S3`
    Map: `R743DATA`

Total CPU time spent processing syscalls in OMVS during the interval (short floating point)
"""

r743ctmn : Final[Field] = Field(
    name='r743ctmn',
    origin='R743CTMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Min. CPU time spent processing syscalls in OMVS during one cycle

SMF Info
--------
    Field: `R743CTMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. CPU time spent processing syscalls in OMVS during one cycle
"""
r743ctmn.__doc__ = """Min. CPU time spent processing syscalls in OMVS during one cycle

SMF Info
--------
    Field: `R743CTMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. CPU time spent processing syscalls in OMVS during one cycle
"""

r743ctmx : Final[Field] = Field(
    name='r743ctmx',
    origin='R743CTMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. CPU time spent processing syscalls in OMVS during one cycle

SMF Info
--------
    Field: `R743CTMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. CPU time spent processing syscalls in OMVS during one cycle
"""
r743ctmx.__doc__ = """Max. CPU time spent processing syscalls in OMVS during one cycle

SMF Info
--------
    Field: `R743CTMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. CPU time spent processing syscalls in OMVS during one cycle
"""

r743opr : Final[Field] = Field(
    name='r743opr',
    origin='R743OPR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Count of times Fork/Dub failed because max. number of processes was exceeded during one cycle (short floating point)

SMF Info
--------
    Field: `R743OPR`
    Record: `SMF74S3`
    Map: `R743DATA`

Count of times Fork/Dub failed because max. number of processes was exceeded during one cycle (short floating point)
"""
r743opr.__doc__ = """Count of times Fork/Dub failed because max. number of processes was exceeded during one cycle (short floating point)

SMF Info
--------
    Field: `R743OPR`
    Record: `SMF74S3`
    Map: `R743DATA`

Count of times Fork/Dub failed because max. number of processes was exceeded during one cycle (short floating point)
"""

r743opmn : Final[Field] = Field(
    name='r743opmn',
    origin='R743OPMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Min. mumber of times Fork/Dub failed because max. number of processes was exceeded during one cycle

SMF Info
--------
    Field: `R743OPMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. mumber of times Fork/Dub failed because max. number of processes was exceeded during one cycle
"""
r743opmn.__doc__ = """Min. mumber of times Fork/Dub failed because max. number of processes was exceeded during one cycle

SMF Info
--------
    Field: `R743OPMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. mumber of times Fork/Dub failed because max. number of processes was exceeded during one cycle
"""

r743opmx : Final[Field] = Field(
    name='r743opmx',
    origin='R743OPMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. mumber of times Fork/Dub failed because max. number of processes was exceeded during one cycle

SMF Info
--------
    Field: `R743OPMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. mumber of times Fork/Dub failed because max. number of processes was exceeded during one cycle
"""
r743opmx.__doc__ = """Max. mumber of times Fork/Dub failed because max. number of processes was exceeded during one cycle

SMF Info
--------
    Field: `R743OPMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. mumber of times Fork/Dub failed because max. number of processes was exceeded during one cycle
"""

r743ous : Final[Field] = Field(
    name='r743ous',
    origin='R743OUS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Count of times Fork/Dub failed because max. number of users was exceeded during one cycle (short floating point)

SMF Info
--------
    Field: `R743OUS`
    Record: `SMF74S3`
    Map: `R743DATA`

Count of times Fork/Dub failed because max. number of users was exceeded during one cycle (short floating point)
"""
r743ous.__doc__ = """Count of times Fork/Dub failed because max. number of users was exceeded during one cycle (short floating point)

SMF Info
--------
    Field: `R743OUS`
    Record: `SMF74S3`
    Map: `R743DATA`

Count of times Fork/Dub failed because max. number of users was exceeded during one cycle (short floating point)
"""

r743oumn : Final[Field] = Field(
    name='r743oumn',
    origin='R743OUMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Min. mumber of times Fork/Dub failed because max. number of users was exceeded during one cycle

SMF Info
--------
    Field: `R743OUMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. mumber of times Fork/Dub failed because max. number of users was exceeded during one cycle
"""
r743oumn.__doc__ = """Min. mumber of times Fork/Dub failed because max. number of users was exceeded during one cycle

SMF Info
--------
    Field: `R743OUMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. mumber of times Fork/Dub failed because max. number of users was exceeded during one cycle
"""

r743oumx : Final[Field] = Field(
    name='r743oumx',
    origin='R743OUMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. mumber of times Fork/Dub failed because max. number of users was exceeded during one cycle

SMF Info
--------
    Field: `R743OUMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. mumber of times Fork/Dub failed because max. number of users was exceeded during one cycle
"""
r743oumx.__doc__ = """Max. mumber of times Fork/Dub failed because max. number of users was exceeded during one cycle

SMF Info
--------
    Field: `R743OUMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. mumber of times Fork/Dub failed because max. number of users was exceeded during one cycle
"""

r743opru : Final[Field] = Field(
    name='r743opru',
    origin='R743OPRU',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Count of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle (short floating point)

SMF Info
--------
    Field: `R743OPRU`
    Record: `SMF74S3`
    Map: `R743DATA`

Count of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle (short floating point)
"""
r743opru.__doc__ = """Count of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle (short floating point)

SMF Info
--------
    Field: `R743OPRU`
    Record: `SMF74S3`
    Map: `R743DATA`

Count of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle (short floating point)
"""

r743ormn : Final[Field] = Field(
    name='r743ormn',
    origin='R743ORMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Min. number of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle

SMF Info
--------
    Field: `R743ORMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. number of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle
"""
r743ormn.__doc__ = """Min. number of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle

SMF Info
--------
    Field: `R743ORMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. number of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle
"""

r743ormx : Final[Field] = Field(
    name='r743ormx',
    origin='R743ORMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. number of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle

SMF Info
--------
    Field: `R743ORMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle
"""
r743ormx.__doc__ = """Max. number of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle

SMF Info
--------
    Field: `R743ORMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of times Fork/Dub failed because max. number of processes per user was exceeded during one cycle
"""

r743maxp : Final[Field] = Field(
    name='r743maxp',
    origin='R743MAXP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. number of OMVS processes (const.)

SMF Info
--------
    Field: `R743MAXP`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS processes (const.)
"""
r743maxp.__doc__ = """Max. number of OMVS processes (const.)

SMF Info
--------
    Field: `R743MAXP`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS processes (const.)
"""

r743maxu : Final[Field] = Field(
    name='r743maxu',
    origin='R743MAXU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. number of OMVS users (const.)

SMF Info
--------
    Field: `R743MAXU`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS users (const.)
"""
r743maxu.__doc__ = """Max. number of OMVS users (const.)

SMF Info
--------
    Field: `R743MAXU`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS users (const.)
"""

r743mxpu : Final[Field] = Field(
    name='r743mxpu',
    origin='R743MXPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. number of OMVS processes per user (const.)

SMF Info
--------
    Field: `R743MXPU`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS processes per user (const.)
"""
r743mxpu.__doc__ = """Max. number of OMVS processes per user (const.)

SMF Info
--------
    Field: `R743MXPU`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS processes per user (const.)
"""

r743curp : Final[Field] = Field(
    name='r743curp',
    origin='R743CURP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of OMVS processes during the interval (short floating point)

SMF Info
--------
    Field: `R743CURP`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of OMVS processes during the interval (short floating point)
"""
r743curp.__doc__ = """Accumulated number of OMVS processes during the interval (short floating point)

SMF Info
--------
    Field: `R743CURP`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of OMVS processes during the interval (short floating point)
"""

r743cpmn : Final[Field] = Field(
    name='r743cpmn',
    origin='R743CPMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Min. number of OMVS processes during one cycle

SMF Info
--------
    Field: `R743CPMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. number of OMVS processes during one cycle
"""
r743cpmn.__doc__ = """Min. number of OMVS processes during one cycle

SMF Info
--------
    Field: `R743CPMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. number of OMVS processes during one cycle
"""

r743cpmx : Final[Field] = Field(
    name='r743cpmx',
    origin='R743CPMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. number of OMVS processes during one cycle

SMF Info
--------
    Field: `R743CPMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS processes during one cycle
"""
r743cpmx.__doc__ = """Max. number of OMVS processes during one cycle

SMF Info
--------
    Field: `R743CPMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS processes during one cycle
"""

r743curu : Final[Field] = Field(
    name='r743curu',
    origin='R743CURU',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of OMVS users during the interval (short floating point)

SMF Info
--------
    Field: `R743CURU`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of OMVS users during the interval (short floating point)
"""
r743curu.__doc__ = """Accumulated number of OMVS users during the interval (short floating point)

SMF Info
--------
    Field: `R743CURU`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of OMVS users during the interval (short floating point)
"""

r743cumn : Final[Field] = Field(
    name='r743cumn',
    origin='R743CUMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Min. number of OMVS users during one cycle

SMF Info
--------
    Field: `R743CUMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. number of OMVS users during one cycle
"""
r743cumn.__doc__ = """Min. number of OMVS users during one cycle

SMF Info
--------
    Field: `R743CUMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Min. number of OMVS users during one cycle
"""

r743cumx : Final[Field] = Field(
    name='r743cumx',
    origin='R743CUMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Max. number of OMVS users during one cycle

SMF Info
--------
    Field: `R743CUMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS users during one cycle
"""
r743cumx.__doc__ = """Max. number of OMVS users during one cycle

SMF Info
--------
    Field: `R743CUMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Max. number of OMVS users during one cycle
"""

r743mmsg : Final[Field] = Field(
    name='r743mmsg',
    origin='R743MMSG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of message queue IDs (const.)

SMF Info
--------
    Field: `R743MMSG`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of message queue IDs (const.)
"""
r743mmsg.__doc__ = """Maximum number of message queue IDs (const.)

SMF Info
--------
    Field: `R743MMSG`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of message queue IDs (const.)
"""

r743msem : Final[Field] = Field(
    name='r743msem',
    origin='R743MSEM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of semaphore IDs (const.)

SMF Info
--------
    Field: `R743MSEM`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of semaphore IDs (const.)
"""
r743msem.__doc__ = """Maximum number of semaphore IDs (const.)

SMF Info
--------
    Field: `R743MSEM`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of semaphore IDs (const.)
"""

r743mshm : Final[Field] = Field(
    name='r743mshm',
    origin='R743MSHM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of shared memory IDs (const.)

SMF Info
--------
    Field: `R743MSHM`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared memory IDs (const.)
"""
r743mshm.__doc__ = """Maximum number of shared memory IDs (const.)

SMF Info
--------
    Field: `R743MSHM`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared memory IDs (const.)
"""

r743mspg : Final[Field] = Field(
    name='r743mspg',
    origin='R743MSPG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of shared memory pages (const.)

SMF Info
--------
    Field: `R743MSPG`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared memory pages (const.)
"""
r743mspg.__doc__ = """Maximum number of shared memory pages (const.)

SMF Info
--------
    Field: `R743MSPG`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared memory pages (const.)
"""

r743cmsg : Final[Field] = Field(
    name='r743cmsg',
    origin='R743CMSG',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of message queue IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743CMSG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of message queue IDs during one interval (short floating point)
"""
r743cmsg.__doc__ = """Accumulated number of message queue IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743CMSG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of message queue IDs during one interval (short floating point)
"""

r743cmmn : Final[Field] = Field(
    name='r743cmmn',
    origin='R743CMMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of message queue IDs per cycle

SMF Info
--------
    Field: `R743CMMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of message queue IDs per cycle
"""
r743cmmn.__doc__ = """Minimum number of message queue IDs per cycle

SMF Info
--------
    Field: `R743CMMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of message queue IDs per cycle
"""

r743cmmx : Final[Field] = Field(
    name='r743cmmx',
    origin='R743CMMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of message queue IDs per cycle

SMF Info
--------
    Field: `R743CMMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of message queue IDs per cycle
"""
r743cmmx.__doc__ = """Maximum number of message queue IDs per cycle

SMF Info
--------
    Field: `R743CMMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of message queue IDs per cycle
"""

r743csem : Final[Field] = Field(
    name='r743csem',
    origin='R743CSEM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of semaphore IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743CSEM`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of semaphore IDs during one interval (short floating point)
"""
r743csem.__doc__ = """Accumulated number of semaphore IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743CSEM`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of semaphore IDs during one interval (short floating point)
"""

r743csmn : Final[Field] = Field(
    name='r743csmn',
    origin='R743CSMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of semaphore IDs per cycle

SMF Info
--------
    Field: `R743CSMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of semaphore IDs per cycle
"""
r743csmn.__doc__ = """Minimum number of semaphore IDs per cycle

SMF Info
--------
    Field: `R743CSMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of semaphore IDs per cycle
"""

r743csmx : Final[Field] = Field(
    name='r743csmx',
    origin='R743CSMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of semaphore IDs per cycle

SMF Info
--------
    Field: `R743CSMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of semaphore IDs per cycle
"""
r743csmx.__doc__ = """Maximum number of semaphore IDs per cycle

SMF Info
--------
    Field: `R743CSMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of semaphore IDs per cycle
"""

r743cshm : Final[Field] = Field(
    name='r743cshm',
    origin='R743CSHM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of shared memory IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743CSHM`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of shared memory IDs during one interval (short floating point)
"""
r743cshm.__doc__ = """Accumulated number of shared memory IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743CSHM`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of shared memory IDs during one interval (short floating point)
"""

r743chmn : Final[Field] = Field(
    name='r743chmn',
    origin='R743CHMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of shared memory IDs per cycle

SMF Info
--------
    Field: `R743CHMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of shared memory IDs per cycle
"""
r743chmn.__doc__ = """Minimum number of shared memory IDs per cycle

SMF Info
--------
    Field: `R743CHMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of shared memory IDs per cycle
"""

r743chmx : Final[Field] = Field(
    name='r743chmx',
    origin='R743CHMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of shared memory IDs per cycle

SMF Info
--------
    Field: `R743CHMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared memory IDs per cycle
"""
r743chmx.__doc__ = """Maximum number of shared memory IDs per cycle

SMF Info
--------
    Field: `R743CHMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared memory IDs per cycle
"""

r743cspg : Final[Field] = Field(
    name='r743cspg',
    origin='R743CSPG',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of shared memory pages during one interval (short floating point)

SMF Info
--------
    Field: `R743CSPG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of shared memory pages during one interval (short floating point)
"""
r743cspg.__doc__ = """Accumulated number of shared memory pages during one interval (short floating point)

SMF Info
--------
    Field: `R743CSPG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of shared memory pages during one interval (short floating point)
"""

r743cgmn : Final[Field] = Field(
    name='r743cgmn',
    origin='R743CGMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of shared memory pages per cycle

SMF Info
--------
    Field: `R743CGMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of shared memory pages per cycle
"""
r743cgmn.__doc__ = """Minimum number of shared memory pages per cycle

SMF Info
--------
    Field: `R743CGMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of shared memory pages per cycle
"""

r743cgmx : Final[Field] = Field(
    name='r743cgmx',
    origin='R743CGMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of shared memory pages per cycle

SMF Info
--------
    Field: `R743CGMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared memory pages per cycle
"""
r743cgmx.__doc__ = """Maximum number of shared memory pages per cycle

SMF Info
--------
    Field: `R743CGMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared memory pages per cycle
"""

r743omsg : Final[Field] = Field(
    name='r743omsg',
    origin='R743OMSG',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of attempts to exceed maximum number of message queue IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743OMSG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of message queue IDs during one interval (short floating point)
"""
r743omsg.__doc__ = """Accumulated number of attempts to exceed maximum number of message queue IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743OMSG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of message queue IDs during one interval (short floating point)
"""

r743ommn : Final[Field] = Field(
    name='r743ommn',
    origin='R743OMMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of attempts to exceed maximum number of message queue IDs per cycle

SMF Info
--------
    Field: `R743OMMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of message queue IDs per cycle
"""
r743ommn.__doc__ = """Minimum number of attempts to exceed maximum number of message queue IDs per cycle

SMF Info
--------
    Field: `R743OMMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of message queue IDs per cycle
"""

r743ommx : Final[Field] = Field(
    name='r743ommx',
    origin='R743OMMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of attempts to exceed maximum number of message queue IDs per cycle

SMF Info
--------
    Field: `R743OMMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of message queue IDs per cycle
"""
r743ommx.__doc__ = """Maximum number of attempts to exceed maximum number of message queue IDs per cycle

SMF Info
--------
    Field: `R743OMMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of message queue IDs per cycle
"""

r743osem : Final[Field] = Field(
    name='r743osem',
    origin='R743OSEM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of attempts to exceed maximum number of semaphore IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743OSEM`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of semaphore IDs during one interval (short floating point)
"""
r743osem.__doc__ = """Accumulated number of attempts to exceed maximum number of semaphore IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743OSEM`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of semaphore IDs during one interval (short floating point)
"""

r743osmn : Final[Field] = Field(
    name='r743osmn',
    origin='R743OSMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of attempts to exceed maximum number of semaphore IDs per cycle

SMF Info
--------
    Field: `R743OSMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of semaphore IDs per cycle
"""
r743osmn.__doc__ = """Minimum number of attempts to exceed maximum number of semaphore IDs per cycle

SMF Info
--------
    Field: `R743OSMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of semaphore IDs per cycle
"""

r743osmx : Final[Field] = Field(
    name='r743osmx',
    origin='R743OSMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of attempts to exceed maximum number of semaphore IDs per cycle

SMF Info
--------
    Field: `R743OSMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of semaphore IDs per cycle
"""
r743osmx.__doc__ = """Maximum number of attempts to exceed maximum number of semaphore IDs per cycle

SMF Info
--------
    Field: `R743OSMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of semaphore IDs per cycle
"""

r743oshm : Final[Field] = Field(
    name='r743oshm',
    origin='R743OSHM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of attempts to exceed maximum number of shared memory IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743OSHM`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of shared memory IDs during one interval (short floating point)
"""
r743oshm.__doc__ = """Accumulated number of attempts to exceed maximum number of shared memory IDs during one interval (short floating point)

SMF Info
--------
    Field: `R743OSHM`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of shared memory IDs during one interval (short floating point)
"""

r743ohmn : Final[Field] = Field(
    name='r743ohmn',
    origin='R743OHMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of attempts to exceed maximum number of shared memory IDs per cycle

SMF Info
--------
    Field: `R743OHMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of shared memory IDs per cycle
"""
r743ohmn.__doc__ = """Minimum number of attempts to exceed maximum number of shared memory IDs per cycle

SMF Info
--------
    Field: `R743OHMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of shared memory IDs per cycle
"""

r743ohmx : Final[Field] = Field(
    name='r743ohmx',
    origin='R743OHMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of attempts to exceed maximum number of shared memory IDs per cycle

SMF Info
--------
    Field: `R743OHMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of shared memory IDs per cycle
"""
r743ohmx.__doc__ = """Maximum number of attempts to exceed maximum number of shared memory IDs per cycle

SMF Info
--------
    Field: `R743OHMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of shared memory IDs per cycle
"""

r743ospg : Final[Field] = Field(
    name='r743ospg',
    origin='R743OSPG',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of attempts to exceed maximum number of shared memory pages during one interval (short floating point)

SMF Info
--------
    Field: `R743OSPG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of shared memory pages during one interval (short floating point)
"""
r743ospg.__doc__ = """Accumulated number of attempts to exceed maximum number of shared memory pages during one interval (short floating point)

SMF Info
--------
    Field: `R743OSPG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of shared memory pages during one interval (short floating point)
"""

r743ogmn : Final[Field] = Field(
    name='r743ogmn',
    origin='R743OGMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of attempts to exceed maximum number of shared memory pages per cycle

SMF Info
--------
    Field: `R743OGMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of shared memory pages per cycle
"""
r743ogmn.__doc__ = """Minimum number of attempts to exceed maximum number of shared memory pages per cycle

SMF Info
--------
    Field: `R743OGMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of shared memory pages per cycle
"""

r743ogmx : Final[Field] = Field(
    name='r743ogmx',
    origin='R743OGMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of attempts to exceed maximum number of shared memory pages per cycle

SMF Info
--------
    Field: `R743OGMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of shared memory pages per cycle
"""
r743ogmx.__doc__ = """Maximum number of attempts to exceed maximum number of shared memory pages per cycle

SMF Info
--------
    Field: `R743OGMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of shared memory pages per cycle
"""

r743mmap : Final[Field] = Field(
    name='r743mmap',
    origin='R743MMAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of memory map storage pages (const.)

SMF Info
--------
    Field: `R743MMAP`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of memory map storage pages (const.)
"""
r743mmap.__doc__ = """Maximum number of memory map storage pages (const.)

SMF Info
--------
    Field: `R743MMAP`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of memory map storage pages (const.)
"""

r743cmap : Final[Field] = Field(
    name='r743cmap',
    origin='R743CMAP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of memory map storage pages during one interval (short floating point)

SMF Info
--------
    Field: `R743CMAP`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of memory map storage pages during one interval (short floating point)
"""
r743cmap.__doc__ = """Accumulated number of memory map storage pages during one interval (short floating point)

SMF Info
--------
    Field: `R743CMAP`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of memory map storage pages during one interval (short floating point)
"""

r743camn : Final[Field] = Field(
    name='r743camn',
    origin='R743CAMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of memory map storage pages per cycle

SMF Info
--------
    Field: `R743CAMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of memory map storage pages per cycle
"""
r743camn.__doc__ = """Minimum number of memory map storage pages per cycle

SMF Info
--------
    Field: `R743CAMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of memory map storage pages per cycle
"""

r743camx : Final[Field] = Field(
    name='r743camx',
    origin='R743CAMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of memory map storage pages per cycle

SMF Info
--------
    Field: `R743CAMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of memory map storage pages per cycle
"""
r743camx.__doc__ = """Maximum number of memory map storage pages per cycle

SMF Info
--------
    Field: `R743CAMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of memory map storage pages per cycle
"""

r743omap : Final[Field] = Field(
    name='r743omap',
    origin='R743OMAP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of attempts to exceed maximum number of memory map storage pages during one interval (short floating point)

SMF Info
--------
    Field: `R743OMAP`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of memory map storage pages during one interval (short floating point)
"""
r743omap.__doc__ = """Accumulated number of attempts to exceed maximum number of memory map storage pages during one interval (short floating point)

SMF Info
--------
    Field: `R743OMAP`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of memory map storage pages during one interval (short floating point)
"""

r743oamn : Final[Field] = Field(
    name='r743oamn',
    origin='R743OAMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of attempts to exceed maximum number of memory map storage pages per cycle

SMF Info
--------
    Field: `R743OAMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of memory map storage pages per cycle
"""
r743oamn.__doc__ = """Minimum number of attempts to exceed maximum number of memory map storage pages per cycle

SMF Info
--------
    Field: `R743OAMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of memory map storage pages per cycle
"""

r743oamx : Final[Field] = Field(
    name='r743oamx',
    origin='R743OAMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of attempts to exceed maximum number of memory map storage pages per cycle

SMF Info
--------
    Field: `R743OAMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of memory map storage pages per cycle
"""
r743oamx.__doc__ = """Maximum number of attempts to exceed maximum number of memory map storage pages per cycle

SMF Info
--------
    Field: `R743OAMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of memory map storage pages per cycle
"""

r743mpag : Final[Field] = Field(
    name='r743mpag',
    origin='R743MPAG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of shared storage pages (const.)

SMF Info
--------
    Field: `R743MPAG`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared storage pages (const.)
"""
r743mpag.__doc__ = """Maximum number of shared storage pages (const.)

SMF Info
--------
    Field: `R743MPAG`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared storage pages (const.)
"""

r743cpag : Final[Field] = Field(
    name='r743cpag',
    origin='R743CPAG',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of shared storage pages during one interval (short floating point)

SMF Info
--------
    Field: `R743CPAG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of shared storage pages during one interval (short floating point)
"""
r743cpag.__doc__ = """Accumulated number of shared storage pages during one interval (short floating point)

SMF Info
--------
    Field: `R743CPAG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of shared storage pages during one interval (short floating point)
"""

r743cxmn : Final[Field] = Field(
    name='r743cxmn',
    origin='R743CXMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of shared storage pages per cycle

SMF Info
--------
    Field: `R743CXMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of shared storage pages per cycle
"""
r743cxmn.__doc__ = """Minimum number of shared storage pages per cycle

SMF Info
--------
    Field: `R743CXMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of shared storage pages per cycle
"""

r743cxmx : Final[Field] = Field(
    name='r743cxmx',
    origin='R743CXMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of shared storage pages per cycle

SMF Info
--------
    Field: `R743CXMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared storage pages per cycle
"""
r743cxmx.__doc__ = """Maximum number of shared storage pages per cycle

SMF Info
--------
    Field: `R743CXMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared storage pages per cycle
"""

r743opag : Final[Field] = Field(
    name='r743opag',
    origin='R743OPAG',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of attempts to exceed maximum number of shared storage pages during one interval (short floating point)

SMF Info
--------
    Field: `R743OPAG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of shared storage pages during one interval (short floating point)
"""
r743opag.__doc__ = """Accumulated number of attempts to exceed maximum number of shared storage pages during one interval (short floating point)

SMF Info
--------
    Field: `R743OPAG`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum number of shared storage pages during one interval (short floating point)
"""

r743oxmn : Final[Field] = Field(
    name='r743oxmn',
    origin='R743OXMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of attempts to exceed maximum number of shared storage pages per cycle

SMF Info
--------
    Field: `R743OXMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of shared storage pages per cycle
"""
r743oxmn.__doc__ = """Minimum number of attempts to exceed maximum number of shared storage pages per cycle

SMF Info
--------
    Field: `R743OXMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum number of shared storage pages per cycle
"""

r743oxmx : Final[Field] = Field(
    name='r743oxmx',
    origin='R743OXMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of attempts to exceed maximum number of shared storage pages per cycle

SMF Info
--------
    Field: `R743OXMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of shared storage pages per cycle
"""
r743oxmx.__doc__ = """Maximum number of attempts to exceed maximum number of shared storage pages per cycle

SMF Info
--------
    Field: `R743OXMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum number of shared storage pages per cycle
"""

r743mslr : Final[Field] = Field(
    name='r743mslr',
    origin='R743MSLR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum amount of storage available for shared library region (const. in MB)

SMF Info
--------
    Field: `R743MSLR`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum amount of storage available for shared library region (const. in MB)
"""
r743mslr.__doc__ = """Maximum amount of storage available for shared library region (const. in MB)

SMF Info
--------
    Field: `R743MSLR`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum amount of storage available for shared library region (const. in MB)
"""

r743cslr : Final[Field] = Field(
    name='r743cslr',
    origin='R743CSLR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated amount of shared library storage allocated in one interval in MB (short floating point)

SMF Info
--------
    Field: `R743CSLR`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated amount of shared library storage allocated in one interval in MB (short floating point)
"""
r743cslr.__doc__ = """Accumulated amount of shared library storage allocated in one interval in MB (short floating point)

SMF Info
--------
    Field: `R743CSLR`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated amount of shared library storage allocated in one interval in MB (short floating point)
"""

r743clmn : Final[Field] = Field(
    name='r743clmn',
    origin='R743CLMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum amount of shared library storage allocated per cycle

SMF Info
--------
    Field: `R743CLMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum amount of shared library storage allocated per cycle
"""
r743clmn.__doc__ = """Minimum amount of shared library storage allocated per cycle

SMF Info
--------
    Field: `R743CLMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum amount of shared library storage allocated per cycle
"""

r743clmx : Final[Field] = Field(
    name='r743clmx',
    origin='R743CLMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of shared library storage allocated per cycle

SMF Info
--------
    Field: `R743CLMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared library storage allocated per cycle
"""
r743clmx.__doc__ = """Maximum number of shared library storage allocated per cycle

SMF Info
--------
    Field: `R743CLMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of shared library storage allocated per cycle
"""

r743oslr : Final[Field] = Field(
    name='r743oslr',
    origin='R743OSLR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of attempts to exceed maximum amount of shared library region size during one interval (short floating point)

SMF Info
--------
    Field: `R743OSLR`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum amount of shared library region size during one interval (short floating point)
"""
r743oslr.__doc__ = """Accumulated number of attempts to exceed maximum amount of shared library region size during one interval (short floating point)

SMF Info
--------
    Field: `R743OSLR`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum amount of shared library region size during one interval (short floating point)
"""

r743olmn : Final[Field] = Field(
    name='r743olmn',
    origin='R743OLMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of attempts to exceed maximum amount of shared library region per cycle

SMF Info
--------
    Field: `R743OLMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum amount of shared library region per cycle
"""
r743olmn.__doc__ = """Minimum number of attempts to exceed maximum amount of shared library region per cycle

SMF Info
--------
    Field: `R743OLMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum amount of shared library region per cycle
"""

r743olmx : Final[Field] = Field(
    name='r743olmx',
    origin='R743OLMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of attempts to exceed maximum amount of shared library region per cycle

SMF Info
--------
    Field: `R743OLMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum amount of shared library region per cycle
"""
r743olmx.__doc__ = """Maximum number of attempts to exceed maximum amount of shared library region per cycle

SMF Info
--------
    Field: `R743OLMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum amount of shared library region per cycle
"""

r743mqds : Final[Field] = Field(
    name='r743mqds',
    origin='R743MQDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum amount of queued signals allowed per process (const.)

SMF Info
--------
    Field: `R743MQDS`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum amount of queued signals allowed per process (const.)
"""
r743mqds.__doc__ = """Maximum amount of queued signals allowed per process (const.)

SMF Info
--------
    Field: `R743MQDS`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum amount of queued signals allowed per process (const.)
"""

r743oqds : Final[Field] = Field(
    name='r743oqds',
    origin='R743OQDS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R743DATA,
)
"""Accumulated number of attempts to exceed maximum amount of queued signals per interval (short floating point)

SMF Info
--------
    Field: `R743OQDS`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum amount of queued signals per interval (short floating point)
"""
r743oqds.__doc__ = """Accumulated number of attempts to exceed maximum amount of queued signals per interval (short floating point)

SMF Info
--------
    Field: `R743OQDS`
    Record: `SMF74S3`
    Map: `R743DATA`

Accumulated number of attempts to exceed maximum amount of queued signals per interval (short floating point)
"""

r743oqmn : Final[Field] = Field(
    name='r743oqmn',
    origin='R743OQMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Minimum number of attempts to exceed maximum amount of queued signals per cycle

SMF Info
--------
    Field: `R743OQMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum amount of queued signals per cycle
"""
r743oqmn.__doc__ = """Minimum number of attempts to exceed maximum amount of queued signals per cycle

SMF Info
--------
    Field: `R743OQMN`
    Record: `SMF74S3`
    Map: `R743DATA`

Minimum number of attempts to exceed maximum amount of queued signals per cycle
"""

r743oqmx : Final[Field] = Field(
    name='r743oqmx',
    origin='R743OQMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R743DATA,
)
"""Maximum number of attempts to exceed maximum amount of queued signals per cycle

SMF Info
--------
    Field: `R743OQMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum amount of queued signals per cycle
"""
r743oqmx.__doc__ = """Maximum number of attempts to exceed maximum amount of queued signals per cycle

SMF Info
--------
    Field: `R743OQMX`
    Record: `SMF74S3`
    Map: `R743DATA`

Maximum number of attempts to exceed maximum amount of queued signals per cycle
"""
