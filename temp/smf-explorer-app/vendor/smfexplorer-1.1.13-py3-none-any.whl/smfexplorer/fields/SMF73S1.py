# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 73 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=73,
                                smf_subtype=1,
                                spec='SMF 73 Subtype 1',
                                post=None)
"""SMF 73 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF73PRO: Final[RecordMap] = RecordMap(
    origin='SMF73PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
SMF73CTL: Final[RecordMap] = RecordMap(
    origin='SMF73CTL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Channel Path Control Section',
    post=None,
    record_mapping=False)
"""Channel Path Control Section"""
SMF73CHA: Final[RecordMap] = RecordMap(
    origin='SMF73CHA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Channel Path Data Section',
    post=None,
    record_mapping=False)
"""Channel Path Data Section"""
SMF73ECD: Final[RecordMap] = RecordMap(
    origin='SMF73ECD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Extended Channel Data Section',
    post=None,
    record_mapping=False)
"""Extended Channel Data Section"""
SMF73CM1: Final[RecordMap] = RecordMap(
    origin='SMF73CM1',
    record=record,
    parent=SMF73CHA,
    is_multiple=False,
    is_compound=False,
    spec='Channel data Measurement group 1',
    post=None,
    record_mapping=False)
"""Channel data Measurement group 1"""
SMF73CM2: Final[RecordMap] = RecordMap(
    origin='SMF73CM2',
    record=record,
    parent=SMF73CHA,
    is_multiple=False,
    is_compound=False,
    spec='Channel data data Measurement group 2',
    post=None,
    record_mapping=False)
"""Channel data data Measurement group 2"""
SMF73CM3: Final[RecordMap] = RecordMap(
    origin='SMF73CM3',
    record=record,
    parent=SMF73CHA,
    is_multiple=False,
    is_compound=False,
    spec='Channel data data Measurement group 3',
    post=None,
    record_mapping=False)
"""Channel data data Measurement group 3"""
SMF73EM2: Final[RecordMap] = RecordMap(
    origin='SMF73EM2',
    record=record,
    parent=SMF73ECD,
    is_multiple=False,
    is_compound=False,
    spec='Extended channel data for CMG=2',
    post=None,
    record_mapping=False)
"""Extended channel data for CMG=2"""

date : Final[Field] = Field(
    name='date',
    origin='SMF73DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF73DTE`
    Record: `SMF73S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF73DTE`
    Record: `SMF73S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF73TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF73TME`
    Record: `SMF73S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF73TME`
    Record: `SMF73S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF73DTE`), `time`(`SMF73TME`)
    Record: `SMF73S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF73DTE`), `time`(`SMF73TME`)
    Record: `SMF73S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF73LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF73LEN`
    Record: `SMF73S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF73LEN`
    Record: `SMF73S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF73SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF73SEG`
    Record: `SMF73S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF73SEG`
    Record: `SMF73S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF73FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF73FLG`
    Record: `SMF73S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF73FLG`
    Record: `SMF73S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF73FLG`)
    Record: `SMF73S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF73RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF73RTY`
    Record: `SMF73S1`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF73RTY`
    Record: `SMF73S1`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF73TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF73TME`
    Record: `SMF73S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF73TME`
    Record: `SMF73S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF73DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF73DTE`
    Record: `SMF73S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF73DTE`
    Record: `SMF73S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF73SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF73SID`
    Record: `SMF73S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF73SID`
    Record: `SMF73S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF73SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF73SSI`
    Record: `SMF73S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF73SSI`
    Record: `SMF73S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF73STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF73STY`
    Record: `SMF73S1`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF73STY`
    Record: `SMF73S1`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF73TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF73TRN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF73TRN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF73PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF73PRS`
    Record: `SMF73S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF73PRS`
    Record: `SMF73S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF73PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF73PRL`
    Record: `SMF73S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF73PRL`
    Record: `SMF73S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF73PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF73PRN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF73PRN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

his : Final[Field] = Field(
    name='his',
    origin='SMF73HIS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO CHANNEL PATH CONTROL SECTION

SMF Info
--------
    Field: `SMF73HIS`
    Record: `SMF73S1`
    Map: Not part of a map

OFFSET TO CHANNEL PATH CONTROL SECTION
"""
his.__doc__ = """OFFSET TO CHANNEL PATH CONTROL SECTION

SMF Info
--------
    Field: `SMF73HIS`
    Record: `SMF73S1`
    Map: Not part of a map

OFFSET TO CHANNEL PATH CONTROL SECTION
"""

hil : Final[Field] = Field(
    name='hil',
    origin='SMF73HIL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF CHANNEL PATH CONTROL SECTION

SMF Info
--------
    Field: `SMF73HIL`
    Record: `SMF73S1`
    Map: Not part of a map

LENGTH OF CHANNEL PATH CONTROL SECTION
"""
hil.__doc__ = """LENGTH OF CHANNEL PATH CONTROL SECTION

SMF Info
--------
    Field: `SMF73HIL`
    Record: `SMF73S1`
    Map: Not part of a map

LENGTH OF CHANNEL PATH CONTROL SECTION
"""

hin : Final[Field] = Field(
    name='hin',
    origin='SMF73HIN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF CHANNEL PATH CONTROL SECTIONS

SMF Info
--------
    Field: `SMF73HIN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF CHANNEL PATH CONTROL SECTIONS
"""
hin.__doc__ = """NUMBER OF CHANNEL PATH CONTROL SECTIONS

SMF Info
--------
    Field: `SMF73HIN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF CHANNEL PATH CONTROL SECTIONS
"""

hps : Final[Field] = Field(
    name='hps',
    origin='SMF73HPS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO CHANNEL PATH DATA SECTION

SMF Info
--------
    Field: `SMF73HPS`
    Record: `SMF73S1`
    Map: Not part of a map

OFFSET TO CHANNEL PATH DATA SECTION
"""
hps.__doc__ = """OFFSET TO CHANNEL PATH DATA SECTION

SMF Info
--------
    Field: `SMF73HPS`
    Record: `SMF73S1`
    Map: Not part of a map

OFFSET TO CHANNEL PATH DATA SECTION
"""

hpl : Final[Field] = Field(
    name='hpl',
    origin='SMF73HPL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF CHANNEL PATH DATA SECTION

SMF Info
--------
    Field: `SMF73HPL`
    Record: `SMF73S1`
    Map: Not part of a map

LENGTH OF CHANNEL PATH DATA SECTION
"""
hpl.__doc__ = """LENGTH OF CHANNEL PATH DATA SECTION

SMF Info
--------
    Field: `SMF73HPL`
    Record: `SMF73S1`
    Map: Not part of a map

LENGTH OF CHANNEL PATH DATA SECTION
"""

hpn : Final[Field] = Field(
    name='hpn',
    origin='SMF73HPN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF CHANNEL PATH DATA SECTIONS

SMF Info
--------
    Field: `SMF73HPN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF CHANNEL PATH DATA SECTIONS
"""
hpn.__doc__ = """NUMBER OF CHANNEL PATH DATA SECTIONS

SMF Info
--------
    Field: `SMF73HPN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF CHANNEL PATH DATA SECTIONS
"""

hes : Final[Field] = Field(
    name='hes',
    origin='SMF73HES',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO EXTENDED CHANNEL PATH DATA SECTION

SMF Info
--------
    Field: `SMF73HES`
    Record: `SMF73S1`
    Map: Not part of a map

OFFSET TO EXTENDED CHANNEL PATH DATA SECTION
"""
hes.__doc__ = """OFFSET TO EXTENDED CHANNEL PATH DATA SECTION

SMF Info
--------
    Field: `SMF73HES`
    Record: `SMF73S1`
    Map: Not part of a map

OFFSET TO EXTENDED CHANNEL PATH DATA SECTION
"""

hel : Final[Field] = Field(
    name='hel',
    origin='SMF73HEL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF EXTENDED CHANNEL PATH DATA SECTION

SMF Info
--------
    Field: `SMF73HEL`
    Record: `SMF73S1`
    Map: Not part of a map

LENGTH OF EXTENDED CHANNEL PATH DATA SECTION
"""
hel.__doc__ = """LENGTH OF EXTENDED CHANNEL PATH DATA SECTION

SMF Info
--------
    Field: `SMF73HEL`
    Record: `SMF73S1`
    Map: Not part of a map

LENGTH OF EXTENDED CHANNEL PATH DATA SECTION
"""

hen : Final[Field] = Field(
    name='hen',
    origin='SMF73HEN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF EXTENDED CHANNEL PATH DATA SECTIONS

SMF Info
--------
    Field: `SMF73HEN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF EXTENDED CHANNEL PATH DATA SECTIONS
"""
hen.__doc__ = """NUMBER OF EXTENDED CHANNEL PATH DATA SECTIONS

SMF Info
--------
    Field: `SMF73HEN`
    Record: `SMF73S1`
    Map: Not part of a map

NUMBER OF EXTENDED CHANNEL PATH DATA SECTIONS
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF73MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF73MFV`
    Record: `SMF73S1`
    Map: `SMF73PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF73MFV`
    Record: `SMF73S1`
    Map: `SMF73PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF73PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF73PRD`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF73PRD`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF73IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF73PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF73IST`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF73IST`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF73DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF73PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF73DAT`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF73DAT`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF73INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF73PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF73INT`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF73INT`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF73SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF73SAM`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF73SAM`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF73FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF73FLA`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF73FLA`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF73PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF73FLA`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF73CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF73PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF73CYC`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF73CYC`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF73MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF73MVS`
    Record: `SMF73S1`
    Map: `SMF73PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF73MVS`
    Record: `SMF73S1`
    Map: `SMF73PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF73IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF73IML`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF73IML`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF73PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF73PRF`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF73PRF`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF73PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF73PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF73PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF73PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF73PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF73PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF73PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF73PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF73PRF`)
    Record: `SMF73S1`
    Map: `SMF73PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF73PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF73PTN`
    Record: `SMF73S1`
    Map: `SMF73PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF73PTN`
    Record: `SMF73S1`
    Map: `SMF73PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF73SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF73SRL`
    Record: `SMF73S1`
    Map: `SMF73PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF73SRL`
    Record: `SMF73S1`
    Map: `SMF73PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF73IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF73PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF73IET`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF73IET`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF73LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF73LGO`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF73LGO`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF73RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF73RAO`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF73RAO`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF73RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF73RAL`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF73RAL`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF73RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF73RAN`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF73RAN`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF73OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF73OIL`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF73OIL`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF73SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF73SYN`
    Record: `SMF73S1`
    Map: `SMF73PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF73SYN`
    Record: `SMF73S1`
    Map: `SMF73PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF73GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF73PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF73GIE`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF73GIE`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF73XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF73XNM`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF73XNM`
    Record: `SMF73S1`
    Map: `SMF73PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF73SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF73SNM`
    Record: `SMF73S1`
    Map: `SMF73PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF73SNM`
    Record: `SMF73S1`
    Map: `SMF73PRO`

System name for current system as defined in CVTSNAME
"""

smp : Final[Field] = Field(
    name='smp',
    origin='SMF73SMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CTL,
)
"""NUMBER OF SAMPLES, WEIGHTED BY SRM, only valid if SMF73MCS = OFF

SMF Info
--------
    Field: `SMF73SMP`
    Record: `SMF73S1`
    Map: `SMF73CTL`

NUMBER OF SAMPLES, WEIGHTED BY SRM, only valid if SMF73MCS = OFF
"""
smp.__doc__ = """NUMBER OF SAMPLES, WEIGHTED BY SRM, only valid if SMF73MCS = OFF

SMF Info
--------
    Field: `SMF73SMP`
    Record: `SMF73S1`
    Map: `SMF73CTL`

NUMBER OF SAMPLES, WEIGHTED BY SRM, only valid if SMF73MCS = OFF
"""

cfl : Final[Field] = Field(
    name='cfl',
    origin='SMF73CFL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CTL,
)
"""Configuration change flags

SMF Info
--------
    Field: `SMF73CFL`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Configuration change flags
"""
cfl.__doc__ = """Configuration change flags

SMF Info
--------
    Field: `SMF73CFL`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Configuration change flags
"""

config_changed : Final[Field] = Field(
    name='config_changed',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF73CTL,
)
"""Configuration changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

Configuration changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
config_changed.__doc__ = """Configuration changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

Configuration changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

config_change_since_ipl : Final[Field] = Field(
    name='config_change_since_ipl',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF73CTL,
)
"""Configuration changed since last IPL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

Configuration changed since last IPL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
config_change_since_ipl.__doc__ = """Configuration changed since last IPL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

Configuration changed since last IPL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

ipl_iodf : Final[Field] = Field(
    name='ipl_iodf',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF73CTL,
)
"""System IPLed via IODF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

System IPLed via IODF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
ipl_iodf.__doc__ = """System IPLed via IODF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

System IPLed via IODF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

io_token_valid : Final[Field] = Field(
    name='io_token_valid',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF73CTL,
)
"""I/O Token is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

I/O Token is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
io_token_valid.__doc__ = """I/O Token is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

I/O Token is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

invalid_ds : Final[Field] = Field(
    name='invalid_ds',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF73CTL,
)
"""Record may include invalid data sections(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

Record may include invalid data sections

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
invalid_ds.__doc__ = """Record may include invalid data sections(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

Record may include invalid data sections

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

cpmf : Final[Field] = Field(
    name='cpmf',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF73CTL,
)
"""CPMF available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

CPMF available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
cpmf.__doc__ = """CPMF available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

CPMF available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

cpmf_change : Final[Field] = Field(
    name='cpmf_change',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF73CTL,
)
"""CPMF mode change used for duration report(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

CPMF mode change used for duration report

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
cpmf_change.__doc__ = """CPMF mode change used for duration report(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF73CFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

CPMF mode change used for duration report

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

sfl : Final[Field] = Field(
    name='sfl',
    origin='SMF73SFL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CTL,
)
"""Status flags

SMF Info
--------
    Field: `SMF73SFL`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Status flags
"""
sfl.__doc__ = """Status flags

SMF Info
--------
    Field: `SMF73SFL`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Status flags
"""

dcm_supported : Final[Field] = Field(
    name='dcm_supported',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=sfl,
    record=record,
    record_map=SMF73CTL,
)
"""DCM supported by the hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sfl`(`SMF73SFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

DCM supported by the hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
dcm_supported.__doc__ = """DCM supported by the hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sfl`(`SMF73SFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

DCM supported by the hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

dcm_ch : Final[Field] = Field(
    name='dcm_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=sfl,
    record=record,
    record_map=SMF73CTL,
)
"""Configuration contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sfl`(`SMF73SFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

Configuration contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
dcm_ch.__doc__ = """Configuration contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sfl`(`SMF73SFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

Configuration contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

mcs : Final[Field] = Field(
    name='mcs',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=sfl,
    record=record,
    record_map=SMF73CTL,
)
"""1 = Hardware allows multiple channel subsystems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sfl`(`SMF73SFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

1 = Hardware allows multiple channel subsystems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
mcs.__doc__ = """1 = Hardware allows multiple channel subsystems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sfl`(`SMF73SFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

1 = Hardware allows multiple channel subsystems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ench_ch_measurement : Final[Field] = Field(
    name='ench_ch_measurement',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=sfl,
    record=record,
    record_map=SMF73CTL,
)
"""1 = Enhanced channel measurement facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sfl`(`SMF73SFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

1 = Enhanced channel measurement facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ench_ch_measurement.__doc__ = """1 = Enhanced channel measurement facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sfl`(`SMF73SFL`)
    Record: `SMF73S1`
    Map: `SMF73CTL`

1 = Enhanced channel measurement facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

iodf_name : Final[Field] = Field(
    name='iodf_name',
    origin='SMF73TNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CTL,
)
"""IODF name

SMF Info
--------
    Field: `SMF73TNM`
    Record: `SMF73S1`
    Map: `SMF73CTL`

IODF name
"""
iodf_name.__doc__ = """IODF name

SMF Info
--------
    Field: `SMF73TNM`
    Record: `SMF73S1`
    Map: `SMF73CTL`

IODF name
"""

iodf_suffix : Final[Field] = Field(
    name='iodf_suffix',
    origin='SMF73TSF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CTL,
)
"""Suffix of IODF Name

SMF Info
--------
    Field: `SMF73TSF`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Suffix of IODF Name
"""
iodf_suffix.__doc__ = """Suffix of IODF Name

SMF Info
--------
    Field: `SMF73TSF`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Suffix of IODF Name
"""

iodf_date : Final[Field] = Field(
    name='iodf_date',
    origin='SMF73TDT',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CTL,
)
"""IODF creation date mm/dd/yy

SMF Info
--------
    Field: `SMF73TDT`
    Record: `SMF73S1`
    Map: `SMF73CTL`

IODF creation date mm/dd/yy
"""
iodf_date.__doc__ = """IODF creation date mm/dd/yy

SMF Info
--------
    Field: `SMF73TDT`
    Record: `SMF73S1`
    Map: `SMF73CTL`

IODF creation date mm/dd/yy
"""

iodf_time : Final[Field] = Field(
    name='iodf_time',
    origin='SMF73TTM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CTL,
)
"""IODF creation time hh.mm.ss

SMF Info
--------
    Field: `SMF73TTM`
    Record: `SMF73S1`
    Map: `SMF73CTL`

IODF creation time hh.mm.ss
"""
iodf_time.__doc__ = """IODF creation time hh.mm.ss

SMF Info
--------
    Field: `SMF73TTM`
    Record: `SMF73S1`
    Map: `SMF73CTL`

IODF creation time hh.mm.ss
"""

crc : Final[Field] = Field(
    name='crc',
    origin='SMF73CRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CTL,
)
"""Count of times SRM has restarted the Channel Path Measurement Facility (CPMF).

SMF Info
--------
    Field: `SMF73CRC`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Count of times SRM has restarted the Channel Path Measurement Facility (CPMF).
"""
crc.__doc__ = """Count of times SRM has restarted the Channel Path Measurement Facility (CPMF).

SMF Info
--------
    Field: `SMF73CRC`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Count of times SRM has restarted the Channel Path Measurement Facility (CPMF).
"""

csc : Final[Field] = Field(
    name='csc',
    origin='SMF73CSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CTL,
)
"""Last CPMF sample count

SMF Info
--------
    Field: `SMF73CSC`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Last CPMF sample count
"""
csc.__doc__ = """Last CPMF sample count

SMF Info
--------
    Field: `SMF73CSC`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Last CPMF sample count
"""

tdy : Final[Field] = Field(
    name='tdy',
    origin='SMF73TDY',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CTL,
)
"""IODF creation date mm/dd/yyyy

SMF Info
--------
    Field: `SMF73TDY`
    Record: `SMF73S1`
    Map: `SMF73CTL`

IODF creation date mm/dd/yyyy
"""
tdy.__doc__ = """IODF creation date mm/dd/yyyy

SMF Info
--------
    Field: `SMF73TDY`
    Record: `SMF73S1`
    Map: `SMF73CTL`

IODF creation date mm/dd/yyyy
"""

cmi : Final[Field] = Field(
    name='cmi',
    origin='SMF73CMI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CTL,
)
"""CPMF mode info 0 - CPMF not active 1 - Compatibility Mode 2 - Extended Mode

SMF Info
--------
    Field: `SMF73CMI`
    Record: `SMF73S1`
    Map: `SMF73CTL`

CPMF mode info 0 - CPMF not active 1 - Compatibility Mode 2 - Extended Mode
"""
cmi.__doc__ = """CPMF mode info 0 - CPMF not active 1 - Compatibility Mode 2 - Extended Mode

SMF Info
--------
    Field: `SMF73CMI`
    Record: `SMF73S1`
    Map: `SMF73CTL`

CPMF mode info 0 - CPMF not active 1 - Compatibility Mode 2 - Extended Mode
"""

css : Final[Field] = Field(
    name='css',
    origin='SMF73CSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CTL,
)
"""Channel SubSystem Id, only valid if SMF73MCS = ON

SMF Info
--------
    Field: `SMF73CSS`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Channel SubSystem Id, only valid if SMF73MCS = ON
"""
css.__doc__ = """Channel SubSystem Id, only valid if SMF73MCS = ON

SMF Info
--------
    Field: `SMF73CSS`
    Record: `SMF73S1`
    Map: `SMF73CTL`

Channel SubSystem Id, only valid if SMF73MCS = ON
"""

pid : Final[Field] = Field(
    name='pid',
    origin='SMF73PID',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""CHANNEL PATH IDENTIFICATIONS. THE RANGE OF VALUES IS 0 TO FF

SMF Info
--------
    Field: `SMF73PID`
    Record: `SMF73S1`
    Map: `SMF73CHA`

CHANNEL PATH IDENTIFICATIONS. THE RANGE OF VALUES IS 0 TO FF
"""
pid.__doc__ = """CHANNEL PATH IDENTIFICATIONS. THE RANGE OF VALUES IS 0 TO FF

SMF Info
--------
    Field: `SMF73PID`
    Record: `SMF73S1`
    Map: `SMF73CHA`

CHANNEL PATH IDENTIFICATIONS. THE RANGE OF VALUES IS 0 TO FF
"""

fg2 : Final[Field] = Field(
    name='fg2',
    origin='SMF73FG2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""CHANNEL FLAGS

SMF Info
--------
    Field: `SMF73FG2`
    Record: `SMF73S1`
    Map: `SMF73CHA`

CHANNEL FLAGS
"""
fg2.__doc__ = """CHANNEL FLAGS

SMF Info
--------
    Field: `SMF73FG2`
    Record: `SMF73S1`
    Map: `SMF73CHA`

CHANNEL FLAGS
"""

block_multiplexor : Final[Field] = Field(
    name='block_multiplexor',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fg2,
    record=record,
    record_map=SMF73CHA,
)
"""BLOCK MULTIPLEXOR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

BLOCK MULTIPLEXOR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
block_multiplexor.__doc__ = """BLOCK MULTIPLEXOR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

BLOCK MULTIPLEXOR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

byte_multiplexor : Final[Field] = Field(
    name='byte_multiplexor',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fg2,
    record=record,
    record_map=SMF73CHA,
)
"""BYTE MULTIPLEXOR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

BYTE MULTIPLEXOR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
byte_multiplexor.__doc__ = """BYTE MULTIPLEXOR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

BYTE MULTIPLEXOR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

partial_stat : Final[Field] = Field(
    name='partial_stat',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fg2,
    record=record,
    record_map=SMF73CHA,
)
"""ONLY PARTIAL STATISTICS(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

ONLY PARTIAL STATISTICS

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
partial_stat.__doc__ = """ONLY PARTIAL STATISTICS(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

ONLY PARTIAL STATISTICS

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

data_invalid : Final[Field] = Field(
    name='data_invalid',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fg2,
    record=record,
    record_map=SMF73CHA,
)
"""DATA INVALID. CHANNEL PATH WAS VARIED DURING INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

DATA INVALID. CHANNEL PATH WAS VARIED DURING INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
data_invalid.__doc__ = """DATA INVALID. CHANNEL PATH WAS VARIED DURING INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

DATA INVALID. CHANNEL PATH WAS VARIED DURING INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ch_path_online : Final[Field] = Field(
    name='ch_path_online',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=fg2,
    record=record,
    record_map=SMF73CHA,
)
"""CHANNEL PATH IS CURRENTLY ONLINE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CHANNEL PATH IS CURRENTLY ONLINE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
ch_path_online.__doc__ = """CHANNEL PATH IS CURRENTLY ONLINE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg2`(`SMF73FG2`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CHANNEL PATH IS CURRENTLY ONLINE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ch_flags_ext : Final[Field] = Field(
    name='ch_flags_ext',
    origin='SMF73FG3',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""Channel flags extension

SMF Info
--------
    Field: `SMF73FG3`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel flags extension
"""
ch_flags_ext.__doc__ = """Channel flags extension

SMF Info
--------
    Field: `SMF73FG3`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel flags extension
"""

es_connection_ch : Final[Field] = Field(
    name='es_connection_ch',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=ch_flags_ext,
    record=record,
    record_map=SMF73CHA,
)
"""ES CONNECTION CHANNEL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

ES CONNECTION CHANNEL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
es_connection_ch.__doc__ = """ES CONNECTION CHANNEL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

ES CONNECTION CHANNEL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

es_connection_dir : Final[Field] = Field(
    name='es_connection_dir',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=ch_flags_ext,
    record=record,
    record_map=SMF73CHA,
)
"""ES CONNECTION DIRECTOR ATTACHED TO CHANNEL PATH(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

ES CONNECTION DIRECTOR ATTACHED TO CHANNEL PATH

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
es_connection_dir.__doc__ = """ES CONNECTION DIRECTOR ATTACHED TO CHANNEL PATH(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

ES CONNECTION DIRECTOR ATTACHED TO CHANNEL PATH

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

es_conv_ch : Final[Field] = Field(
    name='es_conv_ch',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=ch_flags_ext,
    record=record,
    record_map=SMF73CHA,
)
"""ES CONVERSION CHANNEL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

ES CONVERSION CHANNEL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
es_conv_ch.__doc__ = """ES CONVERSION CHANNEL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

ES CONVERSION CHANNEL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ch_path_modified : Final[Field] = Field(
    name='ch_path_modified',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=ch_flags_ext,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path modified(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path modified

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ch_path_modified.__doc__ = """Channel path modified(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path modified

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

ch_path_deleted : Final[Field] = Field(
    name='ch_path_deleted',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=ch_flags_ext,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path deleted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path deleted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
ch_path_deleted.__doc__ = """Channel path deleted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path deleted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ch_path_inserted : Final[Field] = Field(
    name='ch_path_inserted',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=ch_flags_ext,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path inserted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path inserted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ch_path_inserted.__doc__ = """Channel path inserted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path inserted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

valid_path : Final[Field] = Field(
    name='valid_path',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=ch_flags_ext,
    record=record,
    record_map=SMF73CHA,
)
"""Valid Path(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Valid Path

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
valid_path.__doc__ = """Valid Path(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Valid Path

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ch_path_shared : Final[Field] = Field(
    name='ch_path_shared',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=ch_flags_ext,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path is shared between logical partitions.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path is shared between logical partitions.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
ch_path_shared.__doc__ = """Channel path is shared between logical partitions.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `ch_flags_ext`(`SMF73FG3`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path is shared between logical partitions.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

fg4 : Final[Field] = Field(
    name='fg4',
    origin='SMF73FG4',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path flags

SMF Info
--------
    Field: `SMF73FG4`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path flags
"""
fg4.__doc__ = """Channel path flags

SMF Info
--------
    Field: `SMF73FG4`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path flags
"""

cpmb_invalid : Final[Field] = Field(
    name='cpmb_invalid',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fg4,
    record=record,
    record_map=SMF73CHA,
)
"""Entry in CPMB was not valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Entry in CPMB was not valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cpmb_invalid.__doc__ = """Entry in CPMB was not valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Entry in CPMB was not valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

ctc_defined : Final[Field] = Field(
    name='ctc_defined',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fg4,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path is CTC defined.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path is CTC defined.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
ctc_defined.__doc__ = """Channel path is CTC defined.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path is CTC defined.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

ch_conversion : Final[Field] = Field(
    name='ch_conversion',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fg4,
    record=record,
    record_map=SMF73CHA,
)
"""Channel conversion 3090(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel conversion 3090

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
ch_conversion.__doc__ = """Channel conversion 3090(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel conversion 3090

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ch_path_dcm : Final[Field] = Field(
    name='ch_path_dcm',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fg4,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path is DCM managed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path is DCM managed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
ch_path_dcm.__doc__ = """Channel path is DCM managed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path is DCM managed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ch_charact_changed : Final[Field] = Field(
    name='ch_charact_changed',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fg4,
    record=record,
    record_map=SMF73CHA,
)
"""Channel characteristics changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel characteristics changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ch_charact_changed.__doc__ = """Channel characteristics changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel characteristics changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ch_path_extended : Final[Field] = Field(
    name='ch_path_extended',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fg4,
    record=record,
    record_map=SMF73CHA,
)
"""Extended channel path measurements are supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Extended channel path measurements are supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ch_path_extended.__doc__ = """Extended channel path measurements are supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Extended channel path measurements are supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

physical_network : Final[Field] = Field(
    name='physical_network',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=fg4,
    record=record,
    record_map=SMF73CHA,
)
"""Physical-network identifiers SMF73NT1 and SMF73NT2 are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Physical-network identifiers SMF73NT1 and SMF73NT2 are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
physical_network.__doc__ = """Physical-network identifiers SMF73NT1 and SMF73NT2 are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg4`(`SMF73FG4`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

Physical-network identifiers SMF73NT1 and SMF73NT2 are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ch_path_busy_samples : Final[Field] = Field(
    name='ch_path_busy_samples',
    origin='SMF73BSY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CHA,
)
"""NUMBER OF SAMPLES IN WHICH THE CHANNEL PATH WAS BUSY. WEIGHTED BY SRM.

SMF Info
--------
    Field: `SMF73BSY`
    Record: `SMF73S1`
    Map: `SMF73CHA`

NUMBER OF SAMPLES IN WHICH THE CHANNEL PATH WAS BUSY. WEIGHTED BY SRM.
"""
ch_path_busy_samples.__doc__ = """NUMBER OF SAMPLES IN WHICH THE CHANNEL PATH WAS BUSY. WEIGHTED BY SRM.

SMF Info
--------
    Field: `SMF73BSY`
    Record: `SMF73S1`
    Map: `SMF73CHA`

NUMBER OF SAMPLES IN WHICH THE CHANNEL PATH WAS BUSY. WEIGHTED BY SRM.
"""

pby : Final[Field] = Field(
    name='pby',
    origin='SMF73PBY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CHA,
)
"""Partition's channel path busy time since last interval (in units of 1024 microseconds)

SMF Info
--------
    Field: `SMF73PBY`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Partition's channel path busy time since last interval (in units of 1024 microseconds)
"""
pby.__doc__ = """Partition's channel path busy time since last interval (in units of 1024 microseconds)

SMF Info
--------
    Field: `SMF73PBY`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Partition's channel path busy time since last interval (in units of 1024 microseconds)
"""

pti : Final[Field] = Field(
    name='pti',
    origin='SMF73PTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path measurement interval (in units of 1024 microseconds)

SMF Info
--------
    Field: `SMF73PTI`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path measurement interval (in units of 1024 microseconds)
"""
pti.__doc__ = """Channel path measurement interval (in units of 1024 microseconds)

SMF Info
--------
    Field: `SMF73PTI`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path measurement interval (in units of 1024 microseconds)
"""

cpd : Final[Field] = Field(
    name='cpd',
    origin='SMF73CPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path description. For an explanation, you can issue the command D M=CHP.

SMF Info
--------
    Field: `SMF73CPD`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path description. For an explanation, you can issue the command D M=CHP.
"""
cpd.__doc__ = """Channel path description. For an explanation, you can issue the command D M=CHP.

SMF Info
--------
    Field: `SMF73CPD`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path description. For an explanation, you can issue the command D M=CHP.
"""

acr : Final[Field] = Field(
    name='acr',
    origin='SMF73ACR',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""Channel Path Acronym

SMF Info
--------
    Field: `SMF73ACR`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel Path Acronym
"""
acr.__doc__ = """Channel Path Acronym

SMF Info
--------
    Field: `SMF73ACR`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel Path Acronym
"""

cmg : Final[Field] = Field(
    name='cmg',
    origin='SMF73CMG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CHA,
)
"""CPMF Channel Measurement Group

SMF Info
--------
    Field: `SMF73CMG`
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel Measurement Group
"""
cmg.__doc__ = """CPMF Channel Measurement Group

SMF Info
--------
    Field: `SMF73CMG`
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel Measurement Group
"""

fg5 : Final[Field] = Field(
    name='fg5',
    origin='SMF73FG5',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path Flags

SMF Info
--------
    Field: `SMF73FG5`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path Flags
"""
fg5.__doc__ = """Channel path Flags

SMF Info
--------
    Field: `SMF73FG5`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path Flags
"""

cpmf_word1 : Final[Field] = Field(
    name='cpmf_word1',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fg5,
    record=record,
    record_map=SMF73CHA,
)
"""CPMF Channel characteristics word 1 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 1 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cpmf_word1.__doc__ = """CPMF Channel characteristics word 1 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 1 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cpmf_word2 : Final[Field] = Field(
    name='cpmf_word2',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fg5,
    record=record,
    record_map=SMF73CHA,
)
"""CPMF Channel characteristics word 2 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 2 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cpmf_word2.__doc__ = """CPMF Channel characteristics word 2 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 2 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

cpmf_word3 : Final[Field] = Field(
    name='cpmf_word3',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fg5,
    record=record,
    record_map=SMF73CHA,
)
"""CPMF Channel characteristics word 3 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 3 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
cpmf_word3.__doc__ = """CPMF Channel characteristics word 3 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 3 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

cpmf_word4 : Final[Field] = Field(
    name='cpmf_word4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fg5,
    record=record,
    record_map=SMF73CHA,
)
"""CPMF Channel characteristics word 4 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 4 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
cpmf_word4.__doc__ = """CPMF Channel characteristics word 4 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 4 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

cpmf_word5 : Final[Field] = Field(
    name='cpmf_word5',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fg5,
    record=record,
    record_map=SMF73CHA,
)
"""CPMF Channel characteristics word 5 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 5 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
cpmf_word5.__doc__ = """CPMF Channel characteristics word 5 valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fg5`(`SMF73FG5`)
    Record: `SMF73S1`
    Map: `SMF73CHA`

CPMF Channel characteristics word 5 valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ch_path_parameter : Final[Field] = Field(
    name='ch_path_parameter',
    origin='SMF73CPP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path parameter

SMF Info
--------
    Field: `SMF73CPP`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path parameter
"""
ch_path_parameter.__doc__ = """Channel path parameter

SMF Info
--------
    Field: `SMF73CPP`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path parameter
"""

gen : Final[Field] = Field(
    name='gen',
    origin='SMF73GEN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CHA,
)
"""Channel type generation

SMF Info
--------
    Field: `SMF73GEN`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel type generation
"""
gen.__doc__ = """Channel type generation

SMF Info
--------
    Field: `SMF73GEN`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel type generation
"""

eix : Final[Field] = Field(
    name='eix',
    origin='SMF73EIX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CHA,
)
"""Index to Extended Channel Data section. Only valid if SMF73XCM (bit 6 of SMF73FG4) is ON

SMF Info
--------
    Field: `SMF73EIX`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Index to Extended Channel Data section. Only valid if SMF73XCM (bit 6 of SMF73FG4) is ON
"""
eix.__doc__ = """Index to Extended Channel Data section. Only valid if SMF73XCM (bit 6 of SMF73FG4) is ON

SMF Info
--------
    Field: `SMF73EIX`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Index to Extended Channel Data section. Only valid if SMF73XCM (bit 6 of SMF73FG4) is ON
"""

spd : Final[Field] = Field(
    name='spd',
    origin='SMF73SPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path speed at the end of interval. If channel path power (bits 4-7 of SMF73MSC) is zero, the channel path speed is in units of 100 megabits per second. Otherwise, this value must be multiplied by 10**Power to get the speed in units of bits per second

SMF Info
--------
    Field: `SMF73SPD`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path speed at the end of interval. If channel path power (bits 4-7 of SMF73MSC) is zero, the channel path speed is in units of 100 megabits per second. Otherwise, this value must be multiplied by 10**Power to get the speed in units of bits per second
"""
spd.__doc__ = """Channel path speed at the end of interval. If channel path power (bits 4-7 of SMF73MSC) is zero, the channel path speed is in units of 100 megabits per second. Otherwise, this value must be multiplied by 10**Power to get the speed in units of bits per second

SMF Info
--------
    Field: `SMF73SPD`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path speed at the end of interval. If channel path power (bits 4-7 of SMF73MSC) is zero, the channel path speed is in units of 100 megabits per second. Otherwise, this value must be multiplied by 10**Power to get the speed in units of bits per second
"""

msc : Final[Field] = Field(
    name='msc',
    origin='SMF73MSC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""Miscellaneous

SMF Info
--------
    Field: `SMF73MSC`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Miscellaneous
"""
msc.__doc__ = """Miscellaneous

SMF Info
--------
    Field: `SMF73MSC`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Miscellaneous
"""

pow : Final[Field] = Field(
    name='pow',
    origin='SMF73POW',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""Channel path power at the end of interval. If non-zero, this value can be used to calculate the channel path speed (SMF73SPD * 10**Power)

SMF Info
--------
    Field: `SMF73POW`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path power at the end of interval. If non-zero, this value can be used to calculate the channel path speed (SMF73SPD * 10**Power)
"""
pow.__doc__ = """Channel path power at the end of interval. If non-zero, this value can be used to calculate the channel path speed (SMF73SPD * 10**Power)

SMF Info
--------
    Field: `SMF73POW`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Channel path power at the end of interval. If non-zero, this value can be used to calculate the channel path speed (SMF73SPD * 10**Power)
"""

nt1 : Final[Field] = Field(
    name='nt1',
    origin='SMF73NT1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""Physical-network identifier (PNET ID) of an Ethernet network that is accessible from the first port of the channel path. Only valid for OSD and IQD channel path types.

SMF Info
--------
    Field: `SMF73NT1`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Physical-network identifier (PNET ID) of an Ethernet network that is accessible from the first port of the channel path. Only valid for OSD and IQD channel path types.
"""
nt1.__doc__ = """Physical-network identifier (PNET ID) of an Ethernet network that is accessible from the first port of the channel path. Only valid for OSD and IQD channel path types.

SMF Info
--------
    Field: `SMF73NT1`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Physical-network identifier (PNET ID) of an Ethernet network that is accessible from the first port of the channel path. Only valid for OSD and IQD channel path types.
"""

nt2 : Final[Field] = Field(
    name='nt2',
    origin='SMF73NT2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73CHA,
)
"""Physical-network identifier (PNET ID) of an Ethernet network that is accessible from the second port of the channel path. Only valid for OSD channel path type.

SMF Info
--------
    Field: `SMF73NT2`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Physical-network identifier (PNET ID) of an Ethernet network that is accessible from the second port of the channel path. Only valid for OSD channel path type.
"""
nt2.__doc__ = """Physical-network identifier (PNET ID) of an Ethernet network that is accessible from the second port of the channel path. Only valid for OSD channel path type.

SMF Info
--------
    Field: `SMF73NT2`
    Record: `SMF73S1`
    Map: `SMF73CHA`

Physical-network identifier (PNET ID) of an Ethernet network that is accessible from the second port of the channel path. Only valid for OSD channel path type.
"""

ecp : Final[Field] = Field(
    name='ecp',
    origin='SMF73ECP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF73ECD,
)
"""Channel path identifier

SMF Info
--------
    Field: `SMF73ECP`
    Record: `SMF73S1`
    Map: `SMF73ECD`

Channel path identifier
"""
ecp.__doc__ = """Channel path identifier

SMF Info
--------
    Field: `SMF73ECP`
    Record: `SMF73S1`
    Map: `SMF73ECD`

Channel path identifier
"""

tut : Final[Field] = Field(
    name='tut',
    origin='SMF73TUT',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM1,
)
"""CPMF Total channel path busy Time in units of 128 microseconds short floating point

SMF Info
--------
    Field: `SMF73TUT`
    Record: `SMF73S1`
    Map: `SMF73CM1`

CPMF Total channel path busy Time in units of 128 microseconds short floating point
"""
tut.__doc__ = """CPMF Total channel path busy Time in units of 128 microseconds short floating point

SMF Info
--------
    Field: `SMF73TUT`
    Record: `SMF73S1`
    Map: `SMF73CM1`

CPMF Total channel path busy Time in units of 128 microseconds short floating point
"""

put : Final[Field] = Field(
    name='put',
    origin='SMF73PUT',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM1,
)
"""CPMF LPAR channel path busy Time in units of 128 microseconds short floating point

SMF Info
--------
    Field: `SMF73PUT`
    Record: `SMF73S1`
    Map: `SMF73CM1`

CPMF LPAR channel path busy Time in units of 128 microseconds short floating point
"""
put.__doc__ = """CPMF LPAR channel path busy Time in units of 128 microseconds short floating point

SMF Info
--------
    Field: `SMF73PUT`
    Record: `SMF73S1`
    Map: `SMF73CM1`

CPMF LPAR channel path busy Time in units of 128 microseconds short floating point
"""

mbc : Final[Field] = Field(
    name='mbc',
    origin='SMF73MBC',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF Maximum Bus Cycles per second (word 1) short floating point

SMF Info
--------
    Field: `SMF73MBC`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Maximum Bus Cycles per second (word 1) short floating point
"""
mbc.__doc__ = """CPMF Maximum Bus Cycles per second (word 1) short floating point

SMF Info
--------
    Field: `SMF73MBC`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Maximum Bus Cycles per second (word 1) short floating point
"""

mcu : Final[Field] = Field(
    name='mcu',
    origin='SMF73MCU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF Maximum Channel work Units per second (word 2) short floating point

SMF Info
--------
    Field: `SMF73MCU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Maximum Channel work Units per second (word 2) short floating point
"""
mcu.__doc__ = """CPMF Maximum Channel work Units per second (word 2) short floating point

SMF Info
--------
    Field: `SMF73MCU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Maximum Channel work Units per second (word 2) short floating point
"""

mwu : Final[Field] = Field(
    name='mwu',
    origin='SMF73MWU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF Maximum Write data Units per second (word 3) short floating point

SMF Info
--------
    Field: `SMF73MWU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Maximum Write data Units per second (word 3) short floating point
"""
mwu.__doc__ = """CPMF Maximum Write data Units per second (word 3) short floating point

SMF Info
--------
    Field: `SMF73MWU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Maximum Write data Units per second (word 3) short floating point
"""

mru : Final[Field] = Field(
    name='mru',
    origin='SMF73MRU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF Maximum Read data Units per second (word 4) short floating point

SMF Info
--------
    Field: `SMF73MRU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Maximum Read data Units per second (word 4) short floating point
"""
mru.__doc__ = """CPMF Maximum Read data Units per second (word 4) short floating point

SMF Info
--------
    Field: `SMF73MRU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Maximum Read data Units per second (word 4) short floating point
"""

us : Final[Field] = Field(
    name='us',
    origin='SMF73US',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF data Unit Size in bytes (word 5) short floating point

SMF Info
--------
    Field: `SMF73US`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF data Unit Size in bytes (word 5) short floating point
"""
us.__doc__ = """CPMF data Unit Size in bytes (word 5) short floating point

SMF Info
--------
    Field: `SMF73US`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF data Unit Size in bytes (word 5) short floating point
"""

tbc : Final[Field] = Field(
    name='tbc',
    origin='SMF73TBC',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF Total Bus Cycles count short floating point

SMF Info
--------
    Field: `SMF73TBC`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Total Bus Cycles count short floating point
"""
tbc.__doc__ = """CPMF Total Bus Cycles count short floating point

SMF Info
--------
    Field: `SMF73TBC`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Total Bus Cycles count short floating point
"""

tuc : Final[Field] = Field(
    name='tuc',
    origin='SMF73TUC',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF Total channel work Unit Count short floating point

SMF Info
--------
    Field: `SMF73TUC`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Total channel work Unit Count short floating point
"""
tuc.__doc__ = """CPMF Total channel work Unit Count short floating point

SMF Info
--------
    Field: `SMF73TUC`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Total channel work Unit Count short floating point
"""

puc : Final[Field] = Field(
    name='puc',
    origin='SMF73PUC',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF LPAR channel work Units Count short floating point

SMF Info
--------
    Field: `SMF73PUC`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF LPAR channel work Units Count short floating point
"""
puc.__doc__ = """CPMF LPAR channel work Units Count short floating point

SMF Info
--------
    Field: `SMF73PUC`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF LPAR channel work Units Count short floating point
"""

twu : Final[Field] = Field(
    name='twu',
    origin='SMF73TWU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF Total Write data Units count short floating point

SMF Info
--------
    Field: `SMF73TWU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Total Write data Units count short floating point
"""
twu.__doc__ = """CPMF Total Write data Units count short floating point

SMF Info
--------
    Field: `SMF73TWU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Total Write data Units count short floating point
"""

pwu : Final[Field] = Field(
    name='pwu',
    origin='SMF73PWU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF LPAR Write data Units count short floating point

SMF Info
--------
    Field: `SMF73PWU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF LPAR Write data Units count short floating point
"""
pwu.__doc__ = """CPMF LPAR Write data Units count short floating point

SMF Info
--------
    Field: `SMF73PWU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF LPAR Write data Units count short floating point
"""

tru : Final[Field] = Field(
    name='tru',
    origin='SMF73TRU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF Total Read data Units count short floating point

SMF Info
--------
    Field: `SMF73TRU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Total Read data Units count short floating point
"""
tru.__doc__ = """CPMF Total Read data Units count short floating point

SMF Info
--------
    Field: `SMF73TRU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF Total Read data Units count short floating point
"""

pru : Final[Field] = Field(
    name='pru',
    origin='SMF73PRU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM2,
)
"""CPMF LPAR Read data Units count short floating point

SMF Info
--------
    Field: `SMF73PRU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF LPAR Read data Units count short floating point
"""
pru.__doc__ = """CPMF LPAR Read data Units count short floating point

SMF Info
--------
    Field: `SMF73PRU`
    Record: `SMF73S1`
    Map: `SMF73CM2`

CPMF LPAR Read data Units count short floating point
"""

pdu : Final[Field] = Field(
    name='pdu',
    origin='SMF73PDU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF LPAR Data Unit size in bytes (word 1) short floating point

SMF Info
--------
    Field: `SMF73PDU`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR Data Unit size in bytes (word 1) short floating point
"""
pdu.__doc__ = """CPMF LPAR Data Unit size in bytes (word 1) short floating point

SMF Info
--------
    Field: `SMF73PDU`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR Data Unit size in bytes (word 1) short floating point
"""

tdu : Final[Field] = Field(
    name='tdu',
    origin='SMF73TDU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF Total Data Unit size in bytes (word 2) short floating point

SMF Info
--------
    Field: `SMF73TDU`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total Data Unit size in bytes (word 2) short floating point
"""
tdu.__doc__ = """CPMF Total Data Unit size in bytes (word 2) short floating point

SMF Info
--------
    Field: `SMF73TDU`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total Data Unit size in bytes (word 2) short floating point
"""

pum : Final[Field] = Field(
    name='pum',
    origin='SMF73PUM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF LPAR Message sent unit size (word 3) short floating point

SMF Info
--------
    Field: `SMF73PUM`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR Message sent unit size (word 3) short floating point
"""
pum.__doc__ = """CPMF LPAR Message sent unit size (word 3) short floating point

SMF Info
--------
    Field: `SMF73PUM`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR Message sent unit size (word 3) short floating point
"""

tum : Final[Field] = Field(
    name='tum',
    origin='SMF73TUM',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF Total Message sent unit size (word 4) short floating point

SMF Info
--------
    Field: `SMF73TUM`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total Message sent unit size (word 4) short floating point
"""
tum.__doc__ = """CPMF Total Message sent unit size (word 4) short floating point

SMF Info
--------
    Field: `SMF73TUM`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total Message sent unit size (word 4) short floating point
"""

pms : Final[Field] = Field(
    name='pms',
    origin='SMF73PMS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF LPAR Message Sent units count short floating point

SMF Info
--------
    Field: `SMF73PMS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR Message Sent units count short floating point
"""
pms.__doc__ = """CPMF LPAR Message Sent units count short floating point

SMF Info
--------
    Field: `SMF73PMS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR Message Sent units count short floating point
"""

tms : Final[Field] = Field(
    name='tms',
    origin='SMF73TMS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF Total Messages Sent units count short floating point

SMF Info
--------
    Field: `SMF73TMS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total Messages Sent units count short floating point
"""
tms.__doc__ = """CPMF Total Messages Sent units count short floating point

SMF Info
--------
    Field: `SMF73TMS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total Messages Sent units count short floating point
"""

pus : Final[Field] = Field(
    name='pus',
    origin='SMF73PUS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF LPAR count of Unsuccessful attempts to Send messages short floating point

SMF Info
--------
    Field: `SMF73PUS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR count of Unsuccessful attempts to Send messages short floating point
"""
pus.__doc__ = """CPMF LPAR count of Unsuccessful attempts to Send messages short floating point

SMF Info
--------
    Field: `SMF73PUS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR count of Unsuccessful attempts to Send messages short floating point
"""

pub : Final[Field] = Field(
    name='pub',
    origin='SMF73PUB',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF LPAR count of Unsuccessful attempts to receive messages due to unavailable Buffers short floating point

SMF Info
--------
    Field: `SMF73PUB`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR count of Unsuccessful attempts to receive messages due to unavailable Buffers short floating point
"""
pub.__doc__ = """CPMF LPAR count of Unsuccessful attempts to receive messages due to unavailable Buffers short floating point

SMF Info
--------
    Field: `SMF73PUB`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR count of Unsuccessful attempts to receive messages due to unavailable Buffers short floating point
"""

tub : Final[Field] = Field(
    name='tub',
    origin='SMF73TUB',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF Total count of Unsuccessful attempts to receive messages due to unavailable Buffers short floating point

SMF Info
--------
    Field: `SMF73TUB`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total count of Unsuccessful attempts to receive messages due to unavailable Buffers short floating point
"""
tub.__doc__ = """CPMF Total count of Unsuccessful attempts to receive messages due to unavailable Buffers short floating point

SMF Info
--------
    Field: `SMF73TUB`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total count of Unsuccessful attempts to receive messages due to unavailable Buffers short floating point
"""

pds : Final[Field] = Field(
    name='pds',
    origin='SMF73PDS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF LPAR Data units Sent count short floating point

SMF Info
--------
    Field: `SMF73PDS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR Data units Sent count short floating point
"""
pds.__doc__ = """CPMF LPAR Data units Sent count short floating point

SMF Info
--------
    Field: `SMF73PDS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF LPAR Data units Sent count short floating point
"""

tds : Final[Field] = Field(
    name='tds',
    origin='SMF73TDS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF73CM3,
)
"""CPMF Total Data units Sent count short floating point

SMF Info
--------
    Field: `SMF73TDS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total Data units Sent count short floating point
"""
tds.__doc__ = """CPMF Total Data units Sent count short floating point

SMF Info
--------
    Field: `SMF73TDS`
    Record: `SMF73S1`
    Map: `SMF73CM3`

CPMF Total Data units Sent count short floating point
"""

eoc : Final[Field] = Field(
    name='eoc',
    origin='SMF73EOC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73EM2,
)
"""Total number of FICON command-mode operations (CPC) that have been attempted by the channel.

SMF Info
--------
    Field: `SMF73EOC`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Total number of FICON command-mode operations (CPC) that have been attempted by the channel.
"""
eoc.__doc__ = """Total number of FICON command-mode operations (CPC) that have been attempted by the channel.

SMF Info
--------
    Field: `SMF73EOC`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Total number of FICON command-mode operations (CPC) that have been attempted by the channel.
"""

eod : Final[Field] = Field(
    name='eod',
    origin='SMF73EOD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73EM2,
)
"""Total number of FICON command-mode operations (CPC) that could not be initiated by the channel due to a lack of available resources

SMF Info
--------
    Field: `SMF73EOD`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Total number of FICON command-mode operations (CPC) that could not be initiated by the channel due to a lack of available resources
"""
eod.__doc__ = """Total number of FICON command-mode operations (CPC) that could not be initiated by the channel due to a lack of available resources

SMF Info
--------
    Field: `SMF73EOD`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Total number of FICON command-mode operations (CPC) that could not be initiated by the channel due to a lack of available resources
"""

eos : Final[Field] = Field(
    name='eos',
    origin='SMF73EOS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73EM2,
)
"""Summation count of FICON command-mode operations (CPC). Each time the number of FICON command-mode operations is incremented, the number of FICON command-mode operations active at the channel, including the one being initiated, is added to this field

SMF Info
--------
    Field: `SMF73EOS`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Summation count of FICON command-mode operations (CPC). Each time the number of FICON command-mode operations is incremented, the number of FICON command-mode operations active at the channel, including the one being initiated, is added to this field
"""
eos.__doc__ = """Summation count of FICON command-mode operations (CPC). Each time the number of FICON command-mode operations is incremented, the number of FICON command-mode operations active at the channel, including the one being initiated, is added to this field

SMF Info
--------
    Field: `SMF73EOS`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Summation count of FICON command-mode operations (CPC). Each time the number of FICON command-mode operations is incremented, the number of FICON command-mode operations active at the channel, including the one being initiated, is added to this field
"""

etc : Final[Field] = Field(
    name='etc',
    origin='SMF73ETC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73EM2,
)
"""Total number of FICON transport-mode operations (CPC) that have been attempted by the channel. Zero when no zHPF.

SMF Info
--------
    Field: `SMF73ETC`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Total number of FICON transport-mode operations (CPC) that have been attempted by the channel. Zero when no zHPF.
"""
etc.__doc__ = """Total number of FICON transport-mode operations (CPC) that have been attempted by the channel. Zero when no zHPF.

SMF Info
--------
    Field: `SMF73ETC`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Total number of FICON transport-mode operations (CPC) that have been attempted by the channel. Zero when no zHPF.
"""

etd : Final[Field] = Field(
    name='etd',
    origin='SMF73ETD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73EM2,
)
"""Total number of FICON transport-mode operations (CPC) that could not be initiated by the channel due to a lack of available resources. Zero when no zHPF.

SMF Info
--------
    Field: `SMF73ETD`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Total number of FICON transport-mode operations (CPC) that could not be initiated by the channel due to a lack of available resources. Zero when no zHPF.
"""
etd.__doc__ = """Total number of FICON transport-mode operations (CPC) that could not be initiated by the channel due to a lack of available resources. Zero when no zHPF.

SMF Info
--------
    Field: `SMF73ETD`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Total number of FICON transport-mode operations (CPC) that could not be initiated by the channel due to a lack of available resources. Zero when no zHPF.
"""

ets : Final[Field] = Field(
    name='ets',
    origin='SMF73ETS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF73EM2,
)
"""Summation count of FICON transport-mode operations (CPC). Each time the number of FICON transport-mode operations is incremented, the number of transport-mode operations active at the channel, including the one being initiated, is added to this field. Zero when no zHPF.

SMF Info
--------
    Field: `SMF73ETS`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Summation count of FICON transport-mode operations (CPC). Each time the number of FICON transport-mode operations is incremented, the number of transport-mode operations active at the channel, including the one being initiated, is added to this field. Zero when no zHPF.
"""
ets.__doc__ = """Summation count of FICON transport-mode operations (CPC). Each time the number of FICON transport-mode operations is incremented, the number of transport-mode operations active at the channel, including the one being initiated, is added to this field. Zero when no zHPF.

SMF Info
--------
    Field: `SMF73ETS`
    Record: `SMF73S1`
    Map: `SMF73EM2`

Summation count of FICON transport-mode operations (CPC). Each time the number of FICON transport-mode operations is incremented, the number of transport-mode operations active at the channel, including the one being initiated, is added to this field. Zero when no zHPF.
"""
