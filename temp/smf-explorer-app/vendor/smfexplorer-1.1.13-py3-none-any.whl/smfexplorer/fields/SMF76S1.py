# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 76 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=76,
                                smf_subtype=1,
                                spec='SMF 76 Subtype 1',
                                post=None)
"""SMF 76 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF76PRO: Final[RecordMap] = RecordMap(
    origin='SMF76PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
SMF76A: Final[RecordMap] = RecordMap(
    origin='SMF76A',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Trace Control Section',
    post=None,
    record_mapping=False)
"""Trace Control Section"""
SMF76B: Final[RecordMap] = RecordMap(
    origin='SMF76B',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Trace Data Section',
    post=None,
    record_mapping=False)
"""Trace Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF76DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF76DTE`
    Record: `SMF76S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF76DTE`
    Record: `SMF76S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF76TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF76TME`
    Record: `SMF76S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF76TME`
    Record: `SMF76S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF76DTE`), `time`(`SMF76TME`)
    Record: `SMF76S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF76DTE`), `time`(`SMF76TME`)
    Record: `SMF76S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF76LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF76LEN`
    Record: `SMF76S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF76LEN`
    Record: `SMF76S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF76SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF76SEG`
    Record: `SMF76S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF76SEG`
    Record: `SMF76S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF76FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF76FLG`
    Record: `SMF76S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF76FLG`
    Record: `SMF76S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF76FLG`)
    Record: `SMF76S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF76RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF76RTY`
    Record: `SMF76S1`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF76RTY`
    Record: `SMF76S1`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF76TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF76TME`
    Record: `SMF76S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF76TME`
    Record: `SMF76S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF76DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF76DTE`
    Record: `SMF76S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF76DTE`
    Record: `SMF76S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF76SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF76SID`
    Record: `SMF76S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF76SID`
    Record: `SMF76S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF76SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF76SSI`
    Record: `SMF76S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF76SSI`
    Record: `SMF76S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF76STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF76STY`
    Record: `SMF76S1`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF76STY`
    Record: `SMF76S1`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF76TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF76TRN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF76TRN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF76PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF76PRS`
    Record: `SMF76S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF76PRS`
    Record: `SMF76S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF76PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF76PRL`
    Record: `SMF76S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF76PRL`
    Record: `SMF76S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF76PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF76PRN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF76PRN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

tcs : Final[Field] = Field(
    name='tcs',
    origin='SMF76TCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO TRACE CONTROL SECTION

SMF Info
--------
    Field: `SMF76TCS`
    Record: `SMF76S1`
    Map: Not part of a map

OFFSET TO TRACE CONTROL SECTION
"""
tcs.__doc__ = """OFFSET TO TRACE CONTROL SECTION

SMF Info
--------
    Field: `SMF76TCS`
    Record: `SMF76S1`
    Map: Not part of a map

OFFSET TO TRACE CONTROL SECTION
"""

tcl : Final[Field] = Field(
    name='tcl',
    origin='SMF76TCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF TRACE CONTROL SECTION

SMF Info
--------
    Field: `SMF76TCL`
    Record: `SMF76S1`
    Map: Not part of a map

LENGTH OF TRACE CONTROL SECTION
"""
tcl.__doc__ = """LENGTH OF TRACE CONTROL SECTION

SMF Info
--------
    Field: `SMF76TCL`
    Record: `SMF76S1`
    Map: Not part of a map

LENGTH OF TRACE CONTROL SECTION
"""

tcn : Final[Field] = Field(
    name='tcn',
    origin='SMF76TCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRACE CONTROL SECTIONS

SMF Info
--------
    Field: `SMF76TCN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF TRACE CONTROL SECTIONS
"""
tcn.__doc__ = """NUMBER OF TRACE CONTROL SECTIONS

SMF Info
--------
    Field: `SMF76TCN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF TRACE CONTROL SECTIONS
"""

tds : Final[Field] = Field(
    name='tds',
    origin='SMF76TDS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO TRACE DATA ENTRY SECTION

SMF Info
--------
    Field: `SMF76TDS`
    Record: `SMF76S1`
    Map: Not part of a map

OFFSET TO TRACE DATA ENTRY SECTION
"""
tds.__doc__ = """OFFSET TO TRACE DATA ENTRY SECTION

SMF Info
--------
    Field: `SMF76TDS`
    Record: `SMF76S1`
    Map: Not part of a map

OFFSET TO TRACE DATA ENTRY SECTION
"""

tdl : Final[Field] = Field(
    name='tdl',
    origin='SMF76TDL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF TRACE DATA ENTRY SECTION

SMF Info
--------
    Field: `SMF76TDL`
    Record: `SMF76S1`
    Map: Not part of a map

LENGTH OF TRACE DATA ENTRY SECTION
"""
tdl.__doc__ = """LENGTH OF TRACE DATA ENTRY SECTION

SMF Info
--------
    Field: `SMF76TDL`
    Record: `SMF76S1`
    Map: Not part of a map

LENGTH OF TRACE DATA ENTRY SECTION
"""

tdn : Final[Field] = Field(
    name='tdn',
    origin='SMF76TDN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRACE DATA ENTRY SECT.

SMF Info
--------
    Field: `SMF76TDN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF TRACE DATA ENTRY SECT.
"""
tdn.__doc__ = """NUMBER OF TRACE DATA ENTRY SECT.

SMF Info
--------
    Field: `SMF76TDN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF TRACE DATA ENTRY SECT.
"""

vfs : Final[Field] = Field(
    name='vfs',
    origin='SMF76VFS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO VARIABLE FORMAT SET

SMF Info
--------
    Field: `SMF76VFS`
    Record: `SMF76S1`
    Map: Not part of a map

OFFSET TO VARIABLE FORMAT SET
"""
vfs.__doc__ = """OFFSET TO VARIABLE FORMAT SET

SMF Info
--------
    Field: `SMF76VFS`
    Record: `SMF76S1`
    Map: Not part of a map

OFFSET TO VARIABLE FORMAT SET
"""

vfl : Final[Field] = Field(
    name='vfl',
    origin='SMF76VFL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF VARIABLE FORMAT SET

SMF Info
--------
    Field: `SMF76VFL`
    Record: `SMF76S1`
    Map: Not part of a map

LENGTH OF VARIABLE FORMAT SET
"""
vfl.__doc__ = """LENGTH OF VARIABLE FORMAT SET

SMF Info
--------
    Field: `SMF76VFL`
    Record: `SMF76S1`
    Map: Not part of a map

LENGTH OF VARIABLE FORMAT SET
"""

vfn : Final[Field] = Field(
    name='vfn',
    origin='SMF76VFN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF VARIABLE FORMAT SET

SMF Info
--------
    Field: `SMF76VFN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF VARIABLE FORMAT SET
"""
vfn.__doc__ = """NUMBER OF VARIABLE FORMAT SET

SMF Info
--------
    Field: `SMF76VFN`
    Record: `SMF76S1`
    Map: Not part of a map

NUMBER OF VARIABLE FORMAT SET
"""

subtype1_variable_trace_data_section_array : Final[Field] = Field(
    name='subtype1_variable_trace_data_section_array',
    origin='SMF76_SUBTYPE1_VARIABLE_TRACE_DATA_SECTION_ARRAY',
    type=None,
    record=record,
)
"""

SMF Info
--------
    Field: `SMF76_SUBTYPE1_VARIABLE_TRACE_DATA_SECTION_ARRAY`
    Record: `SMF76S1`
    Map: Not part of a map
"""
subtype1_variable_trace_data_section_array.__doc__ = """

SMF Info
--------
    Field: `SMF76_SUBTYPE1_VARIABLE_TRACE_DATA_SECTION_ARRAY`
    Record: `SMF76S1`
    Map: Not part of a map
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF76MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF76MFV`
    Record: `SMF76S1`
    Map: `SMF76PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF76MFV`
    Record: `SMF76S1`
    Map: `SMF76PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF76PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF76PRD`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF76PRD`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF76IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF76PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF76IST`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF76IST`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF76DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF76PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF76DAT`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF76DAT`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF76INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF76PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF76INT`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF76INT`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF76SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF76SAM`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF76SAM`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF76FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF76FLA`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF76FLA`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

lower_service_level : Final[Field] = Field(
    name='lower_service_level',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
lower_service_level.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

higher_service_level : Final[Field] = Field(
    name='higher_service_level',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
higher_service_level.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF76PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF76FLA`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF76CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF76PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF76CYC`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF76CYC`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF76MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF76MVS`
    Record: `SMF76S1`
    Map: `SMF76PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF76MVS`
    Record: `SMF76S1`
    Map: `SMF76PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF76IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF76IML`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF76IML`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF76PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF76PRF`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF76PRF`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF76PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF76PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF76PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF76PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF76PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF76PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF76PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF76PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF76PRF`)
    Record: `SMF76S1`
    Map: `SMF76PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF76PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF76PTN`
    Record: `SMF76S1`
    Map: `SMF76PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF76PTN`
    Record: `SMF76S1`
    Map: `SMF76PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF76SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF76SRL`
    Record: `SMF76S1`
    Map: `SMF76PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF76SRL`
    Record: `SMF76S1`
    Map: `SMF76PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF76IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF76PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF76IET`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF76IET`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF76LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF76LGO`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF76LGO`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF76RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF76RAO`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF76RAO`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF76RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF76RAL`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF76RAL`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF76RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF76RAN`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF76RAN`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF76OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF76OIL`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF76OIL`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF76SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF76SYN`
    Record: `SMF76S1`
    Map: `SMF76PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF76SYN`
    Record: `SMF76S1`
    Map: `SMF76PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF76GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF76PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF76GIE`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF76GIE`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF76XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF76XNM`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF76XNM`
    Record: `SMF76S1`
    Map: `SMF76PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF76SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF76SNM`
    Record: `SMF76S1`
    Map: `SMF76PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF76SNM`
    Record: `SMF76S1`
    Map: `SMF76PRO`

System name for current system as defined in CVTSNAME
"""

num : Final[Field] = Field(
    name='num',
    origin='SMF76NUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76A,
)
"""NUMBER OF SET ENTRIES THAT FOLLOW THE TOTAL VALUES

SMF Info
--------
    Field: `SMF76NUM`
    Record: `SMF76S1`
    Map: `SMF76A`

NUMBER OF SET ENTRIES THAT FOLLOW THE TOTAL VALUES
"""
num.__doc__ = """NUMBER OF SET ENTRIES THAT FOLLOW THE TOTAL VALUES

SMF Info
--------
    Field: `SMF76NUM`
    Record: `SMF76S1`
    Map: `SMF76A`

NUMBER OF SET ENTRIES THAT FOLLOW THE TOTAL VALUES
"""

nam : Final[Field] = Field(
    name='nam',
    origin='SMF76NAM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76B,
)
"""FIELD NAME

SMF Info
--------
    Field: `SMF76NAM`
    Record: `SMF76S1`
    Map: `SMF76B`

FIELD NAME
"""
nam.__doc__ = """FIELD NAME

SMF Info
--------
    Field: `SMF76NAM`
    Record: `SMF76S1`
    Map: `SMF76B`

FIELD NAME
"""

opt : Final[Field] = Field(
    name='opt',
    origin='SMF76OPT',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76B,
)
"""FLAGS(OPTIONS SPECIFIED ON TRACE INPUT IN RMF PARMLIB MEMBER FOR THE FIELD NAME)

SMF Info
--------
    Field: `SMF76OPT`
    Record: `SMF76S1`
    Map: `SMF76B`

FLAGS(OPTIONS SPECIFIED ON TRACE INPUT IN RMF PARMLIB MEMBER FOR THE FIELD NAME)
"""
opt.__doc__ = """FLAGS(OPTIONS SPECIFIED ON TRACE INPUT IN RMF PARMLIB MEMBER FOR THE FIELD NAME)

SMF Info
--------
    Field: `SMF76OPT`
    Record: `SMF76S1`
    Map: `SMF76B`

FLAGS(OPTIONS SPECIFIED ON TRACE INPUT IN RMF PARMLIB MEMBER FOR THE FIELD NAME)
"""

min_req : Final[Field] = Field(
    name='min_req',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=opt,
    record=record,
    record_map=SMF76B,
)
"""MINIMUM REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

MINIMUM REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
min_req.__doc__ = """MINIMUM REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

MINIMUM REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

max_req : Final[Field] = Field(
    name='max_req',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=opt,
    record=record,
    record_map=SMF76B,
)
"""MAXIMUM REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

MAXIMUM REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
max_req.__doc__ = """MAXIMUM REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

MAXIMUM REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

avr_req : Final[Field] = Field(
    name='avr_req',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=opt,
    record=record,
    record_map=SMF76B,
)
"""AVERAGE REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

AVERAGE REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
avr_req.__doc__ = """AVERAGE REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

AVERAGE REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

std_dev_req : Final[Field] = Field(
    name='std_dev_req',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=opt,
    record=record,
    record_map=SMF76B,
)
"""STD. DEV. REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

STD. DEV. REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
std_dev_req.__doc__ = """STD. DEV. REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

STD. DEV. REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

end_value_req : Final[Field] = Field(
    name='end_value_req',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=opt,
    record=record,
    record_map=SMF76B,
)
"""END VALUE REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

END VALUE REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
end_value_req.__doc__ = """END VALUE REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

END VALUE REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

all_req : Final[Field] = Field(
    name='all_req',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=opt,
    record=record,
    record_map=SMF76B,
)
"""ALL OPTIONS REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

ALL OPTIONS REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
all_req.__doc__ = """ALL OPTIONS REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

ALL OPTIONS REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ips : Final[Field] = Field(
    name='ips',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=opt,
    record=record,
    record_map=SMF76B,
)
"""IPS CHANGE OCCURRED (AFTER INITIALIZATION)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

IPS CHANGE OCCURRED (AFTER INITIALIZATION)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ips.__doc__ = """IPS CHANGE OCCURRED (AFTER INITIALIZATION)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

IPS CHANGE OCCURRED (AFTER INITIALIZATION)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

name_is_domain : Final[Field] = Field(
    name='name_is_domain',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=opt,
    record=record,
    record_map=SMF76B,
)
"""NAME IS A DOMAIN TABLE FIELD(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

NAME IS A DOMAIN TABLE FIELD

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
name_is_domain.__doc__ = """NAME IS A DOMAIN TABLE FIELD(V)

SMF Info (Virtual Field)
--------
    Field: Based on `opt`(`SMF76OPT`)
    Record: `SMF76S1`
    Map: `SMF76B`

NAME IS A DOMAIN TABLE FIELD

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

op1 : Final[Field] = Field(
    name='op1',
    origin='SMF76OP1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF76B,
)
"""FLAGS

SMF Info
--------
    Field: `SMF76OP1`
    Record: `SMF76S1`
    Map: `SMF76B`

FLAGS
"""
op1.__doc__ = """FLAGS

SMF Info
--------
    Field: `SMF76OP1`
    Record: `SMF76S1`
    Map: `SMF76B`

FLAGS
"""

lpb : Final[Field] = Field(
    name='lpb',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=op1,
    record=record,
    record_map=SMF76B,
)
"""LPB - ID TRACE REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `op1`(`SMF76OP1`)
    Record: `SMF76S1`
    Map: `SMF76B`

LPB - ID TRACE REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
lpb.__doc__ = """LPB - ID TRACE REQUESTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `op1`(`SMF76OP1`)
    Record: `SMF76S1`
    Map: `SMF76B`

LPB - ID TRACE REQUESTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

lpb_end : Final[Field] = Field(
    name='lpb_end',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=op1,
    record=record,
    record_map=SMF76B,
)
"""LPB TRACE REQUEST ENDED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `op1`(`SMF76OP1`)
    Record: `SMF76S1`
    Map: `SMF76B`

LPB TRACE REQUEST ENDED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
lpb_end.__doc__ = """LPB TRACE REQUEST ENDED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `op1`(`SMF76OP1`)
    Record: `SMF76S1`
    Map: `SMF76B`

LPB TRACE REQUEST ENDED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

valid_data : Final[Field] = Field(
    name='valid_data',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=op1,
    record=record,
    record_map=SMF76B,
)
"""ON = VALID DATA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `op1`(`SMF76OP1`)
    Record: `SMF76S1`
    Map: `SMF76B`

ON = VALID DATA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
valid_data.__doc__ = """ON = VALID DATA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `op1`(`SMF76OP1`)
    Record: `SMF76S1`
    Map: `SMF76B`

ON = VALID DATA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

sln : Final[Field] = Field(
    name='sln',
    origin='SMF76SLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76B,
)
"""LENGTH OF A SET

SMF Info
--------
    Field: `SMF76SLN`
    Record: `SMF76S1`
    Map: `SMF76B`

LENGTH OF A SET
"""
sln.__doc__ = """LENGTH OF A SET

SMF Info
--------
    Field: `SMF76SLN`
    Record: `SMF76S1`
    Map: `SMF76B`

LENGTH OF A SET
"""

dln : Final[Field] = Field(
    name='dln',
    origin='SMF76DLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76B,
)
"""LENGTH OF FIELD SAMPLED

SMF Info
--------
    Field: `SMF76DLN`
    Record: `SMF76S1`
    Map: `SMF76B`

LENGTH OF FIELD SAMPLED
"""
dln.__doc__ = """LENGTH OF FIELD SAMPLED

SMF Info
--------
    Field: `SMF76DLN`
    Record: `SMF76S1`
    Map: `SMF76B`

LENGTH OF FIELD SAMPLED
"""

sss : Final[Field] = Field(
    name='sss',
    origin='SMF76SSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76B,
)
"""SAMPLES PER SET

SMF Info
--------
    Field: `SMF76SSS`
    Record: `SMF76S1`
    Map: `SMF76B`

SAMPLES PER SET
"""
sss.__doc__ = """SAMPLES PER SET

SMF Info
--------
    Field: `SMF76SSS`
    Record: `SMF76S1`
    Map: `SMF76B`

SAMPLES PER SET
"""

ssl : Final[Field] = Field(
    name='ssl',
    origin='SMF76SSL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76B,
)
"""SAMPLES PER SET FOR LAST SET IN INTERVAL

SMF Info
--------
    Field: `SMF76SSL`
    Record: `SMF76S1`
    Map: `SMF76B`

SAMPLES PER SET FOR LAST SET IN INTERVAL
"""
ssl.__doc__ = """SAMPLES PER SET FOR LAST SET IN INTERVAL

SMF Info
--------
    Field: `SMF76SSL`
    Record: `SMF76S1`
    Map: `SMF76B`

SAMPLES PER SET FOR LAST SET IN INTERVAL
"""

min : Final[Field] = Field(
    name='min',
    origin='SMF76MIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76B,
)
"""MIN. VALUE OF CONTENTS OF FIELD DURING INTERVAL (VALID IF BIT 0 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76MIN`
    Record: `SMF76S1`
    Map: `SMF76B`

MIN. VALUE OF CONTENTS OF FIELD DURING INTERVAL (VALID IF BIT 0 OR BIT 5 OF SMF76OPT IS SET)
"""
min.__doc__ = """MIN. VALUE OF CONTENTS OF FIELD DURING INTERVAL (VALID IF BIT 0 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76MIN`
    Record: `SMF76S1`
    Map: `SMF76B`

MIN. VALUE OF CONTENTS OF FIELD DURING INTERVAL (VALID IF BIT 0 OR BIT 5 OF SMF76OPT IS SET)
"""

max : Final[Field] = Field(
    name='max',
    origin='SMF76MAX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76B,
)
"""MAX. VALUE OF CONTENTS OF FIELD DURING INTERVAL (VALID IF BIT 1 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76MAX`
    Record: `SMF76S1`
    Map: `SMF76B`

MAX. VALUE OF CONTENTS OF FIELD DURING INTERVAL (VALID IF BIT 1 OR BIT 5 OF SMF76OPT IS SET)
"""
max.__doc__ = """MAX. VALUE OF CONTENTS OF FIELD DURING INTERVAL (VALID IF BIT 1 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76MAX`
    Record: `SMF76S1`
    Map: `SMF76B`

MAX. VALUE OF CONTENTS OF FIELD DURING INTERVAL (VALID IF BIT 1 OR BIT 5 OF SMF76OPT IS SET)
"""

avg : Final[Field] = Field(
    name='avg',
    origin='SMF76AVG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76B,
)
"""ACCUMULATED VALUE USED TO COMPUTE THE AVERAGE STANDARD DEVIATION (VALID IF BIT 2 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76AVG`
    Record: `SMF76S1`
    Map: `SMF76B`

ACCUMULATED VALUE USED TO COMPUTE THE AVERAGE STANDARD DEVIATION (VALID IF BIT 2 OR BIT 5 OF SMF76OPT IS SET)
"""
avg.__doc__ = """ACCUMULATED VALUE USED TO COMPUTE THE AVERAGE STANDARD DEVIATION (VALID IF BIT 2 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76AVG`
    Record: `SMF76S1`
    Map: `SMF76B`

ACCUMULATED VALUE USED TO COMPUTE THE AVERAGE STANDARD DEVIATION (VALID IF BIT 2 OR BIT 5 OF SMF76OPT IS SET)
"""

std : Final[Field] = Field(
    name='std',
    origin='SMF76STD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76B,
)
"""SUM OF SQUARES USED TO COMPUTE STANDARD DEVIATION (VALID IF BIT 3 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76STD`
    Record: `SMF76S1`
    Map: `SMF76B`

SUM OF SQUARES USED TO COMPUTE STANDARD DEVIATION (VALID IF BIT 3 OR BIT 5 OF SMF76OPT IS SET)
"""
std.__doc__ = """SUM OF SQUARES USED TO COMPUTE STANDARD DEVIATION (VALID IF BIT 3 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76STD`
    Record: `SMF76S1`
    Map: `SMF76B`

SUM OF SQUARES USED TO COMPUTE STANDARD DEVIATION (VALID IF BIT 3 OR BIT 5 OF SMF76OPT IS SET)
"""

env : Final[Field] = Field(
    name='env',
    origin='SMF76ENV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF76B,
)
"""END VALUE OF CONTENTS OF FIELD (VALID IF BIT 4 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76ENV`
    Record: `SMF76S1`
    Map: `SMF76B`

END VALUE OF CONTENTS OF FIELD (VALID IF BIT 4 OR BIT 5 OF SMF76OPT IS SET)
"""
env.__doc__ = """END VALUE OF CONTENTS OF FIELD (VALID IF BIT 4 OR BIT 5 OF SMF76OPT IS SET)

SMF Info
--------
    Field: `SMF76ENV`
    Record: `SMF76S1`
    Map: `SMF76B`

END VALUE OF CONTENTS OF FIELD (VALID IF BIT 4 OR BIT 5 OF SMF76OPT IS SET)
"""
