# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 72 Subtype 3"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=72,
                                smf_subtype=3,
                                spec='SMF 72 Subtype 3',
                                post=None)
"""SMF 72 Subtype 3"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __timestamp_mod_inline_post(df):
    timestamp_mod = df['timestamp'] + pd.to_timedelta('500ms')
    return timestamp_mod.dt.floor('s')


def __interval_in_milliseconds_inline_post(df):
    return df.interval.dt.total_seconds() * 1e3


def __cpu_service_coefficient_adjusted_inline_post(df):
    adjustment_factor = 16e7 / df.cpu_rate_adjustment_factor
    adjustment_factor = adjustment_factor.fillna(0)
    return df.cpu_service_coefficient * adjustment_factor


def __srb_service_coefficient_adjusted_inline_post(df):
    adjustment_factor = 16e7 / df.cpu_rate_adjustment_factor
    adjustment_factor = adjustment_factor.fillna(0)
    return df.srb_service_coefficient * adjustment_factor


def __utilization_total_inline_post(df):
    tcbtime_insec = df.total_cpu_service_units * 1e10 / df.cpu_service_coefficient_adjusted
    srbtime_insec = df.total_srb_service_units * 1e10 / df.srb_service_coefficient_adjusted
    total_time = tcbtime_insec.fillna(0) + srbtime_insec.fillna(0) + df.total_rct_time.dt.total_seconds() * 1e3 + df.total_io_interrupt_time.dt.total_seconds() * 1e3 + df.total_hspace_service_time.dt.total_seconds() * 1e3
    return total_time / df.interval_in_milliseconds


def __transaction_total_swapped_in_inline_post(df):
    return df.total_page_residency_time / df.interval_in_milliseconds * 1024 / 1000


def __transaction_average_active_inline_post(df):
    return df.total_transaction_time / df.interval_in_milliseconds * 1024 / 1000


def __transaction_total_per_second_inline_post(df):
    return df.transaction_total_count * 1000 / df.interval_in_milliseconds


def __transaction_executed_per_second_inline_post(df):
    return df.transaction_executed_count * 1000 / df.interval_in_milliseconds


def __transaction_response_time_mean_inline_post(df):
    transaction_response_time_mean = df.transaction_total_time / df.transaction_total_count
    return transaction_response_time_mean.fillna(0)


def __transaction_response_time_variance_inline_post(df):
    numerator = df.transaction_squared_sum_time - (df.transaction_total_time ** 2 / df.transaction_total_count)
    transaction_response_time_variance = numerator / (df.transaction_total_count - 1) * 1024 / 1e9
    valid_filter = (df.transaction_total_count > 5) & (transaction_response_time_variance < 1) & transaction_response_time_variance.notna()
    return transaction_response_time_variance.where(valid_filter, 0)


def __transaction_execution_time_mean_inline_post(df):
    transaction_execution_time_mean = df.transaction_execution_time / df.transaction_total_count * 1024 / 1e6
    return transaction_execution_time_mean.fillna(0)


def __execution_velocity_inline_post(df):
    execution_velocity = df.sample_total_using * 100 / (df.sample_total_using + df.sample_total_delay)
    return execution_velocity.fillna(0)


def __transaction_address_space_percentage_inline_post(df):
    return df.sample_adress_space_count / df.wlm_sampling_count


def __transaction_queue_delay_time_mean_inline_post(df):
    transaction_queue_delay_time_mean = df.transaction_queue_delay_time / df.transaction_total_count * 1024 / 1e6
    return transaction_queue_delay_time_mean.fillna(0)


def __transaction_aff_delay_time_mean_inline_post(df):
    transaction_aff_delay_time_mean = df.transaction_aff_delay_time / df.transaction_total_count * 1024 / 1e6
    return transaction_aff_delay_time_mean.fillna(0)


def __transaction_jcl_time_mean_inline_post(df):
    transaction_jcl_time_mean = df.transaction_jcl_time / df.transaction_total_count * 1024 / 1e6
    return transaction_jcl_time_mean.fillna(0)


def __transaction_inel_delay_time_mean_inline_post(df):
    transaction_inel_delay_time_mean = df.transaction_inel_delay_time / df.transaction_total_count * 1024 / 1e6
    return transaction_inel_delay_time_mean.fillna(0)


def __transaction_enclave_average_inline_post(df):
    return df.total_ind_enclave_active_time / df.interval_in_milliseconds * 1024 / 1000


def __utilization_zaap_inline_post(df):
    return df.total_service_units_zaap * df.normalization_factor_zaap / 256 / df.interval_in_milliseconds


def __utilization_zaap_on_cp_inline_post(df):
    return df.total_service_units_zaap_on_cp / df.interval_in_milliseconds


def __utilization_ziip_inline_post(df):
    utilization_ziip = df.total_service_units_ziip * df.normalization_factor_ziip * 1e4 / 256 / df.cpu_service_coefficient_adjusted
    return utilization_ziip.fillna(0) * 1e6 / df.interval_in_milliseconds


def __utilization_ziip_on_cp_inline_post(df):
    utilization_ziip_on_cp = df.total_service_units_ziip_on_cp * 1e4 / df.cpu_service_coefficient_adjusted
    return utilization_ziip_on_cp.fillna(0) * 1e6 / df.interval_in_milliseconds


def __utilization_cp_inline_post(df):
    return df.utilization_total - df.utilization_ziip - df.utilization_zaap


def __performance_index_inline_post(df):
    bucket_sum = df.class_rt_bucket_1 + df.class_rt_bucket_2 + df.class_rt_bucket_3 + df.class_rt_bucket_4 + df.class_rt_bucket_5 + df.class_rt_bucket_6 + df.class_rt_bucket_7 + df.class_rt_bucket_8 + df.class_rt_bucket_9 + df.class_rt_bucket_10 + df.class_rt_bucket_11 + df.class_rt_bucket_12 + df.class_rt_bucket_13 + df.class_rt_bucket_14
    weighted_bucket_sum = 50*df.class_rt_bucket_1 + 60*df.class_rt_bucket_2 + 70*df.class_rt_bucket_3 + 80*df.class_rt_bucket_4 + 90*df.class_rt_bucket_5 + 100*df.class_rt_bucket_6 + 110*df.class_rt_bucket_7 + 120*df.class_rt_bucket_8 + 130*df.class_rt_bucket_9 + 140*df.class_rt_bucket_10 + 150*df.class_rt_bucket_11 + 200*df.class_rt_bucket_12 + 400*df.class_rt_bucket_13 + 550*df.class_rt_bucket_14
    bucket1 = (df.class_rt_bucket_1 / bucket_sum * 100) >= df.class_goal_percentile
    bucket2 = ((df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket3 = ((df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket4 = ((df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket5 = ((df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket6 = ((df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket7 = ((df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket8 = ((df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket9 = ((df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket10 = ((df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket11 = ((df.class_rt_bucket_11 + df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket12 = ((df.class_rt_bucket_12 + df.class_rt_bucket_11 + df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket13 = ((df.class_rt_bucket_13 + df.class_rt_bucket_12 + df.class_rt_bucket_11 + df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    maxindex = pd.Series([13] * df.shape[0])
    for bucket in [bucket1, bucket2, bucket3, bucket4, bucket5, bucket6, bucket7, bucket8, bucket9, bucket10, bucket11, bucket12, bucket13]:
        maxindex = maxindex.subtract(bucket.astype('int64'))

    performance_index = 0.0 * bucket_sum
    exvel_pi = df.class_goal_value / df.execution_velocity * 100
    avres_pi = weighted_bucket_sum / bucket_sum
    prres_pi = 50 + maxindex * 10 + ((maxindex == 11) * 40) + ((maxindex == 12) * 230) + ((maxindex == 13) * 370)
    performance_index = performance_index.where(df.class_goal_type != "Execution Velocity", exvel_pi)
    performance_index = performance_index.where(df.class_goal_type != "Average Resp. Time", avres_pi)
    performance_index = performance_index.where(df.class_goal_type != "Percentile Resp. Time", prres_pi)
    zerosum = (bucket_sum != 0) | (df.class_goal_type == "Execution Velocity")
    performance_index = performance_index.where(zerosum, 0)
    performance_index = performance_index.fillna(0)
    return performance_index



SMF72PRO: Final[RecordMap] = RecordMap(
    origin='SMF72PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=True)
"""RMF Product Section"""
R723WMS: Final[RecordMap] = RecordMap(
    origin='R723WMS',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Subtype III Data Sections Workload Manager Control Section',
    post=None,
    record_mapping=False)
"""Subtype III Data Sections Workload Manager Control Section"""
R723RGS: Final[RecordMap] = RecordMap(
    origin='R723RGS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Resource Group Data Section',
    post=None,
    record_mapping=False)
"""Resource Group Data Section"""
R723SCS: Final[RecordMap] = RecordMap(
    origin='R723SCS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Service or Report Class Period Data - GOALS',
    post=None,
    record_mapping=False)
"""Service or Report Class Period Data - GOALS"""
R723WRS: Final[RecordMap] = RecordMap(
    origin='R723WRS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Work Manager / Resource Manager States',
    post=None,
    record_mapping=False)
"""Work Manager / Resource Manager States"""
R723SSS: Final[RecordMap] = RecordMap(
    origin='R723SSS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Service Classes being served',
    post=None,
    record_mapping=False)
"""Service Classes being served"""
R723DNS: Final[RecordMap] = RecordMap(
    origin='R723DNS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Resource Delay Names Section',
    post=None,
    record_mapping=False)
"""Resource Delay Names Section"""
R723RTS: Final[RecordMap] = RecordMap(
    origin='R723RTS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Response Time Distribution Map and Counts Table This table defines up ...',
    post=None,
    record_mapping=False)
"""Response Time Distribution Map and Counts Table This table defines up ..."""

date : Final[Field] = Field(
    name='date',
    origin='SMF72DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S3`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S3`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF72TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S3`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S3`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF72DTE`), `time`(`SMF72TME`)
    Record: `SMF72S3`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF72DTE`), `time`(`SMF72TME`)
    Record: `SMF72S3`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

timestamp_mod : Final[Field] = Field(
    name='timestamp_mod',
    origin=None,
    post="core.inline",
    post_param=__timestamp_mod_inline_post,
    virtual=True,
    ref=timestamp,
    record=record,
)
"""Adjusted timestamp that accounts for small difference in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `timestamp`(`None`)
    Record: `SMF72S3`
    Map: Not part of a map

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    timestamp_mod = df['timestamp'] + pd.to_timedelta('500ms')
    return timestamp_mod.dt.floor('s')

"""
timestamp_mod.__doc__ = """Adjusted timestamp that accounts for small difference in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `timestamp`(`None`)
    Record: `SMF72S3`
    Map: Not part of a map

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    timestamp_mod = df['timestamp'] + pd.to_timedelta('500ms')
    return timestamp_mod.dt.floor('s')

"""

len : Final[Field] = Field(
    name='len',
    origin='SMF72LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF72LEN`
    Record: `SMF72S3`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF72LEN`
    Record: `SMF72S3`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF72SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF72SEG`
    Record: `SMF72S3`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF72SEG`
    Record: `SMF72S3`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF72FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF72FLG`
    Record: `SMF72S3`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF72FLG`
    Record: `SMF72S3`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

new_record : Final[Field] = Field(
    name='new_record',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
new_record.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

subtypes_used : Final[Field] = Field(
    name='subtypes_used',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
subtypes_used.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S3`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF72RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF72RTY`
    Record: `SMF72S3`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF72RTY`
    Record: `SMF72S3`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF72TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S3`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S3`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF72DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S3`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S3`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF72SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF72SID`
    Record: `SMF72S3`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF72SID`
    Record: `SMF72S3`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF72SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF72SSI`
    Record: `SMF72S3`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF72SSI`
    Record: `SMF72S3`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF72STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF72STY`
    Record: `SMF72S3`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF72STY`
    Record: `SMF72S3`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF72TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF72TRN`
    Record: `SMF72S3`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF72TRN`
    Record: `SMF72S3`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF72PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRS`
    Record: `SMF72S3`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRS`
    Record: `SMF72S3`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF72PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRL`
    Record: `SMF72S3`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRL`
    Record: `SMF72S3`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF72PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF72PRN`
    Record: `SMF72S3`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF72PRN`
    Record: `SMF72S3`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

wms : Final[Field] = Field(
    name='wms',
    origin='SMF72WMS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to workload manager control section (subtype3)

SMF Info
--------
    Field: `SMF72WMS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to workload manager control section (subtype3)
"""
wms.__doc__ = """Offset to workload manager control section (subtype3)

SMF Info
--------
    Field: `SMF72WMS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to workload manager control section (subtype3)
"""

wml : Final[Field] = Field(
    name='wml',
    origin='SMF72WML',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of workload manager control section (subtype 3)

SMF Info
--------
    Field: `SMF72WML`
    Record: `SMF72S3`
    Map: Not part of a map

Length of workload manager control section (subtype 3)
"""
wml.__doc__ = """Length of workload manager control section (subtype 3)

SMF Info
--------
    Field: `SMF72WML`
    Record: `SMF72S3`
    Map: Not part of a map

Length of workload manager control section (subtype 3)
"""

wmn : Final[Field] = Field(
    name='wmn',
    origin='SMF72WMN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of workload manager control sections (subtype 3)

SMF Info
--------
    Field: `SMF72WMN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of workload manager control sections (subtype 3)
"""
wmn.__doc__ = """Number of workload manager control sections (subtype 3)

SMF Info
--------
    Field: `SMF72WMN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of workload manager control sections (subtype 3)
"""

sss : Final[Field] = Field(
    name='sss',
    origin='SMF72SSS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to service class served data (subtype 3)

SMF Info
--------
    Field: `SMF72SSS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to service class served data (subtype 3)
"""
sss.__doc__ = """Offset to service class served data (subtype 3)

SMF Info
--------
    Field: `SMF72SSS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to service class served data (subtype 3)
"""

ssl : Final[Field] = Field(
    name='ssl',
    origin='SMF72SSL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of service class served data (subtype 3)

SMF Info
--------
    Field: `SMF72SSL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of service class served data (subtype 3)
"""
ssl.__doc__ = """Length of service class served data (subtype 3)

SMF Info
--------
    Field: `SMF72SSL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of service class served data (subtype 3)
"""

ssn : Final[Field] = Field(
    name='ssn',
    origin='SMF72SSN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of service class served data (subtype 3)

SMF Info
--------
    Field: `SMF72SSN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of service class served data (subtype 3)
"""
ssn.__doc__ = """Number of service class served data (subtype 3)

SMF Info
--------
    Field: `SMF72SSN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of service class served data (subtype 3)
"""

rgs : Final[Field] = Field(
    name='rgs',
    origin='SMF72RGS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to resource group data section (subtype 3)

SMF Info
--------
    Field: `SMF72RGS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to resource group data section (subtype 3)
"""
rgs.__doc__ = """Offset to resource group data section (subtype 3)

SMF Info
--------
    Field: `SMF72RGS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to resource group data section (subtype 3)
"""

rgl : Final[Field] = Field(
    name='rgl',
    origin='SMF72RGL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of resource group data section (subtype 3)

SMF Info
--------
    Field: `SMF72RGL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of resource group data section (subtype 3)
"""
rgl.__doc__ = """Length of resource group data section (subtype 3)

SMF Info
--------
    Field: `SMF72RGL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of resource group data section (subtype 3)
"""

rgn : Final[Field] = Field(
    name='rgn',
    origin='SMF72RGN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of resource group data sections (subtype 3)

SMF Info
--------
    Field: `SMF72RGN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of resource group data sections (subtype 3)
"""
rgn.__doc__ = """Number of resource group data sections (subtype 3)

SMF Info
--------
    Field: `SMF72RGN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of resource group data sections (subtype 3)
"""

scs : Final[Field] = Field(
    name='scs',
    origin='SMF72SCS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to period data section (subtype 3)

SMF Info
--------
    Field: `SMF72SCS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to period data section (subtype 3)
"""
scs.__doc__ = """Offset to period data section (subtype 3)

SMF Info
--------
    Field: `SMF72SCS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to period data section (subtype 3)
"""

scl : Final[Field] = Field(
    name='scl',
    origin='SMF72SCL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of period data section (subtype 3)

SMF Info
--------
    Field: `SMF72SCL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of period data section (subtype 3)
"""
scl.__doc__ = """Length of period data section (subtype 3)

SMF Info
--------
    Field: `SMF72SCL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of period data section (subtype 3)
"""

scn : Final[Field] = Field(
    name='scn',
    origin='SMF72SCN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of period data sections (subtype 3)

SMF Info
--------
    Field: `SMF72SCN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of period data sections (subtype 3)
"""
scn.__doc__ = """Number of period data sections (subtype 3)

SMF Info
--------
    Field: `SMF72SCN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of period data sections (subtype 3)
"""

rts : Final[Field] = Field(
    name='rts',
    origin='SMF72RTS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to response time distribution bucket data section (subtype 3)

SMF Info
--------
    Field: `SMF72RTS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to response time distribution bucket data section (subtype 3)
"""
rts.__doc__ = """Offset to response time distribution bucket data section (subtype 3)

SMF Info
--------
    Field: `SMF72RTS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to response time distribution bucket data section (subtype 3)
"""

rtl : Final[Field] = Field(
    name='rtl',
    origin='SMF72RTL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of response time distribution bucket data section (subtype 3)

SMF Info
--------
    Field: `SMF72RTL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of response time distribution bucket data section (subtype 3)
"""
rtl.__doc__ = """Length of response time distribution bucket data section (subtype 3)

SMF Info
--------
    Field: `SMF72RTL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of response time distribution bucket data section (subtype 3)
"""

rtn : Final[Field] = Field(
    name='rtn',
    origin='SMF72RTN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of response time distribution bucket data sections (subtype 3)

SMF Info
--------
    Field: `SMF72RTN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of response time distribution bucket data sections (subtype 3)
"""
rtn.__doc__ = """Number of response time distribution bucket data sections (subtype 3)

SMF Info
--------
    Field: `SMF72RTN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of response time distribution bucket data sections (subtype 3)
"""

wrs : Final[Field] = Field(
    name='wrs',
    origin='SMF72WRS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to work/resource manager state (subtype 3)

SMF Info
--------
    Field: `SMF72WRS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to work/resource manager state (subtype 3)
"""
wrs.__doc__ = """Offset to work/resource manager state (subtype 3)

SMF Info
--------
    Field: `SMF72WRS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to work/resource manager state (subtype 3)
"""

wrl : Final[Field] = Field(
    name='wrl',
    origin='SMF72WRL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of work/resource manager state (subtype 3)

SMF Info
--------
    Field: `SMF72WRL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of work/resource manager state (subtype 3)
"""
wrl.__doc__ = """Length of work/resource manager state (subtype 3)

SMF Info
--------
    Field: `SMF72WRL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of work/resource manager state (subtype 3)
"""

wrn : Final[Field] = Field(
    name='wrn',
    origin='SMF72WRN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of work/resource manager state (subtype 3)

SMF Info
--------
    Field: `SMF72WRN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of work/resource manager state (subtype 3)
"""
wrn.__doc__ = """Number of work/resource manager state (subtype 3)

SMF Info
--------
    Field: `SMF72WRN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of work/resource manager state (subtype 3)
"""

dns : Final[Field] = Field(
    name='dns',
    origin='SMF72DNS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to resource delay names section (subtype 3)

SMF Info
--------
    Field: `SMF72DNS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to resource delay names section (subtype 3)
"""
dns.__doc__ = """Offset to resource delay names section (subtype 3)

SMF Info
--------
    Field: `SMF72DNS`
    Record: `SMF72S3`
    Map: Not part of a map

Offset to resource delay names section (subtype 3)
"""

dnl : Final[Field] = Field(
    name='dnl',
    origin='SMF72DNL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of resource delay names section (subtype 3)

SMF Info
--------
    Field: `SMF72DNL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of resource delay names section (subtype 3)
"""
dnl.__doc__ = """Length of resource delay names section (subtype 3)

SMF Info
--------
    Field: `SMF72DNL`
    Record: `SMF72S3`
    Map: Not part of a map

Length of resource delay names section (subtype 3)
"""

dnn : Final[Field] = Field(
    name='dnn',
    origin='SMF72DNN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of resource delay names sections (subtype 3)

SMF Info
--------
    Field: `SMF72DNN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of resource delay names sections (subtype 3)
"""
dnn.__doc__ = """Number of resource delay names sections (subtype 3)

SMF Info
--------
    Field: `SMF72DNN`
    Record: `SMF72S3`
    Map: Not part of a map

Number of resource delay names sections (subtype 3)
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF72MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF72MFV`
    Record: `SMF72S3`
    Map: `SMF72PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF72MFV`
    Record: `SMF72S3`
    Map: `SMF72PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF72PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF72PRD`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF72PRD`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF72IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF72PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF72IST`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF72IST`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF72DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF72PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF72DAT`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF72DAT`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Date monitor interval start
"""

interval : Final[Field] = Field(
    name='interval',
    origin='SMF72INT',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF72PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF72INT`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Duration of monitor interval
"""
interval.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF72INT`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF72SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF72SAM`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF72SAM`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF72FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF72FLA`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF72FLA`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF72CYC',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF72PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF72CYC`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF72CYC`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF72MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF72MVS`
    Record: `SMF72S3`
    Map: `SMF72PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF72MVS`
    Record: `SMF72S3`
    Map: `SMF72PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF72IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF72IML`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF72IML`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF72PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF72PRF`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF72PRF`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF72PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF72PTN`
    Record: `SMF72S3`
    Map: `SMF72PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF72PTN`
    Record: `SMF72S3`
    Map: `SMF72PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF72SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF72SRL`
    Record: `SMF72S3`
    Map: `SMF72PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF72SRL`
    Record: `SMF72S3`
    Map: `SMF72PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF72IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF72PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF72IET`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF72IET`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF72LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF72LGO`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF72LGO`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF72RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF72RAO`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF72RAO`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF72RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF72RAL`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF72RAL`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF72RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF72RAN`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF72RAN`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF72OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF72OIL`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF72OIL`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF72SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF72SYN`
    Record: `SMF72S3`
    Map: `SMF72PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF72SYN`
    Record: `SMF72S3`
    Map: `SMF72PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF72GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF72PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF72GIE`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF72GIE`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF72XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF72XNM`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF72XNM`
    Record: `SMF72S3`
    Map: `SMF72PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF72SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF72SNM`
    Record: `SMF72S3`
    Map: `SMF72PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF72SNM`
    Record: `SMF72S3`
    Map: `SMF72PRO`

System name for current system as defined in CVTSNAME
"""

interval_in_milliseconds : Final[Field] = Field(
    name='interval_in_milliseconds',
    origin=None,
    post="core.inline",
    post_param=__interval_in_milliseconds_inline_post,
    virtual=True,
    ref=interval,
    record=record,
    record_map=SMF72PRO,
)
"""Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF72INT`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""
interval_in_milliseconds.__doc__ = """Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF72INT`)
    Record: `SMF72S3`
    Map: `SMF72PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""

r723mscf : Final[Field] = Field(
    name='r723mscf',
    origin='R723MSCF',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Service class flags

SMF Info
--------
    Field: `R723MSCF`
    Record: `SMF72S3`
    Map: `R723WMS`

Service class flags
"""
r723mscf.__doc__ = """Service class flags

SMF Info
--------
    Field: `R723MSCF`
    Record: `SMF72S3`
    Map: `R723WMS`

Service class flags
"""

is_report_class : Final[Field] = Field(
    name='is_report_class',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r723mscf,
    record=record,
    record_map=R723WMS,
)
"""x'80' This is a report class (RCAARCL)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'80' This is a report class (RCAARCL)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
is_report_class.__doc__ = """x'80' This is a report class (RCAARCL)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'80' This is a report class (RCAARCL)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

rcaa_unaval : Final[Field] = Field(
    name='rcaa_unaval',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r723mscf,
    record=record,
    record_map=R723WMS,
)
"""x'40' RCAA data not available RC 08/RSN 0831 from IWMRCOLL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'40' RCAA data not available RC 08/RSN 0831 from IWMRCOLL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
rcaa_unaval.__doc__ = """x'40' RCAA data not available RC 08/RSN 0831 from IWMRCOLL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'40' RCAA data not available RC 08/RSN 0831 from IWMRCOLL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

svpol_unaval : Final[Field] = Field(
    name='svpol_unaval',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r723mscf,
    record=record,
    record_map=R723WMS,
)
"""x'20' SVPOL data not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'20' SVPOL data not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
svpol_unaval.__doc__ = """x'20' SVPOL data not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'20' SVPOL data not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

velocity_io_delays : Final[Field] = Field(
    name='velocity_io_delays',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r723mscf,
    record=record,
    record_map=R723WMS,
)
"""x'10' System is calculating velocity using I/O delays(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'10' System is calculating velocity using I/O delays

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
velocity_io_delays.__doc__ = """x'10' System is calculating velocity using I/O delays(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'10' System is calculating velocity using I/O delays

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

cpu_protection : Final[Field] = Field(
    name='cpu_protection',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r723mscf,
    record=record,
    record_map=R723WMS,
)
"""x'08' Indicator for CPU protection(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'08' Indicator for CPU protection

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
cpu_protection.__doc__ = """x'08' Indicator for CPU protection(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'08' Indicator for CPU protection

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

stor_protection : Final[Field] = Field(
    name='stor_protection',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r723mscf,
    record=record,
    record_map=R723WMS,
)
"""x'04' Indicator for storage protection(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'04' Indicator for storage protection

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
stor_protection.__doc__ = """x'04' Indicator for storage protection(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'04' Indicator for storage protection

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dynamic_alias : Final[Field] = Field(
    name='dynamic_alias',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r723mscf,
    record=record,
    record_map=R723WMS,
)
"""x'02' Indicator for dynamic alias management(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'02' Indicator for dynamic alias management

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dynamic_alias.__doc__ = """x'02' Indicator for dynamic alias management(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'02' Indicator for dynamic alias management

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

io_high : Final[Field] = Field(
    name='io_high',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r723mscf,
    record=record,
    record_map=R723WMS,
)
"""x'01' Indicator for I/O priority group HIGH(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'01' Indicator for I/O priority group HIGH

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
io_high.__doc__ = """x'01' Indicator for I/O priority group HIGH(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mscf`(`R723MSCF`)
    Record: `SMF72S3`
    Map: `R723WMS`

x'01' Indicator for I/O priority group HIGH

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r723mflg : Final[Field] = Field(
    name='r723mflg',
    origin='R723MFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Flags

SMF Info
--------
    Field: `R723MFLG`
    Record: `SMF72S3`
    Map: `R723WMS`

Flags
"""
r723mflg.__doc__ = """Flags

SMF Info
--------
    Field: `R723MFLG`
    Record: `SMF72S3`
    Map: `R723WMS`

Flags
"""

zaap_crossover : Final[Field] = Field(
    name='zaap_crossover',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r723mflg,
    record=record,
    record_map=R723WMS,
)
"""Indicates zAAP crossover(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicates zAAP crossover

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
zaap_crossover.__doc__ = """Indicates zAAP crossover(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicates zAAP crossover

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

zaap_honor_prio : Final[Field] = Field(
    name='zaap_honor_prio',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r723mflg,
    record=record,
    record_map=R723WMS,
)
"""Indicates zAAP honor priority(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicates zAAP honor priority

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
zaap_honor_prio.__doc__ = """Indicates zAAP honor priority(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicates zAAP honor priority

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

ziip_honor_prio : Final[Field] = Field(
    name='ziip_honor_prio',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r723mflg,
    record=record,
    record_map=R723WMS,
)
"""Indicates zIIP honor priority(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicates zIIP honor priority

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
ziip_honor_prio.__doc__ = """Indicates zIIP honor priority(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicates zIIP honor priority

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

hismt_failure : Final[Field] = Field(
    name='hismt_failure',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r723mflg,
    record=record,
    record_map=R723WMS,
)
"""Failure returned by HISMT service. Multithreading maximum capacity numerator values are invalid.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Failure returned by HISMT service. Multithreading maximum capacity numerator values are invalid.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
hismt_failure.__doc__ = """Failure returned by HISMT service. Multithreading maximum capacity numerator values are invalid.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Failure returned by HISMT service. Multithreading maximum capacity numerator values are invalid.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

honor_prio : Final[Field] = Field(
    name='honor_prio',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r723mflg,
    record=record,
    record_map=R723WMS,
)
"""Indicates ineligibility for honor priority. When ON, specialty engine eligible work in this service class is not offloaded to CPs for help processing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicates ineligibility for honor priority. When ON, specialty engine eligible work in this service class is not offloaded to CPs for help processing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
honor_prio.__doc__ = """Indicates ineligibility for honor priority. When ON, specialty engine eligible work in this service class is not offloaded to CPs for help processing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicates ineligibility for honor priority. When ON, specialty engine eligible work in this service class is not offloaded to CPs for help processing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

tenant_report_class : Final[Field] = Field(
    name='tenant_report_class',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r723mflg,
    record=record,
    record_map=R723WMS,
)
"""Indicator for a tenant report class(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicator for a tenant report class

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
tenant_report_class.__doc__ = """Indicator for a tenant report class(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Indicator for a tenant report class

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r723mdis : Final[Field] = Field(
    name='r723mdis',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r723mflg,
    record=record,
    record_map=R723WMS,
)
"""Service class and tenant report class periods that are assoc iated with a resource group and have assigned a discretionary goal are excluded from workload management(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Service class and tenant report class periods that are assoc iated with a resource group and have assigned a discretionary goal are excluded from workload management

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r723mdis.__doc__ = """Service class and tenant report class periods that are assoc iated with a resource group and have assigned a discretionary goal are excluded from workload management(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

Service class and tenant report class periods that are assoc iated with a resource group and have assigned a discretionary goal are excluded from workload management

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r723mbai : Final[Field] = Field(
    name='r723mbai',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r723mflg,
    record=record,
    record_map=R723WMS,
)
"""WLM batch initiator management is AI infused(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

WLM batch initiator management is AI infused

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r723mbai.__doc__ = """WLM batch initiator management is AI infused(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mflg`(`R723MFLG`)
    Record: `SMF72S3`
    Map: `R723WMS`

WLM batch initiator management is AI infused

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r723mfl2 : Final[Field] = Field(
    name='r723mfl2',
    origin='R723MFL2',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Additional flags

SMF Info
--------
    Field: `R723MFL2`
    Record: `SMF72S3`
    Map: `R723WMS`

Additional flags
"""
r723mfl2.__doc__ = """Additional flags

SMF Info
--------
    Field: `R723MFL2`
    Record: `SMF72S3`
    Map: `R723WMS`

Additional flags
"""

r723mapo : Final[Field] = Field(
    name='r723mapo',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r723mfl2,
    record=record,
    record_map=R723WMS,
)
"""At least one zAAP online in sysplex (or local system when not joined to a sysplex)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mfl2`(`R723MFL2`)
    Record: `SMF72S3`
    Map: `R723WMS`

At least one zAAP online in sysplex (or local system when not joined to a sysplex)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r723mapo.__doc__ = """At least one zAAP online in sysplex (or local system when not joined to a sysplex)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723mfl2`(`R723MFL2`)
    Record: `SMF72S3`
    Map: `R723WMS`

At least one zAAP online in sysplex (or local system when not joined to a sysplex)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

policy_name : Final[Field] = Field(
    name='policy_name',
    origin='R723MNSP',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Policy name

SMF Info
--------
    Field: `R723MNSP`
    Record: `SMF72S3`
    Map: `R723WMS`

Policy name
"""
policy_name.__doc__ = """Policy name

SMF Info
--------
    Field: `R723MNSP`
    Record: `SMF72S3`
    Map: `R723WMS`

Policy name
"""

policy_descr : Final[Field] = Field(
    name='policy_descr',
    origin='R723MDSP',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Policy description

SMF Info
--------
    Field: `R723MDSP`
    Record: `SMF72S3`
    Map: `R723WMS`

Policy description
"""
policy_descr.__doc__ = """Policy description

SMF Info
--------
    Field: `R723MDSP`
    Record: `SMF72S3`
    Map: `R723WMS`

Policy description
"""

r723mtpa : Final[Field] = Field(
    name='r723mtpa',
    origin='R723MTPA',
    type=FieldType.DATETIME,
    record=record,
    record_map=R723WMS,
)
"""Local time/date of policy activation

SMF Info
--------
    Field: `R723MTPA`
    Record: `SMF72S3`
    Map: `R723WMS`

Local time/date of policy activation
"""
r723mtpa.__doc__ = """Local time/date of policy activation

SMF Info
--------
    Field: `R723MTPA`
    Record: `SMF72S3`
    Map: `R723WMS`

Local time/date of policy activation
"""

cpu_service_coefficient : Final[Field] = Field(
    name='cpu_service_coefficient',
    origin='R723MCPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""System pre-set CPU service coefficient (CPU = 1 * 10000). The number by which accumulated CPU service units will be multiplied (weighted)

SMF Info
--------
    Field: `R723MCPU`
    Record: `SMF72S3`
    Map: `R723WMS`

System pre-set CPU service coefficient (CPU = 1 * 10000). The number by which accumulated CPU service units will be multiplied (weighted)
"""
cpu_service_coefficient.__doc__ = """System pre-set CPU service coefficient (CPU = 1 * 10000). The number by which accumulated CPU service units will be multiplied (weighted)

SMF Info
--------
    Field: `R723MCPU`
    Record: `SMF72S3`
    Map: `R723WMS`

System pre-set CPU service coefficient (CPU = 1 * 10000). The number by which accumulated CPU service units will be multiplied (weighted)
"""

io_service_coefficient : Final[Field] = Field(
    name='io_service_coefficient',
    origin='R723MIOC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""System pre-set I/O service coefficient (IOC=0)

SMF Info
--------
    Field: `R723MIOC`
    Record: `SMF72S3`
    Map: `R723WMS`

System pre-set I/O service coefficient (IOC=0)
"""
io_service_coefficient.__doc__ = """System pre-set I/O service coefficient (IOC=0)

SMF Info
--------
    Field: `R723MIOC`
    Record: `SMF72S3`
    Map: `R723WMS`

System pre-set I/O service coefficient (IOC=0)
"""

storage_service_coefficient : Final[Field] = Field(
    name='storage_service_coefficient',
    origin='R723MMSO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""System pre-set storage service coefficient (MSO=0)

SMF Info
--------
    Field: `R723MMSO`
    Record: `SMF72S3`
    Map: `R723WMS`

System pre-set storage service coefficient (MSO=0)
"""
storage_service_coefficient.__doc__ = """System pre-set storage service coefficient (MSO=0)

SMF Info
--------
    Field: `R723MMSO`
    Record: `SMF72S3`
    Map: `R723WMS`

System pre-set storage service coefficient (MSO=0)
"""

srb_service_coefficient : Final[Field] = Field(
    name='srb_service_coefficient',
    origin='R723MSRB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""System pre-set SRB service coefficient (SRB = 1 * 10000). The number by which accumulated SRB service units will be multiplied (weighted)

SMF Info
--------
    Field: `R723MSRB`
    Record: `SMF72S3`
    Map: `R723WMS`

System pre-set SRB service coefficient (SRB = 1 * 10000). The number by which accumulated SRB service units will be multiplied (weighted)
"""
srb_service_coefficient.__doc__ = """System pre-set SRB service coefficient (SRB = 1 * 10000). The number by which accumulated SRB service units will be multiplied (weighted)

SMF Info
--------
    Field: `R723MSRB`
    Record: `SMF72S3`
    Map: `R723WMS`

System pre-set SRB service coefficient (SRB = 1 * 10000). The number by which accumulated SRB service units will be multiplied (weighted)
"""

r723mtvl : Final[Field] = Field(
    name='r723mtvl',
    origin='R723MTVL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Current sample interval (in milliseconds). This is the frequency with which WLM samples delays reported in the RCAA

SMF Info
--------
    Field: `R723MTVL`
    Record: `SMF72S3`
    Map: `R723WMS`

Current sample interval (in milliseconds). This is the frequency with which WLM samples delays reported in the RCAA
"""
r723mtvl.__doc__ = """Current sample interval (in milliseconds). This is the frequency with which WLM samples delays reported in the RCAA

SMF Info
--------
    Field: `R723MTVL`
    Record: `SMF72S3`
    Map: `R723WMS`

Current sample interval (in milliseconds). This is the frequency with which WLM samples delays reported in the RCAA
"""

wlm_sampling_count : Final[Field] = Field(
    name='wlm_sampling_count',
    origin='R723MTV#',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Total number of times WLM sampling code ran. A RMF issuing successive calls to IWMRCOLL should not assume that WLM sampling code ran at the interval specified by R723MTVL between its calls. This field can be used to translate sampled state data into actual percentages of time.

SMF Info
--------
    Field: `R723MTV#`
    Record: `SMF72S3`
    Map: `R723WMS`

Total number of times WLM sampling code ran. A RMF issuing successive calls to IWMRCOLL should not assume that WLM sampling code ran at the interval specified by R723MTVL between its calls. This field can be used to translate sampled state data into actual percentages of time.
"""
wlm_sampling_count.__doc__ = """Total number of times WLM sampling code ran. A RMF issuing successive calls to IWMRCOLL should not assume that WLM sampling code ran at the interval specified by R723MTVL between its calls. This field can be used to translate sampled state data into actual percentages of time.

SMF Info
--------
    Field: `R723MTV#`
    Record: `SMF72S3`
    Map: `R723WMS`

Total number of times WLM sampling code ran. A RMF issuing successive calls to IWMRCOLL should not assume that WLM sampling code ran at the interval specified by R723MTVL between its calls. This field can be used to translate sampled state data into actual percentages of time.
"""

r723mopt : Final[Field] = Field(
    name='r723mopt',
    origin='R723MOPT',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""OPT member suffix (RCAAOPT)

SMF Info
--------
    Field: `R723MOPT`
    Record: `SMF72S3`
    Map: `R723WMS`

OPT member suffix (RCAAOPT)
"""
r723mopt.__doc__ = """OPT member suffix (RCAAOPT)

SMF Info
--------
    Field: `R723MOPT`
    Record: `SMF72S3`
    Map: `R723WMS`

OPT member suffix (RCAAOPT)
"""

workload : Final[Field] = Field(
    name='workload',
    origin='R723MWNM',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Workload group name

SMF Info
--------
    Field: `R723MWNM`
    Record: `SMF72S3`
    Map: `R723WMS`

Workload group name
"""
workload.__doc__ = """Workload group name

SMF Info
--------
    Field: `R723MWNM`
    Record: `SMF72S3`
    Map: `R723WMS`

Workload group name
"""

workload_descr : Final[Field] = Field(
    name='workload_descr',
    origin='R723MWDE',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Workload group description

SMF Info
--------
    Field: `R723MWDE`
    Record: `SMF72S3`
    Map: `R723WMS`

Workload group description
"""
workload_descr.__doc__ = """Workload group description

SMF Info
--------
    Field: `R723MWDE`
    Record: `SMF72S3`
    Map: `R723WMS`

Workload group description
"""

class_name : Final[Field] = Field(
    name='class_name',
    origin='R723MCNM',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Service/Report class name

SMF Info
--------
    Field: `R723MCNM`
    Record: `SMF72S3`
    Map: `R723WMS`

Service/Report class name
"""
class_name.__doc__ = """Service/Report class name

SMF Info
--------
    Field: `R723MCNM`
    Record: `SMF72S3`
    Map: `R723WMS`

Service/Report class name
"""

report_class : Final[Field] = Field(
    name='report_class',
    origin='R723MCDE',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Service/Report class description

SMF Info
--------
    Field: `R723MCDE`
    Record: `SMF72S3`
    Map: `R723WMS`

Service/Report class description
"""
report_class.__doc__ = """Service/Report class description

SMF Info
--------
    Field: `R723MCDE`
    Record: `SMF72S3`
    Map: `R723WMS`

Service/Report class description
"""

period_number : Final[Field] = Field(
    name='period_number',
    origin='R723MCPG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Number of periods belonging to this service or report class

SMF Info
--------
    Field: `R723MCPG`
    Record: `SMF72S3`
    Map: `R723WMS`

Number of periods belonging to this service or report class
"""
period_number.__doc__ = """Number of periods belonging to this service or report class

SMF Info
--------
    Field: `R723MCPG`
    Record: `SMF72S3`
    Map: `R723WMS`

Number of periods belonging to this service or report class
"""

subsystem_entry : Final[Field] = Field(
    name='subsystem_entry',
    origin='R723MSUB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Number of entries belonging to a subsystem. (See R723MSEC for current release value).

SMF Info
--------
    Field: `R723MSUB`
    Record: `SMF72S3`
    Map: `R723WMS`

Number of entries belonging to a subsystem. (See R723MSEC for current release value).
"""
subsystem_entry.__doc__ = """Number of entries belonging to a subsystem. (See R723MSEC for current release value).

SMF Info
--------
    Field: `R723MSUB`
    Record: `SMF72S3`
    Map: `R723WMS`

Number of entries belonging to a subsystem. (See R723MSEC for current release value).
"""

r723merf : Final[Field] = Field(
    name='r723merf',
    origin='R723MERF',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""ERV resource factor coefficient (from RMPTOPE)

SMF Info
--------
    Field: `R723MERF`
    Record: `SMF72S3`
    Map: `R723WMS`

ERV resource factor coefficient (from RMPTOPE)
"""
r723merf.__doc__ = """ERV resource factor coefficient (from RMPTOPE)

SMF Info
--------
    Field: `R723MERF`
    Record: `SMF72S3`
    Map: `R723WMS`

ERV resource factor coefficient (from RMPTOPE)
"""

cpu_rate_adjustment_factor : Final[Field] = Field(
    name='cpu_rate_adjustment_factor',
    origin='R723MADJ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Value of RMCTADJC - adjustment factor for CPU rate

SMF Info
--------
    Field: `R723MADJ`
    Record: `SMF72S3`
    Map: `R723WMS`

Value of RMCTADJC - adjustment factor for CPU rate
"""
cpu_rate_adjustment_factor.__doc__ = """Value of RMCTADJC - adjustment factor for CPU rate

SMF Info
--------
    Field: `R723MADJ`
    Record: `SMF72S3`
    Map: `R723WMS`

Value of RMCTADJC - adjustment factor for CPU rate
"""

service_definition : Final[Field] = Field(
    name='service_definition',
    origin='R723MIDN',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Service definition name

SMF Info
--------
    Field: `R723MIDN`
    Record: `SMF72S3`
    Map: `R723WMS`

Service definition name
"""
service_definition.__doc__ = """Service definition name

SMF Info
--------
    Field: `R723MIDN`
    Record: `SMF72S3`
    Map: `R723WMS`

Service definition name
"""

service_definition_descr : Final[Field] = Field(
    name='service_definition_descr',
    origin='R723MIDD',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Service definition description

SMF Info
--------
    Field: `R723MIDD`
    Record: `SMF72S3`
    Map: `R723WMS`

Service definition description
"""
service_definition_descr.__doc__ = """Service definition description

SMF Info
--------
    Field: `R723MIDD`
    Record: `SMF72S3`
    Map: `R723WMS`

Service definition description
"""

r723mtdi : Final[Field] = Field(
    name='r723mtdi',
    origin='R723MTDI',
    type=FieldType.DATETIME,
    record=record,
    record_map=R723WMS,
)
"""Local time/date the service definition was installed

SMF Info
--------
    Field: `R723MTDI`
    Record: `SMF72S3`
    Map: `R723WMS`

Local time/date the service definition was installed
"""
r723mtdi.__doc__ = """Local time/date the service definition was installed

SMF Info
--------
    Field: `R723MTDI`
    Record: `SMF72S3`
    Map: `R723WMS`

Local time/date the service definition was installed
"""

r723midu : Final[Field] = Field(
    name='r723midu',
    origin='R723MIDU',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Userid that installed the service definition

SMF Info
--------
    Field: `R723MIDU`
    Record: `SMF72S3`
    Map: `R723WMS`

Userid that installed the service definition
"""
r723midu.__doc__ = """Userid that installed the service definition

SMF Info
--------
    Field: `R723MIDU`
    Record: `SMF72S3`
    Map: `R723WMS`

Userid that installed the service definition
"""

service_class_contributed : Final[Field] = Field(
    name='service_class_contributed',
    origin='R723CLSC',
    type=FieldType.STRING,
    record=record,
    record_map=R723WMS,
)
"""Service class that last contributed to this report class. Blank if this is a service class.

SMF Info
--------
    Field: `R723CLSC`
    Record: `SMF72S3`
    Map: `R723WMS`

Service class that last contributed to this report class. Blank if this is a service class.
"""
service_class_contributed.__doc__ = """Service class that last contributed to this report class. Blank if this is a service class.

SMF Info
--------
    Field: `R723CLSC`
    Record: `SMF72S3`
    Map: `R723WMS`

Service class that last contributed to this report class. Blank if this is a service class.
"""

normalization_factor_zaap : Final[Field] = Field(
    name='normalization_factor_zaap',
    origin='R723NFFI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Normalization factor for zAAP. Multiply zAAP service times or service units with this value and divide by 256 to calculate the CP equivalent value

SMF Info
--------
    Field: `R723NFFI`
    Record: `SMF72S3`
    Map: `R723WMS`

Normalization factor for zAAP. Multiply zAAP service times or service units with this value and divide by 256 to calculate the CP equivalent value
"""
normalization_factor_zaap.__doc__ = """Normalization factor for zAAP. Multiply zAAP service times or service units with this value and divide by 256 to calculate the CP equivalent value

SMF Info
--------
    Field: `R723NFFI`
    Record: `SMF72S3`
    Map: `R723WMS`

Normalization factor for zAAP. Multiply zAAP service times or service units with this value and divide by 256 to calculate the CP equivalent value
"""

normalization_factor_ziip : Final[Field] = Field(
    name='normalization_factor_ziip',
    origin='R723NFFS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Normalization factor for zIIP. Multiply zIIP service units with this value and divide by 256 to calculate the CP equivalent value.

SMF Info
--------
    Field: `R723NFFS`
    Record: `SMF72S3`
    Map: `R723WMS`

Normalization factor for zIIP. Multiply zIIP service units with this value and divide by 256 to calculate the CP equivalent value.
"""
normalization_factor_ziip.__doc__ = """Normalization factor for zIIP. Multiply zIIP service units with this value and divide by 256 to calculate the CP equivalent value.

SMF Info
--------
    Field: `R723NFFS`
    Record: `SMF72S3`
    Map: `R723WMS`

Normalization factor for zIIP. Multiply zIIP service units with this value and divide by 256 to calculate the CP equivalent value.
"""

r723nadj : Final[Field] = Field(
    name='r723nadj',
    origin='R723NADJ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Nominal adjustment factor for CPU rate

SMF Info
--------
    Field: `R723NADJ`
    Record: `SMF72S3`
    Map: `R723WMS`

Nominal adjustment factor for CPU rate
"""
r723nadj.__doc__ = """Nominal adjustment factor for CPU rate

SMF Info
--------
    Field: `R723NADJ`
    Record: `SMF72S3`
    Map: `R723WMS`

Nominal adjustment factor for CPU rate
"""

cec_adjustment_factor : Final[Field] = Field(
    name='cec_adjustment_factor',
    origin='R723CECA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""CEC adjustment factor

SMF Info
--------
    Field: `R723CECA`
    Record: `SMF72S3`
    Map: `R723WMS`

CEC adjustment factor
"""
cec_adjustment_factor.__doc__ = """CEC adjustment factor

SMF Info
--------
    Field: `R723CECA`
    Record: `SMF72S3`
    Map: `R723WMS`

CEC adjustment factor
"""

r723mcf : Final[Field] = Field(
    name='r723mcf',
    origin='R723MCF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multi threading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

SMF Info
--------
    Field: `R723MCF`
    Record: `SMF72S3`
    Map: `R723WMS`

Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multi threading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.
"""
r723mcf.__doc__ = """Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multi threading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

SMF Info
--------
    Field: `R723MCF`
    Record: `SMF72S3`
    Map: `R723WMS`

Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multi threading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.
"""

r723mcfs : Final[Field] = Field(
    name='r723mcfs',
    origin='R723MCFS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Multithreading maximum capacity numerator for zIIP. Divide this value by 1024 to get the multithreading maximum capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed.

SMF Info
--------
    Field: `R723MCFS`
    Record: `SMF72S3`
    Map: `R723WMS`

Multithreading maximum capacity numerator for zIIP. Divide this value by 1024 to get the multithreading maximum capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed.
"""
r723mcfs.__doc__ = """Multithreading maximum capacity numerator for zIIP. Divide this value by 1024 to get the multithreading maximum capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed.

SMF Info
--------
    Field: `R723MCFS`
    Record: `SMF72S3`
    Map: `R723WMS`

Multithreading maximum capacity numerator for zIIP. Divide this value by 1024 to get the multithreading maximum capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed.
"""

r723mcfi : Final[Field] = Field(
    name='r723mcfi',
    origin='R723MCFI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Multithreading maximum capacity numerator for zAAP. Divide this value by 1024 to get the multithreading maximum capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed.

SMF Info
--------
    Field: `R723MCFI`
    Record: `SMF72S3`
    Map: `R723WMS`

Multithreading maximum capacity numerator for zAAP. Divide this value by 1024 to get the multithreading maximum capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed.
"""
r723mcfi.__doc__ = """Multithreading maximum capacity numerator for zAAP. Divide this value by 1024 to get the multithreading maximum capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed.

SMF Info
--------
    Field: `R723MCFI`
    Record: `SMF72S3`
    Map: `R723WMS`

Multithreading maximum capacity numerator for zAAP. Divide this value by 1024 to get the multithreading maximum capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed.
"""

cpu_adjustment_factor : Final[Field] = Field(
    name='cpu_adjustment_factor',
    origin='R723CPA_ACTUAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Physical CPU adjustment factor based on Model Capacity Rating

SMF Info
--------
    Field: `R723CPA_ACTUAL`
    Record: `SMF72S3`
    Map: `R723WMS`

Physical CPU adjustment factor based on Model Capacity Rating
"""
cpu_adjustment_factor.__doc__ = """Physical CPU adjustment factor based on Model Capacity Rating

SMF Info
--------
    Field: `R723CPA_ACTUAL`
    Record: `SMF72S3`
    Map: `R723WMS`

Physical CPU adjustment factor based on Model Capacity Rating
"""

cpa_scaling_factor : Final[Field] = Field(
    name='cpa_scaling_factor',
    origin='R723CPA_SCALING_FACTOR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WMS,
)
"""Scaling factor for R723CPA_actual

SMF Info
--------
    Field: `R723CPA_SCALING_FACTOR`
    Record: `SMF72S3`
    Map: `R723WMS`

Scaling factor for R723CPA_actual
"""
cpa_scaling_factor.__doc__ = """Scaling factor for R723CPA_actual

SMF Info
--------
    Field: `R723CPA_SCALING_FACTOR`
    Record: `SMF72S3`
    Map: `R723WMS`

Scaling factor for R723CPA_actual
"""

cpu_service_coefficient_adjusted : Final[Field] = Field(
    name='cpu_service_coefficient_adjusted',
    origin=None,
    post="core.inline",
    post_param=__cpu_service_coefficient_adjusted_inline_post,
    virtual=True,
    ref=[cpu_service_coefficient, cpu_rate_adjustment_factor],
    record=record,
    record_map=R723WMS,
)
"""CPU service coefficient adjusted with R723MADJ.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_service_coefficient`(`R723MCPU`), `cpu_rate_adjustment_factor`(`R723MADJ`)
    Record: `SMF72S3`
    Map: `R723WMS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    adjustment_factor = 16e7 / df.cpu_rate_adjustment_factor
    adjustment_factor = adjustment_factor.fillna(0)
    return df.cpu_service_coefficient * adjustment_factor

"""
cpu_service_coefficient_adjusted.__doc__ = """CPU service coefficient adjusted with R723MADJ.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_service_coefficient`(`R723MCPU`), `cpu_rate_adjustment_factor`(`R723MADJ`)
    Record: `SMF72S3`
    Map: `R723WMS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    adjustment_factor = 16e7 / df.cpu_rate_adjustment_factor
    adjustment_factor = adjustment_factor.fillna(0)
    return df.cpu_service_coefficient * adjustment_factor

"""

srb_service_coefficient_adjusted : Final[Field] = Field(
    name='srb_service_coefficient_adjusted',
    origin=None,
    post="core.inline",
    post_param=__srb_service_coefficient_adjusted_inline_post,
    virtual=True,
    ref=[srb_service_coefficient, cpu_rate_adjustment_factor],
    record=record,
    record_map=R723WMS,
)
"""SRB service coefficient adjusted with R723MADJ.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `srb_service_coefficient`(`R723MSRB`), `cpu_rate_adjustment_factor`(`R723MADJ`)
    Record: `SMF72S3`
    Map: `R723WMS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    adjustment_factor = 16e7 / df.cpu_rate_adjustment_factor
    adjustment_factor = adjustment_factor.fillna(0)
    return df.srb_service_coefficient * adjustment_factor

"""
srb_service_coefficient_adjusted.__doc__ = """SRB service coefficient adjusted with R723MADJ.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `srb_service_coefficient`(`R723MSRB`), `cpu_rate_adjustment_factor`(`R723MADJ`)
    Record: `SMF72S3`
    Map: `R723WMS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    adjustment_factor = 16e7 / df.cpu_rate_adjustment_factor
    adjustment_factor = adjustment_factor.fillna(0)
    return df.srb_service_coefficient * adjustment_factor

"""

resource_group : Final[Field] = Field(
    name='resource_group',
    origin='R723GGNM',
    type=FieldType.STRING,
    record=record,
    record_map=R723RGS,
)
"""Resource group name

SMF Info
--------
    Field: `R723GGNM`
    Record: `SMF72S3`
    Map: `R723RGS`

Resource group name
"""
resource_group.__doc__ = """Resource group name

SMF Info
--------
    Field: `R723GGNM`
    Record: `SMF72S3`
    Map: `R723RGS`

Resource group name
"""

esource_group_desc : Final[Field] = Field(
    name='esource_group_desc',
    origin='R723GGDE',
    type=FieldType.STRING,
    record=record,
    record_map=R723RGS,
)
"""Resource group description

SMF Info
--------
    Field: `R723GGDE`
    Record: `SMF72S3`
    Map: `R723RGS`

Resource group description
"""
esource_group_desc.__doc__ = """Resource group description

SMF Info
--------
    Field: `R723GGDE`
    Record: `SMF72S3`
    Map: `R723RGS`

Resource group description
"""

r723gglt : Final[Field] = Field(
    name='r723gglt',
    origin='R723GGLT',
    type=FieldType.STRING,
    record=record,
    record_map=R723RGS,
)
"""Resource group flags

SMF Info
--------
    Field: `R723GGLT`
    Record: `SMF72S3`
    Map: `R723RGS`

Resource group flags
"""
r723gglt.__doc__ = """Resource group flags

SMF Info
--------
    Field: `R723GGLT`
    Record: `SMF72S3`
    Map: `R723RGS`

Resource group flags
"""

has_max_capacity : Final[Field] = Field(
    name='has_max_capacity',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r723gglt,
    record=record,
    record_map=R723RGS,
)
"""x'80' Maximum capacity was specified(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

x'80' Maximum capacity was specified

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
has_max_capacity.__doc__ = """x'80' Maximum capacity was specified(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

x'80' Maximum capacity was specified

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

has_min_capacity : Final[Field] = Field(
    name='has_min_capacity',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r723gglt,
    record=record,
    record_map=R723RGS,
)
"""x'40' Minimum capacity was specified(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

x'40' Minimum capacity was specified

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
has_min_capacity.__doc__ = """x'40' Minimum capacity was specified(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

x'40' Minimum capacity was specified

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r723ggpv : Final[Field] = Field(
    name='r723ggpv',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r723gglt,
    record=record,
    record_map=R723RGS,
)
"""Specification of R723GGMN and R723GGMX is in percentage of the LPAR share rather than in service units. In addition, the scope of the resource group is system-wide rather than sysplex-wide(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Specification of R723GGMN and R723GGMX is in percentage of the LPAR share rather than in service units. In addition, the scope of the resource group is system-wide rather than sysplex-wide

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r723ggpv.__doc__ = """Specification of R723GGMN and R723GGMX is in percentage of the LPAR share rather than in service units. In addition, the scope of the resource group is system-wide rather than sysplex-wide(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Specification of R723GGMN and R723GGMX is in percentage of the LPAR share rather than in service units. In addition, the scope of the resource group is system-wide rather than sysplex-wide

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r723ggpc : Final[Field] = Field(
    name='r723ggpc',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r723gglt,
    record=record,
    record_map=R723RGS,
)
"""Specification of R723GGMN and R723GGMX is in percentage of a single processor capacity rather than in service units. In addition, the scope of the resource group is system-wide rather than sysplex-wide(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Specification of R723GGMN and R723GGMX is in percentage of a single processor capacity rather than in service units. In addition, the scope of the resource group is system-wide rather than sysplex-wide

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r723ggpc.__doc__ = """Specification of R723GGMN and R723GGMX is in percentage of a single processor capacity rather than in service units. In addition, the scope of the resource group is system-wide rather than sysplex-wide(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Specification of R723GGMN and R723GGMX is in percentage of a single processor capacity rather than in service units. In addition, the scope of the resource group is system-wide rather than sysplex-wide

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

has_memory_limit : Final[Field] = Field(
    name='has_memory_limit',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r723gglt,
    record=record,
    record_map=R723RGS,
)
"""Memory limit was specified(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Memory limit was specified

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
has_memory_limit.__doc__ = """Memory limit was specified(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Memory limit was specified

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r723ggms : Final[Field] = Field(
    name='r723ggms',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r723gglt,
    record=record,
    record_map=R723RGS,
)
"""Specification of R723GGMN and R723GGMX is in MSU/h rather than in service units(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Specification of R723GGMN and R723GGMX is in MSU/h rather than in service units

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r723ggms.__doc__ = """Specification of R723GGMN and R723GGMX is in MSU/h rather than in service units(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Specification of R723GGMN and R723GGMX is in MSU/h rather than in service units

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r723gisp : Final[Field] = Field(
    name='r723gisp',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r723gglt,
    record=record,
    record_map=R723RGS,
)
"""Specialty processor consumption is included into the WLM capping algorithms, i.e. R723GGMN and R723GGMX limit the combined general purpose and specialty processor consumption(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Specialty processor consumption is included into the WLM capping algorithms, i.e. R723GGMN and R723GGMX limit the combined general purpose and specialty processor consumption

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r723gisp.__doc__ = """Specialty processor consumption is included into the WLM capping algorithms, i.e. R723GGMN and R723GGMX limit the combined general purpose and specialty processor consumption(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723gglt`(`R723GGLT`)
    Record: `SMF72S3`
    Map: `R723RGS`

Specialty processor consumption is included into the WLM capping algorithms, i.e. R723GGMN and R723GGMX limit the combined general purpose and specialty processor consumption

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r723ggtf : Final[Field] = Field(
    name='r723ggtf',
    origin='R723GGTF',
    type=FieldType.STRING,
    record=record,
    record_map=R723RGS,
)
"""Tenant resource group flags

SMF Info
--------
    Field: `R723GGTF`
    Record: `SMF72S3`
    Map: `R723RGS`

Tenant resource group flags
"""
r723ggtf.__doc__ = """Tenant resource group flags

SMF Info
--------
    Field: `R723GGTF`
    Record: `SMF72S3`
    Map: `R723RGS`

Tenant resource group flags
"""

is_tenant : Final[Field] = Field(
    name='is_tenant',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r723ggtf,
    record=record,
    record_map=R723RGS,
)
"""Indicator for a tenant resource group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723ggtf`(`R723GGTF`)
    Record: `SMF72S3`
    Map: `R723RGS`

Indicator for a tenant resource group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
is_tenant.__doc__ = """Indicator for a tenant resource group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723ggtf`(`R723GGTF`)
    Record: `SMF72S3`
    Map: `R723RGS`

Indicator for a tenant resource group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r723ggmn : Final[Field] = Field(
    name='r723ggmn',
    origin='R723GGMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723RGS,
)
"""If R723GMNS is ON, minimum capacity of the resource group. If R723GGPV, R723GGPC and R723GGMS are OFF, this value is in unweighted CPU service units per second. In addition, the scope of the resource group is sysplex-wide. If R723GGPV, R723GGPC or R723GGMS is ON, see description of R723GGLT

SMF Info
--------
    Field: `R723GGMN`
    Record: `SMF72S3`
    Map: `R723RGS`

If R723GMNS is ON, minimum capacity of the resource group. If R723GGPV, R723GGPC and R723GGMS are OFF, this value is in unweighted CPU service units per second. In addition, the scope of the resource group is sysplex-wide. If R723GGPV, R723GGPC or R723GGMS is ON, see description of R723GGLT
"""
r723ggmn.__doc__ = """If R723GMNS is ON, minimum capacity of the resource group. If R723GGPV, R723GGPC and R723GGMS are OFF, this value is in unweighted CPU service units per second. In addition, the scope of the resource group is sysplex-wide. If R723GGPV, R723GGPC or R723GGMS is ON, see description of R723GGLT

SMF Info
--------
    Field: `R723GGMN`
    Record: `SMF72S3`
    Map: `R723RGS`

If R723GMNS is ON, minimum capacity of the resource group. If R723GGPV, R723GGPC and R723GGMS are OFF, this value is in unweighted CPU service units per second. In addition, the scope of the resource group is sysplex-wide. If R723GGPV, R723GGPC or R723GGMS is ON, see description of R723GGLT
"""

r723ggmx : Final[Field] = Field(
    name='r723ggmx',
    origin='R723GGMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723RGS,
)
"""If R723GMXS is ON, maximum capacity of the resource group. If R723GGPV, R723GGPC and R723GGMS are OFF, this value is in unweighted CPU service units per second. In addition, the scope of the resource group is sysplex-wide. If R723GGPV, R723GGPC or R723GGMS is ON, see description of R723GGLT

SMF Info
--------
    Field: `R723GGMX`
    Record: `SMF72S3`
    Map: `R723RGS`

If R723GMXS is ON, maximum capacity of the resource group. If R723GGPV, R723GGPC and R723GGMS are OFF, this value is in unweighted CPU service units per second. In addition, the scope of the resource group is sysplex-wide. If R723GGPV, R723GGPC or R723GGMS is ON, see description of R723GGLT
"""
r723ggmx.__doc__ = """If R723GMXS is ON, maximum capacity of the resource group. If R723GGPV, R723GGPC and R723GGMS are OFF, this value is in unweighted CPU service units per second. In addition, the scope of the resource group is sysplex-wide. If R723GGPV, R723GGPC or R723GGMS is ON, see description of R723GGLT

SMF Info
--------
    Field: `R723GGMX`
    Record: `SMF72S3`
    Map: `R723RGS`

If R723GMXS is ON, maximum capacity of the resource group. If R723GGPV, R723GGPC and R723GGMS are OFF, this value is in unweighted CPU service units per second. In addition, the scope of the resource group is sysplex-wide. If R723GGPV, R723GGPC or R723GGMS is ON, see description of R723GGLT
"""

resource_group_memory : Final[Field] = Field(
    name='resource_group_memory',
    origin='R723GGML',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723RGS,
)
"""If R723GMLS is ON, memory limit of the resource group

SMF Info
--------
    Field: `R723GGML`
    Record: `SMF72S3`
    Map: `R723RGS`

If R723GMLS is ON, memory limit of the resource group
"""
resource_group_memory.__doc__ = """If R723GMLS is ON, memory limit of the resource group

SMF Info
--------
    Field: `R723GGML`
    Record: `SMF72S3`
    Map: `R723RGS`

If R723GMLS is ON, memory limit of the resource group
"""

r723ggti : Final[Field] = Field(
    name='r723ggti',
    origin='R723GGTI',
    type=FieldType.STRING,
    record=record,
    record_map=R723RGS,
)
"""Tenant identifier. Only valid if R723GTRG is ON.

SMF Info
--------
    Field: `R723GGTI`
    Record: `SMF72S3`
    Map: `R723RGS`

Tenant identifier. Only valid if R723GTRG is ON.
"""
r723ggti.__doc__ = """Tenant identifier. Only valid if R723GTRG is ON.

SMF Info
--------
    Field: `R723GGTI`
    Record: `SMF72S3`
    Map: `R723RGS`

Tenant identifier. Only valid if R723GTRG is ON.
"""

tenant_resource_group : Final[Field] = Field(
    name='tenant_resource_group',
    origin='R723GGTN',
    type=FieldType.STRING,
    record=record,
    record_map=R723RGS,
)
"""Tenant name. Only valid if R723GTRG is ON.

SMF Info
--------
    Field: `R723GGTN`
    Record: `SMF72S3`
    Map: `R723RGS`

Tenant name. Only valid if R723GTRG is ON.
"""
tenant_resource_group.__doc__ = """Tenant name. Only valid if R723GTRG is ON.

SMF Info
--------
    Field: `R723GGTN`
    Record: `SMF72S3`
    Map: `R723RGS`

Tenant name. Only valid if R723GTRG is ON.
"""

solution_indent : Final[Field] = Field(
    name='solution_indent',
    origin='R723GGKY',
    type=FieldType.STRING,
    record=record,
    record_map=R723RGS,
)
"""Solution identifier. Only valid if R723GTRG is ON.

SMF Info
--------
    Field: `R723GGKY`
    Record: `SMF72S3`
    Map: `R723RGS`

Solution identifier. Only valid if R723GTRG is ON.
"""
solution_indent.__doc__ = """Solution identifier. Only valid if R723GTRG is ON.

SMF Info
--------
    Field: `R723GGKY`
    Record: `SMF72S3`
    Map: `R723RGS`

Solution identifier. Only valid if R723GTRG is ON.
"""

r723crtx : Final[Field] = Field(
    name='r723crtx',
    origin='R723CRTX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Index into the response time distribution buckets. Entry 0 represents the distribution map

SMF Info
--------
    Field: `R723CRTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Index into the response time distribution buckets. Entry 0 represents the distribution map
"""
r723crtx.__doc__ = """Index into the response time distribution buckets. Entry 0 represents the distribution map

SMF Info
--------
    Field: `R723CRTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Index into the response time distribution buckets. Entry 0 represents the distribution map
"""

r723cwmx : Final[Field] = Field(
    name='r723cwmx',
    origin='R723CWMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Index into the work/resource manager states area

SMF Info
--------
    Field: `R723CWMX`
    Record: `SMF72S3`
    Map: `R723SCS`

Index into the work/resource manager states area
"""
r723cwmx.__doc__ = """Index into the work/resource manager states area

SMF Info
--------
    Field: `R723CWMX`
    Record: `SMF72S3`
    Map: `R723SCS`

Index into the work/resource manager states area
"""

r723cwmn : Final[Field] = Field(
    name='r723cwmn',
    origin='R723CWMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Number of entries in the work/resource manager states area associated with this service class period (R723CWMX points to the first entry)

SMF Info
--------
    Field: `R723CWMN`
    Record: `SMF72S3`
    Map: `R723SCS`

Number of entries in the work/resource manager states area associated with this service class period (R723CWMX points to the first entry)
"""
r723cwmn.__doc__ = """Number of entries in the work/resource manager states area associated with this service class period (R723CWMX points to the first entry)

SMF Info
--------
    Field: `R723CWMN`
    Record: `SMF72S3`
    Map: `R723SCS`

Number of entries in the work/resource manager states area associated with this service class period (R723CWMX points to the first entry)
"""

r723crs1 : Final[Field] = Field(
    name='r723crs1',
    origin='R723CRS1',
    type=FieldType.STRING,
    record=record,
    record_map=R723SCS,
)
"""Service and Report class period flags

SMF Info
--------
    Field: `R723CRS1`
    Record: `SMF72S3`
    Map: `R723SCS`

Service and Report class period flags
"""
r723crs1.__doc__ = """Service and Report class period flags

SMF Info
--------
    Field: `R723CRS1`
    Record: `SMF72S3`
    Map: `R723SCS`

Service and Report class period flags
"""

is_heterogeneous : Final[Field] = Field(
    name='is_heterogeneous',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r723crs1,
    record=record,
    record_map=R723SCS,
)
"""This report class period is heterogeneous.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crs1`(`R723CRS1`)
    Record: `SMF72S3`
    Map: `R723SCS`

This report class period is heterogeneous.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
is_heterogeneous.__doc__ = """This report class period is heterogeneous.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crs1`(`R723CRS1`)
    Record: `SMF72S3`
    Map: `R723SCS`

This report class period is heterogeneous.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r723ccimp : Final[Field] = Field(
    name='r723ccimp',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r723crs1,
    record=record,
    record_map=R723SCS,
)
"""Service class period implicitly designated CPU critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crs1`(`R723CRS1`)
    Record: `SMF72S3`
    Map: `R723SCS`

Service class period implicitly designated CPU critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r723ccimp.__doc__ = """Service class period implicitly designated CPU critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crs1`(`R723CRS1`)
    Record: `SMF72S3`
    Map: `R723SCS`

Service class period implicitly designated CPU critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r723cadf : Final[Field] = Field(
    name='r723cadf',
    origin='R723CADF',
    type=FieldType.STRING,
    record=record,
    record_map=R723SCS,
)
"""Actuals data section flag

SMF Info
--------
    Field: `R723CADF`
    Record: `SMF72S3`
    Map: `R723SCS`

Actuals data section flag
"""
r723cadf.__doc__ = """Actuals data section flag

SMF Info
--------
    Field: `R723CADF`
    Record: `SMF72S3`
    Map: `R723SCS`

Actuals data section flag
"""

r723crca : Final[Field] = Field(
    name='r723crca',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r723cadf,
    record=record,
    record_map=R723SCS,
)
"""Resource consumption data actuals (R723CRCD) are available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723cadf`(`R723CADF`)
    Record: `SMF72S3`
    Map: `R723SCS`

Resource consumption data actuals (R723CRCD) are available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r723crca.__doc__ = """Resource consumption data actuals (R723CRCD) are available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723cadf`(`R723CADF`)
    Record: `SMF72S3`
    Map: `R723SCS`

Resource consumption data actuals (R723CRCD) are available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r723crta : Final[Field] = Field(
    name='r723crta',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r723cadf,
    record=record,
    record_map=R723SCS,
)
"""Response time data actuals (R723CRTD) are available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723cadf`(`R723CADF`)
    Record: `SMF72S3`
    Map: `R723SCS`

Response time data actuals (R723CRTD) are available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r723crta.__doc__ = """Response time data actuals (R723CRTD) are available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723cadf`(`R723CADF`)
    Record: `SMF72S3`
    Map: `R723SCS`

Response time data actuals (R723CRTD) are available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r723ceda : Final[Field] = Field(
    name='r723ceda',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r723cadf,
    record=record,
    record_map=R723SCS,
)
"""General execution delay data actuals (R723CGDE) are available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723cadf`(`R723CADF`)
    Record: `SMF72S3`
    Map: `R723SCS`

General execution delay data actuals (R723CGDE) are available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r723ceda.__doc__ = """General execution delay data actuals (R723CGDE) are available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723cadf`(`R723CADF`)
    Record: `SMF72S3`
    Map: `R723SCS`

General execution delay data actuals (R723CGDE) are available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

class_period : Final[Field] = Field(
    name='class_period',
    origin='R723CPER',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Period number

SMF Info
--------
    Field: `R723CPER`
    Record: `SMF72S3`
    Map: `R723SCS`

Period number
"""
class_period.__doc__ = """Period number

SMF Info
--------
    Field: `R723CPER`
    Record: `SMF72S3`
    Map: `R723SCS`

Period number
"""

r723crtf : Final[Field] = Field(
    name='r723crtf',
    origin='R723CRTF',
    type=FieldType.STRING,
    record=record,
    record_map=R723SCS,
)
"""Response time flags

SMF Info
--------
    Field: `R723CRTF`
    Record: `SMF72S3`
    Map: `R723SCS`

Response time flags
"""
r723crtf.__doc__ = """Response time flags

SMF Info
--------
    Field: `R723CRTF`
    Record: `SMF72S3`
    Map: `R723SCS`

Response time flags
"""

response_time_millisec : Final[Field] = Field(
    name='response_time_millisec',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r723crtf,
    record=record,
    record_map=R723SCS,
)
"""x'80' Response time specified in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crtf`(`R723CRTF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'80' Response time specified in milliseconds

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
response_time_millisec.__doc__ = """x'80' Response time specified in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crtf`(`R723CRTF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'80' Response time specified in milliseconds

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

response_time_seconds : Final[Field] = Field(
    name='response_time_seconds',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r723crtf,
    record=record,
    record_map=R723SCS,
)
"""x'40' Response time specified in seconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crtf`(`R723CRTF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'40' Response time specified in seconds

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
response_time_seconds.__doc__ = """x'40' Response time specified in seconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crtf`(`R723CRTF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'40' Response time specified in seconds

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

response_time_minutes : Final[Field] = Field(
    name='response_time_minutes',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r723crtf,
    record=record,
    record_map=R723SCS,
)
"""x'20' Response time specified in minutes(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crtf`(`R723CRTF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'20' Response time specified in minutes

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
response_time_minutes.__doc__ = """x'20' Response time specified in minutes(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crtf`(`R723CRTF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'20' Response time specified in minutes

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

response_time_hours : Final[Field] = Field(
    name='response_time_hours',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r723crtf,
    record=record,
    record_map=R723SCS,
)
"""x'10' Response time specified in hours(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crtf`(`R723CRTF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'10' Response time specified in hours

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
response_time_hours.__doc__ = """x'10' Response time specified in hours(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723crtf`(`R723CRTF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'10' Response time specified in hours

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

class_goal_flags : Final[Field] = Field(
    name='class_goal_flags',
    origin='R723CRGF',
    type=FieldType.STRING,
    record=record,
    record_map=R723SCS,
)
"""Response time goal flags

SMF Info
--------
    Field: `R723CRGF`
    Record: `SMF72S3`
    Map: `R723SCS`

Response time goal flags
"""
class_goal_flags.__doc__ = """Response time goal flags

SMF Info
--------
    Field: `R723CRGF`
    Record: `SMF72S3`
    Map: `R723SCS`

Response time goal flags
"""

r723cprc : Final[Field] = Field(
    name='r723cprc',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=class_goal_flags,
    record=record,
    record_map=R723SCS,
)
"""x'80' Percentile response time goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'80' Percentile response time goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r723cprc.__doc__ = """x'80' Percentile response time goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'80' Percentile response time goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r723cavg : Final[Field] = Field(
    name='r723cavg',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=class_goal_flags,
    record=record,
    record_map=R723SCS,
)
"""x'40' Average response time goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'40' Average response time goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r723cavg.__doc__ = """x'40' Average response time goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'40' Average response time goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r723cvel : Final[Field] = Field(
    name='r723cvel',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=class_goal_flags,
    record=record,
    record_map=R723SCS,
)
"""x'20' Execution velocity goal goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'20' Execution velocity goal goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r723cvel.__doc__ = """x'20' Execution velocity goal goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'20' Execution velocity goal goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r723cdsc : Final[Field] = Field(
    name='r723cdsc',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=class_goal_flags,
    record=record,
    record_map=R723SCS,
)
"""x'10' Discretionary goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'10' Discretionary goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r723cdsc.__doc__ = """x'10' Discretionary goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'10' Discretionary goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r723cstm : Final[Field] = Field(
    name='r723cstm',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=class_goal_flags,
    record=record,
    record_map=R723SCS,
)
"""x'08' System specified goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'08' System specified goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r723cstm.__doc__ = """x'08' System specified goal(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

x'08' System specified goal

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

class_goal_value : Final[Field] = Field(
    name='class_goal_value',
    origin='R723CVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Response time goal - or Execution velocity goal - or zero if discretionary, system or no goal

SMF Info
--------
    Field: `R723CVAL`
    Record: `SMF72S3`
    Map: `R723SCS`

Response time goal - or Execution velocity goal - or zero if discretionary, system or no goal
"""
class_goal_value.__doc__ = """Response time goal - or Execution velocity goal - or zero if discretionary, system or no goal

SMF Info
--------
    Field: `R723CVAL`
    Record: `SMF72S3`
    Map: `R723SCS`

Response time goal - or Execution velocity goal - or zero if discretionary, system or no goal
"""

class_goal_percentile : Final[Field] = Field(
    name='class_goal_percentile',
    origin='R723CPCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Goal percentile value

SMF Info
--------
    Field: `R723CPCT`
    Record: `SMF72S3`
    Map: `R723SCS`

Goal percentile value
"""
class_goal_percentile.__doc__ = """Goal percentile value

SMF Info
--------
    Field: `R723CPCT`
    Record: `SMF72S3`
    Map: `R723SCS`

Goal percentile value
"""

r723cimp : Final[Field] = Field(
    name='r723cimp',
    origin='R723CIMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Relative importance of the goal to be achieved for this service class period (1=highest, 5=lowest)

SMF Info
--------
    Field: `R723CIMP`
    Record: `SMF72S3`
    Map: `R723SCS`

Relative importance of the goal to be achieved for this service class period (1=highest, 5=lowest)
"""
r723cimp.__doc__ = """Relative importance of the goal to be achieved for this service class period (1=highest, 5=lowest)

SMF Info
--------
    Field: `R723CIMP`
    Record: `SMF72S3`
    Map: `R723SCS`

Relative importance of the goal to be achieved for this service class period (1=highest, 5=lowest)
"""

r723cdur : Final[Field] = Field(
    name='r723cdur',
    origin='R723CDUR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Service class period duration in service units, or zero for last period

SMF Info
--------
    Field: `R723CDUR`
    Record: `SMF72S3`
    Map: `R723SCS`

Service class period duration in service units, or zero for last period
"""
r723cdur.__doc__ = """Service class period duration in service units, or zero for last period

SMF Info
--------
    Field: `R723CDUR`
    Record: `SMF72S3`
    Map: `R723SCS`

Service class period duration in service units, or zero for last period
"""

total_service_units : Final[Field] = Field(
    name='total_service_units',
    origin='R723CSRV',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CSRV`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units (floating point 64-bit long format)
"""
total_service_units.__doc__ = """Total service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CSRV`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units (floating point 64-bit long format)
"""

total_cpu_service_units : Final[Field] = Field(
    name='total_cpu_service_units',
    origin='R723CCPU',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total CPU service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CCPU`
    Record: `SMF72S3`
    Map: `R723SCS`

Total CPU service units (floating point 64-bit long format)
"""
total_cpu_service_units.__doc__ = """Total CPU service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CCPU`
    Record: `SMF72S3`
    Map: `R723SCS`

Total CPU service units (floating point 64-bit long format)
"""

r723cioc : Final[Field] = Field(
    name='r723cioc',
    origin='R723CIOC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total IOC service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CIOC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total IOC service units (floating point 64-bit long format)
"""
r723cioc.__doc__ = """Total IOC service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CIOC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total IOC service units (floating point 64-bit long format)
"""

r723cmso : Final[Field] = Field(
    name='r723cmso',
    origin='R723CMSO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total storage service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CMSO`
    Record: `SMF72S3`
    Map: `R723SCS`

Total storage service units (floating point 64-bit long format)
"""
r723cmso.__doc__ = """Total storage service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CMSO`
    Record: `SMF72S3`
    Map: `R723SCS`

Total storage service units (floating point 64-bit long format)
"""

total_srb_service_units : Final[Field] = Field(
    name='total_srb_service_units',
    origin='R723CSRB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total SRB service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CSRB`
    Record: `SMF72S3`
    Map: `R723SCS`

Total SRB service units (floating point 64-bit long format)
"""
total_srb_service_units.__doc__ = """Total SRB service units (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CSRB`
    Record: `SMF72S3`
    Map: `R723SCS`

Total SRB service units (floating point 64-bit long format)
"""

r723cpir : Final[Field] = Field(
    name='r723cpir',
    origin='R723CPIR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total page-in count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CPIR`
    Record: `SMF72S3`
    Map: `R723SCS`

Total page-in count (floating point 64-bit long format)
"""
r723cpir.__doc__ = """Total page-in count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CPIR`
    Record: `SMF72S3`
    Map: `R723SCS`

Total page-in count (floating point 64-bit long format)
"""

r723chpi : Final[Field] = Field(
    name='r723chpi',
    origin='R723CHPI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total hiperspace page-in count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CHPI`
    Record: `SMF72S3`
    Map: `R723SCS`

Total hiperspace page-in count (floating point 64-bit long format)
"""
r723chpi.__doc__ = """Total hiperspace page-in count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CHPI`
    Record: `SMF72S3`
    Map: `R723SCS`

Total hiperspace page-in count (floating point 64-bit long format)
"""

r723cbpi : Final[Field] = Field(
    name='r723cbpi',
    origin='R723CBPI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total block page-in from aux count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CBPI`
    Record: `SMF72S3`
    Map: `R723SCS`

Total block page-in from aux count (floating point 64-bit long format)
"""
r723cbpi.__doc__ = """Total block page-in from aux count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CBPI`
    Record: `SMF72S3`
    Map: `R723SCS`

Total block page-in from aux count (floating point 64-bit long format)
"""

r723cpie : Final[Field] = Field(
    name='r723cpie',
    origin='R723CPIE',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total page-in from expanded count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CPIE`
    Record: `SMF72S3`
    Map: `R723SCS`

Total page-in from expanded count (floating point 64-bit long format)
"""
r723cpie.__doc__ = """Total page-in from expanded count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CPIE`
    Record: `SMF72S3`
    Map: `R723SCS`

Total page-in from expanded count (floating point 64-bit long format)
"""

r723cbpe : Final[Field] = Field(
    name='r723cbpe',
    origin='R723CBPE',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total block page-in from expanded count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CBPE`
    Record: `SMF72S3`
    Map: `R723SCS`

Total block page-in from expanded count (floating point 64-bit long format)
"""
r723cbpe.__doc__ = """Total block page-in from expanded count (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CBPE`
    Record: `SMF72S3`
    Map: `R723SCS`

Total block page-in from expanded count (floating point 64-bit long format)
"""

r723cbka : Final[Field] = Field(
    name='r723cbka',
    origin='R723CBKA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total aux blocks paged in (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CBKA`
    Record: `SMF72S3`
    Map: `R723SCS`

Total aux blocks paged in (floating point 64-bit long format)
"""
r723cbka.__doc__ = """Total aux blocks paged in (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CBKA`
    Record: `SMF72S3`
    Map: `R723SCS`

Total aux blocks paged in (floating point 64-bit long format)
"""

r723cbke : Final[Field] = Field(
    name='r723cbke',
    origin='R723CBKE',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total expanded blocks paged in (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CBKE`
    Record: `SMF72S3`
    Map: `R723SCS`

Total expanded blocks paged in (floating point 64-bit long format)
"""
r723cbke.__doc__ = """Total expanded blocks paged in (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CBKE`
    Record: `SMF72S3`
    Map: `R723SCS`

Total expanded blocks paged in (floating point 64-bit long format)
"""

total_page_residency_time : Final[Field] = Field(
    name='total_page_residency_time',
    origin='R723CPRS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total page residency time (1024 microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CPRS`
    Record: `SMF72S3`
    Map: `R723SCS`

Total page residency time (1024 microsecond) (floating point 64-bit long format)
"""
total_page_residency_time.__doc__ = """Total page residency time (1024 microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CPRS`
    Record: `SMF72S3`
    Map: `R723SCS`

Total page residency time (1024 microsecond) (floating point 64-bit long format)
"""

r723cers : Final[Field] = Field(
    name='r723cers',
    origin='R723CERS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total expanded page residency time (1024 microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CERS`
    Record: `SMF72S3`
    Map: `R723SCS`

Total expanded page residency time (1024 microseconds) (floating point 64-bit long format)
"""
r723cers.__doc__ = """Total expanded page residency time (1024 microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CERS`
    Record: `SMF72S3`
    Map: `R723SCS`

Total expanded page residency time (1024 microseconds) (floating point 64-bit long format)
"""

r723ctrr : Final[Field] = Field(
    name='r723ctrr',
    origin='R723CTRR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total in storage residency time (1024 microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CTRR`
    Record: `SMF72S3`
    Map: `R723SCS`

Total in storage residency time (1024 microsecond) (floating point 64-bit long format)
"""
r723ctrr.__doc__ = """Total in storage residency time (1024 microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CTRR`
    Record: `SMF72S3`
    Map: `R723SCS`

Total in storage residency time (1024 microsecond) (floating point 64-bit long format)
"""

total_transaction_time : Final[Field] = Field(
    name='total_transaction_time',
    origin='R723CTAT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total transaction active time (1024 microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CTAT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction active time (1024 microsecond) (floating point 64-bit long format)
"""
total_transaction_time.__doc__ = """Total transaction active time (1024 microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CTAT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction active time (1024 microsecond) (floating point 64-bit long format)
"""

total_rct_time : Final[Field] = Field(
    name='total_rct_time',
    origin='R723CRCT',
    post='core.timedelta',
    post_param="""us""",
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total RCT time (microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CRCT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total RCT time (microseconds) (floating point 64-bit long format)

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `us`
"""
total_rct_time.__doc__ = """Total RCT time (microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CRCT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total RCT time (microseconds) (floating point 64-bit long format)

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `us`
"""

total_io_interrupt_time : Final[Field] = Field(
    name='total_io_interrupt_time',
    origin='R723CIIT',
    post='core.timedelta',
    post_param="""us""",
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total I/O interrupt time (microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CIIT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total I/O interrupt time (microsecond) (floating point 64-bit long format)

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `us`
"""
total_io_interrupt_time.__doc__ = """Total I/O interrupt time (microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CIIT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total I/O interrupt time (microsecond) (floating point 64-bit long format)

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `us`
"""

total_hspace_service_time : Final[Field] = Field(
    name='total_hspace_service_time',
    origin='R723CHST',
    post='core.timedelta',
    post_param="""us""",
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total hiperspace service time (microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CHST`
    Record: `SMF72S3`
    Map: `R723SCS`

Total hiperspace service time (microseconds) (floating point 64-bit long format)

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `us`
"""
total_hspace_service_time.__doc__ = """Total hiperspace service time (microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CHST`
    Record: `SMF72S3`
    Map: `R723SCS`

Total hiperspace service time (microseconds) (floating point 64-bit long format)

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `us`
"""

r723cswc : Final[Field] = Field(
    name='r723cswc',
    origin='R723CSWC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Total swap count

SMF Info
--------
    Field: `R723CSWC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total swap count
"""
r723cswc.__doc__ = """Total swap count

SMF Info
--------
    Field: `R723CSWC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total swap count
"""

r723ccrm : Final[Field] = Field(
    name='r723ccrm',
    origin='R723CCRM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Total hiperspace eso read miss count

SMF Info
--------
    Field: `R723CCRM`
    Record: `SMF72S3`
    Map: `R723SCS`

Total hiperspace eso read miss count
"""
r723ccrm.__doc__ = """Total hiperspace eso read miss count

SMF Info
--------
    Field: `R723CCRM`
    Record: `SMF72S3`
    Map: `R723SCS`

Total hiperspace eso read miss count
"""

transaction_total_count : Final[Field] = Field(
    name='transaction_total_count',
    origin='R723CRCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Count of transaction completions for this period. This field includes transaction completions reported by subsystem work managers via the IWMRPT service

SMF Info
--------
    Field: `R723CRCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Count of transaction completions for this period. This field includes transaction completions reported by subsystem work managers via the IWMRPT service
"""
transaction_total_count.__doc__ = """Count of transaction completions for this period. This field includes transaction completions reported by subsystem work managers via the IWMRPT service

SMF Info
--------
    Field: `R723CRCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Count of transaction completions for this period. This field includes transaction completions reported by subsystem work managers via the IWMRPT service
"""

r723carc : Final[Field] = Field(
    name='r723carc',
    origin='R723CARC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Count of transaction that completed abnormally as reported by subsystem work manager. This value is not part of R723CRCP and should not be used for response time calculations

SMF Info
--------
    Field: `R723CARC`
    Record: `SMF72S3`
    Map: `R723SCS`

Count of transaction that completed abnormally as reported by subsystem work manager. This value is not part of R723CRCP and should not be used for response time calculations
"""
r723carc.__doc__ = """Count of transaction that completed abnormally as reported by subsystem work manager. This value is not part of R723CRCP and should not be used for response time calculations

SMF Info
--------
    Field: `R723CARC`
    Record: `SMF72S3`
    Map: `R723SCS`

Count of transaction that completed abnormally as reported by subsystem work manager. This value is not part of R723CRCP and should not be used for response time calculations
"""

transaction_executed_count : Final[Field] = Field(
    name='transaction_executed_count',
    origin='R723CNCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Count of transaction that completed their execution phase as reported by subsystem work managers via the IWMNTFY service

SMF Info
--------
    Field: `R723CNCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Count of transaction that completed their execution phase as reported by subsystem work managers via the IWMNTFY service
"""
transaction_executed_count.__doc__ = """Count of transaction that completed their execution phase as reported by subsystem work managers via the IWMNTFY service

SMF Info
--------
    Field: `R723CNCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Count of transaction that completed their execution phase as reported by subsystem work managers via the IWMNTFY service
"""

r723canc : Final[Field] = Field(
    name='r723canc',
    origin='R723CANC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Count of transaction that completed their execution phase abnormally as reported by subsystem work Manager. This value is not part of R723CNCP and should not be used for execution response time calculations

SMF Info
--------
    Field: `R723CANC`
    Record: `SMF72S3`
    Map: `R723SCS`

Count of transaction that completed their execution phase abnormally as reported by subsystem work Manager. This value is not part of R723CNCP and should not be used for execution response time calculations
"""
r723canc.__doc__ = """Count of transaction that completed their execution phase abnormally as reported by subsystem work Manager. This value is not part of R723CNCP and should not be used for execution response time calculations

SMF Info
--------
    Field: `R723CANC`
    Record: `SMF72S3`
    Map: `R723SCS`

Count of transaction that completed their execution phase abnormally as reported by subsystem work Manager. This value is not part of R723CNCP and should not be used for execution response time calculations
"""

transaction_total_time : Final[Field] = Field(
    name='transaction_total_time',
    origin='R723CTET',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total transaction elapsed time (1024 microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CTET`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction elapsed time (1024 microsecond) (floating point 64-bit long format)
"""
transaction_total_time.__doc__ = """Total transaction elapsed time (1024 microsecond) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CTET`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction elapsed time (1024 microsecond) (floating point 64-bit long format)
"""

transaction_execution_time : Final[Field] = Field(
    name='transaction_execution_time',
    origin='R723CXET',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total transaction execution time (1024 microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CXET`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction execution time (1024 microseconds) (floating point 64-bit long format)
"""
transaction_execution_time.__doc__ = """Total transaction execution time (1024 microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CXET`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction execution time (1024 microseconds) (floating point 64-bit long format)
"""

transaction_squared_sum_time : Final[Field] = Field(
    name='transaction_squared_sum_time',
    origin='R723CETS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Sum of transaction elapsed times squared (1024 microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CETS`
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of transaction elapsed times squared (1024 microseconds) (floating point 64-bit long format)
"""
transaction_squared_sum_time.__doc__ = """Sum of transaction elapsed times squared (1024 microseconds) (floating point 64-bit long format)

SMF Info
--------
    Field: `R723CETS`
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of transaction elapsed times squared (1024 microseconds) (floating point 64-bit long format)
"""

sample_cpu_using : Final[Field] = Field(
    name='sample_cpu_using',
    origin='R723CCUS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""CPU using samples

SMF Info
--------
    Field: `R723CCUS`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU using samples
"""
sample_cpu_using.__doc__ = """CPU using samples

SMF Info
--------
    Field: `R723CCUS`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU using samples
"""

sample_total_delay : Final[Field] = Field(
    name='sample_total_delay',
    origin='R723CTOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Total delay samples used in SRM's execution velocity calculation

SMF Info
--------
    Field: `R723CTOT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total delay samples used in SRM's execution velocity calculation
"""
sample_total_delay.__doc__ = """Total delay samples used in SRM's execution velocity calculation

SMF Info
--------
    Field: `R723CTOT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total delay samples used in SRM's execution velocity calculation
"""

sample_cpu_delay : Final[Field] = Field(
    name='sample_cpu_delay',
    origin='R723CCDE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""CPU delay. A TCB or SRB is waiting to be dispatched (other than the first in-line behind sampler) or a TCB is waiting for local lock

SMF Info
--------
    Field: `R723CCDE`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU delay. A TCB or SRB is waiting to be dispatched (other than the first in-line behind sampler) or a TCB is waiting for local lock
"""
sample_cpu_delay.__doc__ = """CPU delay. A TCB or SRB is waiting to be dispatched (other than the first in-line behind sampler) or a TCB is waiting for local lock

SMF Info
--------
    Field: `R723CCDE`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU delay. A TCB or SRB is waiting to be dispatched (other than the first in-line behind sampler) or a TCB is waiting for local lock
"""

sample_cpu_capping_delay : Final[Field] = Field(
    name='sample_cpu_capping_delay',
    origin='R723CCCA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""CPU capping delay. A TCB or SRB is marked non-dispatchable because a resource group maximum is being enforced. Note that R723CCCA is NOT a subset of R723CCDE

SMF Info
--------
    Field: `R723CCCA`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU capping delay. A TCB or SRB is marked non-dispatchable because a resource group maximum is being enforced. Note that R723CCCA is NOT a subset of R723CCDE
"""
sample_cpu_capping_delay.__doc__ = """CPU capping delay. A TCB or SRB is marked non-dispatchable because a resource group maximum is being enforced. Note that R723CCCA is NOT a subset of R723CCDE

SMF Info
--------
    Field: `R723CCCA`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU capping delay. A TCB or SRB is marked non-dispatchable because a resource group maximum is being enforced. Note that R723CCCA is NOT a subset of R723CCDE
"""

sample_swapin_delay : Final[Field] = Field(
    name='sample_swapin_delay',
    origin='R723CSWI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Swap-in delay. Swap-in has started, but not completed completed

SMF Info
--------
    Field: `R723CSWI`
    Record: `SMF72S3`
    Map: `R723SCS`

Swap-in delay. Swap-in has started, but not completed completed
"""
sample_swapin_delay.__doc__ = """Swap-in delay. Swap-in has started, but not completed completed

SMF Info
--------
    Field: `R723CSWI`
    Record: `SMF72S3`
    Map: `R723SCS`

Swap-in delay. Swap-in has started, but not completed completed
"""

sample_mpl_delay : Final[Field] = Field(
    name='sample_mpl_delay',
    origin='R723CMPL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""MPL delay. Ready but swap-in has not started

SMF Info
--------
    Field: `R723CMPL`
    Record: `SMF72S3`
    Map: `R723SCS`

MPL delay. Ready but swap-in has not started
"""
sample_mpl_delay.__doc__ = """MPL delay. Ready but swap-in has not started

SMF Info
--------
    Field: `R723CMPL`
    Record: `SMF72S3`
    Map: `R723SCS`

MPL delay. Ready but swap-in has not started
"""

sample_aux_private_delay : Final[Field] = Field(
    name='sample_aux_private_delay',
    origin='R723CAPR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""AUX page from private

SMF Info
--------
    Field: `R723CAPR`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from private
"""
sample_aux_private_delay.__doc__ = """AUX page from private

SMF Info
--------
    Field: `R723CAPR`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from private
"""

sample_aux_common_delay : Final[Field] = Field(
    name='sample_aux_common_delay',
    origin='R723CACO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""AUX page from common

SMF Info
--------
    Field: `R723CACO`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from common
"""
sample_aux_common_delay.__doc__ = """AUX page from common

SMF Info
--------
    Field: `R723CACO`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from common
"""

sample_aux_cross_mem_delay : Final[Field] = Field(
    name='sample_aux_cross_mem_delay',
    origin='R723CAXM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""AUX page from cross memory memory

SMF Info
--------
    Field: `R723CAXM`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from cross memory memory
"""
sample_aux_cross_mem_delay.__doc__ = """AUX page from cross memory memory

SMF Info
--------
    Field: `R723CAXM`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from cross memory memory
"""

sample_aux_vio_delay : Final[Field] = Field(
    name='sample_aux_vio_delay',
    origin='R723CVIO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""AUX page from VIO

SMF Info
--------
    Field: `R723CVIO`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from VIO
"""
sample_aux_vio_delay.__doc__ = """AUX page from VIO

SMF Info
--------
    Field: `R723CVIO`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from VIO
"""

sample_aux_std_hspace_delay : Final[Field] = Field(
    name='sample_aux_std_hspace_delay',
    origin='R723CHSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""AUX page from standard hiperspaces

SMF Info
--------
    Field: `R723CHSP`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from standard hiperspaces
"""
sample_aux_std_hspace_delay.__doc__ = """AUX page from standard hiperspaces

SMF Info
--------
    Field: `R723CHSP`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from standard hiperspaces
"""

sample_aux_eso_hspace_delay : Final[Field] = Field(
    name='sample_aux_eso_hspace_delay',
    origin='R723CCHS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""AUX page from eso hiperspaces

SMF Info
--------
    Field: `R723CCHS`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from eso hiperspaces
"""
sample_aux_eso_hspace_delay.__doc__ = """AUX page from eso hiperspaces

SMF Info
--------
    Field: `R723CCHS`
    Record: `SMF72S3`
    Map: `R723SCS`

AUX page from eso hiperspaces
"""

sample_unknown : Final[Field] = Field(
    name='sample_unknown',
    origin='R723CUNK',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Unknown. Dispatchable unit or AS is waiting, but none of the above reasons apply. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CUNK`
    Record: `SMF72S3`
    Map: `R723SCS`

Unknown. Dispatchable unit or AS is waiting, but none of the above reasons apply. These samples are not included in R723CTOT
"""
sample_unknown.__doc__ = """Unknown. Dispatchable unit or AS is waiting, but none of the above reasons apply. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CUNK`
    Record: `SMF72S3`
    Map: `R723SCS`

Unknown. Dispatchable unit or AS is waiting, but none of the above reasons apply. These samples are not included in R723CTOT
"""

sample_idle : Final[Field] = Field(
    name='sample_idle',
    origin='R723CIDL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Idle. Work is in STIMER wait, TSO terminal wait, APPC wait, or is an initiator waiting for work. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CIDL`
    Record: `SMF72S3`
    Map: `R723SCS`

Idle. Work is in STIMER wait, TSO terminal wait, APPC wait, or is an initiator waiting for work. These samples are not included in R723CTOT
"""
sample_idle.__doc__ = """Idle. Work is in STIMER wait, TSO terminal wait, APPC wait, or is an initiator waiting for work. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CIDL`
    Record: `SMF72S3`
    Map: `R723SCS`

Idle. Work is in STIMER wait, TSO terminal wait, APPC wait, or is an initiator waiting for work. These samples are not included in R723CTOT
"""

sample_resource_group_capping : Final[Field] = Field(
    name='sample_resource_group_capping',
    origin='R723CPDE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Resource group capping count. Group maximum is being enforced for work in this service class. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CPDE`
    Record: `SMF72S3`
    Map: `R723SCS`

Resource group capping count. Group maximum is being enforced for work in this service class. These samples are not included in R723CTOT
"""
sample_resource_group_capping.__doc__ = """Resource group capping count. Group maximum is being enforced for work in this service class. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CPDE`
    Record: `SMF72S3`
    Map: `R723SCS`

Resource group capping count. Group maximum is being enforced for work in this service class. These samples are not included in R723CTOT
"""

sample_quiesce_count : Final[Field] = Field(
    name='sample_quiesce_count',
    origin='R723CPQU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Quiesce count. Some work in this service class has been reset via the RESET xxx, QUIESCE command. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CPQU`
    Record: `SMF72S3`
    Map: `R723SCS`

Quiesce count. Some work in this service class has been reset via the RESET xxx, QUIESCE command. These samples are not included in R723CTOT
"""
sample_quiesce_count.__doc__ = """Quiesce count. Some work in this service class has been reset via the RESET xxx, QUIESCE command. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CPQU`
    Record: `SMF72S3`
    Map: `R723SCS`

Quiesce count. Some work in this service class has been reset via the RESET xxx, QUIESCE command. These samples are not included in R723CTOT
"""

sample_adress_space_count : Final[Field] = Field(
    name='sample_adress_space_count',
    origin='R723CSAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Sampled address space count. Number of address spaces that contributed delay and using samples to this service class. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CSAC`
    Record: `SMF72S3`
    Map: `R723SCS`

Sampled address space count. Number of address spaces that contributed delay and using samples to this service class. These samples are not included in R723CTOT
"""
sample_adress_space_count.__doc__ = """Sampled address space count. Number of address spaces that contributed delay and using samples to this service class. These samples are not included in R723CTOT

SMF Info
--------
    Field: `R723CSAC`
    Record: `SMF72S3`
    Map: `R723SCS`

Sampled address space count. Number of address spaces that contributed delay and using samples to this service class. These samples are not included in R723CTOT
"""

r723csrs : Final[Field] = Field(
    name='r723csrs',
    origin='R723CSRS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total shared page residency time (1024 microseconds) (long floating point)

SMF Info
--------
    Field: `R723CSRS`
    Record: `SMF72S3`
    Map: `R723SCS`

Total shared page residency time (1024 microseconds) (long floating point)
"""
r723csrs.__doc__ = """Total shared page residency time (1024 microseconds) (long floating point)

SMF Info
--------
    Field: `R723CSRS`
    Record: `SMF72S3`
    Map: `R723SCS`

Total shared page residency time (1024 microseconds) (long floating point)
"""

r723cspa : Final[Field] = Field(
    name='r723cspa',
    origin='R723CSPA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total shared page-ins from auxiliary storage (long floating point)

SMF Info
--------
    Field: `R723CSPA`
    Record: `SMF72S3`
    Map: `R723SCS`

Total shared page-ins from auxiliary storage (long floating point)
"""
r723cspa.__doc__ = """Total shared page-ins from auxiliary storage (long floating point)

SMF Info
--------
    Field: `R723CSPA`
    Record: `SMF72S3`
    Map: `R723SCS`

Total shared page-ins from auxiliary storage (long floating point)
"""

r723cspe : Final[Field] = Field(
    name='r723cspe',
    origin='R723CSPE',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total shared page-ins from expanded storage (long floating point)

SMF Info
--------
    Field: `R723CSPE`
    Record: `SMF72S3`
    Map: `R723SCS`

Total shared page-ins from expanded storage (long floating point)
"""
r723cspe.__doc__ = """Total shared page-ins from expanded storage (long floating point)

SMF Info
--------
    Field: `R723CSPE`
    Record: `SMF72S3`
    Map: `R723SCS`

Total shared page-ins from expanded storage (long floating point)
"""

r723cict : Final[Field] = Field(
    name='r723cict',
    origin='R723CICT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total DASD I/O connect time in 128 microsecond units

SMF Info
--------
    Field: `R723CICT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD I/O connect time in 128 microsecond units
"""
r723cict.__doc__ = """Total DASD I/O connect time in 128 microsecond units

SMF Info
--------
    Field: `R723CICT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD I/O connect time in 128 microsecond units
"""

r723ciwt : Final[Field] = Field(
    name='r723ciwt',
    origin='R723CIWT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total DASD I/O wait time (queue time + pending time in 128 microsecond units)

SMF Info
--------
    Field: `R723CIWT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD I/O wait time (queue time + pending time in 128 microsecond units)
"""
r723ciwt.__doc__ = """Total DASD I/O wait time (queue time + pending time in 128 microsecond units)

SMF Info
--------
    Field: `R723CIWT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD I/O wait time (queue time + pending time in 128 microsecond units)
"""

r723cidt : Final[Field] = Field(
    name='r723cidt',
    origin='R723CIDT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total DASD I/O disconnect time in 128 microsecond units. Does not include IOS queue time.

SMF Info
--------
    Field: `R723CIDT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD I/O disconnect time in 128 microsecond units. Does not include IOS queue time.
"""
r723cidt.__doc__ = """Total DASD I/O disconnect time in 128 microsecond units. Does not include IOS queue time.

SMF Info
--------
    Field: `R723CIDT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD I/O disconnect time in 128 microsecond units. Does not include IOS queue time.
"""

sample_dasd_io_using : Final[Field] = Field(
    name='sample_dasd_io_using',
    origin='R723CIRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total DASD I/O count. This can be used with the above fields (R723CICT, R723CIWT, and R723CIDT) to determine the average DASD resp. time for the period. (long floating point)

SMF Info
--------
    Field: `R723CIRC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD I/O count. This can be used with the above fields (R723CICT, R723CIWT, and R723CIDT) to determine the average DASD resp. time for the period. (long floating point)
"""
sample_dasd_io_using.__doc__ = """Total DASD I/O count. This can be used with the above fields (R723CICT, R723CIWT, and R723CIDT) to determine the average DASD resp. time for the period. (long floating point)

SMF Info
--------
    Field: `R723CIRC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD I/O count. This can be used with the above fields (R723CICT, R723CIWT, and R723CIDT) to determine the average DASD resp. time for the period. (long floating point)
"""

sample_total_using : Final[Field] = Field(
    name='sample_total_using',
    origin='R723CTOU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Total usings. Velocity should be calculated as R723CTOU/ (R723CTOU+R723CTOT).

SMF Info
--------
    Field: `R723CTOU`
    Record: `SMF72S3`
    Map: `R723SCS`

Total usings. Velocity should be calculated as R723CTOU/ (R723CTOU+R723CTOT).
"""
sample_total_using.__doc__ = """Total usings. Velocity should be calculated as R723CTOU/ (R723CTOU+R723CTOT).

SMF Info
--------
    Field: `R723CTOU`
    Record: `SMF72S3`
    Map: `R723SCS`

Total usings. Velocity should be calculated as R723CTOU/ (R723CTOU+R723CTOT).
"""

sample_io_using : Final[Field] = Field(
    name='sample_io_using',
    origin='R723CIOU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Total I/O usings. These are included in R723CTOU. Only non paging DASD I/Os can contribute to I/O usings.

SMF Info
--------
    Field: `R723CIOU`
    Record: `SMF72S3`
    Map: `R723SCS`

Total I/O usings. These are included in R723CTOU. Only non paging DASD I/Os can contribute to I/O usings.
"""
sample_io_using.__doc__ = """Total I/O usings. These are included in R723CTOU. Only non paging DASD I/Os can contribute to I/O usings.

SMF Info
--------
    Field: `R723CIOU`
    Record: `SMF72S3`
    Map: `R723SCS`

Total I/O usings. These are included in R723CTOU. Only non paging DASD I/Os can contribute to I/O usings.
"""

sample_io_delay : Final[Field] = Field(
    name='sample_io_delay',
    origin='R723CIOD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""DASD I/O delay samples

SMF Info
--------
    Field: `R723CIOD`
    Record: `SMF72S3`
    Map: `R723SCS`

DASD I/O delay samples
"""
sample_io_delay.__doc__ = """DASD I/O delay samples

SMF Info
--------
    Field: `R723CIOD`
    Record: `SMF72S3`
    Map: `R723SCS`

DASD I/O delay samples
"""

sample_queue_delay : Final[Field] = Field(
    name='sample_queue_delay',
    origin='R723CQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Queue delay samples. Work is waiting for a server

SMF Info
--------
    Field: `R723CQ`
    Record: `SMF72S3`
    Map: `R723SCS`

Queue delay samples. Work is waiting for a server
"""
sample_queue_delay.__doc__ = """Queue delay samples. Work is waiting for a server

SMF Info
--------
    Field: `R723CQ`
    Record: `SMF72S3`
    Map: `R723SCS`

Queue delay samples. Work is waiting for a server
"""

sample_server_prv_paging_delay : Final[Field] = Field(
    name='sample_server_prv_paging_delay',
    origin='R723CSPV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Server private area paging delay samples

SMF Info
--------
    Field: `R723CSPV`
    Record: `SMF72S3`
    Map: `R723SCS`

Server private area paging delay samples
"""
sample_server_prv_paging_delay.__doc__ = """Server private area paging delay samples

SMF Info
--------
    Field: `R723CSPV`
    Record: `SMF72S3`
    Map: `R723SCS`

Server private area paging delay samples
"""

sample_server_vio_paging_delay : Final[Field] = Field(
    name='sample_server_vio_paging_delay',
    origin='R723CSVI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Server space VIO paging delay samples

SMF Info
--------
    Field: `R723CSVI`
    Record: `SMF72S3`
    Map: `R723SCS`

Server space VIO paging delay samples
"""
sample_server_vio_paging_delay.__doc__ = """Server space VIO paging delay samples

SMF Info
--------
    Field: `R723CSVI`
    Record: `SMF72S3`
    Map: `R723SCS`

Server space VIO paging delay samples
"""

sample_server_hsp_paging_delay : Final[Field] = Field(
    name='sample_server_hsp_paging_delay',
    origin='R723CSHS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Server hiperspace paging delay samples

SMF Info
--------
    Field: `R723CSHS`
    Record: `SMF72S3`
    Map: `R723SCS`

Server hiperspace paging delay samples
"""
sample_server_hsp_paging_delay.__doc__ = """Server hiperspace paging delay samples

SMF Info
--------
    Field: `R723CSHS`
    Record: `SMF72S3`
    Map: `R723SCS`

Server hiperspace paging delay samples
"""

sample_server_mpl_delay : Final[Field] = Field(
    name='sample_server_mpl_delay',
    origin='R723CSMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Server MPL delay samples

SMF Info
--------
    Field: `R723CSMP`
    Record: `SMF72S3`
    Map: `R723SCS`

Server MPL delay samples
"""
sample_server_mpl_delay.__doc__ = """Server MPL delay samples

SMF Info
--------
    Field: `R723CSMP`
    Record: `SMF72S3`
    Map: `R723SCS`

Server MPL delay samples
"""

sample_server_swapin_delay : Final[Field] = Field(
    name='sample_server_swapin_delay',
    origin='R723CSSW',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Server swap-in delay samples

SMF Info
--------
    Field: `R723CSSW`
    Record: `SMF72S3`
    Map: `R723SCS`

Server swap-in delay samples
"""
sample_server_swapin_delay.__doc__ = """Server swap-in delay samples

SMF Info
--------
    Field: `R723CSSW`
    Record: `SMF72S3`
    Map: `R723SCS`

Server swap-in delay samples
"""

r723cndi : Final[Field] = Field(
    name='r723cndi',
    origin='R723CNDI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Non DASD I/O using or delay samples

SMF Info
--------
    Field: `R723CNDI`
    Record: `SMF72S3`
    Map: `R723SCS`

Non DASD I/O using or delay samples
"""
r723cndi.__doc__ = """Non DASD I/O using or delay samples

SMF Info
--------
    Field: `R723CNDI`
    Record: `SMF72S3`
    Map: `R723SCS`

Non DASD I/O using or delay samples
"""

r723ctdq : Final[Field] = Field(
    name='r723ctdq',
    origin='R723CTDQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Total delay samples always including batch queue delay. For service classes that contain batch jobs that were not run in WLM managed initiators the batch queue delay samples are derived from the measured batch queue delay time. For service classes that contain jobs that ran in WLM managed initiators this value is the same as RCEATOTD. RCAETOTDQ can be used as a migration aid to determine what a batch service class period's velocity will be if its jobs are run in WLM managed initators

SMF Info
--------
    Field: `R723CTDQ`
    Record: `SMF72S3`
    Map: `R723SCS`

Total delay samples always including batch queue delay. For service classes that contain batch jobs that were not run in WLM managed initiators the batch queue delay samples are derived from the measured batch queue delay time. For service classes that contain jobs that ran in WLM managed initiators this value is the same as RCEATOTD. RCAETOTDQ can be used as a migration aid to determine what a batch service class period's velocity will be if its jobs are run in WLM managed initators
"""
r723ctdq.__doc__ = """Total delay samples always including batch queue delay. For service classes that contain batch jobs that were not run in WLM managed initiators the batch queue delay samples are derived from the measured batch queue delay time. For service classes that contain jobs that ran in WLM managed initiators this value is the same as RCEATOTD. RCAETOTDQ can be used as a migration aid to determine what a batch service class period's velocity will be if its jobs are run in WLM managed initators

SMF Info
--------
    Field: `R723CTDQ`
    Record: `SMF72S3`
    Map: `R723SCS`

Total delay samples always including batch queue delay. For service classes that contain batch jobs that were not run in WLM managed initiators the batch queue delay samples are derived from the measured batch queue delay time. For service classes that contain jobs that ran in WLM managed initiators this value is the same as RCEATOTD. RCAETOTDQ can be used as a migration aid to determine what a batch service class period's velocity will be if its jobs are run in WLM managed initators
"""

r723ctsa : Final[Field] = Field(
    name='r723ctsa',
    origin='R723CTSA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total execution samples. It is the sum of RCAETOTU, RCAETOTD, RCAEUNKN and RCAEIDLE. Also always includes I/O using/delay samples whether or not I/O samples are included in RCAETOTU or RCAETOTD, respectively. (Long floating point)

SMF Info
--------
    Field: `R723CTSA`
    Record: `SMF72S3`
    Map: `R723SCS`

Total execution samples. It is the sum of RCAETOTU, RCAETOTD, RCAEUNKN and RCAEIDLE. Also always includes I/O using/delay samples whether or not I/O samples are included in RCAETOTU or RCAETOTD, respectively. (Long floating point)
"""
r723ctsa.__doc__ = """Total execution samples. It is the sum of RCAETOTU, RCAETOTD, RCAEUNKN and RCAEIDLE. Also always includes I/O using/delay samples whether or not I/O samples are included in RCAETOTU or RCAETOTD, respectively. (Long floating point)

SMF Info
--------
    Field: `R723CTSA`
    Record: `SMF72S3`
    Map: `R723SCS`

Total execution samples. It is the sum of RCAETOTU, RCAETOTD, RCAEUNKN and RCAEIDLE. Also always includes I/O using/delay samples whether or not I/O samples are included in RCAETOTU or RCAETOTD, respectively. (Long floating point)
"""

r723ciot : Final[Field] = Field(
    name='r723ciot',
    origin='R723CIOT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total DASD IOS queue time in 128 microsecond units (long floating point)

SMF Info
--------
    Field: `R723CIOT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD IOS queue time in 128 microsecond units (long floating point)
"""
r723ciot.__doc__ = """Total DASD IOS queue time in 128 microsecond units (long floating point)

SMF Info
--------
    Field: `R723CIOT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total DASD IOS queue time in 128 microsecond units (long floating point)
"""

transaction_queue_delay_time : Final[Field] = Field(
    name='transaction_queue_delay_time',
    origin='R723CQDT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total queue delay time. For batch jobs this is the time jobs spent on the job queue while eligible to run on some system. It represents the time the jobs spent waiting for an initiator. For TSO users, this time can be a portion of the LOGON process. For APPC this is the time an APPC request spends on an APPC queue. (long floating point in 1024 micro second units)

SMF Info
--------
    Field: `R723CQDT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total queue delay time. For batch jobs this is the time jobs spent on the job queue while eligible to run on some system. It represents the time the jobs spent waiting for an initiator. For TSO users, this time can be a portion of the LOGON process. For APPC this is the time an APPC request spends on an APPC queue. (long floating point in 1024 micro second units)
"""
transaction_queue_delay_time.__doc__ = """Total queue delay time. For batch jobs this is the time jobs spent on the job queue while eligible to run on some system. It represents the time the jobs spent waiting for an initiator. For TSO users, this time can be a portion of the LOGON process. For APPC this is the time an APPC request spends on an APPC queue. (long floating point in 1024 micro second units)

SMF Info
--------
    Field: `R723CQDT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total queue delay time. For batch jobs this is the time jobs spent on the job queue while eligible to run on some system. It represents the time the jobs spent waiting for an initiator. For TSO users, this time can be a portion of the LOGON process. For APPC this is the time an APPC request spends on an APPC queue. (long floating point in 1024 micro second units)
"""

transaction_aff_delay_time : Final[Field] = Field(
    name='transaction_aff_delay_time',
    origin='R723CADT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total time batch jobs were ineligible to run because a resource the job had affinity to was unavailable. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)

SMF Info
--------
    Field: `R723CADT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs were ineligible to run because a resource the job had affinity to was unavailable. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)
"""
transaction_aff_delay_time.__doc__ = """Total time batch jobs were ineligible to run because a resource the job had affinity to was unavailable. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)

SMF Info
--------
    Field: `R723CADT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs were ineligible to run because a resource the job had affinity to was unavailable. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)
"""

transaction_jcl_time : Final[Field] = Field(
    name='transaction_jcl_time',
    origin='R723CCVT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total time batch jobs spent in JCL conversion. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)

SMF Info
--------
    Field: `R723CCVT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs spent in JCL conversion. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)
"""
transaction_jcl_time.__doc__ = """Total time batch jobs spent in JCL conversion. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)

SMF Info
--------
    Field: `R723CCVT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs spent in JCL conversion. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)
"""

transaction_inel_delay_time : Final[Field] = Field(
    name='transaction_inel_delay_time',
    origin='R723CIQT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)

SMF Info
--------
    Field: `R723CIQT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)
"""
transaction_inel_delay_time.__doc__ = """Total time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)

SMF Info
--------
    Field: `R723CIQT`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Only applies to batch work. Zero for other work types. (long floating point in 1024 microsecond units)
"""

total_ind_enclave_active_time : Final[Field] = Field(
    name='total_ind_enclave_active_time',
    origin='R723CIEA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Independent enclave total transaction active time (in 1024 microsecond units) for enclaves that originated on this system.

SMF Info
--------
    Field: `R723CIEA`
    Record: `SMF72S3`
    Map: `R723SCS`

Independent enclave total transaction active time (in 1024 microsecond units) for enclaves that originated on this system.
"""
total_ind_enclave_active_time.__doc__ = """Independent enclave total transaction active time (in 1024 microsecond units) for enclaves that originated on this system.

SMF Info
--------
    Field: `R723CIEA`
    Record: `SMF72S3`
    Map: `R723SCS`

Independent enclave total transaction active time (in 1024 microsecond units) for enclaves that originated on this system.
"""

r723cxea : Final[Field] = Field(
    name='r723cxea',
    origin='R723CXEA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Exported enclave total transaction active time (in 1024 microsecond units).

SMF Info
--------
    Field: `R723CXEA`
    Record: `SMF72S3`
    Map: `R723SCS`

Exported enclave total transaction active time (in 1024 microsecond units).
"""
r723cxea.__doc__ = """Exported enclave total transaction active time (in 1024 microsecond units).

SMF Info
--------
    Field: `R723CXEA`
    Record: `SMF72S3`
    Map: `R723SCS`

Exported enclave total transaction active time (in 1024 microsecond units).
"""

r723cfea : Final[Field] = Field(
    name='r723cfea',
    origin='R723CFEA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Foreign enclave total transaction active time (in 1024 microsecond units).

SMF Info
--------
    Field: `R723CFEA`
    Record: `SMF72S3`
    Map: `R723SCS`

Foreign enclave total transaction active time (in 1024 microsecond units).
"""
r723cfea.__doc__ = """Foreign enclave total transaction active time (in 1024 microsecond units).

SMF Info
--------
    Field: `R723CFEA`
    Record: `SMF72S3`
    Map: `R723SCS`

Foreign enclave total transaction active time (in 1024 microsecond units).
"""

sample_ap_crypto_using : Final[Field] = Field(
    name='sample_ap_crypto_using',
    origin='R723APU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""AP crypto using samples. A TCB was found executing on a Cryptographic Assist Processor

SMF Info
--------
    Field: `R723APU`
    Record: `SMF72S3`
    Map: `R723SCS`

AP crypto using samples. A TCB was found executing on a Cryptographic Assist Processor
"""
sample_ap_crypto_using.__doc__ = """AP crypto using samples. A TCB was found executing on a Cryptographic Assist Processor

SMF Info
--------
    Field: `R723APU`
    Record: `SMF72S3`
    Map: `R723SCS`

AP crypto using samples. A TCB was found executing on a Cryptographic Assist Processor
"""

sample_ap_crypto_delay : Final[Field] = Field(
    name='sample_ap_crypto_delay',
    origin='R723APD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""AP crypto delay samples. A TCB was found waiting for a Cryptographic Assist Processor

SMF Info
--------
    Field: `R723APD`
    Record: `SMF72S3`
    Map: `R723SCS`

AP crypto delay samples. A TCB was found waiting for a Cryptographic Assist Processor
"""
sample_ap_crypto_delay.__doc__ = """AP crypto delay samples. A TCB was found waiting for a Cryptographic Assist Processor

SMF Info
--------
    Field: `R723APD`
    Record: `SMF72S3`
    Map: `R723SCS`

AP crypto delay samples. A TCB was found waiting for a Cryptographic Assist Processor
"""

sample_feature_queue_delay : Final[Field] = Field(
    name='sample_feature_queue_delay',
    origin='R723FQD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Feature queue delay samples. A TCB was found waiting on a processor feature queue associated with a CPU. Subset of R723CCDE. Note, R723CCUS includes feature queue using samples.

SMF Info
--------
    Field: `R723FQD`
    Record: `SMF72S3`
    Map: `R723SCS`

Feature queue delay samples. A TCB was found waiting on a processor feature queue associated with a CPU. Subset of R723CCDE. Note, R723CCUS includes feature queue using samples.
"""
sample_feature_queue_delay.__doc__ = """Feature queue delay samples. A TCB was found waiting on a processor feature queue associated with a CPU. Subset of R723CCDE. Note, R723CCUS includes feature queue using samples.

SMF Info
--------
    Field: `R723FQD`
    Record: `SMF72S3`
    Map: `R723SCS`

Feature queue delay samples. A TCB was found waiting on a processor feature queue associated with a CPU. Subset of R723CCDE. Note, R723CCUS includes feature queue using samples.
"""

r723plsc : Final[Field] = Field(
    name='r723plsc',
    origin='R723PLSC',
    type=FieldType.STRING,
    record=record,
    record_map=R723SCS,
)
"""Service class that last contributed to this report class period during this interval. Blank if this is a service class period

SMF Info
--------
    Field: `R723PLSC`
    Record: `SMF72S3`
    Map: `R723SCS`

Service class that last contributed to this report class period during this interval. Blank if this is a service class period
"""
r723plsc.__doc__ = """Service class that last contributed to this report class period during this interval. Blank if this is a service class period

SMF Info
--------
    Field: `R723PLSC`
    Record: `SMF72S3`
    Map: `R723SCS`

Service class that last contributed to this report class period during this interval. Blank if this is a service class period
"""

r723rcod : Final[Field] = Field(
    name='r723rcod',
    origin='R723RCOD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Contention delay samples count or work waiting for resources as reported to WLM by a resource manager

SMF Info
--------
    Field: `R723RCOD`
    Record: `SMF72S3`
    Map: `R723SCS`

Contention delay samples count or work waiting for resources as reported to WLM by a resource manager
"""
r723rcod.__doc__ = """Contention delay samples count or work waiting for resources as reported to WLM by a resource manager

SMF Info
--------
    Field: `R723RCOD`
    Record: `SMF72S3`
    Map: `R723SCS`

Contention delay samples count or work waiting for resources as reported to WLM by a resource manager
"""

r723rcou : Final[Field] = Field(
    name='r723rcou',
    origin='R723RCOU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Contention using samples count of work holding resources as reported to WLM by a resource manager

SMF Info
--------
    Field: `R723RCOU`
    Record: `SMF72S3`
    Map: `R723SCS`

Contention using samples count of work holding resources as reported to WLM by a resource manager
"""
r723rcou.__doc__ = """Contention using samples count of work holding resources as reported to WLM by a resource manager

SMF Info
--------
    Field: `R723RCOU`
    Record: `SMF72S3`
    Map: `R723SCS`

Contention using samples count of work holding resources as reported to WLM by a resource manager
"""

r723ectc : Final[Field] = Field(
    name='r723ectc',
    origin='R723ECTC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""CPU time consumed while dispatching priority was temporarily raised by enqueue management because the work held a resource that other work needed (in 1024 microsecond units)

SMF Info
--------
    Field: `R723ECTC`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority was temporarily raised by enqueue management because the work held a resource that other work needed (in 1024 microsecond units)
"""
r723ectc.__doc__ = """CPU time consumed while dispatching priority was temporarily raised by enqueue management because the work held a resource that other work needed (in 1024 microsecond units)

SMF Info
--------
    Field: `R723ECTC`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority was temporarily raised by enqueue management because the work held a resource that other work needed (in 1024 microsecond units)
"""

sample_zaap_using : Final[Field] = Field(
    name='sample_zaap_using',
    origin='R723IFAU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""zAAP using samples

SMF Info
--------
    Field: `R723IFAU`
    Record: `SMF72S3`
    Map: `R723SCS`

zAAP using samples
"""
sample_zaap_using.__doc__ = """zAAP using samples

SMF Info
--------
    Field: `R723IFAU`
    Record: `SMF72S3`
    Map: `R723SCS`

zAAP using samples
"""

r723ifcu : Final[Field] = Field(
    name='r723ifcu',
    origin='R723IFCU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""zAAP on CP using samples. These are included in R723CCUS

SMF Info
--------
    Field: `R723IFCU`
    Record: `SMF72S3`
    Map: `R723SCS`

zAAP on CP using samples. These are included in R723CCUS
"""
r723ifcu.__doc__ = """zAAP on CP using samples. These are included in R723CCUS

SMF Info
--------
    Field: `R723IFCU`
    Record: `SMF72S3`
    Map: `R723SCS`

zAAP on CP using samples. These are included in R723CCUS
"""

sample_zaap_delay : Final[Field] = Field(
    name='sample_zaap_delay',
    origin='R723IFAD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""zAAP delay samples

SMF Info
--------
    Field: `R723IFAD`
    Record: `SMF72S3`
    Map: `R723SCS`

zAAP delay samples
"""
sample_zaap_delay.__doc__ = """zAAP delay samples

SMF Info
--------
    Field: `R723IFAD`
    Record: `SMF72S3`
    Map: `R723SCS`

zAAP delay samples
"""

sample_ziip_using : Final[Field] = Field(
    name='sample_ziip_using',
    origin='R723SUPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""zIIP using samples

SMF Info
--------
    Field: `R723SUPU`
    Record: `SMF72S3`
    Map: `R723SCS`

zIIP using samples
"""
sample_ziip_using.__doc__ = """zIIP using samples

SMF Info
--------
    Field: `R723SUPU`
    Record: `SMF72S3`
    Map: `R723SCS`

zIIP using samples
"""

r723sucu : Final[Field] = Field(
    name='r723sucu',
    origin='R723SUCU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""zIIP on CP using samples. These are included in R723CCUS

SMF Info
--------
    Field: `R723SUCU`
    Record: `SMF72S3`
    Map: `R723SCS`

zIIP on CP using samples. These are included in R723CCUS
"""
r723sucu.__doc__ = """zIIP on CP using samples. These are included in R723CCUS

SMF Info
--------
    Field: `R723SUCU`
    Record: `SMF72S3`
    Map: `R723SCS`

zIIP on CP using samples. These are included in R723CCUS
"""

sample_ziip_delay : Final[Field] = Field(
    name='sample_ziip_delay',
    origin='R723SUPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""zIIP delay samples

SMF Info
--------
    Field: `R723SUPD`
    Record: `SMF72S3`
    Map: `R723SCS`

zIIP delay samples
"""
sample_ziip_delay.__doc__ = """zIIP delay samples

SMF Info
--------
    Field: `R723SUPD`
    Record: `SMF72S3`
    Map: `R723SCS`

zIIP delay samples
"""

total_service_units_ziip : Final[Field] = Field(
    name='total_service_units_ziip',
    origin='R723CSUP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total service units on zIIPs. Multiply with R723NFFS and divide by 256 to calculate the CP equivalent value.

SMF Info
--------
    Field: `R723CSUP`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units on zIIPs. Multiply with R723NFFS and divide by 256 to calculate the CP equivalent value.
"""
total_service_units_ziip.__doc__ = """Total service units on zIIPs. Multiply with R723NFFS and divide by 256 to calculate the CP equivalent value.

SMF Info
--------
    Field: `R723CSUP`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units on zIIPs. Multiply with R723NFFS and divide by 256 to calculate the CP equivalent value.
"""

total_service_units_ziip_on_cp : Final[Field] = Field(
    name='total_service_units_ziip_on_cp',
    origin='R723CSUC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total service units on CPs spent by zIIP eligible work

SMF Info
--------
    Field: `R723CSUC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units on CPs spent by zIIP eligible work
"""
total_service_units_ziip_on_cp.__doc__ = """Total service units on CPs spent by zIIP eligible work

SMF Info
--------
    Field: `R723CSUC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units on CPs spent by zIIP eligible work
"""

total_service_units_zaap : Final[Field] = Field(
    name='total_service_units_zaap',
    origin='R723CIFA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total service units on zAAPs. Multiply with R723NFFI and divide by 256 to calculate the CP equivalent value.

SMF Info
--------
    Field: `R723CIFA`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units on zAAPs. Multiply with R723NFFI and divide by 256 to calculate the CP equivalent value.
"""
total_service_units_zaap.__doc__ = """Total service units on zAAPs. Multiply with R723NFFI and divide by 256 to calculate the CP equivalent value.

SMF Info
--------
    Field: `R723CIFA`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units on zAAPs. Multiply with R723NFFI and divide by 256 to calculate the CP equivalent value.
"""

total_service_units_zaap_on_cp : Final[Field] = Field(
    name='total_service_units_zaap_on_cp',
    origin='R723CIFC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total service units on CPs spent by zAAP eligible work

SMF Info
--------
    Field: `R723CIFC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units on CPs spent by zAAP eligible work
"""
total_service_units_zaap_on_cp.__doc__ = """Total service units on CPs spent by zAAP eligible work

SMF Info
--------
    Field: `R723CIFC`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units on CPs spent by zAAP eligible work
"""

r723tpdp : Final[Field] = Field(
    name='r723tpdp',
    origin='R723TPDP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""CPU time consumed while dispatching priority of work with low importance was temporarily raised to help blocked workloads (in 1024 microsecond units)

SMF Info
--------
    Field: `R723TPDP`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority of work with low importance was temporarily raised to help blocked workloads (in 1024 microsecond units)
"""
r723tpdp.__doc__ = """CPU time consumed while dispatching priority of work with low importance was temporarily raised to help blocked workloads (in 1024 microsecond units)

SMF Info
--------
    Field: `R723TPDP`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority of work with low importance was temporarily raised to help blocked workloads (in 1024 microsecond units)
"""

r723cpdp : Final[Field] = Field(
    name='r723cpdp',
    origin='R723CPDP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""CPU time consumed while dispatching priority was temporarily raised by chronic resource contention management because the work held a resource that other work needed (in 1024 microsecond units)

SMF Info
--------
    Field: `R723CPDP`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority was temporarily raised by chronic resource contention management because the work held a resource that other work needed (in 1024 microsecond units)
"""
r723cpdp.__doc__ = """CPU time consumed while dispatching priority was temporarily raised by chronic resource contention management because the work held a resource that other work needed (in 1024 microsecond units)

SMF Info
--------
    Field: `R723CPDP`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority was temporarily raised by chronic resource contention management because the work held a resource that other work needed (in 1024 microsecond units)
"""

r723lpdp : Final[Field] = Field(
    name='r723lpdp',
    origin='R723LPDP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""CPU time consumed while dispatching priority was temporarily raised to shorten the lock hold time of a local suspend lock (in 1024 microsecond units).

SMF Info
--------
    Field: `R723LPDP`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority was temporarily raised to shorten the lock hold time of a local suspend lock (in 1024 microsecond units).
"""
r723lpdp.__doc__ = """CPU time consumed while dispatching priority was temporarily raised to shorten the lock hold time of a local suspend lock (in 1024 microsecond units).

SMF Info
--------
    Field: `R723LPDP`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority was temporarily raised to shorten the lock hold time of a local suspend lock (in 1024 microsecond units).
"""

r723spdp : Final[Field] = Field(
    name='r723spdp',
    origin='R723SPDP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""CPU time consumed while dispatching priority was temporarily raised by z/OS Supervisor to a higher DP than the WLM assigned DP (in 1024 microsecond units)

SMF Info
--------
    Field: `R723SPDP`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority was temporarily raised by z/OS Supervisor to a higher DP than the WLM assigned DP (in 1024 microsecond units)
"""
r723spdp.__doc__ = """CPU time consumed while dispatching priority was temporarily raised by z/OS Supervisor to a higher DP than the WLM assigned DP (in 1024 microsecond units)

SMF Info
--------
    Field: `R723SPDP`
    Record: `SMF72S3`
    Map: `R723SCS`

CPU time consumed while dispatching priority was temporarily raised by z/OS Supervisor to a higher DP than the WLM assigned DP (in 1024 microsecond units)
"""

r723rtdm : Final[Field] = Field(
    name='r723rtdm',
    origin='R723RTDM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Midpoint of all response times that were collected in the response time distribution buckets in milliseconds. For response time goals, the mid point is always the response time goal. For execution velocity goals, it is the average of all response times that were collected in the response time distribution buckets. The field equals zero for discretionary goals.

SMF Info
--------
    Field: `R723RTDM`
    Record: `SMF72S3`
    Map: `R723SCS`

Midpoint of all response times that were collected in the response time distribution buckets in milliseconds. For response time goals, the mid point is always the response time goal. For execution velocity goals, it is the average of all response times that were collected in the response time distribution buckets. The field equals zero for discretionary goals.
"""
r723rtdm.__doc__ = """Midpoint of all response times that were collected in the response time distribution buckets in milliseconds. For response time goals, the mid point is always the response time goal. For execution velocity goals, it is the average of all response times that were collected in the response time distribution buckets. The field equals zero for discretionary goals.

SMF Info
--------
    Field: `R723RTDM`
    Record: `SMF72S3`
    Map: `R723SCS`

Midpoint of all response times that were collected in the response time distribution buckets in milliseconds. For response time goals, the mid point is always the response time goal. For execution velocity goals, it is the average of all response times that were collected in the response time distribution buckets. The field equals zero for discretionary goals.
"""

r723rtdc : Final[Field] = Field(
    name='r723rtdc',
    origin='R723RTDC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Number of midpoint changes that occurred during interval

SMF Info
--------
    Field: `R723RTDC`
    Record: `SMF72S3`
    Map: `R723SCS`

Number of midpoint changes that occurred during interval
"""
r723rtdc.__doc__ = """Number of midpoint changes that occurred during interval

SMF Info
--------
    Field: `R723RTDC`
    Record: `SMF72S3`
    Map: `R723SCS`

Number of midpoint changes that occurred during interval
"""

r723rtdt : Final[Field] = Field(
    name='r723rtdt',
    origin='R723RTDT',
    type=FieldType.DATETIME,
    record=record,
    record_map=R723SCS,
)
"""Timestamp showing the last time when a midpoint change occurred. The midpoint is kept in R723RTDM.

SMF Info
--------
    Field: `R723RTDT`
    Record: `SMF72S3`
    Map: `R723SCS`

Timestamp showing the last time when a midpoint change occurred. The midpoint is kept in R723RTDM.
"""
r723rtdt.__doc__ = """Timestamp showing the last time when a midpoint change occurred. The midpoint is kept in R723RTDM.

SMF Info
--------
    Field: `R723RTDT`
    Record: `SMF72S3`
    Map: `R723SCS`

Timestamp showing the last time when a midpoint change occurred. The midpoint is kept in R723RTDM.
"""

r723tsucp : Final[Field] = Field(
    name='r723tsucp',
    origin='R723TSUCP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total service units consumed by transactions, executed on on general purpose processors.

SMF Info
--------
    Field: `R723TSUCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units consumed by transactions, executed on on general purpose processors.
"""
r723tsucp.__doc__ = """Total service units consumed by transactions, executed on on general purpose processors.

SMF Info
--------
    Field: `R723TSUCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units consumed by transactions, executed on on general purpose processors.
"""

r723tsusp : Final[Field] = Field(
    name='r723tsusp',
    origin='R723TSUSP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total service units consumed by transactions, executed on on specialty processors.

SMF Info
--------
    Field: `R723TSUSP`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units consumed by transactions, executed on on specialty processors.
"""
r723tsusp.__doc__ = """Total service units consumed by transactions, executed on on specialty processors.

SMF Info
--------
    Field: `R723TSUSP`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units consumed by transactions, executed on on specialty processors.
"""

r723tsuocp : Final[Field] = Field(
    name='r723tsuocp',
    origin='R723TSUOCP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total service units consumed by transactions, eligible to run on specialty processors, but executed on general purpose processors.

SMF Info
--------
    Field: `R723TSUOCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units consumed by transactions, eligible to run on specialty processors, but executed on general purpose processors.
"""
r723tsuocp.__doc__ = """Total service units consumed by transactions, eligible to run on specialty processors, but executed on general purpose processors.

SMF Info
--------
    Field: `R723TSUOCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Total service units consumed by transactions, eligible to run on specialty processors, but executed on general purpose processors.
"""

r723msucp : Final[Field] = Field(
    name='r723msucp',
    origin='R723MSUCP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Service units consumed by transactions, classified with reporting attribute MOBILE, executed on general purpose processors.

SMF Info
--------
    Field: `R723MSUCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute MOBILE, executed on general purpose processors.
"""
r723msucp.__doc__ = """Service units consumed by transactions, classified with reporting attribute MOBILE, executed on general purpose processors.

SMF Info
--------
    Field: `R723MSUCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute MOBILE, executed on general purpose processors.
"""

r723msusp : Final[Field] = Field(
    name='r723msusp',
    origin='R723MSUSP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Service units consumed by transactions, classified with reporting attribute MOBILE, executed on specialty processors.

SMF Info
--------
    Field: `R723MSUSP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute MOBILE, executed on specialty processors.
"""
r723msusp.__doc__ = """Service units consumed by transactions, classified with reporting attribute MOBILE, executed on specialty processors.

SMF Info
--------
    Field: `R723MSUSP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute MOBILE, executed on specialty processors.
"""

r723msuocp : Final[Field] = Field(
    name='r723msuocp',
    origin='R723MSUOCP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Service units consumed by transactions, classified with reporting attribute MOBILE, eligible to run on specialty processors, but executed on general purpose processors.

SMF Info
--------
    Field: `R723MSUOCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute MOBILE, eligible to run on specialty processors, but executed on general purpose processors.
"""
r723msuocp.__doc__ = """Service units consumed by transactions, classified with reporting attribute MOBILE, eligible to run on specialty processors, but executed on general purpose processors.

SMF Info
--------
    Field: `R723MSUOCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute MOBILE, eligible to run on specialty processors, but executed on general purpose processors.
"""

r723asucp : Final[Field] = Field(
    name='r723asucp',
    origin='R723ASUCP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Service units consumed by transactions, classified with reporting attribute CATEGORYA, executed on general purpose processors.

SMF Info
--------
    Field: `R723ASUCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYA, executed on general purpose processors.
"""
r723asucp.__doc__ = """Service units consumed by transactions, classified with reporting attribute CATEGORYA, executed on general purpose processors.

SMF Info
--------
    Field: `R723ASUCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYA, executed on general purpose processors.
"""

r723asusp : Final[Field] = Field(
    name='r723asusp',
    origin='R723ASUSP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Service units consumed by transactions, classified with reporting attribute CATEGORYA, executed on specialty processors.

SMF Info
--------
    Field: `R723ASUSP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYA, executed on specialty processors.
"""
r723asusp.__doc__ = """Service units consumed by transactions, classified with reporting attribute CATEGORYA, executed on specialty processors.

SMF Info
--------
    Field: `R723ASUSP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYA, executed on specialty processors.
"""

r723asuocp : Final[Field] = Field(
    name='r723asuocp',
    origin='R723ASUOCP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Service units consumed by transactions, classified with reporting attribute CATEGORYA, eligible to run on specialty processors, but executed on general purpose processors.

SMF Info
--------
    Field: `R723ASUOCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYA, eligible to run on specialty processors, but executed on general purpose processors.
"""
r723asuocp.__doc__ = """Service units consumed by transactions, classified with reporting attribute CATEGORYA, eligible to run on specialty processors, but executed on general purpose processors.

SMF Info
--------
    Field: `R723ASUOCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYA, eligible to run on specialty processors, but executed on general purpose processors.
"""

r723bsucp : Final[Field] = Field(
    name='r723bsucp',
    origin='R723BSUCP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Service units consumed by transactions, classified with reporting attribute CATEGORYB, executed on general purpose processors.

SMF Info
--------
    Field: `R723BSUCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYB, executed on general purpose processors.
"""
r723bsucp.__doc__ = """Service units consumed by transactions, classified with reporting attribute CATEGORYB, executed on general purpose processors.

SMF Info
--------
    Field: `R723BSUCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYB, executed on general purpose processors.
"""

r723bsusp : Final[Field] = Field(
    name='r723bsusp',
    origin='R723BSUSP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Service units consumed by transactions, classified with reporting attribute CATEGORYB, executed on specialty processors.

SMF Info
--------
    Field: `R723BSUSP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYB, executed on specialty processors.
"""
r723bsusp.__doc__ = """Service units consumed by transactions, classified with reporting attribute CATEGORYB, executed on specialty processors.

SMF Info
--------
    Field: `R723BSUSP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYB, executed on specialty processors.
"""

r723bsuocp : Final[Field] = Field(
    name='r723bsuocp',
    origin='R723BSUOCP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Service units consumed by transactions, classified with reporting attribute CATEGORYB, eligible to run on specialty processors, but executed on general purpose processors.

SMF Info
--------
    Field: `R723BSUOCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYB, eligible to run on specialty processors, but executed on general purpose processors.
"""
r723bsuocp.__doc__ = """Service units consumed by transactions, classified with reporting attribute CATEGORYB, eligible to run on specialty processors, but executed on general purpose processors.

SMF Info
--------
    Field: `R723BSUOCP`
    Record: `SMF72S3`
    Map: `R723SCS`

Service units consumed by transactions, classified with reporting attribute CATEGORYB, eligible to run on specialty processors, but executed on general purpose processors.
"""

r723ctetx : Final[Field] = Field(
    name='r723ctetx',
    origin='R723CTETX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total transaction elapsed time. Same as R723CTET, but in microseconds.

SMF Info
--------
    Field: `R723CTETX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction elapsed time. Same as R723CTET, but in microseconds.
"""
r723ctetx.__doc__ = """Total transaction elapsed time. Same as R723CTET, but in microseconds.

SMF Info
--------
    Field: `R723CTETX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction elapsed time. Same as R723CTET, but in microseconds.
"""

r723cxetx : Final[Field] = Field(
    name='r723cxetx',
    origin='R723CXETX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total transaction execution time. Same as R723CXET, but in microseconds.

SMF Info
--------
    Field: `R723CXETX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction execution time. Same as R723CXET, but in microseconds.
"""
r723cxetx.__doc__ = """Total transaction execution time. Same as R723CXET, but in microseconds.

SMF Info
--------
    Field: `R723CXETX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total transaction execution time. Same as R723CXET, but in microseconds.
"""

r723cetsx : Final[Field] = Field(
    name='r723cetsx',
    origin='R723CETSX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Sum of transaction elapsed times squared. Same as R723CETS, but in microseconds.

SMF Info
--------
    Field: `R723CETSX`
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of transaction elapsed times squared. Same as R723CETS, but in microseconds.
"""
r723cetsx.__doc__ = """Sum of transaction elapsed times squared. Same as R723CETS, but in microseconds.

SMF Info
--------
    Field: `R723CETSX`
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of transaction elapsed times squared. Same as R723CETS, but in microseconds.
"""

r723cqdtx : Final[Field] = Field(
    name='r723cqdtx',
    origin='R723CQDTX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total queue delay time. Same as R723CQDT, but in microseconds.

SMF Info
--------
    Field: `R723CQDTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total queue delay time. Same as R723CQDT, but in microseconds.
"""
r723cqdtx.__doc__ = """Total queue delay time. Same as R723CQDT, but in microseconds.

SMF Info
--------
    Field: `R723CQDTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total queue delay time. Same as R723CQDT, but in microseconds.
"""

r723cadtx : Final[Field] = Field(
    name='r723cadtx',
    origin='R723CADTX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total time batch jobs were ineligible to run because a resource the job had affinity to was unavailable. Same as R723CADT, but in microseconds.

SMF Info
--------
    Field: `R723CADTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs were ineligible to run because a resource the job had affinity to was unavailable. Same as R723CADT, but in microseconds.
"""
r723cadtx.__doc__ = """Total time batch jobs were ineligible to run because a resource the job had affinity to was unavailable. Same as R723CADT, but in microseconds.

SMF Info
--------
    Field: `R723CADTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs were ineligible to run because a resource the job had affinity to was unavailable. Same as R723CADT, but in microseconds.
"""

r723ccvtx : Final[Field] = Field(
    name='r723ccvtx',
    origin='R723CCVTX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total time batch jobs spent in JCL conversion. Same as R723CCVT, but in microseconds.

SMF Info
--------
    Field: `R723CCVTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs spent in JCL conversion. Same as R723CCVT, but in microseconds.
"""
r723ccvtx.__doc__ = """Total time batch jobs spent in JCL conversion. Same as R723CCVT, but in microseconds.

SMF Info
--------
    Field: `R723CCVTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs spent in JCL conversion. Same as R723CCVT, but in microseconds.
"""

r723ciqtx : Final[Field] = Field(
    name='r723ciqtx',
    origin='R723CIQTX',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Same as R723CIQT, but in microseconds.

SMF Info
--------
    Field: `R723CIQTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Same as R723CIQT, but in microseconds.
"""
r723ciqtx.__doc__ = """Total time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Same as R723CIQT, but in microseconds.

SMF Info
--------
    Field: `R723CIQTX`
    Record: `SMF72S3`
    Map: `R723SCS`

Total time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Same as R723CIQT, but in microseconds.
"""

r723enctrxnum : Final[Field] = Field(
    name='r723enctrxnum',
    origin='R723ENCTRXNUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Number of single subsystem transactions processed within enclaves.

SMF Info
--------
    Field: `R723ENCTRXNUM`
    Record: `SMF72S3`
    Map: `R723SCS`

Number of single subsystem transactions processed within enclaves.
"""
r723enctrxnum.__doc__ = """Number of single subsystem transactions processed within enclaves.

SMF Info
--------
    Field: `R723ENCTRXNUM`
    Record: `SMF72S3`
    Map: `R723SCS`

Number of single subsystem transactions processed within enclaves.
"""

r723enctrxcalls : Final[Field] = Field(
    name='r723enctrxcalls',
    origin='R723ENCTRXCALLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SCS,
)
"""Number of times transaction data has been reported by subsystem work managers when deleting an enclave.

SMF Info
--------
    Field: `R723ENCTRXCALLS`
    Record: `SMF72S3`
    Map: `R723SCS`

Number of times transaction data has been reported by subsystem work managers when deleting an enclave.
"""
r723enctrxcalls.__doc__ = """Number of times transaction data has been reported by subsystem work managers when deleting an enclave.

SMF Info
--------
    Field: `R723ENCTRXCALLS`
    Record: `SMF72S3`
    Map: `R723SCS`

Number of times transaction data has been reported by subsystem work managers when deleting an enclave.
"""

r723enctrxet : Final[Field] = Field(
    name='r723enctrxet',
    origin='R723ENCTRXET',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Total execution time in microseconds for number of subsystem transactions in R723ENCTRXNUM. (format: float)

SMF Info
--------
    Field: `R723ENCTRXET`
    Record: `SMF72S3`
    Map: `R723SCS`

Total execution time in microseconds for number of subsystem transactions in R723ENCTRXNUM. (format: float)
"""
r723enctrxet.__doc__ = """Total execution time in microseconds for number of subsystem transactions in R723ENCTRXNUM. (format: float)

SMF Info
--------
    Field: `R723ENCTRXET`
    Record: `SMF72S3`
    Map: `R723SCS`

Total execution time in microseconds for number of subsystem transactions in R723ENCTRXNUM. (format: float)
"""

r723enctrxets : Final[Field] = Field(
    name='r723enctrxets',
    origin='R723ENCTRXETS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R723SCS,
)
"""Sum of squared execution times in microseconds for number of subsystem transactions in R723ENCTRXNUM. (format: float)

SMF Info
--------
    Field: `R723ENCTRXETS`
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of squared execution times in microseconds for number of subsystem transactions in R723ENCTRXNUM. (format: float)
"""
r723enctrxets.__doc__ = """Sum of squared execution times in microseconds for number of subsystem transactions in R723ENCTRXNUM. (format: float)

SMF Info
--------
    Field: `R723ENCTRXETS`
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of squared execution times in microseconds for number of subsystem transactions in R723ENCTRXNUM. (format: float)
"""

class_goal_type : Final[Field] = Field(
    name='class_goal_type',
    origin=None,
    post='core.flagmap',
    post_param={'default': 'Unknown', 'map': {4: 'System', 3: 'Discretionary', 2: 'Execution Velocity', 1: 'Average Resp. Time', 0: 'Percentile Resp. Time'}},
    virtual=True,
    ref=class_goal_flags,
    record=record,
    record_map=R723SCS,
)
"""Class goal type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'Unknown', 'map': {4: 'System', 3: 'Discretionary', 2: 'Execution Velocity', 1: 'Average Resp. Time', 0: 'Percentile Resp. Time'}}
"""
class_goal_type.__doc__ = """Class goal type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_flags`(`R723CRGF`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'Unknown', 'map': {4: 'System', 3: 'Discretionary', 2: 'Execution Velocity', 1: 'Average Resp. Time', 0: 'Percentile Resp. Time'}}
"""

utilization_total : Final[Field] = Field(
    name='utilization_total',
    origin=None,
    post="core.inline",
    post_param=__utilization_total_inline_post,
    virtual=True,
    ref=[total_cpu_service_units, total_srb_service_units, total_rct_time, total_io_interrupt_time, total_hspace_service_time, cpu_service_coefficient_adjusted, srb_service_coefficient_adjusted, interval_in_milliseconds],
    record=record,
    record_map=R723SCS,
)
"""Percentage application utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_cpu_service_units`(`R723CCPU`), `total_srb_service_units`(`R723CSRB`), `total_rct_time`(`R723CRCT`), `total_io_interrupt_time`(`R723CIIT`), `total_hspace_service_time`(`R723CHST`), `cpu_service_coefficient_adjusted`(Virtual), `srb_service_coefficient_adjusted`(Virtual), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Percentage application utilization, summing CPU, SRB, RCT, I/O interrupt and hyperspace times.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    tcbtime_insec = df.total_cpu_service_units * 1e10 / df.cpu_service_coefficient_adjusted
    srbtime_insec = df.total_srb_service_units * 1e10 / df.srb_service_coefficient_adjusted
    total_time = tcbtime_insec.fillna(0) + srbtime_insec.fillna(0) + df.total_rct_time.dt.total_seconds() * 1e3 + df.total_io_interrupt_time.dt.total_seconds() * 1e3 + df.total_hspace_service_time.dt.total_seconds() * 1e3
    return total_time / df.interval_in_milliseconds

"""
utilization_total.__doc__ = """Percentage application utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_cpu_service_units`(`R723CCPU`), `total_srb_service_units`(`R723CSRB`), `total_rct_time`(`R723CRCT`), `total_io_interrupt_time`(`R723CIIT`), `total_hspace_service_time`(`R723CHST`), `cpu_service_coefficient_adjusted`(Virtual), `srb_service_coefficient_adjusted`(Virtual), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Percentage application utilization, summing CPU, SRB, RCT, I/O interrupt and hyperspace times.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    tcbtime_insec = df.total_cpu_service_units * 1e10 / df.cpu_service_coefficient_adjusted
    srbtime_insec = df.total_srb_service_units * 1e10 / df.srb_service_coefficient_adjusted
    total_time = tcbtime_insec.fillna(0) + srbtime_insec.fillna(0) + df.total_rct_time.dt.total_seconds() * 1e3 + df.total_io_interrupt_time.dt.total_seconds() * 1e3 + df.total_hspace_service_time.dt.total_seconds() * 1e3
    return total_time / df.interval_in_milliseconds

"""

transaction_total_swapped_in : Final[Field] = Field(
    name='transaction_total_swapped_in',
    origin=None,
    post="core.inline",
    post_param=__transaction_total_swapped_in_inline_post,
    virtual=True,
    ref=[total_page_residency_time, interval_in_milliseconds],
    record=record,
    record_map=R723SCS,
)
"""Total frames of all swapped-in transactions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_page_residency_time`(`R723CPRS`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Total (Central Storage + Expanded Storage) frames of all swapped-in transactions

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_page_residency_time / df.interval_in_milliseconds * 1024 / 1000

"""
transaction_total_swapped_in.__doc__ = """Total frames of all swapped-in transactions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_page_residency_time`(`R723CPRS`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Total (Central Storage + Expanded Storage) frames of all swapped-in transactions

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_page_residency_time / df.interval_in_milliseconds * 1024 / 1000

"""

transaction_average_active : Final[Field] = Field(
    name='transaction_average_active',
    origin=None,
    post="core.inline",
    post_param=__transaction_average_active_inline_post,
    virtual=True,
    ref=[total_transaction_time, interval_in_milliseconds],
    record=record,
    record_map=R723SCS,
)
"""Average number of active transactions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_transaction_time`(`R723CTAT`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_transaction_time / df.interval_in_milliseconds * 1024 / 1000

"""
transaction_average_active.__doc__ = """Average number of active transactions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_transaction_time`(`R723CTAT`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_transaction_time / df.interval_in_milliseconds * 1024 / 1000

"""

transaction_total_per_second : Final[Field] = Field(
    name='transaction_total_per_second',
    origin=None,
    post="core.inline",
    post_param=__transaction_total_per_second_inline_post,
    virtual=True,
    ref=[transaction_total_count, interval_in_milliseconds],
    record=record,
    record_map=R723SCS,
)
"""Average transaction completions per second for this interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_total_count`(`R723CRCP`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Average number of transactions completed per second for this interval.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.transaction_total_count * 1000 / df.interval_in_milliseconds

"""
transaction_total_per_second.__doc__ = """Average transaction completions per second for this interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_total_count`(`R723CRCP`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Average number of transactions completed per second for this interval.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.transaction_total_count * 1000 / df.interval_in_milliseconds

"""

transaction_executed_per_second : Final[Field] = Field(
    name='transaction_executed_per_second',
    origin=None,
    post="core.inline",
    post_param=__transaction_executed_per_second_inline_post,
    virtual=True,
    ref=[transaction_executed_count, interval_in_milliseconds],
    record=record,
    record_map=R723SCS,
)
"""Average transaction executions per second for this interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_executed_count`(`R723CNCP`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Average number of transactions completed their execution phase per second for this  interval.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.transaction_executed_count * 1000 / df.interval_in_milliseconds

"""
transaction_executed_per_second.__doc__ = """Average transaction executions per second for this interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_executed_count`(`R723CNCP`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Average number of transactions completed their execution phase per second for this  interval.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.transaction_executed_count * 1000 / df.interval_in_milliseconds

"""

transaction_response_time_mean : Final[Field] = Field(
    name='transaction_response_time_mean',
    origin=None,
    post="core.inline",
    post_param=__transaction_response_time_mean_inline_post,
    virtual=True,
    ref=[transaction_total_count, transaction_total_time],
    record=record,
    record_map=R723SCS,
)
"""Mean of the transaction RT times(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_total_count`(`R723CRCP`), `transaction_total_time`(`R723CTET`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_response_time_mean = df.transaction_total_time / df.transaction_total_count
    return transaction_response_time_mean.fillna(0)

"""
transaction_response_time_mean.__doc__ = """Mean of the transaction RT times(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_total_count`(`R723CRCP`), `transaction_total_time`(`R723CTET`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_response_time_mean = df.transaction_total_time / df.transaction_total_count
    return transaction_response_time_mean.fillna(0)

"""

transaction_response_time_variance : Final[Field] = Field(
    name='transaction_response_time_variance',
    origin=None,
    post="core.inline",
    post_param=__transaction_response_time_variance_inline_post,
    virtual=True,
    ref=[transaction_total_count, transaction_total_time, transaction_squared_sum_time],
    record=record,
    record_map=R723SCS,
)
"""Variance of the transaction RT times(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_total_count`(`R723CRCP`), `transaction_total_time`(`R723CTET`), `transaction_squared_sum_time`(`R723CETS`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    numerator = df.transaction_squared_sum_time - (df.transaction_total_time ** 2 / df.transaction_total_count)
    transaction_response_time_variance = numerator / (df.transaction_total_count - 1) * 1024 / 1e9
    valid_filter = (df.transaction_total_count > 5) & (transaction_response_time_variance < 1) & transaction_response_time_variance.notna()
    return transaction_response_time_variance.where(valid_filter, 0)

"""
transaction_response_time_variance.__doc__ = """Variance of the transaction RT times(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_total_count`(`R723CRCP`), `transaction_total_time`(`R723CTET`), `transaction_squared_sum_time`(`R723CETS`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    numerator = df.transaction_squared_sum_time - (df.transaction_total_time ** 2 / df.transaction_total_count)
    transaction_response_time_variance = numerator / (df.transaction_total_count - 1) * 1024 / 1e9
    valid_filter = (df.transaction_total_count > 5) & (transaction_response_time_variance < 1) & transaction_response_time_variance.notna()
    return transaction_response_time_variance.where(valid_filter, 0)

"""

transaction_execution_time_mean : Final[Field] = Field(
    name='transaction_execution_time_mean',
    origin=None,
    post="core.inline",
    post_param=__transaction_execution_time_mean_inline_post,
    virtual=True,
    ref=[transaction_execution_time, transaction_total_count],
    record=record,
    record_map=R723SCS,
)
"""Mean transaction execution time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_execution_time`(`R723CXET`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_execution_time_mean = df.transaction_execution_time / df.transaction_total_count * 1024 / 1e6
    return transaction_execution_time_mean.fillna(0)

"""
transaction_execution_time_mean.__doc__ = """Mean transaction execution time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_execution_time`(`R723CXET`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_execution_time_mean = df.transaction_execution_time / df.transaction_total_count * 1024 / 1e6
    return transaction_execution_time_mean.fillna(0)

"""

execution_velocity : Final[Field] = Field(
    name='execution_velocity',
    origin=None,
    post="core.inline",
    post_param=__execution_velocity_inline_post,
    virtual=True,
    ref=[sample_total_using, sample_total_delay],
    record=record,
    record_map=R723SCS,
)
"""Execution velocity of service class.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_total_using`(`R723CTOU`), `sample_total_delay`(`R723CTOT`)
    Record: `SMF72S3`
    Map: `R723SCS`

Execution velocity of the service class period, for one timepoint.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    execution_velocity = df.sample_total_using * 100 / (df.sample_total_using + df.sample_total_delay)
    return execution_velocity.fillna(0)

"""
execution_velocity.__doc__ = """Execution velocity of service class.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_total_using`(`R723CTOU`), `sample_total_delay`(`R723CTOT`)
    Record: `SMF72S3`
    Map: `R723SCS`

Execution velocity of the service class period, for one timepoint.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    execution_velocity = df.sample_total_using * 100 / (df.sample_total_using + df.sample_total_delay)
    return execution_velocity.fillna(0)

"""

sample_storage_delay : Final[Field] = Field(
    name='sample_storage_delay',
    origin=None,
    post='core.math.sum',
    post_param=None,
    virtual=True,
    ref=[sample_aux_private_delay, sample_aux_common_delay, sample_aux_cross_mem_delay, sample_aux_vio_delay, sample_aux_std_hspace_delay, sample_aux_eso_hspace_delay],
    record=record,
    record_map=R723SCS,
)
"""Storage delay samples(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_aux_private_delay`(`R723CAPR`), `sample_aux_common_delay`(`R723CACO`), `sample_aux_cross_mem_delay`(`R723CAXM`), `sample_aux_vio_delay`(`R723CVIO`), `sample_aux_std_hspace_delay`(`R723CHSP`), `sample_aux_eso_hspace_delay`(`R723CCHS`)
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of all storage related delay samples (R723CAPR, R723CACO, R723CAXM, R723CVIO, R723CHSP, R723CCHS).

Post Processing (`core.math.sum`)
---------------
No post-processing parameter defined
"""
sample_storage_delay.__doc__ = """Storage delay samples(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_aux_private_delay`(`R723CAPR`), `sample_aux_common_delay`(`R723CACO`), `sample_aux_cross_mem_delay`(`R723CAXM`), `sample_aux_vio_delay`(`R723CVIO`), `sample_aux_std_hspace_delay`(`R723CHSP`), `sample_aux_eso_hspace_delay`(`R723CCHS`)
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of all storage related delay samples (R723CAPR, R723CACO, R723CAXM, R723CVIO, R723CHSP, R723CCHS).

Post Processing (`core.math.sum`)
---------------
No post-processing parameter defined
"""

transaction_address_space_percentage : Final[Field] = Field(
    name='transaction_address_space_percentage',
    origin=None,
    post="core.inline",
    post_param=__transaction_address_space_percentage_inline_post,
    virtual=True,
    ref=[sample_adress_space_count, wlm_sampling_count],
    record=record,
    record_map=R723SCS,
)
"""Percentage of transaction address spaces(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_adress_space_count`(`R723CSAC`), `wlm_sampling_count`(`R723MTV#`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.sample_adress_space_count / df.wlm_sampling_count

"""
transaction_address_space_percentage.__doc__ = """Percentage of transaction address spaces(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_adress_space_count`(`R723CSAC`), `wlm_sampling_count`(`R723MTV#`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.sample_adress_space_count / df.wlm_sampling_count

"""

sample_server_delay : Final[Field] = Field(
    name='sample_server_delay',
    origin=None,
    post='core.math.sum',
    post_param=None,
    virtual=True,
    ref=[sample_server_prv_paging_delay, sample_server_vio_paging_delay, sample_server_hsp_paging_delay, sample_server_mpl_delay, sample_server_swapin_delay],
    record=record,
    record_map=R723SCS,
)
"""Server delay samples(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_server_prv_paging_delay`(`R723CSPV`), `sample_server_vio_paging_delay`(`R723CSVI`), `sample_server_hsp_paging_delay`(`R723CSHS`), `sample_server_mpl_delay`(`R723CSMP`), `sample_server_swapin_delay`(`R723CSSW`)
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of all server related delay samples (R723CSPV, R723CSVI, R723CSHS, R723CSMP, R723CSSW).

Post Processing (`core.math.sum`)
---------------
No post-processing parameter defined
"""
sample_server_delay.__doc__ = """Server delay samples(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_server_prv_paging_delay`(`R723CSPV`), `sample_server_vio_paging_delay`(`R723CSVI`), `sample_server_hsp_paging_delay`(`R723CSHS`), `sample_server_mpl_delay`(`R723CSMP`), `sample_server_swapin_delay`(`R723CSSW`)
    Record: `SMF72S3`
    Map: `R723SCS`

Sum of all server related delay samples (R723CSPV, R723CSVI, R723CSHS, R723CSMP, R723CSSW).

Post Processing (`core.math.sum`)
---------------
No post-processing parameter defined
"""

transaction_queue_delay_time_mean : Final[Field] = Field(
    name='transaction_queue_delay_time_mean',
    origin=None,
    post="core.inline",
    post_param=__transaction_queue_delay_time_mean_inline_post,
    virtual=True,
    ref=[transaction_queue_delay_time, transaction_total_count],
    record=record,
    record_map=R723SCS,
)
"""Mean transaction queue delay time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_queue_delay_time`(`R723CQDT`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_queue_delay_time_mean = df.transaction_queue_delay_time / df.transaction_total_count * 1024 / 1e6
    return transaction_queue_delay_time_mean.fillna(0)

"""
transaction_queue_delay_time_mean.__doc__ = """Mean transaction queue delay time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_queue_delay_time`(`R723CQDT`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_queue_delay_time_mean = df.transaction_queue_delay_time / df.transaction_total_count * 1024 / 1e6
    return transaction_queue_delay_time_mean.fillna(0)

"""

transaction_aff_delay_time_mean : Final[Field] = Field(
    name='transaction_aff_delay_time_mean',
    origin=None,
    post="core.inline",
    post_param=__transaction_aff_delay_time_mean_inline_post,
    virtual=True,
    ref=[transaction_aff_delay_time, transaction_total_count],
    record=record,
    record_map=R723SCS,
)
"""Mean transaction affinity delay time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_aff_delay_time`(`R723CADT`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Mean transaction delay time for which batch jobs were ineligible to run because a resource  the job had affinity to was unavailable. Only applies to batch work. Zero for other work  types

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_aff_delay_time_mean = df.transaction_aff_delay_time / df.transaction_total_count * 1024 / 1e6
    return transaction_aff_delay_time_mean.fillna(0)

"""
transaction_aff_delay_time_mean.__doc__ = """Mean transaction affinity delay time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_aff_delay_time`(`R723CADT`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Mean transaction delay time for which batch jobs were ineligible to run because a resource  the job had affinity to was unavailable. Only applies to batch work. Zero for other work  types

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_aff_delay_time_mean = df.transaction_aff_delay_time / df.transaction_total_count * 1024 / 1e6
    return transaction_aff_delay_time_mean.fillna(0)

"""

transaction_jcl_time_mean : Final[Field] = Field(
    name='transaction_jcl_time_mean',
    origin=None,
    post="core.inline",
    post_param=__transaction_jcl_time_mean_inline_post,
    virtual=True,
    ref=[transaction_jcl_time, transaction_total_count],
    record=record,
    record_map=R723SCS,
)
"""Mean transaction JCL conversion time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_jcl_time`(`R723CCVT`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_jcl_time_mean = df.transaction_jcl_time / df.transaction_total_count * 1024 / 1e6
    return transaction_jcl_time_mean.fillna(0)

"""
transaction_jcl_time_mean.__doc__ = """Mean transaction JCL conversion time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_jcl_time`(`R723CCVT`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_jcl_time_mean = df.transaction_jcl_time / df.transaction_total_count * 1024 / 1e6
    return transaction_jcl_time_mean.fillna(0)

"""

transaction_inel_delay_time_mean : Final[Field] = Field(
    name='transaction_inel_delay_time_mean',
    origin=None,
    post="core.inline",
    post_param=__transaction_inel_delay_time_mean_inline_post,
    virtual=True,
    ref=[transaction_inel_delay_time, transaction_total_count],
    record=record,
    record_map=R723SCS,
)
"""Mean transaction not-affinity-related delay time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_inel_delay_time`(`R723CIQT`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Mean transaction not-affinity-related delay time, i.e. time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Only applies to batch work. Zero for other work types.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_inel_delay_time_mean = df.transaction_inel_delay_time / df.transaction_total_count * 1024 / 1e6
    return transaction_inel_delay_time_mean.fillna(0)

"""
transaction_inel_delay_time_mean.__doc__ = """Mean transaction not-affinity-related delay time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `transaction_inel_delay_time`(`R723CIQT`), `transaction_total_count`(`R723CRCP`)
    Record: `SMF72S3`
    Map: `R723SCS`

Mean transaction not-affinity-related delay time, i.e. time batch jobs spend on job queue (after JCL conversion) while ineligible to run on any system for reasons other than resource affinities. Only applies to batch work. Zero for other work types.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    transaction_inel_delay_time_mean = df.transaction_inel_delay_time / df.transaction_total_count * 1024 / 1e6
    return transaction_inel_delay_time_mean.fillna(0)

"""

transaction_enclave_average : Final[Field] = Field(
    name='transaction_enclave_average',
    origin=None,
    post="core.inline",
    post_param=__transaction_enclave_average_inline_post,
    virtual=True,
    ref=[total_ind_enclave_active_time, interval_in_milliseconds],
    record=record,
    record_map=R723SCS,
)
"""Average number of independent enclaves during the interval (contained in TRANSAVG)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_ind_enclave_active_time`(`R723CIEA`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_ind_enclave_active_time / df.interval_in_milliseconds * 1024 / 1000

"""
transaction_enclave_average.__doc__ = """Average number of independent enclaves during the interval (contained in TRANSAVG)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_ind_enclave_active_time`(`R723CIEA`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_ind_enclave_active_time / df.interval_in_milliseconds * 1024 / 1000

"""

sample_crypto_using : Final[Field] = Field(
    name='sample_crypto_using',
    origin=None,
    post='core.math.sum',
    post_param=None,
    virtual=True,
    ref=sample_ap_crypto_using,
    record=record,
    record_map=R723SCS,
)
"""Total crypto using samples.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_ap_crypto_using`(`R723APU`)
    Record: `SMF72S3`
    Map: `R723SCS`

Total crypto using samples, summing R723CAMU and R723APU.

Post Processing (`core.math.sum`)
---------------
No post-processing parameter defined
"""
sample_crypto_using.__doc__ = """Total crypto using samples.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_ap_crypto_using`(`R723APU`)
    Record: `SMF72S3`
    Map: `R723SCS`

Total crypto using samples, summing R723CAMU and R723APU.

Post Processing (`core.math.sum`)
---------------
No post-processing parameter defined
"""

sample_crypto_delay : Final[Field] = Field(
    name='sample_crypto_delay',
    origin=None,
    post='core.math.sum',
    post_param=None,
    virtual=True,
    ref=[sample_ap_crypto_delay, sample_feature_queue_delay],
    record=record,
    record_map=R723SCS,
)
"""Total crypto delay samples.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_ap_crypto_delay`(`R723APD`), `sample_feature_queue_delay`(`R723FQD`)
    Record: `SMF72S3`
    Map: `R723SCS`

Total crypto delay samples, summing R723FQD, and R723APD.

Post Processing (`core.math.sum`)
---------------
No post-processing parameter defined
"""
sample_crypto_delay.__doc__ = """Total crypto delay samples.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sample_ap_crypto_delay`(`R723APD`), `sample_feature_queue_delay`(`R723FQD`)
    Record: `SMF72S3`
    Map: `R723SCS`

Total crypto delay samples, summing R723FQD, and R723APD.

Post Processing (`core.math.sum`)
---------------
No post-processing parameter defined
"""

utilization_zaap : Final[Field] = Field(
    name='utilization_zaap',
    origin=None,
    post="core.inline",
    post_param=__utilization_zaap_inline_post,
    virtual=True,
    ref=[total_service_units_zaap, normalization_factor_zaap, interval_in_milliseconds],
    record=record,
    record_map=R723SCS,
)
"""Percentage zaap utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_service_units_zaap`(`R723CIFA`), `normalization_factor_zaap`(`R723NFFI`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Percentage zaap utilization, normalized with R723NFFI

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_service_units_zaap * df.normalization_factor_zaap / 256 / df.interval_in_milliseconds

"""
utilization_zaap.__doc__ = """Percentage zaap utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_service_units_zaap`(`R723CIFA`), `normalization_factor_zaap`(`R723NFFI`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Percentage zaap utilization, normalized with R723NFFI

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_service_units_zaap * df.normalization_factor_zaap / 256 / df.interval_in_milliseconds

"""

utilization_zaap_on_cp : Final[Field] = Field(
    name='utilization_zaap_on_cp',
    origin=None,
    post="core.inline",
    post_param=__utilization_zaap_on_cp_inline_post,
    virtual=True,
    ref=[total_service_units_zaap_on_cp, interval_in_milliseconds],
    record=record,
    record_map=R723SCS,
)
"""Percentage CP utilization of zAAP eligible workload.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_service_units_zaap_on_cp`(`R723CIFC`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_service_units_zaap_on_cp / df.interval_in_milliseconds

"""
utilization_zaap_on_cp.__doc__ = """Percentage CP utilization of zAAP eligible workload.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_service_units_zaap_on_cp`(`R723CIFC`), `interval_in_milliseconds`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.total_service_units_zaap_on_cp / df.interval_in_milliseconds

"""

utilization_ziip : Final[Field] = Field(
    name='utilization_ziip',
    origin=None,
    post="core.inline",
    post_param=__utilization_ziip_inline_post,
    virtual=True,
    ref=[total_service_units_ziip, normalization_factor_ziip, interval_in_milliseconds, cpu_service_coefficient_adjusted],
    record=record,
    record_map=R723SCS,
)
"""Percentage ziip utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_service_units_ziip`(`R723CSUP`), `normalization_factor_ziip`(`R723NFFS`), `interval_in_milliseconds`(Virtual), `cpu_service_coefficient_adjusted`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Percentage ziip utilization, normalized with R723NFFS

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    utilization_ziip = df.total_service_units_ziip * df.normalization_factor_ziip * 1e4 / 256 / df.cpu_service_coefficient_adjusted
    return utilization_ziip.fillna(0) * 1e6 / df.interval_in_milliseconds

"""
utilization_ziip.__doc__ = """Percentage ziip utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_service_units_ziip`(`R723CSUP`), `normalization_factor_ziip`(`R723NFFS`), `interval_in_milliseconds`(Virtual), `cpu_service_coefficient_adjusted`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Percentage ziip utilization, normalized with R723NFFS

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    utilization_ziip = df.total_service_units_ziip * df.normalization_factor_ziip * 1e4 / 256 / df.cpu_service_coefficient_adjusted
    return utilization_ziip.fillna(0) * 1e6 / df.interval_in_milliseconds

"""

utilization_ziip_on_cp : Final[Field] = Field(
    name='utilization_ziip_on_cp',
    origin=None,
    post="core.inline",
    post_param=__utilization_ziip_on_cp_inline_post,
    virtual=True,
    ref=[total_service_units_ziip_on_cp, interval_in_milliseconds, cpu_service_coefficient_adjusted],
    record=record,
    record_map=R723SCS,
)
"""Percentage CP utilization of zIIP eligible workload.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_service_units_ziip_on_cp`(`R723CSUC`), `interval_in_milliseconds`(Virtual), `cpu_service_coefficient_adjusted`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    utilization_ziip_on_cp = df.total_service_units_ziip_on_cp * 1e4 / df.cpu_service_coefficient_adjusted
    return utilization_ziip_on_cp.fillna(0) * 1e6 / df.interval_in_milliseconds

"""
utilization_ziip_on_cp.__doc__ = """Percentage CP utilization of zIIP eligible workload.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `total_service_units_ziip_on_cp`(`R723CSUC`), `interval_in_milliseconds`(Virtual), `cpu_service_coefficient_adjusted`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    utilization_ziip_on_cp = df.total_service_units_ziip_on_cp * 1e4 / df.cpu_service_coefficient_adjusted
    return utilization_ziip_on_cp.fillna(0) * 1e6 / df.interval_in_milliseconds

"""

r723rtyp : Final[Field] = Field(
    name='r723rtyp',
    origin='R723RTYP',
    type=FieldType.STRING,
    record=record,
    record_map=R723WRS,
)
"""Subsystem type, as used in the classification rules specified in the WLM administrative application. The subsystem's documentation should explain the meaning that the product attributes to the various states

SMF Info
--------
    Field: `R723RTYP`
    Record: `SMF72S3`
    Map: `R723WRS`

Subsystem type, as used in the classification rules specified in the WLM administrative application. The subsystem's documentation should explain the meaning that the product attributes to the various states
"""
r723rtyp.__doc__ = """Subsystem type, as used in the classification rules specified in the WLM administrative application. The subsystem's documentation should explain the meaning that the product attributes to the various states

SMF Info
--------
    Field: `R723RTYP`
    Record: `SMF72S3`
    Map: `R723WRS`

Subsystem type, as used in the classification rules specified in the WLM administrative application. The subsystem's documentation should explain the meaning that the product attributes to the various states
"""

r723rflg : Final[Field] = Field(
    name='r723rflg',
    origin='R723RFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R723WRS,
)
"""Work/Resource manager flags

SMF Info
--------
    Field: `R723RFLG`
    Record: `SMF72S3`
    Map: `R723WRS`

Work/Resource manager flags
"""
r723rflg.__doc__ = """Work/Resource manager flags

SMF Info
--------
    Field: `R723RFLG`
    Record: `SMF72S3`
    Map: `R723WRS`

Work/Resource manager flags
"""

r723rdbe : Final[Field] = Field(
    name='r723rdbe',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r723rflg,
    record=record,
    record_map=R723WRS,
)
"""x'80' Represents states sampled in the begin-to-end phase of a transaction(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723rflg`(`R723RFLG`)
    Record: `SMF72S3`
    Map: `R723WRS`

x'80' Represents states sampled in the begin-to-end phase of a transaction

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r723rdbe.__doc__ = """x'80' Represents states sampled in the begin-to-end phase of a transaction(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723rflg`(`R723RFLG`)
    Record: `SMF72S3`
    Map: `R723WRS`

x'80' Represents states sampled in the begin-to-end phase of a transaction

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r723rexe : Final[Field] = Field(
    name='r723rexe',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r723rflg,
    record=record,
    record_map=R723WRS,
)
"""x'40' Represents states sampled in the execution phase of a transaction(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723rflg`(`R723RFLG`)
    Record: `SMF72S3`
    Map: `R723WRS`

x'40' Represents states sampled in the execution phase of a transaction

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r723rexe.__doc__ = """x'40' Represents states sampled in the execution phase of a transaction(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r723rflg`(`R723RFLG`)
    Record: `SMF72S3`
    Map: `R723WRS`

x'40' Represents states sampled in the execution phase of a transaction

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r723ress : Final[Field] = Field(
    name='r723ress',
    origin='R723RESS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of transaction states sampled in the work phase specified by R723RFLG

SMF Info
--------
    Field: `R723RESS`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of transaction states sampled in the work phase specified by R723RFLG
"""
r723ress.__doc__ = """Total number of transaction states sampled in the work phase specified by R723RFLG

SMF Info
--------
    Field: `R723RESS`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of transaction states sampled in the work phase specified by R723RFLG
"""

r723ract : Final[Field] = Field(
    name='r723ract',
    origin='R723RACT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of active state samples. Active indicates that there is a program executing on behalf of the work request, from the perspective of the work manager. This does not mean that the program is active from the base control program's perspective

SMF Info
--------
    Field: `R723RACT`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of active state samples. Active indicates that there is a program executing on behalf of the work request, from the perspective of the work manager. This does not mean that the program is active from the base control program's perspective
"""
r723ract.__doc__ = """Total number of active state samples. Active indicates that there is a program executing on behalf of the work request, from the perspective of the work manager. This does not mean that the program is active from the base control program's perspective

SMF Info
--------
    Field: `R723RACT`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of active state samples. Active indicates that there is a program executing on behalf of the work request, from the perspective of the work manager. This does not mean that the program is active from the base control program's perspective
"""

r723rrdy : Final[Field] = Field(
    name='r723rrdy',
    origin='R723RRDY',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of ready state samples. Ready indicates that there is a program ready to execute on behalf of the work request described by the monitoring environment, but the work manager has given priority to another work request

SMF Info
--------
    Field: `R723RRDY`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of ready state samples. Ready indicates that there is a program ready to execute on behalf of the work request described by the monitoring environment, but the work manager has given priority to another work request
"""
r723rrdy.__doc__ = """Total number of ready state samples. Ready indicates that there is a program ready to execute on behalf of the work request described by the monitoring environment, but the work manager has given priority to another work request

SMF Info
--------
    Field: `R723RRDY`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of ready state samples. Ready indicates that there is a program ready to execute on behalf of the work request described by the monitoring environment, but the work manager has given priority to another work request
"""

r723ridl : Final[Field] = Field(
    name='r723ridl',
    origin='R723RIDL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of idle state samples. Idle indicates that no work reques is available to the work manager that is allowed to run.

SMF Info
--------
    Field: `R723RIDL`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of idle state samples. Idle indicates that no work reques is available to the work manager that is allowed to run.
"""
r723ridl.__doc__ = """Total number of idle state samples. Idle indicates that no work reques is available to the work manager that is allowed to run.

SMF Info
--------
    Field: `R723RIDL`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of idle state samples. Idle indicates that no work reques is available to the work manager that is allowed to run.
"""

r723rwlo : Final[Field] = Field(
    name='r723rwlo',
    origin='R723RWLO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of waiting for lock state samples

SMF Info
--------
    Field: `R723RWLO`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for lock state samples
"""
r723rwlo.__doc__ = """Total number of waiting for lock state samples

SMF Info
--------
    Field: `R723RWLO`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for lock state samples
"""

r723rwio : Final[Field] = Field(
    name='r723rwio',
    origin='R723RWIO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of waiting for I/O state samples. Waiting for I/O indicates that the work manager is waiting for an activity related to an I/O request. This may be an actual I/O operation or some other function associated with the I/O request

SMF Info
--------
    Field: `R723RWIO`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for I/O state samples. Waiting for I/O indicates that the work manager is waiting for an activity related to an I/O request. This may be an actual I/O operation or some other function associated with the I/O request
"""
r723rwio.__doc__ = """Total number of waiting for I/O state samples. Waiting for I/O indicates that the work manager is waiting for an activity related to an I/O request. This may be an actual I/O operation or some other function associated with the I/O request

SMF Info
--------
    Field: `R723RWIO`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for I/O state samples. Waiting for I/O indicates that the work manager is waiting for an activity related to an I/O request. This may be an actual I/O operation or some other function associated with the I/O request
"""

r723rwco : Final[Field] = Field(
    name='r723rwco',
    origin='R723RWCO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of waiting for conversation state samples. Waiting for conversation may have been used in conjunction with the WLM service IWMMSWCH to identify where the recipient of the conversation is located. In this case, only the switched state will be recorded.

SMF Info
--------
    Field: `R723RWCO`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for conversation state samples. Waiting for conversation may have been used in conjunction with the WLM service IWMMSWCH to identify where the recipient of the conversation is located. In this case, only the switched state will be recorded.
"""
r723rwco.__doc__ = """Total number of waiting for conversation state samples. Waiting for conversation may have been used in conjunction with the WLM service IWMMSWCH to identify where the recipient of the conversation is located. In this case, only the switched state will be recorded.

SMF Info
--------
    Field: `R723RWCO`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for conversation state samples. Waiting for conversation may have been used in conjunction with the WLM service IWMMSWCH to identify where the recipient of the conversation is located. In this case, only the switched state will be recorded.
"""

r723rwds : Final[Field] = Field(
    name='r723rwds',
    origin='R723RWDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of waiting for distributed request state samples. Waiting for distributed request indicates a high level that some function or data must be routed prior to resumption of the work request. This is to be contrasted with waiting for conversation, which is a low level view of the precise resource that is needed. A distributed request could involve waiting on a conversation as part of its processing

SMF Info
--------
    Field: `R723RWDS`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for distributed request state samples. Waiting for distributed request indicates a high level that some function or data must be routed prior to resumption of the work request. This is to be contrasted with waiting for conversation, which is a low level view of the precise resource that is needed. A distributed request could involve waiting on a conversation as part of its processing
"""
r723rwds.__doc__ = """Total number of waiting for distributed request state samples. Waiting for distributed request indicates a high level that some function or data must be routed prior to resumption of the work request. This is to be contrasted with waiting for conversation, which is a low level view of the precise resource that is needed. A distributed request could involve waiting on a conversation as part of its processing

SMF Info
--------
    Field: `R723RWDS`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for distributed request state samples. Waiting for distributed request indicates a high level that some function or data must be routed prior to resumption of the work request. This is to be contrasted with waiting for conversation, which is a low level view of the precise resource that is needed. A distributed request could involve waiting on a conversation as part of its processing
"""

r723rwsl : Final[Field] = Field(
    name='r723rwsl',
    origin='R723RWSL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Waiting for a session to be established locally, i.e. on the current MVS image

SMF Info
--------
    Field: `R723RWSL`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for a session to be established locally, i.e. on the current MVS image
"""
r723rwsl.__doc__ = """Waiting for a session to be established locally, i.e. on the current MVS image

SMF Info
--------
    Field: `R723RWSL`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for a session to be established locally, i.e. on the current MVS image
"""

r723rwsn : Final[Field] = Field(
    name='r723rwsn',
    origin='R723RWSN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Waiting for a session to be established somewhere in the network

SMF Info
--------
    Field: `R723RWSN`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for a session to be established somewhere in the network
"""
r723rwsn.__doc__ = """Waiting for a session to be established somewhere in the network

SMF Info
--------
    Field: `R723RWSN`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for a session to be established somewhere in the network
"""

r723rwss : Final[Field] = Field(
    name='r723rwss',
    origin='R723RWSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Waiting for a session to be established somewhere in the sysplex

SMF Info
--------
    Field: `R723RWSS`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for a session to be established somewhere in the sysplex
"""
r723rwss.__doc__ = """Waiting for a session to be established somewhere in the sysplex

SMF Info
--------
    Field: `R723RWSS`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for a session to be established somewhere in the sysplex
"""

r723rwtm : Final[Field] = Field(
    name='r723rwtm',
    origin='R723RWTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Waiting for a timer

SMF Info
--------
    Field: `R723RWTM`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for a timer
"""
r723rwtm.__doc__ = """Waiting for a timer

SMF Info
--------
    Field: `R723RWTM`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for a timer
"""

r723rwo : Final[Field] = Field(
    name='r723rwo',
    origin='R723RWO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Waiting for another product

SMF Info
--------
    Field: `R723RWO`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for another product
"""
r723rwo.__doc__ = """Waiting for another product

SMF Info
--------
    Field: `R723RWO`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for another product
"""

r723rwms : Final[Field] = Field(
    name='r723rwms',
    origin='R723RWMS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Waiting for unidentified resource, possibly among another more specific category, but which may not be readily determined

SMF Info
--------
    Field: `R723RWMS`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for unidentified resource, possibly among another more specific category, but which may not be readily determined
"""
r723rwms.__doc__ = """Waiting for unidentified resource, possibly among another more specific category, but which may not be readily determined

SMF Info
--------
    Field: `R723RWMS`
    Record: `SMF72S3`
    Map: `R723WRS`

Waiting for unidentified resource, possibly among another more specific category, but which may not be readily determined
"""

r723rssl : Final[Field] = Field(
    name='r723rssl',
    origin='R723RSSL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""State representing transactions for which there are logical continuations on this MVS image. Subsystem work managers might set this state when they function ship a transaction to another component within the same MVS image

SMF Info
--------
    Field: `R723RSSL`
    Record: `SMF72S3`
    Map: `R723WRS`

State representing transactions for which there are logical continuations on this MVS image. Subsystem work managers might set this state when they function ship a transaction to another component within the same MVS image
"""
r723rssl.__doc__ = """State representing transactions for which there are logical continuations on this MVS image. Subsystem work managers might set this state when they function ship a transaction to another component within the same MVS image

SMF Info
--------
    Field: `R723RSSL`
    Record: `SMF72S3`
    Map: `R723WRS`

State representing transactions for which there are logical continuations on this MVS image. Subsystem work managers might set this state when they function ship a transaction to another component within the same MVS image
"""

r723rsss : Final[Field] = Field(
    name='r723rsss',
    origin='R723RSSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""State representing transactions for which there are logical continuations on another MVS image in the sysplex. Subsystem work managers might set this state when they function ship a transaction to another component on another MVS image within the sysplex

SMF Info
--------
    Field: `R723RSSS`
    Record: `SMF72S3`
    Map: `R723WRS`

State representing transactions for which there are logical continuations on another MVS image in the sysplex. Subsystem work managers might set this state when they function ship a transaction to another component on another MVS image within the sysplex
"""
r723rsss.__doc__ = """State representing transactions for which there are logical continuations on another MVS image in the sysplex. Subsystem work managers might set this state when they function ship a transaction to another component on another MVS image within the sysplex

SMF Info
--------
    Field: `R723RSSS`
    Record: `SMF72S3`
    Map: `R723WRS`

State representing transactions for which there are logical continuations on another MVS image in the sysplex. Subsystem work managers might set this state when they function ship a transaction to another component on another MVS image within the sysplex
"""

r723rssn : Final[Field] = Field(
    name='r723rssn',
    origin='R723RSSN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""State representing transactions for which there are logical continuations somewhere within the network. Subsystem work managers might set this state when they function ship a transaction to another component within the network

SMF Info
--------
    Field: `R723RSSN`
    Record: `SMF72S3`
    Map: `R723WRS`

State representing transactions for which there are logical continuations somewhere within the network. Subsystem work managers might set this state when they function ship a transaction to another component within the network
"""
r723rssn.__doc__ = """State representing transactions for which there are logical continuations somewhere within the network. Subsystem work managers might set this state when they function ship a transaction to another component within the network

SMF Info
--------
    Field: `R723RSSN`
    Record: `SMF72S3`
    Map: `R723WRS`

State representing transactions for which there are logical continuations somewhere within the network. Subsystem work managers might set this state when they function ship a transaction to another component within the network
"""

r723rwst : Final[Field] = Field(
    name='r723rwst',
    origin='R723RWST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of waiting for SSL thread samples

SMF Info
--------
    Field: `R723RWST`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for SSL thread samples
"""
r723rwst.__doc__ = """Total number of waiting for SSL thread samples

SMF Info
--------
    Field: `R723RWST`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for SSL thread samples
"""

r723rwrt : Final[Field] = Field(
    name='r723rwrt',
    origin='R723RWRT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of waiting for regular thread samples

SMF Info
--------
    Field: `R723RWRT`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for regular thread samples
"""
r723rwrt.__doc__ = """Total number of waiting for regular thread samples

SMF Info
--------
    Field: `R723RWRT`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for regular thread samples
"""

r723rwwr : Final[Field] = Field(
    name='r723rwwr',
    origin='R723RWWR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of waiting for work table registration samples

SMF Info
--------
    Field: `R723RWWR`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for work table registration samples
"""
r723rwwr.__doc__ = """Total number of waiting for work table registration samples

SMF Info
--------
    Field: `R723RWWR`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of waiting for work table registration samples
"""

r723rapp : Final[Field] = Field(
    name='r723rapp',
    origin='R723RAPP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of active application state samples

SMF Info
--------
    Field: `R723RAPP`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of active application state samples
"""
r723rapp.__doc__ = """Total number of active application state samples

SMF Info
--------
    Field: `R723RAPP`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of active application state samples
"""

r723rwnl : Final[Field] = Field(
    name='r723rwnl',
    origin='R723RWNL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Total number of state samples reflecting waiting for new latch

SMF Info
--------
    Field: `R723RWNL`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of state samples reflecting waiting for new latch
"""
r723rwnl.__doc__ = """Total number of state samples reflecting waiting for new latch

SMF Info
--------
    Field: `R723RWNL`
    Record: `SMF72S3`
    Map: `R723WRS`

Total number of state samples reflecting waiting for new latch
"""

r723rbpm : Final[Field] = Field(
    name='r723rbpm',
    origin='R723RBPM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Number of state samples representing buffer pool misses that resulted in I/O

SMF Info
--------
    Field: `R723RBPM`
    Record: `SMF72S3`
    Map: `R723WRS`

Number of state samples representing buffer pool misses that resulted in I/O
"""
r723rbpm.__doc__ = """Number of state samples representing buffer pool misses that resulted in I/O

SMF Info
--------
    Field: `R723RBPM`
    Record: `SMF72S3`
    Map: `R723WRS`

Number of state samples representing buffer pool misses that resulted in I/O
"""

r723rdnx : Final[Field] = Field(
    name='r723rdnx',
    origin='R723RDNX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Index into the resource delay names table

SMF Info
--------
    Field: `R723RDNX`
    Record: `SMF72S3`
    Map: `R723WRS`

Index into the resource delay names table
"""
r723rdnx.__doc__ = """Index into the resource delay names table

SMF Info
--------
    Field: `R723RDNX`
    Record: `SMF72S3`
    Map: `R723WRS`

Index into the resource delay names table
"""

r723rdnn : Final[Field] = Field(
    name='r723rdnn',
    origin='R723RDNN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723WRS,
)
"""Number of entries in the resource delay names table

SMF Info
--------
    Field: `R723RDNN`
    Record: `SMF72S3`
    Map: `R723WRS`

Number of entries in the resource delay names table
"""
r723rdnn.__doc__ = """Number of entries in the resource delay names table

SMF Info
--------
    Field: `R723RDNN`
    Record: `SMF72S3`
    Map: `R723WRS`

Number of entries in the resource delay names table
"""

r723scsn : Final[Field] = Field(
    name='r723scsn',
    origin='R723SCSN',
    type=FieldType.STRING,
    record=record,
    record_map=R723SSS,
)
"""Name of service class being served

SMF Info
--------
    Field: `R723SCSN`
    Record: `SMF72S3`
    Map: `R723SSS`

Name of service class being served
"""
r723scsn.__doc__ = """Name of service class being served

SMF Info
--------
    Field: `R723SCSN`
    Record: `SMF72S3`
    Map: `R723SSS`

Name of service class being served
"""

r723scscount : Final[Field] = Field(
    name='r723scscount',
    origin='R723SCS#',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723SSS,
)
"""Number of times an AS running with service class R723MCNM served service class R723SCSN

SMF Info
--------
    Field: `R723SCS#`
    Record: `SMF72S3`
    Map: `R723SSS`

Number of times an AS running with service class R723MCNM served service class R723SCSN
"""
r723scscount.__doc__ = """Number of times an AS running with service class R723MCNM served service class R723SCSN

SMF Info
--------
    Field: `R723SCS#`
    Record: `SMF72S3`
    Map: `R723SSS`

Number of times an AS running with service class R723MCNM served service class R723SCSN
"""

r723dnst : Final[Field] = Field(
    name='r723dnst',
    origin='R723DNST',
    type=FieldType.STRING,
    record=record,
    record_map=R723DNS,
)
"""Subsystem type as used in the classification rules specified in the WLM administrative application

SMF Info
--------
    Field: `R723DNST`
    Record: `SMF72S3`
    Map: `R723DNS`

Subsystem type as used in the classification rules specified in the WLM administrative application
"""
r723dnst.__doc__ = """Subsystem type as used in the classification rules specified in the WLM administrative application

SMF Info
--------
    Field: `R723DNST`
    Record: `SMF72S3`
    Map: `R723DNS`

Subsystem type as used in the classification rules specified in the WLM administrative application
"""

r723dnnu : Final[Field] = Field(
    name='r723dnnu',
    origin='R723DNNU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723DNS,
)
"""Number of the resource delay type. Values 1-15 are related to R723RW01-R723RW15

SMF Info
--------
    Field: `R723DNNU`
    Record: `SMF72S3`
    Map: `R723DNS`

Number of the resource delay type. Values 1-15 are related to R723RW01-R723RW15
"""
r723dnnu.__doc__ = """Number of the resource delay type. Values 1-15 are related to R723RW01-R723RW15

SMF Info
--------
    Field: `R723DNNU`
    Record: `SMF72S3`
    Map: `R723DNS`

Number of the resource delay type. Values 1-15 are related to R723RW01-R723RW15
"""

r723dnde : Final[Field] = Field(
    name='r723dnde',
    origin='R723DNDE',
    type=FieldType.STRING,
    record=record,
    record_map=R723DNS,
)
"""Resource delay description

SMF Info
--------
    Field: `R723DNDE`
    Record: `SMF72S3`
    Map: `R723DNS`

Resource delay description
"""
r723dnde.__doc__ = """Resource delay description

SMF Info
--------
    Field: `R723DNDE`
    Record: `SMF72S3`
    Map: `R723DNS`

Resource delay description
"""

class_rt : Final[Field] = Field(
    name='class_rt',
    origin='R723TRDB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R723RTS,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 14,
)
"""Response Time distribution map or counts. Each map entry defines a maximum percentage of the midpoint that was calculated for the response time distribution. When used in conjunction with an entry in the response time distribution count table, it shows the number of transactions that completed in a percentage of the midpoint.

SMF Info
--------
    Field: `R723TRDB`
    Record: `SMF72S3`
    Map: `R723RTS`

Response Time distribution map or counts. Each map entry defines a maximum percentage of the midpoint that was calculated for the response time distribution. When used in conjunction with an entry in the response time distribution count table, it shows the number of transactions that completed in a percentage of the midpoint.
"""
class_rt.__doc__ = """Response Time distribution map or counts. Each map entry defines a maximum percentage of the midpoint that was calculated for the response time distribution. When used in conjunction with an entry in the response time distribution count table, it shows the number of transactions that completed in a percentage of the midpoint.

SMF Info
--------
    Field: `R723TRDB`
    Record: `SMF72S3`
    Map: `R723RTS`

Response Time distribution map or counts. Each map entry defines a maximum percentage of the midpoint that was calculated for the response time distribution. When used in conjunction with an entry in the response time distribution count table, it shows the number of transactions that completed in a percentage of the midpoint.
"""

class_rt_bucket_1 : Final[Field] = Field(
    name='class_rt_bucket_1',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[0],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 1.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_1.__doc__ = """Response Time Distribution bucket 1.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_2 : Final[Field] = Field(
    name='class_rt_bucket_2',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[1],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 2.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_2.__doc__ = """Response Time Distribution bucket 2.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_3 : Final[Field] = Field(
    name='class_rt_bucket_3',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[2],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 3.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_3.__doc__ = """Response Time Distribution bucket 3.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_4 : Final[Field] = Field(
    name='class_rt_bucket_4',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[3],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 4.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_4.__doc__ = """Response Time Distribution bucket 4.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_5 : Final[Field] = Field(
    name='class_rt_bucket_5',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[4],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 5.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_5.__doc__ = """Response Time Distribution bucket 5.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_6 : Final[Field] = Field(
    name='class_rt_bucket_6',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[5],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 6.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_6.__doc__ = """Response Time Distribution bucket 6.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_7 : Final[Field] = Field(
    name='class_rt_bucket_7',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[6],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 7.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_7.__doc__ = """Response Time Distribution bucket 7.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_8 : Final[Field] = Field(
    name='class_rt_bucket_8',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[7],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 8.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_8.__doc__ = """Response Time Distribution bucket 8.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_9 : Final[Field] = Field(
    name='class_rt_bucket_9',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[8],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 9.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_9.__doc__ = """Response Time Distribution bucket 9.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_10 : Final[Field] = Field(
    name='class_rt_bucket_10',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[9],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 10.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_10.__doc__ = """Response Time Distribution bucket 10.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_11 : Final[Field] = Field(
    name='class_rt_bucket_11',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[10],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 11.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_11.__doc__ = """Response Time Distribution bucket 11.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_12 : Final[Field] = Field(
    name='class_rt_bucket_12',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[11],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 12.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_12.__doc__ = """Response Time Distribution bucket 12.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_13 : Final[Field] = Field(
    name='class_rt_bucket_13',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[12],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 13.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_13.__doc__ = """Response Time Distribution bucket 13.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

class_rt_bucket_14 : Final[Field] = Field(
    name='class_rt_bucket_14',
    origin=None,
    post='core.alias',
    post_param=None,
    virtual=True,
    ref=class_rt[13],
    record=record,
    record_map=R723RTS,
)
"""Response Time Distribution bucket 14.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""
class_rt_bucket_14.__doc__ = """Response Time Distribution bucket 14.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_rt`(`R723TRDB`)
    Record: `SMF72S3`
    Map: `R723RTS`

Post Processing (`core.alias`)
---------------
No post-processing parameter defined
"""

utilization_cp : Final[Field] = Field(
    name='utilization_cp',
    origin=None,
    post="core.inline",
    post_param=__utilization_cp_inline_post,
    virtual=True,
    ref=[utilization_total, utilization_ziip, utilization_zaap],
    record=record,
    record_map=R723SCS,
)
"""Percentage CPU utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `utilization_total`(Virtual), `utilization_ziip`(Virtual), `utilization_zaap`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Percentage CPU utilization, i.e. application utilization minus zIIP and zAAP utilization.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.utilization_total - df.utilization_ziip - df.utilization_zaap

"""
utilization_cp.__doc__ = """Percentage CPU utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `utilization_total`(Virtual), `utilization_ziip`(Virtual), `utilization_zaap`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Percentage CPU utilization, i.e. application utilization minus zIIP and zAAP utilization.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.utilization_total - df.utilization_ziip - df.utilization_zaap

"""

performance_index : Final[Field] = Field(
    name='performance_index',
    origin=None,
    post="core.inline",
    post_param=__performance_index_inline_post,
    virtual=True,
    ref=[class_goal_percentile, class_goal_value, class_goal_type, execution_velocity, class_rt_bucket_1, class_rt_bucket_2, class_rt_bucket_3, class_rt_bucket_4, class_rt_bucket_5, class_rt_bucket_6, class_rt_bucket_7, class_rt_bucket_8, class_rt_bucket_9, class_rt_bucket_10, class_rt_bucket_11, class_rt_bucket_12, class_rt_bucket_13, class_rt_bucket_14],
    record=record,
    record_map=R723SCS,
)
"""Performance Index value of a service class period.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_percentile`(`R723CPCT`), `class_goal_value`(`R723CVAL`), `class_goal_type`(Virtual), `execution_velocity`(Virtual), `class_rt_bucket_1`(Virtual), `class_rt_bucket_2`(Virtual), `class_rt_bucket_3`(Virtual), `class_rt_bucket_4`(Virtual), `class_rt_bucket_5`(Virtual), `class_rt_bucket_6`(Virtual), `class_rt_bucket_7`(Virtual), `class_rt_bucket_8`(Virtual), `class_rt_bucket_9`(Virtual), `class_rt_bucket_10`(Virtual), `class_rt_bucket_11`(Virtual), `class_rt_bucket_12`(Virtual), `class_rt_bucket_13`(Virtual), `class_rt_bucket_14`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Performance Index value of a service class period at one timepoint. Calculated according to the goal type. This value is the main performance metric used by Workload Manager to manage the system resources. Currently it requires the timestamp to be requested because database structure in Rocket does not allow  querying for RT buckets for a single period.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    bucket_sum = df.class_rt_bucket_1 + df.class_rt_bucket_2 + df.class_rt_bucket_3 + df.class_rt_bucket_4 + df.class_rt_bucket_5 + df.class_rt_bucket_6 + df.class_rt_bucket_7 + df.class_rt_bucket_8 + df.class_rt_bucket_9 + df.class_rt_bucket_10 + df.class_rt_bucket_11 + df.class_rt_bucket_12 + df.class_rt_bucket_13 + df.class_rt_bucket_14
    weighted_bucket_sum = 50*df.class_rt_bucket_1 + 60*df.class_rt_bucket_2 + 70*df.class_rt_bucket_3 + 80*df.class_rt_bucket_4 + 90*df.class_rt_bucket_5 + 100*df.class_rt_bucket_6 + 110*df.class_rt_bucket_7 + 120*df.class_rt_bucket_8 + 130*df.class_rt_bucket_9 + 140*df.class_rt_bucket_10 + 150*df.class_rt_bucket_11 + 200*df.class_rt_bucket_12 + 400*df.class_rt_bucket_13 + 550*df.class_rt_bucket_14
    bucket1 = (df.class_rt_bucket_1 / bucket_sum * 100) >= df.class_goal_percentile
    bucket2 = ((df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket3 = ((df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket4 = ((df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket5 = ((df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket6 = ((df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket7 = ((df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket8 = ((df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket9 = ((df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket10 = ((df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket11 = ((df.class_rt_bucket_11 + df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket12 = ((df.class_rt_bucket_12 + df.class_rt_bucket_11 + df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket13 = ((df.class_rt_bucket_13 + df.class_rt_bucket_12 + df.class_rt_bucket_11 + df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    maxindex = pd.Series([13] * df.shape[0])
    for bucket in [bucket1, bucket2, bucket3, bucket4, bucket5, bucket6, bucket7, bucket8, bucket9, bucket10, bucket11, bucket12, bucket13]:
        maxindex = maxindex.subtract(bucket.astype('int64'))

    performance_index = 0.0 * bucket_sum
    exvel_pi = df.class_goal_value / df.execution_velocity * 100
    avres_pi = weighted_bucket_sum / bucket_sum
    prres_pi = 50 + maxindex * 10 + ((maxindex == 11) * 40) + ((maxindex == 12) * 230) + ((maxindex == 13) * 370)
    performance_index = performance_index.where(df.class_goal_type != "Execution Velocity", exvel_pi)
    performance_index = performance_index.where(df.class_goal_type != "Average Resp. Time", avres_pi)
    performance_index = performance_index.where(df.class_goal_type != "Percentile Resp. Time", prres_pi)
    zerosum = (bucket_sum != 0) | (df.class_goal_type == "Execution Velocity")
    performance_index = performance_index.where(zerosum, 0)
    performance_index = performance_index.fillna(0)
    return performance_index

"""
performance_index.__doc__ = """Performance Index value of a service class period.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `class_goal_percentile`(`R723CPCT`), `class_goal_value`(`R723CVAL`), `class_goal_type`(Virtual), `execution_velocity`(Virtual), `class_rt_bucket_1`(Virtual), `class_rt_bucket_2`(Virtual), `class_rt_bucket_3`(Virtual), `class_rt_bucket_4`(Virtual), `class_rt_bucket_5`(Virtual), `class_rt_bucket_6`(Virtual), `class_rt_bucket_7`(Virtual), `class_rt_bucket_8`(Virtual), `class_rt_bucket_9`(Virtual), `class_rt_bucket_10`(Virtual), `class_rt_bucket_11`(Virtual), `class_rt_bucket_12`(Virtual), `class_rt_bucket_13`(Virtual), `class_rt_bucket_14`(Virtual)
    Record: `SMF72S3`
    Map: `R723SCS`

Performance Index value of a service class period at one timepoint. Calculated according to the goal type. This value is the main performance metric used by Workload Manager to manage the system resources. Currently it requires the timestamp to be requested because database structure in Rocket does not allow  querying for RT buckets for a single period.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    bucket_sum = df.class_rt_bucket_1 + df.class_rt_bucket_2 + df.class_rt_bucket_3 + df.class_rt_bucket_4 + df.class_rt_bucket_5 + df.class_rt_bucket_6 + df.class_rt_bucket_7 + df.class_rt_bucket_8 + df.class_rt_bucket_9 + df.class_rt_bucket_10 + df.class_rt_bucket_11 + df.class_rt_bucket_12 + df.class_rt_bucket_13 + df.class_rt_bucket_14
    weighted_bucket_sum = 50*df.class_rt_bucket_1 + 60*df.class_rt_bucket_2 + 70*df.class_rt_bucket_3 + 80*df.class_rt_bucket_4 + 90*df.class_rt_bucket_5 + 100*df.class_rt_bucket_6 + 110*df.class_rt_bucket_7 + 120*df.class_rt_bucket_8 + 130*df.class_rt_bucket_9 + 140*df.class_rt_bucket_10 + 150*df.class_rt_bucket_11 + 200*df.class_rt_bucket_12 + 400*df.class_rt_bucket_13 + 550*df.class_rt_bucket_14
    bucket1 = (df.class_rt_bucket_1 / bucket_sum * 100) >= df.class_goal_percentile
    bucket2 = ((df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket3 = ((df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket4 = ((df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket5 = ((df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket6 = ((df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket7 = ((df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket8 = ((df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket9 = ((df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket10 = ((df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket11 = ((df.class_rt_bucket_11 + df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket12 = ((df.class_rt_bucket_12 + df.class_rt_bucket_11 + df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    bucket13 = ((df.class_rt_bucket_13 + df.class_rt_bucket_12 + df.class_rt_bucket_11 + df.class_rt_bucket_10 + df.class_rt_bucket_9 + df.class_rt_bucket_8 + df.class_rt_bucket_7 + df.class_rt_bucket_6 + df.class_rt_bucket_5 + df.class_rt_bucket_4 + df.class_rt_bucket_3 + df.class_rt_bucket_2 + df.class_rt_bucket_1) / bucket_sum * 100) >= df.class_goal_percentile
    maxindex = pd.Series([13] * df.shape[0])
    for bucket in [bucket1, bucket2, bucket3, bucket4, bucket5, bucket6, bucket7, bucket8, bucket9, bucket10, bucket11, bucket12, bucket13]:
        maxindex = maxindex.subtract(bucket.astype('int64'))

    performance_index = 0.0 * bucket_sum
    exvel_pi = df.class_goal_value / df.execution_velocity * 100
    avres_pi = weighted_bucket_sum / bucket_sum
    prres_pi = 50 + maxindex * 10 + ((maxindex == 11) * 40) + ((maxindex == 12) * 230) + ((maxindex == 13) * 370)
    performance_index = performance_index.where(df.class_goal_type != "Execution Velocity", exvel_pi)
    performance_index = performance_index.where(df.class_goal_type != "Average Resp. Time", avres_pi)
    performance_index = performance_index.where(df.class_goal_type != "Percentile Resp. Time", prres_pi)
    zerosum = (bucket_sum != 0) | (df.class_goal_type == "Execution Velocity")
    performance_index = performance_index.where(zerosum, 0)
    performance_index = performance_index.fillna(0)
    return performance_index

"""
