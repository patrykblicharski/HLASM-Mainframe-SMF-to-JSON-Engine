# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 78 Suptye 3"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=78,
                                smf_subtype=3,
                                spec='SMF 78 Suptye 3',
                                post=None)
"""SMF 78 Suptye 3"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF78PRO: Final[RecordMap] = RecordMap(
    origin='SMF78PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R783GD: Final[RecordMap] = RecordMap(
    origin='R783GD',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Global Section',
    post=None,
    record_mapping=False)
"""Global Section"""
R783CS: Final[RecordMap] = RecordMap(
    origin='R783CS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Configuration Control Section',
    post=None,
    record_mapping=False)
"""Configuration Control Section"""
R783DS: Final[RecordMap] = RecordMap(
    origin='R783DS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Data Section',
    post=None,
    record_mapping=False)
"""Data Section"""
R783HPAV: Final[RecordMap] = RecordMap(
    origin='R783HPAV',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='HyperPAV/SuperPAV data section',
    post=None,
    record_mapping=False)
"""HyperPAV/SuperPAV data section"""
R783IQD: Final[RecordMap] = RecordMap(
    origin='R783IQD',
    record=record,
    parent=R783GD,
    is_multiple=True,
    is_compound=False,
    spec='IOP initiative queue data section',
    post=None,
    record_mapping=False)
"""IOP initiative queue data section"""
R783CPD: Final[RecordMap] = RecordMap(
    origin='R783CPD',
    record=record,
    parent=R783CS,
    is_multiple=True,
    is_compound=False,
    spec='Configuration Data Section',
    post=None,
    record_mapping=False)
"""Configuration Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF78DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF78DTE`
    Record: `SMF78S3`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF78DTE`
    Record: `SMF78S3`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF78TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF78TME`
    Record: `SMF78S3`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF78TME`
    Record: `SMF78S3`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF78DTE`), `time`(`SMF78TME`)
    Record: `SMF78S3`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF78DTE`), `time`(`SMF78TME`)
    Record: `SMF78S3`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF78LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF78LEN`
    Record: `SMF78S3`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF78LEN`
    Record: `SMF78S3`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF78SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF78SEG`
    Record: `SMF78S3`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF78SEG`
    Record: `SMF78S3`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF78FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF78FLG`
    Record: `SMF78S3`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF78FLG`
    Record: `SMF78S3`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF78FLG`)
    Record: `SMF78S3`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF78RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF78RTY`
    Record: `SMF78S3`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF78RTY`
    Record: `SMF78S3`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF78TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF78TME`
    Record: `SMF78S3`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF78TME`
    Record: `SMF78S3`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF78DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF78DTE`
    Record: `SMF78S3`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF78DTE`
    Record: `SMF78S3`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF78SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF78SID`
    Record: `SMF78S3`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF78SID`
    Record: `SMF78S3`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF78SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF78SSI`
    Record: `SMF78S3`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF78SSI`
    Record: `SMF78S3`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF78STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF78STY`
    Record: `SMF78S3`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF78STY`
    Record: `SMF78S3`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF78TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF78TRN`
    Record: `SMF78S3`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF78TRN`
    Record: `SMF78S3`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF78PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF78PRS`
    Record: `SMF78S3`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF78PRS`
    Record: `SMF78S3`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF78PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF78PRL`
    Record: `SMF78S3`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF78PRL`
    Record: `SMF78S3`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF78PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF78PRN`
    Record: `SMF78S3`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF78PRN`
    Record: `SMF78S3`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

dcs : Final[Field] = Field(
    name='dcs',
    origin='SMF78DCS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to configuration section R781CS (subtype 1), data section R782COMN (subtype 2) or configuration section R783CS (subtype 3)

SMF Info
--------
    Field: `SMF78DCS`
    Record: `SMF78S3`
    Map: Not part of a map

Offset to configuration section R781CS (subtype 1), data section R782COMN (subtype 2) or configuration section R783CS (subtype 3)
"""
dcs.__doc__ = """Offset to configuration section R781CS (subtype 1), data section R782COMN (subtype 2) or configuration section R783CS (subtype 3)

SMF Info
--------
    Field: `SMF78DCS`
    Record: `SMF78S3`
    Map: Not part of a map

Offset to configuration section R781CS (subtype 1), data section R782COMN (subtype 2) or configuration section R783CS (subtype 3)
"""

dcl : Final[Field] = Field(
    name='dcl',
    origin='SMF78DCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF SECTION

SMF Info
--------
    Field: `SMF78DCL`
    Record: `SMF78S3`
    Map: Not part of a map

LENGTH OF SECTION
"""
dcl.__doc__ = """LENGTH OF SECTION

SMF Info
--------
    Field: `SMF78DCL`
    Record: `SMF78S3`
    Map: Not part of a map

LENGTH OF SECTION
"""

dcn : Final[Field] = Field(
    name='dcn',
    origin='SMF78DCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF SECTIONS

SMF Info
--------
    Field: `SMF78DCN`
    Record: `SMF78S3`
    Map: Not part of a map

NUMBER OF SECTIONS
"""
dcn.__doc__ = """NUMBER OF SECTIONS

SMF Info
--------
    Field: `SMF78DCN`
    Record: `SMF78S3`
    Map: Not part of a map

NUMBER OF SECTIONS
"""

ass : Final[Field] = Field(
    name='ass',
    origin='SMF78ASS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to data section R781DS (subtype 1) R782PVT (subtype 2) R783DS (subtype 3)

SMF Info
--------
    Field: `SMF78ASS`
    Record: `SMF78S3`
    Map: Not part of a map

Offset to data section R781DS (subtype 1) R782PVT (subtype 2) R783DS (subtype 3)
"""
ass.__doc__ = """Offset to data section R781DS (subtype 1) R782PVT (subtype 2) R783DS (subtype 3)

SMF Info
--------
    Field: `SMF78ASS`
    Record: `SMF78S3`
    Map: Not part of a map

Offset to data section R781DS (subtype 1) R782PVT (subtype 2) R783DS (subtype 3)
"""

asl : Final[Field] = Field(
    name='asl',
    origin='SMF78ASL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF78ASL`
    Record: `SMF78S3`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""
asl.__doc__ = """LENGTH OF DATA SECTION

SMF Info
--------
    Field: `SMF78ASL`
    Record: `SMF78S3`
    Map: Not part of a map

LENGTH OF DATA SECTION
"""

asn : Final[Field] = Field(
    name='asn',
    origin='SMF78ASN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DATA SECTIONS

SMF Info
--------
    Field: `SMF78ASN`
    Record: `SMF78S3`
    Map: Not part of a map

NUMBER OF DATA SECTIONS
"""
asn.__doc__ = """NUMBER OF DATA SECTIONS

SMF Info
--------
    Field: `SMF78ASN`
    Record: `SMF78S3`
    Map: Not part of a map

NUMBER OF DATA SECTIONS
"""

qds : Final[Field] = Field(
    name='qds',
    origin='SMF78QDS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to IOQ global section

SMF Info
--------
    Field: `SMF78QDS`
    Record: `SMF78S3`
    Map: Not part of a map

Offset to IOQ global section
"""
qds.__doc__ = """Offset to IOQ global section

SMF Info
--------
    Field: `SMF78QDS`
    Record: `SMF78S3`
    Map: Not part of a map

Offset to IOQ global section
"""

qdl : Final[Field] = Field(
    name='qdl',
    origin='SMF78QDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of IOQ global section

SMF Info
--------
    Field: `SMF78QDL`
    Record: `SMF78S3`
    Map: Not part of a map

Length of IOQ global section
"""
qdl.__doc__ = """Length of IOQ global section

SMF Info
--------
    Field: `SMF78QDL`
    Record: `SMF78S3`
    Map: Not part of a map

Length of IOQ global section
"""

qdn : Final[Field] = Field(
    name='qdn',
    origin='SMF78QDN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of IOQ global section

SMF Info
--------
    Field: `SMF78QDN`
    Record: `SMF78S3`
    Map: Not part of a map

Number of IOQ global section
"""
qdn.__doc__ = """Number of IOQ global section

SMF Info
--------
    Field: `SMF78QDN`
    Record: `SMF78S3`
    Map: Not part of a map

Number of IOQ global section
"""

hps : Final[Field] = Field(
    name='hps',
    origin='SMF78HPS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to HyperPAV/ SuperPAV Data Sections

SMF Info
--------
    Field: `SMF78HPS`
    Record: `SMF78S3`
    Map: Not part of a map

Offset to HyperPAV/ SuperPAV Data Sections
"""
hps.__doc__ = """Offset to HyperPAV/ SuperPAV Data Sections

SMF Info
--------
    Field: `SMF78HPS`
    Record: `SMF78S3`
    Map: Not part of a map

Offset to HyperPAV/ SuperPAV Data Sections
"""

hpl : Final[Field] = Field(
    name='hpl',
    origin='SMF78HPL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of HyperPAV/ SuperPAV Data Section

SMF Info
--------
    Field: `SMF78HPL`
    Record: `SMF78S3`
    Map: Not part of a map

Length of HyperPAV/ SuperPAV Data Section
"""
hpl.__doc__ = """Length of HyperPAV/ SuperPAV Data Section

SMF Info
--------
    Field: `SMF78HPL`
    Record: `SMF78S3`
    Map: Not part of a map

Length of HyperPAV/ SuperPAV Data Section
"""

hpn : Final[Field] = Field(
    name='hpn',
    origin='SMF78HPN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of HyperPAV/ SuperPAV Data Sections

SMF Info
--------
    Field: `SMF78HPN`
    Record: `SMF78S3`
    Map: Not part of a map

Number of HyperPAV/ SuperPAV Data Sections
"""
hpn.__doc__ = """Number of HyperPAV/ SuperPAV Data Sections

SMF Info
--------
    Field: `SMF78HPN`
    Record: `SMF78S3`
    Map: Not part of a map

Number of HyperPAV/ SuperPAV Data Sections
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF78MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF78MFV`
    Record: `SMF78S3`
    Map: `SMF78PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF78MFV`
    Record: `SMF78S3`
    Map: `SMF78PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF78PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF78PRD`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF78PRD`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF78IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF78PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF78IST`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF78IST`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF78DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF78PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF78DAT`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF78DAT`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF78INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF78PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF78INT`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF78INT`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF78SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF78SAM`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF78SAM`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF78FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF78FLA`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF78FLA`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

lower_service_level : Final[Field] = Field(
    name='lower_service_level',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
lower_service_level.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

higher_service_level : Final[Field] = Field(
    name='higher_service_level',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
higher_service_level.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF78PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF78FLA`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF78CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF78PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF78CYC`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF78CYC`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF78MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF78MVS`
    Record: `SMF78S3`
    Map: `SMF78PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF78MVS`
    Record: `SMF78S3`
    Map: `SMF78PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF78IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF78IML`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF78IML`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF78PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF78PRF`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF78PRF`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zapp_inst : Final[Field] = Field(
    name='zapp_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zapp_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF78PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF78PRF`)
    Record: `SMF78S3`
    Map: `SMF78PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF78PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF78PTN`
    Record: `SMF78S3`
    Map: `SMF78PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF78PTN`
    Record: `SMF78S3`
    Map: `SMF78PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF78SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF78SRL`
    Record: `SMF78S3`
    Map: `SMF78PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF78SRL`
    Record: `SMF78S3`
    Map: `SMF78PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF78IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF78PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF78IET`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF78IET`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF78LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF78LGO`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF78LGO`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF78RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF78RAO`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF78RAO`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF78RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF78RAL`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF78RAL`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF78RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF78RAN`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF78RAN`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF78OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF78OIL`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF78OIL`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF78SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF78PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF78SYN`
    Record: `SMF78S3`
    Map: `SMF78PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF78SYN`
    Record: `SMF78S3`
    Map: `SMF78PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF78GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF78PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF78GIE`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF78GIE`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF78XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF78XNM`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF78XNM`
    Record: `SMF78S3`
    Map: `SMF78PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF78SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF78PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF78SNM`
    Record: `SMF78S3`
    Map: `SMF78PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF78SNM`
    Record: `SMF78S3`
    Map: `SMF78PRO`

System name for current system as defined in CVTSNAME
"""

r783gflg : Final[Field] = Field(
    name='r783gflg',
    origin='R783GFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R783GD,
)
"""IOQ global flag

SMF Info
--------
    Field: `R783GFLG`
    Record: `SMF78S3`
    Map: `R783GD`

IOQ global flag
"""
r783gflg.__doc__ = """IOQ global flag

SMF Info
--------
    Field: `R783GFLG`
    Record: `SMF78S3`
    Map: `R783GD`

IOQ global flag
"""

data_invalid_ch_failure : Final[Field] = Field(
    name='data_invalid_ch_failure',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r783gflg,
    record=record,
    record_map=R783GD,
)
"""X'80' Data is invalid due to failure of the channel measurement facility(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'80' Data is invalid due to failure of the channel measurement facility

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
data_invalid_ch_failure.__doc__ = """X'80' Data is invalid due to failure of the channel measurement facility(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'80' Data is invalid due to failure of the channel measurement facility

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

diagnose_failed : Final[Field] = Field(
    name='diagnose_failed',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r783gflg,
    record=record,
    record_map=R783GD,
)
"""X'40' DIAGNOSE interface failed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'40' DIAGNOSE interface failed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
diagnose_failed.__doc__ = """X'40' DIAGNOSE interface failed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'40' DIAGNOSE interface failed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

store_primary_not_supported : Final[Field] = Field(
    name='store_primary_not_supported',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r783gflg,
    record=record,
    record_map=R783GD,
)
"""X'20' Store Primary Queue Data not supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'20' Store Primary Queue Data not supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
store_primary_not_supported.__doc__ = """X'20' Store Primary Queue Data not supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'20' Store Primary Queue Data not supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

dcm_hw_supported : Final[Field] = Field(
    name='dcm_hw_supported',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r783gflg,
    record=record,
    record_map=R783GD,
)
"""X'10' DCM supported by hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'10' DCM supported by hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
dcm_hw_supported.__doc__ = """X'10' DCM supported by hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'10' DCM supported by hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

dcm_managed_ch : Final[Field] = Field(
    name='dcm_managed_ch',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r783gflg,
    record=record,
    record_map=R783GD,
)
"""X'08' Configuration contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'08' Configuration contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
dcm_managed_ch.__doc__ = """X'08' Configuration contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'08' Configuration contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

iop_util_data_supported : Final[Field] = Field(
    name='iop_util_data_supported',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r783gflg,
    record=record,
    record_map=R783GD,
)
"""X'04' IOP utilization data supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'04' IOP utilization data supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
iop_util_data_supported.__doc__ = """X'04' IOP utilization data supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

X'04' IOP utilization data supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

command_response_time_supported : Final[Field] = Field(
    name='command_response_time_supported',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r783gflg,
    record=record,
    record_map=R783GD,
)
"""Initial-command-response time measurements supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

Initial-command-response time measurements supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
command_response_time_supported.__doc__ = """Initial-command-response time measurements supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

Initial-command-response time measurements supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

transfer_ready_disabled_aval : Final[Field] = Field(
    name='transfer_ready_disabled_aval',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r783gflg,
    record=record,
    record_map=R783GD,
)
"""First-transfer-ready disabled write data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

First-transfer-ready disabled write data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
transfer_ready_disabled_aval.__doc__ = """First-transfer-ready disabled write data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflg`(`R783GFLG`)
    Record: `SMF78S3`
    Map: `R783GD`

First-transfer-ready disabled write data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r783gflx : Final[Field] = Field(
    name='r783gflx',
    origin='R783GFLX',
    type=FieldType.STRING,
    record=record,
    record_map=R783GD,
)
"""IOQ global flags extended

SMF Info
--------
    Field: `R783GFLX`
    Record: `SMF78S3`
    Map: `R783GD`

IOQ global flags extended
"""
r783gflx.__doc__ = """IOQ global flags extended

SMF Info
--------
    Field: `R783GFLX`
    Record: `SMF78S3`
    Map: `R783GD`

IOQ global flags extended
"""

alias_management_aval : Final[Field] = Field(
    name='alias_management_aval',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r783gflx,
    record=record,
    record_map=R783GD,
)
"""X'80' Alias Management Groups available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflx`(`R783GFLX`)
    Record: `SMF78S3`
    Map: `R783GD`

X'80' Alias Management Groups available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
alias_management_aval.__doc__ = """X'80' Alias Management Groups available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflx`(`R783GFLX`)
    Record: `SMF78S3`
    Map: `R783GD`

X'80' Alias Management Groups available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

eadm_compression_aval : Final[Field] = Field(
    name='eadm_compression_aval',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r783gflx,
    record=record,
    record_map=R783GD,
)
"""X'40' EADM-compression facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflx`(`R783GFLX`)
    Record: `SMF78S3`
    Map: `R783GD`

X'40' EADM-compression facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
eadm_compression_aval.__doc__ = """X'40' EADM-compression facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflx`(`R783GFLX`)
    Record: `SMF78S3`
    Map: `R783GD`

X'40' EADM-compression facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

scm_aval : Final[Field] = Field(
    name='scm_aval',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r783gflx,
    record=record,
    record_map=R783GD,
)
"""X'20' SCM facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflx`(`R783GFLX`)
    Record: `SMF78S3`
    Map: `R783GD`

X'20' SCM facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
scm_aval.__doc__ = """X'20' SCM facility available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783gflx`(`R783GFLX`)
    Record: `SMF78S3`
    Map: `R783GD`

X'20' SCM facility available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r783gntr : Final[Field] = Field(
    name='r783gntr',
    origin='R783GNTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783GD,
)
"""Number of triplets

SMF Info
--------
    Field: `R783GNTR`
    Record: `SMF78S3`
    Map: `R783GD`

Number of triplets
"""
r783gntr.__doc__ = """Number of triplets

SMF Info
--------
    Field: `R783GNTR`
    Record: `SMF78S3`
    Map: `R783GD`

Number of triplets
"""

r783gids : Final[Field] = Field(
    name='r783gids',
    origin='R783GIDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783GD,
)
"""Offset to IOP initiative queue data section

SMF Info
--------
    Field: `R783GIDS`
    Record: `SMF78S3`
    Map: `R783GD`

Offset to IOP initiative queue data section
"""
r783gids.__doc__ = """Offset to IOP initiative queue data section

SMF Info
--------
    Field: `R783GIDS`
    Record: `SMF78S3`
    Map: `R783GD`

Offset to IOP initiative queue data section
"""

r783gidl : Final[Field] = Field(
    name='r783gidl',
    origin='R783GIDL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783GD,
)
"""Length of IOP initiative queue data section

SMF Info
--------
    Field: `R783GIDL`
    Record: `SMF78S3`
    Map: `R783GD`

Length of IOP initiative queue data section
"""
r783gidl.__doc__ = """Length of IOP initiative queue data section

SMF Info
--------
    Field: `R783GIDL`
    Record: `SMF78S3`
    Map: `R783GD`

Length of IOP initiative queue data section
"""

r783gidn : Final[Field] = Field(
    name='r783gidn',
    origin='R783GIDN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783GD,
)
"""Number of IOP initiative queue data sections

SMF Info
--------
    Field: `R783GIDN`
    Record: `SMF78S3`
    Map: `R783GD`

Number of IOP initiative queue data sections
"""
r783gidn.__doc__ = """Number of IOP initiative queue data sections

SMF Info
--------
    Field: `R783GIDN`
    Record: `SMF78S3`
    Map: `R783GD`

Number of IOP initiative queue data sections
"""

r783tsr : Final[Field] = Field(
    name='r783tsr',
    origin='R783TSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783GD,
)
"""Total number of small records

SMF Info
--------
    Field: `R783TSR`
    Record: `SMF78S3`
    Map: `R783GD`

Total number of small records
"""
r783tsr.__doc__ = """Total number of small records

SMF Info
--------
    Field: `R783TSR`
    Record: `SMF78S3`
    Map: `R783GD`

Total number of small records
"""

r783tot : Final[Field] = Field(
    name='r783tot',
    origin='R783TOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783GD,
)
"""Total number of data sections in large SMF record

SMF Info
--------
    Field: `R783TOT`
    Record: `SMF78S3`
    Map: `R783GD`

Total number of data sections in large SMF record
"""
r783tot.__doc__ = """Total number of data sections in large SMF record

SMF Info
--------
    Field: `R783TOT`
    Record: `SMF78S3`
    Map: `R783GD`

Total number of data sections in large SMF record
"""

r783nxt : Final[Field] = Field(
    name='r783nxt',
    origin='R783NXT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783GD,
)
"""Number of data sections in following records

SMF Info
--------
    Field: `R783NXT`
    Record: `SMF78S3`
    Map: `R783GD`

Number of data sections in following records
"""
r783nxt.__doc__ = """Number of data sections in following records

SMF Info
--------
    Field: `R783NXT`
    Record: `SMF78S3`
    Map: `R783GD`

Number of data sections in following records
"""

r783cfl : Final[Field] = Field(
    name='r783cfl',
    origin='R783CFL',
    type=FieldType.STRING,
    record=record,
    record_map=R783GD,
)
"""Configuration Change Flags

SMF Info
--------
    Field: `R783CFL`
    Record: `SMF78S3`
    Map: `R783GD`

Configuration Change Flags
"""
r783cfl.__doc__ = """Configuration Change Flags

SMF Info
--------
    Field: `R783CFL`
    Record: `SMF78S3`
    Map: `R783GD`

Configuration Change Flags
"""

config_changed : Final[Field] = Field(
    name='config_changed',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r783cfl,
    record=record,
    record_map=R783GD,
)
"""Configuration changed last interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

Configuration changed last interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
config_changed.__doc__ = """Configuration changed last interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

Configuration changed last interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

config_changed_last_ipl : Final[Field] = Field(
    name='config_changed_last_ipl',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r783cfl,
    record=record,
    record_map=R783GD,
)
"""Configuration Changed since last IPL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

Configuration Changed since last IPL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
config_changed_last_ipl.__doc__ = """Configuration Changed since last IPL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

Configuration Changed since last IPL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

ipl_iodf : Final[Field] = Field(
    name='ipl_iodf',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r783cfl,
    record=record,
    record_map=R783GD,
)
"""System IPLed via IODF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

System IPLed via IODF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
ipl_iodf.__doc__ = """System IPLed via IODF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

System IPLed via IODF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

io_config_token_valid : Final[Field] = Field(
    name='io_config_token_valid',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r783cfl,
    record=record,
    record_map=R783GD,
)
"""I/O Configuration Token is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

I/O Configuration Token is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
io_config_token_valid.__doc__ = """I/O Configuration Token is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

I/O Configuration Token is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

multi_ch_subsys_allowed : Final[Field] = Field(
    name='multi_ch_subsys_allowed',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r783cfl,
    record=record,
    record_map=R783GD,
)
"""Hardware allows multiple channel subsystems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

Hardware allows multiple channel subsystems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
multi_ch_subsys_allowed.__doc__ = """Hardware allows multiple channel subsystems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cfl`(`R783CFL`)
    Record: `SMF78S3`
    Map: `R783GD`

Hardware allows multiple channel subsystems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r783css : Final[Field] = Field(
    name='r783css',
    origin='R783CSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783GD,
)
"""Channel SubSystem Id, only valid if R783MCS = ON

SMF Info
--------
    Field: `R783CSS`
    Record: `SMF78S3`
    Map: `R783GD`

Channel SubSystem Id, only valid if R783MCS = ON
"""
r783css.__doc__ = """Channel SubSystem Id, only valid if R783MCS = ON

SMF Info
--------
    Field: `R783CSS`
    Record: `SMF78S3`
    Map: `R783GD`

Channel SubSystem Id, only valid if R783MCS = ON
"""

r783tnm : Final[Field] = Field(
    name='r783tnm',
    origin='R783TNM',
    type=FieldType.STRING,
    record=record,
    record_map=R783GD,
)
"""IODF name

SMF Info
--------
    Field: `R783TNM`
    Record: `SMF78S3`
    Map: `R783GD`

IODF name
"""
r783tnm.__doc__ = """IODF name

SMF Info
--------
    Field: `R783TNM`
    Record: `SMF78S3`
    Map: `R783GD`

IODF name
"""

r783tsf : Final[Field] = Field(
    name='r783tsf',
    origin='R783TSF',
    type=FieldType.STRING,
    record=record,
    record_map=R783GD,
)
"""Suffix of IODF Name

SMF Info
--------
    Field: `R783TSF`
    Record: `SMF78S3`
    Map: `R783GD`

Suffix of IODF Name
"""
r783tsf.__doc__ = """Suffix of IODF Name

SMF Info
--------
    Field: `R783TSF`
    Record: `SMF78S3`
    Map: `R783GD`

Suffix of IODF Name
"""

r783tdt : Final[Field] = Field(
    name='r783tdt',
    origin='R783TDT',
    type=FieldType.STRING,
    record=record,
    record_map=R783GD,
)
"""IODF Creation Date mm/dd/yy

SMF Info
--------
    Field: `R783TDT`
    Record: `SMF78S3`
    Map: `R783GD`

IODF Creation Date mm/dd/yy
"""
r783tdt.__doc__ = """IODF Creation Date mm/dd/yy

SMF Info
--------
    Field: `R783TDT`
    Record: `SMF78S3`
    Map: `R783GD`

IODF Creation Date mm/dd/yy
"""

r783ttm : Final[Field] = Field(
    name='r783ttm',
    origin='R783TTM',
    type=FieldType.STRING,
    record=record,
    record_map=R783GD,
)
"""IODF Creation Time hh.mm.ss

SMF Info
--------
    Field: `R783TTM`
    Record: `SMF78S3`
    Map: `R783GD`

IODF Creation Time hh.mm.ss
"""
r783ttm.__doc__ = """IODF Creation Time hh.mm.ss

SMF Info
--------
    Field: `R783TTM`
    Record: `SMF78S3`
    Map: `R783GD`

IODF Creation Time hh.mm.ss
"""

r783tdy : Final[Field] = Field(
    name='r783tdy',
    origin='R783TDY',
    type=FieldType.STRING,
    record=record,
    record_map=R783GD,
)
"""IODF creation date mm/dd/yyyy

SMF Info
--------
    Field: `R783TDY`
    Record: `SMF78S3`
    Map: `R783GD`

IODF creation date mm/dd/yyyy
"""
r783tdy.__doc__ = """IODF creation date mm/dd/yyyy

SMF Info
--------
    Field: `R783TDY`
    Record: `SMF78S3`
    Map: `R783GD`

IODF creation date mm/dd/yyyy
"""

r783tok : Final[Field] = Field(
    name='r783tok',
    origin='R783TOK',
    type=FieldType.STRING,
    record=record,
    record_map=R783GD,
)
"""Partially Token Information

SMF Info
--------
    Field: `R783TOK`
    Record: `SMF78S3`
    Map: `R783GD`

Partially Token Information
"""
r783tok.__doc__ = """Partially Token Information

SMF Info
--------
    Field: `R783TOK`
    Record: `SMF78S3`
    Map: `R783GD`

Partially Token Information
"""

r783id1 : Final[Field] = Field(
    name='r783id1',
    origin='R783ID1',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CS,
)
"""logical control unit identifier

SMF Info
--------
    Field: `R783ID1`
    Record: `SMF78S3`
    Map: `R783CS`

logical control unit identifier
"""
r783id1.__doc__ = """logical control unit identifier

SMF Info
--------
    Field: `R783ID1`
    Record: `SMF78S3`
    Map: `R783CS`

logical control unit identifier
"""

r783ntr : Final[Field] = Field(
    name='r783ntr',
    origin='R783NTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CS,
)
"""Number of despriptor triplets

SMF Info
--------
    Field: `R783NTR`
    Record: `SMF78S3`
    Map: `R783CS`

Number of despriptor triplets
"""
r783ntr.__doc__ = """Number of despriptor triplets

SMF Info
--------
    Field: `R783NTR`
    Record: `SMF78S3`
    Map: `R783CS`

Number of despriptor triplets
"""

r783cpds : Final[Field] = Field(
    name='r783cpds',
    origin='R783CPDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CS,
)
"""Offset to configuration data section

SMF Info
--------
    Field: `R783CPDS`
    Record: `SMF78S3`
    Map: `R783CS`

Offset to configuration data section
"""
r783cpds.__doc__ = """Offset to configuration data section

SMF Info
--------
    Field: `R783CPDS`
    Record: `SMF78S3`
    Map: `R783CS`

Offset to configuration data section
"""

r783cpdl : Final[Field] = Field(
    name='r783cpdl',
    origin='R783CPDL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CS,
)
"""Length of configuration data section

SMF Info
--------
    Field: `R783CPDL`
    Record: `SMF78S3`
    Map: `R783CS`

Length of configuration data section
"""
r783cpdl.__doc__ = """Length of configuration data section

SMF Info
--------
    Field: `R783CPDL`
    Record: `SMF78S3`
    Map: `R783CS`

Length of configuration data section
"""

r783cpdn : Final[Field] = Field(
    name='r783cpdn',
    origin='R783CPDN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CS,
)
"""Number of configuration data sections

SMF Info
--------
    Field: `R783CPDN`
    Record: `SMF78S3`
    Map: `R783CS`

Number of configuration data sections
"""
r783cpdn.__doc__ = """Number of configuration data sections

SMF Info
--------
    Field: `R783CPDN`
    Record: `SMF78S3`
    Map: `R783CS`

Number of configuration data sections
"""

r783amgc : Final[Field] = Field(
    name='r783amgc',
    origin='R783AMGC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CS,
)
"""The Alias Management Group number defined on the physical controller for this LCU. This number is valid, if the LCU is assigned to a DASD subsystem that supports Alias Management Groups and bit 7 of R783DST is set

SMF Info
--------
    Field: `R783AMGC`
    Record: `SMF78S3`
    Map: `R783CS`

The Alias Management Group number defined on the physical controller for this LCU. This number is valid, if the LCU is assigned to a DASD subsystem that supports Alias Management Groups and bit 7 of R783DST is set
"""
r783amgc.__doc__ = """The Alias Management Group number defined on the physical controller for this LCU. This number is valid, if the LCU is assigned to a DASD subsystem that supports Alias Management Groups and bit 7 of R783DST is set

SMF Info
--------
    Field: `R783AMGC`
    Record: `SMF78S3`
    Map: `R783CS`

The Alias Management Group number defined on the physical controller for this LCU. This number is valid, if the LCU is assigned to a DASD subsystem that supports Alias Management Groups and bit 7 of R783DST is set
"""

r783amgs : Final[Field] = Field(
    name='r783amgs',
    origin='R783AMGS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CS,
)
"""The Alias Management Group number assigned by z/OS for this LCU on this system. This number is valid, if the LCU is assigned to a DASD subsystem that supports Alias Management Groups and bit 7 of R783DST is set

SMF Info
--------
    Field: `R783AMGS`
    Record: `SMF78S3`
    Map: `R783CS`

The Alias Management Group number assigned by z/OS for this LCU on this system. This number is valid, if the LCU is assigned to a DASD subsystem that supports Alias Management Groups and bit 7 of R783DST is set
"""
r783amgs.__doc__ = """The Alias Management Group number assigned by z/OS for this LCU on this system. This number is valid, if the LCU is assigned to a DASD subsystem that supports Alias Management Groups and bit 7 of R783DST is set

SMF Info
--------
    Field: `R783AMGS`
    Record: `SMF78S3`
    Map: `R783CS`

The Alias Management Group number assigned by z/OS for this LCU on this system. This number is valid, if the LCU is assigned to a DASD subsystem that supports Alias Management Groups and bit 7 of R783DST is set
"""

r783id2 : Final[Field] = Field(
    name='r783id2',
    origin='R783ID2',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Logical control unit identifier

SMF Info
--------
    Field: `R783ID2`
    Record: `SMF78S3`
    Map: `R783DS`

Logical control unit identifier
"""
r783id2.__doc__ = """Logical control unit identifier

SMF Info
--------
    Field: `R783ID2`
    Record: `SMF78S3`
    Map: `R783DS`

Logical control unit identifier
"""

r783dst : Final[Field] = Field(
    name='r783dst',
    origin='R783DST',
    type=FieldType.STRING,
    record=record,
    record_map=R783DS,
)
"""Data status

SMF Info
--------
    Field: `R783DST`
    Record: `SMF78S3`
    Map: `R783DS`

Data status
"""
r783dst.__doc__ = """Data status

SMF Info
--------
    Field: `R783DST`
    Record: `SMF78S3`
    Map: `R783DS`

Data status
"""

no_hw_measurement : Final[Field] = Field(
    name='no_hw_measurement',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r783dst,
    record=record,
    record_map=R783DS,
)
"""X'80' No hardware measurements(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'80' No hardware measurements

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
no_hw_measurement.__doc__ = """X'80' No hardware measurements(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'80' No hardware measurements

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

dynamically_changed : Final[Field] = Field(
    name='dynamically_changed',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r783dst,
    record=record,
    record_map=R783DS,
)
"""X'40' Dynamically changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'40' Dynamically changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
dynamically_changed.__doc__ = """X'40' Dynamically changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'40' Dynamically changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

dynamically_added : Final[Field] = Field(
    name='dynamically_added',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r783dst,
    record=record,
    record_map=R783DS,
)
"""X'20' Dynamically added(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'20' Dynamically added

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
dynamically_added.__doc__ = """X'20' Dynamically added(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'20' Dynamically added

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

config_change_attempt : Final[Field] = Field(
    name='config_change_attempt',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r783dst,
    record=record,
    record_map=R783DS,
)
"""X'10' Conf. Chg. Attempt(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'10' Conf. Chg. Attempt

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
config_change_attempt.__doc__ = """X'10' Conf. Chg. Attempt(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'10' Conf. Chg. Attempt

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

lcu_has_dcm_ch : Final[Field] = Field(
    name='lcu_has_dcm_ch',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r783dst,
    record=record,
    record_map=R783DS,
)
"""X'08' LCU contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'08' LCU contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
lcu_has_dcm_ch.__doc__ = """X'08' LCU contains DCM managed channels(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'08' LCU contains DCM managed channels

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

path_attr_valid : Final[Field] = Field(
    name='path_attr_valid',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r783dst,
    record=record,
    record_map=R783DS,
)
"""X'04' Path attributes are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'04' Path attributes are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
path_attr_valid.__doc__ = """X'04' Path attributes are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'04' Path attributes are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

lcu_has_hyperpav : Final[Field] = Field(
    name='lcu_has_hyperpav',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r783dst,
    record=record,
    record_map=R783DS,
)
"""X'02' LCU has HyperPAV devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'02' LCU has HyperPAV devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
lcu_has_hyperpav.__doc__ = """X'02' LCU has HyperPAV devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'02' LCU has HyperPAV devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

lcu_has_superpav : Final[Field] = Field(
    name='lcu_has_superpav',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r783dst,
    record=record,
    record_map=R783DS,
)
"""X'01' LCU has SuperPAV devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'01' LCU has SuperPAV devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
lcu_has_superpav.__doc__ = """X'01' LCU has SuperPAV devices(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dst`(`R783DST`)
    Record: `SMF78S3`
    Map: `R783DS`

X'01' LCU has SuperPAV devices

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r783dstx : Final[Field] = Field(
    name='r783dstx',
    origin='R783DSTX',
    type=FieldType.STRING,
    record=record,
    record_map=R783DS,
)
"""Data status extension

SMF Info
--------
    Field: `R783DSTX`
    Record: `SMF78S3`
    Map: `R783DS`

Data status extension
"""
r783dstx.__doc__ = """Data status extension

SMF Info
--------
    Field: `R783DSTX`
    Record: `SMF78S3`
    Map: `R783DS`

Data status extension
"""

lcu_has_ficom : Final[Field] = Field(
    name='lcu_has_ficom',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r783dstx,
    record=record,
    record_map=R783DS,
)
"""X'80' LCU contains at least one FICON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dstx`(`R783DSTX`)
    Record: `SMF78S3`
    Map: `R783DS`

X'80' LCU contains at least one FICON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
lcu_has_ficom.__doc__ = """X'80' LCU contains at least one FICON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dstx`(`R783DSTX`)
    Record: `SMF78S3`
    Map: `R783DS`

X'80' LCU contains at least one FICON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

connect_time_invalid : Final[Field] = Field(
    name='connect_time_invalid',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r783dstx,
    record=record,
    record_map=R783DS,
)
"""X'40' connect time of at least one device invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dstx`(`R783DSTX`)
    Record: `SMF78S3`
    Map: `R783DS`

X'40' connect time of at least one device invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
connect_time_invalid.__doc__ = """X'40' connect time of at least one device invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dstx`(`R783DSTX`)
    Record: `SMF78S3`
    Map: `R783DS`

X'40' connect time of at least one device invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

disconnect_time_invalid : Final[Field] = Field(
    name='disconnect_time_invalid',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r783dstx,
    record=record,
    record_map=R783DS,
)
"""X'20' disconnect time of at least one device invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dstx`(`R783DSTX`)
    Record: `SMF78S3`
    Map: `R783DS`

X'20' disconnect time of at least one device invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
disconnect_time_invalid.__doc__ = """X'20' disconnect time of at least one device invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783dstx`(`R783DSTX`)
    Record: `SMF78S3`
    Map: `R783DS`

X'20' disconnect time of at least one device invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r783qsm : Final[Field] = Field(
    name='r783qsm',
    origin='R783QSM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Q'd SUM on CU-HDR queue

SMF Info
--------
    Field: `R783QSM`
    Record: `SMF78S3`
    Map: `R783DS`

Q'd SUM on CU-HDR queue
"""
r783qsm.__doc__ = """Q'd SUM on CU-HDR queue

SMF Info
--------
    Field: `R783QSM`
    Record: `SMF78S3`
    Map: `R783DS`

Q'd SUM on CU-HDR queue
"""

r783qct : Final[Field] = Field(
    name='r783qct',
    origin='R783QCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Q'd COUNT on CU-HDR queue

SMF Info
--------
    Field: `R783QCT`
    Record: `SMF78S3`
    Map: `R783DS`

Q'd COUNT on CU-HDR queue
"""
r783qct.__doc__ = """Q'd COUNT on CU-HDR queue

SMF Info
--------
    Field: `R783QCT`
    Record: `SMF78S3`
    Map: `R783DS`

Q'd COUNT on CU-HDR queue
"""

r783mcmn : Final[Field] = Field(
    name='r783mcmn',
    origin='R783MCMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Minimum number of DCM managed channels used

SMF Info
--------
    Field: `R783MCMN`
    Record: `SMF78S3`
    Map: `R783DS`

Minimum number of DCM managed channels used
"""
r783mcmn.__doc__ = """Minimum number of DCM managed channels used

SMF Info
--------
    Field: `R783MCMN`
    Record: `SMF78S3`
    Map: `R783DS`

Minimum number of DCM managed channels used
"""

r783mcmx : Final[Field] = Field(
    name='r783mcmx',
    origin='R783MCMX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Maximum number of DCM managed channels used

SMF Info
--------
    Field: `R783MCMX`
    Record: `SMF78S3`
    Map: `R783DS`

Maximum number of DCM managed channels used
"""
r783mcmx.__doc__ = """Maximum number of DCM managed channels used

SMF Info
--------
    Field: `R783MCMX`
    Record: `SMF78S3`
    Map: `R783DS`

Maximum number of DCM managed channels used
"""

r783mcdf : Final[Field] = Field(
    name='r783mcdf',
    origin='R783MCDF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Defined number of DCM managed channels

SMF Info
--------
    Field: `R783MCDF`
    Record: `SMF78S3`
    Map: `R783DS`

Defined number of DCM managed channels
"""
r783mcdf.__doc__ = """Defined number of DCM managed channels

SMF Info
--------
    Field: `R783MCDF`
    Record: `SMF78S3`
    Map: `R783DS`

Defined number of DCM managed channels
"""

r783ptm : Final[Field] = Field(
    name='r783ptm',
    origin='R783PTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated path taken count for DCM managed channels

SMF Info
--------
    Field: `R783PTM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated path taken count for DCM managed channels
"""
r783ptm.__doc__ = """Accumulated path taken count for DCM managed channels

SMF Info
--------
    Field: `R783PTM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated path taken count for DCM managed channels
"""

r783dpbm : Final[Field] = Field(
    name='r783dpbm',
    origin='R783DPBM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated director port busy count for DCM managed channels

SMF Info
--------
    Field: `R783DPBM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated director port busy count for DCM managed channels
"""
r783dpbm.__doc__ = """Accumulated director port busy count for DCM managed channels

SMF Info
--------
    Field: `R783DPBM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated director port busy count for DCM managed channels
"""

r783cubm : Final[Field] = Field(
    name='r783cubm',
    origin='R783CUBM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated control unit busy count for DCM managed channels

SMF Info
--------
    Field: `R783CUBM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated control unit busy count for DCM managed channels
"""
r783cubm.__doc__ = """Accumulated control unit busy count for DCM managed channels

SMF Info
--------
    Field: `R783CUBM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated control unit busy count for DCM managed channels
"""

r783cbtm : Final[Field] = Field(
    name='r783cbtm',
    origin='R783CBTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated Control unit Busy delay Time for DCM Managed channels valid if R783CPXM=1

SMF Info
--------
    Field: `R783CBTM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated Control unit Busy delay Time for DCM Managed channels valid if R783CPXM=1
"""
r783cbtm.__doc__ = """Accumulated Control unit Busy delay Time for DCM Managed channels valid if R783CPXM=1

SMF Info
--------
    Field: `R783CBTM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated Control unit Busy delay Time for DCM Managed channels valid if R783CPXM=1
"""

r783cmrm : Final[Field] = Field(
    name='r783cmrm',
    origin='R783CMRM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated initial Command Response time for DCM Managed channels valid if R783CPXM=1 and R783GCMR=1

SMF Info
--------
    Field: `R783CMRM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated initial Command Response time for DCM Managed channels valid if R783CPXM=1 and R783GCMR=1
"""
r783cmrm.__doc__ = """Accumulated initial Command Response time for DCM Managed channels valid if R783CPXM=1 and R783GCMR=1

SMF Info
--------
    Field: `R783CMRM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated initial Command Response time for DCM Managed channels valid if R783CPXM=1 and R783GCMR=1
"""

r783sbsm : Final[Field] = Field(
    name='r783sbsm',
    origin='R783SBSM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated Switch Busy count summation for DCM Managed channels valid if R783CPXM=1

SMF Info
--------
    Field: `R783SBSM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated Switch Busy count summation for DCM Managed channels valid if R783CPXM=1
"""
r783sbsm.__doc__ = """Accumulated Switch Busy count summation for DCM Managed channels valid if R783CPXM=1

SMF Info
--------
    Field: `R783SBSM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated Switch Busy count summation for DCM Managed channels valid if R783CPXM=1
"""

r783dctm : Final[Field] = Field(
    name='r783dctm',
    origin='R783DCTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated device connect time for this LCU in units of 128 microseconds

SMF Info
--------
    Field: `R783DCTM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated device connect time for this LCU in units of 128 microseconds
"""
r783dctm.__doc__ = """Accumulated device connect time for this LCU in units of 128 microseconds

SMF Info
--------
    Field: `R783DCTM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated device connect time for this LCU in units of 128 microseconds
"""

r783ddtm : Final[Field] = Field(
    name='r783ddtm',
    origin='R783DDTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated device disconnect time for this LCU in units of 128 microseconds

SMF Info
--------
    Field: `R783DDTM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated device disconnect time for this LCU in units of 128 microseconds
"""
r783ddtm.__doc__ = """Accumulated device disconnect time for this LCU in units of 128 microseconds

SMF Info
--------
    Field: `R783DDTM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated device disconnect time for this LCU in units of 128 microseconds
"""

r783csst : Final[Field] = Field(
    name='r783csst',
    origin='R783CSST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Channel Subsystem Wait Time in units of 128 microseconds valid if R783CPXM=1

SMF Info
--------
    Field: `R783CSST`
    Record: `SMF78S3`
    Map: `R783DS`

Channel Subsystem Wait Time in units of 128 microseconds valid if R783CPXM=1
"""
r783csst.__doc__ = """Channel Subsystem Wait Time in units of 128 microseconds valid if R783CPXM=1

SMF Info
--------
    Field: `R783CSST`
    Record: `SMF78S3`
    Map: `R783DS`

Channel Subsystem Wait Time in units of 128 microseconds valid if R783CPXM=1
"""

r783hcnt : Final[Field] = Field(
    name='r783hcnt',
    origin='R783HCNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Number of HyperPAV sections for that LCU

SMF Info
--------
    Field: `R783HCNT`
    Record: `SMF78S3`
    Map: `R783DS`

Number of HyperPAV sections for that LCU
"""
r783hcnt.__doc__ = """Number of HyperPAV sections for that LCU

SMF Info
--------
    Field: `R783HCNT`
    Record: `SMF78S3`
    Map: `R783DS`

Number of HyperPAV sections for that LCU
"""

r783hix : Final[Field] = Field(
    name='r783hix',
    origin='R783HIX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Index to first HyperPAV section of that LCU

SMF Info
--------
    Field: `R783HIX`
    Record: `SMF78S3`
    Map: `R783DS`

Index to first HyperPAV section of that LCU
"""
r783hix.__doc__ = """Index to first HyperPAV section of that LCU

SMF Info
--------
    Field: `R783HIX`
    Record: `SMF78S3`
    Map: `R783DS`

Index to first HyperPAV section of that LCU
"""

r783tmwm : Final[Field] = Field(
    name='r783tmwm',
    origin='R783TMWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated transport mode write count for DCM managed channels valid if R783CPTD=1

SMF Info
--------
    Field: `R783TMWM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated transport mode write count for DCM managed channels valid if R783CPTD=1
"""
r783tmwm.__doc__ = """Accumulated transport mode write count for DCM managed channels valid if R783CPTD=1

SMF Info
--------
    Field: `R783TMWM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated transport mode write count for DCM managed channels valid if R783CPTD=1
"""

r783trdm : Final[Field] = Field(
    name='r783trdm',
    origin='R783TRDM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783DS,
)
"""Accumulated first-transfer ready-disabled write count for DCM managed channels valid if R783CPTD=1

SMF Info
--------
    Field: `R783TRDM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated first-transfer ready-disabled write count for DCM managed channels valid if R783CPTD=1
"""
r783trdm.__doc__ = """Accumulated first-transfer ready-disabled write count for DCM managed channels valid if R783CPTD=1

SMF Info
--------
    Field: `R783TRDM`
    Record: `SMF78S3`
    Map: `R783DS`

Accumulated first-transfer ready-disabled write count for DCM managed channels valid if R783CPTD=1
"""

r783hlcu : Final[Field] = Field(
    name='r783hlcu',
    origin='R783HLCU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783HPAV,
)
"""HyperPAV Logical control unit identifier

SMF Info
--------
    Field: `R783HLCU`
    Record: `SMF78S3`
    Map: `R783HPAV`

HyperPAV Logical control unit identifier
"""
r783hlcu.__doc__ = """HyperPAV Logical control unit identifier

SMF Info
--------
    Field: `R783HLCU`
    Record: `SMF78S3`
    Map: `R783HPAV`

HyperPAV Logical control unit identifier
"""

r783hcu : Final[Field] = Field(
    name='r783hcu',
    origin='R783HCU',
    type=FieldType.STRING,
    record=record,
    record_map=R783HPAV,
)
"""HyperPAV control unit identifier

SMF Info
--------
    Field: `R783HCU`
    Record: `SMF78S3`
    Map: `R783HPAV`

HyperPAV control unit identifier
"""
r783hcu.__doc__ = """HyperPAV control unit identifier

SMF Info
--------
    Field: `R783HCU`
    Record: `SMF78S3`
    Map: `R783HPAV`

HyperPAV control unit identifier
"""

r783hnai : Final[Field] = Field(
    name='r783hnai',
    origin='R783HNAI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The number of times an I/O could not start for an LSS because no HyperPAV-aliases were available and the device was not waiting for a reserve to be released from another system or long busy to subside (short floating point)

SMF Info
--------
    Field: `R783HNAI`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an I/O could not start for an LSS because no HyperPAV-aliases were available and the device was not waiting for a reserve to be released from another system or long busy to subside (short floating point)
"""
r783hnai.__doc__ = """The number of times an I/O could not start for an LSS because no HyperPAV-aliases were available and the device was not waiting for a reserve to be released from another system or long busy to subside (short floating point)

SMF Info
--------
    Field: `R783HNAI`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an I/O could not start for an LSS because no HyperPAV-aliases were available and the device was not waiting for a reserve to be released from another system or long busy to subside (short floating point)
"""

r783htio : Final[Field] = Field(
    name='r783htio',
    origin='R783HTIO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The total number of HyperPAV I/O requests for the LSS (short floating point)

SMF Info
--------
    Field: `R783HTIO`
    Record: `SMF78S3`
    Map: `R783HPAV`

The total number of HyperPAV I/O requests for the LSS (short floating point)
"""
r783htio.__doc__ = """The total number of HyperPAV I/O requests for the LSS (short floating point)

SMF Info
--------
    Field: `R783HTIO`
    Record: `SMF78S3`
    Map: `R783HPAV`

The total number of HyperPAV I/O requests for the LSS (short floating point)
"""

r783haiu : Final[Field] = Field(
    name='r783haiu',
    origin='R783HAIU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783HPAV,
)
"""The high water mark of the number of in-use HyperPAV-alias devices for the LSS (does not include borrowed alias devices)

SMF Info
--------
    Field: `R783HAIU`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of the number of in-use HyperPAV-alias devices for the LSS (does not include borrowed alias devices)
"""
r783haiu.__doc__ = """The high water mark of the number of in-use HyperPAV-alias devices for the LSS (does not include borrowed alias devices)

SMF Info
--------
    Field: `R783HAIU`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of the number of in-use HyperPAV-alias devices for the LSS (does not include borrowed alias devices)
"""

r783hcad : Final[Field] = Field(
    name='r783hcad',
    origin='R783HCAD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783HPAV,
)
"""The high water mark of the number of aliases concurrently in-use by one of the HyperPAV-base devices of the LSS (does include loaned alias devices)

SMF Info
--------
    Field: `R783HCAD`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of the number of aliases concurrently in-use by one of the HyperPAV-base devices of the LSS (does include loaned alias devices)
"""
r783hcad.__doc__ = """The high water mark of the number of aliases concurrently in-use by one of the HyperPAV-base devices of the LSS (does include loaned alias devices)

SMF Info
--------
    Field: `R783HCAD`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of the number of aliases concurrently in-use by one of the HyperPAV-base devices of the LSS (does include loaned alias devices)
"""

r783hioq : Final[Field] = Field(
    name='r783hioq',
    origin='R783HIOQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783HPAV,
)
"""The high water mark of I/Os queued

SMF Info
--------
    Field: `R783HIOQ`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of I/Os queued
"""
r783hioq.__doc__ = """The high water mark of I/Os queued

SMF Info
--------
    Field: `R783HIOQ`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of I/Os queued
"""

r783xanc : Final[Field] = Field(
    name='r783xanc',
    origin='R783XANC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The number of times an alias was needed to start an I/O (short floating point)

SMF Info
--------
    Field: `R783XANC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was needed to start an I/O (short floating point)
"""
r783xanc.__doc__ = """The number of times an alias was needed to start an I/O (short floating point)

SMF Info
--------
    Field: `R783XANC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was needed to start an I/O (short floating point)
"""

r783xauc : Final[Field] = Field(
    name='r783xauc',
    origin='R783XAUC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The number of times an alias was needed to start an I/O and one was used (short floating point)

SMF Info
--------
    Field: `R783XAUC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was needed to start an I/O and one was used (short floating point)
"""
r783xauc.__doc__ = """The number of times an alias was needed to start an I/O and one was used (short floating point)

SMF Info
--------
    Field: `R783XAUC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was needed to start an I/O and one was used (short floating point)
"""

r783xnhc : Final[Field] = Field(
    name='r783xnhc',
    origin='R783XNHC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The number of times an alias was needed to start an I/O, but none was available in the home LCU (short floating point)

SMF Info
--------
    Field: `R783XNHC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was needed to start an I/O, but none was available in the home LCU (short floating point)
"""
r783xnhc.__doc__ = """The number of times an alias was needed to start an I/O, but none was available in the home LCU (short floating point)

SMF Info
--------
    Field: `R783XNHC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was needed to start an I/O, but none was available in the home LCU (short floating point)
"""

r783xabc : Final[Field] = Field(
    name='r783xabc',
    origin='R783XABC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The number of times an alias was borrowed from a peer LCU (short floating point)

SMF Info
--------
    Field: `R783XABC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was borrowed from a peer LCU (short floating point)
"""
r783xabc.__doc__ = """The number of times an alias was borrowed from a peer LCU (short floating point)

SMF Info
--------
    Field: `R783XABC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was borrowed from a peer LCU (short floating point)
"""

r783xcbc : Final[Field] = Field(
    name='r783xcbc',
    origin='R783XCBC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783HPAV,
)
"""The number of aliases concurrently borrowed from peer LCUs

SMF Info
--------
    Field: `R783XCBC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of aliases concurrently borrowed from peer LCUs
"""
r783xcbc.__doc__ = """The number of aliases concurrently borrowed from peer LCUs

SMF Info
--------
    Field: `R783XCBC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of aliases concurrently borrowed from peer LCUs
"""

r783xhbc : Final[Field] = Field(
    name='r783xhbc',
    origin='R783XHBC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783HPAV,
)
"""The high water mark of concurrently borrowed aliases from peer LCUs

SMF Info
--------
    Field: `R783XHBC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of concurrently borrowed aliases from peer LCUs
"""
r783xhbc.__doc__ = """The high water mark of concurrently borrowed aliases from peer LCUs

SMF Info
--------
    Field: `R783XHBC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of concurrently borrowed aliases from peer LCUs
"""

r783xalc : Final[Field] = Field(
    name='r783xalc',
    origin='R783XALC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The number of times an alias was loaned to a peer LCU (short floating point)

SMF Info
--------
    Field: `R783XALC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was loaned to a peer LCU (short floating point)
"""
r783xalc.__doc__ = """The number of times an alias was loaned to a peer LCU (short floating point)

SMF Info
--------
    Field: `R783XALC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of times an alias was loaned to a peer LCU (short floating point)
"""

r783xclc : Final[Field] = Field(
    name='r783xclc',
    origin='R783XCLC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783HPAV,
)
"""The number of aliases concurrently loaned to peer LCUs

SMF Info
--------
    Field: `R783XCLC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of aliases concurrently loaned to peer LCUs
"""
r783xclc.__doc__ = """The number of aliases concurrently loaned to peer LCUs

SMF Info
--------
    Field: `R783XCLC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of aliases concurrently loaned to peer LCUs
"""

r783xhlc : Final[Field] = Field(
    name='r783xhlc',
    origin='R783XHLC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783HPAV,
)
"""The high water mark of concurrently loaned aliases to peer LCUs

SMF Info
--------
    Field: `R783XHLC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of concurrently loaned aliases to peer LCUs
"""
r783xhlc.__doc__ = """The high water mark of concurrently loaned aliases to peer LCUs

SMF Info
--------
    Field: `R783XHLC`
    Record: `SMF78S3`
    Map: `R783HPAV`

The high water mark of concurrently loaned aliases to peer LCUs
"""

r783xnag : Final[Field] = Field(
    name='r783xnag',
    origin='R783XNAG',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The number of attempts that were made to borrow an alias from peer LCUs but none were available (short floating point)

SMF Info
--------
    Field: `R783XNAG`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of attempts that were made to borrow an alias from peer LCUs but none were available (short floating point)
"""
r783xnag.__doc__ = """The number of attempts that were made to borrow an alias from peer LCUs but none were available (short floating point)

SMF Info
--------
    Field: `R783XNAG`
    Record: `SMF78S3`
    Map: `R783HPAV`

The number of attempts that were made to borrow an alias from peer LCUs but none were available (short floating point)
"""

r783xcqd : Final[Field] = Field(
    name='r783xcqd',
    origin='R783XCQD',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The cumulative number of I/Os queued at the subsystem level when aliases were needed (short floating point)

SMF Info
--------
    Field: `R783XCQD`
    Record: `SMF78S3`
    Map: `R783HPAV`

The cumulative number of I/Os queued at the subsystem level when aliases were needed (short floating point)
"""
r783xcqd.__doc__ = """The cumulative number of I/Os queued at the subsystem level when aliases were needed (short floating point)

SMF Info
--------
    Field: `R783XCQD`
    Record: `SMF78S3`
    Map: `R783HPAV`

The cumulative number of I/Os queued at the subsystem level when aliases were needed (short floating point)
"""

r783xciu : Final[Field] = Field(
    name='r783xciu',
    origin='R783XCIU',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783HPAV,
)
"""The cumulative number of aliases defined to this subsystem that were in use when aliases were needed (short floating point)

SMF Info
--------
    Field: `R783XCIU`
    Record: `SMF78S3`
    Map: `R783HPAV`

The cumulative number of aliases defined to this subsystem that were in use when aliases were needed (short floating point)
"""
r783xciu.__doc__ = """The cumulative number of aliases defined to this subsystem that were in use when aliases were needed (short floating point)

SMF Info
--------
    Field: `R783XCIU`
    Record: `SMF78S3`
    Map: `R783HPAV`

The cumulative number of aliases defined to this subsystem that were in use when aliases were needed (short floating point)
"""

r783iqid : Final[Field] = Field(
    name='r783iqid',
    origin='R783IQID',
    type=FieldType.STRING,
    record=record,
    record_map=R783IQD,
)
"""IOP initiative queue identifier

SMF Info
--------
    Field: `R783IQID`
    Record: `SMF78S3`
    Map: `R783IQD`

IOP initiative queue identifier
"""
r783iqid.__doc__ = """IOP initiative queue identifier

SMF Info
--------
    Field: `R783IQID`
    Record: `SMF78S3`
    Map: `R783IQD`

IOP initiative queue identifier
"""

r783iflg : Final[Field] = Field(
    name='r783iflg',
    origin='R783IFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R783IQD,
)
"""IOP flags

SMF Info
--------
    Field: `R783IFLG`
    Record: `SMF78S3`
    Map: `R783IQD`

IOP flags
"""
r783iflg.__doc__ = """IOP flags

SMF Info
--------
    Field: `R783IFLG`
    Record: `SMF78S3`
    Map: `R783IQD`

IOP flags
"""

iop_installed : Final[Field] = Field(
    name='iop_installed',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r783iflg,
    record=record,
    record_map=R783IQD,
)
"""= 1, if IOP is installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783iflg`(`R783IFLG`)
    Record: `SMF78S3`
    Map: `R783IQD`

= 1, if IOP is installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
iop_installed.__doc__ = """= 1, if IOP is installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783iflg`(`R783IFLG`)
    Record: `SMF78S3`
    Map: `R783IQD`

= 1, if IOP is installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

entries_iop_queue : Final[Field] = Field(
    name='entries_iop_queue',
    origin='R783IQSM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783IQD,
)
"""Sum of number of entries placed on the IOP initiative queue

SMF Info
--------
    Field: `R783IQSM`
    Record: `SMF78S3`
    Map: `R783IQD`

Sum of number of entries placed on the IOP initiative queue
"""
entries_iop_queue.__doc__ = """Sum of number of entries placed on the IOP initiative queue

SMF Info
--------
    Field: `R783IQSM`
    Record: `SMF78S3`
    Map: `R783IQD`

Sum of number of entries placed on the IOP initiative queue
"""

r783iqct : Final[Field] = Field(
    name='r783iqct',
    origin='R783IQCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783IQD,
)
"""Count of number of entries placed on the IOP initiative queue

SMF Info
--------
    Field: `R783IQCT`
    Record: `SMF78S3`
    Map: `R783IQD`

Count of number of entries placed on the IOP initiative queue
"""
r783iqct.__doc__ = """Count of number of entries placed on the IOP initiative queue

SMF Info
--------
    Field: `R783IQCT`
    Record: `SMF78S3`
    Map: `R783IQD`

Count of number of entries placed on the IOP initiative queue
"""

r783iipb : Final[Field] = Field(
    name='r783iipb',
    origin='R783IIPB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of times the I/O processor was busy, (long floating point)

SMF Info
--------
    Field: `R783IIPB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times the I/O processor was busy, (long floating point)
"""
r783iipb.__doc__ = """Number of times the I/O processor was busy, (long floating point)

SMF Info
--------
    Field: `R783IIPB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times the I/O processor was busy, (long floating point)
"""

r783iipi : Final[Field] = Field(
    name='r783iipi',
    origin='R783IIPI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of times the I/O processor was idle, (long floating point)

SMF Info
--------
    Field: `R783IIPI`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times the I/O processor was idle, (long floating point)
"""
r783iipi.__doc__ = """Number of times the I/O processor was idle, (long floating point)

SMF Info
--------
    Field: `R783IIPI`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times the I/O processor was idle, (long floating point)
"""

r783iifs : Final[Field] = Field(
    name='r783iifs',
    origin='R783IIFS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of I/O functions initially started, (long floating point)

SMF Info
--------
    Field: `R783IIFS`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of I/O functions initially started, (long floating point)
"""
r783iifs.__doc__ = """Number of I/O functions initially started, (long floating point)

SMF Info
--------
    Field: `R783IIFS`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of I/O functions initially started, (long floating point)
"""

r783ipii : Final[Field] = Field(
    name='r783ipii',
    origin='R783IPII',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of processed I/O interrupts, (long floating point)

SMF Info
--------
    Field: `R783IPII`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of processed I/O interrupts, (long floating point)
"""
r783ipii.__doc__ = """Number of processed I/O interrupts, (long floating point)

SMF Info
--------
    Field: `R783IPII`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of processed I/O interrupts, (long floating point)
"""

r783icpb : Final[Field] = Field(
    name='r783icpb',
    origin='R783ICPB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of times an I/O was retried due to channel path busy, (long floating point)

SMF Info
--------
    Field: `R783ICPB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times an I/O was retried due to channel path busy, (long floating point)
"""
r783icpb.__doc__ = """Number of times an I/O was retried due to channel path busy, (long floating point)

SMF Info
--------
    Field: `R783ICPB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times an I/O was retried due to channel path busy, (long floating point)
"""

r783idpb : Final[Field] = Field(
    name='r783idpb',
    origin='R783IDPB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of times an I/O was retried due to director port busy, (long floating point)

SMF Info
--------
    Field: `R783IDPB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times an I/O was retried due to director port busy, (long floating point)
"""
r783idpb.__doc__ = """Number of times an I/O was retried due to director port busy, (long floating point)

SMF Info
--------
    Field: `R783IDPB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times an I/O was retried due to director port busy, (long floating point)
"""

r783icub : Final[Field] = Field(
    name='r783icub',
    origin='R783ICUB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of times an I/O was retried due to control unit busy, (long floating point)

SMF Info
--------
    Field: `R783ICUB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times an I/O was retried due to control unit busy, (long floating point)
"""
r783icub.__doc__ = """Number of times an I/O was retried due to control unit busy, (long floating point)

SMF Info
--------
    Field: `R783ICUB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times an I/O was retried due to control unit busy, (long floating point)
"""

r783idvb : Final[Field] = Field(
    name='r783idvb',
    origin='R783IDVB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of times an I/O was retried due to device busy, (long floating point)

SMF Info
--------
    Field: `R783IDVB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times an I/O was retried due to device busy, (long floating point)
"""
r783idvb.__doc__ = """Number of times an I/O was retried due to device busy, (long floating point)

SMF Info
--------
    Field: `R783IDVB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times an I/O was retried due to device busy, (long floating point)
"""

r783iscb : Final[Field] = Field(
    name='r783iscb',
    origin='R783ISCB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of times the I/O processor was busy with SCM operations (long floating point)

SMF Info
--------
    Field: `R783ISCB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times the I/O processor was busy with SCM operations (long floating point)
"""
r783iscb.__doc__ = """Number of times the I/O processor was busy with SCM operations (long floating point)

SMF Info
--------
    Field: `R783ISCB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times the I/O processor was busy with SCM operations (long floating point)
"""

r783iecb : Final[Field] = Field(
    name='r783iecb',
    origin='R783IECB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R783IQD,
)
"""Number of times the I/O processor was busy with compression or decompression (long floating point)

SMF Info
--------
    Field: `R783IECB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times the I/O processor was busy with compression or decompression (long floating point)
"""
r783iecb.__doc__ = """Number of times the I/O processor was busy with compression or decompression (long floating point)

SMF Info
--------
    Field: `R783IECB`
    Record: `SMF78S3`
    Map: `R783IQD`

Number of times the I/O processor was busy with compression or decompression (long floating point)
"""

r783cpid : Final[Field] = Field(
    name='r783cpid',
    origin='R783CPID',
    type=FieldType.STRING,
    record=record,
    record_map=R783CPD,
)
"""Channel path identifier

SMF Info
--------
    Field: `R783CPID`
    Record: `SMF78S3`
    Map: `R783CPD`

Channel path identifier
"""
r783cpid.__doc__ = """Channel path identifier

SMF Info
--------
    Field: `R783CPID`
    Record: `SMF78S3`
    Map: `R783CPD`

Channel path identifier
"""

r783cpst : Final[Field] = Field(
    name='r783cpst',
    origin='R783CPST',
    type=FieldType.STRING,
    record=record,
    record_map=R783CPD,
)
"""Channel path status

SMF Info
--------
    Field: `R783CPST`
    Record: `SMF78S3`
    Map: `R783CPD`

Channel path status
"""
r783cpst.__doc__ = """Channel path status

SMF Info
--------
    Field: `R783CPST`
    Record: `SMF78S3`
    Map: `R783CPD`

Channel path status
"""

ch_path_installed : Final[Field] = Field(
    name='ch_path_installed',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r783cpst,
    record=record,
    record_map=R783CPD,
)
"""X'80' Channel path installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'80' Channel path installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
ch_path_installed.__doc__ = """X'80' Channel path installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'80' Channel path installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

ch_path_online : Final[Field] = Field(
    name='ch_path_online',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r783cpst,
    record=record,
    record_map=R783CPD,
)
"""X'40' Channel path online(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'40' Channel path online

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
ch_path_online.__doc__ = """X'40' Channel path online(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'40' Channel path online

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

ch_path_varied : Final[Field] = Field(
    name='ch_path_varied',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r783cpst,
    record=record,
    record_map=R783CPD,
)
"""X'20' Channel path varied(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'20' Channel path varied

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
ch_path_varied.__doc__ = """X'20' Channel path varied(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'20' Channel path varied

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ch_path_offline : Final[Field] = Field(
    name='ch_path_offline',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r783cpst,
    record=record,
    record_map=R783CPD,
)
"""X'10' This channel path is offline to all devices to the LCU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'10' This channel path is offline to all devices to the LCU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ch_path_offline.__doc__ = """X'10' This channel path is offline to all devices to the LCU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'10' This channel path is offline to all devices to the LCU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

vary_path_action : Final[Field] = Field(
    name='vary_path_action',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r783cpst,
    record=record,
    record_map=R783CPD,
)
"""X'08' The connectivity of this channel path to devices of this LCU has manipulated via VARY PATH during this measurement interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'08' The connectivity of this channel path to devices of this LCU has manipulated via VARY PATH during this measurement interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
vary_path_action.__doc__ = """X'08' The connectivity of this channel path to devices of this LCU has manipulated via VARY PATH during this measurement interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'08' The connectivity of this channel path to devices of this LCU has manipulated via VARY PATH during this measurement interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ch_path_data_invalid : Final[Field] = Field(
    name='ch_path_data_invalid',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r783cpst,
    record=record,
    record_map=R783CPD,
)
"""X'04' Measured channel path data invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'04' Measured channel path data invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ch_path_data_invalid.__doc__ = """X'04' Measured channel path data invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'04' Measured channel path data invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ch_path_dcm : Final[Field] = Field(
    name='ch_path_dcm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r783cpst,
    record=record,
    record_map=R783CPD,
)
"""X'02' Channel path is DCM managed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'02' Channel path is DCM managed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ch_path_dcm.__doc__ = """X'02' Channel path is DCM managed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'02' Channel path is DCM managed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

chpid_manipulated : Final[Field] = Field(
    name='chpid_manipulated',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r783cpst,
    record=record,
    record_map=R783CPD,
)
"""X'01' CHPID manipulated, requiring data reset(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'01' CHPID manipulated, requiring data reset

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
chpid_manipulated.__doc__ = """X'01' CHPID manipulated, requiring data reset(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpst`(`R783CPST`)
    Record: `SMF78S3`
    Map: `R783CPD`

X'01' CHPID manipulated, requiring data reset

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r783cun : Final[Field] = Field(
    name='r783cun',
    origin='R783CUN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""Number of control units attached

SMF Info
--------
    Field: `R783CUN`
    Record: `SMF78S3`
    Map: `R783CPD`

Number of control units attached
"""
r783cun.__doc__ = """Number of control units attached

SMF Info
--------
    Field: `R783CUN`
    Record: `SMF78S3`
    Map: `R783CPD`

Number of control units attached
"""

r783cu1 : Final[Field] = Field(
    name='r783cu1',
    origin='R783CU1',
    type=FieldType.STRING,
    record=record,
    record_map=R783CPD,
)
"""1st ctrl unit identifier

SMF Info
--------
    Field: `R783CU1`
    Record: `SMF78S3`
    Map: `R783CPD`

1st ctrl unit identifier
"""
r783cu1.__doc__ = """1st ctrl unit identifier

SMF Info
--------
    Field: `R783CU1`
    Record: `SMF78S3`
    Map: `R783CPD`

1st ctrl unit identifier
"""

r783cu2 : Final[Field] = Field(
    name='r783cu2',
    origin='R783CU2',
    type=FieldType.STRING,
    record=record,
    record_map=R783CPD,
)
"""2nd ctrl unit identifier

SMF Info
--------
    Field: `R783CU2`
    Record: `SMF78S3`
    Map: `R783CPD`

2nd ctrl unit identifier
"""
r783cu2.__doc__ = """2nd ctrl unit identifier

SMF Info
--------
    Field: `R783CU2`
    Record: `SMF78S3`
    Map: `R783CPD`

2nd ctrl unit identifier
"""

r783cu3 : Final[Field] = Field(
    name='r783cu3',
    origin='R783CU3',
    type=FieldType.STRING,
    record=record,
    record_map=R783CPD,
)
"""3rd ctrl unit identifier

SMF Info
--------
    Field: `R783CU3`
    Record: `SMF78S3`
    Map: `R783CPD`

3rd ctrl unit identifier
"""
r783cu3.__doc__ = """3rd ctrl unit identifier

SMF Info
--------
    Field: `R783CU3`
    Record: `SMF78S3`
    Map: `R783CPD`

3rd ctrl unit identifier
"""

r783cu4 : Final[Field] = Field(
    name='r783cu4',
    origin='R783CU4',
    type=FieldType.STRING,
    record=record,
    record_map=R783CPD,
)
"""4th ctrl unit identifier

SMF Info
--------
    Field: `R783CU4`
    Record: `SMF78S3`
    Map: `R783CPD`

4th ctrl unit identifier
"""
r783cu4.__doc__ = """4th ctrl unit identifier

SMF Info
--------
    Field: `R783CU4`
    Record: `SMF78S3`
    Map: `R783CPD`

4th ctrl unit identifier
"""

r783cub : Final[Field] = Field(
    name='r783cub',
    origin='R783CUB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""Count of control unit busy

SMF Info
--------
    Field: `R783CUB`
    Record: `SMF78S3`
    Map: `R783CPD`

Count of control unit busy
"""
r783cub.__doc__ = """Count of control unit busy

SMF Info
--------
    Field: `R783CUB`
    Record: `SMF78S3`
    Map: `R783CPD`

Count of control unit busy
"""

r783pt : Final[Field] = Field(
    name='r783pt',
    origin='R783PT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""Count of channel path taken

SMF Info
--------
    Field: `R783PT`
    Record: `SMF78S3`
    Map: `R783CPD`

Count of channel path taken
"""
r783pt.__doc__ = """Count of channel path taken

SMF Info
--------
    Field: `R783PT`
    Record: `SMF78S3`
    Map: `R783CPD`

Count of channel path taken
"""

r783dpb : Final[Field] = Field(
    name='r783dpb',
    origin='R783DPB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""ESCON Director port busy count

SMF Info
--------
    Field: `R783DPB`
    Record: `SMF78S3`
    Map: `R783CPD`

ESCON Director port busy count
"""
r783dpb.__doc__ = """ESCON Director port busy count

SMF Info
--------
    Field: `R783DPB`
    Record: `SMF78S3`
    Map: `R783CPD`

ESCON Director port busy count
"""

r783cbt : Final[Field] = Field(
    name='r783cbt',
    origin='R783CBT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""Control Unit busy delay time in units of 128 microseconds valid if R783CPXM=1

SMF Info
--------
    Field: `R783CBT`
    Record: `SMF78S3`
    Map: `R783CPD`

Control Unit busy delay time in units of 128 microseconds valid if R783CPXM=1
"""
r783cbt.__doc__ = """Control Unit busy delay time in units of 128 microseconds valid if R783CPXM=1

SMF Info
--------
    Field: `R783CBT`
    Record: `SMF78S3`
    Map: `R783CPD`

Control Unit busy delay time in units of 128 microseconds valid if R783CPXM=1
"""

r783cmr : Final[Field] = Field(
    name='r783cmr',
    origin='R783CMR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""Initial Command Response time in units of 128 microseconds valid if R783CPXM=1 and R783GCMR=1

SMF Info
--------
    Field: `R783CMR`
    Record: `SMF78S3`
    Map: `R783CPD`

Initial Command Response time in units of 128 microseconds valid if R783CPXM=1 and R783GCMR=1
"""
r783cmr.__doc__ = """Initial Command Response time in units of 128 microseconds valid if R783CPXM=1 and R783GCMR=1

SMF Info
--------
    Field: `R783CMR`
    Record: `SMF78S3`
    Map: `R783CPD`

Initial Command Response time in units of 128 microseconds valid if R783CPXM=1 and R783GCMR=1
"""

r783sbs : Final[Field] = Field(
    name='r783sbs',
    origin='R783SBS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""Switch Busy count Summation contains the switch busy counts received for all partitions valid if R783CPXM=1

SMF Info
--------
    Field: `R783SBS`
    Record: `SMF78S3`
    Map: `R783CPD`

Switch Busy count Summation contains the switch busy counts received for all partitions valid if R783CPXM=1
"""
r783sbs.__doc__ = """Switch Busy count Summation contains the switch busy counts received for all partitions valid if R783CPXM=1

SMF Info
--------
    Field: `R783SBS`
    Record: `SMF78S3`
    Map: `R783CPD`

Switch Busy count Summation contains the switch busy counts received for all partitions valid if R783CPXM=1
"""

r783cpxf : Final[Field] = Field(
    name='r783cpxf',
    origin='R783CPXF',
    type=FieldType.STRING,
    record=record,
    record_map=R783CPD,
)
"""Channel Path extended flags

SMF Info
--------
    Field: `R783CPXF`
    Record: `SMF78S3`
    Map: `R783CPD`

Channel Path extended flags
"""
r783cpxf.__doc__ = """Channel Path extended flags

SMF Info
--------
    Field: `R783CPXF`
    Record: `SMF78S3`
    Map: `R783CPD`

Channel Path extended flags
"""

extended_io_mesurment1 : Final[Field] = Field(
    name='extended_io_mesurment1',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r783cpxf,
    record=record,
    record_map=R783CPD,
)
"""1= extended I/O measurement-block format-1 data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpxf`(`R783CPXF`)
    Record: `SMF78S3`
    Map: `R783CPD`

1= extended I/O measurement-block format-1 data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
extended_io_mesurment1.__doc__ = """1= extended I/O measurement-block format-1 data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpxf`(`R783CPXF`)
    Record: `SMF78S3`
    Map: `R783CPD`

1= extended I/O measurement-block format-1 data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

extended_io_mesurment2 : Final[Field] = Field(
    name='extended_io_mesurment2',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r783cpxf,
    record=record,
    record_map=R783CPD,
)
"""1= extended I/O measurement-block format-2 data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpxf`(`R783CPXF`)
    Record: `SMF78S3`
    Map: `R783CPD`

1= extended I/O measurement-block format-2 data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
extended_io_mesurment2.__doc__ = """1= extended I/O measurement-block format-2 data available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpxf`(`R783CPXF`)
    Record: `SMF78S3`
    Map: `R783CPD`

1= extended I/O measurement-block format-2 data available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

first_transfer_ready_disabled : Final[Field] = Field(
    name='first_transfer_ready_disabled',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r783cpxf,
    record=record,
    record_map=R783CPD,
)
"""1= First-transfer-ready disabled supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpxf`(`R783CPXF`)
    Record: `SMF78S3`
    Map: `R783CPD`

1= First-transfer-ready disabled supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
first_transfer_ready_disabled.__doc__ = """1= First-transfer-ready disabled supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r783cpxf`(`R783CPXF`)
    Record: `SMF78S3`
    Map: `R783CPD`

1= First-transfer-ready disabled supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

path_attributes : Final[Field] = Field(
    name='path_attributes',
    origin='R783CPAT',
    post='core.map',
    post_param={'map': {0: 'no_attributes', 1: 'preferred_path', 2: 'no_preferred_path'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""Path attributes: 0 = No attributes specified, 1 = Preferred path, 2 = Non-preferred path

SMF Info
--------
    Field: `R783CPAT`
    Record: `SMF78S3`
    Map: `R783CPD`

Path attributes: 0 = No attributes specified, 1 = Preferred path, 2 = Non-preferred path

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    0 => no_attributes
    1 => preferred_path
    2 => no_preferred_path
"""
path_attributes.__doc__ = """Path attributes: 0 = No attributes specified, 1 = Preferred path, 2 = Non-preferred path

SMF Info
--------
    Field: `R783CPAT`
    Record: `SMF78S3`
    Map: `R783CPD`

Path attributes: 0 = No attributes specified, 1 = Preferred path, 2 = Non-preferred path

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    0 => no_attributes
    1 => preferred_path
    2 => no_preferred_path
"""

r783ctmw : Final[Field] = Field(
    name='r783ctmw',
    origin='R783CTMW',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""Transport mode write count valid if R783CPTD=1

SMF Info
--------
    Field: `R783CTMW`
    Record: `SMF78S3`
    Map: `R783CPD`

Transport mode write count valid if R783CPTD=1
"""
r783ctmw.__doc__ = """Transport mode write count valid if R783CPTD=1

SMF Info
--------
    Field: `R783CTMW`
    Record: `SMF78S3`
    Map: `R783CPD`

Transport mode write count valid if R783CPTD=1
"""

r783ctrd : Final[Field] = Field(
    name='r783ctrd',
    origin='R783CTRD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R783CPD,
)
"""First-transfer-ready disabled write count valid if R783CPTD=1

SMF Info
--------
    Field: `R783CTRD`
    Record: `SMF78S3`
    Map: `R783CPD`

First-transfer-ready disabled write count valid if R783CPTD=1
"""
r783ctrd.__doc__ = """First-transfer-ready disabled write count valid if R783CPTD=1

SMF Info
--------
    Field: `R783CTRD`
    Record: `SMF78S3`
    Map: `R783CPD`

First-transfer-ready disabled write count valid if R783CPTD=1
"""
