# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 99 Subtype 6"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=99,
                                smf_subtype=6,
                                spec='SMF 99 Subtype 6',
                                post=None)
"""SMF 99 Subtype 6"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF99_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_SDEF_MAP',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 self defining Section',
    post=None,
    record_mapping=False)
"""SMF99 self defining Section"""
SMF99_PRODUCT_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_PRODUCT_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Product Information Section',
    post=None,
    record_mapping=False)
"""SMF99 Product Information Section"""
SMF99_S6_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S6_SDEF_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Subtype 6 self defining section',
    post=None,
    record_mapping=False)
"""SMF99 Subtype 6 self defining section"""
SMF99_S6_PER_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S6_PER_MAP',
    record=record,
    parent=SMF99_S6_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 6 Period data section - BASED(addr(smf_hdr_MAP) + smf992...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 6 Period data section - BASED(addr(smf_hdr_MAP) + smf992..."""
SMF99_S6_SERVER_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S6_SERVER_MAP',
    record=record,
    parent=SMF99_S6_PER_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 SUBTYPE 6 SERVER SECTION. BASED(ADDR(SMF_HDR_MAP) + SMF996_SERVE...',
    post=None,
    record_mapping=False)
"""SMF99 SUBTYPE 6 SERVER SECTION. BASED(ADDR(SMF_HDR_MAP) + SMF996_SERVE..."""

date : Final[Field] = Field(
    name='date',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S6`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S6`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S6`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S6`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S6`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S6`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF99LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S6`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""
len.__doc__ = """Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S6`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF99SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S6`
    Map: Not part of a map

Segment descriptor (see record length field)
"""
seg.__doc__ = """Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S6`
    Map: Not part of a map

Segment descriptor (see record length field)
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF99FLG',
    type=FieldType.STRING,
    record=record,
)
"""System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S6`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""
flg.__doc__ = """System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S6`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""

stu : Final[Field] = Field(
    name='stu',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S6`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
stu.__doc__ = """Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S6`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF99RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S6`
    Map: Not part of a map

Record type 99
"""
rty.__doc__ = """Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S6`
    Map: Not part of a map

Record type 99
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S6`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""
tme.__doc__ = """Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S6`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S6`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""
dte.__doc__ = """Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S6`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF99SID',
    type=FieldType.STRING,
    record=record,
)
"""System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S6`
    Map: Not part of a map

System identification (from the SID parameter).
"""
sid.__doc__ = """System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S6`
    Map: Not part of a map

System identification (from the SID parameter).
"""

ssid : Final[Field] = Field(
    name='ssid',
    origin='SMF99SSID',
    type=FieldType.STRING,
    record=record,
)
"""Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S6`
    Map: Not part of a map

Sub System Identification
"""
ssid.__doc__ = """Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S6`
    Map: Not part of a map

Sub System Identification
"""

tid : Final[Field] = Field(
    name='tid',
    origin='SMF99TID',
    type=FieldType.INTEGER,
    record=record,
)
"""Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S6`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""
tid.__doc__ = """Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S6`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""

sdef_len : Final[Field] = Field(
    name='sdef_len',
    origin='SMF99_SDEF_LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S6`
    Map: Not part of a map

Length of self definition section
"""
sdef_len.__doc__ = """Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S6`
    Map: Not part of a map

Length of self definition section
"""

pof : Final[Field] = Field(
    name='pof',
    origin='SMF99POF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""
pof.__doc__ = """Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""

pln : Final[Field] = Field(
    name='pln',
    origin='SMF99PLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""
pln.__doc__ = """Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""

pon : Final[Field] = Field(
    name='pon',
    origin='SMF99PON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""
pon.__doc__ = """Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""

dof : Final[Field] = Field(
    name='dof',
    origin='SMF99DOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""
dof.__doc__ = """Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""

dln : Final[Field] = Field(
    name='dln',
    origin='SMF99DLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""
dln.__doc__ = """Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""

don : Final[Field] = Field(
    name='don',
    origin='SMF99DON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""
don.__doc__ = """Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S6`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""

vn2 : Final[Field] = Field(
    name='vn2',
    origin='SMF99VN2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""
vn2.__doc__ = """Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""

rvn : Final[Field] = Field(
    name='rvn',
    origin='SMF99RVN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""
rvn.__doc__ = """Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""

pnm : Final[Field] = Field(
    name='pnm',
    origin='SMF99PNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""
pnm.__doc__ = """Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""

slv : Final[Field] = Field(
    name='slv',
    origin='SMF99SLV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""
slv.__doc__ = """System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF99SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""
snm.__doc__ = """System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""

pflg : Final[Field] = Field(
    name='pflg',
    origin='SMF99PFLG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""
pflg.__doc__ = """Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""

record_incomplete : Final[Field] = Field(
    name='record_incomplete',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
record_incomplete.__doc__ = """Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

reasm_indicator : Final[Field] = Field(
    name='reasm_indicator',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
reasm_indicator.__doc__ = """Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S6`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

cpof : Final[Field] = Field(
    name='cpof',
    origin='SMF996CPOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_SDEF_MAP,
)
"""Offset to service class period section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF996CPOF`
    Record: `SMF99S6`
    Map: `SMF99_S6_SDEF_MAP`

Offset to service class period section from beginning of record (including RDW)
"""
cpof.__doc__ = """Offset to service class period section from beginning of record (including RDW)

SMF Info
--------
    Field: `SMF996CPOF`
    Record: `SMF99S6`
    Map: `SMF99_S6_SDEF_MAP`

Offset to service class period section from beginning of record (including RDW)
"""

cpln : Final[Field] = Field(
    name='cpln',
    origin='SMF996CPLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_SDEF_MAP,
)
"""Length of a service class period section

SMF Info
--------
    Field: `SMF996CPLN`
    Record: `SMF99S6`
    Map: `SMF99_S6_SDEF_MAP`

Length of a service class period section
"""
cpln.__doc__ = """Length of a service class period section

SMF Info
--------
    Field: `SMF996CPLN`
    Record: `SMF99S6`
    Map: `SMF99_S6_SDEF_MAP`

Length of a service class period section
"""

cpon : Final[Field] = Field(
    name='cpon',
    origin='SMF996CPON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_SDEF_MAP,
)
"""Number of service class period sections

SMF Info
--------
    Field: `SMF996CPON`
    Record: `SMF99S6`
    Map: `SMF99_S6_SDEF_MAP`

Number of service class period sections
"""
cpon.__doc__ = """Number of service class period sections

SMF Info
--------
    Field: `SMF996CPON`
    Record: `SMF99S6`
    Map: `SMF99_S6_SDEF_MAP`

Number of service class period sections
"""

eclass_name : Final[Field] = Field(
    name='eclass_name',
    origin='SMF996_ECLASS_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""External class name. For an externally defined service class this is the name defined in the service definition. For a server period this name will be of the form $SRMSxxx. For system service classes this name will be $SRMBEST, $SRMDUMP, $SRMGOOD, $SRMDISC, or $SRMQSC.

SMF Info
--------
    Field: `SMF996_ECLASS_NAME`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

External class name. For an externally defined service class this is the name defined in the service definition. For a server period this name will be of the form $SRMSxxx. For system service classes this name will be $SRMBEST, $SRMDUMP, $SRMGOOD, $SRMDISC, or $SRMQSC.
"""
eclass_name.__doc__ = """External class name. For an externally defined service class this is the name defined in the service definition. For a server period this name will be of the form $SRMSxxx. For system service classes this name will be $SRMBEST, $SRMDUMP, $SRMGOOD, $SRMDISC, or $SRMQSC.

SMF Info
--------
    Field: `SMF996_ECLASS_NAME`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

External class name. For an externally defined service class this is the name defined in the service definition. For a server period this name will be of the form $SRMSxxx. For system service classes this name will be $SRMBEST, $SRMDUMP, $SRMGOOD, $SRMDISC, or $SRMQSC.
"""

per_num : Final[Field] = Field(
    name='per_num',
    origin='SMF996_PER_NUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Period number within class

SMF Info
--------
    Field: `SMF996_PER_NUM`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Period number within class
"""
per_num.__doc__ = """Period number within class

SMF Info
--------
    Field: `SMF996_PER_NUM`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Period number within class
"""

goaltype : Final[Field] = Field(
    name='goaltype',
    origin='SMF996_GOALTYPE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""goal type: 0 - System, SYSSTC, or server goal, 1 - short response time, 2 - long response time, 3 - velocity, 4 - discretionary

SMF Info
--------
    Field: `SMF996_GOALTYPE`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

goal type: 0 - System, SYSSTC, or server goal, 1 - short response time, 2 - long response time, 3 - velocity, 4 - discretionary
"""
goaltype.__doc__ = """goal type: 0 - System, SYSSTC, or server goal, 1 - short response time, 2 - long response time, 3 - velocity, 4 - discretionary

SMF Info
--------
    Field: `SMF996_GOALTYPE`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

goal type: 0 - System, SYSSTC, or server goal, 1 - short response time, 2 - long response time, 3 - velocity, 4 - discretionary
"""

percentile : Final[Field] = Field(
    name='percentile',
    origin='SMF996_PERCENTILE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Response time goal percentile. Zero if period does not a percentile response time goal.

SMF Info
--------
    Field: `SMF996_PERCENTILE`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Response time goal percentile. Zero if period does not a percentile response time goal.
"""
percentile.__doc__ = """Response time goal percentile. Zero if period does not a percentile response time goal.

SMF Info
--------
    Field: `SMF996_PERCENTILE`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Response time goal percentile. Zero if period does not a percentile response time goal.
"""

iclass_name : Final[Field] = Field(
    name='iclass_name',
    origin='SMF996_ICLASS_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Internal service class name. Same as SMF996_ECLASS_NAME except for discretionary periods. For discretionary periods the name will be of the form $SRMDIxx.

SMF Info
--------
    Field: `SMF996_ICLASS_NAME`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Internal service class name. Same as SMF996_ECLASS_NAME except for discretionary periods. For discretionary periods the name will be of the form $SRMDIxx.
"""
iclass_name.__doc__ = """Internal service class name. Same as SMF996_ECLASS_NAME except for discretionary periods. For discretionary periods the name will be of the form $SRMDIxx.

SMF Info
--------
    Field: `SMF996_ICLASS_NAME`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Internal service class name. Same as SMF996_ECLASS_NAME except for discretionary periods. For discretionary periods the name will be of the form $SRMDIxx.
"""

goalval : Final[Field] = Field(
    name='goalval',
    origin='SMF996_GOALVAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""goal value: response time goal - goal in milliseconds, velocity - velocity, discretionary, system goal or server period - zero

SMF Info
--------
    Field: `SMF996_GOALVAL`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

goal value: response time goal - goal in milliseconds, velocity - velocity, discretionary, system goal or server period - zero
"""
goalval.__doc__ = """goal value: response time goal - goal in milliseconds, velocity - velocity, discretionary, system goal or server period - zero

SMF Info
--------
    Field: `SMF996_GOALVAL`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

goal value: response time goal - goal in milliseconds, velocity - velocity, discretionary, system goal or server period - zero
"""

impor : Final[Field] = Field(
    name='impor',
    origin='SMF996_IMPOR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Importance of service class period

SMF Info
--------
    Field: `SMF996_IMPOR`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Importance of service class period
"""
impor.__doc__ = """Importance of service class period

SMF Info
--------
    Field: `SMF996_IMPOR`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Importance of service class period
"""

dp : Final[Field] = Field(
    name='dp',
    origin='SMF996_DP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Dispatching priority of period for next policy interval

SMF Info
--------
    Field: `SMF996_DP`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Dispatching priority of period for next policy interval
"""
dp.__doc__ = """Dispatching priority of period for next policy interval

SMF Info
--------
    Field: `SMF996_DP`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Dispatching priority of period for next policy interval
"""

iodp : Final[Field] = Field(
    name='iodp',
    origin='SMF996_IODP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""I/O priority of period for next policy interval

SMF Info
--------
    Field: `SMF996_IODP`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

I/O priority of period for next policy interval
"""
iodp.__doc__ = """I/O priority of period for next policy interval

SMF Info
--------
    Field: `SMF996_IODP`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

I/O priority of period for next policy interval
"""

mpli : Final[Field] = Field(
    name='mpli',
    origin='SMF996_MPLI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""MPL in-target for next policy interval

SMF Info
--------
    Field: `SMF996_MPLI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

MPL in-target for next policy interval
"""
mpli.__doc__ = """MPL in-target for next policy interval

SMF Info
--------
    Field: `SMF996_MPLI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

MPL in-target for next policy interval
"""

mplo : Final[Field] = Field(
    name='mplo',
    origin='SMF996_MPLO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""MPL out-target for next policy interval

SMF Info
--------
    Field: `SMF996_MPLO`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

MPL out-target for next policy interval
"""
mplo.__doc__ = """MPL out-target for next policy interval

SMF Info
--------
    Field: `SMF996_MPLO`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

MPL out-target for next policy interval
"""

rua : Final[Field] = Field(
    name='rua',
    origin='SMF996_RUA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Average number of ready address spaces over last policy interval. Scaled by * 16

SMF Info
--------
    Field: `SMF996_RUA`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Average number of ready address spaces over last policy interval. Scaled by * 16
"""
rua.__doc__ = """Average number of ready address spaces over last policy interval. Scaled by * 16

SMF Info
--------
    Field: `SMF996_RUA`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Average number of ready address spaces over last policy interval. Scaled by * 16
"""

pspt : Final[Field] = Field(
    name='pspt',
    origin='SMF996_PSPT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Time swapped out address spaces in period are protected from being swapped to aux for next policy interval. In 1.024 milliseconds.

SMF Info
--------
    Field: `SMF996_PSPT`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Time swapped out address spaces in period are protected from being swapped to aux for next policy interval. In 1.024 milliseconds.
"""
pspt.__doc__ = """Time swapped out address spaces in period are protected from being swapped to aux for next policy interval. In 1.024 milliseconds.

SMF Info
--------
    Field: `SMF996_PSPT`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Time swapped out address spaces in period are protected from being swapped to aux for next policy interval. In 1.024 milliseconds.
"""

psitar : Final[Field] = Field(
    name='psitar',
    origin='SMF996_PSITAR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""storage isolation target for next policy interval for each address space in period, valid only for work with short response time goals, zero otherwise. Frame count.

SMF Info
--------
    Field: `SMF996_PSITAR`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

storage isolation target for next policy interval for each address space in period, valid only for work with short response time goals, zero otherwise. Frame count.
"""
psitar.__doc__ = """storage isolation target for next policy interval for each address space in period, valid only for work with short response time goals, zero otherwise. Frame count.

SMF Info
--------
    Field: `SMF996_PSITAR`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

storage isolation target for next policy interval for each address space in period, valid only for work with short response time goals, zero otherwise. Frame count.
"""

local_pi : Final[Field] = Field(
    name='local_pi',
    origin='SMF996_LOCAL_PI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""local performance index * 100

SMF Info
--------
    Field: `SMF996_LOCAL_PI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

local performance index * 100
"""
local_pi.__doc__ = """local performance index * 100

SMF Info
--------
    Field: `SMF996_LOCAL_PI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

local performance index * 100
"""

sysplex_pi : Final[Field] = Field(
    name='sysplex_pi',
    origin='SMF996_SYSPLEX_PI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""sysplex performance index * 100

SMF Info
--------
    Field: `SMF996_SYSPLEX_PI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

sysplex performance index * 100
"""
sysplex_pi.__doc__ = """sysplex performance index * 100

SMF Info
--------
    Field: `SMF996_SYSPLEX_PI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

sysplex performance index * 100
"""

server_data_of : Final[Field] = Field(
    name='server_data_of',
    origin='SMF996_SERVER_DATA_OF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Offset to server section from beginning of record (including RDW). Only valid if period is a server period. There will be one server section entry for each different external service class that server address spaces in this server period were originally classified to.

SMF Info
--------
    Field: `SMF996_SERVER_DATA_OF`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Offset to server section from beginning of record (including RDW). Only valid if period is a server period. There will be one server section entry for each different external service class that server address spaces in this server period were originally classified to.
"""
server_data_of.__doc__ = """Offset to server section from beginning of record (including RDW). Only valid if period is a server period. There will be one server section entry for each different external service class that server address spaces in this server period were originally classified to.

SMF Info
--------
    Field: `SMF996_SERVER_DATA_OF`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Offset to server section from beginning of record (including RDW). Only valid if period is a server period. There will be one server section entry for each different external service class that server address spaces in this server period were originally classified to.
"""

server_data_ln : Final[Field] = Field(
    name='server_data_ln',
    origin='SMF996_SERVER_DATA_LN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""LENGTH OF EACH SERVER SECTION ENTRY

SMF Info
--------
    Field: `SMF996_SERVER_DATA_LN`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

LENGTH OF EACH SERVER SECTION ENTRY
"""
server_data_ln.__doc__ = """LENGTH OF EACH SERVER SECTION ENTRY

SMF Info
--------
    Field: `SMF996_SERVER_DATA_LN`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

LENGTH OF EACH SERVER SECTION ENTRY
"""

server_data_on : Final[Field] = Field(
    name='server_data_on',
    origin='SMF996_SERVER_DATA_ON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""NUMBER OF SERVER SECTION ENTRIES

SMF Info
--------
    Field: `SMF996_SERVER_DATA_ON`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

NUMBER OF SERVER SECTION ENTRIES
"""
server_data_on.__doc__ = """NUMBER OF SERVER SECTION ENTRIES

SMF Info
--------
    Field: `SMF996_SERVER_DATA_ON`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

NUMBER OF SERVER SECTION ENTRIES
"""

pserv : Final[Field] = Field(
    name='pserv',
    origin='SMF996_PSERV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""service accumulated during interval

SMF Info
--------
    Field: `SMF996_PSERV`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

service accumulated during interval
"""
pserv.__doc__ = """service accumulated during interval

SMF Info
--------
    Field: `SMF996_PSERV`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

service accumulated during interval
"""

piserv : Final[Field] = Field(
    name='piserv',
    origin='SMF996_PISERV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""IFA service accumulated during interval

SMF Info
--------
    Field: `SMF996_PISERV`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

IFA service accumulated during interval
"""
piserv.__doc__ = """IFA service accumulated during interval

SMF Info
--------
    Field: `SMF996_PISERV`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

IFA service accumulated during interval
"""

psserv : Final[Field] = Field(
    name='psserv',
    origin='SMF996_PSSERV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""accumulated SUP service

SMF Info
--------
    Field: `SMF996_PSSERV`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

accumulated SUP service
"""
psserv.__doc__ = """accumulated SUP service

SMF Info
--------
    Field: `SMF996_PSSERV`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

accumulated SUP service
"""

time_at_pdp_using : Final[Field] = Field(
    name='time_at_pdp_using',
    origin='SMF996_TIME_AT_PDP_USING',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Time at PDP (promoted dispatch priority) using samples

SMF Info
--------
    Field: `SMF996_TIME_AT_PDP_USING`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Time at PDP (promoted dispatch priority) using samples
"""
time_at_pdp_using.__doc__ = """Time at PDP (promoted dispatch priority) using samples

SMF Info
--------
    Field: `SMF996_TIME_AT_PDP_USING`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Time at PDP (promoted dispatch priority) using samples
"""

time_at_pdp : Final[Field] = Field(
    name='time_at_pdp',
    origin='SMF996_TIME_AT_PDP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Time at PDP (promoted dispatch priority) accumulator

SMF Info
--------
    Field: `SMF996_TIME_AT_PDP`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Time at PDP (promoted dispatch priority) accumulator
"""
time_at_pdp.__doc__ = """Time at PDP (promoted dispatch priority) accumulator

SMF Info
--------
    Field: `SMF996_TIME_AT_PDP`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Time at PDP (promoted dispatch priority) accumulator
"""

flags : Final[Field] = Field(
    name='flags',
    origin='SMF996_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Flags

SMF Info
--------
    Field: `SMF996_FLAGS`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Flags
"""
flags.__doc__ = """Flags

SMF Info
--------
    Field: `SMF996_FLAGS`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Flags
"""

ewlm_managed : Final[Field] = Field(
    name='ewlm_managed',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Period is managed using EWLM performance data.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF996_FLAGS`)
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Period is managed using EWLM performance data.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
ewlm_managed.__doc__ = """Period is managed using EWLM performance data.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF996_FLAGS`)
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Period is managed using EWLM performance data.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

io_priority_group : Final[Field] = Field(
    name='io_priority_group',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Period belongs to a service class that was assigned to I/O priority group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF996_FLAGS`)
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Period belongs to a service class that was assigned to I/O priority group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
io_priority_group.__doc__ = """Period belongs to a service class that was assigned to I/O priority group(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF996_FLAGS`)
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Period belongs to a service class that was assigned to I/O priority group

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

inelighonorpriority : Final[Field] = Field(
    name='inelighonorpriority',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""Specialty engine work in this period is ineligible for "Honor Priority Processing", i.e. it will not be offloaded to CPs for help processing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF996_FLAGS`)
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Specialty engine work in this period is ineligible for "Honor Priority Processing", i.e. it will not be offloaded to CPs for help processing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
inelighonorpriority.__doc__ = """Specialty engine work in this period is ineligible for "Honor Priority Processing", i.e. it will not be offloaded to CPs for help processing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF996_FLAGS`)
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

Specialty engine work in this period is ineligible for "Honor Priority Processing", i.e. it will not be offloaded to CPs for help processing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ewlm_local_pi : Final[Field] = Field(
    name='ewlm_local_pi',
    origin='SMF996_EWLM_LOCAL_PI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""EWLM local performance index(PI)

SMF Info
--------
    Field: `SMF996_EWLM_LOCAL_PI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

EWLM local performance index(PI)
"""
ewlm_local_pi.__doc__ = """EWLM local performance index(PI)

SMF Info
--------
    Field: `SMF996_EWLM_LOCAL_PI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

EWLM local performance index(PI)
"""

ewlm_global_pi : Final[Field] = Field(
    name='ewlm_global_pi',
    origin='SMF996_EWLM_GLOBAL_PI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_PER_MAP,
)
"""EWLM global performance index(PI)

SMF Info
--------
    Field: `SMF996_EWLM_GLOBAL_PI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

EWLM global performance index(PI)
"""
ewlm_global_pi.__doc__ = """EWLM global performance index(PI)

SMF Info
--------
    Field: `SMF996_EWLM_GLOBAL_PI`
    Record: `SMF99S6`
    Map: `SMF99_S6_PER_MAP`

EWLM global performance index(PI)
"""

server_class_name : Final[Field] = Field(
    name='server_class_name',
    origin='SMF99_S6_SERVER_CLASS_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S6_SERVER_MAP,
)
"""NAME OF SERVICE CLASS THAT AT LEAST ONE OF THE SERVER ADDRESS SPACES IN THE SERVER PERIOD REPRESENTED BY THE SUBTYPE 6 ENTRY WAS ORIGINAL CLASSIFIED TO

SMF Info
--------
    Field: `SMF99_S6_SERVER_CLASS_NAME`
    Record: `SMF99S6`
    Map: `SMF99_S6_SERVER_MAP`

NAME OF SERVICE CLASS THAT AT LEAST ONE OF THE SERVER ADDRESS SPACES IN THE SERVER PERIOD REPRESENTED BY THE SUBTYPE 6 ENTRY WAS ORIGINAL CLASSIFIED TO
"""
server_class_name.__doc__ = """NAME OF SERVICE CLASS THAT AT LEAST ONE OF THE SERVER ADDRESS SPACES IN THE SERVER PERIOD REPRESENTED BY THE SUBTYPE 6 ENTRY WAS ORIGINAL CLASSIFIED TO

SMF Info
--------
    Field: `SMF99_S6_SERVER_CLASS_NAME`
    Record: `SMF99S6`
    Map: `SMF99_S6_SERVER_MAP`

NAME OF SERVICE CLASS THAT AT LEAST ONE OF THE SERVER ADDRESS SPACES IN THE SERVER PERIOD REPRESENTED BY THE SUBTYPE 6 ENTRY WAS ORIGINAL CLASSIFIED TO
"""

server_per_num : Final[Field] = Field(
    name='server_per_num',
    origin='SMF99_S6_SERVER_PER_NUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S6_SERVER_MAP,
)
"""PERIOD NUMBER WITH IN CLASS

SMF Info
--------
    Field: `SMF99_S6_SERVER_PER_NUM`
    Record: `SMF99S6`
    Map: `SMF99_S6_SERVER_MAP`

PERIOD NUMBER WITH IN CLASS
"""
server_per_num.__doc__ = """PERIOD NUMBER WITH IN CLASS

SMF Info
--------
    Field: `SMF99_S6_SERVER_PER_NUM`
    Record: `SMF99S6`
    Map: `SMF99_S6_SERVER_MAP`

PERIOD NUMBER WITH IN CLASS
"""
