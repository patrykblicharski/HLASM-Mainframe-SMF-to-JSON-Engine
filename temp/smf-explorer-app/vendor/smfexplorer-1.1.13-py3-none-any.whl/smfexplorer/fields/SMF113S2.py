# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 113 Subtype 2"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=113,
                                smf_subtype=2,
                                spec='SMF 113 Subtype 2',
                                post=None)
"""SMF 113 Subtype 2"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __interval_inline_post(df):
    return df.intervalend - df.intervalstart



SMF113SDS: Final[RecordMap] = RecordMap(
    origin='SMF113SDS',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='SMF113 self defining Section',
    post=None,
    record_mapping=False)
"""SMF113 self defining Section"""
SMF113SSS: Final[RecordMap] = RecordMap(
    origin='SMF113SSS',
    record=record,
    parent=SMF113SDS,
    is_multiple=False,
    is_compound=False,
    spec='SMF113 Subsystem Section',
    post=None,
    record_mapping=False)
"""SMF113 Subsystem Section"""
SMF113ID: Final[RecordMap] = RecordMap(
    origin='SMF113ID',
    record=record,
    parent=SMF113SDS,
    is_multiple=False,
    is_compound=False,
    spec='SMF113 Identification Section',
    post=None,
    record_mapping=False)
"""SMF113 Identification Section"""
SMF113_2_CTR: Final[RecordMap] = RecordMap(
    origin='SMF113_2_CTR',
    record=record,
    parent=SMF113SDS,
    is_multiple=False,
    is_compound=False,
    spec='SMF113 Subtype 2 Header Section',
    post=None,
    record_mapping=False)
"""SMF113 Subtype 2 Header Section"""
SMF113_2_CSS: Final[RecordMap] = RecordMap(
    origin='SMF113_2_CSS',
    record=record,
    parent=SMF113_2_CTR,
    is_multiple=True,
    is_compound=False,
    spec='Counter Set Section',
    post=None,
    record_mapping=False)
"""Counter Set Section"""
SMF113_2_CDS: Final[RecordMap] = RecordMap(
    origin='SMF113_2_CDS',
    record=record,
    parent=SMF113_2_CTR,
    is_multiple=True,
    is_compound=False,
    spec='Counter Data Section',
    post=None,
    record_mapping=False)
"""Counter Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF113DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF113DTE`
    Record: `SMF113S2`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF113DTE`
    Record: `SMF113S2`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF113TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF113TME`
    Record: `SMF113S2`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF113TME`
    Record: `SMF113S2`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF113DTE`), `time`(`SMF113TME`)
    Record: `SMF113S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF113DTE`), `time`(`SMF113TME`)
    Record: `SMF113S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF113LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Record length

SMF Info
--------
    Field: `SMF113LEN`
    Record: `SMF113S2`
    Map: Not part of a map

Record length
"""
len.__doc__ = """Record length

SMF Info
--------
    Field: `SMF113LEN`
    Record: `SMF113S2`
    Map: Not part of a map

Record length
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF113SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""Segment descriptor

SMF Info
--------
    Field: `SMF113SEG`
    Record: `SMF113S2`
    Map: Not part of a map

Segment descriptor
"""
seg.__doc__ = """Segment descriptor

SMF Info
--------
    Field: `SMF113SEG`
    Record: `SMF113S2`
    Map: Not part of a map

Segment descriptor
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF113FLG',
    type=FieldType.STRING,
    record=record,
)
"""Header flag byte

SMF Info
--------
    Field: `SMF113FLG`
    Record: `SMF113S2`
    Map: Not part of a map

Header flag byte
"""
flg.__doc__ = """Header flag byte

SMF Info
--------
    Field: `SMF113FLG`
    Record: `SMF113S2`
    Map: Not part of a map

Header flag byte
"""

ssf : Final[Field] = Field(
    name='ssf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""Bit 0 - Subsys ID after Sys ID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF113FLG`)
    Record: `SMF113S2`
    Map: Not part of a map

Bit 0 - Subsys ID after Sys ID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
ssf.__doc__ = """Bit 0 - Subsys ID after Sys ID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF113FLG`)
    Record: `SMF113S2`
    Map: Not part of a map

Bit 0 - Subsys ID after Sys ID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sbt : Final[Field] = Field(
    name='sbt',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""Bit 1 - Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF113FLG`)
    Record: `SMF113S2`
    Map: Not part of a map

Bit 1 - Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sbt.__doc__ = """Bit 1 - Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF113FLG`)
    Record: `SMF113S2`
    Map: Not part of a map

Bit 1 - Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF113RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""Record type - 113 ('71'x)

SMF Info
--------
    Field: `SMF113RTY`
    Record: `SMF113S2`
    Map: Not part of a map

Record type - 113 ('71'x)
"""
rty.__doc__ = """Record type - 113 ('71'x)

SMF Info
--------
    Field: `SMF113RTY`
    Record: `SMF113S2`
    Map: Not part of a map

Record type - 113 ('71'x)
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF113TME',
    type=FieldType.TIME,
    record=record,
)
"""Record written time

SMF Info
--------
    Field: `SMF113TME`
    Record: `SMF113S2`
    Map: Not part of a map

Record written time
"""
tme.__doc__ = """Record written time

SMF Info
--------
    Field: `SMF113TME`
    Record: `SMF113S2`
    Map: Not part of a map

Record written time
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF113DTE',
    type=FieldType.DATE,
    record=record,
)
"""Record written date

SMF Info
--------
    Field: `SMF113DTE`
    Record: `SMF113S2`
    Map: Not part of a map

Record written date
"""
dte.__doc__ = """Record written date

SMF Info
--------
    Field: `SMF113DTE`
    Record: `SMF113S2`
    Map: Not part of a map

Record written date
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF113SID',
    type=FieldType.STRING,
    record=record,
)
"""System identifier

SMF Info
--------
    Field: `SMF113SID`
    Record: `SMF113S2`
    Map: Not part of a map

System identifier
"""
sid.__doc__ = """System identifier

SMF Info
--------
    Field: `SMF113SID`
    Record: `SMF113S2`
    Map: Not part of a map

System identifier
"""

wid : Final[Field] = Field(
    name='wid',
    origin='SMF113WID',
    type=FieldType.STRING,
    record=record,
)
"""Subsystem identifier

SMF Info
--------
    Field: `SMF113WID`
    Record: `SMF113S2`
    Map: Not part of a map

Subsystem identifier
"""
wid.__doc__ = """Subsystem identifier

SMF Info
--------
    Field: `SMF113WID`
    Record: `SMF113S2`
    Map: Not part of a map

Subsystem identifier
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF113STY',
    type=FieldType.INTEGER,
    record=record,
)
"""Record subtype: 1 = Delta event counters 2 = Hardware event counters

SMF Info
--------
    Field: `SMF113STY`
    Record: `SMF113S2`
    Map: Not part of a map

Record subtype: 1 = Delta event counters 2 = Hardware event counters
"""
sty.__doc__ = """Record subtype: 1 = Delta event counters 2 = Hardware event counters

SMF Info
--------
    Field: `SMF113STY`
    Record: `SMF113S2`
    Map: Not part of a map

Record subtype: 1 = Delta event counters 2 = Hardware event counters
"""

sdl : Final[Field] = Field(
    name='sdl',
    origin='SMF113SDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of self-defining section

SMF Info
--------
    Field: `SMF113SDL`
    Record: `SMF113S2`
    Map: Not part of a map

Length of self-defining section
"""
sdl.__doc__ = """Length of self-defining section

SMF Info
--------
    Field: `SMF113SDL`
    Record: `SMF113S2`
    Map: Not part of a map

Length of self-defining section
"""

sof : Final[Field] = Field(
    name='sof',
    origin='SMF113SOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Offset to subsystem section from beginning of record

SMF Info
--------
    Field: `SMF113SOF`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Offset to subsystem section from beginning of record
"""
sof.__doc__ = """Offset to subsystem section from beginning of record

SMF Info
--------
    Field: `SMF113SOF`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Offset to subsystem section from beginning of record
"""

sln : Final[Field] = Field(
    name='sln',
    origin='SMF113SLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Length of subsystem section

SMF Info
--------
    Field: `SMF113SLN`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Length of subsystem section
"""
sln.__doc__ = """Length of subsystem section

SMF Info
--------
    Field: `SMF113SLN`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Length of subsystem section
"""

son : Final[Field] = Field(
    name='son',
    origin='SMF113SON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Number of subsystem sections

SMF Info
--------
    Field: `SMF113SON`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Number of subsystem sections
"""
son.__doc__ = """Number of subsystem sections

SMF Info
--------
    Field: `SMF113SON`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Number of subsystem sections
"""

iof : Final[Field] = Field(
    name='iof',
    origin='SMF113IOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Offset of identification section from beginning of record

SMF Info
--------
    Field: `SMF113IOF`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Offset of identification section from beginning of record
"""
iof.__doc__ = """Offset of identification section from beginning of record

SMF Info
--------
    Field: `SMF113IOF`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Offset of identification section from beginning of record
"""

iln : Final[Field] = Field(
    name='iln',
    origin='SMF113ILN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Length of identification section

SMF Info
--------
    Field: `SMF113ILN`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Length of identification section
"""
iln.__doc__ = """Length of identification section

SMF Info
--------
    Field: `SMF113ILN`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Length of identification section
"""

ion : Final[Field] = Field(
    name='ion',
    origin='SMF113ION',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Number of identification section

SMF Info
--------
    Field: `SMF113ION`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Number of identification section
"""
ion.__doc__ = """Number of identification section

SMF Info
--------
    Field: `SMF113ION`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Number of identification section
"""

dof : Final[Field] = Field(
    name='dof',
    origin='SMF113DOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Offset of data section from beginning of record

SMF Info
--------
    Field: `SMF113DOF`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Offset of data section from beginning of record
"""
dof.__doc__ = """Offset of data section from beginning of record

SMF Info
--------
    Field: `SMF113DOF`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Offset of data section from beginning of record
"""

dln : Final[Field] = Field(
    name='dln',
    origin='SMF113DLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Length of data section

SMF Info
--------
    Field: `SMF113DLN`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Length of data section
"""
dln.__doc__ = """Length of data section

SMF Info
--------
    Field: `SMF113DLN`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Length of data section
"""

don : Final[Field] = Field(
    name='don',
    origin='SMF113DON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Number of data sections

SMF Info
--------
    Field: `SMF113DON`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Number of data sections
"""
don.__doc__ = """Number of data sections

SMF Info
--------
    Field: `SMF113DON`
    Record: `SMF113S2`
    Map: `SMF113SDS`

Number of data sections
"""

rvn : Final[Field] = Field(
    name='rvn',
    origin='SMF113RVN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113SSS,
)
"""Record version number

SMF Info
--------
    Field: `SMF113RVN`
    Record: `SMF113S2`
    Map: `SMF113SSS`

Record version number
"""
rvn.__doc__ = """Record version number

SMF Info
--------
    Field: `SMF113RVN`
    Record: `SMF113S2`
    Map: `SMF113SSS`

Record version number
"""

pnm : Final[Field] = Field(
    name='pnm',
    origin='SMF113PNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113SSS,
)
"""Product name - HIS

SMF Info
--------
    Field: `SMF113PNM`
    Record: `SMF113S2`
    Map: `SMF113SSS`

Product name - HIS
"""
pnm.__doc__ = """Product name - HIS

SMF Info
--------
    Field: `SMF113PNM`
    Record: `SMF113S2`
    Map: `SMF113SSS`

Product name - HIS
"""

osl : Final[Field] = Field(
    name='osl',
    origin='SMF113OSL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113SSS,
)
"""MVS product level

SMF Info
--------
    Field: `SMF113OSL`
    Record: `SMF113S2`
    Map: `SMF113SSS`

MVS product level
"""
osl.__doc__ = """MVS product level

SMF Info
--------
    Field: `SMF113OSL`
    Record: `SMF113S2`
    Map: `SMF113SSS`

MVS product level
"""

jbn : Final[Field] = Field(
    name='jbn',
    origin='SMF113JBN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113ID,
)
"""JobName

SMF Info
--------
    Field: `SMF113JBN`
    Record: `SMF113S2`
    Map: `SMF113ID`

JobName
"""
jbn.__doc__ = """JobName

SMF Info
--------
    Field: `SMF113JBN`
    Record: `SMF113S2`
    Map: `SMF113ID`

JobName
"""

rst : Final[Field] = Field(
    name='rst',
    origin='SMF113RST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF113ID,
)
"""Reader start time

SMF Info
--------
    Field: `SMF113RST`
    Record: `SMF113S2`
    Map: `SMF113ID`

Reader start time
"""
rst.__doc__ = """Reader start time

SMF Info
--------
    Field: `SMF113RST`
    Record: `SMF113S2`
    Map: `SMF113ID`

Reader start time
"""

rsd : Final[Field] = Field(
    name='rsd',
    origin='SMF113RSD',
    type=FieldType.DATE,
    record=record,
    record_map=SMF113ID,
)
"""Reader start date

SMF Info
--------
    Field: `SMF113RSD`
    Record: `SMF113S2`
    Map: `SMF113ID`

Reader start date
"""
rsd.__doc__ = """Reader start date

SMF Info
--------
    Field: `SMF113RSD`
    Record: `SMF113S2`
    Map: `SMF113ID`

Reader start date
"""

stp : Final[Field] = Field(
    name='stp',
    origin='SMF113STP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113ID,
)
"""Step name

SMF Info
--------
    Field: `SMF113STP`
    Record: `SMF113S2`
    Map: `SMF113ID`

Step name
"""
stp.__doc__ = """Step name

SMF Info
--------
    Field: `SMF113STP`
    Record: `SMF113S2`
    Map: `SMF113ID`

Step name
"""

intervalstart : Final[Field] = Field(
    name='intervalstart',
    origin='SMF113INTERVALSTART',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF113ID,
)
"""The interval start time

SMF Info
--------
    Field: `SMF113INTERVALSTART`
    Record: `SMF113S2`
    Map: `SMF113ID`

The interval start time
"""
intervalstart.__doc__ = """The interval start time

SMF Info
--------
    Field: `SMF113INTERVALSTART`
    Record: `SMF113S2`
    Map: `SMF113ID`

The interval start time
"""

intervalend : Final[Field] = Field(
    name='intervalend',
    origin='SMF113INTERVALEND',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF113ID,
)
"""The interval end time

SMF Info
--------
    Field: `SMF113INTERVALEND`
    Record: `SMF113S2`
    Map: `SMF113ID`

The interval end time
"""
intervalend.__doc__ = """The interval end time

SMF Info
--------
    Field: `SMF113INTERVALEND`
    Record: `SMF113S2`
    Map: `SMF113ID`

The interval end time
"""

interval : Final[Field] = Field(
    name='interval',
    origin=None,
    post="core.inline",
    post_param=__interval_inline_post,
    virtual=True,
    ref=[intervalstart, intervalend],
    record=record,
    record_map=SMF113ID,
)
"""The interval time delta(V)

SMF Info (Virtual Field)
--------
    Field: Based on `intervalstart`(`SMF113INTERVALSTART`), `intervalend`(`SMF113INTERVALEND`)
    Record: `SMF113S2`
    Map: `SMF113ID`

The interval time delta

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.intervalend - df.intervalstart

"""
interval.__doc__ = """The interval time delta(V)

SMF Info (Virtual Field)
--------
    Field: Based on `intervalstart`(`SMF113INTERVALSTART`), `intervalend`(`SMF113INTERVALEND`)
    Record: `SMF113S2`
    Map: `SMF113ID`

The interval time delta

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.intervalend - df.intervalstart

"""

cts : Final[Field] = Field(
    name='cts',
    origin='SMF113_2_CTS',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Time when HIS Data collection started

SMF Info
--------
    Field: `SMF113_2_CTS`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Time when HIS Data collection started
"""
cts.__doc__ = """Time when HIS Data collection started

SMF Info
--------
    Field: `SMF113_2_CTS`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Time when HIS Data collection started
"""

ctm : Final[Field] = Field(
    name='ctm',
    origin='SMF113_2_CTM',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Time when this SMF record is written

SMF Info
--------
    Field: `SMF113_2_CTM`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Time when this SMF record is written
"""
ctm.__doc__ = """Time when this SMF record is written

SMF Info
--------
    Field: `SMF113_2_CTM`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Time when this SMF record is written
"""

cpuprocclass : Final[Field] = Field(
    name='cpuprocclass',
    origin='SMF113_2_CPUPROCCLASS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""The processor type for which the event counters are recorded. Will be one of the following: 0 = Standard CP 2 = zCBP or zAAP see SMF113_2_zCBP 4 = zIIP

SMF Info
--------
    Field: `SMF113_2_CPUPROCCLASS`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

The processor type for which the event counters are recorded. Will be one of the following: 0 = Standard CP 2 = zCBP or zAAP see SMF113_2_zCBP 4 = zIIP
"""
cpuprocclass.__doc__ = """The processor type for which the event counters are recorded. Will be one of the following: 0 = Standard CP 2 = zCBP or zAAP see SMF113_2_zCBP 4 = zIIP

SMF Info
--------
    Field: `SMF113_2_CPUPROCCLASS`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

The processor type for which the event counters are recorded. Will be one of the following: 0 = Standard CP 2 = zCBP or zAAP see SMF113_2_zCBP 4 = zIIP
"""

cf : Final[Field] = Field(
    name='cf',
    origin='SMF113_2_CF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Record flags

SMF Info
--------
    Field: `SMF113_2_CF`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Record flags
"""
cf.__doc__ = """Record flags

SMF Info
--------
    Field: `SMF113_2_CF`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Record flags
"""

cff : Final[Field] = Field(
    name='cff',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=cf,
    record=record,
    record_map=SMF113_2_CTR,
)
"""First SMF record for the instrumentation run. The counter values are the initial values.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

First SMF record for the instrumentation run. The counter values are the initial values.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cff.__doc__ = """First SMF record for the instrumentation run. The counter values are the initial values.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

First SMF record for the instrumentation run. The counter values are the initial values.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cfm : Final[Field] = Field(
    name='cfm',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=cf,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Middle SMF record (activated by interval timers). The counter values are intermediate values. The number of intermediate records varies from 0 to many, depending on the duration of the instrumentation run. An intermediate recrod is produced periodically based on the SMFINTVAL parameter.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Middle SMF record (activated by interval timers). The counter values are intermediate values. The number of intermediate records varies from 0 to many, depending on the duration of the instrumentation run. An intermediate recrod is produced periodically based on the SMFINTVAL parameter.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cfm.__doc__ = """Middle SMF record (activated by interval timers). The counter values are intermediate values. The number of intermediate records varies from 0 to many, depending on the duration of the instrumentation run. An intermediate recrod is produced periodically based on the SMFINTVAL parameter.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Middle SMF record (activated by interval timers). The counter values are intermediate values. The number of intermediate records varies from 0 to many, depending on the duration of the instrumentation run. An intermediate recrod is produced periodically based on the SMFINTVAL parameter.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

cfl : Final[Field] = Field(
    name='cfl',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=cf,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Final SMF record for the instrumentation run. The counter values are the values at the end of the run.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Final SMF record for the instrumentation run. The counter values are the values at the end of the run.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
cfl.__doc__ = """Final SMF record for the instrumentation run. The counter values are the values at the end of the run.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Final SMF record for the instrumentation run. The counter values are the values at the end of the run.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

cfns : Final[Field] = Field(
    name='cfns',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=cf,
    record=record,
    record_map=SMF113_2_CTR,
)
"""1=Internal flag indicating SMF record is created on non-standard instrumentation hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

1=Internal flag indicating SMF record is created on non-standard instrumentation hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
cfns.__doc__ = """1=Internal flag indicating SMF record is created on non-standard instrumentation hardware(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

1=Internal flag indicating SMF record is created on non-standard instrumentation hardware

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

lostdata : Final[Field] = Field(
    name='lostdata',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=cf,
    record=record,
    record_map=SMF113_2_CTR,
)
"""When ON, the hardware indicated the hardware has lost counter data on during the current interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

When ON, the hardware indicated the hardware has lost counter data on during the current interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
lostdata.__doc__ = """When ON, the hardware indicated the hardware has lost counter data on during the current interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

When ON, the hardware indicated the hardware has lost counter data on during the current interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

zcbp : Final[Field] = Field(
    name='zcbp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=cf,
    record=record,
    record_map=SMF113_2_CTR,
)
"""When ON, a value of 2 for SMF113_2_CpuProcClass refers to a zCBP processor type, when off a zAAP processor type.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

When ON, a value of 2 for SMF113_2_CpuProcClass refers to a zCBP processor type, when off a zAAP processor type.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
zcbp.__doc__ = """When ON, a value of 2 for SMF113_2_CpuProcClass refers to a zCBP processor type, when off a zAAP processor type.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cf`(`SMF113_2_CF`)
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

When ON, a value of 2 for SMF113_2_CpuProcClass refers to a zCBP processor type, when off a zAAP processor type.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ctrvn1 : Final[Field] = Field(
    name='ctrvn1',
    origin='SMF113_2_CTRVN1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""First counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Basic or Problem-state counter sets

SMF Info
--------
    Field: `SMF113_2_CTRVN1`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

First counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Basic or Problem-state counter sets
"""
ctrvn1.__doc__ = """First counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Basic or Problem-state counter sets

SMF Info
--------
    Field: `SMF113_2_CTRVN1`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

First counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Basic or Problem-state counter sets
"""

ctrvn2 : Final[Field] = Field(
    name='ctrvn2',
    origin='SMF113_2_CTRVN2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Second counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Crypto-activity or Extended counter sets

SMF Info
--------
    Field: `SMF113_2_CTRVN2`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Second counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Crypto-activity or Extended counter sets
"""
ctrvn2.__doc__ = """Second counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Crypto-activity or Extended counter sets

SMF Info
--------
    Field: `SMF113_2_CTRVN2`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Second counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Crypto-activity or Extended counter sets
"""

csof : Final[Field] = Field(
    name='csof',
    origin='SMF113_2_CSOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Offset to counter set section from beginning of record

SMF Info
--------
    Field: `SMF113_2_CSOF`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Offset to counter set section from beginning of record
"""
csof.__doc__ = """Offset to counter set section from beginning of record

SMF Info
--------
    Field: `SMF113_2_CSOF`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Offset to counter set section from beginning of record
"""

csln : Final[Field] = Field(
    name='csln',
    origin='SMF113_2_CSLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Length of counter set sections

SMF Info
--------
    Field: `SMF113_2_CSLN`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Length of counter set sections
"""
csln.__doc__ = """Length of counter set sections

SMF Info
--------
    Field: `SMF113_2_CSLN`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Length of counter set sections
"""

cson : Final[Field] = Field(
    name='cson',
    origin='SMF113_2_CSON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Number of counter set sections

SMF Info
--------
    Field: `SMF113_2_CSON`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Number of counter set sections
"""
cson.__doc__ = """Number of counter set sections

SMF Info
--------
    Field: `SMF113_2_CSON`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Number of counter set sections
"""

cdof : Final[Field] = Field(
    name='cdof',
    origin='SMF113_2_CDOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Offset to counter data section from beginning of record

SMF Info
--------
    Field: `SMF113_2_CDOF`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Offset to counter data section from beginning of record
"""
cdof.__doc__ = """Offset to counter data section from beginning of record

SMF Info
--------
    Field: `SMF113_2_CDOF`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Offset to counter data section from beginning of record
"""

cdln : Final[Field] = Field(
    name='cdln',
    origin='SMF113_2_CDLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Length of counter data sections

SMF Info
--------
    Field: `SMF113_2_CDLN`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Length of counter data sections
"""
cdln.__doc__ = """Length of counter data sections

SMF Info
--------
    Field: `SMF113_2_CDLN`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Length of counter data sections
"""

cdon : Final[Field] = Field(
    name='cdon',
    origin='SMF113_2_CDON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Number of counter data sections. This is the total number of SMF113_2_CDS sections for all the counter sets

SMF Info
--------
    Field: `SMF113_2_CDON`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Number of counter data sections. This is the total number of SMF113_2_CDS sections for all the counter sets
"""
cdon.__doc__ = """Number of counter data sections. This is the total number of SMF113_2_CDS sections for all the counter sets

SMF Info
--------
    Field: `SMF113_2_CDON`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Number of counter data sections. This is the total number of SMF113_2_CDS sections for all the counter sets
"""

cpsp : Final[Field] = Field(
    name='cpsp',
    origin='SMF113_2_CPSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Processor speed for which the event counters are recorded. Speed is in cycles/microsecond.

SMF Info
--------
    Field: `SMF113_2_CPSP`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Processor speed for which the event counters are recorded. Speed is in cycles/microsecond.
"""
cpsp.__doc__ = """Processor speed for which the event counters are recorded. Speed is in cycles/microsecond.

SMF Info
--------
    Field: `SMF113_2_CPSP`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Processor speed for which the event counters are recorded. Speed is in cycles/microsecond.
"""

machtype : Final[Field] = Field(
    name='machtype',
    origin='SMF113_2_MACHTYPE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113_2_CTR,
)
"""The machine type

SMF Info
--------
    Field: `SMF113_2_MACHTYPE`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

The machine type
"""
machtype.__doc__ = """The machine type

SMF Info
--------
    Field: `SMF113_2_MACHTYPE`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

The machine type
"""

machmodel : Final[Field] = Field(
    name='machmodel',
    origin='SMF113_2_MACHMODEL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113_2_CTR,
)
"""The machine model

SMF Info
--------
    Field: `SMF113_2_MACHMODEL`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

The machine model
"""
machmodel.__doc__ = """The machine model

SMF Info
--------
    Field: `SMF113_2_MACHMODEL`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

The machine model
"""

cpuid : Final[Field] = Field(
    name='cpuid',
    origin='SMF113_2_CPUID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CTR,
)
"""Processor ID for which the hardware event counters are recorded. Note that zero is a valid processor ID.

SMF Info
--------
    Field: `SMF113_2_CPUID`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Processor ID for which the hardware event counters are recorded. Note that zero is a valid processor ID.
"""
cpuid.__doc__ = """Processor ID for which the hardware event counters are recorded. Note that zero is a valid processor ID.

SMF Info
--------
    Field: `SMF113_2_CPUID`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

Processor ID for which the hardware event counters are recorded. Note that zero is a valid processor ID.
"""

machseqcode : Final[Field] = Field(
    name='machseqcode',
    origin='SMF113_2_MACHSEQCODE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113_2_CTR,
)
"""The machine sequence code

SMF Info
--------
    Field: `SMF113_2_MACHSEQCODE`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

The machine sequence code
"""
machseqcode.__doc__ = """The machine sequence code

SMF Info
--------
    Field: `SMF113_2_MACHSEQCODE`
    Record: `SMF113S2`
    Map: `SMF113_2_CTR`

The machine sequence code
"""

cst : Final[Field] = Field(
    name='cst',
    origin='SMF113_2_CST',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CSS,
)
"""Counterset type for counters recorded in SMF113_2_CR: 1 = Basic, 2 = Problem state, 3 = Crypto-activity, 4 = Extended

SMF Info
--------
    Field: `SMF113_2_CST`
    Record: `SMF113S2`
    Map: `SMF113_2_CSS`

Counterset type for counters recorded in SMF113_2_CR: 1 = Basic, 2 = Problem state, 3 = Crypto-activity, 4 = Extended
"""
cst.__doc__ = """Counterset type for counters recorded in SMF113_2_CR: 1 = Basic, 2 = Problem state, 3 = Crypto-activity, 4 = Extended

SMF Info
--------
    Field: `SMF113_2_CST`
    Record: `SMF113S2`
    Map: `SMF113_2_CSS`

Counterset type for counters recorded in SMF113_2_CR: 1 = Basic, 2 = Problem state, 3 = Crypto-activity, 4 = Extended
"""

csn : Final[Field] = Field(
    name='csn',
    origin='SMF113_2_CSN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CSS,
)
"""Number of counter sections

SMF Info
--------
    Field: `SMF113_2_CSN`
    Record: `SMF113S2`
    Map: `SMF113_2_CSS`

Number of counter sections
"""
csn.__doc__ = """Number of counter sections

SMF Info
--------
    Field: `SMF113_2_CSN`
    Record: `SMF113S2`
    Map: `SMF113_2_CSS`

Number of counter sections
"""

cr : Final[Field] = Field(
    name='cr',
    origin='SMF113_2_CR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_2_CDS,
)
"""Hardware event counter value. Contains the absolute number of times a particular hardware counter event has occurred.

SMF Info
--------
    Field: `SMF113_2_CR`
    Record: `SMF113S2`
    Map: `SMF113_2_CDS`

Hardware event counter value. Contains the absolute number of times a particular hardware counter event has occurred.
"""
cr.__doc__ = """Hardware event counter value. Contains the absolute number of times a particular hardware counter event has occurred.

SMF Info
--------
    Field: `SMF113_2_CR`
    Record: `SMF113S2`
    Map: `SMF113_2_CDS`

Hardware event counter value. Contains the absolute number of times a particular hardware counter event has occurred.
"""
