# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 8"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=8,
                                spec='SMF 74 Subtype 8',
                                post=None)
"""SMF 74 Subtype 8"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R748CNTL: Final[RecordMap] = RecordMap(
    origin='R748CNTL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Control Data Section',
    post=None,
    record_mapping=False)
"""Control Data Section"""
R748LSS: Final[RecordMap] = RecordMap(
    origin='R748LSS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Link Statistics Section',
    post=None,
    record_mapping=False)
"""Link Statistics Section"""
R748EXTP: Final[RecordMap] = RecordMap(
    origin='R748EXTP',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Extended Pool Statistics Section',
    post=None,
    record_mapping=False)
"""Extended Pool Statistics Section"""
R748RANK: Final[RecordMap] = RecordMap(
    origin='R748RANK',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Rank Statistics Section',
    post=None,
    record_mapping=False)
"""Rank Statistics Section"""
R748ARRY: Final[RecordMap] = RecordMap(
    origin='R748ARRY',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Rank Array Data Section',
    post=None,
    record_mapping=False)
"""Rank Array Data Section"""
R748SIOL: Final[RecordMap] = RecordMap(
    origin='R748SIOL',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Sync I/O Link Statistics Section',
    post=None,
    record_mapping=False)
"""Sync I/O Link Statistics Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S8`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S8`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S8`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S8`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S8`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S8`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S8`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S8`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S8`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S8`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S8`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S8`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S8`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S8`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S8`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S8`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S8`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S8`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S8`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S8`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S8`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S8`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S8`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S8`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S8`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S8`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S8`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S8`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S8`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S8`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S8`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S8`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S8`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

co : Final[Field] = Field(
    name='co',
    origin='SMF748CO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to link control section

SMF Info
--------
    Field: `SMF748CO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to link control section
"""
co.__doc__ = """Offset to link control section

SMF Info
--------
    Field: `SMF748CO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to link control section
"""

cl : Final[Field] = Field(
    name='cl',
    origin='SMF748CL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of link control section

SMF Info
--------
    Field: `SMF748CL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of link control section
"""
cl.__doc__ = """Length of link control section

SMF Info
--------
    Field: `SMF748CL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of link control section
"""

cn : Final[Field] = Field(
    name='cn',
    origin='SMF748CN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of link control sections

SMF Info
--------
    Field: `SMF748CN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of link control sections
"""
cn.__doc__ = """Number of link control sections

SMF Info
--------
    Field: `SMF748CN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of link control sections
"""

lo : Final[Field] = Field(
    name='lo',
    origin='SMF748LO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to link data section

SMF Info
--------
    Field: `SMF748LO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to link data section
"""
lo.__doc__ = """Offset to link data section

SMF Info
--------
    Field: `SMF748LO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to link data section
"""

ll : Final[Field] = Field(
    name='ll',
    origin='SMF748LL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of link data section

SMF Info
--------
    Field: `SMF748LL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of link data section
"""
ll.__doc__ = """Length of link data section

SMF Info
--------
    Field: `SMF748LL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of link data section
"""

ln : Final[Field] = Field(
    name='ln',
    origin='SMF748LN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of link data sections

SMF Info
--------
    Field: `SMF748LN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of link data sections
"""
ln.__doc__ = """Number of link data sections

SMF Info
--------
    Field: `SMF748LN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of link data sections
"""

xo : Final[Field] = Field(
    name='xo',
    origin='SMF748XO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Extent pool data section

SMF Info
--------
    Field: `SMF748XO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to Extent pool data section
"""
xo.__doc__ = """Offset to Extent pool data section

SMF Info
--------
    Field: `SMF748XO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to Extent pool data section
"""

xl : Final[Field] = Field(
    name='xl',
    origin='SMF748XL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Extent pool data section

SMF Info
--------
    Field: `SMF748XL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of Extent pool data section
"""
xl.__doc__ = """Length of Extent pool data section

SMF Info
--------
    Field: `SMF748XL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of Extent pool data section
"""

xn : Final[Field] = Field(
    name='xn',
    origin='SMF748XN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Extent pool data section

SMF Info
--------
    Field: `SMF748XN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of Extent pool data section
"""
xn.__doc__ = """Number of Extent pool data section

SMF Info
--------
    Field: `SMF748XN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of Extent pool data section
"""

ro : Final[Field] = Field(
    name='ro',
    origin='SMF748RO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Rank statistics data section

SMF Info
--------
    Field: `SMF748RO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to Rank statistics data section
"""
ro.__doc__ = """Offset to Rank statistics data section

SMF Info
--------
    Field: `SMF748RO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to Rank statistics data section
"""

rl : Final[Field] = Field(
    name='rl',
    origin='SMF748RL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Rank statistics data section

SMF Info
--------
    Field: `SMF748RL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of Rank statistics data section
"""
rl.__doc__ = """Length of Rank statistics data section

SMF Info
--------
    Field: `SMF748RL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of Rank statistics data section
"""

rn : Final[Field] = Field(
    name='rn',
    origin='SMF748RN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Rank statistics data section

SMF Info
--------
    Field: `SMF748RN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of Rank statistics data section
"""
rn.__doc__ = """Number of Rank statistics data section

SMF Info
--------
    Field: `SMF748RN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of Rank statistics data section
"""

ao : Final[Field] = Field(
    name='ao',
    origin='SMF748AO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Rank Array data section

SMF Info
--------
    Field: `SMF748AO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to Rank Array data section
"""
ao.__doc__ = """Offset to Rank Array data section

SMF Info
--------
    Field: `SMF748AO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to Rank Array data section
"""

al : Final[Field] = Field(
    name='al',
    origin='SMF748AL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Rank Array data section

SMF Info
--------
    Field: `SMF748AL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of Rank Array data section
"""
al.__doc__ = """Length of Rank Array data section

SMF Info
--------
    Field: `SMF748AL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of Rank Array data section
"""

an : Final[Field] = Field(
    name='an',
    origin='SMF748AN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Rank Array data section

SMF Info
--------
    Field: `SMF748AN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of Rank Array data section
"""
an.__doc__ = """Number of Rank Array data section

SMF Info
--------
    Field: `SMF748AN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of Rank Array data section
"""

so : Final[Field] = Field(
    name='so',
    origin='SMF748SO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Synchronous I/O Link Statistics data sect.

SMF Info
--------
    Field: `SMF748SO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to Synchronous I/O Link Statistics data sect.
"""
so.__doc__ = """Offset to Synchronous I/O Link Statistics data sect.

SMF Info
--------
    Field: `SMF748SO`
    Record: `SMF74S8`
    Map: Not part of a map

Offset to Synchronous I/O Link Statistics data sect.
"""

sl : Final[Field] = Field(
    name='sl',
    origin='SMF748SL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Synchronous I/O Link Statistics data sect.

SMF Info
--------
    Field: `SMF748SL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of Synchronous I/O Link Statistics data sect.
"""
sl.__doc__ = """Length of Synchronous I/O Link Statistics data sect.

SMF Info
--------
    Field: `SMF748SL`
    Record: `SMF74S8`
    Map: Not part of a map

Length of Synchronous I/O Link Statistics data sect.
"""

sn : Final[Field] = Field(
    name='sn',
    origin='SMF748SN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Synchronous I/O Link Statistics data sect.

SMF Info
--------
    Field: `SMF748SN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of Synchronous I/O Link Statistics data sect.
"""
sn.__doc__ = """Number of Synchronous I/O Link Statistics data sect.

SMF Info
--------
    Field: `SMF748SN`
    Record: `SMF74S8`
    Map: Not part of a map

Number of Synchronous I/O Link Statistics data sect.
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S8`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S8`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S8`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S8`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S8`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S8`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S8`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S8`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S8`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S8`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S8`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S8`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S8`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S8`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

r748clvl : Final[Field] = Field(
    name='r748clvl',
    origin='R748CLVL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""Gatherer level

SMF Info
--------
    Field: `R748CLVL`
    Record: `SMF74S8`
    Map: `R748CNTL`

Gatherer level
"""
r748clvl.__doc__ = """Gatherer level

SMF Info
--------
    Field: `R748CLVL`
    Record: `SMF74S8`
    Map: `R748CNTL`

Gatherer level
"""

r748ctyp : Final[Field] = Field(
    name='r748ctyp',
    origin='R748CTYP',
    type=FieldType.STRING,
    record=record,
    record_map=R748CNTL,
)
"""CU TYPe

SMF Info
--------
    Field: `R748CTYP`
    Record: `SMF74S8`
    Map: `R748CNTL`

CU TYPe
"""
r748ctyp.__doc__ = """CU TYPe

SMF Info
--------
    Field: `R748CTYP`
    Record: `SMF74S8`
    Map: `R748CNTL`

CU TYPe
"""

r748cmdl : Final[Field] = Field(
    name='r748cmdl',
    origin='R748CMDL',
    type=FieldType.STRING,
    record=record,
    record_map=R748CNTL,
)
"""CU MoDeL

SMF Info
--------
    Field: `R748CMDL`
    Record: `SMF74S8`
    Map: `R748CNTL`

CU MoDeL
"""
r748cmdl.__doc__ = """CU MoDeL

SMF Info
--------
    Field: `R748CMDL`
    Record: `SMF74S8`
    Map: `R748CNTL`

CU MoDeL
"""

r748cser : Final[Field] = Field(
    name='r748cser',
    origin='R748CSER',
    type=FieldType.STRING,
    record=record,
    record_map=R748CNTL,
)
"""Primary CU serial number

SMF Info
--------
    Field: `R748CSER`
    Record: `SMF74S8`
    Map: `R748CNTL`

Primary CU serial number
"""
r748cser.__doc__ = """Primary CU serial number

SMF Info
--------
    Field: `R748CSER`
    Record: `SMF74S8`
    Map: `R748CNTL`

Primary CU serial number
"""

r748cvsn : Final[Field] = Field(
    name='r748cvsn',
    origin='R748CVSN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""VerSioN of link statistics definition 00 = Original length of link statistics 01 = Link statistics extended 02 = Link statistics V2 format

SMF Info
--------
    Field: `R748CVSN`
    Record: `SMF74S8`
    Map: `R748CNTL`

VerSioN of link statistics definition 00 = Original length of link statistics 01 = Link statistics extended 02 = Link statistics V2 format
"""
r748cvsn.__doc__ = """VerSioN of link statistics definition 00 = Original length of link statistics 01 = Link statistics extended 02 = Link statistics V2 format

SMF Info
--------
    Field: `R748CVSN`
    Record: `SMF74S8`
    Map: `R748CNTL`

VerSioN of link statistics definition 00 = Original length of link statistics 01 = Link statistics extended 02 = Link statistics V2 format
"""

r748cae : Final[Field] = Field(
    name='r748cae',
    origin='R748CAE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""Abend Code (SDWACMPC) System and User completion code (12 bits each)

SMF Info
--------
    Field: `R748CAE`
    Record: `SMF74S8`
    Map: `R748CNTL`

Abend Code (SDWACMPC) System and User completion code (12 bits each)
"""
r748cae.__doc__ = """Abend Code (SDWACMPC) System and User completion code (12 bits each)

SMF Info
--------
    Field: `R748CAE`
    Record: `SMF74S8`
    Map: `R748CNTL`

Abend Code (SDWACMPC) System and User completion code (12 bits each)
"""

r748crtn : Final[Field] = Field(
    name='r748crtn',
    origin='R748CRTN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""IDCSS01 return code

SMF Info
--------
    Field: `R748CRTN`
    Record: `SMF74S8`
    Map: `R748CNTL`

IDCSS01 return code
"""
r748crtn.__doc__ = """IDCSS01 return code

SMF Info
--------
    Field: `R748CRTN`
    Record: `SMF74S8`
    Map: `R748CNTL`

IDCSS01 return code
"""

r748csc : Final[Field] = Field(
    name='r748csc',
    origin='R748CSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""Status code 00 = successful processed, 04 = IOS return code R748CIOC ^= 0, 08 = IDCSS01 return code R748CRTN ^= 0, 98 = SYSTEM or USER ABEND R748CAE ^= 0

SMF Info
--------
    Field: `R748CSC`
    Record: `SMF74S8`
    Map: `R748CNTL`

Status code 00 = successful processed, 04 = IOS return code R748CIOC ^= 0, 08 = IDCSS01 return code R748CRTN ^= 0, 98 = SYSTEM or USER ABEND R748CAE ^= 0
"""
r748csc.__doc__ = """Status code 00 = successful processed, 04 = IOS return code R748CIOC ^= 0, 08 = IDCSS01 return code R748CRTN ^= 0, 98 = SYSTEM or USER ABEND R748CAE ^= 0

SMF Info
--------
    Field: `R748CSC`
    Record: `SMF74S8`
    Map: `R748CNTL`

Status code 00 = successful processed, 04 = IOS return code R748CIOC ^= 0, 08 = IDCSS01 return code R748CRTN ^= 0, 98 = SYSTEM or USER ABEND R748CAE ^= 0
"""

r748cioc : Final[Field] = Field(
    name='r748cioc',
    origin='R748CIOC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""IOS return code. If not zero, no link statistic data sections

SMF Info
--------
    Field: `R748CIOC`
    Record: `SMF74S8`
    Map: `R748CNTL`

IOS return code. If not zero, no link statistic data sections
"""
r748cioc.__doc__ = """IOS return code. If not zero, no link statistic data sections

SMF Info
--------
    Field: `R748CIOC`
    Record: `SMF74S8`
    Map: `R748CNTL`

IOS return code. If not zero, no link statistic data sections
"""

r748cfdv : Final[Field] = Field(
    name='r748cfdv',
    origin='R748CFDV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""Failing device

SMF Info
--------
    Field: `R748CFDV`
    Record: `SMF74S8`
    Map: `R748CNTL`

Failing device
"""
r748cfdv.__doc__ = """Failing device

SMF Info
--------
    Field: `R748CFDV`
    Record: `SMF74S8`
    Map: `R748CNTL`

Failing device
"""

r748cvol : Final[Field] = Field(
    name='r748cvol',
    origin='R748CVOL',
    type=FieldType.STRING,
    record=record,
    record_map=R748CNTL,
)
"""Volume serial of device that statistics where read from

SMF Info
--------
    Field: `R748CVOL`
    Record: `SMF74S8`
    Map: `R748CNTL`

Volume serial of device that statistics where read from
"""
r748cvol.__doc__ = """Volume serial of device that statistics where read from

SMF Info
--------
    Field: `R748CVOL`
    Record: `SMF74S8`
    Map: `R748CNTL`

Volume serial of device that statistics where read from
"""

r748cdev : Final[Field] = Field(
    name='r748cdev',
    origin='R748CDEV',
    type=FieldType.STRING,
    record=record,
    record_map=R748CNTL,
)
"""Device number of device that statistics where read from

SMF Info
--------
    Field: `R748CDEV`
    Record: `SMF74S8`
    Map: `R748CNTL`

Device number of device that statistics where read from
"""
r748cdev.__doc__ = """Device number of device that statistics where read from

SMF Info
--------
    Field: `R748CDEV`
    Record: `SMF74S8`
    Map: `R748CNTL`

Device number of device that statistics where read from
"""

r748cflg : Final[Field] = Field(
    name='r748cflg',
    origin='R748CFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R748CNTL,
)
"""Flags

SMF Info
--------
    Field: `R748CFLG`
    Record: `SMF74S8`
    Map: `R748CNTL`

Flags
"""
r748cflg.__doc__ = """Flags

SMF Info
--------
    Field: `R748CFLG`
    Record: `SMF74S8`
    Map: `R748CNTL`

Flags
"""

r748cxvl : Final[Field] = Field(
    name='r748cxvl',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r748cflg,
    record=record,
    record_map=R748CNTL,
)
"""Extent Pool statistics valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748cflg`(`R748CFLG`)
    Record: `SMF74S8`
    Map: `R748CNTL`

Extent Pool statistics valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r748cxvl.__doc__ = """Extent Pool statistics valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748cflg`(`R748CFLG`)
    Record: `SMF74S8`
    Map: `R748CNTL`

Extent Pool statistics valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r748cscs : Final[Field] = Field(
    name='r748cscs',
    origin='R748CSCS',
    type=FieldType.STRING,
    record=record,
    record_map=R748CNTL,
)
"""ID of the subchannel set which is physically configured to the device from which statistics are measured

SMF Info
--------
    Field: `R748CSCS`
    Record: `SMF74S8`
    Map: `R748CNTL`

ID of the subchannel set which is physically configured to the device from which statistics are measured
"""
r748cscs.__doc__ = """ID of the subchannel set which is physically configured to the device from which statistics are measured

SMF Info
--------
    Field: `R748CSCS`
    Record: `SMF74S8`
    Map: `R748CNTL`

ID of the subchannel set which is physically configured to the device from which statistics are measured
"""

r748cint : Final[Field] = Field(
    name='r748cint',
    origin='R748CINT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""Number of seconds since statistics last collected

SMF Info
--------
    Field: `R748CINT`
    Record: `SMF74S8`
    Map: `R748CNTL`

Number of seconds since statistics last collected
"""
r748cint.__doc__ = """Number of seconds since statistics last collected

SMF Info
--------
    Field: `R748CINT`
    Record: `SMF74S8`
    Map: `R748CNTL`

Number of seconds since statistics last collected
"""

r748cftm : Final[Field] = Field(
    name='r748cftm',
    origin='R748CFTM',
    type=FieldType.TIME,
    record=record,
    record_map=R748CNTL,
)
"""Time when first record was written (Reserved for duration processing)

SMF Info
--------
    Field: `R748CFTM`
    Record: `SMF74S8`
    Map: `R748CNTL`

Time when first record was written (Reserved for duration processing)
"""
r748cftm.__doc__ = """Time when first record was written (Reserved for duration processing)

SMF Info
--------
    Field: `R748CFTM`
    Record: `SMF74S8`
    Map: `R748CNTL`

Time when first record was written (Reserved for duration processing)
"""

r748cfdt : Final[Field] = Field(
    name='r748cfdt',
    origin='R748CFDT',
    type=FieldType.TIME,
    record=record,
    record_map=R748CNTL,
)
"""Date when first record was written (Reserved for duration processing)

SMF Info
--------
    Field: `R748CFDT`
    Record: `SMF74S8`
    Map: `R748CNTL`

Date when first record was written (Reserved for duration processing)
"""
r748cfdt.__doc__ = """Date when first record was written (Reserved for duration processing)

SMF Info
--------
    Field: `R748CFDT`
    Record: `SMF74S8`
    Map: `R748CNTL`

Date when first record was written (Reserved for duration processing)
"""

r748cfci : Final[Field] = Field(
    name='r748cfci',
    origin='R748CFCI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""Interval length of first record (Reserved for duration processing)

SMF Info
--------
    Field: `R748CFCI`
    Record: `SMF74S8`
    Map: `R748CNTL`

Interval length of first record (Reserved for duration processing)
"""
r748cfci.__doc__ = """Interval length of first record (Reserved for duration processing)

SMF Info
--------
    Field: `R748CFCI`
    Record: `SMF74S8`
    Map: `R748CNTL`

Interval length of first record (Reserved for duration processing)
"""

r748cfsc : Final[Field] = Field(
    name='r748cfsc',
    origin='R748CFSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748CNTL,
)
"""Subchannel set ID of failing device

SMF Info
--------
    Field: `R748CFSC`
    Record: `SMF74S8`
    Map: `R748CNTL`

Subchannel set ID of failing device
"""
r748cfsc.__doc__ = """Subchannel set ID of failing device

SMF Info
--------
    Field: `R748CFSC`
    Record: `SMF74S8`
    Map: `R748CNTL`

Subchannel set ID of failing device
"""

r748laid : Final[Field] = Field(
    name='r748laid',
    origin='R748LAID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748LSS,
)
"""Adapter ID

SMF Info
--------
    Field: `R748LAID`
    Record: `SMF74S8`
    Map: `R748LSS`

Adapter ID
"""
r748laid.__doc__ = """Adapter ID

SMF Info
--------
    Field: `R748LAID`
    Record: `SMF74S8`
    Map: `R748LSS`

Adapter ID
"""

r748ltyp : Final[Field] = Field(
    name='r748ltyp',
    origin='R748LTYP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748LSS,
)
"""Link type 1 ESCON 2 Fibre Channel 1 Gb/s 3 Fibre Channel 2 Gb/s 4 Fibre Channel 4 Gb/s 5 Fibre Channel 8 Gb/s 6 Fibre Channel 16 Gb/s 10 Ethernet Channel 10 Gb/s

SMF Info
--------
    Field: `R748LTYP`
    Record: `SMF74S8`
    Map: `R748LSS`

Link type 1 ESCON 2 Fibre Channel 1 Gb/s 3 Fibre Channel 2 Gb/s 4 Fibre Channel 4 Gb/s 5 Fibre Channel 8 Gb/s 6 Fibre Channel 16 Gb/s 10 Ethernet Channel 10 Gb/s
"""
r748ltyp.__doc__ = """Link type 1 ESCON 2 Fibre Channel 1 Gb/s 3 Fibre Channel 2 Gb/s 4 Fibre Channel 4 Gb/s 5 Fibre Channel 8 Gb/s 6 Fibre Channel 16 Gb/s 10 Ethernet Channel 10 Gb/s

SMF Info
--------
    Field: `R748LTYP`
    Record: `SMF74S8`
    Map: `R748LSS`

Link type 1 ESCON 2 Fibre Channel 1 Gb/s 3 Fibre Channel 2 Gb/s 4 Fibre Channel 4 Gb/s 5 Fibre Channel 8 Gb/s 6 Fibre Channel 16 Gb/s 10 Ethernet Channel 10 Gb/s
"""

r748lflg : Final[Field] = Field(
    name='r748lflg',
    origin='R748LFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R748LSS,
)
"""Flags

SMF Info
--------
    Field: `R748LFLG`
    Record: `SMF74S8`
    Map: `R748LSS`

Flags
"""
r748lflg.__doc__ = """Flags

SMF Info
--------
    Field: `R748LFLG`
    Record: `SMF74S8`
    Map: `R748LSS`

Flags
"""

r748lbyt : Final[Field] = Field(
    name='r748lbyt',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r748lflg,
    record=record,
    record_map=R748LSS,
)
"""On = Units of bytes indeterminable. Byte values incorrect.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748lflg`(`R748LFLG`)
    Record: `SMF74S8`
    Map: `R748LSS`

On = Units of bytes indeterminable. Byte values incorrect.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r748lbyt.__doc__ = """On = Units of bytes indeterminable. Byte values incorrect.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748lflg`(`R748LFLG`)
    Record: `SMF74S8`
    Map: `R748LSS`

On = Units of bytes indeterminable. Byte values incorrect.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r748ltim : Final[Field] = Field(
    name='r748ltim',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r748lflg,
    record=record,
    record_map=R748LSS,
)
"""On = Units of time indeterminable. Time values incorrect.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748lflg`(`R748LFLG`)
    Record: `SMF74S8`
    Map: `R748LSS`

On = Units of time indeterminable. Time values incorrect.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r748ltim.__doc__ = """On = Units of time indeterminable. Time values incorrect.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748lflg`(`R748LFLG`)
    Record: `SMF74S8`
    Map: `R748LSS`

On = Units of time indeterminable. Time values incorrect.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r748lerb : Final[Field] = Field(
    name='r748lerb',
    origin='R748LERB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""ECKD architecture Read in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LERB`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Read in units of 128K bytes (long floating point)
"""
r748lerb.__doc__ = """ECKD architecture Read in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LERB`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Read in units of 128K bytes (long floating point)
"""

r748lewb : Final[Field] = Field(
    name='r748lewb',
    origin='R748LEWB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""ECKD architecture Write units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LEWB`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Write units of 128K bytes (long floating point)
"""
r748lewb.__doc__ = """ECKD architecture Write units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LEWB`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Write units of 128K bytes (long floating point)
"""

r748lero : Final[Field] = Field(
    name='r748lero',
    origin='R748LERO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""ECKD architecture Read Operations. For ESCON ports, one count per chain which transfers customer data to the host. For FICON ports, one count per command which transfers customer data to the host (long floating point).

SMF Info
--------
    Field: `R748LERO`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Read Operations. For ESCON ports, one count per chain which transfers customer data to the host. For FICON ports, one count per command which transfers customer data to the host (long floating point).
"""
r748lero.__doc__ = """ECKD architecture Read Operations. For ESCON ports, one count per chain which transfers customer data to the host. For FICON ports, one count per command which transfers customer data to the host (long floating point).

SMF Info
--------
    Field: `R748LERO`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Read Operations. For ESCON ports, one count per chain which transfers customer data to the host. For FICON ports, one count per command which transfers customer data to the host (long floating point).
"""

r748lewo : Final[Field] = Field(
    name='r748lewo',
    origin='R748LEWO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""ECKD architecture Write Operations. For ESCON ports, one count per chain which transfers customer data from the host. For FICON ports, one count per command which transfers customer data from the host (long floating point). Note: A chain on an ESCON port that has read and write commands is counted as a read chain.

SMF Info
--------
    Field: `R748LEWO`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Write Operations. For ESCON ports, one count per chain which transfers customer data from the host. For FICON ports, one count per command which transfers customer data from the host (long floating point). Note: A chain on an ESCON port that has read and write commands is counted as a read chain.
"""
r748lewo.__doc__ = """ECKD architecture Write Operations. For ESCON ports, one count per chain which transfers customer data from the host. For FICON ports, one count per command which transfers customer data from the host (long floating point). Note: A chain on an ESCON port that has read and write commands is counted as a read chain.

SMF Info
--------
    Field: `R748LEWO`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Write Operations. For ESCON ports, one count per chain which transfers customer data from the host. For FICON ports, one count per command which transfers customer data from the host (long floating point). Note: A chain on an ESCON port that has read and write commands is counted as a read chain.
"""

r748lert : Final[Field] = Field(
    name='r748lert',
    origin='R748LERT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""ECKD architecture Read accumulated time on channel in milliseconds. The active processing time for each command is accumulated (long floating point).

SMF Info
--------
    Field: `R748LERT`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Read accumulated time on channel in milliseconds. The active processing time for each command is accumulated (long floating point).
"""
r748lert.__doc__ = """ECKD architecture Read accumulated time on channel in milliseconds. The active processing time for each command is accumulated (long floating point).

SMF Info
--------
    Field: `R748LERT`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Read accumulated time on channel in milliseconds. The active processing time for each command is accumulated (long floating point).
"""

r748lewt : Final[Field] = Field(
    name='r748lewt',
    origin='R748LEWT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""ECKD architecture Write accumulated time on channel in milliseconds. The active processing time for each command is accumulated (long floating point).

SMF Info
--------
    Field: `R748LEWT`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Write accumulated time on channel in milliseconds. The active processing time for each command is accumulated (long floating point).
"""
r748lewt.__doc__ = """ECKD architecture Write accumulated time on channel in milliseconds. The active processing time for each command is accumulated (long floating point).

SMF Info
--------
    Field: `R748LEWT`
    Record: `SMF74S8`
    Map: `R748LSS`

ECKD architecture Write accumulated time on channel in milliseconds. The active processing time for each command is accumulated (long floating point).
"""

r748lpsb : Final[Field] = Field(
    name='r748lpsb',
    origin='R748LPSB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""PPRC Sent in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LPSB`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Sent in units of 128K bytes (long floating point)
"""
r748lpsb.__doc__ = """PPRC Sent in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LPSB`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Sent in units of 128K bytes (long floating point)
"""

r748lprb : Final[Field] = Field(
    name='r748lprb',
    origin='R748LPRB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""PPRC Received in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LPRB`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Received in units of 128K bytes (long floating point)
"""
r748lprb.__doc__ = """PPRC Received in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LPRB`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Received in units of 128K bytes (long floating point)
"""

r748lpso : Final[Field] = Field(
    name='r748lpso',
    origin='R748LPSO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""PPRC Sent Operations. Each PPRC write command sent by the PPRC primary (long floating point).

SMF Info
--------
    Field: `R748LPSO`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Sent Operations. Each PPRC write command sent by the PPRC primary (long floating point).
"""
r748lpso.__doc__ = """PPRC Sent Operations. Each PPRC write command sent by the PPRC primary (long floating point).

SMF Info
--------
    Field: `R748LPSO`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Sent Operations. Each PPRC write command sent by the PPRC primary (long floating point).
"""

r748lpro : Final[Field] = Field(
    name='r748lpro',
    origin='R748LPRO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""PPRC Received Operations. Each PPRC write command received by the PPRC secondary (long floating point).

SMF Info
--------
    Field: `R748LPRO`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Received Operations. Each PPRC write command received by the PPRC secondary (long floating point).
"""
r748lpro.__doc__ = """PPRC Received Operations. Each PPRC write command received by the PPRC secondary (long floating point).

SMF Info
--------
    Field: `R748LPRO`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Received Operations. Each PPRC write command received by the PPRC secondary (long floating point).
"""

r748lpst : Final[Field] = Field(
    name='r748lpst',
    origin='R748LPST',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""PPRC Sent accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748LPST`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Sent accumulated time in milliseconds (long floating point)
"""
r748lpst.__doc__ = """PPRC Sent accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748LPST`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Sent accumulated time in milliseconds (long floating point)
"""

r748lprt : Final[Field] = Field(
    name='r748lprt',
    origin='R748LPRT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""PPRC Received accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748LPRT`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Received accumulated time in milliseconds (long floating point)
"""
r748lprt.__doc__ = """PPRC Received accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748LPRT`
    Record: `SMF74S8`
    Map: `R748LSS`

PPRC Received accumulated time in milliseconds (long floating point)
"""

r748lsrb : Final[Field] = Field(
    name='r748lsrb',
    origin='R748LSRB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""SCSI Read in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LSRB`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Read in units of 128K bytes (long floating point)
"""
r748lsrb.__doc__ = """SCSI Read in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LSRB`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Read in units of 128K bytes (long floating point)
"""

r748lswb : Final[Field] = Field(
    name='r748lswb',
    origin='R748LSWB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""SCSI Write in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LSWB`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Write in units of 128K bytes (long floating point)
"""
r748lswb.__doc__ = """SCSI Write in units of 128K bytes (long floating point)

SMF Info
--------
    Field: `R748LSWB`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Write in units of 128K bytes (long floating point)
"""

r748lsro : Final[Field] = Field(
    name='r748lsro',
    origin='R748LSRO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""SCSI Read Operations. Each customer read operation is counted (long floating point).

SMF Info
--------
    Field: `R748LSRO`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Read Operations. Each customer read operation is counted (long floating point).
"""
r748lsro.__doc__ = """SCSI Read Operations. Each customer read operation is counted (long floating point).

SMF Info
--------
    Field: `R748LSRO`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Read Operations. Each customer read operation is counted (long floating point).
"""

r748lswo : Final[Field] = Field(
    name='r748lswo',
    origin='R748LSWO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""SCSI Write Operations. Each customer write operation is counted (long floating point).

SMF Info
--------
    Field: `R748LSWO`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Write Operations. Each customer write operation is counted (long floating point).
"""
r748lswo.__doc__ = """SCSI Write Operations. Each customer write operation is counted (long floating point).

SMF Info
--------
    Field: `R748LSWO`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Write Operations. Each customer write operation is counted (long floating point).
"""

r748lsrt : Final[Field] = Field(
    name='r748lsrt',
    origin='R748LSRT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""SCSI Read accumulated time on channel in milliseconds (long floating point).

SMF Info
--------
    Field: `R748LSRT`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Read accumulated time on channel in milliseconds (long floating point).
"""
r748lsrt.__doc__ = """SCSI Read accumulated time on channel in milliseconds (long floating point).

SMF Info
--------
    Field: `R748LSRT`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Read accumulated time on channel in milliseconds (long floating point).
"""

r748lswt : Final[Field] = Field(
    name='r748lswt',
    origin='R748LSWT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""SCSI Write accumulated time on channel in milliseconds (long floating point).

SMF Info
--------
    Field: `R748LSWT`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Write accumulated time on channel in milliseconds (long floating point).
"""
r748lswt.__doc__ = """SCSI Write accumulated time on channel in milliseconds (long floating point).

SMF Info
--------
    Field: `R748LSWT`
    Record: `SMF74S8`
    Map: `R748LSS`

SCSI Write accumulated time on channel in milliseconds (long floating point).
"""

r748lflf : Final[Field] = Field(
    name='r748lflf',
    origin='R748LFLF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel link failures (short floating point).

SMF Info
--------
    Field: `R748LFLF`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel link failures (short floating point).
"""
r748lflf.__doc__ = """Fibre Channel link failures (short floating point).

SMF Info
--------
    Field: `R748LFLF`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel link failures (short floating point).
"""

r748lfly : Final[Field] = Field(
    name='r748lfly',
    origin='R748LFLY',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel synchronization failures (short floating point).

SMF Info
--------
    Field: `R748LFLY`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel synchronization failures (short floating point).
"""
r748lfly.__doc__ = """Fibre Channel synchronization failures (short floating point).

SMF Info
--------
    Field: `R748LFLY`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel synchronization failures (short floating point).
"""

r748lfls : Final[Field] = Field(
    name='r748lfls',
    origin='R748LFLS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel signal failures (short floating point).

SMF Info
--------
    Field: `R748LFLS`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel signal failures (short floating point).
"""
r748lfls.__doc__ = """Fibre Channel signal failures (short floating point).

SMF Info
--------
    Field: `R748LFLS`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel signal failures (short floating point).
"""

r748lfpq : Final[Field] = Field(
    name='r748lfpq',
    origin='R748LFPQ',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Number of Fibre Channel primitive sequnece errors (short floating point).

SMF Info
--------
    Field: `R748LFPQ`
    Record: `SMF74S8`
    Map: `R748LSS`

Number of Fibre Channel primitive sequnece errors (short floating point).
"""
r748lfpq.__doc__ = """Number of Fibre Channel primitive sequnece errors (short floating point).

SMF Info
--------
    Field: `R748LFPQ`
    Record: `SMF74S8`
    Map: `R748LSS`

Number of Fibre Channel primitive sequnece errors (short floating point).
"""

r748lfit : Final[Field] = Field(
    name='r748lfit',
    origin='R748LFIT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel invalid transmission word errors (short floating point).

SMF Info
--------
    Field: `R748LFIT`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel invalid transmission word errors (short floating point).
"""
r748lfit.__doc__ = """Fibre Channel invalid transmission word errors (short floating point).

SMF Info
--------
    Field: `R748LFIT`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel invalid transmission word errors (short floating point).
"""

r748lfcr : Final[Field] = Field(
    name='r748lfcr',
    origin='R748LFCR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel cyclic redundancy check (CRC) errors (short floating point).

SMF Info
--------
    Field: `R748LFCR`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel cyclic redundancy check (CRC) errors (short floating point).
"""
r748lfcr.__doc__ = """Fibre Channel cyclic redundancy check (CRC) errors (short floating point).

SMF Info
--------
    Field: `R748LFCR`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel cyclic redundancy check (CRC) errors (short floating point).
"""

r748lfr1 : Final[Field] = Field(
    name='r748lfr1',
    origin='R748LFR1',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel link recovery (LR) sent (short floating point).

SMF Info
--------
    Field: `R748LFR1`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel link recovery (LR) sent (short floating point).
"""
r748lfr1.__doc__ = """Fibre Channel link recovery (LR) sent (short floating point).

SMF Info
--------
    Field: `R748LFR1`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel link recovery (LR) sent (short floating point).
"""

r748lfr2 : Final[Field] = Field(
    name='r748lfr2',
    origin='R748LFR2',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel link recovery (LR) received (short floating point).

SMF Info
--------
    Field: `R748LFR2`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel link recovery (LR) received (short floating point).
"""
r748lfr2.__doc__ = """Fibre Channel link recovery (LR) received (short floating point).

SMF Info
--------
    Field: `R748LFR2`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel link recovery (LR) received (short floating point).
"""

r748lfif : Final[Field] = Field(
    name='r748lfif',
    origin='R748LFIF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel illegal frame errors (short floating point).

SMF Info
--------
    Field: `R748LFIF`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel illegal frame errors (short floating point).
"""
r748lfif.__doc__ = """Fibre Channel illegal frame errors (short floating point).

SMF Info
--------
    Field: `R748LFIF`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel illegal frame errors (short floating point).
"""

r748lfod : Final[Field] = Field(
    name='r748lfod',
    origin='R748LFOD',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel out of order data errors (short floating point).

SMF Info
--------
    Field: `R748LFOD`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel out of order data errors (short floating point).
"""
r748lfod.__doc__ = """Fibre Channel out of order data errors (short floating point).

SMF Info
--------
    Field: `R748LFOD`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel out of order data errors (short floating point).
"""

r748lfoa : Final[Field] = Field(
    name='r748lfoa',
    origin='R748LFOA',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel out of order ACK errors (short floating point).

SMF Info
--------
    Field: `R748LFOA`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel out of order ACK errors (short floating point).
"""
r748lfoa.__doc__ = """Fibre Channel out of order ACK errors (short floating point).

SMF Info
--------
    Field: `R748LFOA`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel out of order ACK errors (short floating point).
"""

r748lfdf : Final[Field] = Field(
    name='r748lfdf',
    origin='R748LFDF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel duplicate frame errors (short floating point).

SMF Info
--------
    Field: `R748LFDF`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel duplicate frame errors (short floating point).
"""
r748lfdf.__doc__ = """Fibre Channel duplicate frame errors (short floating point).

SMF Info
--------
    Field: `R748LFDF`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel duplicate frame errors (short floating point).
"""

r748lfio : Final[Field] = Field(
    name='r748lfio',
    origin='R748LFIO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel invalid relative offset failures (short floating point).

SMF Info
--------
    Field: `R748LFIO`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel invalid relative offset failures (short floating point).
"""
r748lfio.__doc__ = """Fibre Channel invalid relative offset failures (short floating point).

SMF Info
--------
    Field: `R748LFIO`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel invalid relative offset failures (short floating point).
"""

r748lftc : Final[Field] = Field(
    name='r748lftc',
    origin='R748LFTC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel sequence timeout errors (short floating point).

SMF Info
--------
    Field: `R748LFTC`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel sequence timeout errors (short floating point).
"""
r748lftc.__doc__ = """Fibre Channel sequence timeout errors (short floating point).

SMF Info
--------
    Field: `R748LFTC`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel sequence timeout errors (short floating point).
"""

r748lfbc : Final[Field] = Field(
    name='r748lfbc',
    origin='R748LFBC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748LSS,
)
"""Fibre Channel bit error rate

SMF Info
--------
    Field: `R748LFBC`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel bit error rate
"""
r748lfbc.__doc__ = """Fibre Channel bit error rate

SMF Info
--------
    Field: `R748LFBC`
    Record: `SMF74S8`
    Map: `R748LSS`

Fibre Channel bit error rate
"""

r748xpid : Final[Field] = Field(
    name='r748xpid',
    origin='R748XPID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Extent pool identifier

SMF Info
--------
    Field: `R748XPID`
    Record: `SMF74S8`
    Map: `R748EXTP`

Extent pool identifier
"""
r748xpid.__doc__ = """Extent pool identifier

SMF Info
--------
    Field: `R748XPID`
    Record: `SMF74S8`
    Map: `R748EXTP`

Extent pool identifier
"""

r748xplt : Final[Field] = Field(
    name='r748xplt',
    origin='R748XPLT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Extent pool type 00-03 = RESERVED, 04 = FB 1Gb, 05-131 = RESERVED, 132 = CKD 1Gb, 133-255 = RESERVED

SMF Info
--------
    Field: `R748XPLT`
    Record: `SMF74S8`
    Map: `R748EXTP`

Extent pool type 00-03 = RESERVED, 04 = FB 1Gb, 05-131 = RESERVED, 132 = CKD 1Gb, 133-255 = RESERVED
"""
r748xplt.__doc__ = """Extent pool type 00-03 = RESERVED, 04 = FB 1Gb, 05-131 = RESERVED, 132 = CKD 1Gb, 133-255 = RESERVED

SMF Info
--------
    Field: `R748XPLT`
    Record: `SMF74S8`
    Map: `R748EXTP`

Extent pool type 00-03 = RESERVED, 04 = FB 1Gb, 05-131 = RESERVED, 132 = CKD 1Gb, 133-255 = RESERVED
"""

r748xptq : Final[Field] = Field(
    name='r748xptq',
    origin='R748XPTQ',
    type=FieldType.STRING,
    record=record,
    record_map=R748EXTP,
)
"""Extent pool type qualifier

SMF Info
--------
    Field: `R748XPTQ`
    Record: `SMF74S8`
    Map: `R748EXTP`

Extent pool type qualifier
"""
r748xptq.__doc__ = """Extent pool type qualifier

SMF Info
--------
    Field: `R748XPTQ`
    Record: `SMF74S8`
    Map: `R748EXTP`

Extent pool type qualifier
"""

r748xtcr : Final[Field] = Field(
    name='r748xtcr',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r748xptq,
    record=record,
    record_map=R748EXTP,
)
"""'1' = Data encrpted extent pool(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748xptq`(`R748XPTQ`)
    Record: `SMF74S8`
    Map: `R748EXTP`

'1' = Data encrpted extent pool

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r748xtcr.__doc__ = """'1' = Data encrpted extent pool(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748xptq`(`R748XPTQ`)
    Record: `SMF74S8`
    Map: `R748EXTP`

'1' = Data encrpted extent pool

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r748xrcp : Final[Field] = Field(
    name='r748xrcp',
    origin='R748XRCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Real extent pool capacity in GB

SMF Info
--------
    Field: `R748XRCP`
    Record: `SMF74S8`
    Map: `R748EXTP`

Real extent pool capacity in GB
"""
r748xrcp.__doc__ = """Real extent pool capacity in GB

SMF Info
--------
    Field: `R748XRCP`
    Record: `SMF74S8`
    Map: `R748EXTP`

Real extent pool capacity in GB
"""

r748xrns : Final[Field] = Field(
    name='r748xrns',
    origin='R748XRNS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Number of real extents in extent pool

SMF Info
--------
    Field: `R748XRNS`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of real extents in extent pool
"""
r748xrns.__doc__ = """Number of real extents in extent pool

SMF Info
--------
    Field: `R748XRNS`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of real extents in extent pool
"""

r748xrna : Final[Field] = Field(
    name='r748xrna',
    origin='R748XRNA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Number of real allocated extents in extent pool

SMF Info
--------
    Field: `R748XRNA`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of real allocated extents in extent pool
"""
r748xrna.__doc__ = """Number of real allocated extents in extent pool

SMF Info
--------
    Field: `R748XRNA`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of real allocated extents in extent pool
"""

r748xrsc : Final[Field] = Field(
    name='r748xrsc',
    origin='R748XRSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Real extent conversions. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XRSC`
    Record: `SMF74S8`
    Map: `R748EXTP`

Real extent conversions. Valid if bit R748CXVL is set
"""
r748xrsc.__doc__ = """Real extent conversions. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XRSC`
    Record: `SMF74S8`
    Map: `R748EXTP`

Real extent conversions. Valid if bit R748CXVL is set
"""

r748xvcp : Final[Field] = Field(
    name='r748xvcp',
    origin='R748XVCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Virtual extent pool capacity in GB. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XVCP`
    Record: `SMF74S8`
    Map: `R748EXTP`

Virtual extent pool capacity in GB. Valid if bit R748CXVL is set
"""
r748xvcp.__doc__ = """Virtual extent pool capacity in GB. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XVCP`
    Record: `SMF74S8`
    Map: `R748EXTP`

Virtual extent pool capacity in GB. Valid if bit R748CXVL is set
"""

r748xvns : Final[Field] = Field(
    name='r748xvns',
    origin='R748XVNS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Number of virtual extents in extent pool. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XVNS`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of virtual extents in extent pool. Valid if bit R748CXVL is set
"""
r748xvns.__doc__ = """Number of virtual extents in extent pool. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XVNS`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of virtual extents in extent pool. Valid if bit R748CXVL is set
"""

r748xvsc : Final[Field] = Field(
    name='r748xvsc',
    origin='R748XVSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Virtual extent conversions. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XVSC`
    Record: `SMF74S8`
    Map: `R748EXTP`

Virtual extent conversions. Valid if bit R748CXVL is set
"""
r748xvsc.__doc__ = """Virtual extent conversions. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XVSC`
    Record: `SMF74S8`
    Map: `R748EXTP`

Virtual extent conversions. Valid if bit R748CXVL is set
"""

r748xsdy : Final[Field] = Field(
    name='r748xsdy',
    origin='R748XSDY',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Number of extents that were sources of dynamic extent relocations. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XSDY`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of extents that were sources of dynamic extent relocations. Valid if bit R748CXVL is set
"""
r748xsdy.__doc__ = """Number of extents that were sources of dynamic extent relocations. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XSDY`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of extents that were sources of dynamic extent relocations. Valid if bit R748CXVL is set
"""

r748xtdy : Final[Field] = Field(
    name='r748xtdy',
    origin='R748XTDY',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748EXTP,
)
"""Number of extents that were targets of dynamic extent relocations. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XTDY`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of extents that were targets of dynamic extent relocations. Valid if bit R748CXVL is set
"""
r748xtdy.__doc__ = """Number of extents that were targets of dynamic extent relocations. Valid if bit R748CXVL is set

SMF Info
--------
    Field: `R748XTDY`
    Record: `SMF74S8`
    Map: `R748EXTP`

Number of extents that were targets of dynamic extent relocations. Valid if bit R748CXVL is set
"""

r748rrid : Final[Field] = Field(
    name='r748rrid',
    origin='R748RRID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748RANK,
)
"""Rank identifier

SMF Info
--------
    Field: `R748RRID`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank identifier
"""
r748rrid.__doc__ = """Rank identifier

SMF Info
--------
    Field: `R748RRID`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank identifier
"""

r748rpnm : Final[Field] = Field(
    name='r748rpnm',
    origin='R748RPNM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748RANK,
)
"""Extent pool number

SMF Info
--------
    Field: `R748RPNM`
    Record: `SMF74S8`
    Map: `R748RANK`

Extent pool number
"""
r748rpnm.__doc__ = """Extent pool number

SMF Info
--------
    Field: `R748RPNM`
    Record: `SMF74S8`
    Map: `R748RANK`

Extent pool number
"""

r748rcnt : Final[Field] = Field(
    name='r748rcnt',
    origin='R748RCNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748RANK,
)
"""Count of arrays in rank

SMF Info
--------
    Field: `R748RCNT`
    Record: `SMF74S8`
    Map: `R748RANK`

Count of arrays in rank
"""
r748rcnt.__doc__ = """Count of arrays in rank

SMF Info
--------
    Field: `R748RCNT`
    Record: `SMF74S8`
    Map: `R748RANK`

Count of arrays in rank
"""

r748raix : Final[Field] = Field(
    name='r748raix',
    origin='R748RAIX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748RANK,
)
"""Index to first array section of rank

SMF Info
--------
    Field: `R748RAIX`
    Record: `SMF74S8`
    Map: `R748RANK`

Index to first array section of rank
"""
r748raix.__doc__ = """Index to first array section of rank

SMF Info
--------
    Field: `R748RAIX`
    Record: `SMF74S8`
    Map: `R748RANK`

Index to first array section of rank
"""

r748rbyr : Final[Field] = Field(
    name='r748rbyr',
    origin='R748RBYR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748RANK,
)
"""Rank 128 KBYtes read. (long floating point)

SMF Info
--------
    Field: `R748RBYR`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank 128 KBYtes read. (long floating point)
"""
r748rbyr.__doc__ = """Rank 128 KBYtes read. (long floating point)

SMF Info
--------
    Field: `R748RBYR`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank 128 KBYtes read. (long floating point)
"""

r748rbyw : Final[Field] = Field(
    name='r748rbyw',
    origin='R748RBYW',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748RANK,
)
"""Rank 128 KBYtes write. (long floating point)

SMF Info
--------
    Field: `R748RBYW`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank 128 KBYtes write. (long floating point)
"""
r748rbyw.__doc__ = """Rank 128 KBYtes write. (long floating point)

SMF Info
--------
    Field: `R748RBYW`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank 128 KBYtes write. (long floating point)
"""

r748rrop : Final[Field] = Field(
    name='r748rrop',
    origin='R748RROP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748RANK,
)
"""Rank read operations. (long floating point)

SMF Info
--------
    Field: `R748RROP`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank read operations. (long floating point)
"""
r748rrop.__doc__ = """Rank read operations. (long floating point)

SMF Info
--------
    Field: `R748RROP`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank read operations. (long floating point)
"""

r748rwop : Final[Field] = Field(
    name='r748rwop',
    origin='R748RWOP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748RANK,
)
"""Rank write operations. (long floating point)

SMF Info
--------
    Field: `R748RWOP`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank write operations. (long floating point)
"""
r748rwop.__doc__ = """Rank write operations. (long floating point)

SMF Info
--------
    Field: `R748RWOP`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank write operations. (long floating point)
"""

r748rkrt : Final[Field] = Field(
    name='r748rkrt',
    origin='R748RKRT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748RANK,
)
"""Rank read response time in units of 16 milliseconds. (long floating point)

SMF Info
--------
    Field: `R748RKRT`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank read response time in units of 16 milliseconds. (long floating point)
"""
r748rkrt.__doc__ = """Rank read response time in units of 16 milliseconds. (long floating point)

SMF Info
--------
    Field: `R748RKRT`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank read response time in units of 16 milliseconds. (long floating point)
"""

r748rkwt : Final[Field] = Field(
    name='r748rkwt',
    origin='R748RKWT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748RANK,
)
"""Rank write response time in units of 16 milliseconds. (long floating point)

SMF Info
--------
    Field: `R748RKWT`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank write response time in units of 16 milliseconds. (long floating point)
"""
r748rkwt.__doc__ = """Rank write response time in units of 16 milliseconds. (long floating point)

SMF Info
--------
    Field: `R748RKWT`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank write response time in units of 16 milliseconds. (long floating point)
"""

r748rtq : Final[Field] = Field(
    name='r748rtq',
    origin='R748RTQ',
    type=FieldType.STRING,
    record=record,
    record_map=R748RANK,
)
"""Rank type qualifer

SMF Info
--------
    Field: `R748RTQ`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank type qualifer
"""
r748rtq.__doc__ = """Rank type qualifer

SMF Info
--------
    Field: `R748RTQ`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank type qualifer
"""

r748rtcr : Final[Field] = Field(
    name='r748rtcr',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r748rtq,
    record=record,
    record_map=R748RANK,
)
"""'1' = Data encrypted rank(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748rtq`(`R748RTQ`)
    Record: `SMF74S8`
    Map: `R748RANK`

'1' = Data encrypted rank

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r748rtcr.__doc__ = """'1' = Data encrypted rank(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748rtq`(`R748RTQ`)
    Record: `SMF74S8`
    Map: `R748RANK`

'1' = Data encrypted rank

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r748raiv : Final[Field] = Field(
    name='r748raiv',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r748rtq,
    record=record,
    record_map=R748RANK,
)
"""'1' = Rank adapter pair id valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748rtq`(`R748RTQ`)
    Record: `SMF74S8`
    Map: `R748RANK`

'1' = Rank adapter pair id valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r748raiv.__doc__ = """'1' = Rank adapter pair id valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748rtq`(`R748RTQ`)
    Record: `SMF74S8`
    Map: `R748RANK`

'1' = Rank adapter pair id valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r748rai : Final[Field] = Field(
    name='r748rai',
    origin='R748RAI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748RANK,
)
"""Rank adapter pair id

SMF Info
--------
    Field: `R748RAI`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank adapter pair id
"""
r748rai.__doc__ = """Rank adapter pair id

SMF Info
--------
    Field: `R748RAI`
    Record: `SMF74S8`
    Map: `R748RANK`

Rank adapter pair id
"""

r748aaid : Final[Field] = Field(
    name='r748aaid',
    origin='R748AAID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748ARRY,
)
"""Rank array identifier

SMF Info
--------
    Field: `R748AAID`
    Record: `SMF74S8`
    Map: `R748ARRY`

Rank array identifier
"""
r748aaid.__doc__ = """Rank array identifier

SMF Info
--------
    Field: `R748AAID`
    Record: `SMF74S8`
    Map: `R748ARRY`

Rank array identifier
"""

r748arid : Final[Field] = Field(
    name='r748arid',
    origin='R748ARID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748ARRY,
)
"""Rank identfier

SMF Info
--------
    Field: `R748ARID`
    Record: `SMF74S8`
    Map: `R748ARRY`

Rank identfier
"""
r748arid.__doc__ = """Rank identfier

SMF Info
--------
    Field: `R748ARID`
    Record: `SMF74S8`
    Map: `R748ARRY`

Rank identfier
"""

r748aebc : Final[Field] = Field(
    name='r748aebc',
    origin='R748AEBC',
    type=FieldType.STRING,
    record=record,
    record_map=R748ARRY,
)
"""Array type in EBCDIC

SMF Info
--------
    Field: `R748AEBC`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array type in EBCDIC
"""
r748aebc.__doc__ = """Array type in EBCDIC

SMF Info
--------
    Field: `R748AEBC`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array type in EBCDIC
"""

r748atyp : Final[Field] = Field(
    name='r748atyp',
    origin='R748ATYP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748ARRY,
)
"""Array type 01 = RAID-5, 02 = RAID-10, 03 = RAID-6, 04-FF Not used

SMF Info
--------
    Field: `R748ATYP`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array type 01 = RAID-5, 02 = RAID-10, 03 = RAID-6, 04-FF Not used
"""
r748atyp.__doc__ = """Array type 01 = RAID-5, 02 = RAID-10, 03 = RAID-6, 04-FF Not used

SMF Info
--------
    Field: `R748ATYP`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array type 01 = RAID-5, 02 = RAID-10, 03 = RAID-6, 04-FF Not used
"""

r748aasp : Final[Field] = Field(
    name='r748aasp',
    origin='R748AASP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748ARRY,
)
"""Array speed in 1000 RPM

SMF Info
--------
    Field: `R748AASP`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array speed in 1000 RPM
"""
r748aasp.__doc__ = """Array speed in 1000 RPM

SMF Info
--------
    Field: `R748AASP`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array speed in 1000 RPM
"""

r748aawd : Final[Field] = Field(
    name='r748aawd',
    origin='R748AAWD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748ARRY,
)
"""Array width

SMF Info
--------
    Field: `R748AAWD`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array width
"""
r748aawd.__doc__ = """Array width

SMF Info
--------
    Field: `R748AAWD`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array width
"""

r748aacp : Final[Field] = Field(
    name='r748aacp',
    origin='R748AACP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748ARRY,
)
"""Array capacity in GB

SMF Info
--------
    Field: `R748AACP`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array capacity in GB
"""
r748aacp.__doc__ = """Array capacity in GB

SMF Info
--------
    Field: `R748AACP`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array capacity in GB
"""

r748aast : Final[Field] = Field(
    name='r748aast',
    origin='R748AAST',
    type=FieldType.STRING,
    record=record,
    record_map=R748ARRY,
)
"""Array device class and Array status

SMF Info
--------
    Field: `R748AAST`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array device class and Array status
"""
r748aast.__doc__ = """Array device class and Array status

SMF Info
--------
    Field: `R748AAST`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array device class and Array status
"""

r748adc : Final[Field] = Field(
    name='r748adc',
    origin='R748ADC',
    type=FieldType.STRING,
    record=record,
    record_map=R748ARRY,
)
"""Array device class 00 = Enterprise 01 = Near-line 10 = SATA 11 = Solid state drive

SMF Info
--------
    Field: `R748ADC`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array device class 00 = Enterprise 01 = Near-line 10 = SATA 11 = Solid state drive
"""
r748adc.__doc__ = """Array device class 00 = Enterprise 01 = Near-line 10 = SATA 11 = Solid state drive

SMF Info
--------
    Field: `R748ADC`
    Record: `SMF74S8`
    Map: `R748ARRY`

Array device class 00 = Enterprise 01 = Near-line 10 = SATA 11 = Solid state drive
"""

r748ard : Final[Field] = Field(
    name='r748ard',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r748adc,
    record=record,
    record_map=R748ARRY,
)
"""'1' = Raid degraded(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748adc`(`R748ADC`)
    Record: `SMF74S8`
    Map: `R748ARRY`

'1' = Raid degraded

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r748ard.__doc__ = """'1' = Raid degraded(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748adc`(`R748ADC`)
    Record: `SMF74S8`
    Map: `R748ARRY`

'1' = Raid degraded

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r748adt : Final[Field] = Field(
    name='r748adt',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r748adc,
    record=record,
    record_map=R748ARRY,
)
"""'1' = DDM throttling(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748adc`(`R748ADC`)
    Record: `SMF74S8`
    Map: `R748ARRY`

'1' = DDM throttling

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r748adt.__doc__ = """'1' = DDM throttling(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748adc`(`R748ADC`)
    Record: `SMF74S8`
    Map: `R748ARRY`

'1' = DDM throttling

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r748are : Final[Field] = Field(
    name='r748are',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r748adc,
    record=record,
    record_map=R748ARRY,
)
"""'1' = RPM exception(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748adc`(`R748ADC`)
    Record: `SMF74S8`
    Map: `R748ARRY`

'1' = RPM exception

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r748are.__doc__ = """'1' = RPM exception(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748adc`(`R748ADC`)
    Record: `SMF74S8`
    Map: `R748ARRY`

'1' = RPM exception

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r748siid : Final[Field] = Field(
    name='r748siid',
    origin='R748SIID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O link interface identifier.

SMF Info
--------
    Field: `R748SIID`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link interface identifier.
"""
r748siid.__doc__ = """Synchronous I/O link interface identifier.

SMF Info
--------
    Field: `R748SIID`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link interface identifier.
"""

r748styp : Final[Field] = Field(
    name='r748styp',
    origin='R748STYP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O link type. 00 Not used 01 Optical PCIe 02-FF Not used

SMF Info
--------
    Field: `R748STYP`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link type. 00 Not used 01 Optical PCIe 02-FF Not used
"""
r748styp.__doc__ = """Synchronous I/O link type. 00 Not used 01 Optical PCIe 02-FF Not used

SMF Info
--------
    Field: `R748STYP`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link type. 00 Not used 01 Optical PCIe 02-FF Not used
"""

r748sspd : Final[Field] = Field(
    name='r748sspd',
    origin='R748SSPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O link type. 00 Not used 01 PCIe Gen 1 02 PCIe Gen 2 03 PCIe Gen 3 04 PCIe Gen 4 05-FF Not used

SMF Info
--------
    Field: `R748SSPD`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link type. 00 Not used 01 PCIe Gen 1 02 PCIe Gen 2 03 PCIe Gen 3 04 PCIe Gen 4 05-FF Not used
"""
r748sspd.__doc__ = """Synchronous I/O link type. 00 Not used 01 PCIe Gen 1 02 PCIe Gen 2 03 PCIe Gen 3 04 PCIe Gen 4 05-FF Not used

SMF Info
--------
    Field: `R748SSPD`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link type. 00 Not used 01 PCIe Gen 1 02 PCIe Gen 2 03 PCIe Gen 3 04 PCIe Gen 4 05-FF Not used
"""

r748swdh : Final[Field] = Field(
    name='r748swdh',
    origin='R748SWDH',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O link width. This is the number of PCIe lanes.

SMF Info
--------
    Field: `R748SWDH`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link width. This is the number of PCIe lanes.
"""
r748swdh.__doc__ = """Synchronous I/O link width. This is the number of PCIe lanes.

SMF Info
--------
    Field: `R748SWDH`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link width. This is the number of PCIe lanes.
"""

r748sste : Final[Field] = Field(
    name='r748sste',
    origin='R748SSTE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O link type. 00 Not used 01 Link not trained 02 Link handshake incomplete 03 Link handshake complete, link operational 04 Link in service mode 05-FF Not used

SMF Info
--------
    Field: `R748SSTE`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link type. 00 Not used 01 Link not trained 02 Link handshake incomplete 03 Link handshake complete, link operational 04 Link in service mode 05-FF Not used
"""
r748sste.__doc__ = """Synchronous I/O link type. 00 Not used 01 Link not trained 02 Link handshake incomplete 03 Link handshake complete, link operational 04 Link in service mode 05-FF Not used

SMF Info
--------
    Field: `R748SSTE`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O link type. 00 Not used 01 Link not trained 02 Link handshake incomplete 03 Link handshake complete, link operational 04 Link in service mode 05-FF Not used
"""

r748sflg : Final[Field] = Field(
    name='r748sflg',
    origin='R748SFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R748SIOL,
)
"""Flags

SMF Info
--------
    Field: `R748SFLG`
    Record: `SMF74S8`
    Map: `R748SIOL`

Flags
"""
r748sflg.__doc__ = """Flags

SMF Info
--------
    Field: `R748SFLG`
    Record: `SMF74S8`
    Map: `R748SIOL`

Flags
"""

r748sbyt : Final[Field] = Field(
    name='r748sbyt',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r748sflg,
    record=record,
    record_map=R748SIOL,
)
"""On = Units of bytes indeterminable. Byte values incorrect.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748sflg`(`R748SFLG`)
    Record: `SMF74S8`
    Map: `R748SIOL`

On = Units of bytes indeterminable. Byte values incorrect.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r748sbyt.__doc__ = """On = Units of bytes indeterminable. Byte values incorrect.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748sflg`(`R748SFLG`)
    Record: `SMF74S8`
    Map: `R748SIOL`

On = Units of bytes indeterminable. Byte values incorrect.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r748stim : Final[Field] = Field(
    name='r748stim',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r748sflg,
    record=record,
    record_map=R748SIOL,
)
"""On = Units of time indeterminable. Time values incorrect.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748sflg`(`R748SFLG`)
    Record: `SMF74S8`
    Map: `R748SIOL`

On = Units of time indeterminable. Time values incorrect.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r748stim.__doc__ = """On = Units of time indeterminable. Time values incorrect.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r748sflg`(`R748SFLG`)
    Record: `SMF74S8`
    Map: `R748SIOL`

On = Units of time indeterminable. Time values incorrect.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r748scbr : Final[Field] = Field(
    name='r748scbr',
    origin='R748SCBR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O cache bytes read in units of 128K bytes. (long floating point)

SMF Info
--------
    Field: `R748SCBR`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O cache bytes read in units of 128K bytes. (long floating point)
"""
r748scbr.__doc__ = """Synchronous I/O cache bytes read in units of 128K bytes. (long floating point)

SMF Info
--------
    Field: `R748SCBR`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O cache bytes read in units of 128K bytes. (long floating point)
"""

r748scro : Final[Field] = Field(
    name='r748scro',
    origin='R748SCRO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Total number of synchronous I/O cache read operations. (long floating point)

SMF Info
--------
    Field: `R748SCRO`
    Record: `SMF74S8`
    Map: `R748SIOL`

Total number of synchronous I/O cache read operations. (long floating point)
"""
r748scro.__doc__ = """Total number of synchronous I/O cache read operations. (long floating point)

SMF Info
--------
    Field: `R748SCRO`
    Record: `SMF74S8`
    Map: `R748SIOL`

Total number of synchronous I/O cache read operations. (long floating point)
"""

r748scrs : Final[Field] = Field(
    name='r748scrs',
    origin='R748SCRS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Number of successful synchronous I/O cache read operations. (long floating point)

SMF Info
--------
    Field: `R748SCRS`
    Record: `SMF74S8`
    Map: `R748SIOL`

Number of successful synchronous I/O cache read operations. (long floating point)
"""
r748scrs.__doc__ = """Number of successful synchronous I/O cache read operations. (long floating point)

SMF Info
--------
    Field: `R748SCRS`
    Record: `SMF74S8`
    Map: `R748SIOL`

Number of successful synchronous I/O cache read operations. (long floating point)
"""

r748scrt : Final[Field] = Field(
    name='r748scrt',
    origin='R748SCRT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O cache read accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748SCRT`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O cache read accumulated time in milliseconds (long floating point)
"""
r748scrt.__doc__ = """Synchronous I/O cache read accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748SCRT`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O cache read accumulated time in milliseconds (long floating point)
"""

r748scbw : Final[Field] = Field(
    name='r748scbw',
    origin='R748SCBW',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O cache bytes written in units of 128K bytes. (long floating point)

SMF Info
--------
    Field: `R748SCBW`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O cache bytes written in units of 128K bytes. (long floating point)
"""
r748scbw.__doc__ = """Synchronous I/O cache bytes written in units of 128K bytes. (long floating point)

SMF Info
--------
    Field: `R748SCBW`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O cache bytes written in units of 128K bytes. (long floating point)
"""

r748scwo : Final[Field] = Field(
    name='r748scwo',
    origin='R748SCWO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Total number of synchronous I/O cache write operations. (long floating point)

SMF Info
--------
    Field: `R748SCWO`
    Record: `SMF74S8`
    Map: `R748SIOL`

Total number of synchronous I/O cache write operations. (long floating point)
"""
r748scwo.__doc__ = """Total number of synchronous I/O cache write operations. (long floating point)

SMF Info
--------
    Field: `R748SCWO`
    Record: `SMF74S8`
    Map: `R748SIOL`

Total number of synchronous I/O cache write operations. (long floating point)
"""

r748scws : Final[Field] = Field(
    name='r748scws',
    origin='R748SCWS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Number of successful synchronous I/O cache write operations. (long floating point)

SMF Info
--------
    Field: `R748SCWS`
    Record: `SMF74S8`
    Map: `R748SIOL`

Number of successful synchronous I/O cache write operations. (long floating point)
"""
r748scws.__doc__ = """Number of successful synchronous I/O cache write operations. (long floating point)

SMF Info
--------
    Field: `R748SCWS`
    Record: `SMF74S8`
    Map: `R748SIOL`

Number of successful synchronous I/O cache write operations. (long floating point)
"""

r748scwt : Final[Field] = Field(
    name='r748scwt',
    origin='R748SCWT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O cache write accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748SCWT`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O cache write accumulated time in milliseconds (long floating point)
"""
r748scwt.__doc__ = """Synchronous I/O cache write accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748SCWT`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O cache write accumulated time in milliseconds (long floating point)
"""

r748snbw : Final[Field] = Field(
    name='r748snbw',
    origin='R748SNBW',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O NVS bytes written in units of 128K bytes. (long floating point)

SMF Info
--------
    Field: `R748SNBW`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O NVS bytes written in units of 128K bytes. (long floating point)
"""
r748snbw.__doc__ = """Synchronous I/O NVS bytes written in units of 128K bytes. (long floating point)

SMF Info
--------
    Field: `R748SNBW`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O NVS bytes written in units of 128K bytes. (long floating point)
"""

r748snwo : Final[Field] = Field(
    name='r748snwo',
    origin='R748SNWO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Total number of synchronous I/O NVS write operations. (long floating point)

SMF Info
--------
    Field: `R748SNWO`
    Record: `SMF74S8`
    Map: `R748SIOL`

Total number of synchronous I/O NVS write operations. (long floating point)
"""
r748snwo.__doc__ = """Total number of synchronous I/O NVS write operations. (long floating point)

SMF Info
--------
    Field: `R748SNWO`
    Record: `SMF74S8`
    Map: `R748SIOL`

Total number of synchronous I/O NVS write operations. (long floating point)
"""

r748snws : Final[Field] = Field(
    name='r748snws',
    origin='R748SNWS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Number of successful synchronous I/O NVS write operations. (long floating point)

SMF Info
--------
    Field: `R748SNWS`
    Record: `SMF74S8`
    Map: `R748SIOL`

Number of successful synchronous I/O NVS write operations. (long floating point)
"""
r748snws.__doc__ = """Number of successful synchronous I/O NVS write operations. (long floating point)

SMF Info
--------
    Field: `R748SNWS`
    Record: `SMF74S8`
    Map: `R748SIOL`

Number of successful synchronous I/O NVS write operations. (long floating point)
"""

r748snwt : Final[Field] = Field(
    name='r748snwt',
    origin='R748SNWT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R748SIOL,
)
"""Synchronous I/O NVS write accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748SNWT`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O NVS write accumulated time in milliseconds (long floating point)
"""
r748snwt.__doc__ = """Synchronous I/O NVS write accumulated time in milliseconds (long floating point)

SMF Info
--------
    Field: `R748SNWT`
    Record: `SMF74S8`
    Map: `R748SIOL`

Synchronous I/O NVS write accumulated time in milliseconds (long floating point)
"""
