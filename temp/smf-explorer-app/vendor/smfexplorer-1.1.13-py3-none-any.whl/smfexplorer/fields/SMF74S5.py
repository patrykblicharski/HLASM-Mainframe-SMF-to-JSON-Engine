# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 5"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=5,
                                spec='SMF 74 Subtype 5',
                                post=None)
"""SMF 74 Subtype 5"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R745CNTL: Final[RecordMap] = RecordMap(
    origin='R745CNTL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Cache Control Section',
    post=None,
    record_mapping=False)
"""Cache Control Section"""
R745DEV: Final[RecordMap] = RecordMap(
    origin='R745DEV',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Cache Device Data Section',
    post=None,
    record_mapping=False)
"""Cache Device Data Section"""
R745XDEV: Final[RecordMap] = RecordMap(
    origin='R745XDEV',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Cache Device Data Section Extension',
    post=None,
    record_mapping=False)
"""Cache Device Data Section Extension"""
R745STAT: Final[RecordMap] = RecordMap(
    origin='R745STAT',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Cache Status Data Section',
    post=None,
    record_mapping=False)
"""Cache Status Data Section"""
R7451DEV: Final[RecordMap] = RecordMap(
    origin='R7451DEV',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='RAID Rank Data Section',
    post=None,
    record_mapping=False)
"""RAID Rank Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S5`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S5`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S5`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S5`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S5`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S5`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S5`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S5`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S5`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S5`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S5`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S5`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S5`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S5`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S5`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S5`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S5`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S5`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S5`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S5`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S5`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S5`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S5`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S5`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S5`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S5`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S5`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S5`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S5`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S5`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S5`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S5`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S5`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

co : Final[Field] = Field(
    name='co',
    origin='SMF745CO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to control section

SMF Info
--------
    Field: `SMF745CO`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to control section
"""
co.__doc__ = """Offset to control section

SMF Info
--------
    Field: `SMF745CO`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to control section
"""

cl : Final[Field] = Field(
    name='cl',
    origin='SMF745CL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of control section

SMF Info
--------
    Field: `SMF745CL`
    Record: `SMF74S5`
    Map: Not part of a map

Length of control section
"""
cl.__doc__ = """Length of control section

SMF Info
--------
    Field: `SMF745CL`
    Record: `SMF74S5`
    Map: Not part of a map

Length of control section
"""

cn : Final[Field] = Field(
    name='cn',
    origin='SMF745CN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of control sections

SMF Info
--------
    Field: `SMF745CN`
    Record: `SMF74S5`
    Map: Not part of a map

Number of control sections
"""
cn.__doc__ = """Number of control sections

SMF Info
--------
    Field: `SMF745CN`
    Record: `SMF74S5`
    Map: Not part of a map

Number of control sections
"""

do : Final[Field] = Field(
    name='do',
    origin='SMF745DO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CACHE device data section

SMF Info
--------
    Field: `SMF745DO`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to CACHE device data section
"""
do.__doc__ = """Offset to CACHE device data section

SMF Info
--------
    Field: `SMF745DO`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to CACHE device data section
"""

dl : Final[Field] = Field(
    name='dl',
    origin='SMF745DL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CACHE device data section

SMF Info
--------
    Field: `SMF745DL`
    Record: `SMF74S5`
    Map: Not part of a map

Length of CACHE device data section
"""
dl.__doc__ = """Length of CACHE device data section

SMF Info
--------
    Field: `SMF745DL`
    Record: `SMF74S5`
    Map: Not part of a map

Length of CACHE device data section
"""

dn : Final[Field] = Field(
    name='dn',
    origin='SMF745DN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CACHE device data sections

SMF Info
--------
    Field: `SMF745DN`
    Record: `SMF74S5`
    Map: Not part of a map

Number of CACHE device data sections
"""
dn.__doc__ = """Number of CACHE device data sections

SMF Info
--------
    Field: `SMF745DN`
    Record: `SMF74S5`
    Map: Not part of a map

Number of CACHE device data sections
"""

xo : Final[Field] = Field(
    name='xo',
    origin='SMF745XO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CACHE device data section extension

SMF Info
--------
    Field: `SMF745XO`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to CACHE device data section extension
"""
xo.__doc__ = """Offset to CACHE device data section extension

SMF Info
--------
    Field: `SMF745XO`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to CACHE device data section extension
"""

xl : Final[Field] = Field(
    name='xl',
    origin='SMF745XL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CACHE device data section extension

SMF Info
--------
    Field: `SMF745XL`
    Record: `SMF74S5`
    Map: Not part of a map

Length of CACHE device data section extension
"""
xl.__doc__ = """Length of CACHE device data section extension

SMF Info
--------
    Field: `SMF745XL`
    Record: `SMF74S5`
    Map: Not part of a map

Length of CACHE device data section extension
"""

xn : Final[Field] = Field(
    name='xn',
    origin='SMF745XN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CACHE device data section extensions

SMF Info
--------
    Field: `SMF745XN`
    Record: `SMF74S5`
    Map: Not part of a map

Number of CACHE device data section extensions
"""
xn.__doc__ = """Number of CACHE device data section extensions

SMF Info
--------
    Field: `SMF745XN`
    Record: `SMF74S5`
    Map: Not part of a map

Number of CACHE device data section extensions
"""

so : Final[Field] = Field(
    name='so',
    origin='SMF745SO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CACHE status data section

SMF Info
--------
    Field: `SMF745SO`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to CACHE status data section
"""
so.__doc__ = """Offset to CACHE status data section

SMF Info
--------
    Field: `SMF745SO`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to CACHE status data section
"""

sl : Final[Field] = Field(
    name='sl',
    origin='SMF745SL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CACHE status data section

SMF Info
--------
    Field: `SMF745SL`
    Record: `SMF74S5`
    Map: Not part of a map

Length of CACHE status data section
"""
sl.__doc__ = """Length of CACHE status data section

SMF Info
--------
    Field: `SMF745SL`
    Record: `SMF74S5`
    Map: Not part of a map

Length of CACHE status data section
"""

sn : Final[Field] = Field(
    name='sn',
    origin='SMF745SN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CACHE status data sections

SMF Info
--------
    Field: `SMF745SN`
    Record: `SMF74S5`
    Map: Not part of a map

Number of CACHE status data sections
"""
sn.__doc__ = """Number of CACHE status data sections

SMF Info
--------
    Field: `SMF745SN`
    Record: `SMF74S5`
    Map: Not part of a map

Number of CACHE status data sections
"""

_1o : Final[Field] = Field(
    name='_1o',
    origin='SMF7451O',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to RAID rank data section

SMF Info
--------
    Field: `SMF7451O`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to RAID rank data section
"""
_1o.__doc__ = """Offset to RAID rank data section

SMF Info
--------
    Field: `SMF7451O`
    Record: `SMF74S5`
    Map: Not part of a map

Offset to RAID rank data section
"""

_1l : Final[Field] = Field(
    name='_1l',
    origin='SMF7451L',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of RAID rank data section

SMF Info
--------
    Field: `SMF7451L`
    Record: `SMF74S5`
    Map: Not part of a map

Length of RAID rank data section
"""
_1l.__doc__ = """Length of RAID rank data section

SMF Info
--------
    Field: `SMF7451L`
    Record: `SMF74S5`
    Map: Not part of a map

Length of RAID rank data section
"""

_1n : Final[Field] = Field(
    name='_1n',
    origin='SMF7451N',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of RAID rank data sections

SMF Info
--------
    Field: `SMF7451N`
    Record: `SMF74S5`
    Map: Not part of a map

Number of RAID rank data sections
"""
_1n.__doc__ = """Number of RAID rank data sections

SMF Info
--------
    Field: `SMF7451N`
    Record: `SMF74S5`
    Map: Not part of a map

Number of RAID rank data sections
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S5`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S5`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S5`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S5`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S5`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S5`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S5`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S5`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S5`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S5`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S5`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S5`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S5`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S5`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

r745clvl : Final[Field] = Field(
    name='r745clvl',
    origin='R745CLVL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745CNTL,
)
"""Gatherer level

SMF Info
--------
    Field: `R745CLVL`
    Record: `SMF74S5`
    Map: `R745CNTL`

Gatherer level
"""
r745clvl.__doc__ = """Gatherer level

SMF Info
--------
    Field: `R745CLVL`
    Record: `SMF74S5`
    Map: `R745CNTL`

Gatherer level
"""

r745cmdl : Final[Field] = Field(
    name='r745cmdl',
    origin='R745CMDL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745CNTL,
)
"""Caching subsystem model

SMF Info
--------
    Field: `R745CMDL`
    Record: `SMF74S5`
    Map: `R745CNTL`

Caching subsystem model
"""
r745cmdl.__doc__ = """Caching subsystem model

SMF Info
--------
    Field: `R745CMDL`
    Record: `SMF74S5`
    Map: `R745CNTL`

Caching subsystem model
"""

r745ccnt : Final[Field] = Field(
    name='r745ccnt',
    origin='R745CCNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745CNTL,
)
"""Record sequence number

SMF Info
--------
    Field: `R745CCNT`
    Record: `SMF74S5`
    Map: `R745CNTL`

Record sequence number
"""
r745ccnt.__doc__ = """Record sequence number

SMF Info
--------
    Field: `R745CCNT`
    Record: `SMF74S5`
    Map: `R745CNTL`

Record sequence number
"""

r745cuid : Final[Field] = Field(
    name='r745cuid',
    origin='R745CUID',
    type=FieldType.STRING,
    record=record,
    record_map=R745CNTL,
)
"""Real CU type code. If R745CMDL=1, configured CU type code

SMF Info
--------
    Field: `R745CUID`
    Record: `SMF74S5`
    Map: `R745CNTL`

Real CU type code. If R745CMDL=1, configured CU type code
"""
r745cuid.__doc__ = """Real CU type code. If R745CMDL=1, configured CU type code

SMF Info
--------
    Field: `R745CUID`
    Record: `SMF74S5`
    Map: `R745CNTL`

Real CU type code. If R745CMDL=1, configured CU type code
"""

r745csc : Final[Field] = Field(
    name='r745csc',
    origin='R745CSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745CNTL,
)
"""Status code 00 = successful processed, 04 = IOS return code R745CIOC ^= 0, 08 = IDCSS01 return code R745CRTN ^= 0, 98 = SYSTEM or USER ABEND R745CEA ^= 0

SMF Info
--------
    Field: `R745CSC`
    Record: `SMF74S5`
    Map: `R745CNTL`

Status code 00 = successful processed, 04 = IOS return code R745CIOC ^= 0, 08 = IDCSS01 return code R745CRTN ^= 0, 98 = SYSTEM or USER ABEND R745CEA ^= 0
"""
r745csc.__doc__ = """Status code 00 = successful processed, 04 = IOS return code R745CIOC ^= 0, 08 = IDCSS01 return code R745CRTN ^= 0, 98 = SYSTEM or USER ABEND R745CEA ^= 0

SMF Info
--------
    Field: `R745CSC`
    Record: `SMF74S5`
    Map: `R745CNTL`

Status code 00 = successful processed, 04 = IOS return code R745CIOC ^= 0, 08 = IDCSS01 return code R745CRTN ^= 0, 98 = SYSTEM or USER ABEND R745CEA ^= 0
"""

r745cae : Final[Field] = Field(
    name='r745cae',
    origin='R745CAE',
    type=FieldType.STRING,
    record=record,
    record_map=R745CNTL,
)
"""ABEND CODE (SDWACMPC). System and User completion code (12 bits each)

SMF Info
--------
    Field: `R745CAE`
    Record: `SMF74S5`
    Map: `R745CNTL`

ABEND CODE (SDWACMPC). System and User completion code (12 bits each)
"""
r745cae.__doc__ = """ABEND CODE (SDWACMPC). System and User completion code (12 bits each)

SMF Info
--------
    Field: `R745CAE`
    Record: `SMF74S5`
    Map: `R745CNTL`

ABEND CODE (SDWACMPC). System and User completion code (12 bits each)
"""

r745crtn : Final[Field] = Field(
    name='r745crtn',
    origin='R745CRTN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745CNTL,
)
"""IDCSS01 return code. If not zero, no device data sections. SMF745DN = 0

SMF Info
--------
    Field: `R745CRTN`
    Record: `SMF74S5`
    Map: `R745CNTL`

IDCSS01 return code. If not zero, no device data sections. SMF745DN = 0
"""
r745crtn.__doc__ = """IDCSS01 return code. If not zero, no device data sections. SMF745DN = 0

SMF Info
--------
    Field: `R745CRTN`
    Record: `SMF74S5`
    Map: `R745CNTL`

IDCSS01 return code. If not zero, no device data sections. SMF745DN = 0
"""

r745cioc : Final[Field] = Field(
    name='r745cioc',
    origin='R745CIOC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745CNTL,
)
"""IOS return code. If not zero, no device data sections. SMF745DN = 0

SMF Info
--------
    Field: `R745CIOC`
    Record: `SMF74S5`
    Map: `R745CNTL`

IOS return code. If not zero, no device data sections. SMF745DN = 0
"""
r745cioc.__doc__ = """IOS return code. If not zero, no device data sections. SMF745DN = 0

SMF Info
--------
    Field: `R745CIOC`
    Record: `SMF74S5`
    Map: `R745CNTL`

IOS return code. If not zero, no device data sections. SMF745DN = 0
"""

r745cint : Final[Field] = Field(
    name='r745cint',
    origin='R745CINT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745CNTL,
)
"""Number of seconds since subsystem statistics last collected

SMF Info
--------
    Field: `R745CINT`
    Record: `SMF74S5`
    Map: `R745CNTL`

Number of seconds since subsystem statistics last collected
"""
r745cint.__doc__ = """Number of seconds since subsystem statistics last collected

SMF Info
--------
    Field: `R745CINT`
    Record: `SMF74S5`
    Map: `R745CNTL`

Number of seconds since subsystem statistics last collected
"""

r745cfdv : Final[Field] = Field(
    name='r745cfdv',
    origin='R745CFDV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745CNTL,
)
"""Failing device

SMF Info
--------
    Field: `R745CFDV`
    Record: `SMF74S5`
    Map: `R745CNTL`

Failing device
"""
r745cfdv.__doc__ = """Failing device

SMF Info
--------
    Field: `R745CFDV`
    Record: `SMF74S5`
    Map: `R745CNTL`

Failing device
"""

nedtypen : Final[Field] = Field(
    name='nedtypen',
    origin='NEDTYPEN',
    type=FieldType.STRING,
    record=record,
    record_map=R745CNTL,
)
"""Type number

SMF Info
--------
    Field: `NEDTYPEN`
    Record: `SMF74S5`
    Map: `R745CNTL`

Type number
"""
nedtypen.__doc__ = """Type number

SMF Info
--------
    Field: `NEDTYPEN`
    Record: `SMF74S5`
    Map: `R745CNTL`

Type number
"""

nedmodn : Final[Field] = Field(
    name='nedmodn',
    origin='NEDMODN',
    type=FieldType.STRING,
    record=record,
    record_map=R745CNTL,
)
"""Model number

SMF Info
--------
    Field: `NEDMODN`
    Record: `SMF74S5`
    Map: `R745CNTL`

Model number
"""
nedmodn.__doc__ = """Model number

SMF Info
--------
    Field: `NEDMODN`
    Record: `SMF74S5`
    Map: `R745CNTL`

Model number
"""

nedmanuf : Final[Field] = Field(
    name='nedmanuf',
    origin='NEDMANUF',
    type=FieldType.STRING,
    record=record,
    record_map=R745CNTL,
)
"""Manufacturer

SMF Info
--------
    Field: `NEDMANUF`
    Record: `SMF74S5`
    Map: `R745CNTL`

Manufacturer
"""
nedmanuf.__doc__ = """Manufacturer

SMF Info
--------
    Field: `NEDMANUF`
    Record: `SMF74S5`
    Map: `R745CNTL`

Manufacturer
"""

nedpmanu : Final[Field] = Field(
    name='nedpmanu',
    origin='NEDPMANU',
    type=FieldType.STRING,
    record=record,
    record_map=R745CNTL,
)
"""Plant of manufacture

SMF Info
--------
    Field: `NEDPMANU`
    Record: `SMF74S5`
    Map: `R745CNTL`

Plant of manufacture
"""
nedpmanu.__doc__ = """Plant of manufacture

SMF Info
--------
    Field: `NEDPMANU`
    Record: `SMF74S5`
    Map: `R745CNTL`

Plant of manufacture
"""

nedseqn : Final[Field] = Field(
    name='nedseqn',
    origin='NEDSEQN',
    type=FieldType.STRING,
    record=record,
    record_map=R745CNTL,
)
"""Sequence number

SMF Info
--------
    Field: `NEDSEQN`
    Record: `SMF74S5`
    Map: `R745CNTL`

Sequence number
"""
nedseqn.__doc__ = """Sequence number

SMF Info
--------
    Field: `NEDSEQN`
    Record: `SMF74S5`
    Map: `R745CNTL`

Sequence number
"""

nedtag : Final[Field] = Field(
    name='nedtag',
    origin='NEDTAG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745CNTL,
)
"""Tag

SMF Info
--------
    Field: `NEDTAG`
    Record: `SMF74S5`
    Map: `R745CNTL`

Tag
"""
nedtag.__doc__ = """Tag

SMF Info
--------
    Field: `NEDTAG`
    Record: `SMF74S5`
    Map: `R745CNTL`

Tag
"""

r745dvol : Final[Field] = Field(
    name='r745dvol',
    origin='R745DVOL',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Volume serial of device

SMF Info
--------
    Field: `R745DVOL`
    Record: `SMF74S5`
    Map: `R745DEV`

Volume serial of device
"""
r745dvol.__doc__ = """Volume serial of device

SMF Info
--------
    Field: `R745DVOL`
    Record: `SMF74S5`
    Map: `R745DEV`

Volume serial of device
"""

r745dfl4 : Final[Field] = Field(
    name='r745dfl4',
    origin='R745DFL4',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Flags

SMF Info
--------
    Field: `R745DFL4`
    Record: `SMF74S5`
    Map: `R745DEV`

Flags
"""
r745dfl4.__doc__ = """Flags

SMF Info
--------
    Field: `R745DFL4`
    Record: `SMF74S5`
    Map: `R745DEV`

Flags
"""

r745dev4 : Final[Field] = Field(
    name='r745dev4',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r745dfl4,
    record=record,
    record_map=R745DEV,
)
"""B'1' 4 digit device addr.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dfl4`(`R745DFL4`)
    Record: `SMF74S5`
    Map: `R745DEV`

B'1' 4 digit device addr.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r745dev4.__doc__ = """B'1' 4 digit device addr.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dfl4`(`R745DFL4`)
    Record: `SMF74S5`
    Map: `R745DEV`

B'1' 4 digit device addr.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r745dscs : Final[Field] = Field(
    name='r745dscs',
    origin='R745DSCS',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Subchannel set ID 00 - Subchannel set ID 0 01 - Subchannel set ID 1 10 - Subchannel set ID 2 11 - Subchannel set ID 3

SMF Info
--------
    Field: `R745DSCS`
    Record: `SMF74S5`
    Map: `R745DEV`

Subchannel set ID 00 - Subchannel set ID 0 01 - Subchannel set ID 1 10 - Subchannel set ID 2 11 - Subchannel set ID 3
"""
r745dscs.__doc__ = """Subchannel set ID 00 - Subchannel set ID 0 01 - Subchannel set ID 1 10 - Subchannel set ID 2 11 - Subchannel set ID 3

SMF Info
--------
    Field: `R745DSCS`
    Record: `SMF74S5`
    Map: `R745DEV`

Subchannel set ID 00 - Subchannel set ID 0 01 - Subchannel set ID 1 10 - Subchannel set ID 2 11 - Subchannel set ID 3
"""

r745dccu : Final[Field] = Field(
    name='r745dccu',
    origin='R745DCCU',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Configured control unit type code if R745CMDL = 1

SMF Info
--------
    Field: `R745DCCU`
    Record: `SMF74S5`
    Map: `R745DEV`

Configured control unit type code if R745CMDL = 1
"""
r745dccu.__doc__ = """Configured control unit type code if R745CMDL = 1

SMF Info
--------
    Field: `R745DCCU`
    Record: `SMF74S5`
    Map: `R745DEV`

Configured control unit type code if R745CMDL = 1
"""

r745dunt : Final[Field] = Field(
    name='r745dunt',
    origin='R745DUNT',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Unit addr. for sense CMD

SMF Info
--------
    Field: `R745DUNT`
    Record: `SMF74S5`
    Map: `R745DEV`

Unit addr. for sense CMD
"""
r745dunt.__doc__ = """Unit addr. for sense CMD

SMF Info
--------
    Field: `R745DUNT`
    Record: `SMF74S5`
    Map: `R745DEV`

Unit addr. for sense CMD
"""

r745devn : Final[Field] = Field(
    name='r745devn',
    origin='R745DEVN',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Device number (binary)

SMF Info
--------
    Field: `R745DEVN`
    Record: `SMF74S5`
    Map: `R745DEV`

Device number (binary)
"""
r745devn.__doc__ = """Device number (binary)

SMF Info
--------
    Field: `R745DEVN`
    Record: `SMF74S5`
    Map: `R745DEV`

Device number (binary)
"""

r745dflg : Final[Field] = Field(
    name='r745dflg',
    origin='R745DFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Flags

SMF Info
--------
    Field: `R745DFLG`
    Record: `SMF74S5`
    Map: `R745DEV`

Flags
"""
r745dflg.__doc__ = """Flags

SMF Info
--------
    Field: `R745DFLG`
    Record: `SMF74S5`
    Map: `R745DEV`

Flags
"""

r745dnav : Final[Field] = Field(
    name='r745dnav',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r745dflg,
    record=record,
    record_map=R745DEV,
)
"""Cache storage not available set to 0 for DS8000(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dflg`(`R745DFLG`)
    Record: `SMF74S5`
    Map: `R745DEV`

Cache storage not available set to 0 for DS8000

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r745dnav.__doc__ = """Cache storage not available set to 0 for DS8000(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dflg`(`R745DFLG`)
    Record: `SMF74S5`
    Map: `R745DEV`

Cache storage not available set to 0 for DS8000

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r745dpdf : Final[Field] = Field(
    name='r745dpdf',
    origin='R745DPDF',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Format of Performance Data returned B'000' = 3990 Format B'001' = DS8000 Disk Controller Format

SMF Info
--------
    Field: `R745DPDF`
    Record: `SMF74S5`
    Map: `R745DEV`

Format of Performance Data returned B'000' = 3990 Format B'001' = DS8000 Disk Controller Format
"""
r745dpdf.__doc__ = """Format of Performance Data returned B'000' = 3990 Format B'001' = DS8000 Disk Controller Format

SMF Info
--------
    Field: `R745DPDF`
    Record: `SMF74S5`
    Map: `R745DEV`

Format of Performance Data returned B'000' = 3990 Format B'001' = DS8000 Disk Controller Format
"""

r745dfrm : Final[Field] = Field(
    name='r745dfrm',
    origin='R745DFRM',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Format of data returned B'0000' = 3990 Models 1,2 and 3 or Basic Operation Mode B'0001' = 3990 Model 6 Enhanced Operation Mode 1 or host supports DS8000 Disk Controller

SMF Info
--------
    Field: `R745DFRM`
    Record: `SMF74S5`
    Map: `R745DEV`

Format of data returned B'0000' = 3990 Models 1,2 and 3 or Basic Operation Mode B'0001' = 3990 Model 6 Enhanced Operation Mode 1 or host supports DS8000 Disk Controller
"""
r745dfrm.__doc__ = """Format of data returned B'0000' = 3990 Models 1,2 and 3 or Basic Operation Mode B'0001' = 3990 Model 6 Enhanced Operation Mode 1 or host supports DS8000 Disk Controller

SMF Info
--------
    Field: `R745DFRM`
    Record: `SMF74S5`
    Map: `R745DEV`

Format of data returned B'0000' = 3990 Models 1,2 and 3 or Basic Operation Mode B'0001' = 3990 Model 6 Enhanced Operation Mode 1 or host supports DS8000 Disk Controller
"""

r745dvid : Final[Field] = Field(
    name='r745dvid',
    origin='R745DVID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745DEV,
)
"""Device address

SMF Info
--------
    Field: `R745DVID`
    Record: `SMF74S5`
    Map: `R745DEV`

Device address
"""
r745dvid.__doc__ = """Device address

SMF Info
--------
    Field: `R745DVID`
    Record: `SMF74S5`
    Map: `R745DEV`

Device address
"""

r745dvs1 : Final[Field] = Field(
    name='r745dvs1',
    origin='R745DVS1',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Addressed device status 1

SMF Info
--------
    Field: `R745DVS1`
    Record: `SMF74S5`
    Map: `R745DEV`

Addressed device status 1
"""
r745dvs1.__doc__ = """Addressed device status 1

SMF Info
--------
    Field: `R745DVS1`
    Record: `SMF74S5`
    Map: `R745DEV`

Addressed device status 1
"""

r745dsdv : Final[Field] = Field(
    name='r745dsdv',
    origin='R745DSDV',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Device caching status B'00' = Caching activated

SMF Info
--------
    Field: `R745DSDV`
    Record: `SMF74S5`
    Map: `R745DEV`

Device caching status B'00' = Caching activated
"""
r745dsdv.__doc__ = """Device caching status B'00' = Caching activated

SMF Info
--------
    Field: `R745DSDV`
    Record: `SMF74S5`
    Map: `R745DEV`

Device caching status B'00' = Caching activated
"""

r745dsfw : Final[Field] = Field(
    name='r745dsfw',
    origin='R745DSFW',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""DASD fast write device status B'00' = DFW allowed

SMF Info
--------
    Field: `R745DSFW`
    Record: `SMF74S5`
    Map: `R745DEV`

DASD fast write device status B'00' = DFW allowed
"""
r745dsfw.__doc__ = """DASD fast write device status B'00' = DFW allowed

SMF Info
--------
    Field: `R745DSFW`
    Record: `SMF74S5`
    Map: `R745DEV`

DASD fast write device status B'00' = DFW allowed
"""

r745dspd : Final[Field] = Field(
    name='r745dspd',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r745dsfw,
    record=record,
    record_map=R745DEV,
)
"""PPRC copy pair suspended(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dsfw`(`R745DSFW`)
    Record: `SMF74S5`
    Map: `R745DEV`

PPRC copy pair suspended

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r745dspd.__doc__ = """PPRC copy pair suspended(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dsfw`(`R745DSFW`)
    Record: `SMF74S5`
    Map: `R745DEV`

PPRC copy pair suspended

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r745dssd : Final[Field] = Field(
    name='r745dssd',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r745dsfw,
    record=record,
    record_map=R745DEV,
)
"""PPRC copy pair is duplex pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dsfw`(`R745DSFW`)
    Record: `SMF74S5`
    Map: `R745DEV`

PPRC copy pair is duplex pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r745dssd.__doc__ = """PPRC copy pair is duplex pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dsfw`(`R745DSFW`)
    Record: `SMF74S5`
    Map: `R745DEV`

PPRC copy pair is duplex pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r745dsdp : Final[Field] = Field(
    name='r745dsdp',
    origin='R745DSDP',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""PPRC pair status B'00' = PPRC pair available (full duplex) B'01' = PPRC pair pending B'10' = Not used B'11' = Suspended

SMF Info
--------
    Field: `R745DSDP`
    Record: `SMF74S5`
    Map: `R745DEV`

PPRC pair status B'00' = PPRC pair available (full duplex) B'01' = PPRC pair pending B'10' = Not used B'11' = Suspended
"""
r745dsdp.__doc__ = """PPRC pair status B'00' = PPRC pair available (full duplex) B'01' = PPRC pair pending B'10' = Not used B'11' = Suspended

SMF Info
--------
    Field: `R745DSDP`
    Record: `SMF74S5`
    Map: `R745DEV`

PPRC pair status B'00' = PPRC pair available (full duplex) B'01' = PPRC pair pending B'10' = Not used B'11' = Suspended
"""

r745dvs2 : Final[Field] = Field(
    name='r745dvs2',
    origin='R745DVS2',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Addressed device status 2 If R745SFT = 0 Pinned data (2 bits) 00.. .... No pinned data 01.. .... Pinned data exists for device 10.. .... Reserved 11.. .... Not used ..xx xx.. Not used .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled If R745SFT = 1 or 2 Global Mirror State (3 bits) 000. .... No Global Mirror configured 001. .... Global Mirror running optimal 010. .... Global Mirror running suboptimal 011. .... Global Mirror running Consistency Groups failing 100. .... Global Mirror paused 101. .... Global Mirror fatal 110. .... More than 1 Global Mirror session running in the box 111. .... Reserved ...1 .... Session Member pending .... 1... Volume not allowed online .... .1.. Reserved .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled

SMF Info
--------
    Field: `R745DVS2`
    Record: `SMF74S5`
    Map: `R745DEV`

Addressed device status 2 If R745SFT = 0 Pinned data (2 bits) 00.. .... No pinned data 01.. .... Pinned data exists for device 10.. .... Reserved 11.. .... Not used ..xx xx.. Not used .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled If R745SFT = 1 or 2 Global Mirror State (3 bits) 000. .... No Global Mirror configured 001. .... Global Mirror running optimal 010. .... Global Mirror running suboptimal 011. .... Global Mirror running Consistency Groups failing 100. .... Global Mirror paused 101. .... Global Mirror fatal 110. .... More than 1 Global Mirror session running in the box 111. .... Reserved ...1 .... Session Member pending .... 1... Volume not allowed online .... .1.. Reserved .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled
"""
r745dvs2.__doc__ = """Addressed device status 2 If R745SFT = 0 Pinned data (2 bits) 00.. .... No pinned data 01.. .... Pinned data exists for device 10.. .... Reserved 11.. .... Not used ..xx xx.. Not used .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled If R745SFT = 1 or 2 Global Mirror State (3 bits) 000. .... No Global Mirror configured 001. .... Global Mirror running optimal 010. .... Global Mirror running suboptimal 011. .... Global Mirror running Consistency Groups failing 100. .... Global Mirror paused 101. .... Global Mirror fatal 110. .... More than 1 Global Mirror session running in the box 111. .... Reserved ...1 .... Session Member pending .... 1... Volume not allowed online .... .1.. Reserved .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled

SMF Info
--------
    Field: `R745DVS2`
    Record: `SMF74S5`
    Map: `R745DEV`

Addressed device status 2 If R745SFT = 0 Pinned data (2 bits) 00.. .... No pinned data 01.. .... Pinned data exists for device 10.. .... Reserved 11.. .... Not used ..xx xx.. Not used .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled If R745SFT = 1 or 2 Global Mirror State (3 bits) 000. .... No Global Mirror configured 001. .... Global Mirror running optimal 010. .... Global Mirror running suboptimal 011. .... Global Mirror running Consistency Groups failing 100. .... Global Mirror paused 101. .... Global Mirror fatal 110. .... More than 1 Global Mirror session running in the box 111. .... Reserved ...1 .... Session Member pending .... 1... Volume not allowed online .... .1.. Reserved .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled
"""

r745drcr : Final[Field] = Field(
    name='r745drcr',
    origin='R745DRCR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Search read caching requ. Floating point short

SMF Info
--------
    Field: `R745DRCR`
    Record: `SMF74S5`
    Map: `R745DEV`

Search read caching requ. Floating point short
"""
r745drcr.__doc__ = """Search read caching requ. Floating point short

SMF Info
--------
    Field: `R745DRCR`
    Record: `SMF74S5`
    Map: `R745DEV`

Search read caching requ. Floating point short
"""

r745dcrh : Final[Field] = Field(
    name='r745dcrh',
    origin='R745DCRH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Search read caching hits Floating point short

SMF Info
--------
    Field: `R745DCRH`
    Record: `SMF74S5`
    Map: `R745DEV`

Search read caching hits Floating point short
"""
r745dcrh.__doc__ = """Search read caching hits Floating point short

SMF Info
--------
    Field: `R745DCRH`
    Record: `SMF74S5`
    Map: `R745DEV`

Search read caching hits Floating point short
"""

r745dwrc : Final[Field] = Field(
    name='r745dwrc',
    origin='R745DWRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Write caching requests Floating point short

SMF Info
--------
    Field: `R745DWRC`
    Record: `SMF74S5`
    Map: `R745DEV`

Write caching requests Floating point short
"""
r745dwrc.__doc__ = """Write caching requests Floating point short

SMF Info
--------
    Field: `R745DWRC`
    Record: `SMF74S5`
    Map: `R745DEV`

Write caching requests Floating point short
"""

r745dwch : Final[Field] = Field(
    name='r745dwch',
    origin='R745DWCH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Write caching requ. hits Floating point short

SMF Info
--------
    Field: `R745DWCH`
    Record: `SMF74S5`
    Map: `R745DEV`

Write caching requ. hits Floating point short
"""
r745dwch.__doc__ = """Write caching requ. hits Floating point short

SMF Info
--------
    Field: `R745DWCH`
    Record: `SMF74S5`
    Map: `R745DEV`

Write caching requ. hits Floating point short
"""

r745drsr : Final[Field] = Field(
    name='r745drsr',
    origin='R745DRSR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Read sequential requests Floating point short

SMF Info
--------
    Field: `R745DRSR`
    Record: `SMF74S5`
    Map: `R745DEV`

Read sequential requests Floating point short
"""
r745drsr.__doc__ = """Read sequential requests Floating point short

SMF Info
--------
    Field: `R745DRSR`
    Record: `SMF74S5`
    Map: `R745DEV`

Read sequential requests Floating point short
"""

r745drsh : Final[Field] = Field(
    name='r745drsh',
    origin='R745DRSH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Read sequential requ.hits Floating point short

SMF Info
--------
    Field: `R745DRSH`
    Record: `SMF74S5`
    Map: `R745DEV`

Read sequential requ.hits Floating point short
"""
r745drsh.__doc__ = """Read sequential requ.hits Floating point short

SMF Info
--------
    Field: `R745DRSH`
    Record: `SMF74S5`
    Map: `R745DEV`

Read sequential requ.hits Floating point short
"""

r745dwsr : Final[Field] = Field(
    name='r745dwsr',
    origin='R745DWSR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Write sequential requests Floating point short

SMF Info
--------
    Field: `R745DWSR`
    Record: `SMF74S5`
    Map: `R745DEV`

Write sequential requests Floating point short
"""
r745dwsr.__doc__ = """Write sequential requests Floating point short

SMF Info
--------
    Field: `R745DWSR`
    Record: `SMF74S5`
    Map: `R745DEV`

Write sequential requests Floating point short
"""

r745dwsh : Final[Field] = Field(
    name='r745dwsh',
    origin='R745DWSH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Write sequ. request hits Floating point short

SMF Info
--------
    Field: `R745DWSH`
    Record: `SMF74S5`
    Map: `R745DEV`

Write sequ. request hits Floating point short
"""
r745dwsh.__doc__ = """Write sequ. request hits Floating point short

SMF Info
--------
    Field: `R745DWSH`
    Record: `SMF74S5`
    Map: `R745DEV`

Write sequ. request hits Floating point short
"""

r745drnr : Final[Field] = Field(
    name='r745drnr',
    origin='R745DRNR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Search read non-retentive requests Floating point short

SMF Info
--------
    Field: `R745DRNR`
    Record: `SMF74S5`
    Map: `R745DEV`

Search read non-retentive requests Floating point short
"""
r745drnr.__doc__ = """Search read non-retentive requests Floating point short

SMF Info
--------
    Field: `R745DRNR`
    Record: `SMF74S5`
    Map: `R745DEV`

Search read non-retentive requests Floating point short
"""

r745dnrh : Final[Field] = Field(
    name='r745dnrh',
    origin='R745DNRH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Search read non-retentive request hits Floating point short

SMF Info
--------
    Field: `R745DNRH`
    Record: `SMF74S5`
    Map: `R745DEV`

Search read non-retentive request hits Floating point short
"""
r745dnrh.__doc__ = """Search read non-retentive request hits Floating point short

SMF Info
--------
    Field: `R745DNRH`
    Record: `SMF74S5`
    Map: `R745DEV`

Search read non-retentive request hits Floating point short
"""

r745dwnr : Final[Field] = Field(
    name='r745dwnr',
    origin='R745DWNR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Write non-retentive requests Floating point short

SMF Info
--------
    Field: `R745DWNR`
    Record: `SMF74S5`
    Map: `R745DEV`

Write non-retentive requests Floating point short
"""
r745dwnr.__doc__ = """Write non-retentive requests Floating point short

SMF Info
--------
    Field: `R745DWNR`
    Record: `SMF74S5`
    Map: `R745DEV`

Write non-retentive requests Floating point short
"""

r745dwnh : Final[Field] = Field(
    name='r745dwnh',
    origin='R745DWNH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Write non-retentive hits Floating point short

SMF Info
--------
    Field: `R745DWNH`
    Record: `SMF74S5`
    Map: `R745DEV`

Write non-retentive hits Floating point short
"""
r745dwnh.__doc__ = """Write non-retentive hits Floating point short

SMF Info
--------
    Field: `R745DWNH`
    Record: `SMF74S5`
    Map: `R745DEV`

Write non-retentive hits Floating point short
"""

r745dicl : Final[Field] = Field(
    name='r745dicl',
    origin='R745DICL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Inhibit cache load req. Floating point short

SMF Info
--------
    Field: `R745DICL`
    Record: `SMF74S5`
    Map: `R745DEV`

Inhibit cache load req. Floating point short
"""
r745dicl.__doc__ = """Inhibit cache load req. Floating point short

SMF Info
--------
    Field: `R745DICL`
    Record: `SMF74S5`
    Map: `R745DEV`

Inhibit cache load req. Floating point short
"""

r745dbcr : Final[Field] = Field(
    name='r745dbcr',
    origin='R745DBCR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Bypass cache requests Floating point short

SMF Info
--------
    Field: `R745DBCR`
    Record: `SMF74S5`
    Map: `R745DEV`

Bypass cache requests Floating point short
"""
r745dbcr.__doc__ = """Bypass cache requests Floating point short

SMF Info
--------
    Field: `R745DBCR`
    Record: `SMF74S5`
    Map: `R745DEV`

Bypass cache requests Floating point short
"""

r745dtc : Final[Field] = Field(
    name='r745dtc',
    origin='R745DTC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Seq DASD to cache XFRs Floating point short

SMF Info
--------
    Field: `R745DTC`
    Record: `SMF74S5`
    Map: `R745DEV`

Seq DASD to cache XFRs Floating point short
"""
r745dtc.__doc__ = """Seq DASD to cache XFRs Floating point short

SMF Info
--------
    Field: `R745DTC`
    Record: `SMF74S5`
    Map: `R745DEV`

Seq DASD to cache XFRs Floating point short
"""

r745dntd : Final[Field] = Field(
    name='r745dntd',
    origin='R745DNTD',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Normal cache requests DASD to CACHE XFRs Floating point short

SMF Info
--------
    Field: `R745DNTD`
    Record: `SMF74S5`
    Map: `R745DEV`

Normal cache requests DASD to CACHE XFRs Floating point short
"""
r745dntd.__doc__ = """Normal cache requests DASD to CACHE XFRs Floating point short

SMF Info
--------
    Field: `R745DNTD`
    Record: `SMF74S5`
    Map: `R745DEV`

Normal cache requests DASD to CACHE XFRs Floating point short
"""

r745dctd : Final[Field] = Field(
    name='r745dctd',
    origin='R745DCTD',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""CACHE to DASD XFRs Floating point short

SMF Info
--------
    Field: `R745DCTD`
    Record: `SMF74S5`
    Map: `R745DEV`

CACHE to DASD XFRs Floating point short
"""
r745dctd.__doc__ = """CACHE to DASD XFRs Floating point short

SMF Info
--------
    Field: `R745DCTD`
    Record: `SMF74S5`
    Map: `R745DEV`

CACHE to DASD XFRs Floating point short
"""

r745dfwb : Final[Field] = Field(
    name='r745dfwb',
    origin='R745DFWB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""DASD Fast Write operations delayed due to non-volatile storage space constraints Floating point short

SMF Info
--------
    Field: `R745DFWB`
    Record: `SMF74S5`
    Map: `R745DEV`

DASD Fast Write operations delayed due to non-volatile storage space constraints Floating point short
"""
r745dfwb.__doc__ = """DASD Fast Write operations delayed due to non-volatile storage space constraints Floating point short

SMF Info
--------
    Field: `R745DFWB`
    Record: `SMF74S5`
    Map: `R745DEV`

DASD Fast Write operations delayed due to non-volatile storage space constraints Floating point short
"""

r745dfwc : Final[Field] = Field(
    name='r745dfwc',
    origin='R745DFWC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Fast write caching req. Floating point short

SMF Info
--------
    Field: `R745DFWC`
    Record: `SMF74S5`
    Map: `R745DEV`

Fast write caching req. Floating point short
"""
r745dfwc.__doc__ = """Fast write caching req. Floating point short

SMF Info
--------
    Field: `R745DFWC`
    Record: `SMF74S5`
    Map: `R745DEV`

Fast write caching req. Floating point short
"""

r745dfws : Final[Field] = Field(
    name='r745dfws',
    origin='R745DFWS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Fast write sequ. req. Floating point short

SMF Info
--------
    Field: `R745DFWS`
    Record: `SMF74S5`
    Map: `R745DEV`

Fast write sequ. req. Floating point short
"""
r745dfws.__doc__ = """Fast write sequ. req. Floating point short

SMF Info
--------
    Field: `R745DFWS`
    Record: `SMF74S5`
    Map: `R745DEV`

Fast write sequ. req. Floating point short
"""

r745dcrm : Final[Field] = Field(
    name='r745dcrm',
    origin='R745DCRM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Record cache read misses Floating point short

SMF Info
--------
    Field: `R745DCRM`
    Record: `SMF74S5`
    Map: `R745DEV`

Record cache read misses Floating point short
"""
r745dcrm.__doc__ = """Record cache read misses Floating point short

SMF Info
--------
    Field: `R745DCRM`
    Record: `SMF74S5`
    Map: `R745DEV`

Record cache read misses Floating point short
"""

r745dsg2 : Final[Field] = Field(
    name='r745dsg2',
    origin='R745DSG2',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Device status group 2 .... 1... Device in a SPID Fenced state .... .1.. Volume is part of a RAID rank that is undergoing RAID rebuild

SMF Info
--------
    Field: `R745DSG2`
    Record: `SMF74S5`
    Map: `R745DEV`

Device status group 2 .... 1... Device in a SPID Fenced state .... .1.. Volume is part of a RAID rank that is undergoing RAID rebuild
"""
r745dsg2.__doc__ = """Device status group 2 .... 1... Device in a SPID Fenced state .... .1.. Volume is part of a RAID rank that is undergoing RAID rebuild

SMF Info
--------
    Field: `R745DSG2`
    Record: `SMF74S5`
    Map: `R745DEV`

Device status group 2 .... 1... Device in a SPID Fenced state .... .1.. Volume is part of a RAID rank that is undergoing RAID rebuild
"""

r745dcol : Final[Field] = Field(
    name='r745dcol',
    origin='R745DCOL',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Volume Space Management B'00' = Standard volume B'01' = Track Space Efficient Volume B'10' = Extent Space Efficient Volume B'11' = Reserved

SMF Info
--------
    Field: `R745DCOL`
    Record: `SMF74S5`
    Map: `R745DEV`

Volume Space Management B'00' = Standard volume B'01' = Track Space Efficient Volume B'10' = Extent Space Efficient Volume B'11' = Reserved
"""
r745dcol.__doc__ = """Volume Space Management B'00' = Standard volume B'01' = Track Space Efficient Volume B'10' = Extent Space Efficient Volume B'11' = Reserved

SMF Info
--------
    Field: `R745DCOL`
    Record: `SMF74S5`
    Map: `R745DEV`

Volume Space Management B'00' = Standard volume B'01' = Track Space Efficient Volume B'10' = Extent Space Efficient Volume B'11' = Reserved
"""

r745defn : Final[Field] = Field(
    name='r745defn',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r745dcol,
    record=record,
    record_map=R745DEV,
)
"""Data exits in failed NVS(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dcol`(`R745DCOL`)
    Record: `SMF74S5`
    Map: `R745DEV`

Data exits in failed NVS

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r745defn.__doc__ = """Data exits in failed NVS(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dcol`(`R745DCOL`)
    Record: `SMF74S5`
    Map: `R745DEV`

Data exits in failed NVS

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r745dbdp : Final[Field] = Field(
    name='r745dbdp',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r745dcol,
    record=record,
    record_map=R745DEV,
)
"""Device in a Soft Fenced state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dcol`(`R745DCOL`)
    Record: `SMF74S5`
    Map: `R745DEV`

Device in a Soft Fenced state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r745dbdp.__doc__ = """Device in a Soft Fenced state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745dcol`(`R745DCOL`)
    Record: `SMF74S5`
    Map: `R745DEV`

Device in a Soft Fenced state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r745dpdt : Final[Field] = Field(
    name='r745dpdt',
    origin='R745DPDT',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""If R745SFT = 1 or 2 Pinned data B'00' = No pinned data B'01' = Pinned data exists for the device B'10' = Reserved B'11' = Not used

SMF Info
--------
    Field: `R745DPDT`
    Record: `SMF74S5`
    Map: `R745DEV`

If R745SFT = 1 or 2 Pinned data B'00' = No pinned data B'01' = Pinned data exists for the device B'10' = Reserved B'11' = Not used
"""
r745dpdt.__doc__ = """If R745SFT = 1 or 2 Pinned data B'00' = No pinned data B'01' = Pinned data exists for the device B'10' = Reserved B'11' = Not used

SMF Info
--------
    Field: `R745DPDT`
    Record: `SMF74S5`
    Map: `R745DEV`

If R745SFT = 1 or 2 Pinned data B'00' = No pinned data B'01' = Pinned data exists for the device B'10' = Reserved B'11' = Not used
"""

r745dsid : Final[Field] = Field(
    name='r745dsid',
    origin='R745DSID',
    type=FieldType.STRING,
    record=record,
    record_map=R745DEV,
)
"""Subsystem ID

SMF Info
--------
    Field: `R745DSID`
    Record: `SMF74S5`
    Map: `R745DEV`

Subsystem ID
"""
r745dsid.__doc__ = """Subsystem ID

SMF Info
--------
    Field: `R745DSID`
    Record: `SMF74S5`
    Map: `R745DEV`

Subsystem ID
"""

r745dcwp : Final[Field] = Field(
    name='r745dcwp',
    origin='R745DCWP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""RCD cache write promotions Floating point short

SMF Info
--------
    Field: `R745DCWP`
    Record: `SMF74S5`
    Map: `R745DEV`

RCD cache write promotions Floating point short
"""
r745dcwp.__doc__ = """RCD cache write promotions Floating point short

SMF Info
--------
    Field: `R745DCWP`
    Record: `SMF74S5`
    Map: `R745DEV`

RCD cache write promotions Floating point short
"""

r745dkdw : Final[Field] = Field(
    name='r745dkdw',
    origin='R745DKDW',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""CKD writes, collected for 3990-03/06, 2105 Floating point short

SMF Info
--------
    Field: `R745DKDW`
    Record: `SMF74S5`
    Map: `R745DEV`

CKD writes, collected for 3990-03/06, 2105 Floating point short
"""
r745dkdw.__doc__ = """CKD writes, collected for 3990-03/06, 2105 Floating point short

SMF Info
--------
    Field: `R745DKDW`
    Record: `SMF74S5`
    Map: `R745DEV`

CKD writes, collected for 3990-03/06, 2105 Floating point short
"""

r745dkdh : Final[Field] = Field(
    name='r745dkdh',
    origin='R745DKDH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""CKD write hits, collected for 3990-03/06, 2105 Floating point short

SMF Info
--------
    Field: `R745DKDH`
    Record: `SMF74S5`
    Map: `R745DEV`

CKD write hits, collected for 3990-03/06, 2105 Floating point short
"""
r745dkdh.__doc__ = """CKD write hits, collected for 3990-03/06, 2105 Floating point short

SMF Info
--------
    Field: `R745DKDH`
    Record: `SMF74S5`
    Map: `R745DEV`

CKD write hits, collected for 3990-03/06, 2105 Floating point short
"""

r745dfwr : Final[Field] = Field(
    name='r745dfwr',
    origin='R745DFWR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R745DEV,
)
"""Operations delayed due to cache space constraints Floating point short

SMF Info
--------
    Field: `R745DFWR`
    Record: `SMF74S5`
    Map: `R745DEV`

Operations delayed due to cache space constraints Floating point short
"""
r745dfwr.__doc__ = """Operations delayed due to cache space constraints Floating point short

SMF Info
--------
    Field: `R745DFWR`
    Record: `SMF74S5`
    Map: `R745DEV`

Operations delayed due to cache space constraints Floating point short
"""

r745xdvn : Final[Field] = Field(
    name='r745xdvn',
    origin='R745XDVN',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Device number (binary)

SMF Info
--------
    Field: `R745XDVN`
    Record: `SMF74S5`
    Map: `R745XDEV`

Device number (binary)
"""
r745xdvn.__doc__ = """Device number (binary)

SMF Info
--------
    Field: `R745XDVN`
    Record: `SMF74S5`
    Map: `R745XDEV`

Device number (binary)
"""

r745xscs : Final[Field] = Field(
    name='r745xscs',
    origin='R745XSCS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745XDEV,
)
"""Subchannel set ID

SMF Info
--------
    Field: `R745XSCS`
    Record: `SMF74S5`
    Map: `R745XDEV`

Subchannel set ID
"""
r745xscs.__doc__ = """Subchannel set ID

SMF Info
--------
    Field: `R745XSCS`
    Record: `SMF74S5`
    Map: `R745XDEV`

Subchannel set ID
"""

r745xrsv : Final[Field] = Field(
    name='r745xrsv',
    origin='R745XRSV',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Lower interface I/O msec

SMF Info
--------
    Field: `R745XRSV`
    Record: `SMF74S5`
    Map: `R745XDEV`

Lower interface I/O msec
"""
r745xrsv.__doc__ = """Lower interface I/O msec

SMF Info
--------
    Field: `R745XRSV`
    Record: `SMF74S5`
    Map: `R745XDEV`

Lower interface I/O msec
"""

r745xctc : Final[Field] = Field(
    name='r745xctc',
    origin='R745XCTC',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not Used by RMF

SMF Info
--------
    Field: `R745XCTC`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not Used by RMF
"""
r745xctc.__doc__ = """Not Used by RMF

SMF Info
--------
    Field: `R745XCTC`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not Used by RMF
"""

r745xctr : Final[Field] = Field(
    name='r745xctr',
    origin='R745XCTR',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCTR`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xctr.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCTR`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xvrd : Final[Field] = Field(
    name='r745xvrd',
    origin='R745XVRD',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XVRD`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xvrd.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XVRD`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xvrh : Final[Field] = Field(
    name='r745xvrh',
    origin='R745XVRH',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XVRH`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xvrh.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XVRH`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xvwr : Final[Field] = Field(
    name='r745xvwr',
    origin='R745XVWR',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XVWR`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xvwr.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XVWR`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xvwh : Final[Field] = Field(
    name='r745xvwh',
    origin='R745XVWH',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XVWH`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xvwh.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XVWH`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xsrr : Final[Field] = Field(
    name='r745xsrr',
    origin='R745XSRR',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XSRR`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xsrr.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XSRR`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xfrd : Final[Field] = Field(
    name='r745xfrd',
    origin='R745XFRD',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XFRD`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xfrd.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XFRD`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xwcc : Final[Field] = Field(
    name='r745xwcc',
    origin='R745XWCC',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XWCC`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xwcc.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XWCC`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xprc : Final[Field] = Field(
    name='r745xprc',
    origin='R745XPRC',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XPRC`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xprc.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XPRC`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xct1 : Final[Field] = Field(
    name='r745xct1',
    origin='R745XCT1',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCT1`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xct1.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCT1`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xct2 : Final[Field] = Field(
    name='r745xct2',
    origin='R745XCT2',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCT2`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xct2.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCT2`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xct3 : Final[Field] = Field(
    name='r745xct3',
    origin='R745XCT3',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCT3`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xct3.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCT3`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xct4 : Final[Field] = Field(
    name='r745xct4',
    origin='R745XCT4',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCT4`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xct4.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCT4`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xct5 : Final[Field] = Field(
    name='r745xct5',
    origin='R745XCT5',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCT5`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xct5.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCT5`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xct6 : Final[Field] = Field(
    name='r745xct6',
    origin='R745XCT6',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCT6`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xct6.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCT6`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xct7 : Final[Field] = Field(
    name='r745xct7',
    origin='R745XCT7',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCT7`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xct7.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCT7`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xct8 : Final[Field] = Field(
    name='r745xct8',
    origin='R745XCT8',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCT8`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xct8.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCT8`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xct9 : Final[Field] = Field(
    name='r745xct9',
    origin='R745XCT9',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCT9`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xct9.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCT9`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745xcta : Final[Field] = Field(
    name='r745xcta',
    origin='R745XCTA',
    type=FieldType.STRING,
    record=record,
    record_map=R745XDEV,
)
"""Not used by RMF

SMF Info
--------
    Field: `R745XCTA`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""
r745xcta.__doc__ = """Not used by RMF

SMF Info
--------
    Field: `R745XCTA`
    Record: `SMF74S5`
    Map: `R745XDEV`

Not used by RMF
"""

r745svol : Final[Field] = Field(
    name='r745svol',
    origin='R745SVOL',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Volume serial of device

SMF Info
--------
    Field: `R745SVOL`
    Record: `SMF74S5`
    Map: `R745STAT`

Volume serial of device
"""
r745svol.__doc__ = """Volume serial of device

SMF Info
--------
    Field: `R745SVOL`
    Record: `SMF74S5`
    Map: `R745STAT`

Volume serial of device
"""

r745sunt : Final[Field] = Field(
    name='r745sunt',
    origin='R745SUNT',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Unit addr. for sense CMD

SMF Info
--------
    Field: `R745SUNT`
    Record: `SMF74S5`
    Map: `R745STAT`

Unit addr. for sense CMD
"""
r745sunt.__doc__ = """Unit addr. for sense CMD

SMF Info
--------
    Field: `R745SUNT`
    Record: `SMF74S5`
    Map: `R745STAT`

Unit addr. for sense CMD
"""

r745sdev : Final[Field] = Field(
    name='r745sdev',
    origin='R745SDEV',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Device number (binary)

SMF Info
--------
    Field: `R745SDEV`
    Record: `SMF74S5`
    Map: `R745STAT`

Device number (binary)
"""
r745sdev.__doc__ = """Device number (binary)

SMF Info
--------
    Field: `R745SDEV`
    Record: `SMF74S5`
    Map: `R745STAT`

Device number (binary)
"""

r745sln : Final[Field] = Field(
    name='r745sln',
    origin='R745SLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Length of data section

SMF Info
--------
    Field: `R745SLN`
    Record: `SMF74S5`
    Map: `R745STAT`

Length of data section
"""
r745sln.__doc__ = """Length of data section

SMF Info
--------
    Field: `R745SLN`
    Record: `SMF74S5`
    Map: `R745STAT`

Length of data section
"""

r745sft : Final[Field] = Field(
    name='r745sft',
    origin='R745SFT',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Status data format B'....0000' = 40 bytes sense B'.......1' = 44 bytes sense/ unit KB B'......10' = 96 bytes sense/ unit KB

SMF Info
--------
    Field: `R745SFT`
    Record: `SMF74S5`
    Map: `R745STAT`

Status data format B'....0000' = 40 bytes sense B'.......1' = 44 bytes sense/ unit KB B'......10' = 96 bytes sense/ unit KB
"""
r745sft.__doc__ = """Status data format B'....0000' = 40 bytes sense B'.......1' = 44 bytes sense/ unit KB B'......10' = 96 bytes sense/ unit KB

SMF Info
--------
    Field: `R745SFT`
    Record: `SMF74S5`
    Map: `R745STAT`

Status data format B'....0000' = 40 bytes sense B'.......1' = 44 bytes sense/ unit KB B'......10' = 96 bytes sense/ unit KB
"""

r745sdid : Final[Field] = Field(
    name='r745sdid',
    origin='R745SDID',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Device ID

SMF Info
--------
    Field: `R745SDID`
    Record: `SMF74S5`
    Map: `R745STAT`

Device ID
"""
r745sdid.__doc__ = """Device ID

SMF Info
--------
    Field: `R745SDID`
    Record: `SMF74S5`
    Map: `R745STAT`

Device ID
"""

r745snad : Final[Field] = Field(
    name='r745snad',
    origin='R745SNAD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Num. of attached devices

SMF Info
--------
    Field: `R745SNAD`
    Record: `SMF74S5`
    Map: `R745STAT`

Num. of attached devices
"""
r745snad.__doc__ = """Num. of attached devices

SMF Info
--------
    Field: `R745SNAD`
    Record: `SMF74S5`
    Map: `R745STAT`

Num. of attached devices
"""

r745snss : Final[Field] = Field(
    name='r745snss',
    origin='R745SNSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Num. of statistic sets

SMF Info
--------
    Field: `R745SNSS`
    Record: `SMF74S5`
    Map: `R745STAT`

Num. of statistic sets
"""
r745snss.__doc__ = """Num. of statistic sets

SMF Info
--------
    Field: `R745SNSS`
    Record: `SMF74S5`
    Map: `R745STAT`

Num. of statistic sets
"""

r745scs : Final[Field] = Field(
    name='r745scs',
    origin='R745SCS',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Caching status ...1 .... Reserved .... 1... Storage Facility running as a single cluster .... .1.. Must be zero .... ..1. Reserved

SMF Info
--------
    Field: `R745SCS`
    Record: `SMF74S5`
    Map: `R745STAT`

Caching status ...1 .... Reserved .... 1... Storage Facility running as a single cluster .... .1.. Must be zero .... ..1. Reserved
"""
r745scs.__doc__ = """Caching status ...1 .... Reserved .... 1... Storage Facility running as a single cluster .... .1.. Must be zero .... ..1. Reserved

SMF Info
--------
    Field: `R745SCS`
    Record: `SMF74S5`
    Map: `R745STAT`

Caching status ...1 .... Reserved .... 1... Storage Facility running as a single cluster .... .1.. Must be zero .... ..1. Reserved
"""

r745sos : Final[Field] = Field(
    name='r745sos',
    origin='R745SOS',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Overall caching status B'000' = Caching active B'001' = Reserved B'010' = Subsystem error B'011'- B'111' = Reserved

SMF Info
--------
    Field: `R745SOS`
    Record: `SMF74S5`
    Map: `R745STAT`

Overall caching status B'000' = Caching active B'001' = Reserved B'010' = Subsystem error B'011'- B'111' = Reserved
"""
r745sos.__doc__ = """Overall caching status B'000' = Caching active B'001' = Reserved B'010' = Subsystem error B'011'- B'111' = Reserved

SMF Info
--------
    Field: `R745SOS`
    Record: `SMF74S5`
    Map: `R745STAT`

Overall caching status B'000' = Caching active B'001' = Reserved B'010' = Subsystem error B'011'- B'111' = Reserved
"""

r745snr : Final[Field] = Field(
    name='r745snr',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r745sos,
    record=record,
    record_map=R745STAT,
)
"""Non-retentive deactivated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sos`(`R745SOS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Non-retentive deactivated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r745snr.__doc__ = """Non-retentive deactivated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sos`(`R745SOS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Non-retentive deactivated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r745svss : Final[Field] = Field(
    name='r745svss',
    origin='R745SVSS',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Non-volatile storage stat.

SMF Info
--------
    Field: `R745SVSS`
    Record: `SMF74S5`
    Map: `R745STAT`

Non-volatile storage stat.
"""
r745svss.__doc__ = """Non-volatile storage stat.

SMF Info
--------
    Field: `R745SVSS`
    Record: `SMF74S5`
    Map: `R745STAT`

Non-volatile storage stat.
"""

r745snht : Final[Field] = Field(
    name='r745snht',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r745svss,
    record=record,
    record_map=R745STAT,
)
"""Host termination(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Host termination

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r745snht.__doc__ = """Host termination(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Host termination

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r745snis : Final[Field] = Field(
    name='r745snis',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r745svss,
    record=record,
    record_map=R745STAT,
)
"""Problem termination(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Problem termination

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r745snis.__doc__ = """Problem termination(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Problem termination

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r745dfwi : Final[Field] = Field(
    name='r745dfwi',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r745svss,
    record=record,
    record_map=R745STAT,
)
"""DFW inhibited(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

DFW inhibited

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r745dfwi.__doc__ = """DFW inhibited(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

DFW inhibited

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r745snds : Final[Field] = Field(
    name='r745snds',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r745svss,
    record=record,
    record_map=R745STAT,
)
"""Disabled for maintenance(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Disabled for maintenance

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r745snds.__doc__ = """Disabled for maintenance(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Disabled for maintenance

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r745snpe : Final[Field] = Field(
    name='r745snpe',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r745svss,
    record=record,
    record_map=R745STAT,
)
"""Pending due to problem(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Pending due to problem

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r745snpe.__doc__ = """Pending due to problem(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745svss`(`R745SVSS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Pending due to problem

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r745scln : Final[Field] = Field(
    name='r745scln',
    origin='R745SCLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Lng.of subsys. count area

SMF Info
--------
    Field: `R745SCLN`
    Record: `SMF74S5`
    Map: `R745STAT`

Lng.of subsys. count area
"""
r745scln.__doc__ = """Lng.of subsys. count area

SMF Info
--------
    Field: `R745SCLN`
    Record: `SMF74S5`
    Map: `R745STAT`

Lng.of subsys. count area
"""

r745scsf : Final[Field] = Field(
    name='r745scsf',
    origin='R745SCSF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""State of Copy Services Function

SMF Info
--------
    Field: `R745SCSF`
    Record: `SMF74S5`
    Map: `R745STAT`

State of Copy Services Function
"""
r745scsf.__doc__ = """State of Copy Services Function

SMF Info
--------
    Field: `R745SCSF`
    Record: `SMF74S5`
    Map: `R745STAT`

State of Copy Services Function
"""

r745scnf : Final[Field] = Field(
    name='r745scnf',
    origin='R745SCNF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Configured subsystem storage if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SCNF`
    Record: `SMF74S5`
    Map: `R745STAT`

Configured subsystem storage if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""
r745scnf.__doc__ = """Configured subsystem storage if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SCNF`
    Record: `SMF74S5`
    Map: `R745STAT`

Configured subsystem storage if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""

r745savl : Final[Field] = Field(
    name='r745savl',
    origin='R745SAVL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Available subsystem storage if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SAVL`
    Record: `SMF74S5`
    Map: `R745STAT`

Available subsystem storage if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""
r745savl.__doc__ = """Available subsystem storage if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SAVL`
    Record: `SMF74S5`
    Map: `R745STAT`

Available subsystem storage if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""

r745spin : Final[Field] = Field(
    name='r745spin',
    origin='R745SPIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Pinned subsystem storage,collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SPIN`
    Record: `SMF74S5`
    Map: `R745STAT`

Pinned subsystem storage,collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""
r745spin.__doc__ = """Pinned subsystem storage,collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SPIN`
    Record: `SMF74S5`
    Map: `R745STAT`

Pinned subsystem storage,collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""

r745soff : Final[Field] = Field(
    name='r745soff',
    origin='R745SOFF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Offline subsystem storage, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SOFF`
    Record: `SMF74S5`
    Map: `R745STAT`

Offline subsystem storage, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""
r745soff.__doc__ = """Offline subsystem storage, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SOFF`
    Record: `SMF74S5`
    Map: `R745STAT`

Offline subsystem storage, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""

r745sds1 : Final[Field] = Field(
    name='r745sds1',
    origin='R745SDS1',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Addressed device status 1

SMF Info
--------
    Field: `R745SDS1`
    Record: `SMF74S5`
    Map: `R745STAT`

Addressed device status 1
"""
r745sds1.__doc__ = """Addressed device status 1

SMF Info
--------
    Field: `R745SDS1`
    Record: `SMF74S5`
    Map: `R745STAT`

Addressed device status 1
"""

r745sdcs : Final[Field] = Field(
    name='r745sdcs',
    origin='R745SDCS',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Device caching status B'00' = Caching activated

SMF Info
--------
    Field: `R745SDCS`
    Record: `SMF74S5`
    Map: `R745STAT`

Device caching status B'00' = Caching activated
"""
r745sdcs.__doc__ = """Device caching status B'00' = Caching activated

SMF Info
--------
    Field: `R745SDCS`
    Record: `SMF74S5`
    Map: `R745STAT`

Device caching status B'00' = Caching activated
"""

r745sdfw : Final[Field] = Field(
    name='r745sdfw',
    origin='R745SDFW',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""DASD fast write status B'00' = DFW allowed

SMF Info
--------
    Field: `R745SDFW`
    Record: `SMF74S5`
    Map: `R745STAT`

DASD fast write status B'00' = DFW allowed
"""
r745sdfw.__doc__ = """DASD fast write status B'00' = DFW allowed

SMF Info
--------
    Field: `R745SDFW`
    Record: `SMF74S5`
    Map: `R745STAT`

DASD fast write status B'00' = DFW allowed
"""

r745spdp : Final[Field] = Field(
    name='r745spdp',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r745sdfw,
    record=record,
    record_map=R745STAT,
)
"""PPRC copy pair suspended(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sdfw`(`R745SDFW`)
    Record: `SMF74S5`
    Map: `R745STAT`

PPRC copy pair suspended

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r745spdp.__doc__ = """PPRC copy pair suspended(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sdfw`(`R745SDFW`)
    Record: `SMF74S5`
    Map: `R745STAT`

PPRC copy pair suspended

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r745ssdp : Final[Field] = Field(
    name='r745ssdp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r745sdfw,
    record=record,
    record_map=R745STAT,
)
"""PPRC copy pair is duplex pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sdfw`(`R745SDFW`)
    Record: `SMF74S5`
    Map: `R745STAT`

PPRC copy pair is duplex pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r745ssdp.__doc__ = """PPRC copy pair is duplex pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sdfw`(`R745SDFW`)
    Record: `SMF74S5`
    Map: `R745STAT`

PPRC copy pair is duplex pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r745sdps : Final[Field] = Field(
    name='r745sdps',
    origin='R745SDPS',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""PPRC pair status B'00' = PPRC pair available (full duplex) B'01' = PPRC pair pending B'10' = Not used B'11' = Suspended

SMF Info
--------
    Field: `R745SDPS`
    Record: `SMF74S5`
    Map: `R745STAT`

PPRC pair status B'00' = PPRC pair available (full duplex) B'01' = PPRC pair pending B'10' = Not used B'11' = Suspended
"""
r745sdps.__doc__ = """PPRC pair status B'00' = PPRC pair available (full duplex) B'01' = PPRC pair pending B'10' = Not used B'11' = Suspended

SMF Info
--------
    Field: `R745SDPS`
    Record: `SMF74S5`
    Map: `R745STAT`

PPRC pair status B'00' = PPRC pair available (full duplex) B'01' = PPRC pair pending B'10' = Not used B'11' = Suspended
"""

r745sds2 : Final[Field] = Field(
    name='r745sds2',
    origin='R745SDS2',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Addressed device status 2 If R745SFT = 0 Pinned data (2 bits) 00.. .... No pinned data 01.. .... Pinned data exists for device 10.. .... Reserved 11.. .... Not used ..xx xx.. Not used .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled If R745SFT = 1 or 2 Global Mirror State (3 bits) 000. .... No Global Mirror configured 001. .... Global Mirror running optimal 010. .... Global Mirror running suboptimal 011. .... Global Mirror running Consistency Groups failing 100. .... Global Mirror paused 101. .... Global Mirror fatal 110. .... More than 1 Global Mirror session running in the box 111. .... Reserved ...1 .... Session Member pending .... 1... Volume not allowed online .... .1.. Reserved .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled

SMF Info
--------
    Field: `R745SDS2`
    Record: `SMF74S5`
    Map: `R745STAT`

Addressed device status 2 If R745SFT = 0 Pinned data (2 bits) 00.. .... No pinned data 01.. .... Pinned data exists for device 10.. .... Reserved 11.. .... Not used ..xx xx.. Not used .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled If R745SFT = 1 or 2 Global Mirror State (3 bits) 000. .... No Global Mirror configured 001. .... Global Mirror running optimal 010. .... Global Mirror running suboptimal 011. .... Global Mirror running Consistency Groups failing 100. .... Global Mirror paused 101. .... Global Mirror fatal 110. .... More than 1 Global Mirror session running in the box 111. .... Reserved ...1 .... Session Member pending .... 1... Volume not allowed online .... .1.. Reserved .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled
"""
r745sds2.__doc__ = """Addressed device status 2 If R745SFT = 0 Pinned data (2 bits) 00.. .... No pinned data 01.. .... Pinned data exists for device 10.. .... Reserved 11.. .... Not used ..xx xx.. Not used .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled If R745SFT = 1 or 2 Global Mirror State (3 bits) 000. .... No Global Mirror configured 001. .... Global Mirror running optimal 010. .... Global Mirror running suboptimal 011. .... Global Mirror running Consistency Groups failing 100. .... Global Mirror paused 101. .... Global Mirror fatal 110. .... More than 1 Global Mirror session running in the box 111. .... Reserved ...1 .... Session Member pending .... 1... Volume not allowed online .... .1.. Reserved .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled

SMF Info
--------
    Field: `R745SDS2`
    Record: `SMF74S5`
    Map: `R745STAT`

Addressed device status 2 If R745SFT = 0 Pinned data (2 bits) 00.. .... No pinned data 01.. .... Pinned data exists for device 10.. .... Reserved 11.. .... Not used ..xx xx.. Not used .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled If R745SFT = 1 or 2 Global Mirror State (3 bits) 000. .... No Global Mirror configured 001. .... Global Mirror running optimal 010. .... Global Mirror running suboptimal 011. .... Global Mirror running Consistency Groups failing 100. .... Global Mirror paused 101. .... Global Mirror fatal 110. .... More than 1 Global Mirror session running in the box 111. .... Reserved ...1 .... Session Member pending .... 1... Volume not allowed online .... .1.. Reserved .... ..1. Advanced FlashCopy enabled .... ...1 FlashCopy volume enabled
"""

r745sdpn : Final[Field] = Field(
    name='r745sdpn',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r745sds2,
    record=record,
    record_map=R745STAT,
)
"""Pinned data (no longer used)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sds2`(`R745SDS2`)
    Record: `SMF74S5`
    Map: `R745STAT`

Pinned data (no longer used)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r745sdpn.__doc__ = """Pinned data (no longer used)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sds2`(`R745SDS2`)
    Record: `SMF74S5`
    Map: `R745STAT`

Pinned data (no longer used)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r745scnv : Final[Field] = Field(
    name='r745scnv',
    origin='R745SCNV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Config. non-volatile cache, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SCNV`
    Record: `SMF74S5`
    Map: `R745STAT`

Config. non-volatile cache, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""
r745scnv.__doc__ = """Config. non-volatile cache, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SCNV`
    Record: `SMF74S5`
    Map: `R745STAT`

Config. non-volatile cache, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""

r745spnd : Final[Field] = Field(
    name='r745spnd',
    origin='R745SPND',
    type=FieldType.INTEGER,
    record=record,
    record_map=R745STAT,
)
"""Pinned non-volatile cache, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SPND`
    Record: `SMF74S5`
    Map: `R745STAT`

Pinned non-volatile cache, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""
r745spnd.__doc__ = """Pinned non-volatile cache, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB

SMF Info
--------
    Field: `R745SPND`
    Record: `SMF74S5`
    Map: `R745STAT`

Pinned non-volatile cache, collected for if R745SFT = 0 in bytes if R745SFT = 1 or 2 in KB
"""

r745sg2 : Final[Field] = Field(
    name='r745sg2',
    origin='R745SG2',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Device status group 2 .... 1... Device in a SPID Fenced state .... .1.. Volume is part of a RAID rank that is undergoing RAID rebuild

SMF Info
--------
    Field: `R745SG2`
    Record: `SMF74S5`
    Map: `R745STAT`

Device status group 2 .... 1... Device in a SPID Fenced state .... .1.. Volume is part of a RAID rank that is undergoing RAID rebuild
"""
r745sg2.__doc__ = """Device status group 2 .... 1... Device in a SPID Fenced state .... .1.. Volume is part of a RAID rank that is undergoing RAID rebuild

SMF Info
--------
    Field: `R745SG2`
    Record: `SMF74S5`
    Map: `R745STAT`

Device status group 2 .... 1... Device in a SPID Fenced state .... .1.. Volume is part of a RAID rank that is undergoing RAID rebuild
"""

r745scol : Final[Field] = Field(
    name='r745scol',
    origin='R745SCOL',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Colume Space Management B'00' = Standard volume B'01' = Track Space Efficient Volume B'10' = Extent Space Efficient Volume B'11' = Reserved

SMF Info
--------
    Field: `R745SCOL`
    Record: `SMF74S5`
    Map: `R745STAT`

Colume Space Management B'00' = Standard volume B'01' = Track Space Efficient Volume B'10' = Extent Space Efficient Volume B'11' = Reserved
"""
r745scol.__doc__ = """Colume Space Management B'00' = Standard volume B'01' = Track Space Efficient Volume B'10' = Extent Space Efficient Volume B'11' = Reserved

SMF Info
--------
    Field: `R745SCOL`
    Record: `SMF74S5`
    Map: `R745STAT`

Colume Space Management B'00' = Standard volume B'01' = Track Space Efficient Volume B'10' = Extent Space Efficient Volume B'11' = Reserved
"""

r745sfvs : Final[Field] = Field(
    name='r745sfvs',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r745scol,
    record=record,
    record_map=R745STAT,
)
"""Data on failed NVS(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745scol`(`R745SCOL`)
    Record: `SMF74S5`
    Map: `R745STAT`

Data on failed NVS

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r745sfvs.__doc__ = """Data on failed NVS(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745scol`(`R745SCOL`)
    Record: `SMF74S5`
    Map: `R745STAT`

Data on failed NVS

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r745sdbp : Final[Field] = Field(
    name='r745sdbp',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r745scol,
    record=record,
    record_map=R745STAT,
)
"""Device in a Soft Fenced state pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745scol`(`R745SCOL`)
    Record: `SMF74S5`
    Map: `R745STAT`

Device in a Soft Fenced state pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r745sdbp.__doc__ = """Device in a Soft Fenced state pending(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745scol`(`R745SCOL`)
    Record: `SMF74S5`
    Map: `R745STAT`

Device in a Soft Fenced state pending

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r745spda : Final[Field] = Field(
    name='r745spda',
    origin='R745SPDA',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""If R745SFT = 1 or 2 Pinned data B'00' = No pinned data B'01' = Pinned data exists for the device B'10' = Reserved B'11' = Not used

SMF Info
--------
    Field: `R745SPDA`
    Record: `SMF74S5`
    Map: `R745STAT`

If R745SFT = 1 or 2 Pinned data B'00' = No pinned data B'01' = Pinned data exists for the device B'10' = Reserved B'11' = Not used
"""
r745spda.__doc__ = """If R745SFT = 1 or 2 Pinned data B'00' = No pinned data B'01' = Pinned data exists for the device B'10' = Reserved B'11' = Not used

SMF Info
--------
    Field: `R745SPDA`
    Record: `SMF74S5`
    Map: `R745STAT`

If R745SFT = 1 or 2 Pinned data B'00' = No pinned data B'01' = Pinned data exists for the device B'10' = Reserved B'11' = Not used
"""

r745sgl : Final[Field] = Field(
    name='r745sgl',
    origin='R745SGL',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Global status X'80' CFW & DFW suspended

SMF Info
--------
    Field: `R745SGL`
    Record: `SMF74S5`
    Map: `R745STAT`

Global status X'80' CFW & DFW suspended
"""
r745sgl.__doc__ = """Global status X'80' CFW & DFW suspended

SMF Info
--------
    Field: `R745SGL`
    Record: `SMF74S5`
    Map: `R745STAT`

Global status X'80' CFW & DFW suspended
"""

r745ssid : Final[Field] = Field(
    name='r745ssid',
    origin='R745SSID',
    type=FieldType.STRING,
    record=record,
    record_map=R745STAT,
)
"""Subsystem Id

SMF Info
--------
    Field: `R745SSID`
    Record: `SMF74S5`
    Map: `R745STAT`

Subsystem Id
"""
r745ssid.__doc__ = """Subsystem Id

SMF Info
--------
    Field: `R745SSID`
    Record: `SMF74S5`
    Map: `R745STAT`

Subsystem Id
"""

r745sds : Final[Field] = Field(
    name='r745sds',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r745sos,
    record=record,
    record_map=R745STAT,
)
"""Disabled for maintenance (No longer used)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sos`(`R745SOS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r745sds.__doc__ = """Disabled for maintenance (No longer used)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sos`(`R745SOS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r745sim : Final[Field] = Field(
    name='r745sim',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r745sos,
    record=record,
    record_map=R745STAT,
)
"""IML device not available (no longer used)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sos`(`R745SOS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r745sim.__doc__ = """IML device not available (no longer used)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sos`(`R745SOS`)
    Record: `SMF74S5`
    Map: `R745STAT`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r745sfdp : Final[Field] = Field(
    name='r745sfdp',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r745sds2,
    record=record,
    record_map=R745STAT,
)
"""Device is failed duplex (no longer used)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sds2`(`R745SDS2`)
    Record: `SMF74S5`
    Map: `R745STAT`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r745sfdp.__doc__ = """Device is failed duplex (no longer used)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r745sds2`(`R745SDS2`)
    Record: `SMF74S5`
    Map: `R745STAT`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r7451dvn : Final[Field] = Field(
    name='r7451dvn',
    origin='R7451DVN',
    type=FieldType.STRING,
    record=record,
    record_map=R7451DEV,
)
"""Device number (binary)

SMF Info
--------
    Field: `R7451DVN`
    Record: `SMF74S5`
    Map: `R7451DEV`

Device number (binary)
"""
r7451dvn.__doc__ = """Device number (binary)

SMF Info
--------
    Field: `R7451DVN`
    Record: `SMF74S5`
    Map: `R7451DEV`

Device number (binary)
"""

r7451inc : Final[Field] = Field(
    name='r7451inc',
    origin='R7451INC',
    type=FieldType.STRING,
    record=record,
    record_map=R7451DEV,
)
"""Increment values

SMF Info
--------
    Field: `R7451INC`
    Record: `SMF74S5`
    Map: `R7451DEV`

Increment values
"""
r7451inc.__doc__ = """Increment values

SMF Info
--------
    Field: `R7451INC`
    Record: `SMF74S5`
    Map: `R7451DEV`

Increment values
"""

r7451sio : Final[Field] = Field(
    name='r7451sio',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r7451inc,
    record=record,
    record_map=R7451DEV,
)
"""'1' = Synchronous I/O cache data are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7451inc`(`R7451INC`)
    Record: `SMF74S5`
    Map: `R7451DEV`

'1' = Synchronous I/O cache data are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r7451sio.__doc__ = """'1' = Synchronous I/O cache data are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7451inc`(`R7451INC`)
    Record: `SMF74S5`
    Map: `R7451DEV`

'1' = Synchronous I/O cache data are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r7451hpf : Final[Field] = Field(
    name='r7451hpf',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r7451inc,
    record=record,
    record_map=R7451DEV,
)
"""zHPF read and write I/O requests available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7451inc`(`R7451INC`)
    Record: `SMF74S5`
    Map: `R7451DEV`

zHPF read and write I/O requests available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r7451hpf.__doc__ = """zHPF read and write I/O requests available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7451inc`(`R7451INC`)
    Record: `SMF74S5`
    Map: `R7451DEV`

zHPF read and write I/O requests available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r7451unt : Final[Field] = Field(
    name='r7451unt',
    origin='R7451UNT',
    type=FieldType.STRING,
    record=record,
    record_map=R7451DEV,
)
"""Units: '00' = Bytes in units of 128K. Times in units of 16 milliseconds. '01' = Reserved. '10' = Reserved. '11' = Reserved.

SMF Info
--------
    Field: `R7451UNT`
    Record: `SMF74S5`
    Map: `R7451DEV`

Units: '00' = Bytes in units of 128K. Times in units of 16 milliseconds. '01' = Reserved. '10' = Reserved. '11' = Reserved.
"""
r7451unt.__doc__ = """Units: '00' = Bytes in units of 128K. Times in units of 16 milliseconds. '01' = Reserved. '10' = Reserved. '11' = Reserved.

SMF Info
--------
    Field: `R7451UNT`
    Record: `SMF74S5`
    Map: `R7451DEV`

Units: '00' = Bytes in units of 128K. Times in units of 16 milliseconds. '01' = Reserved. '10' = Reserved. '11' = Reserved.
"""

r7451xfl : Final[Field] = Field(
    name='r7451xfl',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r7451unt,
    record=record,
    record_map=R7451DEV,
)
"""'1' = Transfer statistics R7451XFR valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7451unt`(`R7451UNT`)
    Record: `SMF74S5`
    Map: `R7451DEV`

'1' = Transfer statistics R7451XFR valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r7451xfl.__doc__ = """'1' = Transfer statistics R7451XFR valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7451unt`(`R7451UNT`)
    Record: `SMF74S5`
    Map: `R7451DEV`

'1' = Transfer statistics R7451XFR valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r7451scs : Final[Field] = Field(
    name='r7451scs',
    origin='R7451SCS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7451DEV,
)
"""Subchannel set ID

SMF Info
--------
    Field: `R7451SCS`
    Record: `SMF74S5`
    Map: `R7451DEV`

Subchannel set ID
"""
r7451scs.__doc__ = """Subchannel set ID

SMF Info
--------
    Field: `R7451SCS`
    Record: `SMF74S5`
    Map: `R7451DEV`

Subchannel set ID
"""

r7451rsv : Final[Field] = Field(
    name='r7451rsv',
    origin='R7451RSV',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Lower interface I/O activity in msec (short float). Zero for 2107

SMF Info
--------
    Field: `R7451RSV`
    Record: `SMF74S5`
    Map: `R7451DEV`

Lower interface I/O activity in msec (short float). Zero for 2107
"""
r7451rsv.__doc__ = """Lower interface I/O activity in msec (short float). Zero for 2107

SMF Info
--------
    Field: `R7451RSV`
    Record: `SMF74S5`
    Map: `R7451DEV`

Lower interface I/O activity in msec (short float). Zero for 2107
"""

r7451flg : Final[Field] = Field(
    name='r7451flg',
    origin='R7451FLG',
    type=FieldType.STRING,
    record=record,
    record_map=R7451DEV,
)
"""Information in this section: X'00' = No additional data. X'01' = RAID rank data. X'02' = Physical storage data.

SMF Info
--------
    Field: `R7451FLG`
    Record: `SMF74S5`
    Map: `R7451DEV`

Information in this section: X'00' = No additional data. X'01' = RAID rank data. X'02' = Physical storage data.
"""
r7451flg.__doc__ = """Information in this section: X'00' = No additional data. X'01' = RAID rank data. X'02' = Physical storage data.

SMF Info
--------
    Field: `R7451FLG`
    Record: `SMF74S5`
    Map: `R7451DEV`

Information in this section: X'00' = No additional data. X'01' = RAID rank data. X'02' = Physical storage data.
"""

r7451aid : Final[Field] = Field(
    name='r7451aid',
    origin='R7451AID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7451DEV,
)
"""Device adapter ID. Only valid with RAID rank data

SMF Info
--------
    Field: `R7451AID`
    Record: `SMF74S5`
    Map: `R7451DEV`

Device adapter ID. Only valid with RAID rank data
"""
r7451aid.__doc__ = """Device adapter ID. Only valid with RAID rank data

SMF Info
--------
    Field: `R7451AID`
    Record: `SMF74S5`
    Map: `R7451DEV`

Device adapter ID. Only valid with RAID rank data
"""

r7452xid : Final[Field] = Field(
    name='r7452xid',
    origin='R7452XID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7451DEV,
)
"""Extent pool id

SMF Info
--------
    Field: `R7452XID`
    Record: `SMF74S5`
    Map: `R7451DEV`

Extent pool id
"""
r7452xid.__doc__ = """Extent pool id

SMF Info
--------
    Field: `R7452XID`
    Record: `SMF74S5`
    Map: `R7451DEV`

Extent pool id
"""

r7452xty : Final[Field] = Field(
    name='r7452xty',
    origin='R7452XTY',
    type=FieldType.STRING,
    record=record,
    record_map=R7451DEV,
)
"""Extent type: X'04' = FB 1Gb. X'84' = CKD 1Gb

SMF Info
--------
    Field: `R7452XTY`
    Record: `SMF74S5`
    Map: `R7451DEV`

Extent type: X'04' = FB 1Gb. X'84' = CKD 1Gb
"""
r7452xty.__doc__ = """Extent type: X'04' = FB 1Gb. X'84' = CKD 1Gb

SMF Info
--------
    Field: `R7452XTY`
    Record: `SMF74S5`
    Map: `R7451DEV`

Extent type: X'04' = FB 1Gb. X'84' = CKD 1Gb
"""

r7452xfl : Final[Field] = Field(
    name='r7452xfl',
    origin='R7452XFL',
    type=FieldType.STRING,
    record=record,
    record_map=R7451DEV,
)
"""Extent flags

SMF Info
--------
    Field: `R7452XFL`
    Record: `SMF74S5`
    Map: `R7451DEV`

Extent flags
"""
r7452xfl.__doc__ = """Extent flags

SMF Info
--------
    Field: `R7452XFL`
    Record: `SMF74S5`
    Map: `R7451DEV`

Extent flags
"""

r7452dxa : Final[Field] = Field(
    name='r7452dxa',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r7452xfl,
    record=record,
    record_map=R7451DEV,
)
"""Dynamic extent allocation(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7452xfl`(`R7452XFL`)
    Record: `SMF74S5`
    Map: `R7451DEV`

Dynamic extent allocation

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r7452dxa.__doc__ = """Dynamic extent allocation(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7452xfl`(`R7452XFL`)
    Record: `SMF74S5`
    Map: `R7451DEV`

Dynamic extent allocation

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r7452dsh : Final[Field] = Field(
    name='r7452dsh',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r7452xfl,
    record=record,
    record_map=R7451DEV,
)
"""Data sharing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7452xfl`(`R7452XFL`)
    Record: `SMF74S5`
    Map: `R7451DEV`

Data sharing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r7452dsh.__doc__ = """Data sharing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7452xfl`(`R7452XFL`)
    Record: `SMF74S5`
    Map: `R7451DEV`

Data sharing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r7452mis : Final[Field] = Field(
    name='r7452mis',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r7452xfl,
    record=record,
    record_map=R7451DEV,
)
"""Migrating/migration state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7452xfl`(`R7452XFL`)
    Record: `SMF74S5`
    Map: `R7451DEV`

Migrating/migration state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r7452mis.__doc__ = """Migrating/migration state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7452xfl`(`R7452XFL`)
    Record: `SMF74S5`
    Map: `R7451DEV`

Migrating/migration state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r7451hss : Final[Field] = Field(
    name='r7451hss',
    origin='R7451HSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R7451DEV,
)
"""HDD sector size. Only valid with RAID rank data

SMF Info
--------
    Field: `R7451HSS`
    Record: `SMF74S5`
    Map: `R7451DEV`

HDD sector size. Only valid with RAID rank data
"""
r7451hss.__doc__ = """HDD sector size. Only valid with RAID rank data

SMF Info
--------
    Field: `R7451HSS`
    Record: `SMF74S5`
    Map: `R7451DEV`

HDD sector size. Only valid with RAID rank data
"""

r7452pro : Final[Field] = Field(
    name='r7452pro',
    origin='R7452PRO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Physical storage read operations (short float)

SMF Info
--------
    Field: `R7452PRO`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage read operations (short float)
"""
r7452pro.__doc__ = """Physical storage read operations (short float)

SMF Info
--------
    Field: `R7452PRO`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage read operations (short float)
"""

r7452pwo : Final[Field] = Field(
    name='r7452pwo',
    origin='R7452PWO',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Physical storage write operations (short float)

SMF Info
--------
    Field: `R7452PWO`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage write operations (short float)
"""
r7452pwo.__doc__ = """Physical storage write operations (short float)

SMF Info
--------
    Field: `R7452PWO`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage write operations (short float)
"""

r7452pbr : Final[Field] = Field(
    name='r7452pbr',
    origin='R7452PBR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Physical storage bytes read (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7452PBR`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage bytes read (short float). Units in R7451UNT
"""
r7452pbr.__doc__ = """Physical storage bytes read (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7452PBR`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage bytes read (short float). Units in R7451UNT
"""

r7452pbw : Final[Field] = Field(
    name='r7452pbw',
    origin='R7452PBW',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Physical storage bytes written (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7452PBW`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage bytes written (short float). Units in R7451UNT
"""
r7452pbw.__doc__ = """Physical storage bytes written (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7452PBW`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage bytes written (short float). Units in R7451UNT
"""

r7451rmr : Final[Field] = Field(
    name='r7451rmr',
    origin='R7451RMR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Record mode read request (short float)

SMF Info
--------
    Field: `R7451RMR`
    Record: `SMF74S5`
    Map: `R7451DEV`

Record mode read request (short float)
"""
r7451rmr.__doc__ = """Record mode read request (short float)

SMF Info
--------
    Field: `R7451RMR`
    Record: `SMF74S5`
    Map: `R7451DEV`

Record mode read request (short float)
"""

r7451xsf : Final[Field] = Field(
    name='r7451xsf',
    origin='R7451XSF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""XRC or CC sidefile reads (short float)

SMF Info
--------
    Field: `R7451XSF`
    Record: `SMF74S5`
    Map: `R7451DEV`

XRC or CC sidefile reads (short float)
"""
r7451xsf.__doc__ = """XRC or CC sidefile reads (short float)

SMF Info
--------
    Field: `R7451XSF`
    Record: `SMF74S5`
    Map: `R7451DEV`

XRC or CC sidefile reads (short float)
"""

r7451xcw : Final[Field] = Field(
    name='r7451xcw',
    origin='R7451XCW',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""XRC or CC contaminated writes (short float)

SMF Info
--------
    Field: `R7451XCW`
    Record: `SMF74S5`
    Map: `R7451DEV`

XRC or CC contaminated writes (short float)
"""
r7451xcw.__doc__ = """XRC or CC contaminated writes (short float)

SMF Info
--------
    Field: `R7451XCW`
    Record: `SMF74S5`
    Map: `R7451DEV`

XRC or CC contaminated writes (short float)
"""

r7451tsp : Final[Field] = Field(
    name='r7451tsp',
    origin='R7451TSP',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Number of tracks transferred to secondary PPRC volume (short float)

SMF Info
--------
    Field: `R7451TSP`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of tracks transferred to secondary PPRC volume (short float)
"""
r7451tsp.__doc__ = """Number of tracks transferred to secondary PPRC volume (short float)

SMF Info
--------
    Field: `R7451TSP`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of tracks transferred to secondary PPRC volume (short float)
"""

r7451nvs : Final[Field] = Field(
    name='r7451nvs',
    origin='R7451NVS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""NVS space allocation (short float)

SMF Info
--------
    Field: `R7451NVS`
    Record: `SMF74S5`
    Map: `R7451DEV`

NVS space allocation (short float)
"""
r7451nvs.__doc__ = """NVS space allocation (short float)

SMF Info
--------
    Field: `R7451NVS`
    Record: `SMF74S5`
    Map: `R7451DEV`

NVS space allocation (short float)
"""

r7452prt : Final[Field] = Field(
    name='r7452prt',
    origin='R7452PRT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Physical storage read response time (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7452PRT`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage read response time (short float). Units in R7451UNT
"""
r7452prt.__doc__ = """Physical storage read response time (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7452PRT`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage read response time (short float). Units in R7451UNT
"""

r7452pwt : Final[Field] = Field(
    name='r7452pwt',
    origin='R7452PWT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Physical storage write response time (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7452PWT`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage write response time (short float). Units in R7451UNT
"""
r7452pwt.__doc__ = """Physical storage write response time (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7452PWT`
    Record: `SMF74S5`
    Map: `R7451DEV`

Physical storage write response time (short float). Units in R7451UNT
"""

r7451ct1 : Final[Field] = Field(
    name='r7451ct1',
    origin='R7451CT1',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Bytes read (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7451CT1`
    Record: `SMF74S5`
    Map: `R7451DEV`

Bytes read (short float). Units in R7451UNT
"""
r7451ct1.__doc__ = """Bytes read (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7451CT1`
    Record: `SMF74S5`
    Map: `R7451DEV`

Bytes read (short float). Units in R7451UNT
"""

r7451ct2 : Final[Field] = Field(
    name='r7451ct2',
    origin='R7451CT2',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Bytes written (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7451CT2`
    Record: `SMF74S5`
    Map: `R7451DEV`

Bytes written (short float). Units in R7451UNT
"""
r7451ct2.__doc__ = """Bytes written (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7451CT2`
    Record: `SMF74S5`
    Map: `R7451DEV`

Bytes written (short float). Units in R7451UNT
"""

r7451ct3 : Final[Field] = Field(
    name='r7451ct3',
    origin='R7451CT3',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Read response time (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7451CT3`
    Record: `SMF74S5`
    Map: `R7451DEV`

Read response time (short float). Units in R7451UNT
"""
r7451ct3.__doc__ = """Read response time (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7451CT3`
    Record: `SMF74S5`
    Map: `R7451DEV`

Read response time (short float). Units in R7451UNT
"""

r7451ct4 : Final[Field] = Field(
    name='r7451ct4',
    origin='R7451CT4',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Write response time (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7451CT4`
    Record: `SMF74S5`
    Map: `R7451DEV`

Write response time (short float). Units in R7451UNT
"""
r7451ct4.__doc__ = """Write response time (short float). Units in R7451UNT

SMF Info
--------
    Field: `R7451CT4`
    Record: `SMF74S5`
    Map: `R7451DEV`

Write response time (short float). Units in R7451UNT
"""

r7451ct5 : Final[Field] = Field(
    name='r7451ct5',
    origin='R7451CT5',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""z/HPF Read I/O requests (short float)

SMF Info
--------
    Field: `R7451CT5`
    Record: `SMF74S5`
    Map: `R7451DEV`

z/HPF Read I/O requests (short float)
"""
r7451ct5.__doc__ = """z/HPF Read I/O requests (short float)

SMF Info
--------
    Field: `R7451CT5`
    Record: `SMF74S5`
    Map: `R7451DEV`

z/HPF Read I/O requests (short float)
"""

r7451ct6 : Final[Field] = Field(
    name='r7451ct6',
    origin='R7451CT6',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""z/HPF Write I/O requests (short float)

SMF Info
--------
    Field: `R7451CT6`
    Record: `SMF74S5`
    Map: `R7451DEV`

z/HPF Write I/O requests (short float)
"""
r7451ct6.__doc__ = """z/HPF Write I/O requests (short float)

SMF Info
--------
    Field: `R7451CT6`
    Record: `SMF74S5`
    Map: `R7451DEV`

z/HPF Write I/O requests (short float)
"""

r7451zhl : Final[Field] = Field(
    name='r7451zhl',
    origin='R7451ZHL',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""zHPF List Pre-fetch I/O Requests. Number of command chains, where the Transport Mode operation specified a non-zero Imbedded Locate Record Count

SMF Info
--------
    Field: `R7451ZHL`
    Record: `SMF74S5`
    Map: `R7451DEV`

zHPF List Pre-fetch I/O Requests. Number of command chains, where the Transport Mode operation specified a non-zero Imbedded Locate Record Count
"""
r7451zhl.__doc__ = """zHPF List Pre-fetch I/O Requests. Number of command chains, where the Transport Mode operation specified a non-zero Imbedded Locate Record Count

SMF Info
--------
    Field: `R7451ZHL`
    Record: `SMF74S5`
    Map: `R7451DEV`

zHPF List Pre-fetch I/O Requests. Number of command chains, where the Transport Mode operation specified a non-zero Imbedded Locate Record Count
"""

r7451zhh : Final[Field] = Field(
    name='r7451zhh',
    origin='R7451ZHH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""zHPF List Pre-fetch I/O Request Hits. Number of command chains, where - the Transport Mode operation specified a non-zero Imbedded Locate Record Count. - the chain was completed without requiring access to any DDM.

SMF Info
--------
    Field: `R7451ZHH`
    Record: `SMF74S5`
    Map: `R7451DEV`

zHPF List Pre-fetch I/O Request Hits. Number of command chains, where - the Transport Mode operation specified a non-zero Imbedded Locate Record Count. - the chain was completed without requiring access to any DDM.
"""
r7451zhh.__doc__ = """zHPF List Pre-fetch I/O Request Hits. Number of command chains, where - the Transport Mode operation specified a non-zero Imbedded Locate Record Count. - the chain was completed without requiring access to any DDM.

SMF Info
--------
    Field: `R7451ZHH`
    Record: `SMF74S5`
    Map: `R7451DEV`

zHPF List Pre-fetch I/O Request Hits. Number of command chains, where - the Transport Mode operation specified a non-zero Imbedded Locate Record Count. - the chain was completed without requiring access to any DDM.
"""

r7451gsf : Final[Field] = Field(
    name='r7451gsf',
    origin='R7451GSF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Global Mirror Collisions (GMC) sidefile count (short float). A GMC occurs when, during the sending of data in the secondary to create a consistency group, a subsequent host update is attempted before the modified track has been transmitted to the secondary volume. The modified track will be moved to the sidefile before allowing a new host write. The counter will be incremented by one when a track is added to the sidefile.

SMF Info
--------
    Field: `R7451GSF`
    Record: `SMF74S5`
    Map: `R7451DEV`

Global Mirror Collisions (GMC) sidefile count (short float). A GMC occurs when, during the sending of data in the secondary to create a consistency group, a subsequent host update is attempted before the modified track has been transmitted to the secondary volume. The modified track will be moved to the sidefile before allowing a new host write. The counter will be incremented by one when a track is added to the sidefile.
"""
r7451gsf.__doc__ = """Global Mirror Collisions (GMC) sidefile count (short float). A GMC occurs when, during the sending of data in the secondary to create a consistency group, a subsequent host update is attempted before the modified track has been transmitted to the secondary volume. The modified track will be moved to the sidefile before allowing a new host write. The counter will be incremented by one when a track is added to the sidefile.

SMF Info
--------
    Field: `R7451GSF`
    Record: `SMF74S5`
    Map: `R7451DEV`

Global Mirror Collisions (GMC) sidefile count (short float). A GMC occurs when, during the sending of data in the secondary to create a consistency group, a subsequent host update is attempted before the modified track has been transmitted to the secondary volume. The modified track will be moved to the sidefile before allowing a new host write. The counter will be incremented by one when a track is added to the sidefile.
"""

r7451gss : Final[Field] = Field(
    name='r7451gss',
    origin='R7451GSS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Global Mirror Collisions Send synchronous count (short float). When a write collision occurs, the modified track data which belongs to the current consistency group may be sent to the remote control unit before allowing the write. The data may come from the sidefile if it is full or from cache if the collision sidefile is not being utilized.

SMF Info
--------
    Field: `R7451GSS`
    Record: `SMF74S5`
    Map: `R7451DEV`

Global Mirror Collisions Send synchronous count (short float). When a write collision occurs, the modified track data which belongs to the current consistency group may be sent to the remote control unit before allowing the write. The data may come from the sidefile if it is full or from cache if the collision sidefile is not being utilized.
"""
r7451gss.__doc__ = """Global Mirror Collisions Send synchronous count (short float). When a write collision occurs, the modified track data which belongs to the current consistency group may be sent to the remote control unit before allowing the write. The data may come from the sidefile if it is full or from cache if the collision sidefile is not being utilized.

SMF Info
--------
    Field: `R7451GSS`
    Record: `SMF74S5`
    Map: `R7451DEV`

Global Mirror Collisions Send synchronous count (short float). When a write collision occurs, the modified track data which belongs to the current consistency group may be sent to the remote control unit before allowing the write. The data may come from the sidefile if it is full or from cache if the collision sidefile is not being utilized.
"""

r7451srr : Final[Field] = Field(
    name='r7451srr',
    origin='R7451SRR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Number of synchronous I/O cache read requests. (Valid if bit 3 of R7451INC is set.)

SMF Info
--------
    Field: `R7451SRR`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of synchronous I/O cache read requests. (Valid if bit 3 of R7451INC is set.)
"""
r7451srr.__doc__ = """Number of synchronous I/O cache read requests. (Valid if bit 3 of R7451INC is set.)

SMF Info
--------
    Field: `R7451SRR`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of synchronous I/O cache read requests. (Valid if bit 3 of R7451INC is set.)
"""

r7451srh : Final[Field] = Field(
    name='r7451srh',
    origin='R7451SRH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Number of synchronous I/O cache read request hits. (Valid if bit 3 of R7451INC is set.)

SMF Info
--------
    Field: `R7451SRH`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of synchronous I/O cache read request hits. (Valid if bit 3 of R7451INC is set.)
"""
r7451srh.__doc__ = """Number of synchronous I/O cache read request hits. (Valid if bit 3 of R7451INC is set.)

SMF Info
--------
    Field: `R7451SRH`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of synchronous I/O cache read request hits. (Valid if bit 3 of R7451INC is set.)
"""

r7451swr : Final[Field] = Field(
    name='r7451swr',
    origin='R7451SWR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Number of synchronous I/O cache write requests. (Valid if bit 3 of R7451INC is set.)

SMF Info
--------
    Field: `R7451SWR`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of synchronous I/O cache write requests. (Valid if bit 3 of R7451INC is set.)
"""
r7451swr.__doc__ = """Number of synchronous I/O cache write requests. (Valid if bit 3 of R7451INC is set.)

SMF Info
--------
    Field: `R7451SWR`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of synchronous I/O cache write requests. (Valid if bit 3 of R7451INC is set.)
"""

r7451swh : Final[Field] = Field(
    name='r7451swh',
    origin='R7451SWH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7451DEV,
)
"""Number of synchronous I/O cache write request hits. (Valid if bit 3 of R7451INC is set.)

SMF Info
--------
    Field: `R7451SWH`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of synchronous I/O cache write request hits. (Valid if bit 3 of R7451INC is set.)
"""
r7451swh.__doc__ = """Number of synchronous I/O cache write request hits. (Valid if bit 3 of R7451INC is set.)

SMF Info
--------
    Field: `R7451SWH`
    Record: `SMF74S5`
    Map: `R7451DEV`

Number of synchronous I/O cache write request hits. (Valid if bit 3 of R7451INC is set.)
"""
