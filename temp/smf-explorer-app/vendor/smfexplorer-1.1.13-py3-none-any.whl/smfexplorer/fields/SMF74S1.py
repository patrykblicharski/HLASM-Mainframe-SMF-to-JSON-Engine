# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=1,
                                spec='SMF 74 Subtype 1',
                                post=None)
"""SMF 74 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
SMF74A: Final[RecordMap] = RecordMap(
    origin='SMF74A',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Device Control Data',
    post=None,
    record_mapping=False)
"""Device Control Data"""
SMF74B: Final[RecordMap] = RecordMap(
    origin='SMF74B',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Device Data',
    post=None,
    record_mapping=False)
"""Device Data"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S1`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S1`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S1`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S1`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

dcs : Final[Field] = Field(
    name='dcs',
    origin='SMF74DCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO DEVICE CNTL SECTION

SMF Info
--------
    Field: `SMF74DCS`
    Record: `SMF74S1`
    Map: Not part of a map

OFFSET TO DEVICE CNTL SECTION
"""
dcs.__doc__ = """OFFSET TO DEVICE CNTL SECTION

SMF Info
--------
    Field: `SMF74DCS`
    Record: `SMF74S1`
    Map: Not part of a map

OFFSET TO DEVICE CNTL SECTION
"""

dcl : Final[Field] = Field(
    name='dcl',
    origin='SMF74DCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DEVICE CNTL SECTION

SMF Info
--------
    Field: `SMF74DCL`
    Record: `SMF74S1`
    Map: Not part of a map

LENGTH OF DEVICE CNTL SECTION
"""
dcl.__doc__ = """LENGTH OF DEVICE CNTL SECTION

SMF Info
--------
    Field: `SMF74DCL`
    Record: `SMF74S1`
    Map: Not part of a map

LENGTH OF DEVICE CNTL SECTION
"""

dcn : Final[Field] = Field(
    name='dcn',
    origin='SMF74DCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DEVICE CNTL SECTIONS

SMF Info
--------
    Field: `SMF74DCN`
    Record: `SMF74S1`
    Map: Not part of a map

NUMBER OF DEVICE CNTL SECTIONS
"""
dcn.__doc__ = """NUMBER OF DEVICE CNTL SECTIONS

SMF Info
--------
    Field: `SMF74DCN`
    Record: `SMF74S1`
    Map: Not part of a map

NUMBER OF DEVICE CNTL SECTIONS
"""

dds : Final[Field] = Field(
    name='dds',
    origin='SMF74DDS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO DEVICE DATA SECTION

SMF Info
--------
    Field: `SMF74DDS`
    Record: `SMF74S1`
    Map: Not part of a map

OFFSET TO DEVICE DATA SECTION
"""
dds.__doc__ = """OFFSET TO DEVICE DATA SECTION

SMF Info
--------
    Field: `SMF74DDS`
    Record: `SMF74S1`
    Map: Not part of a map

OFFSET TO DEVICE DATA SECTION
"""

ddl : Final[Field] = Field(
    name='ddl',
    origin='SMF74DDL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF DEVICE DATA SECTION

SMF Info
--------
    Field: `SMF74DDL`
    Record: `SMF74S1`
    Map: Not part of a map

LENGTH OF DEVICE DATA SECTION
"""
ddl.__doc__ = """LENGTH OF DEVICE DATA SECTION

SMF Info
--------
    Field: `SMF74DDL`
    Record: `SMF74S1`
    Map: Not part of a map

LENGTH OF DEVICE DATA SECTION
"""

ddn : Final[Field] = Field(
    name='ddn',
    origin='SMF74DDN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF DEVICE DATA SECTIONS

SMF Info
--------
    Field: `SMF74DDN`
    Record: `SMF74S1`
    Map: Not part of a map

NUMBER OF DEVICE DATA SECTIONS
"""
ddn.__doc__ = """NUMBER OF DEVICE DATA SECTIONS

SMF Info
--------
    Field: `SMF74DDN`
    Record: `SMF74S1`
    Map: Not part of a map

NUMBER OF DEVICE DATA SECTIONS
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S1`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S1`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S1`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S1`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S1`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S1`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S1`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S1`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S1`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S1`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S1`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S1`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S1`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S1`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

nxt : Final[Field] = Field(
    name='nxt',
    origin='SMF74NXT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74A,
)
"""NUMBER OF DEVICE DATA SECTIONS IN FOLLOWING BROKEN RECORDS FOR THIS LOGICAL DEVICE CLASS RECORD

SMF Info
--------
    Field: `SMF74NXT`
    Record: `SMF74S1`
    Map: `SMF74A`

NUMBER OF DEVICE DATA SECTIONS IN FOLLOWING BROKEN RECORDS FOR THIS LOGICAL DEVICE CLASS RECORD
"""
nxt.__doc__ = """NUMBER OF DEVICE DATA SECTIONS IN FOLLOWING BROKEN RECORDS FOR THIS LOGICAL DEVICE CLASS RECORD

SMF Info
--------
    Field: `SMF74NXT`
    Record: `SMF74S1`
    Map: `SMF74A`

NUMBER OF DEVICE DATA SECTIONS IN FOLLOWING BROKEN RECORDS FOR THIS LOGICAL DEVICE CLASS RECORD
"""

tot : Final[Field] = Field(
    name='tot',
    origin='SMF74TOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74A,
)
"""NUMBER OF DEVICE DATA SECTIONS IN ALL RECORDS FOR THIS LOGICAL DEVICE CLASS RECORD

SMF Info
--------
    Field: `SMF74TOT`
    Record: `SMF74S1`
    Map: `SMF74A`

NUMBER OF DEVICE DATA SECTIONS IN ALL RECORDS FOR THIS LOGICAL DEVICE CLASS RECORD
"""
tot.__doc__ = """NUMBER OF DEVICE DATA SECTIONS IN ALL RECORDS FOR THIS LOGICAL DEVICE CLASS RECORD

SMF Info
--------
    Field: `SMF74TOT`
    Record: `SMF74S1`
    Map: `SMF74A`

NUMBER OF DEVICE DATA SECTIONS IN ALL RECORDS FOR THIS LOGICAL DEVICE CLASS RECORD
"""

gen : Final[Field] = Field(
    name='gen',
    origin='SMF74GEN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74A,
)
"""TOTAL NUMBER OF DEVICES SYSGENED FOR ALL CLASSES

SMF Info
--------
    Field: `SMF74GEN`
    Record: `SMF74S1`
    Map: `SMF74A`

TOTAL NUMBER OF DEVICES SYSGENED FOR ALL CLASSES
"""
gen.__doc__ = """TOTAL NUMBER OF DEVICES SYSGENED FOR ALL CLASSES

SMF Info
--------
    Field: `SMF74GEN`
    Record: `SMF74S1`
    Map: `SMF74A`

TOTAL NUMBER OF DEVICES SYSGENED FOR ALL CLASSES
"""

sub : Final[Field] = Field(
    name='sub',
    origin='SMF74SUB',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""UCB DEV TYPE CODE IN RIGHT BYTE

SMF Info
--------
    Field: `SMF74SUB`
    Record: `SMF74S1`
    Map: `SMF74A`

UCB DEV TYPE CODE IN RIGHT BYTE
"""
sub.__doc__ = """UCB DEV TYPE CODE IN RIGHT BYTE

SMF Info
--------
    Field: `SMF74SUB`
    Record: `SMF74S1`
    Map: `SMF74A`

UCB DEV TYPE CODE IN RIGHT BYTE
"""

dcf : Final[Field] = Field(
    name='dcf',
    origin='SMF74DCF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""Flags for DASD class

SMF Info
--------
    Field: `SMF74DCF`
    Record: `SMF74S1`
    Map: `SMF74A`

Flags for DASD class
"""
dcf.__doc__ = """Flags for DASD class

SMF Info
--------
    Field: `SMF74DCF`
    Record: `SMF74S1`
    Map: `SMF74A`

Flags for DASD class
"""

nrf : Final[Field] = Field(
    name='nrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=dcf,
    record=record,
    record_map=SMF74A,
)
"""Flag to cause two report areas(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dcf`(`SMF74DCF`)
    Record: `SMF74S1`
    Map: `SMF74A`

Flag to cause two report areas

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
nrf.__doc__ = """Flag to cause two report areas(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dcf`(`SMF74DCF`)
    Record: `SMF74S1`
    Map: `SMF74A`

Flag to cause two report areas

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sgf : Final[Field] = Field(
    name='sgf',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=dcf,
    record=record,
    record_map=SMF74A,
)
"""Flag to cause sort by SG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dcf`(`SMF74DCF`)
    Record: `SMF74S1`
    Map: `SMF74A`

Flag to cause sort by SG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sgf.__doc__ = """Flag to cause sort by SG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dcf`(`SMF74DCF`)
    Record: `SMF74S1`
    Map: `SMF74A`

Flag to cause sort by SG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

dms : Final[Field] = Field(
    name='dms',
    origin='SMF74DMS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""Message flags

SMF Info
--------
    Field: `SMF74DMS`
    Record: `SMF74S1`
    Map: `SMF74A`

Message flags
"""
dms.__doc__ = """Message flags

SMF Info
--------
    Field: `SMF74DMS`
    Record: `SMF74S1`
    Map: `SMF74A`

Message flags
"""

_429 : Final[Field] = Field(
    name='_429',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=dms,
    record=record,
    record_map=SMF74A,
)
"""Message ERB429I(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dms`(`SMF74DMS`)
    Record: `SMF74S1`
    Map: `SMF74A`

Message ERB429I

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
_429.__doc__ = """Message ERB429I(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dms`(`SMF74DMS`)
    Record: `SMF74S1`
    Map: `SMF74A`

Message ERB429I

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sme : Final[Field] = Field(
    name='sme',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=dms,
    record=record,
    record_map=SMF74A,
)
"""SMS Interface Error(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dms`(`SMF74DMS`)
    Record: `SMF74S1`
    Map: `SMF74A`

SMS Interface Error

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sme.__doc__ = """SMS Interface Error(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dms`(`SMF74DMS`)
    Record: `SMF74S1`
    Map: `SMF74A`

SMS Interface Error

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

enf : Final[Field] = Field(
    name='enf',
    origin='SMF74ENF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""Flags

SMF Info
--------
    Field: `SMF74ENF`
    Record: `SMF74S1`
    Map: `SMF74A`

Flags
"""
enf.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74ENF`
    Record: `SMF74S1`
    Map: `SMF74A`

Flags
"""

ecm : Final[Field] = Field(
    name='ecm',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=enf,
    record=record,
    record_map=SMF74A,
)
"""On = extended CMB(V)

SMF Info (Virtual Field)
--------
    Field: Based on `enf`(`SMF74ENF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = extended CMB

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
ecm.__doc__ = """On = extended CMB(V)

SMF Info (Virtual Field)
--------
    Field: Based on `enf`(`SMF74ENF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = extended CMB

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sts : Final[Field] = Field(
    name='sts',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=enf,
    record=record,
    record_map=SMF74A,
)
"""On = model dependent data not available by STSCH(V)

SMF Info (Virtual Field)
--------
    Field: Based on `enf`(`SMF74ENF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = model dependent data not available by STSCH

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sts.__doc__ = """On = model dependent data not available by STSCH(V)

SMF Info (Virtual Field)
--------
    Field: Based on `enf`(`SMF74ENF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = model dependent data not available by STSCH

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

fcm : Final[Field] = Field(
    name='fcm',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=enf,
    record=record,
    record_map=SMF74A,
)
"""On = initial command response time valid (SMF74CMR)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `enf`(`SMF74ENF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = initial command response time valid (SMF74CMR)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
fcm.__doc__ = """On = initial command response time valid (SMF74CMR)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `enf`(`SMF74ENF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = initial command response time valid (SMF74CMR)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

fid : Final[Field] = Field(
    name='fid',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=enf,
    record=record,
    record_map=SMF74A,
)
"""On = interrupt delay time valid (SMF74IDT)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `enf`(`SMF74ENF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = interrupt delay time valid (SMF74IDT)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
fid.__doc__ = """On = interrupt delay time valid (SMF74IDT)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `enf`(`SMF74ENF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = interrupt delay time valid (SMF74IDT)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

smf : Final[Field] = Field(
    name='smf',
    origin='SMF74SMF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""Logical SMF record flag

SMF Info
--------
    Field: `SMF74SMF`
    Record: `SMF74S1`
    Map: `SMF74A`

Logical SMF record flag
"""
smf.__doc__ = """Logical SMF record flag

SMF Info
--------
    Field: `SMF74SMF`
    Record: `SMF74S1`
    Map: `SMF74A`

Logical SMF record flag
"""

msm : Final[Field] = Field(
    name='msm',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=smf,
    record=record,
    record_map=SMF74A,
)
"""On = There are more logical SMF records in device class(V)

SMF Info (Virtual Field)
--------
    Field: Based on `smf`(`SMF74SMF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = There are more logical SMF records in device class

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
msm.__doc__ = """On = There are more logical SMF records in device class(V)

SMF Info (Virtual Field)
--------
    Field: Based on `smf`(`SMF74SMF`)
    Record: `SMF74S1`
    Map: `SMF74A`

On = There are more logical SMF records in device class

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

s15 : Final[Field] = Field(
    name='s15',
    origin='SMF74S15',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74A,
)
"""Reg 15 after SMS interface call (SSI RC)

SMF Info
--------
    Field: `SMF74S15`
    Record: `SMF74S1`
    Map: `SMF74A`

Reg 15 after SMS interface call (SSI RC)
"""
s15.__doc__ = """Reg 15 after SMS interface call (SSI RC)

SMF Info
--------
    Field: `SMF74S15`
    Record: `SMF74S1`
    Map: `SMF74A`

Reg 15 after SMS interface call (SSI RC)
"""

src : Final[Field] = Field(
    name='src',
    origin='SMF74SRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74A,
)
"""Return code from SMS interface (SSOB RC)

SMF Info
--------
    Field: `SMF74SRC`
    Record: `SMF74S1`
    Map: `SMF74A`

Return code from SMS interface (SSOB RC)
"""
src.__doc__ = """Return code from SMS interface (SSOB RC)

SMF Info
--------
    Field: `SMF74SRC`
    Record: `SMF74S1`
    Map: `SMF74A`

Return code from SMS interface (SSOB RC)
"""

srs : Final[Field] = Field(
    name='srs',
    origin='SMF74SRS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74A,
)
"""Reason code from SMS interface (SSOB RS)

SMF Info
--------
    Field: `SMF74SRS`
    Record: `SMF74S1`
    Map: `SMF74A`

Reason code from SMS interface (SSOB RS)
"""
srs.__doc__ = """Reason code from SMS interface (SSOB RS)

SMF Info
--------
    Field: `SMF74SRS`
    Record: `SMF74S1`
    Map: `SMF74A`

Reason code from SMS interface (SSOB RS)
"""

tsr : Final[Field] = Field(
    name='tsr',
    origin='SMF74TSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74A,
)
"""Number of small records written during interval

SMF Info
--------
    Field: `SMF74TSR`
    Record: `SMF74S1`
    Map: `SMF74A`

Number of small records written during interval
"""
tsr.__doc__ = """Number of small records written during interval

SMF Info
--------
    Field: `SMF74TSR`
    Record: `SMF74S1`
    Map: `SMF74A`

Number of small records written during interval
"""

cfl : Final[Field] = Field(
    name='cfl',
    origin='SMF74CFL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""Configuration Change Flags

SMF Info
--------
    Field: `SMF74CFL`
    Record: `SMF74S1`
    Map: `SMF74A`

Configuration Change Flags
"""
cfl.__doc__ = """Configuration Change Flags

SMF Info
--------
    Field: `SMF74CFL`
    Record: `SMF74S1`
    Map: `SMF74A`

Configuration Change Flags
"""

dca : Final[Field] = Field(
    name='dca',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF74A,
)
"""Configuration Changed this interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF74CFL`)
    Record: `SMF74S1`
    Map: `SMF74A`

Configuration Changed this interval.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
dca.__doc__ = """Configuration Changed this interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF74CFL`)
    Record: `SMF74S1`
    Map: `SMF74A`

Configuration Changed this interval.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iac : Final[Field] = Field(
    name='iac',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF74A,
)
"""Configuration Changed since last IPL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF74CFL`)
    Record: `SMF74S1`
    Map: `SMF74A`

Configuration Changed since last IPL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iac.__doc__ = """Configuration Changed since last IPL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF74CFL`)
    Record: `SMF74S1`
    Map: `SMF74A`

Configuration Changed since last IPL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

iod : Final[Field] = Field(
    name='iod',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF74A,
)
"""System IPLed via IODF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF74CFL`)
    Record: `SMF74S1`
    Map: `SMF74A`

System IPLed via IODF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
iod.__doc__ = """System IPLed via IODF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF74CFL`)
    Record: `SMF74S1`
    Map: `SMF74A`

System IPLed via IODF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

icv : Final[Field] = Field(
    name='icv',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=cfl,
    record=record,
    record_map=SMF74A,
)
"""I/O Configuration Token is valid.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF74CFL`)
    Record: `SMF74S1`
    Map: `SMF74A`

I/O Configuration Token is valid.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
icv.__doc__ = """I/O Configuration Token is valid.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cfl`(`SMF74CFL`)
    Record: `SMF74S1`
    Map: `SMF74A`

I/O Configuration Token is valid.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

lsn : Final[Field] = Field(
    name='lsn',
    origin='SMF74LSN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74A,
)
"""Logical SMF record sequence number for device class

SMF Info
--------
    Field: `SMF74LSN`
    Record: `SMF74S1`
    Map: `SMF74A`

Logical SMF record sequence number for device class
"""
lsn.__doc__ = """Logical SMF record sequence number for device class

SMF Info
--------
    Field: `SMF74LSN`
    Record: `SMF74S1`
    Map: `SMF74A`

Logical SMF record sequence number for device class
"""

tnm : Final[Field] = Field(
    name='tnm',
    origin='SMF74TNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""IODF Name

SMF Info
--------
    Field: `SMF74TNM`
    Record: `SMF74S1`
    Map: `SMF74A`

IODF Name
"""
tnm.__doc__ = """IODF Name

SMF Info
--------
    Field: `SMF74TNM`
    Record: `SMF74S1`
    Map: `SMF74A`

IODF Name
"""

tsf : Final[Field] = Field(
    name='tsf',
    origin='SMF74TSF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""Suffix of IODF Name

SMF Info
--------
    Field: `SMF74TSF`
    Record: `SMF74S1`
    Map: `SMF74A`

Suffix of IODF Name
"""
tsf.__doc__ = """Suffix of IODF Name

SMF Info
--------
    Field: `SMF74TSF`
    Record: `SMF74S1`
    Map: `SMF74A`

Suffix of IODF Name
"""

tdt : Final[Field] = Field(
    name='tdt',
    origin='SMF74TDT',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""IODF creation date mm/dd/yy

SMF Info
--------
    Field: `SMF74TDT`
    Record: `SMF74S1`
    Map: `SMF74A`

IODF creation date mm/dd/yy
"""
tdt.__doc__ = """IODF creation date mm/dd/yy

SMF Info
--------
    Field: `SMF74TDT`
    Record: `SMF74S1`
    Map: `SMF74A`

IODF creation date mm/dd/yy
"""

ttm : Final[Field] = Field(
    name='ttm',
    origin='SMF74TTM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""IODF creation time hh.mm.ss

SMF Info
--------
    Field: `SMF74TTM`
    Record: `SMF74S1`
    Map: `SMF74A`

IODF creation time hh.mm.ss
"""
ttm.__doc__ = """IODF creation time hh.mm.ss

SMF Info
--------
    Field: `SMF74TTM`
    Record: `SMF74S1`
    Map: `SMF74A`

IODF creation time hh.mm.ss
"""

mct : Final[Field] = Field(
    name='mct',
    origin='SMF74MCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74A,
)
"""Maximum number of allocated tape devices

SMF Info
--------
    Field: `SMF74MCT`
    Record: `SMF74S1`
    Map: `SMF74A`

Maximum number of allocated tape devices
"""
mct.__doc__ = """Maximum number of allocated tape devices

SMF Info
--------
    Field: `SMF74MCT`
    Record: `SMF74S1`
    Map: `SMF74A`

Maximum number of allocated tape devices
"""

tdy : Final[Field] = Field(
    name='tdy',
    origin='SMF74TDY',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""IODF creation date mm/dd/yyyy

SMF Info
--------
    Field: `SMF74TDY`
    Record: `SMF74S1`
    Map: `SMF74A`

IODF creation date mm/dd/yyyy
"""
tdy.__doc__ = """IODF creation date mm/dd/yyyy

SMF Info
--------
    Field: `SMF74TDY`
    Record: `SMF74S1`
    Map: `SMF74A`

IODF creation date mm/dd/yyyy
"""

tok : Final[Field] = Field(
    name='tok',
    origin='SMF74TOK',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74A,
)
"""Configuration token

SMF Info
--------
    Field: `SMF74TOK`
    Record: `SMF74S1`
    Map: `SMF74A`

Configuration token
"""
tok.__doc__ = """Configuration token

SMF Info
--------
    Field: `SMF74TOK`
    Record: `SMF74S1`
    Map: `SMF74A`

Configuration token
"""

num : Final[Field] = Field(
    name='num',
    origin='SMF74NUM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""DEVICE NUMBER

SMF Info
--------
    Field: `SMF74NUM`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE NUMBER
"""
num.__doc__ = """DEVICE NUMBER

SMF Info
--------
    Field: `SMF74NUM`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE NUMBER
"""

lcu : Final[Field] = Field(
    name='lcu',
    origin='SMF74LCU',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""LOGICAL CONTROL UNIT NUMBER

SMF Info
--------
    Field: `SMF74LCU`
    Record: `SMF74S1`
    Map: `SMF74B`

LOGICAL CONTROL UNIT NUMBER
"""
lcu.__doc__ = """LOGICAL CONTROL UNIT NUMBER

SMF Info
--------
    Field: `SMF74LCU`
    Record: `SMF74S1`
    Map: `SMF74B`

LOGICAL CONTROL UNIT NUMBER
"""

cnf : Final[Field] = Field(
    name='cnf',
    origin='SMF74CNF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""DEVICE FLAGS

SMF Info
--------
    Field: `SMF74CNF`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE FLAGS
"""
cnf.__doc__ = """DEVICE FLAGS

SMF Info
--------
    Field: `SMF74CNF`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE FLAGS
"""

lcd : Final[Field] = Field(
    name='lcd',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF74B,
)
"""=1 IF NO LCU DATA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 IF NO LCU DATA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
lcd.__doc__ = """=1 IF NO LCU DATA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 IF NO LCU DATA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

cmb : Final[Field] = Field(
    name='cmb',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF74B,
)
"""=1 IF CMB DATA INVALID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 IF CMB DATA INVALID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
cmb.__doc__ = """=1 IF CMB DATA INVALID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 IF CMB DATA INVALID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

del_ : Final[Field] = Field(
    name='del_',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF74B,
)
"""=1 Device has been deleted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device has been deleted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
del_.__doc__ = """=1 Device has been deleted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device has been deleted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

par : Final[Field] = Field(
    name='par',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF74B,
)
"""=1 ONLY PARTIAL STATISTICS AVAILABLE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 ONLY PARTIAL STATISTICS AVAILABLE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
par.__doc__ = """=1 ONLY PARTIAL STATISTICS AVAILABLE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 ONLY PARTIAL STATISTICS AVAILABLE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vac : Final[Field] = Field(
    name='vac',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF74B,
)
"""DATA INVALID, VARIED ON OR OFF, OR DYNAMIC RECONFIGURATION(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

DATA INVALID, VARIED ON OR OFF, OR DYNAMIC RECONFIGURATION

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
vac.__doc__ = """DATA INVALID, VARIED ON OR OFF, OR DYNAMIC RECONFIGURATION(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

DATA INVALID, VARIED ON OR OFF, OR DYNAMIC RECONFIGURATION

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

sta : Final[Field] = Field(
    name='sta',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF74B,
)
"""=1 at interval end online or offline devices indicated to be monitored(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 at interval end online or offline devices indicated to be monitored

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
sta.__doc__ = """=1 at interval end online or offline devices indicated to be monitored(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF74CNF`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 at interval end online or offline devices indicated to be monitored

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ser : Final[Field] = Field(
    name='ser',
    origin='SMF74SER',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""VOLUME SERIAL NUMBER OF MOUNTED VOLUME

SMF Info
--------
    Field: `SMF74SER`
    Record: `SMF74S1`
    Map: `SMF74B`

VOLUME SERIAL NUMBER OF MOUNTED VOLUME
"""
ser.__doc__ = """VOLUME SERIAL NUMBER OF MOUNTED VOLUME

SMF Info
--------
    Field: `SMF74SER`
    Record: `SMF74S1`
    Map: `SMF74B`

VOLUME SERIAL NUMBER OF MOUNTED VOLUME
"""

typ : Final[Field] = Field(
    name='typ',
    origin='SMF74TYP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""UNIT TYPE FROM UCBTYP FIELD

SMF Info
--------
    Field: `SMF74TYP`
    Record: `SMF74S1`
    Map: `SMF74B`

UNIT TYPE FROM UCBTYP FIELD
"""
typ.__doc__ = """UNIT TYPE FROM UCBTYP FIELD

SMF Info
--------
    Field: `SMF74TYP`
    Record: `SMF74S1`
    Map: `SMF74B`

UNIT TYPE FROM UCBTYP FIELD
"""

nux : Final[Field] = Field(
    name='nux',
    origin='SMF74NUX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Number of exposures, if multiple exposure device. In case of HyperPAV base device, SMF74HPV = 1, number of accumulated HyperPAV aliases

SMF Info
--------
    Field: `SMF74NUX`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of exposures, if multiple exposure device. In case of HyperPAV base device, SMF74HPV = 1, number of accumulated HyperPAV aliases
"""
nux.__doc__ = """Number of exposures, if multiple exposure device. In case of HyperPAV base device, SMF74HPV = 1, number of accumulated HyperPAV aliases

SMF Info
--------
    Field: `SMF74NUX`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of exposures, if multiple exposure device. In case of HyperPAV base device, SMF74HPV = 1, number of accumulated HyperPAV aliases
"""

ssc : Final[Field] = Field(
    name='ssc',
    origin='SMF74SSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""START SUBCHANNEL (SSCH) COUNT

SMF Info
--------
    Field: `SMF74SSC`
    Record: `SMF74S1`
    Map: `SMF74B`

START SUBCHANNEL (SSCH) COUNT
"""
ssc.__doc__ = """START SUBCHANNEL (SSCH) COUNT

SMF Info
--------
    Field: `SMF74SSC`
    Record: `SMF74S1`
    Map: `SMF74B`

START SUBCHANNEL (SSCH) COUNT
"""

mec : Final[Field] = Field(
    name='mec',
    origin='SMF74MEC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""MEASUREMENT EVENT COUNT (NUMBER OF SSCH FOR WHICH CONNECT, PENDING, AND ACTIVE TIME WERE STORED

SMF Info
--------
    Field: `SMF74MEC`
    Record: `SMF74S1`
    Map: `SMF74B`

MEASUREMENT EVENT COUNT (NUMBER OF SSCH FOR WHICH CONNECT, PENDING, AND ACTIVE TIME WERE STORED
"""
mec.__doc__ = """MEASUREMENT EVENT COUNT (NUMBER OF SSCH FOR WHICH CONNECT, PENDING, AND ACTIVE TIME WERE STORED

SMF Info
--------
    Field: `SMF74MEC`
    Record: `SMF74S1`
    Map: `SMF74B`

MEASUREMENT EVENT COUNT (NUMBER OF SSCH FOR WHICH CONNECT, PENDING, AND ACTIVE TIME WERE STORED
"""

cnn : Final[Field] = Field(
    name='cnn',
    origin='SMF74CNN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""DEVICE CONNECT TIME

SMF Info
--------
    Field: `SMF74CNN`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE CONNECT TIME
"""
cnn.__doc__ = """DEVICE CONNECT TIME

SMF Info
--------
    Field: `SMF74CNN`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE CONNECT TIME
"""

pen : Final[Field] = Field(
    name='pen',
    origin='SMF74PEN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""DEVICE PENDING TIME

SMF Info
--------
    Field: `SMF74PEN`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE PENDING TIME
"""
pen.__doc__ = """DEVICE PENDING TIME

SMF Info
--------
    Field: `SMF74PEN`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE PENDING TIME
"""

atv : Final[Field] = Field(
    name='atv',
    origin='SMF74ATV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""DEVICE ACTIVE TIME

SMF Info
--------
    Field: `SMF74ATV`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE ACTIVE TIME
"""
atv.__doc__ = """DEVICE ACTIVE TIME

SMF Info
--------
    Field: `SMF74ATV`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE ACTIVE TIME
"""

dis : Final[Field] = Field(
    name='dis',
    origin='SMF74DIS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""DEVICE DISCONNECT TIME

SMF Info
--------
    Field: `SMF74DIS`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE DISCONNECT TIME
"""
dis.__doc__ = """DEVICE DISCONNECT TIME

SMF Info
--------
    Field: `SMF74DIS`
    Record: `SMF74S1`
    Map: `SMF74B`

DEVICE DISCONNECT TIME
"""

que : Final[Field] = Field(
    name='que',
    origin='SMF74QUE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""NUMBER OF REQUESTS QUEUED IN IOS FOR THIS DEVICE

SMF Info
--------
    Field: `SMF74QUE`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF REQUESTS QUEUED IN IOS FOR THIS DEVICE
"""
que.__doc__ = """NUMBER OF REQUESTS QUEUED IN IOS FOR THIS DEVICE

SMF Info
--------
    Field: `SMF74QUE`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF REQUESTS QUEUED IN IOS FOR THIS DEVICE
"""

utl : Final[Field] = Field(
    name='utl',
    origin='SMF74UTL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""NUMBER OF SAMPLES WHEN THE DEVICE WAS RESERVED, BUT AN SSCH HAD NOT BEEN ISSUED

SMF Info
--------
    Field: `SMF74UTL`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES WHEN THE DEVICE WAS RESERVED, BUT AN SSCH HAD NOT BEEN ISSUED
"""
utl.__doc__ = """NUMBER OF SAMPLES WHEN THE DEVICE WAS RESERVED, BUT AN SSCH HAD NOT BEEN ISSUED

SMF Info
--------
    Field: `SMF74UTL`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES WHEN THE DEVICE WAS RESERVED, BUT AN SSCH HAD NOT BEEN ISSUED
"""

rsv : Final[Field] = Field(
    name='rsv',
    origin='SMF74RSV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS RESERVED

SMF Info
--------
    Field: `SMF74RSV`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS RESERVED
"""
rsv.__doc__ = """NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS RESERVED

SMF Info
--------
    Field: `SMF74RSV`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS RESERVED
"""

alc : Final[Field] = Field(
    name='alc',
    origin='SMF74ALC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS ALLOCATED

SMF Info
--------
    Field: `SMF74ALC`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS ALLOCATED
"""
alc.__doc__ = """NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS ALLOCATED

SMF Info
--------
    Field: `SMF74ALC`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS ALLOCATED
"""

mtp : Final[Field] = Field(
    name='mtp',
    origin='SMF74MTP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED A MOUNT PENDING CONDITION

SMF Info
--------
    Field: `SMF74MTP`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED A MOUNT PENDING CONDITION
"""
mtp.__doc__ = """NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED A MOUNT PENDING CONDITION

SMF Info
--------
    Field: `SMF74MTP`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED A MOUNT PENDING CONDITION
"""

nrd : Final[Field] = Field(
    name='nrd',
    origin='SMF74NRD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS NOT READY

SMF Info
--------
    Field: `SMF74NRD`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS NOT READY
"""
nrd.__doc__ = """NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS NOT READY

SMF Info
--------
    Field: `SMF74NRD`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF SAMPLES DURING THE INTERVAL THAT INDICATED THAT THE DEVICE WAS NOT READY
"""

cof : Final[Field] = Field(
    name='cof',
    origin='SMF74COF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""NUMBER OF REQUESTS THAT HAD CONNECT TIME OVERFLOW

SMF Info
--------
    Field: `SMF74COF`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF REQUESTS THAT HAD CONNECT TIME OVERFLOW
"""
cof.__doc__ = """NUMBER OF REQUESTS THAT HAD CONNECT TIME OVERFLOW

SMF Info
--------
    Field: `SMF74COF`
    Record: `SMF74S1`
    Map: `SMF74B`

NUMBER OF REQUESTS THAT HAD CONNECT TIME OVERFLOW
"""

dvb : Final[Field] = Field(
    name='dvb',
    origin='SMF74DVB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""device busy delay time

SMF Info
--------
    Field: `SMF74DVB`
    Record: `SMF74S1`
    Map: `SMF74B`

device busy delay time
"""
dvb.__doc__ = """device busy delay time

SMF Info
--------
    Field: `SMF74DVB`
    Record: `SMF74S1`
    Map: `SMF74B`

device busy delay time
"""

clf : Final[Field] = Field(
    name='clf',
    origin='SMF74CLF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""Flags for each device class

SMF Info
--------
    Field: `SMF74CLF`
    Record: `SMF74S1`
    Map: `SMF74B`

Flags for each device class
"""
clf.__doc__ = """Flags for each device class

SMF Info
--------
    Field: `SMF74CLF`
    Record: `SMF74S1`
    Map: `SMF74B`

Flags for each device class
"""

rnr : Final[Field] = Field(
    name='rnr',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=clf,
    record=record,
    record_map=SMF74B,
)
"""Flag number option active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Flag number option active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rnr.__doc__ = """Flag number option active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Flag number option active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

rsg : Final[Field] = Field(
    name='rsg',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=clf,
    record=record,
    record_map=SMF74B,
)
"""Flag SG option active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Flag SG option active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
rsg.__doc__ = """Flag SG option active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Flag SG option active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rcs : Final[Field] = Field(
    name='rcs',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=clf,
    record=record,
    record_map=SMF74B,
)
"""Flag for SG name changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Flag for SG name changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
rcs.__doc__ = """Flag for SG name changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Flag for SG name changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

mts : Final[Field] = Field(
    name='mts',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=clf,
    record=record,
    record_map=SMF74B,
)
"""Open mount at interval start(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Open mount at interval start

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
mts.__doc__ = """Open mount at interval start(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Open mount at interval start

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

mte : Final[Field] = Field(
    name='mte',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=clf,
    record=record,
    record_map=SMF74B,
)
"""Open mount at interval end(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Open mount at interval end

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
mte.__doc__ = """Open mount at interval end(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

Open mount at interval end

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

clw : Final[Field] = Field(
    name='clw',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=clf,
    record=record,
    record_map=SMF74B,
)
"""CTC with special protocol(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

CTC with special protocol

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
clw.__doc__ = """CTC with special protocol(V)

SMF Info (Virtual Field)
--------
    Field: Based on `clf`(`SMF74CLF`)
    Record: `SMF74S1`
    Map: `SMF74B`

CTC with special protocol

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

sgn : Final[Field] = Field(
    name='sgn',
    origin='SMF74SGN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""Storage Group Name

SMF Info
--------
    Field: `SMF74SGN`
    Record: `SMF74S1`
    Map: `SMF74B`

Storage Group Name
"""
sgn.__doc__ = """Storage Group Name

SMF Info
--------
    Field: `SMF74SGN`
    Record: `SMF74S1`
    Map: `SMF74B`

Storage Group Name
"""

nda : Final[Field] = Field(
    name='nda',
    origin='SMF74NDA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Total number of allocations in effect for the device

SMF Info
--------
    Field: `SMF74NDA`
    Record: `SMF74S1`
    Map: `SMF74B`

Total number of allocations in effect for the device
"""
nda.__doc__ = """Total number of allocations in effect for the device

SMF Info
--------
    Field: `SMF74NDA`
    Record: `SMF74S1`
    Map: `SMF74B`

Total number of allocations in effect for the device
"""

dev : Final[Field] = Field(
    name='dev',
    origin='SMF74DEV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""Device name

SMF Info
--------
    Field: `SMF74DEV`
    Record: `SMF74S1`
    Map: `SMF74B`

Device name
"""
dev.__doc__ = """Device name

SMF Info
--------
    Field: `SMF74DEV`
    Record: `SMF74S1`
    Map: `SMF74B`

Device name
"""

cu : Final[Field] = Field(
    name='cu',
    origin='SMF74CU',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""Control unit name

SMF Info
--------
    Field: `SMF74CU`
    Record: `SMF74S1`
    Map: `SMF74B`

Control unit name
"""
cu.__doc__ = """Control unit name

SMF Info
--------
    Field: `SMF74CU`
    Record: `SMF74S1`
    Map: `SMF74B`

Control unit name
"""

cnx : Final[Field] = Field(
    name='cnx',
    origin='SMF74CNX',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""Device Flag Extension see also SMF74CNF above

SMF Info
--------
    Field: `SMF74CNX`
    Record: `SMF74S1`
    Map: `SMF74B`

Device Flag Extension see also SMF74CNF above
"""
cnx.__doc__ = """Device Flag Extension see also SMF74CNF above

SMF Info
--------
    Field: `SMF74CNX`
    Record: `SMF74S1`
    Map: `SMF74B`

Device Flag Extension see also SMF74CNF above
"""

dyc : Final[Field] = Field(
    name='dyc',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=cnx,
    record=record,
    record_map=SMF74B,
)
"""Device Dynamically Changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

Device Dynamically Changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
dyc.__doc__ = """Device Dynamically Changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

Device Dynamically Changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

ddt : Final[Field] = Field(
    name='ddt',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=cnx,
    record=record,
    record_map=SMF74B,
)
"""=1 If device disconnect time is invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If device disconnect time is invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
ddt.__doc__ = """=1 If device disconnect time is invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If device disconnect time is invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

pav : Final[Field] = Field(
    name='pav',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=cnx,
    record=record,
    record_map=SMF74B,
)
"""=1 If base exposure of a Parallel Access Volume(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If base exposure of a Parallel Access Volume

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
pav.__doc__ = """=1 If base exposure of a Parallel Access Volume(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If base exposure of a Parallel Access Volume

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

nxc : Final[Field] = Field(
    name='nxc',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=cnx,
    record=record,
    record_map=SMF74B,
)
"""=1 If number of alias exposures changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If number of alias exposures changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
nxc.__doc__ = """=1 If number of alias exposures changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If number of alias exposures changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

ntf : Final[Field] = Field(
    name='ntf',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=cnx,
    record=record,
    record_map=SMF74B,
)
"""Timing facility not active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

Timing facility not active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
ntf.__doc__ = """Timing facility not active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

Timing facility not active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

cni : Final[Field] = Field(
    name='cni',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=cnx,
    record=record,
    record_map=SMF74B,
)
"""=1 If device connect time is invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If device connect time is invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
cni.__doc__ = """=1 If device connect time is invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If device connect time is invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

hpv : Final[Field] = Field(
    name='hpv',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=cnx,
    record=record,
    record_map=SMF74B,
)
"""=1 If HyperPAV base device(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If HyperPAV base device

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
hpv.__doc__ = """=1 If HyperPAV base device(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 If HyperPAV base device

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

cfc : Final[Field] = Field(
    name='cfc',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=cnx,
    record=record,
    record_map=SMF74B,
)
"""=1 Device connected to Ficon(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device connected to Ficon

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
cfc.__doc__ = """=1 Device connected to Ficon(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnx`(`SMF74CNX`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device connected to Ficon

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

cn2 : Final[Field] = Field(
    name='cn2',
    origin='SMF74CN2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""Device Flag Extension 2

SMF Info
--------
    Field: `SMF74CN2`
    Record: `SMF74S1`
    Map: `SMF74B`

Device Flag Extension 2
"""
cn2.__doc__ = """Device Flag Extension 2

SMF Info
--------
    Field: `SMF74CN2`
    Record: `SMF74S1`
    Map: `SMF74B`

Device Flag Extension 2
"""

hwr : Final[Field] = Field(
    name='hwr',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=cn2,
    record=record,
    record_map=SMF74B,
)
"""=1 HyperWrite requested(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cn2`(`SMF74CN2`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 HyperWrite requested

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
hwr.__doc__ = """=1 HyperWrite requested(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cn2`(`SMF74CN2`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 HyperWrite requested

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

xpv : Final[Field] = Field(
    name='xpv',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=cn2,
    record=record,
    record_map=SMF74B,
)
"""=1 Device in SuperPAV mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cn2`(`SMF74CN2`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device in SuperPAV mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
xpv.__doc__ = """=1 Device in SuperPAV mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cn2`(`SMF74CN2`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device in SuperPAV mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

sir : Final[Field] = Field(
    name='sir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=cn2,
    record=record,
    record_map=SMF74B,
)
"""=1 Device is capable of synch I/O read requests(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cn2`(`SMF74CN2`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device is capable of synch I/O read requests

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
sir.__doc__ = """=1 Device is capable of synch I/O read requests(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cn2`(`SMF74CN2`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device is capable of synch I/O read requests

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

siw : Final[Field] = Field(
    name='siw',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=cn2,
    record=record,
    record_map=SMF74B,
)
"""=1 Device is capable of synch I/O write requests(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cn2`(`SMF74CN2`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device is capable of synch I/O write requests

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
siw.__doc__ = """=1 Device is capable of synch I/O write requests(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cn2`(`SMF74CN2`)
    Record: `SMF74S1`
    Map: `SMF74B`

=1 Device is capable of synch I/O write requests

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

mtc : Final[Field] = Field(
    name='mtc',
    origin='SMF74MTC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Number of mount conditions

SMF Info
--------
    Field: `SMF74MTC`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of mount conditions
"""
mtc.__doc__ = """Number of mount conditions

SMF Info
--------
    Field: `SMF74MTC`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of mount conditions
"""

dts : Final[Field] = Field(
    name='dts',
    origin='SMF74DTS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""indentify source of Token

SMF Info
--------
    Field: `SMF74DTS`
    Record: `SMF74S1`
    Map: `SMF74B`

indentify source of Token
"""
dts.__doc__ = """indentify source of Token

SMF Info
--------
    Field: `SMF74DTS`
    Record: `SMF74S1`
    Map: `SMF74B`

indentify source of Token
"""

srd : Final[Field] = Field(
    name='srd',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=dts,
    record=record,
    record_map=SMF74B,
)
"""if set: self desc. device(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dts`(`SMF74DTS`)
    Record: `SMF74S1`
    Map: `SMF74B`

if set: self desc. device

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
srd.__doc__ = """if set: self desc. device(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dts`(`SMF74DTS`)
    Record: `SMF74S1`
    Map: `SMF74B`

if set: self desc. device

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

snd : Final[Field] = Field(
    name='snd',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=dts,
    record=record,
    record_map=SMF74B,
)
"""if set: no self desc. device 4-byte device number stored(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dts`(`SMF74DTS`)
    Record: `SMF74S1`
    Map: `SMF74B`

if set: no self desc. device 4-byte device number stored

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
snd.__doc__ = """if set: no self desc. device 4-byte device number stored(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dts`(`SMF74DTS`)
    Record: `SMF74S1`
    Map: `SMF74B`

if set: no self desc. device 4-byte device number stored

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

shv : Final[Field] = Field(
    name='shv',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=dts,
    record=record,
    record_map=SMF74B,
)
"""ON = SMF74SHR indication is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dts`(`SMF74DTS`)
    Record: `SMF74S1`
    Map: `SMF74B`

ON = SMF74SHR indication is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
shv.__doc__ = """ON = SMF74SHR indication is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dts`(`SMF74DTS`)
    Record: `SMF74S1`
    Map: `SMF74B`

ON = SMF74SHR indication is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

shr : Final[Field] = Field(
    name='shr',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=dts,
    record=record,
    record_map=SMF74B,
)
"""ON = device is shared/assigned to multiple systems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dts`(`SMF74DTS`)
    Record: `SMF74S1`
    Map: `SMF74B`

ON = device is shared/assigned to multiple systems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
shr.__doc__ = """ON = device is shared/assigned to multiple systems(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dts`(`SMF74DTS`)
    Record: `SMF74S1`
    Map: `SMF74B`

ON = device is shared/assigned to multiple systems

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ndn : Final[Field] = Field(
    name='ndn',
    origin='SMF74NDN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""4-byte device number in EBCDIC format, if SMF74SND = 1

SMF Info
--------
    Field: `SMF74NDN`
    Record: `SMF74S1`
    Map: `SMF74B`

4-byte device number in EBCDIC format, if SMF74SND = 1
"""
ndn.__doc__ = """4-byte device number in EBCDIC format, if SMF74SND = 1

SMF Info
--------
    Field: `SMF74NDN`
    Record: `SMF74S1`
    Map: `SMF74B`

4-byte device number in EBCDIC format, if SMF74SND = 1
"""

hpc : Final[Field] = Field(
    name='hpc',
    origin='SMF74HPC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Number of HyperPAV aliases configured for that LSS

SMF Info
--------
    Field: `SMF74HPC`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of HyperPAV aliases configured for that LSS
"""
hpc.__doc__ = """Number of HyperPAV aliases configured for that LSS

SMF Info
--------
    Field: `SMF74HPC`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of HyperPAV aliases configured for that LSS
"""

nss : Final[Field] = Field(
    name='nss',
    origin='SMF74NSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Number of skipped samples caused by too large delta values

SMF Info
--------
    Field: `SMF74NSS`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of skipped samples caused by too large delta values
"""
nss.__doc__ = """Number of skipped samples caused by too large delta values

SMF Info
--------
    Field: `SMF74NSS`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of skipped samples caused by too large delta values
"""

psm : Final[Field] = Field(
    name='psm',
    origin='SMF74PSM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Number of successful PAV samples

SMF Info
--------
    Field: `SMF74PSM`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of successful PAV samples
"""
psm.__doc__ = """Number of successful PAV samples

SMF Info
--------
    Field: `SMF74PSM`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of successful PAV samples
"""

pct : Final[Field] = Field(
    name='pct',
    origin='SMF74PCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Number of unsuccessful PAV samples

SMF Info
--------
    Field: `SMF74PCT`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of unsuccessful PAV samples
"""
pct.__doc__ = """Number of unsuccessful PAV samples

SMF Info
--------
    Field: `SMF74PCT`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of unsuccessful PAV samples
"""

cmr : Final[Field] = Field(
    name='cmr',
    origin='SMF74CMR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Initial command response time in units of 128 microseconds

SMF Info
--------
    Field: `SMF74CMR`
    Record: `SMF74S1`
    Map: `SMF74B`

Initial command response time in units of 128 microseconds
"""
cmr.__doc__ = """Initial command response time in units of 128 microseconds

SMF Info
--------
    Field: `SMF74CMR`
    Record: `SMF74S1`
    Map: `SMF74B`

Initial command response time in units of 128 microseconds
"""

cap : Final[Field] = Field(
    name='cap',
    origin='SMF74CAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""DASD volume capacity (in cylinders)

SMF Info
--------
    Field: `SMF74CAP`
    Record: `SMF74S1`
    Map: `SMF74B`

DASD volume capacity (in cylinders)
"""
cap.__doc__ = """DASD volume capacity (in cylinders)

SMF Info
--------
    Field: `SMF74CAP`
    Record: `SMF74S1`
    Map: `SMF74B`

DASD volume capacity (in cylinders)
"""

idt : Final[Field] = Field(
    name='idt',
    origin='SMF74IDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Interrupt delay time in units of microseconds. This field is zero if not supported by the hardware.

SMF Info
--------
    Field: `SMF74IDT`
    Record: `SMF74S1`
    Map: `SMF74B`

Interrupt delay time in units of microseconds. This field is zero if not supported by the hardware.
"""
idt.__doc__ = """Interrupt delay time in units of microseconds. This field is zero if not supported by the hardware.

SMF Info
--------
    Field: `SMF74IDT`
    Record: `SMF74S1`
    Map: `SMF74B`

Interrupt delay time in units of microseconds. This field is zero if not supported by the hardware.
"""

cuq : Final[Field] = Field(
    name='cuq',
    origin='SMF74CUQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Control Unit Queuing Time

SMF Info
--------
    Field: `SMF74CUQ`
    Record: `SMF74S1`
    Map: `SMF74B`

Control Unit Queuing Time
"""
cuq.__doc__ = """Control Unit Queuing Time

SMF Info
--------
    Field: `SMF74CUQ`
    Record: `SMF74S1`
    Map: `SMF74B`

Control Unit Queuing Time
"""

scs : Final[Field] = Field(
    name='scs',
    origin='SMF74SCS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Subchannel Set the device is situated

SMF Info
--------
    Field: `SMF74SCS`
    Record: `SMF74S1`
    Map: `SMF74B`

Subchannel Set the device is situated
"""
scs.__doc__ = """Subchannel Set the device is situated

SMF Info
--------
    Field: `SMF74SCS`
    Record: `SMF74S1`
    Map: `SMF74B`

Subchannel Set the device is situated
"""

nm2 : Final[Field] = Field(
    name='nm2',
    origin='SMF74NM2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""Device number same as SMF74NUM

SMF Info
--------
    Field: `SMF74NM2`
    Record: `SMF74S1`
    Map: `SMF74B`

Device number same as SMF74NUM
"""
nm2.__doc__ = """Device number same as SMF74NUM

SMF Info
--------
    Field: `SMF74NM2`
    Record: `SMF74S1`
    Map: `SMF74B`

Device number same as SMF74NUM
"""

atd : Final[Field] = Field(
    name='atd',
    origin='SMF74ATD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""Number of times I/Os were subjected to imposed delays due to PAV alias throttling

SMF Info
--------
    Field: `SMF74ATD`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of times I/Os were subjected to imposed delays due to PAV alias throttling
"""
atd.__doc__ = """Number of times I/Os were subjected to imposed delays due to PAV alias throttling

SMF Info
--------
    Field: `SMF74ATD`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of times I/Os were subjected to imposed delays due to PAV alias throttling
"""

agc : Final[Field] = Field(
    name='agc',
    origin='SMF74AGC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""The Alias Management Group number defined on the physical controller for this device. This number is valid if the device belongs to a DASD subsystem that supports Alias Management Groups and bit 1 of SMF74CN2 is set

SMF Info
--------
    Field: `SMF74AGC`
    Record: `SMF74S1`
    Map: `SMF74B`

The Alias Management Group number defined on the physical controller for this device. This number is valid if the device belongs to a DASD subsystem that supports Alias Management Groups and bit 1 of SMF74CN2 is set
"""
agc.__doc__ = """The Alias Management Group number defined on the physical controller for this device. This number is valid if the device belongs to a DASD subsystem that supports Alias Management Groups and bit 1 of SMF74CN2 is set

SMF Info
--------
    Field: `SMF74AGC`
    Record: `SMF74S1`
    Map: `SMF74B`

The Alias Management Group number defined on the physical controller for this device. This number is valid if the device belongs to a DASD subsystem that supports Alias Management Groups and bit 1 of SMF74CN2 is set
"""

ags : Final[Field] = Field(
    name='ags',
    origin='SMF74AGS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74B,
)
"""The Alias Management Group number assigend by z/OS for this device on this system. This number is valid if the device belongs to a DASD subsystem that supports Alias Management Groups and bit 1 of SMF74CN2 is set

SMF Info
--------
    Field: `SMF74AGS`
    Record: `SMF74S1`
    Map: `SMF74B`

The Alias Management Group number assigend by z/OS for this device on this system. This number is valid if the device belongs to a DASD subsystem that supports Alias Management Groups and bit 1 of SMF74CN2 is set
"""
ags.__doc__ = """The Alias Management Group number assigend by z/OS for this device on this system. This number is valid if the device belongs to a DASD subsystem that supports Alias Management Groups and bit 1 of SMF74CN2 is set

SMF Info
--------
    Field: `SMF74AGS`
    Record: `SMF74S1`
    Map: `SMF74B`

The Alias Management Group number assigend by z/OS for this device on this system. This number is valid if the device belongs to a DASD subsystem that supports Alias Management Groups and bit 1 of SMF74CN2 is set
"""

sbr : Final[Field] = Field(
    name='sbr',
    origin='SMF74SBR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of synchronous I/O read bytes transferred (long floating point)

SMF Info
--------
    Field: `SMF74SBR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O read bytes transferred (long floating point)
"""
sbr.__doc__ = """Number of synchronous I/O read bytes transferred (long floating point)

SMF Info
--------
    Field: `SMF74SBR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O read bytes transferred (long floating point)
"""

sbw : Final[Field] = Field(
    name='sbw',
    origin='SMF74SBW',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of synchronous I/O write bytes transferred (long floating point)

SMF Info
--------
    Field: `SMF74SBW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write bytes transferred (long floating point)
"""
sbw.__doc__ = """Number of synchronous I/O write bytes transferred (long floating point)

SMF Info
--------
    Field: `SMF74SBW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write bytes transferred (long floating point)
"""

sqr : Final[Field] = Field(
    name='sqr',
    origin='SMF74SQR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of successfully completed synchronous I/O read requests (long floating point)

SMF Info
--------
    Field: `SMF74SQR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of successfully completed synchronous I/O read requests (long floating point)
"""
sqr.__doc__ = """Number of successfully completed synchronous I/O read requests (long floating point)

SMF Info
--------
    Field: `SMF74SQR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of successfully completed synchronous I/O read requests (long floating point)
"""

sqw : Final[Field] = Field(
    name='sqw',
    origin='SMF74SQW',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of successfully completed synchronous I/O write requests (long floating point)

SMF Info
--------
    Field: `SMF74SQW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of successfully completed synchronous I/O write requests (long floating point)
"""
sqw.__doc__ = """Number of successfully completed synchronous I/O write requests (long floating point)

SMF Info
--------
    Field: `SMF74SQW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of successfully completed synchronous I/O write requests (long floating point)
"""

spr : Final[Field] = Field(
    name='spr',
    origin='SMF74SPR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Processing time (in 0.5 micro second units) for successful synchronous I/O read requests (long floating point)

SMF Info
--------
    Field: `SMF74SPR`
    Record: `SMF74S1`
    Map: `SMF74B`

Processing time (in 0.5 micro second units) for successful synchronous I/O read requests (long floating point)
"""
spr.__doc__ = """Processing time (in 0.5 micro second units) for successful synchronous I/O read requests (long floating point)

SMF Info
--------
    Field: `SMF74SPR`
    Record: `SMF74S1`
    Map: `SMF74B`

Processing time (in 0.5 micro second units) for successful synchronous I/O read requests (long floating point)
"""

spw : Final[Field] = Field(
    name='spw',
    origin='SMF74SPW',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Processing time (in 0.5 micro second units) for successful synchronous I/O write requests (long floating point)

SMF Info
--------
    Field: `SMF74SPW`
    Record: `SMF74S1`
    Map: `SMF74B`

Processing time (in 0.5 micro second units) for successful synchronous I/O write requests (long floating point)
"""
spw.__doc__ = """Processing time (in 0.5 micro second units) for successful synchronous I/O write requests (long floating point)

SMF Info
--------
    Field: `SMF74SPW`
    Record: `SMF74S1`
    Map: `SMF74B`

Processing time (in 0.5 micro second units) for successful synchronous I/O write requests (long floating point)
"""

sftr : Final[Field] = Field(
    name='sftr',
    origin='SMF74SFTR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Elapsed (fail) time (in 0.5 micro second units) for unsuccessful synchronous I/O read requests (long floating point)

SMF Info
--------
    Field: `SMF74SFTR`
    Record: `SMF74S1`
    Map: `SMF74B`

Elapsed (fail) time (in 0.5 micro second units) for unsuccessful synchronous I/O read requests (long floating point)
"""
sftr.__doc__ = """Elapsed (fail) time (in 0.5 micro second units) for unsuccessful synchronous I/O read requests (long floating point)

SMF Info
--------
    Field: `SMF74SFTR`
    Record: `SMF74S1`
    Map: `SMF74B`

Elapsed (fail) time (in 0.5 micro second units) for unsuccessful synchronous I/O read requests (long floating point)
"""

sftw : Final[Field] = Field(
    name='sftw',
    origin='SMF74SFTW',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Elapsed (fail) time (in 0.5 micro second units) for unsuccessful synchronous I/O write requests (long floating point)

SMF Info
--------
    Field: `SMF74SFTW`
    Record: `SMF74S1`
    Map: `SMF74B`

Elapsed (fail) time (in 0.5 micro second units) for unsuccessful synchronous I/O write requests (long floating point)
"""
sftw.__doc__ = """Elapsed (fail) time (in 0.5 micro second units) for unsuccessful synchronous I/O write requests (long floating point)

SMF Info
--------
    Field: `SMF74SFTW`
    Record: `SMF74S1`
    Map: `SMF74B`

Elapsed (fail) time (in 0.5 micro second units) for unsuccessful synchronous I/O write requests (long floating point)
"""

slbr : Final[Field] = Field(
    name='slbr',
    origin='SMF74SLBR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of synchronous I/O read link busy conditions (short floating point)

SMF Info
--------
    Field: `SMF74SLBR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O read link busy conditions (short floating point)
"""
slbr.__doc__ = """Number of synchronous I/O read link busy conditions (short floating point)

SMF Info
--------
    Field: `SMF74SLBR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O read link busy conditions (short floating point)
"""

slbw : Final[Field] = Field(
    name='slbw',
    origin='SMF74SLBW',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of synchronous I/O write link busy conditions (short floating point)

SMF Info
--------
    Field: `SMF74SLBW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write link busy conditions (short floating point)
"""
slbw.__doc__ = """Number of synchronous I/O write link busy conditions (short floating point)

SMF Info
--------
    Field: `SMF74SLBW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write link busy conditions (short floating point)
"""

scmr : Final[Field] = Field(
    name='scmr',
    origin='SMF74SCMR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of cache miss conditions for synchronous I/O read requests (short floating point)

SMF Info
--------
    Field: `SMF74SCMR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of cache miss conditions for synchronous I/O read requests (short floating point)
"""
scmr.__doc__ = """Number of cache miss conditions for synchronous I/O read requests (short floating point)

SMF Info
--------
    Field: `SMF74SCMR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of cache miss conditions for synchronous I/O read requests (short floating point)
"""

snis : Final[Field] = Field(
    name='snis',
    origin='SMF74SNIS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of synchronous I/O write requests where the write data could not be immediately stored (short floating point)

SMF Info
--------
    Field: `SMF74SNIS`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write requests where the write data could not be immediately stored (short floating point)
"""
snis.__doc__ = """Number of synchronous I/O write requests where the write data could not be immediately stored (short floating point)

SMF Info
--------
    Field: `SMF74SNIS`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write requests where the write data could not be immediately stored (short floating point)
"""

stor : Final[Field] = Field(
    name='stor',
    origin='SMF74STOR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of synchronous I/O read timeout conditions (short floating point)

SMF Info
--------
    Field: `SMF74STOR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O read timeout conditions (short floating point)
"""
stor.__doc__ = """Number of synchronous I/O read timeout conditions (short floating point)

SMF Info
--------
    Field: `SMF74STOR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O read timeout conditions (short floating point)
"""

stow : Final[Field] = Field(
    name='stow',
    origin='SMF74STOW',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of synchronous I/O write timeout conditions (short floating point)

SMF Info
--------
    Field: `SMF74STOW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write timeout conditions (short floating point)
"""
stow.__doc__ = """Number of synchronous I/O write timeout conditions (short floating point)

SMF Info
--------
    Field: `SMF74STOW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write timeout conditions (short floating point)
"""

sor : Final[Field] = Field(
    name='sor',
    origin='SMF74SOR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of synchronous I/O read requests rejected for other reasons (short floating point)

SMF Info
--------
    Field: `SMF74SOR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O read requests rejected for other reasons (short floating point)
"""
sor.__doc__ = """Number of synchronous I/O read requests rejected for other reasons (short floating point)

SMF Info
--------
    Field: `SMF74SOR`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O read requests rejected for other reasons (short floating point)
"""

sow : Final[Field] = Field(
    name='sow',
    origin='SMF74SOW',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""Number of synchronous I/O write requests rejected for other reasons (short floating point)

SMF Info
--------
    Field: `SMF74SOW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write requests rejected for other reasons (short floating point)
"""
sow.__doc__ = """Number of synchronous I/O write requests rejected for other reasons (short floating point)

SMF Info
--------
    Field: `SMF74SOW`
    Record: `SMF74S1`
    Map: `SMF74B`

Number of synchronous I/O write requests rejected for other reasons (short floating point)
"""

ios : Final[Field] = Field(
    name='ios',
    origin='SMF74IOS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF74B,
)
"""IOS Queue time in microseconds (short floating point)

SMF Info
--------
    Field: `SMF74IOS`
    Record: `SMF74S1`
    Map: `SMF74B`

IOS Queue time in microseconds (short floating point)
"""
ios.__doc__ = """IOS Queue time in microseconds (short floating point)

SMF Info
--------
    Field: `SMF74IOS`
    Record: `SMF74S1`
    Map: `SMF74B`

IOS Queue time in microseconds (short floating point)
"""

dct : Final[Field] = Field(
    name='dct',
    origin='SMF74DCT',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74B,
)
"""Configuration Token for self-describing devices valid if SMF74SND = 0

SMF Info
--------
    Field: `SMF74DCT`
    Record: `SMF74S1`
    Map: `SMF74B`

Configuration Token for self-describing devices valid if SMF74SND = 0
"""
dct.__doc__ = """Configuration Token for self-describing devices valid if SMF74SND = 0

SMF Info
--------
    Field: `SMF74DCT`
    Record: `SMF74S1`
    Map: `SMF74B`

Configuration Token for self-describing devices valid if SMF74SND = 0
"""
