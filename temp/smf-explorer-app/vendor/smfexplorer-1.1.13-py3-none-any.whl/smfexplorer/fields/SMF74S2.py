# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 2"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=2,
                                spec='SMF 74 Subtype 2',
                                post=None)
"""SMF 74 Subtype 2"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R742SYS: Final[RecordMap] = RecordMap(
    origin='R742SYS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='System Data',
    post=None,
    record_mapping=False)
"""System Data"""
R742PTH: Final[RecordMap] = RecordMap(
    origin='R742PTH',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Path Data',
    post=None,
    record_mapping=False)
"""Path Data"""
R742MBR: Final[RecordMap] = RecordMap(
    origin='R742MBR',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Member Data',
    post=None,
    record_mapping=False)
"""Member Data"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S2`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S2`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S2`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S2`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S2`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S2`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S2`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S2`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S2`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S2`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S2`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S2`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S2`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S2`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S2`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S2`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S2`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S2`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S2`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S2`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S2`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S2`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S2`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S2`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S2`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S2`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S2`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S2`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S2`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S2`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S2`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

co : Final[Field] = Field(
    name='co',
    origin='SMF742CO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to control data section

SMF Info
--------
    Field: `SMF742CO`
    Record: `SMF74S2`
    Map: Not part of a map

Offset to control data section
"""
co.__doc__ = """Offset to control data section

SMF Info
--------
    Field: `SMF742CO`
    Record: `SMF74S2`
    Map: Not part of a map

Offset to control data section
"""

cl : Final[Field] = Field(
    name='cl',
    origin='SMF742CL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of control data section

SMF Info
--------
    Field: `SMF742CL`
    Record: `SMF74S2`
    Map: Not part of a map

Length of control data section
"""
cl.__doc__ = """Length of control data section

SMF Info
--------
    Field: `SMF742CL`
    Record: `SMF74S2`
    Map: Not part of a map

Length of control data section
"""

cn : Final[Field] = Field(
    name='cn',
    origin='SMF742CN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of control data sections

SMF Info
--------
    Field: `SMF742CN`
    Record: `SMF74S2`
    Map: Not part of a map

Number of control data sections
"""
cn.__doc__ = """Number of control data sections

SMF Info
--------
    Field: `SMF742CN`
    Record: `SMF74S2`
    Map: Not part of a map

Number of control data sections
"""

so : Final[Field] = Field(
    name='so',
    origin='SMF742SO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to system data section

SMF Info
--------
    Field: `SMF742SO`
    Record: `SMF74S2`
    Map: Not part of a map

Offset to system data section
"""
so.__doc__ = """Offset to system data section

SMF Info
--------
    Field: `SMF742SO`
    Record: `SMF74S2`
    Map: Not part of a map

Offset to system data section
"""

sl : Final[Field] = Field(
    name='sl',
    origin='SMF742SL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of system data section

SMF Info
--------
    Field: `SMF742SL`
    Record: `SMF74S2`
    Map: Not part of a map

Length of system data section
"""
sl.__doc__ = """Length of system data section

SMF Info
--------
    Field: `SMF742SL`
    Record: `SMF74S2`
    Map: Not part of a map

Length of system data section
"""

sn : Final[Field] = Field(
    name='sn',
    origin='SMF742SN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of system data section

SMF Info
--------
    Field: `SMF742SN`
    Record: `SMF74S2`
    Map: Not part of a map

Number of system data section
"""
sn.__doc__ = """Number of system data section

SMF Info
--------
    Field: `SMF742SN`
    Record: `SMF74S2`
    Map: Not part of a map

Number of system data section
"""

po : Final[Field] = Field(
    name='po',
    origin='SMF742PO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to path data section

SMF Info
--------
    Field: `SMF742PO`
    Record: `SMF74S2`
    Map: Not part of a map

Offset to path data section
"""
po.__doc__ = """Offset to path data section

SMF Info
--------
    Field: `SMF742PO`
    Record: `SMF74S2`
    Map: Not part of a map

Offset to path data section
"""

pl : Final[Field] = Field(
    name='pl',
    origin='SMF742PL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of path data section

SMF Info
--------
    Field: `SMF742PL`
    Record: `SMF74S2`
    Map: Not part of a map

Length of path data section
"""
pl.__doc__ = """Length of path data section

SMF Info
--------
    Field: `SMF742PL`
    Record: `SMF74S2`
    Map: Not part of a map

Length of path data section
"""

pn : Final[Field] = Field(
    name='pn',
    origin='SMF742PN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of path data sections

SMF Info
--------
    Field: `SMF742PN`
    Record: `SMF74S2`
    Map: Not part of a map

Number of path data sections
"""
pn.__doc__ = """Number of path data sections

SMF Info
--------
    Field: `SMF742PN`
    Record: `SMF74S2`
    Map: Not part of a map

Number of path data sections
"""

mo : Final[Field] = Field(
    name='mo',
    origin='SMF742MO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Member data section

SMF Info
--------
    Field: `SMF742MO`
    Record: `SMF74S2`
    Map: Not part of a map

Offset to Member data section
"""
mo.__doc__ = """Offset to Member data section

SMF Info
--------
    Field: `SMF742MO`
    Record: `SMF74S2`
    Map: Not part of a map

Offset to Member data section
"""

ml : Final[Field] = Field(
    name='ml',
    origin='SMF742ML',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of member data section

SMF Info
--------
    Field: `SMF742ML`
    Record: `SMF74S2`
    Map: Not part of a map

Length of member data section
"""
ml.__doc__ = """Length of member data section

SMF Info
--------
    Field: `SMF742ML`
    Record: `SMF74S2`
    Map: Not part of a map

Length of member data section
"""

mn : Final[Field] = Field(
    name='mn',
    origin='SMF742MN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of member data sections

SMF Info
--------
    Field: `SMF742MN`
    Record: `SMF74S2`
    Map: Not part of a map

Number of member data sections
"""
mn.__doc__ = """Number of member data sections

SMF Info
--------
    Field: `SMF742MN`
    Record: `SMF74S2`
    Map: Not part of a map

Number of member data sections
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S2`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S2`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S2`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S2`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S2`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S2`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S2`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S2`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S2`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S2`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S2`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S2`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S2`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S2`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

r742snme : Final[Field] = Field(
    name='r742snme',
    origin='R742SNME',
    type=FieldType.STRING,
    record=record,
    record_map=R742SYS,
)
"""System name

SMF Info
--------
    Field: `R742SNME`
    Record: `SMF74S2`
    Map: `R742SYS`

System name
"""
r742snme.__doc__ = """System name

SMF Info
--------
    Field: `R742SNME`
    Record: `SMF74S2`
    Map: `R742SYS`

System name
"""

r742sstf : Final[Field] = Field(
    name='r742sstf',
    origin='R742SSTF',
    type=FieldType.STRING,
    record=record,
    record_map=R742SYS,
)
"""Status flags

SMF Info
--------
    Field: `R742SSTF`
    Record: `SMF74S2`
    Map: `R742SYS`

Status flags
"""
r742sstf.__doc__ = """Status flags

SMF Info
--------
    Field: `R742SSTF`
    Record: `SMF74S2`
    Map: `R742SYS`

Status flags
"""

r742sact : Final[Field] = Field(
    name='r742sact',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r742sstf,
    record=record,
    record_map=R742SYS,
)
"""System became active during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sstf`(`R742SSTF`)
    Record: `SMF74S2`
    Map: `R742SYS`

System became active during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r742sact.__doc__ = """System became active during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sstf`(`R742SSTF`)
    Record: `SMF74S2`
    Map: `R742SYS`

System became active during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r742siac : Final[Field] = Field(
    name='r742siac',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r742sstf,
    record=record,
    record_map=R742SYS,
)
"""System became inactive during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sstf`(`R742SSTF`)
    Record: `SMF74S2`
    Map: `R742SYS`

System became inactive during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r742siac.__doc__ = """System became inactive during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sstf`(`R742SSTF`)
    Record: `SMF74S2`
    Map: `R742SYS`

System became inactive during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r742sres : Final[Field] = Field(
    name='r742sres',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r742sstf,
    record=record,
    record_map=R742SYS,
)
"""Counts reset by XCF during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sstf`(`R742SSTF`)
    Record: `SMF74S2`
    Map: `R742SYS`

Counts reset by XCF during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r742sres.__doc__ = """Counts reset by XCF during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sstf`(`R742SSTF`)
    Record: `SMF74S2`
    Map: `R742SYS`

Counts reset by XCF during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r742spar : Final[Field] = Field(
    name='r742spar',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r742sstf,
    record=record,
    record_map=R742SYS,
)
"""Partially not active during RMF post processor interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sstf`(`R742SSTF`)
    Record: `SMF74S2`
    Map: `R742SYS`

Partially not active during RMF post processor interval.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r742spar.__doc__ = """Partially not active during RMF post processor interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sstf`(`R742SSTF`)
    Record: `SMF74S2`
    Map: `R742SYS`

Partially not active during RMF post processor interval.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r742sdir : Final[Field] = Field(
    name='r742sdir',
    origin='R742SDIR',
    type=FieldType.STRING,
    record=record,
    record_map=R742SYS,
)
"""Direction

SMF Info
--------
    Field: `R742SDIR`
    Record: `SMF74S2`
    Map: `R742SYS`

Direction
"""
r742sdir.__doc__ = """Direction

SMF Info
--------
    Field: `R742SDIR`
    Record: `SMF74S2`
    Map: `R742SYS`

Direction
"""

r742sin : Final[Field] = Field(
    name='r742sin',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r742sdir,
    record=record,
    record_map=R742SYS,
)
"""Inbound(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sdir`(`R742SDIR`)
    Record: `SMF74S2`
    Map: `R742SYS`

Inbound

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r742sin.__doc__ = """Inbound(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sdir`(`R742SDIR`)
    Record: `SMF74S2`
    Map: `R742SYS`

Inbound

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r742sout : Final[Field] = Field(
    name='r742sout',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r742sdir,
    record=record,
    record_map=R742SYS,
)
"""Outbound(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sdir`(`R742SDIR`)
    Record: `SMF74S2`
    Map: `R742SYS`

Outbound

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r742sout.__doc__ = """Outbound(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sdir`(`R742SDIR`)
    Record: `SMF74S2`
    Map: `R742SYS`

Outbound

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r742slcl : Final[Field] = Field(
    name='r742slcl',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r742sdir,
    record=record,
    record_map=R742SYS,
)
"""Local(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sdir`(`R742SDIR`)
    Record: `SMF74S2`
    Map: `R742SYS`

Local

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r742slcl.__doc__ = """Local(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742sdir`(`R742SDIR`)
    Record: `SMF74S2`
    Map: `R742SYS`

Local

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r742spth : Final[Field] = Field(
    name='r742spth',
    origin='R742SPTH',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742SYS,
)
"""Current number of paths in service. Zero for local entry. If outbound entry, count is for indicated transport class

SMF Info
--------
    Field: `R742SPTH`
    Record: `SMF74S2`
    Map: `R742SYS`

Current number of paths in service. Zero for local entry. If outbound entry, count is for indicated transport class
"""
r742spth.__doc__ = """Current number of paths in service. Zero for local entry. If outbound entry, count is for indicated transport class

SMF Info
--------
    Field: `R742SPTH`
    Record: `SMF74S2`
    Map: `R742SYS`

Current number of paths in service. Zero for local entry. If outbound entry, count is for indicated transport class
"""

r742sbsy : Final[Field] = Field(
    name='r742sbsy',
    origin='R742SBSY',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742SYS,
)
"""Number of no buffer conditions. For local or outbound entry, count is for indicated transport class.

SMF Info
--------
    Field: `R742SBSY`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of no buffer conditions. For local or outbound entry, count is for indicated transport class.
"""
r742sbsy.__doc__ = """Number of no buffer conditions. For local or outbound entry, count is for indicated transport class.

SMF Info
--------
    Field: `R742SBSY`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of no buffer conditions. For local or outbound entry, count is for indicated transport class.
"""

r742snop : Final[Field] = Field(
    name='r742snop',
    origin='R742SNOP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742SYS,
)
"""Number of no path conditions Zero for local entry. For outbound entry, count is for indicated transport class

SMF Info
--------
    Field: `R742SNOP`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of no path conditions Zero for local entry. For outbound entry, count is for indicated transport class
"""
r742snop.__doc__ = """Number of no path conditions Zero for local entry. For outbound entry, count is for indicated transport class

SMF Info
--------
    Field: `R742SNOP`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of no path conditions Zero for local entry. For outbound entry, count is for indicated transport class
"""

r742smxb : Final[Field] = Field(
    name='r742smxb',
    origin='R742SMXB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742SYS,
)
"""Maximum 1K blocks of message buffer space. For local or outbound entry, count is for indicated transport class

SMF Info
--------
    Field: `R742SMXB`
    Record: `SMF74S2`
    Map: `R742SYS`

Maximum 1K blocks of message buffer space. For local or outbound entry, count is for indicated transport class
"""
r742smxb.__doc__ = """Maximum 1K blocks of message buffer space. For local or outbound entry, count is for indicated transport class

SMF Info
--------
    Field: `R742SMXB`
    Record: `SMF74S2`
    Map: `R742SYS`

Maximum 1K blocks of message buffer space. For local or outbound entry, count is for indicated transport class
"""

r742sbig : Final[Field] = Field(
    name='r742sbig',
    origin='R742SBIG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742SYS,
)
"""Number of message too big conditions. Zero for inbound entry.

SMF Info
--------
    Field: `R742SBIG`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of message too big conditions. Zero for inbound entry.
"""
r742sbig.__doc__ = """Number of message too big conditions. Zero for inbound entry.

SMF Info
--------
    Field: `R742SBIG`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of message too big conditions. Zero for inbound entry.
"""

r742sfit : Final[Field] = Field(
    name='r742sfit',
    origin='R742SFIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742SYS,
)
"""Number of messages that fits in buffer. Zero for inbound entry.

SMF Info
--------
    Field: `R742SFIT`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of messages that fits in buffer. Zero for inbound entry.
"""
r742sfit.__doc__ = """Number of messages that fits in buffer. Zero for inbound entry.

SMF Info
--------
    Field: `R742SFIT`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of messages that fits in buffer. Zero for inbound entry.
"""

r742ssml : Final[Field] = Field(
    name='r742ssml',
    origin='R742SSML',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742SYS,
)
"""Number of messages too small conditions. Zero for inbound entry.

SMF Info
--------
    Field: `R742SSML`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of messages too small conditions. Zero for inbound entry.
"""
r742ssml.__doc__ = """Number of messages too small conditions. Zero for inbound entry.

SMF Info
--------
    Field: `R742SSML`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of messages too small conditions. Zero for inbound entry.
"""

r742sovr : Final[Field] = Field(
    name='r742sovr',
    origin='R742SOVR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742SYS,
)
"""Number of messages for which signalling service was optimized. Zero for inbound entry.

SMF Info
--------
    Field: `R742SOVR`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of messages for which signalling service was optimized. Zero for inbound entry.
"""
r742sovr.__doc__ = """Number of messages for which signalling service was optimized. Zero for inbound entry.

SMF Info
--------
    Field: `R742SOVR`
    Record: `SMF74S2`
    Map: `R742SYS`

Number of messages for which signalling service was optimized. Zero for inbound entry.
"""

r742stcl : Final[Field] = Field(
    name='r742stcl',
    origin='R742STCL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742SYS,
)
"""Message length for transport class. Zero for inbound entry.

SMF Info
--------
    Field: `R742STCL`
    Record: `SMF74S2`
    Map: `R742SYS`

Message length for transport class. Zero for inbound entry.
"""
r742stcl.__doc__ = """Message length for transport class. Zero for inbound entry.

SMF Info
--------
    Field: `R742STCL`
    Record: `SMF74S2`
    Map: `R742SYS`

Message length for transport class. Zero for inbound entry.
"""

r742stcn : Final[Field] = Field(
    name='r742stcn',
    origin='R742STCN',
    type=FieldType.STRING,
    record=record,
    record_map=R742SYS,
)
"""Transport class name. Blanks for inbound entry.

SMF Info
--------
    Field: `R742STCN`
    Record: `SMF74S2`
    Map: `R742SYS`

Transport class name. Blanks for inbound entry.
"""
r742stcn.__doc__ = """Transport class name. Blanks for inbound entry.

SMF Info
--------
    Field: `R742STCN`
    Record: `SMF74S2`
    Map: `R742SYS`

Transport class name. Blanks for inbound entry.
"""

r742pnme : Final[Field] = Field(
    name='r742pnme',
    origin='R742PNME',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""System name

SMF Info
--------
    Field: `R742PNME`
    Record: `SMF74S2`
    Map: `R742PTH`

System name
"""
r742pnme.__doc__ = """System name

SMF Info
--------
    Field: `R742PNME`
    Record: `SMF74S2`
    Map: `R742PTH`

System name
"""

r742pdev : Final[Field] = Field(
    name='r742pdev',
    origin='R742PDEV',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""Device number

SMF Info
--------
    Field: `R742PDEV`
    Record: `SMF74S2`
    Map: `R742PTH`

Device number
"""
r742pdev.__doc__ = """Device number

SMF Info
--------
    Field: `R742PDEV`
    Record: `SMF74S2`
    Map: `R742PTH`

Device number
"""

r742pstf : Final[Field] = Field(
    name='r742pstf',
    origin='R742PSTF',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""Status flags

SMF Info
--------
    Field: `R742PSTF`
    Record: `SMF74S2`
    Map: `R742PTH`

Status flags
"""
r742pstf.__doc__ = """Status flags

SMF Info
--------
    Field: `R742PSTF`
    Record: `SMF74S2`
    Map: `R742PTH`

Status flags
"""

r742pact : Final[Field] = Field(
    name='r742pact',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r742pstf,
    record=record,
    record_map=R742PTH,
)
"""Path became active during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstf`(`R742PSTF`)
    Record: `SMF74S2`
    Map: `R742PTH`

Path became active during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r742pact.__doc__ = """Path became active during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstf`(`R742PSTF`)
    Record: `SMF74S2`
    Map: `R742PTH`

Path became active during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r742piac : Final[Field] = Field(
    name='r742piac',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r742pstf,
    record=record,
    record_map=R742PTH,
)
"""Path became inactive during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstf`(`R742PSTF`)
    Record: `SMF74S2`
    Map: `R742PTH`

Path became inactive during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r742piac.__doc__ = """Path became inactive during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstf`(`R742PSTF`)
    Record: `SMF74S2`
    Map: `R742PTH`

Path became inactive during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r742pres : Final[Field] = Field(
    name='r742pres',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r742pstf,
    record=record,
    record_map=R742PTH,
)
"""Counts reset by XCF during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstf`(`R742PSTF`)
    Record: `SMF74S2`
    Map: `R742PTH`

Counts reset by XCF during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r742pres.__doc__ = """Counts reset by XCF during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstf`(`R742PSTF`)
    Record: `SMF74S2`
    Map: `R742PTH`

Counts reset by XCF during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r742pdir : Final[Field] = Field(
    name='r742pdir',
    origin='R742PDIR',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""Direction path

SMF Info
--------
    Field: `R742PDIR`
    Record: `SMF74S2`
    Map: `R742PTH`

Direction path
"""
r742pdir.__doc__ = """Direction path

SMF Info
--------
    Field: `R742PDIR`
    Record: `SMF74S2`
    Map: `R742PTH`

Direction path
"""

r742pin : Final[Field] = Field(
    name='r742pin',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r742pdir,
    record=record,
    record_map=R742PTH,
)
"""Inbound path(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pdir`(`R742PDIR`)
    Record: `SMF74S2`
    Map: `R742PTH`

Inbound path

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r742pin.__doc__ = """Inbound path(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pdir`(`R742PDIR`)
    Record: `SMF74S2`
    Map: `R742PTH`

Inbound path

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r742pout : Final[Field] = Field(
    name='r742pout',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r742pdir,
    record=record,
    record_map=R742PTH,
)
"""Outbound path(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pdir`(`R742PDIR`)
    Record: `SMF74S2`
    Map: `R742PTH`

Outbound path

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r742pout.__doc__ = """Outbound path(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pdir`(`R742PDIR`)
    Record: `SMF74S2`
    Map: `R742PTH`

Outbound path

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r742ptyp : Final[Field] = Field(
    name='r742ptyp',
    origin='R742PTYP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Path type indicator: '01'x for CTC, '03'x for list structure

SMF Info
--------
    Field: `R742PTYP`
    Record: `SMF74S2`
    Map: `R742PTH`

Path type indicator: '01'x for CTC, '03'x for list structure
"""
r742ptyp.__doc__ = """Path type indicator: '01'x for CTC, '03'x for list structure

SMF Info
--------
    Field: `R742PTYP`
    Record: `SMF74S2`
    Map: `R742PTH`

Path type indicator: '01'x for CTC, '03'x for list structure
"""

r742pona : Final[Field] = Field(
    name='r742pona',
    origin='R742PONA',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""Name of system on other end if known, otherwise blanks.

SMF Info
--------
    Field: `R742PONA`
    Record: `SMF74S2`
    Map: `R742PTH`

Name of system on other end if known, otherwise blanks.
"""
r742pona.__doc__ = """Name of system on other end if known, otherwise blanks.

SMF Info
--------
    Field: `R742PONA`
    Record: `SMF74S2`
    Map: `R742PTH`

Name of system on other end if known, otherwise blanks.
"""

r742podv : Final[Field] = Field(
    name='r742podv',
    origin='R742PODV',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""Device number on other end if known, otherwise blanks.

SMF Info
--------
    Field: `R742PODV`
    Record: `SMF74S2`
    Map: `R742PTH`

Device number on other end if known, otherwise blanks.
"""
r742podv.__doc__ = """Device number on other end if known, otherwise blanks.

SMF Info
--------
    Field: `R742PODV`
    Record: `SMF74S2`
    Map: `R742PTH`

Device number on other end if known, otherwise blanks.
"""

r742psta : Final[Field] = Field(
    name='r742psta',
    origin='R742PSTA',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""Path status

SMF Info
--------
    Field: `R742PSTA`
    Record: `SMF74S2`
    Map: `R742PTH`

Path status
"""
r742psta.__doc__ = """Path status

SMF Info
--------
    Field: `R742PSTA`
    Record: `SMF74S2`
    Map: `R742PTH`

Path status
"""

r742pst : Final[Field] = Field(
    name='r742pst',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r742psta,
    record=record,
    record_map=R742PTH,
)
"""Starting(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Starting

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r742pst.__doc__ = """Starting(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Starting

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r742prs : Final[Field] = Field(
    name='r742prs',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r742psta,
    record=record,
    record_map=R742PTH,
)
"""Restarting(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Restarting

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r742prs.__doc__ = """Restarting(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Restarting

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r742pwk : Final[Field] = Field(
    name='r742pwk',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r742psta,
    record=record,
    record_map=R742PTH,
)
"""Working(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Working

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r742pwk.__doc__ = """Working(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Working

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r742psp : Final[Field] = Field(
    name='r742psp',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r742psta,
    record=record,
    record_map=R742PTH,
)
"""Stopping(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Stopping

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r742psp.__doc__ = """Stopping(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Stopping

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r742plk : Final[Field] = Field(
    name='r742plk',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r742psta,
    record=record,
    record_map=R742PTH,
)
"""Waiting for completion of communication link.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Waiting for completion of communication link.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r742plk.__doc__ = """Waiting for completion of communication link.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Waiting for completion of communication link.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r742pnp : Final[Field] = Field(
    name='r742pnp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r742psta,
    record=record,
    record_map=R742PTH,
)
"""Not operational. Path defined to XCF but not usable until hardware and/or definition problems are resolved(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Not operational. Path defined to XCF but not usable until hardware and/or definition problems are resolved

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r742pnp.__doc__ = """Not operational. Path defined to XCF but not usable until hardware and/or definition problems are resolved(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Not operational. Path defined to XCF but not usable until hardware and/or definition problems are resolved

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r742psf : Final[Field] = Field(
    name='r742psf',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r742psta,
    record=record,
    record_map=R742PTH,
)
"""Stop failed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Stop failed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r742psf.__doc__ = """Stop failed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Stop failed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r742prb : Final[Field] = Field(
    name='r742prb',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r742psta,
    record=record,
    record_map=R742PTH,
)
"""Rebuilding(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Rebuilding

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r742prb.__doc__ = """Rebuilding(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742psta`(`R742PSTA`)
    Record: `SMF74S2`
    Map: `R742PTH`

Rebuilding

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r742pstm : Final[Field] = Field(
    name='r742pstm',
    origin='R742PSTM',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""More path status flags

SMF Info
--------
    Field: `R742PSTM`
    Record: `SMF74S2`
    Map: `R742PTH`

More path status flags
"""
r742pstm.__doc__ = """More path status flags

SMF Info
--------
    Field: `R742PSTM`
    Record: `SMF74S2`
    Map: `R742PTH`

More path status flags
"""

r742pqg : Final[Field] = Field(
    name='r742pqg',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r742pstm,
    record=record,
    record_map=R742PTH,
)
"""Quiescing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstm`(`R742PSTM`)
    Record: `SMF74S2`
    Map: `R742PTH`

Quiescing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r742pqg.__doc__ = """Quiescing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstm`(`R742PSTM`)
    Record: `SMF74S2`
    Map: `R742PTH`

Quiescing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r742pqd : Final[Field] = Field(
    name='r742pqd',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r742pstm,
    record=record,
    record_map=R742PTH,
)
"""Quiesced(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstm`(`R742PSTM`)
    Record: `SMF74S2`
    Map: `R742PTH`

Quiesced

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r742pqd.__doc__ = """Quiesced(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742pstm`(`R742PSTM`)
    Record: `SMF74S2`
    Map: `R742PTH`

Quiesced

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r742pret : Final[Field] = Field(
    name='r742pret',
    origin='R742PRET',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Path retry limit

SMF Info
--------
    Field: `R742PRET`
    Record: `SMF74S2`
    Map: `R742PTH`

Path retry limit
"""
r742pret.__doc__ = """Path retry limit

SMF Info
--------
    Field: `R742PRET`
    Record: `SMF74S2`
    Map: `R742PTH`

Path retry limit
"""

r742prst : Final[Field] = Field(
    name='r742prst',
    origin='R742PRST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Number of restarts

SMF Info
--------
    Field: `R742PRST`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of restarts
"""
r742prst.__doc__ = """Number of restarts

SMF Info
--------
    Field: `R742PRST`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of restarts
"""

r742pmxm : Final[Field] = Field(
    name='r742pmxm',
    origin='R742PMXM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Maximum number of 1K blocks message buffer space.

SMF Info
--------
    Field: `R742PMXM`
    Record: `SMF74S2`
    Map: `R742PTH`

Maximum number of 1K blocks message buffer space.
"""
r742pmxm.__doc__ = """Maximum number of 1K blocks message buffer space.

SMF Info
--------
    Field: `R742PMXM`
    Record: `SMF74S2`
    Map: `R742PTH`

Maximum number of 1K blocks message buffer space.
"""

r742psig : Final[Field] = Field(
    name='r742psig',
    origin='R742PSIG',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Number of outbound (inbound) signals sent (received) over path.

SMF Info
--------
    Field: `R742PSIG`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of outbound (inbound) signals sent (received) over path.
"""
r742psig.__doc__ = """Number of outbound (inbound) signals sent (received) over path.

SMF Info
--------
    Field: `R742PSIG`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of outbound (inbound) signals sent (received) over path.
"""

r742pqln : Final[Field] = Field(
    name='r742pqln',
    origin='R742PQLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Number of outbound signals pending transfer on path

SMF Info
--------
    Field: `R742PQLN`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of outbound signals pending transfer on path
"""
r742pqln.__doc__ = """Number of outbound signals pending transfer on path

SMF Info
--------
    Field: `R742PQLN`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of outbound signals pending transfer on path
"""

r742pibr : Final[Field] = Field(
    name='r742pibr',
    origin='R742PIBR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Number of inbound signals refused due to maximum message limit.

SMF Info
--------
    Field: `R742PIBR`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of inbound signals refused due to maximum message limit.
"""
r742pibr.__doc__ = """Number of inbound signals refused due to maximum message limit.

SMF Info
--------
    Field: `R742PIBR`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of inbound signals refused due to maximum message limit.
"""

r742psus : Final[Field] = Field(
    name='r742psus',
    origin='R742PSUS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Number of outbound signals satisfied by suspended path.

SMF Info
--------
    Field: `R742PSUS`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of outbound signals satisfied by suspended path.
"""
r742psus.__doc__ = """Number of outbound signals satisfied by suspended path.

SMF Info
--------
    Field: `R742PSUS`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of outbound signals satisfied by suspended path.
"""

r742papp : Final[Field] = Field(
    name='r742papp',
    origin='R742PAPP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Number of outbound signal requests satisfied by this path while active.

SMF Info
--------
    Field: `R742PAPP`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of outbound signal requests satisfied by this path while active.
"""
r742papp.__doc__ = """Number of outbound signal requests satisfied by this path while active.

SMF Info
--------
    Field: `R742PAPP`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of outbound signal requests satisfied by this path while active.
"""

r742ptcn : Final[Field] = Field(
    name='r742ptcn',
    origin='R742PTCN',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""Transport class name. For an outbound path, the class to which the path is assigned. For an inbound path, the class to which the outbound side of the path is assigned, blanks if not known.

SMF Info
--------
    Field: `R742PTCN`
    Record: `SMF74S2`
    Map: `R742PTH`

Transport class name. For an outbound path, the class to which the path is assigned. For an inbound path, the class to which the outbound side of the path is assigned, blanks if not known.
"""
r742ptcn.__doc__ = """Transport class name. For an outbound path, the class to which the path is assigned. For an inbound path, the class to which the outbound side of the path is assigned, blanks if not known.

SMF Info
--------
    Field: `R742PTCN`
    Record: `SMF74S2`
    Map: `R742PTH`

Transport class name. For an outbound path, the class to which the path is assigned. For an inbound path, the class to which the outbound side of the path is assigned, blanks if not known.
"""

r742pstr : Final[Field] = Field(
    name='r742pstr',
    origin='R742PSTR',
    type=FieldType.STRING,
    record=record,
    record_map=R742PTH,
)
"""Name of XES list structure being used as a path, blank for CTC's

SMF Info
--------
    Field: `R742PSTR`
    Record: `SMF74S2`
    Map: `R742PTH`

Name of XES list structure being used as a path, blank for CTC's
"""
r742pstr.__doc__ = """Name of XES list structure being used as a path, blank for CTC's

SMF Info
--------
    Field: `R742PSTR`
    Record: `SMF74S2`
    Map: `R742PTH`

Name of XES list structure being used as a path, blank for CTC's
"""

r742piot : Final[Field] = Field(
    name='r742piot',
    origin='R742PIOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""For inbound paths: Average I/O transfer time for the most recently received signals. Units: Micro Seconds. Zero if not available. X'FFFFFFFF' if overflow (more than 35 minutes)

SMF Info
--------
    Field: `R742PIOT`
    Record: `SMF74S2`
    Map: `R742PTH`

For inbound paths: Average I/O transfer time for the most recently received signals. Units: Micro Seconds. Zero if not available. X'FFFFFFFF' if overflow (more than 35 minutes)
"""
r742piot.__doc__ = """For inbound paths: Average I/O transfer time for the most recently received signals. Units: Micro Seconds. Zero if not available. X'FFFFFFFF' if overflow (more than 35 minutes)

SMF Info
--------
    Field: `R742PIOT`
    Record: `SMF74S2`
    Map: `R742PTH`

For inbound paths: Average I/O transfer time for the most recently received signals. Units: Micro Seconds. Zero if not available. X'FFFFFFFF' if overflow (more than 35 minutes)
"""

r742prct : Final[Field] = Field(
    name='r742prct',
    origin='R742PRCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Path retry count

SMF Info
--------
    Field: `R742PRCT`
    Record: `SMF74S2`
    Map: `R742PTH`

Path retry count
"""
r742prct.__doc__ = """Path retry count

SMF Info
--------
    Field: `R742PRCT`
    Record: `SMF74S2`
    Map: `R742PTH`

Path retry count
"""

r742ppnd : Final[Field] = Field(
    name='r742ppnd',
    origin='R742PPND',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""The current number of signals pending transfer on the path (outbound only)

SMF Info
--------
    Field: `R742PPND`
    Record: `SMF74S2`
    Map: `R742PTH`

The current number of signals pending transfer on the path (outbound only)
"""
r742ppnd.__doc__ = """The current number of signals pending transfer on the path (outbound only)

SMF Info
--------
    Field: `R742PPND`
    Record: `SMF74S2`
    Map: `R742PTH`

The current number of signals pending transfer on the path (outbound only)
"""

r742puse : Final[Field] = Field(
    name='r742puse',
    origin='R742PUSE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""The current number of 1K byte blocks of message buffer space in use by this path

SMF Info
--------
    Field: `R742PUSE`
    Record: `SMF74S2`
    Map: `R742PTH`

The current number of 1K byte blocks of message buffer space in use by this path
"""
r742puse.__doc__ = """The current number of 1K byte blocks of message buffer space in use by this path

SMF Info
--------
    Field: `R742PUSE`
    Record: `SMF74S2`
    Map: `R742PTH`

The current number of 1K byte blocks of message buffer space in use by this path
"""

r742plin : Final[Field] = Field(
    name='r742plin',
    origin='R742PLIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""List number within structure

SMF Info
--------
    Field: `R742PLIN`
    Record: `SMF74S2`
    Map: `R742PTH`

List number within structure
"""
r742plin.__doc__ = """List number within structure

SMF Info
--------
    Field: `R742PLIN`
    Record: `SMF74S2`
    Map: `R742PTH`

List number within structure
"""

r742pusg_timesum : Final[Field] = Field(
    name='r742pusg_timesum',
    origin='R742PUSG_TIMESUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Total time this path was in use at the indicated percent utilization (in ms)

SMF Info
--------
    Field: `R742PUSG_TIMESUM`
    Record: `SMF74S2`
    Map: `R742PTH`

Total time this path was in use at the indicated percent utilization (in ms)
"""
r742pusg_timesum.__doc__ = """Total time this path was in use at the indicated percent utilization (in ms)

SMF Info
--------
    Field: `R742PUSG_TIMESUM`
    Record: `SMF74S2`
    Map: `R742PTH`

Total time this path was in use at the indicated percent utilization (in ms)
"""

r742pusg_timessq : Final[Field] = Field(
    name='r742pusg_timessq',
    origin='R742PUSG_TIMESSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Squared microseconds this path was in use at the indicated percent utilization

SMF Info
--------
    Field: `R742PUSG_TIMESSQ`
    Record: `SMF74S2`
    Map: `R742PTH`

Squared microseconds this path was in use at the indicated percent utilization
"""
r742pusg_timessq.__doc__ = """Squared microseconds this path was in use at the indicated percent utilization

SMF Info
--------
    Field: `R742PUSG_TIMESSQ`
    Record: `SMF74S2`
    Map: `R742PTH`

Squared microseconds this path was in use at the indicated percent utilization
"""

r742pusg_timenum : Final[Field] = Field(
    name='r742pusg_timenum',
    origin='R742PUSG_TIME#',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Number of times this path was in use at the indicated percent utilization

SMF Info
--------
    Field: `R742PUSG_TIME#`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of times this path was in use at the indicated percent utilization
"""
r742pusg_timenum.__doc__ = """Number of times this path was in use at the indicated percent utilization

SMF Info
--------
    Field: `R742PUSG_TIME#`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of times this path was in use at the indicated percent utilization
"""

r742pusg_sigcnt : Final[Field] = Field(
    name='r742pusg_sigcnt',
    origin='R742PUSG_SIGCNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Number of signals sent for this usage entry

SMF Info
--------
    Field: `R742PUSG_SIGCNT`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of signals sent for this usage entry
"""
r742pusg_sigcnt.__doc__ = """Number of signals sent for this usage entry

SMF Info
--------
    Field: `R742PUSG_SIGCNT`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of signals sent for this usage entry
"""

r742pusg_percent : Final[Field] = Field(
    name='r742pusg_percent',
    origin='R742PUSG_PERCENT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Percent utilization this entry represents

SMF Info
--------
    Field: `R742PUSG_PERCENT`
    Record: `SMF74S2`
    Map: `R742PTH`

Percent utilization this entry represents
"""
r742pusg_percent.__doc__ = """Percent utilization this entry represents

SMF Info
--------
    Field: `R742PUSG_PERCENT`
    Record: `SMF74S2`
    Map: `R742PTH`

Percent utilization this entry represents
"""

r742pnib_timesum : Final[Field] = Field(
    name='r742pnib_timesum',
    origin='R742PNIB_TIMESUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Total time this path had a no-inbound-buffer impact condition (in ms)

SMF Info
--------
    Field: `R742PNIB_TIMESUM`
    Record: `SMF74S2`
    Map: `R742PTH`

Total time this path had a no-inbound-buffer impact condition (in ms)
"""
r742pnib_timesum.__doc__ = """Total time this path had a no-inbound-buffer impact condition (in ms)

SMF Info
--------
    Field: `R742PNIB_TIMESUM`
    Record: `SMF74S2`
    Map: `R742PTH`

Total time this path had a no-inbound-buffer impact condition (in ms)
"""

r742pnib_timessq : Final[Field] = Field(
    name='r742pnib_timessq',
    origin='R742PNIB_TIMESSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Squared microseconds for each no-inbound-buffer impact condition

SMF Info
--------
    Field: `R742PNIB_TIMESSQ`
    Record: `SMF74S2`
    Map: `R742PTH`

Squared microseconds for each no-inbound-buffer impact condition
"""
r742pnib_timessq.__doc__ = """Squared microseconds for each no-inbound-buffer impact condition

SMF Info
--------
    Field: `R742PNIB_TIMESSQ`
    Record: `SMF74S2`
    Map: `R742PTH`

Squared microseconds for each no-inbound-buffer impact condition
"""

r742pnib_timenum : Final[Field] = Field(
    name='r742pnib_timenum',
    origin='R742PNIB_TIME#',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742PTH,
)
"""Number of times this path was impacted by a no-inbound-buffer condition

SMF Info
--------
    Field: `R742PNIB_TIME#`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of times this path was impacted by a no-inbound-buffer condition
"""
r742pnib_timenum.__doc__ = """Number of times this path was impacted by a no-inbound-buffer condition

SMF Info
--------
    Field: `R742PNIB_TIME#`
    Record: `SMF74S2`
    Map: `R742PTH`

Number of times this path was impacted by a no-inbound-buffer condition
"""

r742msys : Final[Field] = Field(
    name='r742msys',
    origin='R742MSYS',
    type=FieldType.STRING,
    record=record,
    record_map=R742MBR,
)
"""System name

SMF Info
--------
    Field: `R742MSYS`
    Record: `SMF74S2`
    Map: `R742MBR`

System name
"""
r742msys.__doc__ = """System name

SMF Info
--------
    Field: `R742MSYS`
    Record: `SMF74S2`
    Map: `R742MBR`

System name
"""

r742mgrp : Final[Field] = Field(
    name='r742mgrp',
    origin='R742MGRP',
    type=FieldType.STRING,
    record=record,
    record_map=R742MBR,
)
"""Group name

SMF Info
--------
    Field: `R742MGRP`
    Record: `SMF74S2`
    Map: `R742MBR`

Group name
"""
r742mgrp.__doc__ = """Group name

SMF Info
--------
    Field: `R742MGRP`
    Record: `SMF74S2`
    Map: `R742MBR`

Group name
"""

r742mmem : Final[Field] = Field(
    name='r742mmem',
    origin='R742MMEM',
    type=FieldType.STRING,
    record=record,
    record_map=R742MBR,
)
"""Member name

SMF Info
--------
    Field: `R742MMEM`
    Record: `SMF74S2`
    Map: `R742MBR`

Member name
"""
r742mmem.__doc__ = """Member name

SMF Info
--------
    Field: `R742MMEM`
    Record: `SMF74S2`
    Map: `R742MBR`

Member name
"""

r742mstf : Final[Field] = Field(
    name='r742mstf',
    origin='R742MSTF',
    type=FieldType.STRING,
    record=record,
    record_map=R742MBR,
)
"""Status flags

SMF Info
--------
    Field: `R742MSTF`
    Record: `SMF74S2`
    Map: `R742MBR`

Status flags
"""
r742mstf.__doc__ = """Status flags

SMF Info
--------
    Field: `R742MSTF`
    Record: `SMF74S2`
    Map: `R742MBR`

Status flags
"""

r742mact : Final[Field] = Field(
    name='r742mact',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r742mstf,
    record=record,
    record_map=R742MBR,
)
"""Member became active during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

Member became active during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r742mact.__doc__ = """Member became active during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

Member became active during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r742miac : Final[Field] = Field(
    name='r742miac',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r742mstf,
    record=record,
    record_map=R742MBR,
)
"""Member became inactive during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

Member became inactive during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r742miac.__doc__ = """Member became inactive during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

Member became inactive during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r742mres : Final[Field] = Field(
    name='r742mres',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r742mstf,
    record=record,
    record_map=R742MBR,
)
"""Counts reset by XCF during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

Counts reset by XCF during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r742mres.__doc__ = """Counts reset by XCF during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

Counts reset by XCF during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r742mpar : Final[Field] = Field(
    name='r742mpar',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r742mstf,
    record=record,
    record_map=R742MBR,
)
"""Partially not active during RMF post processor interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

Partially not active during RMF post processor interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r742mpar.__doc__ = """Partially not active during RMF post processor interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

Partially not active during RMF post processor interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r742mnoq : Final[Field] = Field(
    name='r742mnoq',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r742mstf,
    record=record,
    record_map=R742MBR,
)
"""No information returned from IXCQUERY(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

No information returned from IXCQUERY

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r742mnoq.__doc__ = """No information returned from IXCQUERY(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mstf`(`R742MSTF`)
    Record: `SMF74S2`
    Map: `R742MBR`

No information returned from IXCQUERY

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r742mst1 : Final[Field] = Field(
    name='r742mst1',
    origin='R742MST1',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742MBR,
)
"""Extended member state (1) 2=CREATED, 3=ACTIVE, 4=QUIESCED, 5=FAILED

SMF Info
--------
    Field: `R742MST1`
    Record: `SMF74S2`
    Map: `R742MBR`

Extended member state (1) 2=CREATED, 3=ACTIVE, 4=QUIESCED, 5=FAILED
"""
r742mst1.__doc__ = """Extended member state (1) 2=CREATED, 3=ACTIVE, 4=QUIESCED, 5=FAILED

SMF Info
--------
    Field: `R742MST1`
    Record: `SMF74S2`
    Map: `R742MBR`

Extended member state (1) 2=CREATED, 3=ACTIVE, 4=QUIESCED, 5=FAILED
"""

r742mst2 : Final[Field] = Field(
    name='r742mst2',
    origin='R742MST2',
    type=FieldType.STRING,
    record=record,
    record_map=R742MBR,
)
"""Extended member state (2)

SMF Info
--------
    Field: `R742MST2`
    Record: `SMF74S2`
    Map: `R742MBR`

Extended member state (2)
"""
r742mst2.__doc__ = """Extended member state (2)

SMF Info
--------
    Field: `R742MST2`
    Record: `SMF74S2`
    Map: `R742MBR`

Extended member state (2)
"""

r742mssm : Final[Field] = Field(
    name='r742mssm',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r742mst2,
    record=record,
    record_map=R742MBR,
)
"""System status update missing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

System status update missing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r742mssm.__doc__ = """System status update missing(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

System status update missing

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r742mtrm : Final[Field] = Field(
    name='r742mtrm',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r742mst2,
    record=record,
    record_map=R742MBR,
)
"""System termination started(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

System termination started

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r742mtrm.__doc__ = """System termination started(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

System termination started

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r742mmsm : Final[Field] = Field(
    name='r742mmsm',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r742mst2,
    record=record,
    record_map=R742MBR,
)
"""Status update missing (confirmed)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

Status update missing (confirmed)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r742mmsm.__doc__ = """Status update missing (confirmed)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

Status update missing (confirmed)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r742mmsd : Final[Field] = Field(
    name='r742mmsd',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r742mst2,
    record=record,
    record_map=R742MBR,
)
"""Status update missing (not confirmed)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

Status update missing (not confirmed)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r742mmsd.__doc__ = """Status update missing (not confirmed)(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

Status update missing (not confirmed)

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r742mrem : Final[Field] = Field(
    name='r742mrem',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r742mst2,
    record=record,
    record_map=R742MBR,
)
"""Monitoring has been removed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

Monitoring has been removed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r742mrem.__doc__ = """Monitoring has been removed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r742mst2`(`R742MST2`)
    Record: `SMF74S2`
    Map: `R742MBR`

Monitoring has been removed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r742msnt : Final[Field] = Field(
    name='r742msnt',
    origin='R742MSNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742MBR,
)
"""Number of signals sent by member.

SMF Info
--------
    Field: `R742MSNT`
    Record: `SMF74S2`
    Map: `R742MBR`

Number of signals sent by member.
"""
r742msnt.__doc__ = """Number of signals sent by member.

SMF Info
--------
    Field: `R742MSNT`
    Record: `SMF74S2`
    Map: `R742MBR`

Number of signals sent by member.
"""

r742mrcv : Final[Field] = Field(
    name='r742mrcv',
    origin='R742MRCV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742MBR,
)
"""Number of signals received by member.

SMF Info
--------
    Field: `R742MRCV`
    Record: `SMF74S2`
    Map: `R742MBR`

Number of signals received by member.
"""
r742mrcv.__doc__ = """Number of signals received by member.

SMF Info
--------
    Field: `R742MRCV`
    Record: `SMF74S2`
    Map: `R742MBR`

Number of signals received by member.
"""

r742mint : Final[Field] = Field(
    name='r742mint',
    origin='R742MINT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R742MBR,
)
"""Status checking interval

SMF Info
--------
    Field: `R742MINT`
    Record: `SMF74S2`
    Map: `R742MBR`

Status checking interval
"""
r742mint.__doc__ = """Status checking interval

SMF Info
--------
    Field: `R742MINT`
    Record: `SMF74S2`
    Map: `R742MBR`

Status checking interval
"""

r742mjob : Final[Field] = Field(
    name='r742mjob',
    origin='R742MJOB',
    type=FieldType.STRING,
    record=record,
    record_map=R742MBR,
)
"""Job name that joined the member

SMF Info
--------
    Field: `R742MJOB`
    Record: `SMF74S2`
    Map: `R742MBR`

Job name that joined the member
"""
r742mjob.__doc__ = """Job name that joined the member

SMF Info
--------
    Field: `R742MJOB`
    Record: `SMF74S2`
    Map: `R742MBR`

Job name that joined the member
"""
