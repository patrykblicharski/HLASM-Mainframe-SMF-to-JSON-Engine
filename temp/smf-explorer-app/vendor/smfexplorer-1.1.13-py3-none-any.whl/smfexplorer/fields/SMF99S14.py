# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 99 Subtype 14"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=99,
                                smf_subtype=14,
                                spec='SMF 99 Subtype 14',
                                post=None)
"""SMF 99 Subtype 14"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __high_inline_post(df):
    return df.polar_n1 & df.polar_n2


def __medium_inline_post(df):
    return df.polar_n1 & df.polar_n2


def __low_inline_post(df):
    return df.polar_n1 & df.polar_n2


def __processor_inline_post(df):
    high_filter = ~df.high
    medium_filter = ~df.medium
    low_filter = ~df.low
    processor = df.high.where(df.high, '')
    processor =  processor.where(high_filter, 'High')
    processor =  processor.where(medium_filter, 'Medium')
    processor =  processor.where(low_filter, 'Low')
    return processor



SMF99_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_SDEF_MAP',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 self defining Section',
    post=None,
    record_mapping=False)
"""SMF99 self defining Section"""
SMF99_PRODUCT_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_PRODUCT_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Product Information Section',
    post=None,
    record_mapping=False)
"""SMF99 Product Information Section"""
SMF99_S14_SDEF_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S14_SDEF_MAP',
    record=record,
    parent=SMF99_SDEF_MAP,
    is_multiple=False,
    is_compound=False,
    spec='SMF99 Subtype 14 self defining section',
    post=None,
    record_mapping=False)
"""SMF99 Subtype 14 self defining section"""
SMF99_S14_HD_TOPOCHG_HDR_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S14_HD_TOPOCHG_HDR_MAP',
    record=record,
    parent=SMF99_S14_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 14 Header Data Section BASED(addr(smf_hdr_map) + SMF9914...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 14 Header Data Section BASED(addr(smf_hdr_map) + SMF9914..."""
SMF99_S14_HD_TOPOCHG_CPU_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S14_HD_TOPOCHG_CPU_MAP',
    record=record,
    parent=SMF99_S14_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 14 Processor Data Section BASED(addr(smf_hdr_map) + SMF9...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 14 Processor Data Section BASED(addr(smf_hdr_map) + SMF9..."""
SMF99_S14_HD_TOPOCHG_NODE_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S14_HD_TOPOCHG_NODE_MAP',
    record=record,
    parent=SMF99_S14_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 14 Node Data Section BASED(addr(smf_hdr_map) + SMF9914_H...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 14 Node Data Section BASED(addr(smf_hdr_map) + SMF9914_H..."""
SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP',
    record=record,
    parent=SMF99_S14_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 14 MPWQ CPU Data Section BASED(addr(smf_hdr_map) + SMF99...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 14 MPWQ CPU Data Section BASED(addr(smf_hdr_map) + SMF99..."""
SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP: Final[RecordMap] = RecordMap(
    origin='SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP',
    record=record,
    parent=SMF99_S14_SDEF_MAP,
    is_multiple=True,
    is_compound=False,
    spec='SMF99 subtype 14 MPWQ HNode Data Section BASED(addr(smf_hdr_map) + SMF...',
    post=None,
    record_mapping=False)
"""SMF99 subtype 14 MPWQ HNode Data Section BASED(addr(smf_hdr_map) + SMF..."""

date : Final[Field] = Field(
    name='date',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S14`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S14`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S14`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S14`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S14`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF99DTE`), `time`(`SMF99TME`)
    Record: `SMF99S14`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF99LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S14`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""
len.__doc__ = """Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).

SMF Info
--------
    Field: `SMF99LEN`
    Record: `SMF99S14`
    Map: Not part of a map

Record Length. This field and the next field (total of four bytes) form the RDW (record descriptor word).
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF99SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S14`
    Map: Not part of a map

Segment descriptor (see record length field)
"""
seg.__doc__ = """Segment descriptor (see record length field)

SMF Info
--------
    Field: `SMF99SEG`
    Record: `SMF99S14`
    Map: Not part of a map

Segment descriptor (see record length field)
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF99FLG',
    type=FieldType.STRING,
    record=record,
)
"""System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S14`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""
flg.__doc__ = """System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved

SMF Info
--------
    Field: `SMF99FLG`
    Record: `SMF99S14`
    Map: Not part of a map

System indicator: Bit 0 reserved, Bit 1 subtypes utilized, Bit 2 reserved, Bits 3-6 version indicators, Bit 7 reserved
"""

stu : Final[Field] = Field(
    name='stu',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S14`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
stu.__doc__ = """Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF99FLG`)
    Record: `SMF99S14`
    Map: Not part of a map

Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF99RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S14`
    Map: Not part of a map

Record type 99
"""
rty.__doc__ = """Record type 99

SMF Info
--------
    Field: `SMF99RTY`
    Record: `SMF99S14`
    Map: Not part of a map

Record type 99
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF99TME',
    type=FieldType.TIME,
    record=record,
)
"""Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S14`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""
tme.__doc__ = """Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer

SMF Info
--------
    Field: `SMF99TME`
    Record: `SMF99S14`
    Map: Not part of a map

Time since midnight, in hundreths of a second, that the record was moved into the SMF buffer
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF99DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S14`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""
dte.__doc__ = """Date when the record was moved into the SMF buffer, in the form 0cyydddF.

SMF Info
--------
    Field: `SMF99DTE`
    Record: `SMF99S14`
    Map: Not part of a map

Date when the record was moved into the SMF buffer, in the form 0cyydddF.
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF99SID',
    type=FieldType.STRING,
    record=record,
)
"""System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S14`
    Map: Not part of a map

System identification (from the SID parameter).
"""
sid.__doc__ = """System identification (from the SID parameter).

SMF Info
--------
    Field: `SMF99SID`
    Record: `SMF99S14`
    Map: Not part of a map

System identification (from the SID parameter).
"""

ssid : Final[Field] = Field(
    name='ssid',
    origin='SMF99SSID',
    type=FieldType.STRING,
    record=record,
)
"""Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S14`
    Map: Not part of a map

Sub System Identification
"""
ssid.__doc__ = """Sub System Identification

SMF Info
--------
    Field: `SMF99SSID`
    Record: `SMF99S14`
    Map: Not part of a map

Sub System Identification
"""

tid : Final[Field] = Field(
    name='tid',
    origin='SMF99TID',
    type=FieldType.INTEGER,
    record=record,
)
"""Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S14`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""
tid.__doc__ = """Record subtype (must be at offset '16'X)

SMF Info
--------
    Field: `SMF99TID`
    Record: `SMF99S14`
    Map: Not part of a map

Record subtype (must be at offset '16'X)
"""

sdef_len : Final[Field] = Field(
    name='sdef_len',
    origin='SMF99_SDEF_LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S14`
    Map: Not part of a map

Length of self definition section
"""
sdef_len.__doc__ = """Length of self definition section

SMF Info
--------
    Field: `SMF99_SDEF_LEN`
    Record: `SMF99S14`
    Map: Not part of a map

Length of self definition section
"""

pof : Final[Field] = Field(
    name='pof',
    origin='SMF99POF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""
pof.__doc__ = """Offset to the product section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99POF`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Offset to the product section from the beginning of the record (including RDW)
"""

pln : Final[Field] = Field(
    name='pln',
    origin='SMF99PLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""
pln.__doc__ = """Length of the product section

SMF Info
--------
    Field: `SMF99PLN`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Length of the product section
"""

pon : Final[Field] = Field(
    name='pon',
    origin='SMF99PON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""
pon.__doc__ = """Number of product sections

SMF Info
--------
    Field: `SMF99PON`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Number of product sections
"""

dof : Final[Field] = Field(
    name='dof',
    origin='SMF99DOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""
dof.__doc__ = """Offset to the data section from the beginning of the record (including RDW)

SMF Info
--------
    Field: `SMF99DOF`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Offset to the data section from the beginning of the record (including RDW)
"""

dln : Final[Field] = Field(
    name='dln',
    origin='SMF99DLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""
dln.__doc__ = """Length of the data section

SMF Info
--------
    Field: `SMF99DLN`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Length of the data section
"""

don : Final[Field] = Field(
    name='don',
    origin='SMF99DON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_SDEF_MAP,
)
"""Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""
don.__doc__ = """Number of data sections

SMF Info
--------
    Field: `SMF99DON`
    Record: `SMF99S14`
    Map: `SMF99_SDEF_MAP`

Number of data sections
"""

vn2 : Final[Field] = Field(
    name='vn2',
    origin='SMF99VN2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""
vn2.__doc__ = """Record sub version. Used to identify changes to the record in the service stream

SMF Info
--------
    Field: `SMF99VN2`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Record sub version. Used to identify changes to the record in the service stream
"""

rvn : Final[Field] = Field(
    name='rvn',
    origin='SMF99RVN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""
rvn.__doc__ = """Record Version Number

SMF Info
--------
    Field: `SMF99RVN`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Record Version Number
"""

pnm : Final[Field] = Field(
    name='pnm',
    origin='SMF99PNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""
pnm.__doc__ = """Product Name - SRM

SMF Info
--------
    Field: `SMF99PNM`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Product Name - SRM
"""

slv : Final[Field] = Field(
    name='slv',
    origin='SMF99SLV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""
slv.__doc__ = """System level from which record was cut (copied from CVTPRODN)

SMF Info
--------
    Field: `SMF99SLV`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

System level from which record was cut (copied from CVTPRODN)
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF99SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""
snm.__doc__ = """System name from which record was cut (copied from CVTSNAME)

SMF Info
--------
    Field: `SMF99SNM`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

System name from which record was cut (copied from CVTSNAME)
"""

pflg : Final[Field] = Field(
    name='pflg',
    origin='SMF99PFLG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""
pflg.__doc__ = """Record flags

SMF Info
--------
    Field: `SMF99PFLG`
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Record flags
"""

record_incomplete : Final[Field] = Field(
    name='record_incomplete',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
record_incomplete.__doc__ = """Only a subset of the available data was written to avoid that this record gets larger than 32 kByte(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data was written to avoid that this record gets larger than 32 kByte

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

reasm_indicator : Final[Field] = Field(
    name='reasm_indicator',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pflg,
    record=record,
    record_map=SMF99_PRODUCT_MAP,
)
"""Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
reasm_indicator.__doc__ = """Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pflg`(`SMF99PFLG`)
    Record: `SMF99S14`
    Map: `SMF99_PRODUCT_MAP`

Only a subset of the available data is written to this record. The rest follows in subsequent records. This record contains a reassembly area.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

hd_topochg_hdr_offset : Final[Field] = Field(
    name='hd_topochg_hdr_offset',
    origin='SMF9914_HD_TOPOCHG_HDR_OFFSET',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Offset to header data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_HDR_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to header data section
"""
hd_topochg_hdr_offset.__doc__ = """Offset to header data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_HDR_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to header data section
"""

hd_topochg_hdr_length : Final[Field] = Field(
    name='hd_topochg_hdr_length',
    origin='SMF9914_HD_TOPOCHG_HDR_LENGTH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Length of header data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_HDR_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of header data section
"""
hd_topochg_hdr_length.__doc__ = """Length of header data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_HDR_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of header data section
"""

hd_topochg_hdr_number : Final[Field] = Field(
    name='hd_topochg_hdr_number',
    origin='SMF9914_HD_TOPOCHG_HDR_NUMBER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Number of header data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_HDR_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of header data sections
"""
hd_topochg_hdr_number.__doc__ = """Number of header data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_HDR_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of header data sections
"""

hd_topochg_cpu_offset : Final[Field] = Field(
    name='hd_topochg_cpu_offset',
    origin='SMF9914_HD_TOPOCHG_CPU_OFFSET',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Offset to processor data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_CPU_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to processor data section
"""
hd_topochg_cpu_offset.__doc__ = """Offset to processor data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_CPU_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to processor data section
"""

hd_topochg_cpu_length : Final[Field] = Field(
    name='hd_topochg_cpu_length',
    origin='SMF9914_HD_TOPOCHG_CPU_LENGTH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Length of processor data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_CPU_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of processor data section
"""
hd_topochg_cpu_length.__doc__ = """Length of processor data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_CPU_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of processor data section
"""

hd_topochg_cpu_number : Final[Field] = Field(
    name='hd_topochg_cpu_number',
    origin='SMF9914_HD_TOPOCHG_CPU_NUMBER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Number of processor data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_CPU_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of processor data sections
"""
hd_topochg_cpu_number.__doc__ = """Number of processor data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_CPU_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of processor data sections
"""

hd_topochg_node_offset : Final[Field] = Field(
    name='hd_topochg_node_offset',
    origin='SMF9914_HD_TOPOCHG_NODE_OFFSET',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Offset to node data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_NODE_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to node data section
"""
hd_topochg_node_offset.__doc__ = """Offset to node data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_NODE_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to node data section
"""

hd_topochg_node_length : Final[Field] = Field(
    name='hd_topochg_node_length',
    origin='SMF9914_HD_TOPOCHG_NODE_LENGTH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Length of node data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_NODE_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of node data section
"""
hd_topochg_node_length.__doc__ = """Length of node data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_NODE_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of node data section
"""

hd_topochg_node_number : Final[Field] = Field(
    name='hd_topochg_node_number',
    origin='SMF9914_HD_TOPOCHG_NODE_NUMBER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Number of node data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_NODE_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of node data sections
"""
hd_topochg_node_number.__doc__ = """Number of node data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_NODE_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of node data sections
"""

hd_topochg_mpwq_offset : Final[Field] = Field(
    name='hd_topochg_mpwq_offset',
    origin='SMF9914_HD_TOPOCHG_MPWQ_OFFSET',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Offset to MPWQ data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to MPWQ data section
"""
hd_topochg_mpwq_offset.__doc__ = """Offset to MPWQ data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to MPWQ data section
"""

hd_topochg_mpwq_length : Final[Field] = Field(
    name='hd_topochg_mpwq_length',
    origin='SMF9914_HD_TOPOCHG_MPWQ_LENGTH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Length of MPWQ data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of MPWQ data section
"""
hd_topochg_mpwq_length.__doc__ = """Length of MPWQ data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of MPWQ data section
"""

hd_topochg_mpwq_number : Final[Field] = Field(
    name='hd_topochg_mpwq_number',
    origin='SMF9914_HD_TOPOCHG_MPWQ_NUMBER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Number of MPWQ data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of MPWQ data sections
"""
hd_topochg_mpwq_number.__doc__ = """Number of MPWQ data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of MPWQ data sections
"""

hd_topochg_mpwq_hnode_offset : Final[Field] = Field(
    name='hd_topochg_mpwq_hnode_offset',
    origin='SMF9914_HD_TOPOCHG_MPWQ_HNODE_OFFSET',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Offset to MPWQ HNODE data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_HNODE_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to MPWQ HNODE data section
"""
hd_topochg_mpwq_hnode_offset.__doc__ = """Offset to MPWQ HNODE data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_HNODE_OFFSET`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Offset to MPWQ HNODE data section
"""

hd_topochg_mpwq_hnode_length : Final[Field] = Field(
    name='hd_topochg_mpwq_hnode_length',
    origin='SMF9914_HD_TOPOCHG_MPWQ_HNODE_LENGTH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Length of MPWQ HNODE data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_HNODE_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of MPWQ HNODE data section
"""
hd_topochg_mpwq_hnode_length.__doc__ = """Length of MPWQ HNODE data section

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_HNODE_LENGTH`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Length of MPWQ HNODE data section
"""

hd_topochg_mpwq_hnode_number : Final[Field] = Field(
    name='hd_topochg_mpwq_hnode_number',
    origin='SMF9914_HD_TOPOCHG_MPWQ_HNODE_NUMBER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_SDEF_MAP,
)
"""Number of MPWQ HNODE data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_HNODE_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of MPWQ HNODE data sections
"""
hd_topochg_mpwq_hnode_number.__doc__ = """Number of MPWQ HNODE data sections

SMF Info
--------
    Field: `SMF9914_HD_TOPOCHG_MPWQ_HNODE_NUMBER`
    Record: `SMF99S14`
    Map: `SMF99_S14_SDEF_MAP`

Number of MPWQ HNODE data sections
"""

vcm_smf_sequ : Final[Field] = Field(
    name='vcm_smf_sequ',
    origin='SMF99E_VCM_SMF_SEQU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""balancer interval sequence number

SMF Info
--------
    Field: `SMF99E_VCM_SMF_SEQU`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

balancer interval sequence number
"""
vcm_smf_sequ.__doc__ = """balancer interval sequence number

SMF Info
--------
    Field: `SMF99E_VCM_SMF_SEQU`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

balancer interval sequence number
"""

vcm_flag1 : Final[Field] = Field(
    name='vcm_flag1',
    origin='SMF99E_VCM_FLAG1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""balancer interval flag1

SMF Info
--------
    Field: `SMF99E_VCM_FLAG1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

balancer interval flag1
"""
vcm_flag1.__doc__ = """balancer interval flag1

SMF Info
--------
    Field: `SMF99E_VCM_FLAG1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

balancer interval flag1
"""

topology_change : Final[Field] = Field(
    name='topology_change',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""topology has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

topology has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
topology_change.__doc__ = """topology has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

topology has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

affinity_nodes_rebuild : Final[Field] = Field(
    name='affinity_nodes_rebuild',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""rebuild affinity nodes(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

rebuild affinity nodes

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
affinity_nodes_rebuild.__doc__ = """rebuild affinity nodes(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

rebuild affinity nodes

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

honor_priority_change : Final[Field] = Field(
    name='honor_priority_change',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""honor priority has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

honor priority has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
honor_priority_change.__doc__ = """honor priority has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

honor priority has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

wuq_error : Final[Field] = Field(
    name='wuq_error',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""dispatcher WUQ error(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

dispatcher WUQ error

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
wuq_error.__doc__ = """dispatcher WUQ error(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

dispatcher WUQ error

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

speed_change : Final[Field] = Field(
    name='speed_change',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=vcm_flag1,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""processor speed change(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

processor speed change

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
speed_change.__doc__ = """processor speed change(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag1`(`SMF99E_VCM_FLAG1`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

processor speed change

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vcm_flag2 : Final[Field] = Field(
    name='vcm_flag2',
    origin='SMF99E_VCM_FLAG2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""balancer interval flag2

SMF Info
--------
    Field: `SMF99E_VCM_FLAG2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

balancer interval flag2
"""
vcm_flag2.__doc__ = """balancer interval flag2

SMF Info
--------
    Field: `SMF99E_VCM_FLAG2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

balancer interval flag2
"""

vcm_ceccapvalid : Final[Field] = Field(
    name='vcm_ceccapvalid',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""CEC capacities are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

CEC capacities are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_ceccapvalid.__doc__ = """CEC capacities are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

CEC capacities are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_lparcapvalid : Final[Field] = Field(
    name='vcm_lparcapvalid',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""LPAR capacities are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

LPAR capacities are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_lparcapvalid.__doc__ = """LPAR capacities are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

LPAR capacities are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vcm_old_state : Final[Field] = Field(
    name='vcm_old_state',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""old VCM state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

old VCM state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vcm_old_state.__doc__ = """old VCM state(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

old VCM state

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

vcm_mpwq_updated : Final[Field] = Field(
    name='vcm_mpwq_updated',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""dispatcher affinity was updated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

dispatcher affinity was updated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
vcm_mpwq_updated.__doc__ = """dispatcher affinity was updated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

dispatcher affinity was updated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vcm_ptf_switched : Final[Field] = Field(
    name='vcm_ptf_switched',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""PTF was issued to initiate a switch opposite mode. However, the PTF return info tells us that we are already in the requested mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

PTF was issued to initiate a switch opposite mode. However, the PTF return info tells us that we are already in the requested mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vcm_ptf_switched.__doc__ = """PTF was issued to initiate a switch opposite mode. However, the PTF return info tells us that we are already in the requested mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

PTF was issued to initiate a switch opposite mode. However, the PTF return info tells us that we are already in the requested mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

vcm_transition : Final[Field] = Field(
    name='vcm_transition',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=vcm_flag2,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""VCM in transition to/from vertical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

VCM in transition to/from vertical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
vcm_transition.__doc__ = """VCM in transition to/from vertical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vcm_flag2`(`SMF99E_VCM_FLAG2`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

VCM in transition to/from vertical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

vcm_errorcode : Final[Field] = Field(
    name='vcm_errorcode',
    origin='SMF99E_VCM_ERRORCODE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""VCM error code

SMF Info
--------
    Field: `SMF99E_VCM_ERRORCODE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

VCM error code
"""
vcm_errorcode.__doc__ = """VCM error code

SMF Info
--------
    Field: `SMF99E_VCM_ERRORCODE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

VCM error code
"""

vcm_cpsperan : Final[Field] = Field(
    name='vcm_cpsperan',
    origin='SMF99E_VCM_CPSPERAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""CPUs/Cores per affinity node

SMF Info
--------
    Field: `SMF99E_VCM_CPSPERAN`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

CPUs/Cores per affinity node
"""
vcm_cpsperan.__doc__ = """CPUs/Cores per affinity node

SMF Info
--------
    Field: `SMF99E_VCM_CPSPERAN`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

CPUs/Cores per affinity node
"""

vcm_lparphysprocshr : Final[Field] = Field(
    name='vcm_lparphysprocshr',
    origin='SMF99E_VCM_LPARPHYSPROCSHR',
    post='core.scale',
    post_param=256,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""LPAR physical processor share for general CPUs/Cores scaled by 256

SMF Info
--------
    Field: `SMF99E_VCM_LPARPHYSPROCSHR`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

LPAR physical processor share for general CPUs/Cores scaled by 256

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `256`
"""
vcm_lparphysprocshr.__doc__ = """LPAR physical processor share for general CPUs/Cores scaled by 256

SMF Info
--------
    Field: `SMF99E_VCM_LPARPHYSPROCSHR`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

LPAR physical processor share for general CPUs/Cores scaled by 256

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `256`
"""

vcm_maxaffinityindex : Final[Field] = Field(
    name='vcm_maxaffinityindex',
    origin='SMF99E_VCM_MAXAFFINITYINDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""Maximum affinity index the system supports for the life of the IPL

SMF Info
--------
    Field: `SMF99E_VCM_MAXAFFINITYINDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

Maximum affinity index the system supports for the life of the IPL
"""
vcm_maxaffinityindex.__doc__ = """Maximum affinity index the system supports for the life of the IPL

SMF Info
--------
    Field: `SMF99E_VCM_MAXAFFINITYINDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

Maximum affinity index the system supports for the life of the IPL
"""

vcm_maxcpuidforipl : Final[Field] = Field(
    name='vcm_maxcpuidforipl',
    origin='SMF99E_VCM_MAXCPUIDFORIPL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""Maximum CPU ID/Core ID the system supports activating for the life of the IPL

SMF Info
--------
    Field: `SMF99E_VCM_MAXCPUIDFORIPL`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

Maximum CPU ID/Core ID the system supports activating for the life of the IPL
"""
vcm_maxcpuidforipl.__doc__ = """Maximum CPU ID/Core ID the system supports activating for the life of the IPL

SMF Info
--------
    Field: `SMF99E_VCM_MAXCPUIDFORIPL`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

Maximum CPU ID/Core ID the system supports activating for the life of the IPL
"""

vcm_hwlevel : Final[Field] = Field(
    name='vcm_hwlevel',
    origin='SMF99E_VCM_HWLEVEL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""HW level

SMF Info
--------
    Field: `SMF99E_VCM_HWLEVEL`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

HW level
"""
vcm_hwlevel.__doc__ = """HW level

SMF Info
--------
    Field: `SMF99E_VCM_HWLEVEL`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

HW level
"""

vcm_currtopo_tod : Final[Field] = Field(
    name='vcm_currtopo_tod',
    origin='SMF99E_VCM_CURRTOPO_TOD',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_HDR_MAP,
)
"""Timestamp of the STSI returned SYSIB 15.1.x information which is currently used by HiperDispatch

SMF Info
--------
    Field: `SMF99E_VCM_CURRTOPO_TOD`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

Timestamp of the STSI returned SYSIB 15.1.x information which is currently used by HiperDispatch
"""
vcm_currtopo_tod.__doc__ = """Timestamp of the STSI returned SYSIB 15.1.x information which is currently used by HiperDispatch

SMF Info
--------
    Field: `SMF99E_VCM_CURRTOPO_TOD`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_HDR_MAP`

Timestamp of the STSI returned SYSIB 15.1.x information which is currently used by HiperDispatch
"""

hd_topochg_cpu_index : Final[Field] = Field(
    name='hd_topochg_cpu_index',
    origin='SMF99E_HD_TOPOCHG_CPU_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Logical CPU/Core number

SMF Info
--------
    Field: `SMF99E_HD_TOPOCHG_CPU_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Logical CPU/Core number
"""
hd_topochg_cpu_index.__doc__ = """Logical CPU/Core number

SMF Info
--------
    Field: `SMF99E_HD_TOPOCHG_CPU_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Logical CPU/Core number
"""

cp_cputype : Final[Field] = Field(
    name='cp_cputype',
    origin='SMF99E_CP_CPUTYPE',
    post='core.map',
    post_param={'default': 'unknown', 'map': {0: 'CP', 5: 'zIIP'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""CPU/Core type

SMF Info
--------
    Field: `SMF99E_CP_CPUTYPE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

CPU/Core type

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `unknown`)::

    0 => CP
    5 => zIIP
"""
cp_cputype.__doc__ = """CPU/Core type

SMF Info
--------
    Field: `SMF99E_CP_CPUTYPE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

CPU/Core type

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `unknown`)::

    0 => CP
    5 => zIIP
"""

cp_misc : Final[Field] = Field(
    name='cp_misc',
    origin='SMF99E_CP_MISC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""CPU/Core misc. info

SMF Info
--------
    Field: `SMF99E_CP_MISC`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

CPU/Core misc. info
"""
cp_misc.__doc__ = """CPU/Core misc. info

SMF Info
--------
    Field: `SMF99E_CP_MISC`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

CPU/Core misc. info
"""

e_cp_polar : Final[Field] = Field(
    name='e_cp_polar',
    origin='SMF99E_CP_POLAR',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""CPU/Core polarization

SMF Info
--------
    Field: `SMF99E_CP_POLAR`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

CPU/Core polarization
"""
e_cp_polar.__doc__ = """CPU/Core polarization

SMF Info
--------
    Field: `SMF99E_CP_POLAR`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

CPU/Core polarization
"""

cp_nl2 : Final[Field] = Field(
    name='cp_nl2',
    origin='SMF99E_CP_NL2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99E_CP_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Not available
"""
cp_nl2.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99E_CP_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Not available
"""

cp_nl1 : Final[Field] = Field(
    name='cp_nl1',
    origin='SMF99E_CP_NL1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99E_CP_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Not available
"""
cp_nl1.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99E_CP_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Not available
"""

cp_cap : Final[Field] = Field(
    name='cp_cap',
    origin='SMF99E_CP_CAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""CPU/Core capacity in microseconds

SMF Info
--------
    Field: `SMF99E_CP_CAP`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

CPU/Core capacity in microseconds
"""
cp_cap.__doc__ = """CPU/Core capacity in microseconds

SMF Info
--------
    Field: `SMF99E_CP_CAP`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

CPU/Core capacity in microseconds
"""

cp_ci_nlinuse : Final[Field] = Field(
    name='cp_ci_nlinuse',
    origin='SMF99E_CP_CI_NLINUSE',
    post='core.map',
    post_param={'default': 'STISI_15_1_5', 'map': {0: 'STISI_15_1_20', 1: 'STISI_15_1_2', 2: 'STISI_15_1_3', 3: 'STISI_15_1_4', 4: 'STISI_15_1_4'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Number of highest nesting level in use in array SMF99E_CP_CI_NL. 0 = there is no container information available in SMF99E_CP_CI_NL

SMF Info
--------
    Field: `SMF99E_CP_CI_NLINUSE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Number of highest nesting level in use in array SMF99E_CP_CI_NL. 0 = there is no container information available in SMF99E_CP_CI_NL

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `STISI_15_1_5`)::

    0 => STISI_15_1_20
    1 => STISI_15_1_2
    2 => STISI_15_1_3
    3 => STISI_15_1_4
    4 => STISI_15_1_4
"""
cp_ci_nlinuse.__doc__ = """Number of highest nesting level in use in array SMF99E_CP_CI_NL. 0 = there is no container information available in SMF99E_CP_CI_NL

SMF Info
--------
    Field: `SMF99E_CP_CI_NLINUSE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Number of highest nesting level in use in array SMF99E_CP_CI_NL. 0 = there is no container information available in SMF99E_CP_CI_NL

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `STISI_15_1_5`)::

    0 => STISI_15_1_20
    1 => STISI_15_1_2
    2 => STISI_15_1_3
    3 => STISI_15_1_4
    4 => STISI_15_1_4
"""

cp_ci_flags : Final[Field] = Field(
    name='cp_ci_flags',
    origin='SMF99E_CP_CI_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Flags

SMF Info
--------
    Field: `SMF99E_CP_CI_FLAGS`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Flags
"""
cp_ci_flags.__doc__ = """Flags

SMF Info
--------
    Field: `SMF99E_CP_CI_FLAGS`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Flags
"""

cp_ci_notopoinfo : Final[Field] = Field(
    name='cp_ci_notopoinfo',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=cp_ci_flags,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""No CPU/Core topology information available in SMF99E_CP_TOPO(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cp_ci_flags`(`SMF99E_CP_CI_FLAGS`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

No CPU/Core topology information available in SMF99E_CP_TOPO

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cp_ci_notopoinfo.__doc__ = """No CPU/Core topology information available in SMF99E_CP_TOPO(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cp_ci_flags`(`SMF99E_CP_CI_FLAGS`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

No CPU/Core topology information available in SMF99E_CP_TOPO

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cp_ci_nl1 : Final[Field] = Field(
    name='cp_ci_nl1',
    origin='SMF99E_CP_CI_NL1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Container ID of nesting level 1

SMF Info
--------
    Field: `SMF99E_CP_CI_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 1
"""
cp_ci_nl1.__doc__ = """Container ID of nesting level 1

SMF Info
--------
    Field: `SMF99E_CP_CI_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 1
"""

cp_ci_nl2 : Final[Field] = Field(
    name='cp_ci_nl2',
    origin='SMF99E_CP_CI_NL2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Container ID of nesting level 2

SMF Info
--------
    Field: `SMF99E_CP_CI_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 2
"""
cp_ci_nl2.__doc__ = """Container ID of nesting level 2

SMF Info
--------
    Field: `SMF99E_CP_CI_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 2
"""

cp_ci_nl3 : Final[Field] = Field(
    name='cp_ci_nl3',
    origin='SMF99E_CP_CI_NL3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Container ID of nesting level 3

SMF Info
--------
    Field: `SMF99E_CP_CI_NL3`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 3
"""
cp_ci_nl3.__doc__ = """Container ID of nesting level 3

SMF Info
--------
    Field: `SMF99E_CP_CI_NL3`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 3
"""

cp_ci_nl4 : Final[Field] = Field(
    name='cp_ci_nl4',
    origin='SMF99E_CP_CI_NL4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Container ID of nesting level 4

SMF Info
--------
    Field: `SMF99E_CP_CI_NL4`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 4
"""
cp_ci_nl4.__doc__ = """Container ID of nesting level 4

SMF Info
--------
    Field: `SMF99E_CP_CI_NL4`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 4
"""

cp_ci_nl5 : Final[Field] = Field(
    name='cp_ci_nl5',
    origin='SMF99E_CP_CI_NL5',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""Container ID of nesting level 5

SMF Info
--------
    Field: `SMF99E_CP_CI_NL5`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 5
"""
cp_ci_nl5.__doc__ = """Container ID of nesting level 5

SMF Info
--------
    Field: `SMF99E_CP_CI_NL5`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Container ID of nesting level 5
"""

cp_polar : Final[Field] = Field(
    name='cp_polar',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 6, 'map': {'00': 'Horizontal', '01': 'Low', '10': 'Medium', '11': 'High'}},
    virtual=True,
    ref=cp_misc,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""CPU/Core polarization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cp_misc`(`SMF99E_CP_MISC`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `6`::

    00 => Horizontal
    01 => Low
    10 => Medium
    11 => High
"""
cp_polar.__doc__ = """CPU/Core polarization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cp_misc`(`SMF99E_CP_MISC`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `6`::

    00 => Horizontal
    01 => Low
    10 => Medium
    11 => High
"""

polar_n2 : Final[Field] = Field(
    name='polar_n2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=cp_misc,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""polarization infromation(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cp_misc`(`SMF99E_CP_MISC`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
polar_n2.__doc__ = """polarization infromation(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cp_misc`(`SMF99E_CP_MISC`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

polar_n1 : Final[Field] = Field(
    name='polar_n1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=cp_misc,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""polarization infromation(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cp_misc`(`SMF99E_CP_MISC`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
polar_n1.__doc__ = """polarization infromation(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cp_misc`(`SMF99E_CP_MISC`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

high : Final[Field] = Field(
    name='high',
    origin=None,
    post="core.inline",
    post_param=__high_inline_post,
    virtual=True,
    ref=[polar_n1, polar_n2],
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""None(V)

SMF Info (Virtual Field)
--------
    Field: Based on `polar_n1`(Virtual), `polar_n2`(Virtual)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.polar_n1 & df.polar_n2

"""
high.__doc__ = """None(V)

SMF Info (Virtual Field)
--------
    Field: Based on `polar_n1`(Virtual), `polar_n2`(Virtual)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.polar_n1 & df.polar_n2

"""

medium : Final[Field] = Field(
    name='medium',
    origin=None,
    post="core.inline",
    post_param=__medium_inline_post,
    virtual=True,
    ref=[polar_n1, polar_n2],
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""None(V)

SMF Info (Virtual Field)
--------
    Field: Based on `polar_n1`(Virtual), `polar_n2`(Virtual)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.polar_n1 & df.polar_n2

"""
medium.__doc__ = """None(V)

SMF Info (Virtual Field)
--------
    Field: Based on `polar_n1`(Virtual), `polar_n2`(Virtual)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.polar_n1 & df.polar_n2

"""

low : Final[Field] = Field(
    name='low',
    origin=None,
    post="core.inline",
    post_param=__low_inline_post,
    virtual=True,
    ref=[polar_n1, polar_n2],
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""None(V)

SMF Info (Virtual Field)
--------
    Field: Based on `polar_n1`(Virtual), `polar_n2`(Virtual)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.polar_n1 & df.polar_n2

"""
low.__doc__ = """None(V)

SMF Info (Virtual Field)
--------
    Field: Based on `polar_n1`(Virtual), `polar_n2`(Virtual)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.polar_n1 & df.polar_n2

"""

processor : Final[Field] = Field(
    name='processor',
    origin=None,
    post="core.inline",
    post_param=__processor_inline_post,
    virtual=True,
    ref=[high, medium, low],
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_CPU_MAP,
)
"""processor type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `high`(Virtual), `medium`(Virtual), `low`(Virtual)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    high_filter = ~df.high
    medium_filter = ~df.medium
    low_filter = ~df.low
    processor = df.high.where(df.high, '')
    processor =  processor.where(high_filter, 'High')
    processor =  processor.where(medium_filter, 'Medium')
    processor =  processor.where(low_filter, 'Low')
    return processor

"""
processor.__doc__ = """processor type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `high`(Virtual), `medium`(Virtual), `low`(Virtual)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_CPU_MAP`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    high_filter = ~df.high
    medium_filter = ~df.medium
    low_filter = ~df.low
    processor = df.high.where(df.high, '')
    processor =  processor.where(high_filter, 'High')
    processor =  processor.where(medium_filter, 'Medium')
    processor =  processor.where(low_filter, 'Low')
    return processor

"""

hd_topochg_node_index : Final[Field] = Field(
    name='hd_topochg_node_index',
    origin='SMF99E_HD_TOPOCHG_NODE_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Node number

SMF Info
--------
    Field: `SMF99E_HD_TOPOCHG_NODE_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Node number
"""
hd_topochg_node_index.__doc__ = """Node number

SMF Info
--------
    Field: `SMF99E_HD_TOPOCHG_NODE_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Node number
"""

cpu_type : Final[Field] = Field(
    name='cpu_type',
    origin='SMF99E_AN_CPUTYPE',
    post='core.map',
    post_param={'default': 'unknown', 'map': {0: 'CP', 5: 'zIIP'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""CPU/Core type

SMF Info
--------
    Field: `SMF99E_AN_CPUTYPE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

CPU/Core type

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `unknown`)::

    0 => CP
    5 => zIIP
"""
cpu_type.__doc__ = """CPU/Core type

SMF Info
--------
    Field: `SMF99E_AN_CPUTYPE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

CPU/Core type

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `unknown`)::

    0 => CP
    5 => zIIP
"""

an_polarhi : Final[Field] = Field(
    name='an_polarhi',
    origin='SMF99E_AN_POLARHI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Number of VHs in this affinity node

SMF Info
--------
    Field: `SMF99E_AN_POLARHI`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Number of VHs in this affinity node
"""
an_polarhi.__doc__ = """Number of VHs in this affinity node

SMF Info
--------
    Field: `SMF99E_AN_POLARHI`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Number of VHs in this affinity node
"""

an_polarmed : Final[Field] = Field(
    name='an_polarmed',
    origin='SMF99E_AN_POLARMED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Number of VMs in this affinity node

SMF Info
--------
    Field: `SMF99E_AN_POLARMED`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Number of VMs in this affinity node
"""
an_polarmed.__doc__ = """Number of VMs in this affinity node

SMF Info
--------
    Field: `SMF99E_AN_POLARMED`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Number of VMs in this affinity node
"""

an_polarlow : Final[Field] = Field(
    name='an_polarlow',
    origin='SMF99E_AN_POLARLOW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Number of VLs in this affinity node

SMF Info
--------
    Field: `SMF99E_AN_POLARLOW`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Number of VLs in this affinity node
"""
an_polarlow.__doc__ = """Number of VLs in this affinity node

SMF Info
--------
    Field: `SMF99E_AN_POLARLOW`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Number of VLs in this affinity node
"""

vcm_an_nl2 : Final[Field] = Field(
    name='vcm_an_nl2',
    origin='SMF99E_VCM_AN_NL2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99E_VCM_AN_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Not available
"""
vcm_an_nl2.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99E_VCM_AN_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Not available
"""

vcm_an_nl1 : Final[Field] = Field(
    name='vcm_an_nl1',
    origin='SMF99E_VCM_AN_NL1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Not available

SMF Info
--------
    Field: `SMF99E_VCM_AN_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Not available
"""
vcm_an_nl1.__doc__ = """Not available

SMF Info
--------
    Field: `SMF99E_VCM_AN_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Not available
"""

an_flags : Final[Field] = Field(
    name='an_flags',
    origin='SMF99E_AN_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""flags

SMF Info
--------
    Field: `SMF99E_AN_FLAGS`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

flags
"""
an_flags.__doc__ = """flags

SMF Info
--------
    Field: `SMF99E_AN_FLAGS`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

flags
"""

vcm_an_bdycrossing : Final[Field] = Field(
    name='vcm_an_bdycrossing',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=an_flags,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""CPs on this node are boundary crossing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `an_flags`(`SMF99E_AN_FLAGS`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

CPs on this node are boundary crossing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vcm_an_bdycrossing.__doc__ = """CPs on this node are boundary crossing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `an_flags`(`SMF99E_AN_FLAGS`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

CPs on this node are boundary crossing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

vcm_an_hnsbdycrossing : Final[Field] = Field(
    name='vcm_an_hnsbdycrossing',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=an_flags,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Helper nodes are boundary crossing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `an_flags`(`SMF99E_AN_FLAGS`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Helper nodes are boundary crossing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
vcm_an_hnsbdycrossing.__doc__ = """Helper nodes are boundary crossing.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `an_flags`(`SMF99E_AN_FLAGS`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Helper nodes are boundary crossing.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

an_cap : Final[Field] = Field(
    name='an_cap',
    origin='SMF99E_AN_CAP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""capacity of affinity node in microseconds

SMF Info
--------
    Field: `SMF99E_AN_CAP`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

capacity of affinity node in microseconds
"""
an_cap.__doc__ = """capacity of affinity node in microseconds

SMF Info
--------
    Field: `SMF99E_AN_CAP`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

capacity of affinity node in microseconds
"""

an_ci_nlinuse : Final[Field] = Field(
    name='an_ci_nlinuse',
    origin='SMF99E_AN_CI_NLINUSE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Number of highest nesting level in use in array SMF99E_AN_CI_NL. 0 = there is no container information available in SMF99E_AN_CI_NL

SMF Info
--------
    Field: `SMF99E_AN_CI_NLINUSE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Number of highest nesting level in use in array SMF99E_AN_CI_NL. 0 = there is no container information available in SMF99E_AN_CI_NL
"""
an_ci_nlinuse.__doc__ = """Number of highest nesting level in use in array SMF99E_AN_CI_NL. 0 = there is no container information available in SMF99E_AN_CI_NL

SMF Info
--------
    Field: `SMF99E_AN_CI_NLINUSE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Number of highest nesting level in use in array SMF99E_AN_CI_NL. 0 = there is no container information available in SMF99E_AN_CI_NL
"""

an_ci_flags : Final[Field] = Field(
    name='an_ci_flags',
    origin='SMF99E_AN_CI_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Flags

SMF Info
--------
    Field: `SMF99E_AN_CI_FLAGS`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Flags
"""
an_ci_flags.__doc__ = """Flags

SMF Info
--------
    Field: `SMF99E_AN_CI_FLAGS`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Flags
"""

an_ci_notopoinfo : Final[Field] = Field(
    name='an_ci_notopoinfo',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=an_ci_flags,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""No CPU/Core topology information available in SMF99E_AN_TOPO(V)

SMF Info (Virtual Field)
--------
    Field: Based on `an_ci_flags`(`SMF99E_AN_CI_FLAGS`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

No CPU/Core topology information available in SMF99E_AN_TOPO

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
an_ci_notopoinfo.__doc__ = """No CPU/Core topology information available in SMF99E_AN_TOPO(V)

SMF Info (Virtual Field)
--------
    Field: Based on `an_ci_flags`(`SMF99E_AN_CI_FLAGS`)
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

No CPU/Core topology information available in SMF99E_AN_TOPO

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

an_ci_nl1 : Final[Field] = Field(
    name='an_ci_nl1',
    origin='SMF99E_AN_CI_NL1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Container ID of nesting level 1

SMF Info
--------
    Field: `SMF99E_AN_CI_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 1
"""
an_ci_nl1.__doc__ = """Container ID of nesting level 1

SMF Info
--------
    Field: `SMF99E_AN_CI_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 1
"""

an_ci_nl2 : Final[Field] = Field(
    name='an_ci_nl2',
    origin='SMF99E_AN_CI_NL2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Container ID of nesting level 2

SMF Info
--------
    Field: `SMF99E_AN_CI_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 2
"""
an_ci_nl2.__doc__ = """Container ID of nesting level 2

SMF Info
--------
    Field: `SMF99E_AN_CI_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 2
"""

an_ci_nl3 : Final[Field] = Field(
    name='an_ci_nl3',
    origin='SMF99E_AN_CI_NL3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Container ID of nesting level 3

SMF Info
--------
    Field: `SMF99E_AN_CI_NL3`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 3
"""
an_ci_nl3.__doc__ = """Container ID of nesting level 3

SMF Info
--------
    Field: `SMF99E_AN_CI_NL3`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 3
"""

an_ci_nl4 : Final[Field] = Field(
    name='an_ci_nl4',
    origin='SMF99E_AN_CI_NL4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Container ID of nesting level 4

SMF Info
--------
    Field: `SMF99E_AN_CI_NL4`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 4
"""
an_ci_nl4.__doc__ = """Container ID of nesting level 4

SMF Info
--------
    Field: `SMF99E_AN_CI_NL4`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 4
"""

an_ci_nl5 : Final[Field] = Field(
    name='an_ci_nl5',
    origin='SMF99E_AN_CI_NL5',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_NODE_MAP,
)
"""Container ID of nesting level 5

SMF Info
--------
    Field: `SMF99E_AN_CI_NL5`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 5
"""
an_ci_nl5.__doc__ = """Container ID of nesting level 5

SMF Info
--------
    Field: `SMF99E_AN_CI_NL5`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_NODE_MAP`

Container ID of nesting level 5
"""

hd_topochg_mpwq_cpu_index : Final[Field] = Field(
    name='hd_topochg_mpwq_cpu_index',
    origin='SMF99E_HD_TOPOCHG_MPWQ_CPU_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP,
)
"""MPWQ CPU/Core Number

SMF Info
--------
    Field: `SMF99E_HD_TOPOCHG_MPWQ_CPU_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP`

MPWQ CPU/Core Number
"""
hd_topochg_mpwq_cpu_index.__doc__ = """MPWQ CPU/Core Number

SMF Info
--------
    Field: `SMF99E_HD_TOPOCHG_MPWQ_CPU_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP`

MPWQ CPU/Core Number
"""

mpwq_affinity_node : Final[Field] = Field(
    name='mpwq_affinity_node',
    origin='SMF99E_MPWQ_AFFINITY_NODE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP,
)
"""affinity node this CPU/Core belongs to

SMF Info
--------
    Field: `SMF99E_MPWQ_AFFINITY_NODE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP`

affinity node this CPU/Core belongs to
"""
mpwq_affinity_node.__doc__ = """affinity node this CPU/Core belongs to

SMF Info
--------
    Field: `SMF99E_MPWQ_AFFINITY_NODE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP`

affinity node this CPU/Core belongs to
"""

mpwq_share : Final[Field] = Field(
    name='mpwq_share',
    origin='SMF99E_MPWQ_SHARE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP,
)
"""CPU/Core share

SMF Info
--------
    Field: `SMF99E_MPWQ_SHARE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP`

CPU/Core share
"""
mpwq_share.__doc__ = """CPU/Core share

SMF Info
--------
    Field: `SMF99E_MPWQ_SHARE`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_CPU_MAP`

CPU/Core share
"""

hd_topochg_mpwq_node_index : Final[Field] = Field(
    name='hd_topochg_mpwq_node_index',
    origin='SMF99E_HD_TOPOCHG_MPWQ_NODE_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP,
)
"""MPWQ Node Number

SMF Info
--------
    Field: `SMF99E_HD_TOPOCHG_MPWQ_NODE_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

MPWQ Node Number
"""
hd_topochg_mpwq_node_index.__doc__ = """MPWQ Node Number

SMF Info
--------
    Field: `SMF99E_HD_TOPOCHG_MPWQ_NODE_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

MPWQ Node Number
"""

mpwq_book_crossing_index : Final[Field] = Field(
    name='mpwq_book_crossing_index',
    origin='SMF99E_MPWQ_BOOK_CROSSING_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP,
)
"""book crossing index

SMF Info
--------
    Field: `SMF99E_MPWQ_BOOK_CROSSING_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

book crossing index
"""
mpwq_book_crossing_index.__doc__ = """book crossing index

SMF Info
--------
    Field: `SMF99E_MPWQ_BOOK_CROSSING_INDEX`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

book crossing index
"""

mpwq_contcrossindex_nl1 : Final[Field] = Field(
    name='mpwq_contcrossindex_nl1',
    origin='SMF99E_MPWQ_CONTCROSSINDEX_NL1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP,
)
"""Container crossing index of nesting level 1

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 1
"""
mpwq_contcrossindex_nl1.__doc__ = """Container crossing index of nesting level 1

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL1`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 1
"""

mpwq_contcrossindex_nl2 : Final[Field] = Field(
    name='mpwq_contcrossindex_nl2',
    origin='SMF99E_MPWQ_CONTCROSSINDEX_NL2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP,
)
"""Container crossing index of nesting level 2

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 2
"""
mpwq_contcrossindex_nl2.__doc__ = """Container crossing index of nesting level 2

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL2`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 2
"""

mpwq_contcrossindex_nl3 : Final[Field] = Field(
    name='mpwq_contcrossindex_nl3',
    origin='SMF99E_MPWQ_CONTCROSSINDEX_NL3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP,
)
"""Container crossing index of nesting level 3

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL3`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 3
"""
mpwq_contcrossindex_nl3.__doc__ = """Container crossing index of nesting level 3

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL3`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 3
"""

mpwq_contcrossindex_nl4 : Final[Field] = Field(
    name='mpwq_contcrossindex_nl4',
    origin='SMF99E_MPWQ_CONTCROSSINDEX_NL4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP,
)
"""Container crossing index of nesting level 4

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL4`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 4
"""
mpwq_contcrossindex_nl4.__doc__ = """Container crossing index of nesting level 4

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL4`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 4
"""

mpwq_contcrossindex_nl5 : Final[Field] = Field(
    name='mpwq_contcrossindex_nl5',
    origin='SMF99E_MPWQ_CONTCROSSINDEX_NL5',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP,
)
"""Container crossing index of nesting level 5

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL5`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 5
"""
mpwq_contcrossindex_nl5.__doc__ = """Container crossing index of nesting level 5

SMF Info
--------
    Field: `SMF99E_MPWQ_CONTCROSSINDEX_NL5`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Container crossing index of nesting level 5
"""

mpwq_highestcontcross : Final[Field] = Field(
    name='mpwq_highestcontcross',
    origin='SMF99E_MPWQ_HIGHESTCONTCROSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP,
)
"""The highest container crossing for Cores assigned to this node

SMF Info
--------
    Field: `SMF99E_MPWQ_HIGHESTCONTCROSS`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

The highest container crossing for Cores assigned to this node
"""
mpwq_highestcontcross.__doc__ = """The highest container crossing for Cores assigned to this node

SMF Info
--------
    Field: `SMF99E_MPWQ_HIGHESTCONTCROSS`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

The highest container crossing for Cores assigned to this node
"""

mpwq_help_nodes : Final[Field] = Field(
    name='mpwq_help_nodes',
    origin='SMF99E_MPWQ_HELP_NODES',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP,
    pseudo_field = PseudoField.ARRAY_FIELD,
    array_index = 44,
)
"""Array of helper nodes of this aff.node. Only the first 44 helper nodes are supported.

SMF Info
--------
    Field: `SMF99E_MPWQ_HELP_NODES`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Array of helper nodes of this aff.node. Only the first 44 helper nodes are supported.
"""
mpwq_help_nodes.__doc__ = """Array of helper nodes of this aff.node. Only the first 44 helper nodes are supported.

SMF Info
--------
    Field: `SMF99E_MPWQ_HELP_NODES`
    Record: `SMF99S14`
    Map: `SMF99_S14_HD_TOPOCHG_MPWQ_HNODE_MAP`

Array of helper nodes of this aff.node. Only the first 44 helper nodes are supported.
"""
