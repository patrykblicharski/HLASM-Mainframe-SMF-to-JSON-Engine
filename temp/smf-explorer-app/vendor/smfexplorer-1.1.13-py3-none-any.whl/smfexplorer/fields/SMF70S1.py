# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 70 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=70,
                                smf_subtype=1,
                                spec='SMF 70 Subtype 1',
                                post=None)
"""SMF 70 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __interval_in_milliseconds_inline_post(df):
    return df.interval.dt.total_seconds() * 1e3


def __cpu_adjustment_factor_inline_post(df):
    return df.cpu_adjustment_factor_actual / df.cpa_scaling_factor

def __cpu_adjustment_factor_effective_inline_post(df):
    cpa_actual_filter = (df.cpu_adjustment_factor_actual != 0) & (df.cpu_control_section_length > 224)
    return df.cpu_adjustment_factor_actual.where(cpa_actual_filter, df.cpu_adjustment_factor)


def __cpa_scaling_factor_effective_inline_post(df):
    cpa_actual_filter = (df.cpu_adjustment_factor_actual != 0) & (df.cpu_control_section_length > 224)
    return df.cpa_scaling_factor.where(cpa_actual_filter, 1)


def __rate_io_interrupt_inline_post(df):
    return (df.count_slh + df.count_tpi) / df.interval.dt.total_seconds()


def __rate_io_interrupt_by_tpi_inline_post(df):
    rate_io_interrupt_by_tpi = df.count_tpi * 1e2 / (df.count_slh + df.count_tpi)
    return rate_io_interrupt_by_tpi.fillna(0)


def __cpu_parked_percentage_inline_post(df):
    return df.cpu_parked_time / df.interval


def __cpu_busy_time_inline_post(df):
    cpu_busy_time = df.interval - df.cpu_wait_time - df.cpu_parked_time
    invalid_filter = df.cpu_is_online & (cpu_busy_time.dt.total_seconds() >= 0.0)
    return cpu_busy_time.where(df.cpu_is_online, pd.Timedelta(0))


def __rate_tcb_inline_post(df):
    return df.count_tcb * 1e3 / df.interval_in_milliseconds


def __rate_srb_inline_post(df):
    return df.count_srb * 1e3 / df.interval_in_milliseconds


def __rate_io_inline_post(df):
    return df.count_io * 1e3 / df.interval_in_milliseconds


def __lpar_system_name_inline_post(df):
    return df.lpar_name.str.strip().str.cat(df.system_name, '-')


def __msu_physical_inline_post(df):
    return df.dispatch_time_total * 16 * df.cpa_scaling_factor_effective / df.cpu_adjustment_factor_effective * 3.6 / df.interval_in_milliseconds


def __processor_weight_online_inline_post(df):
    valid_filter = df.logical_processor_online_time > 0
    return df.processor_weight.where(valid_filter, 0)


def __msu_effective_inline_post(df):
    return df.dispatch_time_effective * 16 * df.cpa_scaling_factor_effective / df.cpu_adjustment_factor_effective * 3.6 / df.interval_in_milliseconds


def __share_current_inline_post(df):
    zero_samples = df.sample_diagnose == 0
    divided_share = df.share_actual / df.sample_diagnose
    share_actual = df.share_actual.astype('float')
    share_current = share_actual.where(zero_samples, divided_share)
    nonzero_current_share = share_current > 0
    return share_current.where(nonzero_current_share, df.processor_weight)


def __logical_processor_is_online_inline_post(df):
    return df.logical_processor_online_time > 0


def __cpu_unparked_time_inline_post(df):
    cpu_unparked_time = df.interval - df.cpu_parked_time
    invalid_filter = df.cpu_is_online & (df.cpu_busy_time.dt.total_seconds() >= 0)
    return cpu_unparked_time.where(invalid_filter, pd.Timedelta(0))


def __cpu_unparked_percentage_inline_post(df):
    return df.cpu_unparked_time / df.interval


def __cpu_busy_percentage_inline_post(df):
    cpu_busy_percentage = df.cpu_busy_time * df.cpu_unparked_percentage / df.cpu_unparked_time
    return cpu_busy_percentage.fillna(0)


def __mvs_busy_percentage_inline_post(df):
    return df.cpu_busy_percentage * 100 / df.unparked_percentage


def __utilization_per_cpu_physical_inline_post(df):
    utilization_per_cpu_physical = 100 * df.dispatch_time_total / df.logical_processor_online_time
    utilization_per_cpu_physical = utilization_per_cpu_physical / df.cpu_count
    return utilization_per_cpu_physical.fillna(0)


def __lpar_management_per_cpu_inline_post(df):
    lpar_management_per_cpu = 100 * (df.dispatch_time_total - df.dispatch_time_effective) / df.logical_processor_online_time
    lpar_management_per_cpu = lpar_management_per_cpu / df.cpu_count
    return lpar_management_per_cpu.fillna(0)



SMF70PRO: Final[RecordMap] = RecordMap(
    origin='SMF70PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=True)
"""RMF Product Section"""
SMF70AID: Final[RecordMap] = RecordMap(
    origin='SMF70AID',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='ASID DATA SECTION',
    post=None,
    record_mapping=False)
"""ASID DATA SECTION"""
SMF70CTL: Final[RecordMap] = RecordMap(
    origin='SMF70CTL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='CPU CONTROL SECTION',
    post=None,
    record_mapping=False)
"""CPU CONTROL SECTION"""
SMF70CPU: Final[RecordMap] = RecordMap(
    origin='SMF70CPU',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='CPU DATA SECTION',
    post=None,
    record_mapping=False)
"""CPU DATA SECTION"""
SMF70BCT: Final[RecordMap] = RecordMap(
    origin='SMF70BCT',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='PR/SM PARTITION DATA SECTION There is one section per configured parti...',
    post=None,
    record_mapping=False)
"""PR/SM PARTITION DATA SECTION There is one section per configured parti..."""
SMF70BPD: Final[RecordMap] = RecordMap(
    origin='SMF70BPD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='PR/SM Logical Processor Data Section. There is one data section per lo...',
    post=None,
    record_mapping=False)
"""PR/SM Logical Processor Data Section. There is one data section per lo..."""
SMF70CIS: Final[RecordMap] = RecordMap(
    origin='SMF70CIS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='CPU-identification name Section. There is one section per EBCDIC name ...',
    post=None,
    record_mapping=False)
"""CPU-identification name Section. There is one section per EBCDIC name ..."""
SMF70LCS: Final[RecordMap] = RecordMap(
    origin='SMF70LCS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Logical Core Data Section. This section contains usage information for...',
    post=None,
    record_mapping=False)
"""Logical Core Data Section. This section contains usage information for..."""
SMF70TNT: Final[RecordMap] = RecordMap(
    origin='SMF70TNT',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Tenant Resource Group (TRG) Data Section.',
    post=None,
    record_mapping=False)
"""Tenant Resource Group (TRG) Data Section."""

date : Final[Field] = Field(
    name='date',
    origin='SMF70DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF70DTE`
    Record: `SMF70S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF70DTE`
    Record: `SMF70S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF70TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF70TME`
    Record: `SMF70S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF70TME`
    Record: `SMF70S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF70DTE`), `time`(`SMF70TME`)
    Record: `SMF70S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF70DTE`), `time`(`SMF70TME`)
    Record: `SMF70S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF70LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF70LEN`
    Record: `SMF70S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF70LEN`
    Record: `SMF70S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF70SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF70SEG`
    Record: `SMF70S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF70SEG`
    Record: `SMF70S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF70FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF70FLG`
    Record: `SMF70S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF70FLG`
    Record: `SMF70S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

new_record : Final[Field] = Field(
    name='new_record',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
new_record.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

subtypes_used : Final[Field] = Field(
    name='subtypes_used',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
subtypes_used.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF70RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF70RTY`
    Record: `SMF70S1`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF70RTY`
    Record: `SMF70S1`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF70TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF70TME`
    Record: `SMF70S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF70TME`
    Record: `SMF70S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF70DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF70DTE`
    Record: `SMF70S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF70DTE`
    Record: `SMF70S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF70SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF70SID`
    Record: `SMF70S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF70SID`
    Record: `SMF70S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF70SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF70SSI`
    Record: `SMF70S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF70SSI`
    Record: `SMF70S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF70STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF70STY`
    Record: `SMF70S1`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF70STY`
    Record: `SMF70S1`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF70TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF70TRN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF70TRN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF70PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF70PRS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF70PRS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF70PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF70PRL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF70PRL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF70PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF70PRN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF70PRN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

ccs : Final[Field] = Field(
    name='ccs',
    origin='SMF70CCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO CPU CONTROL SECTION

SMF Info
--------
    Field: `SMF70CCS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO CPU CONTROL SECTION
"""
ccs.__doc__ = """OFFSET TO CPU CONTROL SECTION

SMF Info
--------
    Field: `SMF70CCS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO CPU CONTROL SECTION
"""

cpu_control_section_length : Final[Field] = Field(
    name='cpu_control_section_length',
    origin='SMF70CCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF CPU CONTROL SECTION

SMF Info
--------
    Field: `SMF70CCL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF CPU CONTROL SECTION
"""
cpu_control_section_length.__doc__ = """LENGTH OF CPU CONTROL SECTION

SMF Info
--------
    Field: `SMF70CCL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF CPU CONTROL SECTION
"""

ccn : Final[Field] = Field(
    name='ccn',
    origin='SMF70CCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF CPU CONTROL SECTIONS

SMF Info
--------
    Field: `SMF70CCN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF CPU CONTROL SECTIONS
"""
ccn.__doc__ = """NUMBER OF CPU CONTROL SECTIONS

SMF Info
--------
    Field: `SMF70CCN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF CPU CONTROL SECTIONS
"""

cps : Final[Field] = Field(
    name='cps',
    origin='SMF70CPS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO CPU DATA SECTION

SMF Info
--------
    Field: `SMF70CPS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO CPU DATA SECTION
"""
cps.__doc__ = """OFFSET TO CPU DATA SECTION

SMF Info
--------
    Field: `SMF70CPS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO CPU DATA SECTION
"""

cpl : Final[Field] = Field(
    name='cpl',
    origin='SMF70CPL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF CPU DATA SECTION

SMF Info
--------
    Field: `SMF70CPL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF CPU DATA SECTION
"""
cpl.__doc__ = """LENGTH OF CPU DATA SECTION

SMF Info
--------
    Field: `SMF70CPL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF CPU DATA SECTION
"""

cpn : Final[Field] = Field(
    name='cpn',
    origin='SMF70CPN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF CPU DATA SECTIONS

SMF Info
--------
    Field: `SMF70CPN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF CPU DATA SECTIONS
"""
cpn.__doc__ = """NUMBER OF CPU DATA SECTIONS

SMF Info
--------
    Field: `SMF70CPN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF CPU DATA SECTIONS
"""

ass : Final[Field] = Field(
    name='ass',
    origin='SMF70ASS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO ASID DATA SECTION

SMF Info
--------
    Field: `SMF70ASS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO ASID DATA SECTION
"""
ass.__doc__ = """OFFSET TO ASID DATA SECTION

SMF Info
--------
    Field: `SMF70ASS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO ASID DATA SECTION
"""

asl : Final[Field] = Field(
    name='asl',
    origin='SMF70ASL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF ASID DATA SECTION

SMF Info
--------
    Field: `SMF70ASL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF ASID DATA SECTION
"""
asl.__doc__ = """LENGTH OF ASID DATA SECTION

SMF Info
--------
    Field: `SMF70ASL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF ASID DATA SECTION
"""

asn : Final[Field] = Field(
    name='asn',
    origin='SMF70ASN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF ASID DATA SECTIONS

SMF Info
--------
    Field: `SMF70ASN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF ASID DATA SECTIONS
"""
asn.__doc__ = """NUMBER OF ASID DATA SECTIONS

SMF Info
--------
    Field: `SMF70ASN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF ASID DATA SECTIONS
"""

bcs : Final[Field] = Field(
    name='bcs',
    origin='SMF70BCS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO PR/SM PARTITION DATA SECTIONS

SMF Info
--------
    Field: `SMF70BCS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO PR/SM PARTITION DATA SECTIONS
"""
bcs.__doc__ = """OFFSET TO PR/SM PARTITION DATA SECTIONS

SMF Info
--------
    Field: `SMF70BCS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO PR/SM PARTITION DATA SECTIONS
"""

bcl : Final[Field] = Field(
    name='bcl',
    origin='SMF70BCL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF PR/SM PARTITION DATA SECTIONS

SMF Info
--------
    Field: `SMF70BCL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF PR/SM PARTITION DATA SECTIONS
"""
bcl.__doc__ = """LENGTH OF PR/SM PARTITION DATA SECTIONS

SMF Info
--------
    Field: `SMF70BCL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF PR/SM PARTITION DATA SECTIONS
"""

bcn : Final[Field] = Field(
    name='bcn',
    origin='SMF70BCN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF PR/SM PARTITION DATA SECTIONS

SMF Info
--------
    Field: `SMF70BCN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF PR/SM PARTITION DATA SECTIONS
"""
bcn.__doc__ = """NUMBER OF PR/SM PARTITION DATA SECTIONS

SMF Info
--------
    Field: `SMF70BCN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF PR/SM PARTITION DATA SECTIONS
"""

bvs : Final[Field] = Field(
    name='bvs',
    origin='SMF70BVS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO PR/SM LOGICAL PROCESSOR DATA SECTIONS

SMF Info
--------
    Field: `SMF70BVS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO PR/SM LOGICAL PROCESSOR DATA SECTIONS
"""
bvs.__doc__ = """OFFSET TO PR/SM LOGICAL PROCESSOR DATA SECTIONS

SMF Info
--------
    Field: `SMF70BVS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO PR/SM LOGICAL PROCESSOR DATA SECTIONS
"""

bvl : Final[Field] = Field(
    name='bvl',
    origin='SMF70BVL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF PR/SM LOGICAL PROCESSOR DATA SECTIONS

SMF Info
--------
    Field: `SMF70BVL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF PR/SM LOGICAL PROCESSOR DATA SECTIONS
"""
bvl.__doc__ = """LENGTH OF PR/SM LOGICAL PROCESSOR DATA SECTIONS

SMF Info
--------
    Field: `SMF70BVL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF PR/SM LOGICAL PROCESSOR DATA SECTIONS
"""

bvn : Final[Field] = Field(
    name='bvn',
    origin='SMF70BVN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF PR/SM LOGICAL PROCESSOR DATA SECTIONS

SMF Info
--------
    Field: `SMF70BVN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF PR/SM LOGICAL PROCESSOR DATA SECTIONS
"""
bvn.__doc__ = """NUMBER OF PR/SM LOGICAL PROCESSOR DATA SECTIONS

SMF Info
--------
    Field: `SMF70BVN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF PR/SM LOGICAL PROCESSOR DATA SECTIONS
"""

cns : Final[Field] = Field(
    name='cns',
    origin='SMF70CNS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO CPU-IDENTIFICATION NAME SECTIONS

SMF Info
--------
    Field: `SMF70CNS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO CPU-IDENTIFICATION NAME SECTIONS
"""
cns.__doc__ = """OFFSET TO CPU-IDENTIFICATION NAME SECTIONS

SMF Info
--------
    Field: `SMF70CNS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO CPU-IDENTIFICATION NAME SECTIONS
"""

cnl : Final[Field] = Field(
    name='cnl',
    origin='SMF70CNL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF CPU-IDENTIFICATION NAME SECTIONS

SMF Info
--------
    Field: `SMF70CNL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF CPU-IDENTIFICATION NAME SECTIONS
"""
cnl.__doc__ = """LENGTH OF CPU-IDENTIFICATION NAME SECTIONS

SMF Info
--------
    Field: `SMF70CNL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF CPU-IDENTIFICATION NAME SECTIONS
"""

cnn : Final[Field] = Field(
    name='cnn',
    origin='SMF70CNN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF CPU-IDENTIFICATION NAME SECTIONS

SMF Info
--------
    Field: `SMF70CNN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF CPU-IDENTIFICATION NAME SECTIONS
"""
cnn.__doc__ = """NUMBER OF CPU-IDENTIFICATION NAME SECTIONS

SMF Info
--------
    Field: `SMF70CNN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF CPU-IDENTIFICATION NAME SECTIONS
"""

cos : Final[Field] = Field(
    name='cos',
    origin='SMF70COS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO LOGICAL CORE DATA SECTIONS

SMF Info
--------
    Field: `SMF70COS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO LOGICAL CORE DATA SECTIONS
"""
cos.__doc__ = """OFFSET TO LOGICAL CORE DATA SECTIONS

SMF Info
--------
    Field: `SMF70COS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO LOGICAL CORE DATA SECTIONS
"""

col : Final[Field] = Field(
    name='col',
    origin='SMF70COL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF LOGICAL CORE DATA SECTION

SMF Info
--------
    Field: `SMF70COL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF LOGICAL CORE DATA SECTION
"""
col.__doc__ = """LENGTH OF LOGICAL CORE DATA SECTION

SMF Info
--------
    Field: `SMF70COL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF LOGICAL CORE DATA SECTION
"""

con : Final[Field] = Field(
    name='con',
    origin='SMF70CON',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF LOGICAL CORE DATA SECTIONS

SMF Info
--------
    Field: `SMF70CON`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF LOGICAL CORE DATA SECTIONS
"""
con.__doc__ = """NUMBER OF LOGICAL CORE DATA SECTIONS

SMF Info
--------
    Field: `SMF70CON`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF LOGICAL CORE DATA SECTIONS
"""

tns : Final[Field] = Field(
    name='tns',
    origin='SMF70TNS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO TENANT RESOURCE GROUP DATA SECTIONS

SMF Info
--------
    Field: `SMF70TNS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO TENANT RESOURCE GROUP DATA SECTIONS
"""
tns.__doc__ = """OFFSET TO TENANT RESOURCE GROUP DATA SECTIONS

SMF Info
--------
    Field: `SMF70TNS`
    Record: `SMF70S1`
    Map: Not part of a map

OFFSET TO TENANT RESOURCE GROUP DATA SECTIONS
"""

tnl : Final[Field] = Field(
    name='tnl',
    origin='SMF70TNL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF TENANT RESOURCE GROUP DATA SECTION

SMF Info
--------
    Field: `SMF70TNL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF TENANT RESOURCE GROUP DATA SECTION
"""
tnl.__doc__ = """LENGTH OF TENANT RESOURCE GROUP DATA SECTION

SMF Info
--------
    Field: `SMF70TNL`
    Record: `SMF70S1`
    Map: Not part of a map

LENGTH OF TENANT RESOURCE GROUP DATA SECTION
"""

tnn : Final[Field] = Field(
    name='tnn',
    origin='SMF70TNN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TENANT RESOURCE GROUP DATA SECTIONS

SMF Info
--------
    Field: `SMF70TNN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF TENANT RESOURCE GROUP DATA SECTIONS
"""
tnn.__doc__ = """NUMBER OF TENANT RESOURCE GROUP DATA SECTIONS

SMF Info
--------
    Field: `SMF70TNN`
    Record: `SMF70S1`
    Map: Not part of a map

NUMBER OF TENANT RESOURCE GROUP DATA SECTIONS
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF70MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF70MFV`
    Record: `SMF70S1`
    Map: `SMF70PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF70MFV`
    Record: `SMF70S1`
    Map: `SMF70PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF70PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF70PRD`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF70PRD`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF70IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF70PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF70IST`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF70IST`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF70DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF70PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF70DAT`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF70DAT`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Date monitor interval start
"""

interval : Final[Field] = Field(
    name='interval',
    origin='SMF70INT',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF70PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF70INT`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Duration of monitor interval
"""
interval.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF70INT`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF70SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF70SAM`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF70SAM`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF70FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF70FLA`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF70FLA`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF70CYC',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF70PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF70CYC`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF70CYC`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF70MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF70MVS`
    Record: `SMF70S1`
    Map: `SMF70PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF70MVS`
    Record: `SMF70S1`
    Map: `SMF70PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF70IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF70IML`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF70IML`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF70PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF70PRF`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF70PRF`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF70PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF70PTN`
    Record: `SMF70S1`
    Map: `SMF70PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF70PTN`
    Record: `SMF70S1`
    Map: `SMF70PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF70SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF70SRL`
    Record: `SMF70S1`
    Map: `SMF70PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF70SRL`
    Record: `SMF70S1`
    Map: `SMF70PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF70IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF70PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF70IET`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF70IET`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF70LGO',
    post='core.timedelta',
    post_param="""h""",
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF70LGO`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Offset GMT to local time

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `h`
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF70LGO`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Offset GMT to local time

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `h`
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF70RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF70RAO`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF70RAO`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF70RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF70RAL`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF70RAL`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF70RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF70RAN`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF70RAN`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF70OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF70OIL`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF70OIL`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF70SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF70SYN`
    Record: `SMF70S1`
    Map: `SMF70PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF70SYN`
    Record: `SMF70S1`
    Map: `SMF70PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF70GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF70PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF70GIE`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF70GIE`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF70XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF70XNM`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF70XNM`
    Record: `SMF70S1`
    Map: `SMF70PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF70SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF70SNM`
    Record: `SMF70S1`
    Map: `SMF70PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF70SNM`
    Record: `SMF70S1`
    Map: `SMF70PRO`

System name for current system as defined in CVTSNAME
"""

interval_in_milliseconds : Final[Field] = Field(
    name='interval_in_milliseconds',
    origin=None,
    post="core.inline",
    post_param=__interval_in_milliseconds_inline_post,
    virtual=True,
    ref=interval,
    record=record,
    record_map=SMF70PRO,
)
"""Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF70INT`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""
interval_in_milliseconds.__doc__ = """Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF70INT`)
    Record: `SMF70S1`
    Map: `SMF70PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""

rmn : Final[Field] = Field(
    name='rmn',
    origin='SMF70RMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""READY MINIMUM VALUE

SMF Info
--------
    Field: `SMF70RMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

READY MINIMUM VALUE
"""
rmn.__doc__ = """READY MINIMUM VALUE

SMF Info
--------
    Field: `SMF70RMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

READY MINIMUM VALUE
"""

rmm : Final[Field] = Field(
    name='rmm',
    origin='SMF70RMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""READY MAXIMUM VALUE

SMF Info
--------
    Field: `SMF70RMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

READY MAXIMUM VALUE
"""
rmm.__doc__ = """READY MAXIMUM VALUE

SMF Info
--------
    Field: `SMF70RMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

READY MAXIMUM VALUE
"""

rtt : Final[Field] = Field(
    name='rtt',
    origin='SMF70RTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""READY TOTAL VALUE

SMF Info
--------
    Field: `SMF70RTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

READY TOTAL VALUE
"""
rtt.__doc__ = """READY TOTAL VALUE

SMF Info
--------
    Field: `SMF70RTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

READY TOTAL VALUE
"""

r00 : Final[Field] = Field(
    name='r00',
    origin='SMF70R00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 0

SMF Info
--------
    Field: `SMF70R00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 0
"""
r00.__doc__ = """# TIMES READY VAL WAS 0

SMF Info
--------
    Field: `SMF70R00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 0
"""

r01 : Final[Field] = Field(
    name='r01',
    origin='SMF70R01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 1

SMF Info
--------
    Field: `SMF70R01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 1
"""
r01.__doc__ = """# TIMES READY VAL WAS 1

SMF Info
--------
    Field: `SMF70R01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 1
"""

r02 : Final[Field] = Field(
    name='r02',
    origin='SMF70R02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 2

SMF Info
--------
    Field: `SMF70R02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 2
"""
r02.__doc__ = """# TIMES READY VAL WAS 2

SMF Info
--------
    Field: `SMF70R02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 2
"""

r03 : Final[Field] = Field(
    name='r03',
    origin='SMF70R03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 3

SMF Info
--------
    Field: `SMF70R03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 3
"""
r03.__doc__ = """# TIMES READY VAL WAS 3

SMF Info
--------
    Field: `SMF70R03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 3
"""

r04 : Final[Field] = Field(
    name='r04',
    origin='SMF70R04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 4

SMF Info
--------
    Field: `SMF70R04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 4
"""
r04.__doc__ = """# TIMES READY VAL WAS 4

SMF Info
--------
    Field: `SMF70R04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 4
"""

r05 : Final[Field] = Field(
    name='r05',
    origin='SMF70R05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 5

SMF Info
--------
    Field: `SMF70R05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 5
"""
r05.__doc__ = """# TIMES READY VAL WAS 5

SMF Info
--------
    Field: `SMF70R05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 5
"""

r06 : Final[Field] = Field(
    name='r06',
    origin='SMF70R06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 6

SMF Info
--------
    Field: `SMF70R06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 6
"""
r06.__doc__ = """# TIMES READY VAL WAS 6

SMF Info
--------
    Field: `SMF70R06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 6
"""

r07 : Final[Field] = Field(
    name='r07',
    origin='SMF70R07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 7

SMF Info
--------
    Field: `SMF70R07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 7
"""
r07.__doc__ = """# TIMES READY VAL WAS 7

SMF Info
--------
    Field: `SMF70R07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 7
"""

r08 : Final[Field] = Field(
    name='r08',
    origin='SMF70R08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 8

SMF Info
--------
    Field: `SMF70R08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 8
"""
r08.__doc__ = """# TIMES READY VAL WAS 8

SMF Info
--------
    Field: `SMF70R08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 8
"""

r09 : Final[Field] = Field(
    name='r09',
    origin='SMF70R09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES READY VAL WAS 9

SMF Info
--------
    Field: `SMF70R09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 9
"""
r09.__doc__ = """# TIMES READY VAL WAS 9

SMF Info
--------
    Field: `SMF70R09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES READY VAL WAS 9
"""

r10 : Final[Field] = Field(
    name='r10',
    origin='SMF70R10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES RDY VAL WAS 10

SMF Info
--------
    Field: `SMF70R10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 10
"""
r10.__doc__ = """# TIMES RDY VAL WAS 10

SMF Info
--------
    Field: `SMF70R10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 10
"""

r11 : Final[Field] = Field(
    name='r11',
    origin='SMF70R11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES RDY VAL WAS 11

SMF Info
--------
    Field: `SMF70R11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 11
"""
r11.__doc__ = """# TIMES RDY VAL WAS 11

SMF Info
--------
    Field: `SMF70R11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 11
"""

r12 : Final[Field] = Field(
    name='r12',
    origin='SMF70R12',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES RDY VAL WAS 12

SMF Info
--------
    Field: `SMF70R12`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 12
"""
r12.__doc__ = """# TIMES RDY VAL WAS 12

SMF Info
--------
    Field: `SMF70R12`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 12
"""

r13 : Final[Field] = Field(
    name='r13',
    origin='SMF70R13',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES RDY VAL WAS 13

SMF Info
--------
    Field: `SMF70R13`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 13
"""
r13.__doc__ = """# TIMES RDY VAL WAS 13

SMF Info
--------
    Field: `SMF70R13`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 13
"""

r14 : Final[Field] = Field(
    name='r14',
    origin='SMF70R14',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES RDY VAL WAS 14

SMF Info
--------
    Field: `SMF70R14`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 14
"""
r14.__doc__ = """# TIMES RDY VAL WAS 14

SMF Info
--------
    Field: `SMF70R14`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 14
"""

r15 : Final[Field] = Field(
    name='r15',
    origin='SMF70R15',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES RDY VAL WAS 14+

SMF Info
--------
    Field: `SMF70R15`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 14+
"""
r15.__doc__ = """# TIMES RDY VAL WAS 14+

SMF Info
--------
    Field: `SMF70R15`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES RDY VAL WAS 14+
"""

imn : Final[Field] = Field(
    name='imn',
    origin='SMF70IMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""IN USERS MINIMUM

SMF Info
--------
    Field: `SMF70IMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

IN USERS MINIMUM
"""
imn.__doc__ = """IN USERS MINIMUM

SMF Info
--------
    Field: `SMF70IMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

IN USERS MINIMUM
"""

imm : Final[Field] = Field(
    name='imm',
    origin='SMF70IMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""IN USERS MAXIMUM

SMF Info
--------
    Field: `SMF70IMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

IN USERS MAXIMUM
"""
imm.__doc__ = """IN USERS MAXIMUM

SMF Info
--------
    Field: `SMF70IMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

IN USERS MAXIMUM
"""

itt : Final[Field] = Field(
    name='itt',
    origin='SMF70ITT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""IN USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70ITT`
    Record: `SMF70S1`
    Map: `SMF70AID`

IN USERS TOTAL VALUE
"""
itt.__doc__ = """IN USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70ITT`
    Record: `SMF70S1`
    Map: `SMF70AID`

IN USERS TOTAL VALUE
"""

i00 : Final[Field] = Field(
    name='i00',
    origin='SMF70I00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 0

SMF Info
--------
    Field: `SMF70I00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 0
"""
i00.__doc__ = """# TIMES IN USERS WAS 0

SMF Info
--------
    Field: `SMF70I00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 0
"""

i01 : Final[Field] = Field(
    name='i01',
    origin='SMF70I01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70I01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 1 OR 2
"""
i01.__doc__ = """# TIMES IN USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70I01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 1 OR 2
"""

i02 : Final[Field] = Field(
    name='i02',
    origin='SMF70I02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70I02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 3 OR 4
"""
i02.__doc__ = """# TIMES IN USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70I02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 3 OR 4
"""

i03 : Final[Field] = Field(
    name='i03',
    origin='SMF70I03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70I03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 5 OR 6
"""
i03.__doc__ = """# TIMES IN USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70I03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 5 OR 6
"""

i04 : Final[Field] = Field(
    name='i04',
    origin='SMF70I04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70I04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 7 OR 8
"""
i04.__doc__ = """# TIMES IN USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70I04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 7 OR 8
"""

i05 : Final[Field] = Field(
    name='i05',
    origin='SMF70I05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70I05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 9 OR 10
"""
i05.__doc__ = """# TIMES IN USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70I05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 9 OR 10
"""

i06 : Final[Field] = Field(
    name='i06',
    origin='SMF70I06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70I06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 11 - 15
"""
i06.__doc__ = """# TIMES IN USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70I06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 11 - 15
"""

i07 : Final[Field] = Field(
    name='i07',
    origin='SMF70I07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70I07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 16 - 20
"""
i07.__doc__ = """# TIMES IN USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70I07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 16 - 20
"""

i08 : Final[Field] = Field(
    name='i08',
    origin='SMF70I08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70I08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 21 - 25
"""
i08.__doc__ = """# TIMES IN USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70I08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 21 - 25
"""

i09 : Final[Field] = Field(
    name='i09',
    origin='SMF70I09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70I09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 26 - 30
"""
i09.__doc__ = """# TIMES IN USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70I09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 26 - 30
"""

i10 : Final[Field] = Field(
    name='i10',
    origin='SMF70I10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70I10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 31 - 35
"""
i10.__doc__ = """# TIMES IN USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70I10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 31 - 35
"""

i11 : Final[Field] = Field(
    name='i11',
    origin='SMF70I11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES IN USERS WAS 35+

SMF Info
--------
    Field: `SMF70I11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 35+
"""
i11.__doc__ = """# TIMES IN USERS WAS 35+

SMF Info
--------
    Field: `SMF70I11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES IN USERS WAS 35+
"""

omn : Final[Field] = Field(
    name='omn',
    origin='SMF70OMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""OUT USERS MINIMUM

SMF Info
--------
    Field: `SMF70OMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

OUT USERS MINIMUM
"""
omn.__doc__ = """OUT USERS MINIMUM

SMF Info
--------
    Field: `SMF70OMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

OUT USERS MINIMUM
"""

omm : Final[Field] = Field(
    name='omm',
    origin='SMF70OMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""OUT USERS MAXIMUM

SMF Info
--------
    Field: `SMF70OMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

OUT USERS MAXIMUM
"""
omm.__doc__ = """OUT USERS MAXIMUM

SMF Info
--------
    Field: `SMF70OMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

OUT USERS MAXIMUM
"""

ott : Final[Field] = Field(
    name='ott',
    origin='SMF70OTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""OUT USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70OTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

OUT USERS TOTAL VALUE
"""
ott.__doc__ = """OUT USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70OTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

OUT USERS TOTAL VALUE
"""

o00 : Final[Field] = Field(
    name='o00',
    origin='SMF70O00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 0

SMF Info
--------
    Field: `SMF70O00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 0
"""
o00.__doc__ = """# TIMES OUT USERS WAS 0

SMF Info
--------
    Field: `SMF70O00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 0
"""

o01 : Final[Field] = Field(
    name='o01',
    origin='SMF70O01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70O01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 1 OR 2
"""
o01.__doc__ = """# TIMES OUT USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70O01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 1 OR 2
"""

o02 : Final[Field] = Field(
    name='o02',
    origin='SMF70O02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70O02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 3 OR 4
"""
o02.__doc__ = """# TIMES OUT USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70O02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 3 OR 4
"""

o03 : Final[Field] = Field(
    name='o03',
    origin='SMF70O03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70O03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 5 OR 6
"""
o03.__doc__ = """# TIMES OUT USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70O03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 5 OR 6
"""

o04 : Final[Field] = Field(
    name='o04',
    origin='SMF70O04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70O04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 7 OR 8
"""
o04.__doc__ = """# TIMES OUT USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70O04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 7 OR 8
"""

o05 : Final[Field] = Field(
    name='o05',
    origin='SMF70O05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70O05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 9 OR 10
"""
o05.__doc__ = """# TIMES OUT USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70O05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 9 OR 10
"""

o06 : Final[Field] = Field(
    name='o06',
    origin='SMF70O06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70O06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 11 - 15
"""
o06.__doc__ = """# TIMES OUT USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70O06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 11 - 15
"""

o07 : Final[Field] = Field(
    name='o07',
    origin='SMF70O07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70O07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 16 - 20
"""
o07.__doc__ = """# TIMES OUT USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70O07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 16 - 20
"""

o08 : Final[Field] = Field(
    name='o08',
    origin='SMF70O08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70O08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 21 - 25
"""
o08.__doc__ = """# TIMES OUT USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70O08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 21 - 25
"""

o09 : Final[Field] = Field(
    name='o09',
    origin='SMF70O09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70O09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 26 - 30
"""
o09.__doc__ = """# TIMES OUT USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70O09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 26 - 30
"""

o10 : Final[Field] = Field(
    name='o10',
    origin='SMF70O10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70O10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 31 - 35
"""
o10.__doc__ = """# TIMES OUT USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70O10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 31 - 35
"""

o11 : Final[Field] = Field(
    name='o11',
    origin='SMF70O11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OUT USERS WAS 35+

SMF Info
--------
    Field: `SMF70O11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 35+
"""
o11.__doc__ = """# TIMES OUT USERS WAS 35+

SMF Info
--------
    Field: `SMF70O11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OUT USERS WAS 35+
"""

wmn : Final[Field] = Field(
    name='wmn',
    origin='SMF70WMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""WAIT USER MINIMUM

SMF Info
--------
    Field: `SMF70WMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

WAIT USER MINIMUM
"""
wmn.__doc__ = """WAIT USER MINIMUM

SMF Info
--------
    Field: `SMF70WMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

WAIT USER MINIMUM
"""

wmm : Final[Field] = Field(
    name='wmm',
    origin='SMF70WMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""WAIT USERS MAXIMUM

SMF Info
--------
    Field: `SMF70WMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

WAIT USERS MAXIMUM
"""
wmm.__doc__ = """WAIT USERS MAXIMUM

SMF Info
--------
    Field: `SMF70WMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

WAIT USERS MAXIMUM
"""

wtt : Final[Field] = Field(
    name='wtt',
    origin='SMF70WTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""WAIT USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70WTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

WAIT USERS TOTAL VALUE
"""
wtt.__doc__ = """WAIT USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70WTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

WAIT USERS TOTAL VALUE
"""

w00 : Final[Field] = Field(
    name='w00',
    origin='SMF70W00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USER WAS 0

SMF Info
--------
    Field: `SMF70W00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USER WAS 0
"""
w00.__doc__ = """# TIMES WAIT USER WAS 0

SMF Info
--------
    Field: `SMF70W00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USER WAS 0
"""

w01 : Final[Field] = Field(
    name='w01',
    origin='SMF70W01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70W01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 1 OR 2
"""
w01.__doc__ = """# TIMES WAIT USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70W01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 1 OR 2
"""

w02 : Final[Field] = Field(
    name='w02',
    origin='SMF70W02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70W02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 3 OR 4
"""
w02.__doc__ = """# TIMES WAIT USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70W02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 3 OR 4
"""

w03 : Final[Field] = Field(
    name='w03',
    origin='SMF70W03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70W03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 5 OR 6
"""
w03.__doc__ = """# TIMES WAIT USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70W03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 5 OR 6
"""

w04 : Final[Field] = Field(
    name='w04',
    origin='SMF70W04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70W04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 7 OR 8
"""
w04.__doc__ = """# TIMES WAIT USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70W04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 7 OR 8
"""

w05 : Final[Field] = Field(
    name='w05',
    origin='SMF70W05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70W05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 9 OR 10
"""
w05.__doc__ = """# TIMES WAIT USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70W05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 9 OR 10
"""

w06 : Final[Field] = Field(
    name='w06',
    origin='SMF70W06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70W06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 11 - 15
"""
w06.__doc__ = """# TIMES WAIT USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70W06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 11 - 15
"""

w07 : Final[Field] = Field(
    name='w07',
    origin='SMF70W07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70W07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 16 - 20
"""
w07.__doc__ = """# TIMES WAIT USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70W07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 16 - 20
"""

w08 : Final[Field] = Field(
    name='w08',
    origin='SMF70W08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70W08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 21 - 25
"""
w08.__doc__ = """# TIMES WAIT USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70W08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 21 - 25
"""

w09 : Final[Field] = Field(
    name='w09',
    origin='SMF70W09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70W09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 26 - 30
"""
w09.__doc__ = """# TIMES WAIT USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70W09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 26 - 30
"""

w10 : Final[Field] = Field(
    name='w10',
    origin='SMF70W10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70W10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 31 - 35
"""
w10.__doc__ = """# TIMES WAIT USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70W10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 31 - 35
"""

w11 : Final[Field] = Field(
    name='w11',
    origin='SMF70W11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES WAIT USERS WAS 35+

SMF Info
--------
    Field: `SMF70W11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 35+
"""
w11.__doc__ = """# TIMES WAIT USERS WAS 35+

SMF Info
--------
    Field: `SMF70W11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES WAIT USERS WAS 35+
"""

bmn : Final[Field] = Field(
    name='bmn',
    origin='SMF70BMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""BATCH USERS MINIMUM

SMF Info
--------
    Field: `SMF70BMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

BATCH USERS MINIMUM
"""
bmn.__doc__ = """BATCH USERS MINIMUM

SMF Info
--------
    Field: `SMF70BMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

BATCH USERS MINIMUM
"""

bmm : Final[Field] = Field(
    name='bmm',
    origin='SMF70BMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""BATCH USERS MAXIMUM

SMF Info
--------
    Field: `SMF70BMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

BATCH USERS MAXIMUM
"""
bmm.__doc__ = """BATCH USERS MAXIMUM

SMF Info
--------
    Field: `SMF70BMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

BATCH USERS MAXIMUM
"""

btt : Final[Field] = Field(
    name='btt',
    origin='SMF70BTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""BATCH USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70BTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

BATCH USERS TOTAL VALUE
"""
btt.__doc__ = """BATCH USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70BTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

BATCH USERS TOTAL VALUE
"""

b00 : Final[Field] = Field(
    name='b00',
    origin='SMF70B00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 0

SMF Info
--------
    Field: `SMF70B00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 0
"""
b00.__doc__ = """# TIMES BATCH USERS WAS 0

SMF Info
--------
    Field: `SMF70B00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 0
"""

b01 : Final[Field] = Field(
    name='b01',
    origin='SMF70B01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70B01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 1 OR 2
"""
b01.__doc__ = """# TIMES BATCH USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70B01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 1 OR 2
"""

b02 : Final[Field] = Field(
    name='b02',
    origin='SMF70B02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70B02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 3 OR 4
"""
b02.__doc__ = """# TIMES BATCH USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70B02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 3 OR 4
"""

b03 : Final[Field] = Field(
    name='b03',
    origin='SMF70B03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70B03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 5 OR 6
"""
b03.__doc__ = """# TIMES BATCH USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70B03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 5 OR 6
"""

b04 : Final[Field] = Field(
    name='b04',
    origin='SMF70B04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70B04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 7 OR 8
"""
b04.__doc__ = """# TIMES BATCH USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70B04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 7 OR 8
"""

b05 : Final[Field] = Field(
    name='b05',
    origin='SMF70B05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70B05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 9 OR 10
"""
b05.__doc__ = """# TIMES BATCH USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70B05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 9 OR 10
"""

b06 : Final[Field] = Field(
    name='b06',
    origin='SMF70B06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70B06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 11 - 15
"""
b06.__doc__ = """# TIMES BATCH USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70B06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 11 - 15
"""

b07 : Final[Field] = Field(
    name='b07',
    origin='SMF70B07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70B07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 16 - 20
"""
b07.__doc__ = """# TIMES BATCH USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70B07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 16 - 20
"""

b08 : Final[Field] = Field(
    name='b08',
    origin='SMF70B08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70B08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 21 - 25
"""
b08.__doc__ = """# TIMES BATCH USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70B08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 21 - 25
"""

b09 : Final[Field] = Field(
    name='b09',
    origin='SMF70B09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70B09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 26 - 30
"""
b09.__doc__ = """# TIMES BATCH USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70B09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 26 - 30
"""

b10 : Final[Field] = Field(
    name='b10',
    origin='SMF70B10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70B10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 31 - 35
"""
b10.__doc__ = """# TIMES BATCH USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70B10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 31 - 35
"""

b11 : Final[Field] = Field(
    name='b11',
    origin='SMF70B11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES BATCH USERS WAS 35+

SMF Info
--------
    Field: `SMF70B11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 35+
"""
b11.__doc__ = """# TIMES BATCH USERS WAS 35+

SMF Info
--------
    Field: `SMF70B11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES BATCH USERS WAS 35+
"""

smn : Final[Field] = Field(
    name='smn',
    origin='SMF70SMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""STARTED USERS MINIMUM

SMF Info
--------
    Field: `SMF70SMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

STARTED USERS MINIMUM
"""
smn.__doc__ = """STARTED USERS MINIMUM

SMF Info
--------
    Field: `SMF70SMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

STARTED USERS MINIMUM
"""

smm : Final[Field] = Field(
    name='smm',
    origin='SMF70SMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""STARTED USERS MAXIMUM

SMF Info
--------
    Field: `SMF70SMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

STARTED USERS MAXIMUM
"""
smm.__doc__ = """STARTED USERS MAXIMUM

SMF Info
--------
    Field: `SMF70SMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

STARTED USERS MAXIMUM
"""

stt : Final[Field] = Field(
    name='stt',
    origin='SMF70STT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""STARTED USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70STT`
    Record: `SMF70S1`
    Map: `SMF70AID`

STARTED USERS TOTAL VALUE
"""
stt.__doc__ = """STARTED USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70STT`
    Record: `SMF70S1`
    Map: `SMF70AID`

STARTED USERS TOTAL VALUE
"""

s00 : Final[Field] = Field(
    name='s00',
    origin='SMF70S00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 0

SMF Info
--------
    Field: `SMF70S00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 0
"""
s00.__doc__ = """# TIMES STC USERS WAS 0

SMF Info
--------
    Field: `SMF70S00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 0
"""

s01 : Final[Field] = Field(
    name='s01',
    origin='SMF70S01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70S01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 1 OR 2
"""
s01.__doc__ = """# TIMES STC USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70S01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 1 OR 2
"""

s02 : Final[Field] = Field(
    name='s02',
    origin='SMF70S02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70S02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 3 OR 4
"""
s02.__doc__ = """# TIMES STC USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70S02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 3 OR 4
"""

s03 : Final[Field] = Field(
    name='s03',
    origin='SMF70S03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70S03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 5 OR 6
"""
s03.__doc__ = """# TIMES STC USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70S03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 5 OR 6
"""

s04 : Final[Field] = Field(
    name='s04',
    origin='SMF70S04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70S04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 7 OR 8
"""
s04.__doc__ = """# TIMES STC USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70S04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 7 OR 8
"""

s05 : Final[Field] = Field(
    name='s05',
    origin='SMF70S05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70S05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 9 OR 10
"""
s05.__doc__ = """# TIMES STC USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70S05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 9 OR 10
"""

s06 : Final[Field] = Field(
    name='s06',
    origin='SMF70S06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70S06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 11 - 15
"""
s06.__doc__ = """# TIMES STC USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70S06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 11 - 15
"""

s07 : Final[Field] = Field(
    name='s07',
    origin='SMF70S07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70S07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 16 - 20
"""
s07.__doc__ = """# TIMES STC USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70S07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 16 - 20
"""

s08 : Final[Field] = Field(
    name='s08',
    origin='SMF70S08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70S08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 21 - 25
"""
s08.__doc__ = """# TIMES STC USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70S08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 21 - 25
"""

s09 : Final[Field] = Field(
    name='s09',
    origin='SMF70S09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70S09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 26 - 30
"""
s09.__doc__ = """# TIMES STC USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70S09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 26 - 30
"""

s10 : Final[Field] = Field(
    name='s10',
    origin='SMF70S10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70S10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 31 - 35
"""
s10.__doc__ = """# TIMES STC USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70S10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 31 - 35
"""

s11 : Final[Field] = Field(
    name='s11',
    origin='SMF70S11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES STC USERS WAS 35+

SMF Info
--------
    Field: `SMF70S11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 35+
"""
s11.__doc__ = """# TIMES STC USERS WAS 35+

SMF Info
--------
    Field: `SMF70S11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES STC USERS WAS 35+
"""

tmn : Final[Field] = Field(
    name='tmn',
    origin='SMF70TMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""TSO USERS MINIMUM

SMF Info
--------
    Field: `SMF70TMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

TSO USERS MINIMUM
"""
tmn.__doc__ = """TSO USERS MINIMUM

SMF Info
--------
    Field: `SMF70TMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

TSO USERS MINIMUM
"""

tmm : Final[Field] = Field(
    name='tmm',
    origin='SMF70TMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""TSO USERS MAXIMUM

SMF Info
--------
    Field: `SMF70TMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

TSO USERS MAXIMUM
"""
tmm.__doc__ = """TSO USERS MAXIMUM

SMF Info
--------
    Field: `SMF70TMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

TSO USERS MAXIMUM
"""

ttt : Final[Field] = Field(
    name='ttt',
    origin='SMF70TTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""TSO USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70TTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

TSO USERS TOTAL VALUE
"""
ttt.__doc__ = """TSO USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70TTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

TSO USERS TOTAL VALUE
"""

t00 : Final[Field] = Field(
    name='t00',
    origin='SMF70T00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 0

SMF Info
--------
    Field: `SMF70T00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 0
"""
t00.__doc__ = """# TIMES TSO USERS WAS 0

SMF Info
--------
    Field: `SMF70T00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 0
"""

t01 : Final[Field] = Field(
    name='t01',
    origin='SMF70T01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70T01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 1 OR 2
"""
t01.__doc__ = """# TIMES TSO USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70T01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 1 OR 2
"""

t02 : Final[Field] = Field(
    name='t02',
    origin='SMF70T02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70T02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 3 OR 4
"""
t02.__doc__ = """# TIMES TSO USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70T02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 3 OR 4
"""

t03 : Final[Field] = Field(
    name='t03',
    origin='SMF70T03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70T03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 5 OR 6
"""
t03.__doc__ = """# TIMES TSO USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70T03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 5 OR 6
"""

t04 : Final[Field] = Field(
    name='t04',
    origin='SMF70T04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70T04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 7 OR 8
"""
t04.__doc__ = """# TIMES TSO USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70T04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 7 OR 8
"""

t05 : Final[Field] = Field(
    name='t05',
    origin='SMF70T05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70T05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 9 OR 10
"""
t05.__doc__ = """# TIMES TSO USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70T05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 9 OR 10
"""

t06 : Final[Field] = Field(
    name='t06',
    origin='SMF70T06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70T06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 11 - 15
"""
t06.__doc__ = """# TIMES TSO USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70T06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 11 - 15
"""

t07 : Final[Field] = Field(
    name='t07',
    origin='SMF70T07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70T07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 16 - 20
"""
t07.__doc__ = """# TIMES TSO USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70T07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 16 - 20
"""

t08 : Final[Field] = Field(
    name='t08',
    origin='SMF70T08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70T08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 21 - 25
"""
t08.__doc__ = """# TIMES TSO USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70T08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 21 - 25
"""

t09 : Final[Field] = Field(
    name='t09',
    origin='SMF70T09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70T09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 26 - 30
"""
t09.__doc__ = """# TIMES TSO USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70T09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 26 - 30
"""

t10 : Final[Field] = Field(
    name='t10',
    origin='SMF70T10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70T10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 31 - 35
"""
t10.__doc__ = """# TIMES TSO USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70T10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 31 - 35
"""

t11 : Final[Field] = Field(
    name='t11',
    origin='SMF70T11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES TSO USERS WAS 35+

SMF Info
--------
    Field: `SMF70T11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 35+
"""
t11.__doc__ = """# TIMES TSO USERS WAS 35+

SMF Info
--------
    Field: `SMF70T11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES TSO USERS WAS 35+
"""

lmn : Final[Field] = Field(
    name='lmn',
    origin='SMF70LMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""LOG RDY USERS MINIMUM

SMF Info
--------
    Field: `SMF70LMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG RDY USERS MINIMUM
"""
lmn.__doc__ = """LOG RDY USERS MINIMUM

SMF Info
--------
    Field: `SMF70LMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG RDY USERS MINIMUM
"""

lmm : Final[Field] = Field(
    name='lmm',
    origin='SMF70LMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""LOG RDY USERS MAXIMUM

SMF Info
--------
    Field: `SMF70LMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG RDY USERS MAXIMUM
"""
lmm.__doc__ = """LOG RDY USERS MAXIMUM

SMF Info
--------
    Field: `SMF70LMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG RDY USERS MAXIMUM
"""

ltt : Final[Field] = Field(
    name='ltt',
    origin='SMF70LTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""LOG RDY USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70LTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG RDY USERS TOTAL VALUE
"""
ltt.__doc__ = """LOG RDY USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70LTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG RDY USERS TOTAL VALUE
"""

l00 : Final[Field] = Field(
    name='l00',
    origin='SMF70L00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 0

SMF Info
--------
    Field: `SMF70L00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 0
"""
l00.__doc__ = """# TIMES LOG RDY USERS WAS 0

SMF Info
--------
    Field: `SMF70L00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 0
"""

l01 : Final[Field] = Field(
    name='l01',
    origin='SMF70L01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 1-2

SMF Info
--------
    Field: `SMF70L01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 1-2
"""
l01.__doc__ = """# TIMES LOG RDY USERS WAS 1-2

SMF Info
--------
    Field: `SMF70L01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 1-2
"""

l02 : Final[Field] = Field(
    name='l02',
    origin='SMF70L02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 3-4

SMF Info
--------
    Field: `SMF70L02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 3-4
"""
l02.__doc__ = """# TIMES LOG RDY USERS WAS 3-4

SMF Info
--------
    Field: `SMF70L02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 3-4
"""

l03 : Final[Field] = Field(
    name='l03',
    origin='SMF70L03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 5-6

SMF Info
--------
    Field: `SMF70L03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 5-6
"""
l03.__doc__ = """# TIMES LOG RDY USERS WAS 5-6

SMF Info
--------
    Field: `SMF70L03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 5-6
"""

l04 : Final[Field] = Field(
    name='l04',
    origin='SMF70L04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 7-8

SMF Info
--------
    Field: `SMF70L04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 7-8
"""
l04.__doc__ = """# TIMES LOG RDY USERS WAS 7-8

SMF Info
--------
    Field: `SMF70L04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 7-8
"""

l05 : Final[Field] = Field(
    name='l05',
    origin='SMF70L05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 9-10

SMF Info
--------
    Field: `SMF70L05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 9-10
"""
l05.__doc__ = """# TIMES LOG RDY USERS WAS 9-10

SMF Info
--------
    Field: `SMF70L05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 9-10
"""

l06 : Final[Field] = Field(
    name='l06',
    origin='SMF70L06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 11-15

SMF Info
--------
    Field: `SMF70L06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 11-15
"""
l06.__doc__ = """# TIMES LOG RDY USERS WAS 11-15

SMF Info
--------
    Field: `SMF70L06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 11-15
"""

l07 : Final[Field] = Field(
    name='l07',
    origin='SMF70L07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 16-20

SMF Info
--------
    Field: `SMF70L07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 16-20
"""
l07.__doc__ = """# TIMES LOG RDY USERS WAS 16-20

SMF Info
--------
    Field: `SMF70L07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 16-20
"""

l08 : Final[Field] = Field(
    name='l08',
    origin='SMF70L08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 21-25

SMF Info
--------
    Field: `SMF70L08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 21-25
"""
l08.__doc__ = """# TIMES LOG RDY USERS WAS 21-25

SMF Info
--------
    Field: `SMF70L08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 21-25
"""

l09 : Final[Field] = Field(
    name='l09',
    origin='SMF70L09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 26-30

SMF Info
--------
    Field: `SMF70L09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 26-30
"""
l09.__doc__ = """# TIMES LOG RDY USERS WAS 26-30

SMF Info
--------
    Field: `SMF70L09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 26-30
"""

l10 : Final[Field] = Field(
    name='l10',
    origin='SMF70L10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 31-35

SMF Info
--------
    Field: `SMF70L10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 31-35
"""
l10.__doc__ = """# TIMES LOG RDY USERS WAS 31-35

SMF Info
--------
    Field: `SMF70L10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 31-35
"""

l11 : Final[Field] = Field(
    name='l11',
    origin='SMF70L11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES LOG RDY USERS WAS 35+

SMF Info
--------
    Field: `SMF70L11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 35+
"""
l11.__doc__ = """# TIMES LOG RDY USERS WAS 35+

SMF Info
--------
    Field: `SMF70L11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES LOG RDY USERS WAS 35+
"""

amn : Final[Field] = Field(
    name='amn',
    origin='SMF70AMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""LOG WAIT USERS MINIMUM

SMF Info
--------
    Field: `SMF70AMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG WAIT USERS MINIMUM
"""
amn.__doc__ = """LOG WAIT USERS MINIMUM

SMF Info
--------
    Field: `SMF70AMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG WAIT USERS MINIMUM
"""

amm : Final[Field] = Field(
    name='amm',
    origin='SMF70AMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""LOG WAIT USERS MAXIMUM

SMF Info
--------
    Field: `SMF70AMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG WAIT USERS MAXIMUM
"""
amm.__doc__ = """LOG WAIT USERS MAXIMUM

SMF Info
--------
    Field: `SMF70AMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG WAIT USERS MAXIMUM
"""

att : Final[Field] = Field(
    name='att',
    origin='SMF70ATT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""LOG WAIT USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70ATT`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG WAIT USERS TOTAL VALUE
"""
att.__doc__ = """LOG WAIT USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70ATT`
    Record: `SMF70S1`
    Map: `SMF70AID`

LOG WAIT USERS TOTAL VALUE
"""

a00 : Final[Field] = Field(
    name='a00',
    origin='SMF70A00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 0

SMF Info
--------
    Field: `SMF70A00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 0
"""
a00.__doc__ = """# TIME LOG WAIT USERS WAS 0

SMF Info
--------
    Field: `SMF70A00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 0
"""

a01 : Final[Field] = Field(
    name='a01',
    origin='SMF70A01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 1-2

SMF Info
--------
    Field: `SMF70A01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 1-2
"""
a01.__doc__ = """# TIME LOG WAIT USERS WAS 1-2

SMF Info
--------
    Field: `SMF70A01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 1-2
"""

a02 : Final[Field] = Field(
    name='a02',
    origin='SMF70A02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 3-4

SMF Info
--------
    Field: `SMF70A02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 3-4
"""
a02.__doc__ = """# TIME LOG WAIT USERS WAS 3-4

SMF Info
--------
    Field: `SMF70A02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 3-4
"""

a03 : Final[Field] = Field(
    name='a03',
    origin='SMF70A03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 5-6

SMF Info
--------
    Field: `SMF70A03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 5-6
"""
a03.__doc__ = """# TIME LOG WAIT USERS WAS 5-6

SMF Info
--------
    Field: `SMF70A03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 5-6
"""

a04 : Final[Field] = Field(
    name='a04',
    origin='SMF70A04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 7-8

SMF Info
--------
    Field: `SMF70A04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 7-8
"""
a04.__doc__ = """# TIME LOG WAIT USERS WAS 7-8

SMF Info
--------
    Field: `SMF70A04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 7-8
"""

a05 : Final[Field] = Field(
    name='a05',
    origin='SMF70A05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 9-10

SMF Info
--------
    Field: `SMF70A05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 9-10
"""
a05.__doc__ = """# TIME LOG WAIT USERS WAS 9-10

SMF Info
--------
    Field: `SMF70A05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 9-10
"""

a06 : Final[Field] = Field(
    name='a06',
    origin='SMF70A06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 11-15

SMF Info
--------
    Field: `SMF70A06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 11-15
"""
a06.__doc__ = """# TIME LOG WAIT USERS WAS 11-15

SMF Info
--------
    Field: `SMF70A06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 11-15
"""

a07 : Final[Field] = Field(
    name='a07',
    origin='SMF70A07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 16-20

SMF Info
--------
    Field: `SMF70A07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 16-20
"""
a07.__doc__ = """# TIME LOG WAIT USERS WAS 16-20

SMF Info
--------
    Field: `SMF70A07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 16-20
"""

a08 : Final[Field] = Field(
    name='a08',
    origin='SMF70A08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 21-25

SMF Info
--------
    Field: `SMF70A08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 21-25
"""
a08.__doc__ = """# TIME LOG WAIT USERS WAS 21-25

SMF Info
--------
    Field: `SMF70A08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 21-25
"""

a09 : Final[Field] = Field(
    name='a09',
    origin='SMF70A09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 26-30

SMF Info
--------
    Field: `SMF70A09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 26-30
"""
a09.__doc__ = """# TIME LOG WAIT USERS WAS 26-30

SMF Info
--------
    Field: `SMF70A09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 26-30
"""

a10 : Final[Field] = Field(
    name='a10',
    origin='SMF70A10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 31-35

SMF Info
--------
    Field: `SMF70A10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 31-35
"""
a10.__doc__ = """# TIME LOG WAIT USERS WAS 31-35

SMF Info
--------
    Field: `SMF70A10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 31-35
"""

a11 : Final[Field] = Field(
    name='a11',
    origin='SMF70A11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIME LOG WAIT USERS WAS 35+

SMF Info
--------
    Field: `SMF70A11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 35+
"""
a11.__doc__ = """# TIME LOG WAIT USERS WAS 35+

SMF Info
--------
    Field: `SMF70A11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIME LOG WAIT USERS WAS 35+
"""

pmn : Final[Field] = Field(
    name='pmn',
    origin='SMF70PMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""ASCH USERS MINIMUM

SMF Info
--------
    Field: `SMF70PMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

ASCH USERS MINIMUM
"""
pmn.__doc__ = """ASCH USERS MINIMUM

SMF Info
--------
    Field: `SMF70PMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

ASCH USERS MINIMUM
"""

pmm : Final[Field] = Field(
    name='pmm',
    origin='SMF70PMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""ASCH USERS MAXIMUM

SMF Info
--------
    Field: `SMF70PMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

ASCH USERS MAXIMUM
"""
pmm.__doc__ = """ASCH USERS MAXIMUM

SMF Info
--------
    Field: `SMF70PMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

ASCH USERS MAXIMUM
"""

ptt : Final[Field] = Field(
    name='ptt',
    origin='SMF70PTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""ASCH USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70PTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

ASCH USERS TOTAL VALUE
"""
ptt.__doc__ = """ASCH USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70PTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

ASCH USERS TOTAL VALUE
"""

p00 : Final[Field] = Field(
    name='p00',
    origin='SMF70P00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 0

SMF Info
--------
    Field: `SMF70P00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 0
"""
p00.__doc__ = """# TIMES ASCH USERS WAS 0

SMF Info
--------
    Field: `SMF70P00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 0
"""

p01 : Final[Field] = Field(
    name='p01',
    origin='SMF70P01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70P01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 1 OR 2
"""
p01.__doc__ = """# TIMES ASCH USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70P01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 1 OR 2
"""

p02 : Final[Field] = Field(
    name='p02',
    origin='SMF70P02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70P02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 3 OR 4
"""
p02.__doc__ = """# TIMES ASCH USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70P02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 3 OR 4
"""

p03 : Final[Field] = Field(
    name='p03',
    origin='SMF70P03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70P03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 5 OR 6
"""
p03.__doc__ = """# TIMES ASCH USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70P03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 5 OR 6
"""

p04 : Final[Field] = Field(
    name='p04',
    origin='SMF70P04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70P04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 7 OR 8
"""
p04.__doc__ = """# TIMES ASCH USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70P04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 7 OR 8
"""

p05 : Final[Field] = Field(
    name='p05',
    origin='SMF70P05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70P05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 9 OR 10
"""
p05.__doc__ = """# TIMES ASCH USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70P05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 9 OR 10
"""

p06 : Final[Field] = Field(
    name='p06',
    origin='SMF70P06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70P06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 11 - 15
"""
p06.__doc__ = """# TIMES ASCH USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70P06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 11 - 15
"""

p07 : Final[Field] = Field(
    name='p07',
    origin='SMF70P07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70P07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 16 - 20
"""
p07.__doc__ = """# TIMES ASCH USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70P07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 16 - 20
"""

p08 : Final[Field] = Field(
    name='p08',
    origin='SMF70P08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70P08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 21 - 25
"""
p08.__doc__ = """# TIMES ASCH USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70P08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 21 - 25
"""

p09 : Final[Field] = Field(
    name='p09',
    origin='SMF70P09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70P09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 26 - 30
"""
p09.__doc__ = """# TIMES ASCH USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70P09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 26 - 30
"""

p10 : Final[Field] = Field(
    name='p10',
    origin='SMF70P10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70P10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 31 - 35
"""
p10.__doc__ = """# TIMES ASCH USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70P10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 31 - 35
"""

p11 : Final[Field] = Field(
    name='p11',
    origin='SMF70P11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES ASCH USERS WAS 35+

SMF Info
--------
    Field: `SMF70P11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 35+
"""
p11.__doc__ = """# TIMES ASCH USERS WAS 35+

SMF Info
--------
    Field: `SMF70P11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES ASCH USERS WAS 35+
"""

xmn : Final[Field] = Field(
    name='xmn',
    origin='SMF70XMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""OMVS USERS MINIMUM

SMF Info
--------
    Field: `SMF70XMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

OMVS USERS MINIMUM
"""
xmn.__doc__ = """OMVS USERS MINIMUM

SMF Info
--------
    Field: `SMF70XMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

OMVS USERS MINIMUM
"""

xmm : Final[Field] = Field(
    name='xmm',
    origin='SMF70XMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""OMVS USERS MAXIMUM

SMF Info
--------
    Field: `SMF70XMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

OMVS USERS MAXIMUM
"""
xmm.__doc__ = """OMVS USERS MAXIMUM

SMF Info
--------
    Field: `SMF70XMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

OMVS USERS MAXIMUM
"""

xtt : Final[Field] = Field(
    name='xtt',
    origin='SMF70XTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""OMVS USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70XTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

OMVS USERS TOTAL VALUE
"""
xtt.__doc__ = """OMVS USERS TOTAL VALUE

SMF Info
--------
    Field: `SMF70XTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

OMVS USERS TOTAL VALUE
"""

x00 : Final[Field] = Field(
    name='x00',
    origin='SMF70X00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 0

SMF Info
--------
    Field: `SMF70X00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 0
"""
x00.__doc__ = """# TIMES OMVS USERS WAS 0

SMF Info
--------
    Field: `SMF70X00`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 0
"""

x01 : Final[Field] = Field(
    name='x01',
    origin='SMF70X01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70X01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 1 OR 2
"""
x01.__doc__ = """# TIMES OMVS USERS WAS 1 OR 2

SMF Info
--------
    Field: `SMF70X01`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 1 OR 2
"""

x02 : Final[Field] = Field(
    name='x02',
    origin='SMF70X02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70X02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 3 OR 4
"""
x02.__doc__ = """# TIMES OMVS USERS WAS 3 OR 4

SMF Info
--------
    Field: `SMF70X02`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 3 OR 4
"""

x03 : Final[Field] = Field(
    name='x03',
    origin='SMF70X03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70X03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 5 OR 6
"""
x03.__doc__ = """# TIMES OMVS USERS WAS 5 OR 6

SMF Info
--------
    Field: `SMF70X03`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 5 OR 6
"""

x04 : Final[Field] = Field(
    name='x04',
    origin='SMF70X04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70X04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 7 OR 8
"""
x04.__doc__ = """# TIMES OMVS USERS WAS 7 OR 8

SMF Info
--------
    Field: `SMF70X04`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 7 OR 8
"""

x05 : Final[Field] = Field(
    name='x05',
    origin='SMF70X05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70X05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 9 OR 10
"""
x05.__doc__ = """# TIMES OMVS USERS WAS 9 OR 10

SMF Info
--------
    Field: `SMF70X05`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 9 OR 10
"""

x06 : Final[Field] = Field(
    name='x06',
    origin='SMF70X06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70X06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 11 - 15
"""
x06.__doc__ = """# TIMES OMVS USERS WAS 11 - 15

SMF Info
--------
    Field: `SMF70X06`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 11 - 15
"""

x07 : Final[Field] = Field(
    name='x07',
    origin='SMF70X07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70X07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 16 - 20
"""
x07.__doc__ = """# TIMES OMVS USERS WAS 16 - 20

SMF Info
--------
    Field: `SMF70X07`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 16 - 20
"""

x08 : Final[Field] = Field(
    name='x08',
    origin='SMF70X08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70X08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 21 - 25
"""
x08.__doc__ = """# TIMES OMVS USERS WAS 21 - 25

SMF Info
--------
    Field: `SMF70X08`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 21 - 25
"""

x09 : Final[Field] = Field(
    name='x09',
    origin='SMF70X09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70X09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 26 - 30
"""
x09.__doc__ = """# TIMES OMVS USERS WAS 26 - 30

SMF Info
--------
    Field: `SMF70X09`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 26 - 30
"""

x10 : Final[Field] = Field(
    name='x10',
    origin='SMF70X10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70X10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 31 - 35
"""
x10.__doc__ = """# TIMES OMVS USERS WAS 31 - 35

SMF Info
--------
    Field: `SMF70X10`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 31 - 35
"""

x11 : Final[Field] = Field(
    name='x11',
    origin='SMF70X11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""# TIMES OMVS USERS WAS 35+

SMF Info
--------
    Field: `SMF70X11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 35+
"""
x11.__doc__ = """# TIMES OMVS USERS WAS 35+

SMF Info
--------
    Field: `SMF70X11`
    Record: `SMF70S1`
    Map: `SMF70AID`

# TIMES OMVS USERS WAS 35+
"""

q00 : Final[Field] = Field(
    name='q00',
    origin='SMF70Q00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was <= N

SMF Info
--------
    Field: `SMF70Q00`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was <= N
"""
q00.__doc__ = """Count of times In Ready was <= N

SMF Info
--------
    Field: `SMF70Q00`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was <= N
"""

q01 : Final[Field] = Field(
    name='q01',
    origin='SMF70Q01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+1

SMF Info
--------
    Field: `SMF70Q01`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+1
"""
q01.__doc__ = """Count of times In Ready was N+1

SMF Info
--------
    Field: `SMF70Q01`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+1
"""

q02 : Final[Field] = Field(
    name='q02',
    origin='SMF70Q02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+2

SMF Info
--------
    Field: `SMF70Q02`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+2
"""
q02.__doc__ = """Count of times In Ready was N+2

SMF Info
--------
    Field: `SMF70Q02`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+2
"""

q03 : Final[Field] = Field(
    name='q03',
    origin='SMF70Q03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+3

SMF Info
--------
    Field: `SMF70Q03`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+3
"""
q03.__doc__ = """Count of times In Ready was N+3

SMF Info
--------
    Field: `SMF70Q03`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+3
"""

q04 : Final[Field] = Field(
    name='q04',
    origin='SMF70Q04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+4 or N+5

SMF Info
--------
    Field: `SMF70Q04`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+4 or N+5
"""
q04.__doc__ = """Count of times In Ready was N+4 or N+5

SMF Info
--------
    Field: `SMF70Q04`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+4 or N+5
"""

q05 : Final[Field] = Field(
    name='q05',
    origin='SMF70Q05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+6 to N+10

SMF Info
--------
    Field: `SMF70Q05`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+6 to N+10
"""
q05.__doc__ = """Count of times In Ready was N+6 to N+10

SMF Info
--------
    Field: `SMF70Q05`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+6 to N+10
"""

q06 : Final[Field] = Field(
    name='q06',
    origin='SMF70Q06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+11 to N+15

SMF Info
--------
    Field: `SMF70Q06`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+11 to N+15
"""
q06.__doc__ = """Count of times In Ready was N+11 to N+15

SMF Info
--------
    Field: `SMF70Q06`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+11 to N+15
"""

q07 : Final[Field] = Field(
    name='q07',
    origin='SMF70Q07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+16 to N+20

SMF Info
--------
    Field: `SMF70Q07`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+16 to N+20
"""
q07.__doc__ = """Count of times In Ready was N+16 to N+20

SMF Info
--------
    Field: `SMF70Q07`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+16 to N+20
"""

q08 : Final[Field] = Field(
    name='q08',
    origin='SMF70Q08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+21 to N+30

SMF Info
--------
    Field: `SMF70Q08`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+21 to N+30
"""
q08.__doc__ = """Count of times In Ready was N+21 to N+30

SMF Info
--------
    Field: `SMF70Q08`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+21 to N+30
"""

q09 : Final[Field] = Field(
    name='q09',
    origin='SMF70Q09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+31 to N+40

SMF Info
--------
    Field: `SMF70Q09`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+31 to N+40
"""
q09.__doc__ = """Count of times In Ready was N+31 to N+40

SMF Info
--------
    Field: `SMF70Q09`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+31 to N+40
"""

q10 : Final[Field] = Field(
    name='q10',
    origin='SMF70Q10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+41 to N+60

SMF Info
--------
    Field: `SMF70Q10`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+41 to N+60
"""
q10.__doc__ = """Count of times In Ready was N+41 to N+60

SMF Info
--------
    Field: `SMF70Q10`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+41 to N+60
"""

q11 : Final[Field] = Field(
    name='q11',
    origin='SMF70Q11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was N+61 to N+80

SMF Info
--------
    Field: `SMF70Q11`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+61 to N+80
"""
q11.__doc__ = """Count of times In Ready was N+61 to N+80

SMF Info
--------
    Field: `SMF70Q11`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was N+61 to N+80
"""

q12 : Final[Field] = Field(
    name='q12',
    origin='SMF70Q12',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times In Ready was greater N+80

SMF Info
--------
    Field: `SMF70Q12`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was greater N+80
"""
q12.__doc__ = """Count of times In Ready was greater N+80

SMF Info
--------
    Field: `SMF70Q12`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times In Ready was greater N+80
"""

srm : Final[Field] = Field(
    name='srm',
    origin='SMF70SRM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Number of SRM samples for calculation of WEB values

SMF Info
--------
    Field: `SMF70SRM`
    Record: `SMF70S1`
    Map: `SMF70AID`

Number of SRM samples for calculation of WEB values
"""
srm.__doc__ = """Number of SRM samples for calculation of WEB values

SMF Info
--------
    Field: `SMF70SRM`
    Record: `SMF70S1`
    Map: `SMF70AID`

Number of SRM samples for calculation of WEB values
"""

cp_min : Final[Field] = Field(
    name='cp_min',
    origin='SMF70CMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""CP processors minimum

SMF Info
--------
    Field: `SMF70CMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

CP processors minimum
"""
cp_min.__doc__ = """CP processors minimum

SMF Info
--------
    Field: `SMF70CMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

CP processors minimum
"""

cp_max : Final[Field] = Field(
    name='cp_max',
    origin='SMF70CMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""CP processors maximum

SMF Info
--------
    Field: `SMF70CMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

CP processors maximum
"""
cp_max.__doc__ = """CP processors maximum

SMF Info
--------
    Field: `SMF70CMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

CP processors maximum
"""

cp_total : Final[Field] = Field(
    name='cp_total',
    origin='SMF70CTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""CP processors total value

SMF Info
--------
    Field: `SMF70CTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

CP processors total value
"""
cp_total.__doc__ = """CP processors total value

SMF Info
--------
    Field: `SMF70CTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

CP processors total value
"""

zaap_min : Final[Field] = Field(
    name='zaap_min',
    origin='SMF70DMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""AAP processors minimum

SMF Info
--------
    Field: `SMF70DMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

AAP processors minimum
"""
zaap_min.__doc__ = """AAP processors minimum

SMF Info
--------
    Field: `SMF70DMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

AAP processors minimum
"""

zaap_max : Final[Field] = Field(
    name='zaap_max',
    origin='SMF70DMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""AAP processors maximum

SMF Info
--------
    Field: `SMF70DMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

AAP processors maximum
"""
zaap_max.__doc__ = """AAP processors maximum

SMF Info
--------
    Field: `SMF70DMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

AAP processors maximum
"""

zaap_total : Final[Field] = Field(
    name='zaap_total',
    origin='SMF70DTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""AAP processors total

SMF Info
--------
    Field: `SMF70DTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

AAP processors total
"""
zaap_total.__doc__ = """AAP processors total

SMF Info
--------
    Field: `SMF70DTT`
    Record: `SMF70S1`
    Map: `SMF70AID`

AAP processors total
"""

ziip_min : Final[Field] = Field(
    name='ziip_min',
    origin='SMF70EMN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""IIP processors minimum

SMF Info
--------
    Field: `SMF70EMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

IIP processors minimum
"""
ziip_min.__doc__ = """IIP processors minimum

SMF Info
--------
    Field: `SMF70EMN`
    Record: `SMF70S1`
    Map: `SMF70AID`

IIP processors minimum
"""

ziip_max : Final[Field] = Field(
    name='ziip_max',
    origin='SMF70EMM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""IIP processors maximum

SMF Info
--------
    Field: `SMF70EMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

IIP processors maximum
"""
ziip_max.__doc__ = """IIP processors maximum

SMF Info
--------
    Field: `SMF70EMM`
    Record: `SMF70S1`
    Map: `SMF70AID`

IIP processors maximum
"""

ziip_total : Final[Field] = Field(
    name='ziip_total',
    origin='SMF70ETT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""IIP processors total value

SMF Info
--------
    Field: `SMF70ETT`
    Record: `SMF70S1`
    Map: `SMF70AID`

IIP processors total value
"""
ziip_total.__doc__ = """IIP processors total value

SMF Info
--------
    Field: `SMF70ETT`
    Record: `SMF70S1`
    Map: `SMF70AID`

IIP processors total value
"""

u00 : Final[Field] = Field(
    name='u00',
    origin='SMF70U00',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was <= N

SMF Info
--------
    Field: `SMF70U00`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was <= N
"""
u00.__doc__ = """Count of times the number of work units was <= N

SMF Info
--------
    Field: `SMF70U00`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was <= N
"""

u01 : Final[Field] = Field(
    name='u01',
    origin='SMF70U01',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+1

SMF Info
--------
    Field: `SMF70U01`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+1
"""
u01.__doc__ = """Count of times the number of work units was N+1

SMF Info
--------
    Field: `SMF70U01`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+1
"""

u02 : Final[Field] = Field(
    name='u02',
    origin='SMF70U02',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+2

SMF Info
--------
    Field: `SMF70U02`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+2
"""
u02.__doc__ = """Count of times the number of work units was N+2

SMF Info
--------
    Field: `SMF70U02`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+2
"""

u03 : Final[Field] = Field(
    name='u03',
    origin='SMF70U03',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+3

SMF Info
--------
    Field: `SMF70U03`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+3
"""
u03.__doc__ = """Count of times the number of work units was N+3

SMF Info
--------
    Field: `SMF70U03`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+3
"""

u04 : Final[Field] = Field(
    name='u04',
    origin='SMF70U04',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+4 or N+5

SMF Info
--------
    Field: `SMF70U04`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+4 or N+5
"""
u04.__doc__ = """Count of times the number of work units was N+4 or N+5

SMF Info
--------
    Field: `SMF70U04`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+4 or N+5
"""

u05 : Final[Field] = Field(
    name='u05',
    origin='SMF70U05',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+6 to N+10

SMF Info
--------
    Field: `SMF70U05`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+6 to N+10
"""
u05.__doc__ = """Count of times the number of work units was N+6 to N+10

SMF Info
--------
    Field: `SMF70U05`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+6 to N+10
"""

u06 : Final[Field] = Field(
    name='u06',
    origin='SMF70U06',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+11 to N+15

SMF Info
--------
    Field: `SMF70U06`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+11 to N+15
"""
u06.__doc__ = """Count of times the number of work units was N+11 to N+15

SMF Info
--------
    Field: `SMF70U06`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+11 to N+15
"""

u07 : Final[Field] = Field(
    name='u07',
    origin='SMF70U07',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+16 to N+20

SMF Info
--------
    Field: `SMF70U07`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+16 to N+20
"""
u07.__doc__ = """Count of times the number of work units was N+16 to N+20

SMF Info
--------
    Field: `SMF70U07`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+16 to N+20
"""

u08 : Final[Field] = Field(
    name='u08',
    origin='SMF70U08',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+21 to N+30

SMF Info
--------
    Field: `SMF70U08`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+21 to N+30
"""
u08.__doc__ = """Count of times the number of work units was N+21 to N+30

SMF Info
--------
    Field: `SMF70U08`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+21 to N+30
"""

u09 : Final[Field] = Field(
    name='u09',
    origin='SMF70U09',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+31 to N+40

SMF Info
--------
    Field: `SMF70U09`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+31 to N+40
"""
u09.__doc__ = """Count of times the number of work units was N+31 to N+40

SMF Info
--------
    Field: `SMF70U09`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+31 to N+40
"""

u10 : Final[Field] = Field(
    name='u10',
    origin='SMF70U10',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+41 to N+60

SMF Info
--------
    Field: `SMF70U10`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+41 to N+60
"""
u10.__doc__ = """Count of times the number of work units was N+41 to N+60

SMF Info
--------
    Field: `SMF70U10`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+41 to N+60
"""

u11 : Final[Field] = Field(
    name='u11',
    origin='SMF70U11',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+61 to N+80

SMF Info
--------
    Field: `SMF70U11`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+61 to N+80
"""
u11.__doc__ = """Count of times the number of work units was N+61 to N+80

SMF Info
--------
    Field: `SMF70U11`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+61 to N+80
"""

u12 : Final[Field] = Field(
    name='u12',
    origin='SMF70U12',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+81 to N+100

SMF Info
--------
    Field: `SMF70U12`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+81 to N+100
"""
u12.__doc__ = """Count of times the number of work units was N+81 to N+100

SMF Info
--------
    Field: `SMF70U12`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+81 to N+100
"""

u13 : Final[Field] = Field(
    name='u13',
    origin='SMF70U13',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+101 to N+120

SMF Info
--------
    Field: `SMF70U13`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+101 to N+120
"""
u13.__doc__ = """Count of times the number of work units was N+101 to N+120

SMF Info
--------
    Field: `SMF70U13`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+101 to N+120
"""

u14 : Final[Field] = Field(
    name='u14',
    origin='SMF70U14',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was N+121 to N+150

SMF Info
--------
    Field: `SMF70U14`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+121 to N+150
"""
u14.__doc__ = """Count of times the number of work units was N+121 to N+150

SMF Info
--------
    Field: `SMF70U14`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was N+121 to N+150
"""

u15 : Final[Field] = Field(
    name='u15',
    origin='SMF70U15',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70AID,
)
"""Count of times the number of work units was greater N+150

SMF Info
--------
    Field: `SMF70U15`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was greater N+150
"""
u15.__doc__ = """Count of times the number of work units was greater N+150

SMF Info
--------
    Field: `SMF70U15`
    Record: `SMF70S1`
    Map: `SMF70AID`

Count of times the number of work units was greater N+150
"""

mod : Final[Field] = Field(
    name='mod',
    origin='SMF70MOD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""CPU processor family

SMF Info
--------
    Field: `SMF70MOD`
    Record: `SMF70S1`
    Map: `SMF70CTL`

CPU processor family
"""
mod.__doc__ = """CPU processor family

SMF Info
--------
    Field: `SMF70MOD`
    Record: `SMF70S1`
    Map: `SMF70CTL`

CPU processor family
"""

ver : Final[Field] = Field(
    name='ver',
    origin='SMF70VER',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""CPU VERSION NUMBER

SMF Info
--------
    Field: `SMF70VER`
    Record: `SMF70S1`
    Map: `SMF70CTL`

CPU VERSION NUMBER
"""
ver.__doc__ = """CPU VERSION NUMBER

SMF Info
--------
    Field: `SMF70VER`
    Record: `SMF70S1`
    Map: `SMF70CTL`

CPU VERSION NUMBER
"""

bnp : Final[Field] = Field(
    name='bnp',
    origin='SMF70BNP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Number of physical processors assigned for PR/SM use

SMF Info
--------
    Field: `SMF70BNP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Number of physical processors assigned for PR/SM use
"""
bnp.__doc__ = """Number of physical processors assigned for PR/SM use

SMF Info
--------
    Field: `SMF70BNP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Number of physical processors assigned for PR/SM use
"""

inb : Final[Field] = Field(
    name='inb',
    origin='SMF70INB',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""PR/SM indicator bits

SMF Info
--------
    Field: `SMF70INB`
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM indicator bits
"""
inb.__doc__ = """PR/SM indicator bits

SMF Info
--------
    Field: `SMF70INB`
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM indicator bits
"""

diagnose_204_failure : Final[Field] = Field(
    name='diagnose_204_failure',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=inb,
    record=record,
    record_map=SMF70CTL,
)
"""PR/SM - Diagnose X'204' failure(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Diagnose X'204' failure

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
diagnose_204_failure.__doc__ = """PR/SM - Diagnose X'204' failure(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Diagnose X'204' failure

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

physical_proc_chng : Final[Field] = Field(
    name='physical_proc_chng',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=inb,
    record=record,
    record_map=SMF70CTL,
)
"""PR/SM - Number of physical processors has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Number of physical processors has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
physical_proc_chng.__doc__ = """PR/SM - Number of physical processors has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Number of physical processors has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

dispatch_interval_chng : Final[Field] = Field(
    name='dispatch_interval_chng',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=inb,
    record=record,
    record_map=SMF70CTL,
)
"""PR/SM - Dispatch interval value has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Dispatch interval value has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
dispatch_interval_chng.__doc__ = """PR/SM - Dispatch interval value has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Dispatch interval value has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

physical_part : Final[Field] = Field(
    name='physical_part',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=inb,
    record=record,
    record_map=SMF70CTL,
)
"""PR/SM - An additional partition is presented with the name "PHYSICAL". This partition includes all of the otherwise uncaptured time which was used by LPAR but could not be attributed to a specific logical partition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - An additional partition is presented with the name "PHYSICAL". This partition includes all of the otherwise uncaptured time which was used by LPAR but could not be attributed to a specific logical partition

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
physical_part.__doc__ = """PR/SM - An additional partition is presented with the name "PHYSICAL". This partition includes all of the otherwise uncaptured time which was used by LPAR but could not be attributed to a specific logical partition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - An additional partition is presented with the name "PHYSICAL". This partition includes all of the otherwise uncaptured time which was used by LPAR but could not be attributed to a specific logical partition

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

diagnose_204_ext : Final[Field] = Field(
    name='diagnose_204_ext',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=inb,
    record=record,
    record_map=SMF70CTL,
)
"""PR/SM - Diagnose X'204' extended data is supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Diagnose X'204' extended data is supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
diagnose_204_ext.__doc__ = """PR/SM - Diagnose X'204' extended data is supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Diagnose X'204' extended data is supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

diagnose_204_smpl : Final[Field] = Field(
    name='diagnose_204_smpl',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=inb,
    record=record,
    record_map=SMF70CTL,
)
"""Simplified Diagnose X'204' data provided for system running as z/VM guest. CPU consumption by z/VM itself provided with partition data section named "PHYSICAL"(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Simplified Diagnose X'204' data provided for system running as z/VM guest. CPU consumption by z/VM itself provided with partition data section named "PHYSICAL"

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
diagnose_204_smpl.__doc__ = """Simplified Diagnose X'204' data provided for system running as z/VM guest. CPU consumption by z/VM itself provided with partition data section named "PHYSICAL"(V)

SMF Info (Virtual Field)
--------
    Field: Based on `inb`(`SMF70INB`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Simplified Diagnose X'204' data provided for system running as z/VM guest. CPU consumption by z/VM itself provided with partition data section named "PHYSICAL"

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

stf : Final[Field] = Field(
    name='stf',
    origin='SMF70STF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""Control section flags

SMF Info
--------
    Field: `SMF70STF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Control section flags
"""
stf.__doc__ = """Control section flags

SMF Info
--------
    Field: `SMF70STF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Control section flags
"""

store_sys_info : Final[Field] = Field(
    name='store_sys_info',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=stf,
    record=record,
    record_map=SMF70CTL,
)
"""Store-system-information facility installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Store-system-information facility installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
store_sys_info.__doc__ = """Store-system-information facility installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Store-system-information facility installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cpu_adjustment_factor_chng : Final[Field] = Field(
    name='cpu_adjustment_factor_chng',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=stf,
    record=record,
    record_map=SMF70CTL,
)
"""Physical CPU adjustment factor changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Physical CPU adjustment factor changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cpu_adjustment_factor_chng.__doc__ = """Physical CPU adjustment factor changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Physical CPU adjustment factor changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

su_available : Final[Field] = Field(
    name='su_available',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=stf,
    record=record,
    record_map=SMF70CTL,
)
"""Service units available to MVS image changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Service units available to MVS image changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
su_available.__doc__ = """Service units available to MVS image changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Service units available to MVS image changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

rcu : Final[Field] = Field(
    name='rcu',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=stf,
    record=record,
    record_map=SMF70CTL,
)
"""SMF70LAC is provided for systems running in LPAR mode, as a z/VM guest, or under an alternate virtual machine. The value does no longer include CPU wait times.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

SMF70LAC is provided for systems running in LPAR mode, as a z/VM guest, or under an alternate virtual machine. The value does no longer include CPU wait times.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
rcu.__doc__ = """SMF70LAC is provided for systems running in LPAR mode, as a z/VM guest, or under an alternate virtual machine. The value does no longer include CPU wait times.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

SMF70LAC is provided for systems running in LPAR mode, as a z/VM guest, or under an alternate virtual machine. The value does no longer include CPU wait times.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

hwv : Final[Field] = Field(
    name='hwv',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=stf,
    record=record,
    record_map=SMF70CTL,
)
"""SMF70MDL is the model-capacity identifier and SMF70HWM is the physical model. If OFF, SMF70MDL represents both model-capacity identifier and physical model(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

SMF70MDL is the model-capacity identifier and SMF70HWM is the physical model. If OFF, SMF70MDL represents both model-capacity identifier and physical model

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
hwv.__doc__ = """SMF70MDL is the model-capacity identifier and SMF70HWM is the physical model. If OFF, SMF70MDL represents both model-capacity identifier and physical model(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

SMF70MDL is the model-capacity identifier and SMF70HWM is the physical model. If OFF, SMF70MDL represents both model-capacity identifier and physical model

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

cp_promote_slices : Final[Field] = Field(
    name='cp_promote_slices',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=stf,
    record=record,
    record_map=SMF70CTL,
)
"""CP promote slices (OPT parameter BLWLTRPCT) changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

CP promote slices (OPT parameter BLWLTRPCT) changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
cp_promote_slices.__doc__ = """CP promote slices (OPT parameter BLWLTRPCT) changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

CP promote slices (OPT parameter BLWLTRPCT) changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

starvation_threshold : Final[Field] = Field(
    name='starvation_threshold',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=stf,
    record=record,
    record_map=SMF70CTL,
)
"""Swapped-in starvation threshold (OPT parameter BLWLINTHD) changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Swapped-in starvation threshold (OPT parameter BLWLINTHD) changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
starvation_threshold.__doc__ = """Swapped-in starvation threshold (OPT parameter BLWLINTHD) changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Swapped-in starvation threshold (OPT parameter BLWLINTHD) changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

gav : Final[Field] = Field(
    name='gav',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=stf,
    record=record,
    record_map=SMF70CTL,
)
"""SMF70GAU is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

SMF70GAU is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
gav.__doc__ = """SMF70GAU is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `stf`(`SMF70STF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

SMF70GAU is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

dispatch_interval : Final[Field] = Field(
    name='dispatch_interval',
    origin='SMF70GTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""PR/SM - Dispatch accumulated interval time in milliseconds. A zero value indicates that the dispatch interval was dynamically determined

SMF Info
--------
    Field: `SMF70GTS`
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Dispatch accumulated interval time in milliseconds. A zero value indicates that the dispatch interval was dynamically determined
"""
dispatch_interval.__doc__ = """PR/SM - Dispatch accumulated interval time in milliseconds. A zero value indicates that the dispatch interval was dynamically determined

SMF Info
--------
    Field: `SMF70GTS`
    Record: `SMF70S1`
    Map: `SMF70CTL`

PR/SM - Dispatch accumulated interval time in milliseconds. A zero value indicates that the dispatch interval was dynamically determined
"""

mdl : Final[Field] = Field(
    name='mdl',
    origin='SMF70MDL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""EBCDIC CPC model identifier. See Bit 4 of SMF70STF (SMF70HWV)

SMF Info
--------
    Field: `SMF70MDL`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC CPC model identifier. See Bit 4 of SMF70STF (SMF70HWV)
"""
mdl.__doc__ = """EBCDIC CPC model identifier. See Bit 4 of SMF70STF (SMF70HWV)

SMF Info
--------
    Field: `SMF70MDL`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC CPC model identifier. See Bit 4 of SMF70STF (SMF70HWV)
"""

sample_diagnose : Final[Field] = Field(
    name='sample_diagnose',
    origin='SMF70DSA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Number of Diagnose samples

SMF Info
--------
    Field: `SMF70DSA`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Number of Diagnose samples
"""
sample_diagnose.__doc__ = """Number of Diagnose samples

SMF Info
--------
    Field: `SMF70DSA`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Number of Diagnose samples
"""

ifa_online : Final[Field] = Field(
    name='ifa_online',
    origin='SMF70IFA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""zAAPs online at the end of the interval

SMF Info
--------
    Field: `SMF70IFA`
    Record: `SMF70S1`
    Map: `SMF70CTL`

zAAPs online at the end of the interval
"""
ifa_online.__doc__ = """zAAPs online at the end of the interval

SMF Info
--------
    Field: `SMF70IFA`
    Record: `SMF70S1`
    Map: `SMF70CTL`

zAAPs online at the end of the interval
"""

wla : Final[Field] = Field(
    name='wla',
    origin='SMF70WLA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Millions of service units available to MVS image when not running as VM guest. If running as VM guest, capactity available to VM

SMF Info
--------
    Field: `SMF70WLA`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Millions of service units available to MVS image when not running as VM guest. If running as VM guest, capactity available to VM
"""
wla.__doc__ = """Millions of service units available to MVS image when not running as VM guest. If running as VM guest, capactity available to VM

SMF Info
--------
    Field: `SMF70WLA`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Millions of service units available to MVS image when not running as VM guest. If running as VM guest, capactity available to VM
"""

lac : Final[Field] = Field(
    name='lac',
    origin='SMF70LAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Long-term average CPU service in millions of service units. For details, see RCTLACS of IRARCT. Scope of value depends on Bit 3 of SMF70STF (SMF70RCU).

SMF Info
--------
    Field: `SMF70LAC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service in millions of service units. For details, see RCTLACS of IRARCT. Scope of value depends on Bit 3 of SMF70STF (SMF70RCU).
"""
lac.__doc__ = """Long-term average CPU service in millions of service units. For details, see RCTLACS of IRARCT. Scope of value depends on Bit 3 of SMF70STF (SMF70RCU).

SMF Info
--------
    Field: `SMF70LAC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service in millions of service units. For details, see RCTLACS of IRARCT. Scope of value depends on Bit 3 of SMF70STF (SMF70RCU).
"""

hof : Final[Field] = Field(
    name='hof',
    origin='SMF70HOF',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF70CTL,
)
"""Hypervisor date/time offset (aka Sysplex timer offset)

SMF Info
--------
    Field: `SMF70HOF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Hypervisor date/time offset (aka Sysplex timer offset)
"""
hof.__doc__ = """Hypervisor date/time offset (aka Sysplex timer offset)

SMF Info
--------
    Field: `SMF70HOF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Hypervisor date/time offset (aka Sysplex timer offset)
"""

hwm : Final[Field] = Field(
    name='hwm',
    origin='SMF70HWM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""EBCDIC CPC physical model identifier. Valid if Bit 4 of SMF70STF (SMF70HWV) is set.

SMF Info
--------
    Field: `SMF70HWM`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC CPC physical model identifier. Valid if Bit 4 of SMF70STF (SMF70HWV) is set.
"""
hwm.__doc__ = """EBCDIC CPC physical model identifier. Valid if Bit 4 of SMF70STF (SMF70HWV) is set.

SMF Info
--------
    Field: `SMF70HWM`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC CPC physical model identifier. Valid if Bit 4 of SMF70STF (SMF70HWV) is set.
"""

ziip_online : Final[Field] = Field(
    name='ziip_online',
    origin='SMF70SUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""zIIPs online at the end of the interval

SMF Info
--------
    Field: `SMF70SUP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

zIIPs online at the end of the interval
"""
ziip_online.__doc__ = """zIIPs online at the end of the interval

SMF Info
--------
    Field: `SMF70SUP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

zIIPs online at the end of the interval
"""

gjt : Final[Field] = Field(
    name='gjt',
    origin='SMF70GJT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF70CTL,
)
"""Time when the partition that wrote this record has joined or left its capacity group (last change of group name). Also set at IPL time when no member of a capacity group.

SMF Info
--------
    Field: `SMF70GJT`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Time when the partition that wrote this record has joined or left its capacity group (last change of group name). Also set at IPL time when no member of a capacity group.
"""
gjt.__doc__ = """Time when the partition that wrote this record has joined or left its capacity group (last change of group name). Also set at IPL time when no member of a capacity group.

SMF Info
--------
    Field: `SMF70GJT`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Time when the partition that wrote this record has joined or left its capacity group (last change of group name). Also set at IPL time when no member of a capacity group.
"""

pom : Final[Field] = Field(
    name='pom',
    origin='SMF70POM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""EBCDIC plant code that identifies the plant of manufacture for the configuration. The plant code is left-justified with trailing blank characters if necessary

SMF Info
--------
    Field: `SMF70POM`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC plant code that identifies the plant of manufacture for the configuration. The plant code is left-justified with trailing blank characters if necessary
"""
pom.__doc__ = """EBCDIC plant code that identifies the plant of manufacture for the configuration. The plant code is left-justified with trailing blank characters if necessary

SMF Info
--------
    Field: `SMF70POM`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC plant code that identifies the plant of manufacture for the configuration. The plant code is left-justified with trailing blank characters if necessary
"""

csc : Final[Field] = Field(
    name='csc',
    origin='SMF70CSC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""EBCDIC sequence code of the configuration. The sequence code is right-justified with leading EBCDIC zeroes if necessary

SMF Info
--------
    Field: `SMF70CSC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC sequence code of the configuration. The sequence code is right-justified with leading EBCDIC zeroes if necessary
"""
csc.__doc__ = """EBCDIC sequence code of the configuration. The sequence code is right-justified with leading EBCDIC zeroes if necessary

SMF Info
--------
    Field: `SMF70CSC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC sequence code of the configuration. The sequence code is right-justified with leading EBCDIC zeroes if necessary
"""

hhf : Final[Field] = Field(
    name='hhf',
    origin='SMF70HHF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""Additional flags

SMF Info
--------
    Field: `SMF70HHF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Additional flags
"""
hhf.__doc__ = """Additional flags

SMF Info
--------
    Field: `SMF70HHF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Additional flags
"""

hd_supported : Final[Field] = Field(
    name='hd_supported',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=hhf,
    record=record,
    record_map=SMF70CTL,
)
"""HiperDispatch supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

HiperDispatch supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
hd_supported.__doc__ = """HiperDispatch supported(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

HiperDispatch supported

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

hd_active : Final[Field] = Field(
    name='hd_active',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=hhf,
    record=record,
    record_map=SMF70CTL,
)
"""HiperDispatch is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

HiperDispatch is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
hd_active.__doc__ = """HiperDispatch is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

HiperDispatch is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

hd_staus_chng : Final[Field] = Field(
    name='hd_staus_chng',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=hhf,
    record=record,
    record_map=SMF70CTL,
)
"""HiperDispatch status changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

HiperDispatch status changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
hd_staus_chng.__doc__ = """HiperDispatch status changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

HiperDispatch status changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

hismt_failure : Final[Field] = Field(
    name='hismt_failure',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=hhf,
    record=record,
    record_map=SMF70CTL,
)
"""Failure returned by HisMT service. Values in logical core data section, multithreading capacity factors and average thread density values are invalid.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Failure returned by HisMT service. Values in logical core data section, multithreading capacity factors and average thread density values are invalid.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
hismt_failure.__doc__ = """Failure returned by HisMT service. Values in logical core data section, multithreading capacity factors and average thread density values are invalid.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Failure returned by HisMT service. Values in logical core data section, multithreading capacity factors and average thread density values are invalid.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

absolut_msu_capping : Final[Field] = Field(
    name='absolut_msu_capping',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=hhf,
    record=record,
    record_map=SMF70CTL,
)
"""Absolute MSU capping is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Absolute MSU capping is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
absolut_msu_capping.__doc__ = """Absolute MSU capping is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Absolute MSU capping is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prtct_valid : Final[Field] = Field(
    name='prtct_valid',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=hhf,
    record=record,
    record_map=SMF70CTL,
)
"""SMF70OS_PRTCT is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

SMF70OS_PRTCT is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prtct_valid.__doc__ = """SMF70OS_PRTCT is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `hhf`(`SMF70HHF`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

SMF70OS_PRTCT is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

cr : Final[Field] = Field(
    name='cr',
    origin='SMF70CR',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""ZEP field 0

SMF Info
--------
    Field: `SMF70CR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 0
"""
cr.__doc__ = """ZEP field 0

SMF Info
--------
    Field: `SMF70CR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 0
"""

pmi : Final[Field] = Field(
    name='pmi',
    origin='SMF70PMI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Accumulated number of blocked dispatachable units per second that may get promoted in their dispatch priority. To get the average promote event rate, divide SMF70PMI by SMF70SAM

SMF Info
--------
    Field: `SMF70PMI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Accumulated number of blocked dispatachable units per second that may get promoted in their dispatch priority. To get the average promote event rate, divide SMF70PMI by SMF70SAM
"""
pmi.__doc__ = """Accumulated number of blocked dispatachable units per second that may get promoted in their dispatch priority. To get the average promote event rate, divide SMF70PMI by SMF70SAM

SMF Info
--------
    Field: `SMF70PMI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Accumulated number of blocked dispatachable units per second that may get promoted in their dispatch priority. To get the average promote event rate, divide SMF70PMI by SMF70SAM
"""

pmu : Final[Field] = Field(
    name='pmu',
    origin='SMF70PMU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Number of blocked dispatchable units being promoted during the interval

SMF Info
--------
    Field: `SMF70PMU`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Number of blocked dispatchable units being promoted during the interval
"""
pmu.__doc__ = """Number of blocked dispatchable units being promoted during the interval

SMF Info
--------
    Field: `SMF70PMU`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Number of blocked dispatchable units being promoted during the interval
"""

pmw : Final[Field] = Field(
    name='pmw',
    origin='SMF70PMW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Accumulated number of address spaces and enclaves being blocked during the interval. To get the average number of waiters for promote, divide SMF70PMW by SMF70SAM.

SMF Info
--------
    Field: `SMF70PMW`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Accumulated number of address spaces and enclaves being blocked during the interval. To get the average number of waiters for promote, divide SMF70PMW by SMF70SAM.
"""
pmw.__doc__ = """Accumulated number of address spaces and enclaves being blocked during the interval. To get the average number of waiters for promote, divide SMF70PMW by SMF70SAM.

SMF Info
--------
    Field: `SMF70PMW`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Accumulated number of address spaces and enclaves being blocked during the interval. To get the average number of waiters for promote, divide SMF70PMW by SMF70SAM.
"""

pmp : Final[Field] = Field(
    name='pmp',
    origin='SMF70PMP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Maximum number of address spaces and enclaves found being blocked during the interval

SMF Info
--------
    Field: `SMF70PMP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Maximum number of address spaces and enclaves found being blocked during the interval
"""
pmp.__doc__ = """Maximum number of address spaces and enclaves found being blocked during the interval

SMF Info
--------
    Field: `SMF70PMP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Maximum number of address spaces and enclaves found being blocked during the interval
"""

pmt : Final[Field] = Field(
    name='pmt',
    origin='SMF70PMT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""1/1000s of the CPU capacity for promote slices (OPT parameter BLWLTRPCT)

SMF Info
--------
    Field: `SMF70PMT`
    Record: `SMF70S1`
    Map: `SMF70CTL`

1/1000s of the CPU capacity for promote slices (OPT parameter BLWLTRPCT)
"""
pmt.__doc__ = """1/1000s of the CPU capacity for promote slices (OPT parameter BLWLTRPCT)

SMF Info
--------
    Field: `SMF70PMT`
    Record: `SMF70S1`
    Map: `SMF70CTL`

1/1000s of the CPU capacity for promote slices (OPT parameter BLWLTRPCT)
"""

pml : Final[Field] = Field(
    name='pml',
    origin='SMF70PML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Swapped-in starvation threshold. When an address space or enclave not received CPU service within this time interval although it has ready-to-tun work, it is considered being blocked (OPT parameter BLWLINTHD)

SMF Info
--------
    Field: `SMF70PML`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Swapped-in starvation threshold. When an address space or enclave not received CPU service within this time interval although it has ready-to-tun work, it is considered being blocked (OPT parameter BLWLINTHD)
"""
pml.__doc__ = """Swapped-in starvation threshold. When an address space or enclave not received CPU service within this time interval although it has ready-to-tun work, it is considered being blocked (OPT parameter BLWLINTHD)

SMF Info
--------
    Field: `SMF70PML`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Swapped-in starvation threshold. When an address space or enclave not received CPU service within this time interval although it has ready-to-tun work, it is considered being blocked (OPT parameter BLWLINTHD)
"""

mpc : Final[Field] = Field(
    name='mpc',
    origin='SMF70MPC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""When non-zero, EBCDIC model permanent capacity identifier of the configuration. The identifier is left justified with trailing blanks if necessary.

SMF Info
--------
    Field: `SMF70MPC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

When non-zero, EBCDIC model permanent capacity identifier of the configuration. The identifier is left justified with trailing blanks if necessary.
"""
mpc.__doc__ = """When non-zero, EBCDIC model permanent capacity identifier of the configuration. The identifier is left justified with trailing blanks if necessary.

SMF Info
--------
    Field: `SMF70MPC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

When non-zero, EBCDIC model permanent capacity identifier of the configuration. The identifier is left justified with trailing blanks if necessary.
"""

mtc : Final[Field] = Field(
    name='mtc',
    origin='SMF70MTC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""When non-zero, EBCDIC model temporary capacity identifier of the configuration. The identifier is left justified with trailing blanks if necessary.

SMF Info
--------
    Field: `SMF70MTC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

When non-zero, EBCDIC model temporary capacity identifier of the configuration. The identifier is left justified with trailing blanks if necessary.
"""
mtc.__doc__ = """When non-zero, EBCDIC model temporary capacity identifier of the configuration. The identifier is left justified with trailing blanks if necessary.

SMF Info
--------
    Field: `SMF70MTC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

When non-zero, EBCDIC model temporary capacity identifier of the configuration. The identifier is left justified with trailing blanks if necessary.
"""

mcr : Final[Field] = Field(
    name='mcr',
    origin='SMF70MCR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Model capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MDL.

SMF Info
--------
    Field: `SMF70MCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Model capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MDL.
"""
mcr.__doc__ = """Model capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MDL.

SMF Info
--------
    Field: `SMF70MCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Model capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MDL.
"""

mpr : Final[Field] = Field(
    name='mpr',
    origin='SMF70MPR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Model permanent capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MPC.

SMF Info
--------
    Field: `SMF70MPR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Model permanent capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MPC.
"""
mpr.__doc__ = """Model permanent capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MPC.

SMF Info
--------
    Field: `SMF70MPR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Model permanent capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MPC.
"""

mtr : Final[Field] = Field(
    name='mtr',
    origin='SMF70MTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Model temporary capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MTC.

SMF Info
--------
    Field: `SMF70MTR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Model temporary capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MTC.
"""
mtr.__doc__ = """Model temporary capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MTC.

SMF Info
--------
    Field: `SMF70MTR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Model temporary capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MTC.
"""

zep : Final[Field] = Field(
    name='zep',
    origin='SMF70ZEP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""ZEP field 1

SMF Info
--------
    Field: `SMF70ZEP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 1
"""
zep.__doc__ = """ZEP field 1

SMF Info
--------
    Field: `SMF70ZEP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 1
"""

zer : Final[Field] = Field(
    name='zer',
    origin='SMF70ZER',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""ZEP field 2

SMF Info
--------
    Field: `SMF70ZER`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 2
"""
zer.__doc__ = """ZEP field 2

SMF Info
--------
    Field: `SMF70ZER`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 2
"""

zee : Final[Field] = Field(
    name='zee',
    origin='SMF70ZEE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""ZEP field 3

SMF Info
--------
    Field: `SMF70ZEE`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 3
"""
zee.__doc__ = """ZEP field 3

SMF Info
--------
    Field: `SMF70ZEE`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 3
"""

zec : Final[Field] = Field(
    name='zec',
    origin='SMF70ZEC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""ZEP field 4

SMF Info
--------
    Field: `SMF70ZEC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 4
"""
zec.__doc__ = """ZEP field 4

SMF Info
--------
    Field: `SMF70ZEC`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 4
"""

nrm : Final[Field] = Field(
    name='nrm',
    origin='SMF70NRM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Normalization factor for zIIP Multiply zIIP time by this value and divide by 256 to get the equivalent time on a CP

SMF Info
--------
    Field: `SMF70NRM`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Normalization factor for zIIP Multiply zIIP time by this value and divide by 256 to get the equivalent time on a CP
"""
nrm.__doc__ = """Normalization factor for zIIP Multiply zIIP time by this value and divide by 256 to get the equivalent time on a CP

SMF Info
--------
    Field: `SMF70NRM`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Normalization factor for zIIP Multiply zIIP time by this value and divide by 256 to get the equivalent time on a CP
"""

gau : Final[Field] = Field(
    name='gau',
    origin='SMF70GAU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Long-term average of CPU service in millions of service units which would be allowed by the limit of the capacity group but is not used by its members. If the value is negative, this capacity group is capped. Valid if Bit 7 of SMF70STF (SMF70GAV) set.

SMF Info
--------
    Field: `SMF70GAU`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average of CPU service in millions of service units which would be allowed by the limit of the capacity group but is not used by its members. If the value is negative, this capacity group is capped. Valid if Bit 7 of SMF70STF (SMF70GAV) set.
"""
gau.__doc__ = """Long-term average of CPU service in millions of service units which would be allowed by the limit of the capacity group but is not used by its members. If the value is negative, this capacity group is capped. Valid if Bit 7 of SMF70STF (SMF70GAV) set.

SMF Info
--------
    Field: `SMF70GAU`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average of CPU service in millions of service units which would be allowed by the limit of the capacity group but is not used by its members. If the value is negative, this capacity group is capped. Valid if Bit 7 of SMF70STF (SMF70GAV) set.
"""

zei : Final[Field] = Field(
    name='zei',
    origin='SMF70ZEI',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""ZEP field 5

SMF Info
--------
    Field: `SMF70ZEI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 5
"""
zei.__doc__ = """ZEP field 5

SMF Info
--------
    Field: `SMF70ZEI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

ZEP field 5
"""

ncr : Final[Field] = Field(
    name='ncr',
    origin='SMF70NCR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Nominal model-capacity rating. When non-zero, this value is associated with the nominal model capacity as identified in field SMF70MDL. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MCR.

SMF Info
--------
    Field: `SMF70NCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Nominal model-capacity rating. When non-zero, this value is associated with the nominal model capacity as identified in field SMF70MDL. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MCR.
"""
ncr.__doc__ = """Nominal model-capacity rating. When non-zero, this value is associated with the nominal model capacity as identified in field SMF70MDL. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MCR.

SMF Info
--------
    Field: `SMF70NCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Nominal model-capacity rating. When non-zero, this value is associated with the nominal model capacity as identified in field SMF70MDL. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MCR.
"""

npr : Final[Field] = Field(
    name='npr',
    origin='SMF70NPR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Nominal permanent model-capacity rating. When non-zero, this value is associated with the nominal permanent model capacity as identified in field SMF70MPC. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MPR.

SMF Info
--------
    Field: `SMF70NPR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Nominal permanent model-capacity rating. When non-zero, this value is associated with the nominal permanent model capacity as identified in field SMF70MPC. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MPR.
"""
npr.__doc__ = """Nominal permanent model-capacity rating. When non-zero, this value is associated with the nominal permanent model capacity as identified in field SMF70MPC. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MPR.

SMF Info
--------
    Field: `SMF70NPR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Nominal permanent model-capacity rating. When non-zero, this value is associated with the nominal permanent model capacity as identified in field SMF70MPC. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MPR.
"""

ntr : Final[Field] = Field(
    name='ntr',
    origin='SMF70NTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Nominal temporary model-capacity rating. When non-zero, this value is associated with the nominal temporary model capacity as identified in field SMF70MTC. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MTR.

SMF Info
--------
    Field: `SMF70NTR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Nominal temporary model-capacity rating. When non-zero, this value is associated with the nominal temporary model capacity as identified in field SMF70MTC. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MTR.
"""
ntr.__doc__ = """Nominal temporary model-capacity rating. When non-zero, this value is associated with the nominal temporary model capacity as identified in field SMF70MTC. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MTR.

SMF Info
--------
    Field: `SMF70NTR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Nominal temporary model-capacity rating. When non-zero, this value is associated with the nominal temporary model capacity as identified in field SMF70MTC. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MTR.
"""

cai : Final[Field] = Field(
    name='cai',
    origin='SMF70CAI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Capacity-adjustment indication. When zero, the indication is not reported. When in the range 1 to 99, some amount of reduction is indicated. When 100, the machine is operating at its normal capacity. Temporary capacity changes that affect machine performance (for example, CBU or OOCoD) are not included

SMF Info
--------
    Field: `SMF70CAI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Capacity-adjustment indication. When zero, the indication is not reported. When in the range 1 to 99, some amount of reduction is indicated. When 100, the machine is operating at its normal capacity. Temporary capacity changes that affect machine performance (for example, CBU or OOCoD) are not included
"""
cai.__doc__ = """Capacity-adjustment indication. When zero, the indication is not reported. When in the range 1 to 99, some amount of reduction is indicated. When 100, the machine is operating at its normal capacity. Temporary capacity changes that affect machine performance (for example, CBU or OOCoD) are not included

SMF Info
--------
    Field: `SMF70CAI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Capacity-adjustment indication. When zero, the indication is not reported. When in the range 1 to 99, some amount of reduction is indicated. When 100, the machine is operating at its normal capacity. Temporary capacity changes that affect machine performance (for example, CBU or OOCoD) are not included
"""

ccr : Final[Field] = Field(
    name='ccr',
    origin='SMF70CCR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Capacity-change reason. Valid if SMF70CAI is non-zero. When 1, the capacity change is due to the setting of a manual control. When greater than 1, capacity change is due to an internal machine condition

SMF Info
--------
    Field: `SMF70CCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Capacity-change reason. Valid if SMF70CAI is non-zero. When 1, the capacity change is due to the setting of a manual control. When greater than 1, capacity change is due to an internal machine condition
"""
ccr.__doc__ = """Capacity-change reason. Valid if SMF70CAI is non-zero. When 1, the capacity change is due to the setting of a manual control. When greater than 1, capacity change is due to an internal machine condition

SMF Info
--------
    Field: `SMF70CCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Capacity-change reason. Valid if SMF70CAI is non-zero. When 1, the capacity change is due to the setting of a manual control. When greater than 1, capacity change is due to an internal machine condition
"""

mcp : Final[Field] = Field(
    name='mcp',
    origin='SMF70MCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Maximum CPU address available at this IPL

SMF Info
--------
    Field: `SMF70MCP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Maximum CPU address available at this IPL
"""
mcp.__doc__ = """Maximum CPU address available at this IPL

SMF Info
--------
    Field: `SMF70MCP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Maximum CPU address available at this IPL
"""

icp : Final[Field] = Field(
    name='icp',
    origin='SMF70ICP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Highest CPU Id installed at IPL time

SMF Info
--------
    Field: `SMF70ICP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Highest CPU Id installed at IPL time
"""
icp.__doc__ = """Highest CPU Id installed at IPL time

SMF Info
--------
    Field: `SMF70ICP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Highest CPU Id installed at IPL time
"""

ccp : Final[Field] = Field(
    name='ccp',
    origin='SMF70CCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Highest CPU Id currently installed This number can increase upon dynamic CPU addition

SMF Info
--------
    Field: `SMF70CCP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Highest CPU Id currently installed This number can increase upon dynamic CPU addition
"""
ccp.__doc__ = """Highest CPU Id currently installed This number can increase upon dynamic CPU addition

SMF Info
--------
    Field: `SMF70CCP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Highest CPU Id currently installed This number can increase upon dynamic CPU addition
"""

cpu_adjustment_factor_actual : Final[Field] = Field(
    name='cpu_adjustment_factor_actual',
    origin='SMF70CPA_ACTUAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Physical CPU adjustment factor based on Model Capacity Rating (will be used for converting processor time to service units). This value together with SMF70CPUA_scaling_factor replaces SMF70CPA.

SMF Info
--------
    Field: `SMF70CPA_ACTUAL`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Physical CPU adjustment factor based on Model Capacity Rating (will be used for converting processor time to service units). This value together with SMF70CPUA_scaling_factor replaces SMF70CPA.
"""
cpu_adjustment_factor_actual.__doc__ = """Physical CPU adjustment factor based on Model Capacity Rating (will be used for converting processor time to service units). This value together with SMF70CPUA_scaling_factor replaces SMF70CPA.

SMF Info
--------
    Field: `SMF70CPA_ACTUAL`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Physical CPU adjustment factor based on Model Capacity Rating (will be used for converting processor time to service units). This value together with SMF70CPUA_scaling_factor replaces SMF70CPA.
"""

cpa_scaling_factor : Final[Field] = Field(
    name='cpa_scaling_factor',
    origin='SMF70CPA_SCALING_FACTOR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Scaling factor for SMF70CPA_actual

SMF Info
--------
    Field: `SMF70CPA_SCALING_FACTOR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Scaling factor for SMF70CPA_actual
"""
cpa_scaling_factor.__doc__ = """Scaling factor for SMF70CPA_actual

SMF Info
--------
    Field: `SMF70CPA_SCALING_FACTOR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Scaling factor for SMF70CPA_actual
"""

multithreading_cap_cp_max : Final[Field] = Field(
    name='multithreading_cap_cp_max',
    origin='SMF70MCF',
    post='core.scale',
    post_param=1024,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

SMF Info
--------
    Field: `SMF70MCF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""
multithreading_cap_cp_max.__doc__ = """Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

SMF Info
--------
    Field: `SMF70MCF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading maximum capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""

multithreading_cap_ziip_max : Final[Field] = Field(
    name='multithreading_cap_ziip_max',
    origin='SMF70MCFS',
    post='core.scale',
    post_param=1024,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Multithreading maximum capacity numerator for zIIP processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

SMF Info
--------
    Field: `SMF70MCFS`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading maximum capacity numerator for zIIP processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""
multithreading_cap_ziip_max.__doc__ = """Multithreading maximum capacity numerator for zIIP processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

SMF Info
--------
    Field: `SMF70MCFS`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading maximum capacity numerator for zIIP processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""

multithreading_cap_zaap_max : Final[Field] = Field(
    name='multithreading_cap_zaap_max',
    origin='SMF70MCFI',
    post='core.scale',
    post_param=1024,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Multithreading maximum capacity numerator for zAAP processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

SMF Info
--------
    Field: `SMF70MCFI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading maximum capacity numerator for zAAP processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""
multithreading_cap_zaap_max.__doc__ = """Multithreading maximum capacity numerator for zAAP processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

SMF Info
--------
    Field: `SMF70MCFI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading maximum capacity numerator for zAAP processors. Divide this value by 1024 to get the multithreading maximum capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""

multithreading_cap_cp : Final[Field] = Field(
    name='multithreading_cap_cp',
    origin='SMF70CF',
    post='core.scale',
    post_param=1024,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Multithreading capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

SMF Info
--------
    Field: `SMF70CF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""
multithreading_cap_cp.__doc__ = """Multithreading capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

SMF Info
--------
    Field: `SMF70CF`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading capacity numerator for general purpose processors. Divide this value by 1024 to get the multithreading capacity factor for all general purpose processors that were configured ONLINE for the complete interval.

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""

multithreading_cap_ziip : Final[Field] = Field(
    name='multithreading_cap_ziip',
    origin='SMF70CFS',
    post='core.scale',
    post_param=1024,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Multithreading capacity numerator for zIIP processors. Divide this value by 1024 to get get the multithreading capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

SMF Info
--------
    Field: `SMF70CFS`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading capacity numerator for zIIP processors. Divide this value by 1024 to get get the multithreading capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""
multithreading_cap_ziip.__doc__ = """Multithreading capacity numerator for zIIP processors. Divide this value by 1024 to get get the multithreading capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

SMF Info
--------
    Field: `SMF70CFS`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading capacity numerator for zIIP processors. Divide this value by 1024 to get get the multithreading capacity factor for all zIIPs that were configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""

multithreading_cap_zaap : Final[Field] = Field(
    name='multithreading_cap_zaap',
    origin='SMF70CFI',
    post='core.scale',
    post_param=1024,
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Multithreading capacity numerator for zAAP processors. Divide this value by 1024 to get get the multithreading capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

SMF Info
--------
    Field: `SMF70CFI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading capacity numerator for zAAP processors. Divide this value by 1024 to get get the multithreading capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""
multithreading_cap_zaap.__doc__ = """Multithreading capacity numerator for zAAP processors. Divide this value by 1024 to get get the multithreading capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

SMF Info
--------
    Field: `SMF70CFI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Multithreading capacity numerator for zAAP processors. Divide this value by 1024 to get get the multithreading capacity factor for all zAAPs that were configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

Post Processing (`core.scale`)
---------------
The parameter for the post-processor is: `1024`
"""

atd : Final[Field] = Field(
    name='atd',
    origin='SMF70ATD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Average Thread Density numerator for general purpose processors. Divide this value by 1024 to get the average number of active threads for all general purpose processors that were dispatched to physical hardware and configured ONLINE for the complete interval.

SMF Info
--------
    Field: `SMF70ATD`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Average Thread Density numerator for general purpose processors. Divide this value by 1024 to get the average number of active threads for all general purpose processors that were dispatched to physical hardware and configured ONLINE for the complete interval.
"""
atd.__doc__ = """Average Thread Density numerator for general purpose processors. Divide this value by 1024 to get the average number of active threads for all general purpose processors that were dispatched to physical hardware and configured ONLINE for the complete interval.

SMF Info
--------
    Field: `SMF70ATD`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Average Thread Density numerator for general purpose processors. Divide this value by 1024 to get the average number of active threads for all general purpose processors that were dispatched to physical hardware and configured ONLINE for the complete interval.
"""

atds : Final[Field] = Field(
    name='atds',
    origin='SMF70ATDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Average Thread Density numerator for zIIP. Divide this value by 1024 to get the average number of active threads for all zIIPs that were dispatched to physical hardware and configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

SMF Info
--------
    Field: `SMF70ATDS`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Average Thread Density numerator for zIIP. Divide this value by 1024 to get the average number of active threads for all zIIPs that were dispatched to physical hardware and configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed
"""
atds.__doc__ = """Average Thread Density numerator for zIIP. Divide this value by 1024 to get the average number of active threads for all zIIPs that were dispatched to physical hardware and configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed

SMF Info
--------
    Field: `SMF70ATDS`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Average Thread Density numerator for zIIP. Divide this value by 1024 to get the average number of active threads for all zIIPs that were dispatched to physical hardware and configured ONLINE for the complete interval. A zero value is reported if no zIIP is currently installed
"""

atdi : Final[Field] = Field(
    name='atdi',
    origin='SMF70ATDI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Average Thread Density numerator for zAAP. Divide this value by 1024 to get the average number of active threads for all zAAPs that were dispatched to physical hardware and configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

SMF Info
--------
    Field: `SMF70ATDI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Average Thread Density numerator for zAAP. Divide this value by 1024 to get the average number of active threads for all zAAPs that were dispatched to physical hardware and configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed
"""
atdi.__doc__ = """Average Thread Density numerator for zAAP. Divide this value by 1024 to get the average number of active threads for all zAAPs that were dispatched to physical hardware and configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed

SMF Info
--------
    Field: `SMF70ATDI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Average Thread Density numerator for zAAP. Divide this value by 1024 to get the average number of active threads for all zAAPs that were dispatched to physical hardware and configured ONLINE for the complete interval. A zero value is reported if no zAAP is currently installed
"""

lacm : Final[Field] = Field(
    name='lacm',
    origin='SMF70LACM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute MOBILE. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACM.

SMF Info
--------
    Field: `SMF70LACM`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute MOBILE. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACM.
"""
lacm.__doc__ = """Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute MOBILE. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACM.

SMF Info
--------
    Field: `SMF70LACM`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute MOBILE. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACM.
"""

laca : Final[Field] = Field(
    name='laca',
    origin='SMF70LACA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute CATEGORYA. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACA.

SMF Info
--------
    Field: `SMF70LACA`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute CATEGORYA. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACA.
"""
laca.__doc__ = """Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute CATEGORYA. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACA.

SMF Info
--------
    Field: `SMF70LACA`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute CATEGORYA. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACA.
"""

lacb : Final[Field] = Field(
    name='lacb',
    origin='SMF70LACB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute CATEGORYB. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACB.

SMF Info
--------
    Field: `SMF70LACB`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute CATEGORYB. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACB.
"""
lacb.__doc__ = """Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute CATEGORYB. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACB.

SMF Info
--------
    Field: `SMF70LACB`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service (millions of service units) consumed by transactions classified with reporting attribute CATEGORYB. If an address space or enclave is part of a tenant resource group, it will not contribute to SMF70LACB.
"""

adj : Final[Field] = Field(
    name='adj',
    origin='SMF70ADJ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Logical adjustment factor for CPU rate

SMF Info
--------
    Field: `SMF70ADJ`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Logical adjustment factor for CPU rate
"""
adj.__doc__ = """Logical adjustment factor for CPU rate

SMF Info
--------
    Field: `SMF70ADJ`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Logical adjustment factor for CPU rate
"""

laccr : Final[Field] = Field(
    name='laccr',
    origin='SMF70LACCR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Long-term average CPU service (millions of service units) consumed by DFSMS data set encryption. Valid only for IBM z14 and later CPCs

SMF Info
--------
    Field: `SMF70LACCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service (millions of service units) consumed by DFSMS data set encryption. Valid only for IBM z14 and later CPCs
"""
laccr.__doc__ = """Long-term average CPU service (millions of service units) consumed by DFSMS data set encryption. Valid only for IBM z14 and later CPCs

SMF Info
--------
    Field: `SMF70LACCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Long-term average CPU service (millions of service units) consumed by DFSMS data set encryption. Valid only for IBM z14 and later CPCs
"""

maxpu : Final[Field] = Field(
    name='maxpu',
    origin='SMF70MAXPU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""When non-zero, this field indicates how many processor cores are physically available in this particular machine. When the value is 0, it is not defined for this model.

SMF Info
--------
    Field: `SMF70MAXPU`
    Record: `SMF70S1`
    Map: `SMF70CTL`

When non-zero, this field indicates how many processor cores are physically available in this particular machine. When the value is 0, it is not defined for this model.
"""
maxpu.__doc__ = """When non-zero, this field indicates how many processor cores are physically available in this particular machine. When the value is 0, it is not defined for this model.

SMF Info
--------
    Field: `SMF70MAXPU`
    Record: `SMF70S1`
    Map: `SMF70CTL`

When non-zero, this field indicates how many processor cores are physically available in this particular machine. When the value is 0, it is not defined for this model.
"""

os_prtct : Final[Field] = Field(
    name='os_prtct',
    origin='SMF70OS_PRTCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""When non-zero, OSPROTECT system parameter with value other than SYSTEM is in effect. X'01' indicates OSPROTECT=1. May be 0 for IBM z15 and later machines when OSPROTECT=1

SMF Info
--------
    Field: `SMF70OS_PRTCT`
    Record: `SMF70S1`
    Map: `SMF70CTL`

When non-zero, OSPROTECT system parameter with value other than SYSTEM is in effect. X'01' indicates OSPROTECT=1. May be 0 for IBM z15 and later machines when OSPROTECT=1
"""
os_prtct.__doc__ = """When non-zero, OSPROTECT system parameter with value other than SYSTEM is in effect. X'01' indicates OSPROTECT=1. May be 0 for IBM z15 and later machines when OSPROTECT=1

SMF Info
--------
    Field: `SMF70OS_PRTCT`
    Record: `SMF70S1`
    Map: `SMF70CTL`

When non-zero, OSPROTECT system parameter with value other than SYSTEM is in effect. X'01' indicates OSPROTECT=1. May be 0 for IBM z15 and later machines when OSPROTECT=1
"""

ipl_time : Final[Field] = Field(
    name='ipl_time',
    origin='SMF70_IPL_TIME',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF70CTL,
)
"""IPL time of partition (TOD format)

SMF Info
--------
    Field: `SMF70_IPL_TIME`
    Record: `SMF70S1`
    Map: `SMF70CTL`

IPL time of partition (TOD format)
"""
ipl_time.__doc__ = """IPL time of partition (TOD format)

SMF Info
--------
    Field: `SMF70_IPL_TIME`
    Record: `SMF70S1`
    Map: `SMF70CTL`

IPL time of partition (TOD format)
"""

trg_m_cnt : Final[Field] = Field(
    name='trg_m_cnt',
    origin='SMF70_TRG_M_CNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Number of times sampling of tenant resource group memory consumption happened

SMF Info
--------
    Field: `SMF70_TRG_M_CNT`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Number of times sampling of tenant resource group memory consumption happened
"""
trg_m_cnt.__doc__ = """Number of times sampling of tenant resource group memory consumption happened

SMF Info
--------
    Field: `SMF70_TRG_M_CNT`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Number of times sampling of tenant resource group memory consumption happened
"""

cpc_type : Final[Field] = Field(
    name='cpc_type',
    origin='SMF70CPC_TYPE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""CPC Type

SMF Info
--------
    Field: `SMF70CPC_TYPE`
    Record: `SMF70S1`
    Map: `SMF70CTL`

CPC Type
"""
cpc_type.__doc__ = """CPC Type

SMF Info
--------
    Field: `SMF70CPC_TYPE`
    Record: `SMF70S1`
    Map: `SMF70CTL`

CPC Type
"""

mdl_var : Final[Field] = Field(
    name='mdl_var',
    origin='SMF70MDL_VAR',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CTL,
)
"""EBCDIC model variable capacity identifier. The identifier is left justified with trailing blanks if necessary. This field is zero, if not supported by the hardware.

SMF Info
--------
    Field: `SMF70MDL_VAR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC model variable capacity identifier. The identifier is left justified with trailing blanks if necessary. This field is zero, if not supported by the hardware.
"""
mdl_var.__doc__ = """EBCDIC model variable capacity identifier. The identifier is left justified with trailing blanks if necessary. This field is zero, if not supported by the hardware.

SMF Info
--------
    Field: `SMF70MDL_VAR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

EBCDIC model variable capacity identifier. The identifier is left justified with trailing blanks if necessary. This field is zero, if not supported by the hardware.
"""

mvcr : Final[Field] = Field(
    name='mvcr',
    origin='SMF70MVCR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Model variable capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MDL_VAR.

SMF Info
--------
    Field: `SMF70MVCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Model variable capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MDL_VAR.
"""
mvcr.__doc__ = """Model variable capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MDL_VAR.

SMF Info
--------
    Field: `SMF70MVCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Model variable capacity rating. When non-zero, this value is associated with the model capacity as identified in field SMF70MDL_VAR.
"""

nvcr : Final[Field] = Field(
    name='nvcr',
    origin='SMF70NVCR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Nominal model variable capacity rating. When non-zero, this value is associated with the nominal model capacity as identified in field SMF70MDL_VAR. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MVCR.

SMF Info
--------
    Field: `SMF70NVCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Nominal model variable capacity rating. When non-zero, this value is associated with the nominal model capacity as identified in field SMF70MDL_VAR. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MVCR.
"""
nvcr.__doc__ = """Nominal model variable capacity rating. When non-zero, this value is associated with the nominal model capacity as identified in field SMF70MDL_VAR. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MVCR.

SMF Info
--------
    Field: `SMF70NVCR`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Nominal model variable capacity rating. When non-zero, this value is associated with the nominal model capacity as identified in field SMF70MDL_VAR. When field SMF70CAI contains a value of 100, this value equals the value in field SMF70MVCR.
"""

zsu_on_ziip : Final[Field] = Field(
    name='zsu_on_ziip',
    origin='SMF70ZSU_ON_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Unweighted zIIP-eligible service units spent on zIIP for the entire system

SMF Info
--------
    Field: `SMF70ZSU_ON_ZIIP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Unweighted zIIP-eligible service units spent on zIIP for the entire system
"""
zsu_on_ziip.__doc__ = """Unweighted zIIP-eligible service units spent on zIIP for the entire system

SMF Info
--------
    Field: `SMF70ZSU_ON_ZIIP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Unweighted zIIP-eligible service units spent on zIIP for the entire system
"""

zsu_on_cp : Final[Field] = Field(
    name='zsu_on_cp',
    origin='SMF70ZSU_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Unweighted zIIP-eligible service units spent on CP for the entire system

SMF Info
--------
    Field: `SMF70ZSU_ON_CP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Unweighted zIIP-eligible service units spent on CP for the entire system
"""
zsu_on_cp.__doc__ = """Unweighted zIIP-eligible service units spent on CP for the entire system

SMF Info
--------
    Field: `SMF70ZSU_ON_CP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Unweighted zIIP-eligible service units spent on CP for the entire system
"""

jsu_on_ziip : Final[Field] = Field(
    name='jsu_on_ziip',
    origin='SMF70JSU_ON_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Unweighted zIIP-eligible Java service units spent on zIIP for the entire system

SMF Info
--------
    Field: `SMF70JSU_ON_ZIIP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Unweighted zIIP-eligible Java service units spent on zIIP for the entire system
"""
jsu_on_ziip.__doc__ = """Unweighted zIIP-eligible Java service units spent on zIIP for the entire system

SMF Info
--------
    Field: `SMF70JSU_ON_ZIIP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Unweighted zIIP-eligible Java service units spent on zIIP for the entire system
"""

jsu_on_cp : Final[Field] = Field(
    name='jsu_on_cp',
    origin='SMF70JSU_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Unweighted zIIP-eligible Java service units spent on CP for the entire system

SMF Info
--------
    Field: `SMF70JSU_ON_CP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Unweighted zIIP-eligible Java service units spent on CP for the entire system
"""
jsu_on_cp.__doc__ = """Unweighted zIIP-eligible Java service units spent on CP for the entire system

SMF Info
--------
    Field: `SMF70JSU_ON_CP`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Unweighted zIIP-eligible Java service units spent on CP for the entire system
"""

cpe_lo : Final[Field] = Field(
    name='cpe_lo',
    origin='SMF70CPE_LO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Low threshold value of OPT parameter CPENABLE

SMF Info
--------
    Field: `SMF70CPE_LO`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Low threshold value of OPT parameter CPENABLE
"""
cpe_lo.__doc__ = """Low threshold value of OPT parameter CPENABLE

SMF Info
--------
    Field: `SMF70CPE_LO`
    Record: `SMF70S1`
    Map: `SMF70CTL`

Low threshold value of OPT parameter CPENABLE
"""

cpe_hi : Final[Field] = Field(
    name='cpe_hi',
    origin='SMF70CPE_HI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""High threshold value of OPT parameter CPENABLE

SMF Info
--------
    Field: `SMF70CPE_HI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

High threshold value of OPT parameter CPENABLE
"""
cpe_hi.__doc__ = """High threshold value of OPT parameter CPENABLE

SMF Info
--------
    Field: `SMF70CPE_HI`
    Record: `SMF70S1`
    Map: `SMF70CTL`

High threshold value of OPT parameter CPENABLE
"""

cpu_adjustment_factor : Final[Field] = Field(
    name='cpu_adjustment_factor',
    origin=None,
    post="core.inline",
    post_param=__cpu_adjustment_factor_inline_post,
    virtual=True,
    ref=[cpu_adjustment_factor_actual, cpa_scaling_factor],
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CTL,
)
"""Physical CPU adjustment factor based on alternate CPU capability(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_adjustment_factor_actual`(`SMF70CPA_ACTUAL`), `cpa_scaling_factor`(`SMF70CPA_SCALING_FACTOR`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_adjustment_factor_actual / df.cpa_scaling_factor
"""
cpu_adjustment_factor.__doc__ = """Physical CPU adjustment factor based on alternate CPU capability(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_adjustment_factor_actual`(`SMF70CPA_ACTUAL`), `cpa_scaling_factor`(`SMF70CPA_SCALING_FACTOR`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_adjustment_factor_actual / df.cpa_scaling_factor
"""

cpu_adjustment_factor_effective : Final[Field] = Field(
    name='cpu_adjustment_factor_effective',
    origin=None,
    post="core.inline",
    post_param=__cpu_adjustment_factor_effective_inline_post,
    virtual=True,
    ref=[cpu_adjustment_factor, cpu_adjustment_factor_actual, cpu_control_section_length],
    record=record,
    record_map=SMF70CTL,
)
"""Effective CPU adjustment factor(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_adjustment_factor`(Virtual), `cpu_adjustment_factor_actual`(`SMF70CPA_ACTUAL`), `cpu_control_section_length`(`SMF70CCL`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpa_actual_filter = (df.cpu_adjustment_factor_actual != 0) & (df.cpu_control_section_length > 224)
    return df.cpu_adjustment_factor_actual.where(cpa_actual_filter, df.cpu_adjustment_factor)

"""
cpu_adjustment_factor_effective.__doc__ = """Effective CPU adjustment factor(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_adjustment_factor`(Virtual), `cpu_adjustment_factor_actual`(`SMF70CPA_ACTUAL`), `cpu_control_section_length`(`SMF70CCL`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpa_actual_filter = (df.cpu_adjustment_factor_actual != 0) & (df.cpu_control_section_length > 224)
    return df.cpu_adjustment_factor_actual.where(cpa_actual_filter, df.cpu_adjustment_factor)

"""

cpa_scaling_factor_effective : Final[Field] = Field(
    name='cpa_scaling_factor_effective',
    origin=None,
    post="core.inline",
    post_param=__cpa_scaling_factor_effective_inline_post,
    virtual=True,
    ref=[cpa_scaling_factor, cpu_adjustment_factor_actual, cpu_control_section_length],
    record=record,
    record_map=SMF70CTL,
)
"""Scaling factor for SMF70CPA_actual and SMF70CPA_actual_CBP wherever they are used, else 1.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpa_scaling_factor`(`SMF70CPA_SCALING_FACTOR`), `cpu_adjustment_factor_actual`(`SMF70CPA_ACTUAL`), `cpu_control_section_length`(`SMF70CCL`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Scaling factor for SMF70CPA_actual and SMF70CPA_actual_CBP wherever they are used, else  1.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpa_actual_filter = (df.cpu_adjustment_factor_actual != 0) & (df.cpu_control_section_length > 224)
    return df.cpa_scaling_factor.where(cpa_actual_filter, 1)

"""
cpa_scaling_factor_effective.__doc__ = """Scaling factor for SMF70CPA_actual and SMF70CPA_actual_CBP wherever they are used, else 1.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpa_scaling_factor`(`SMF70CPA_SCALING_FACTOR`), `cpu_adjustment_factor_actual`(`SMF70CPA_ACTUAL`), `cpu_control_section_length`(`SMF70CCL`)
    Record: `SMF70S1`
    Map: `SMF70CTL`

Scaling factor for SMF70CPA_actual and SMF70CPA_actual_CBP wherever they are used, else  1.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpa_actual_filter = (df.cpu_adjustment_factor_actual != 0) & (df.cpu_control_section_length > 224)
    return df.cpa_scaling_factor.where(cpa_actual_filter, 1)

"""

cpu_wait_time : Final[Field] = Field(
    name='cpu_wait_time',
    origin='SMF70WAT',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF70CPU,
)
"""CPU wait time

SMF Info
--------
    Field: `SMF70WAT`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU wait time
"""
cpu_wait_time.__doc__ = """CPU wait time

SMF Info
--------
    Field: `SMF70WAT`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU wait time
"""

cpu_id : Final[Field] = Field(
    name='cpu_id',
    origin='SMF70CID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""CPU identifier

SMF Info
--------
    Field: `SMF70CID`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU identifier
"""
cpu_id.__doc__ = """CPU identifier

SMF Info
--------
    Field: `SMF70CID`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU identifier
"""

cnf : Final[Field] = Field(
    name='cnf',
    origin='SMF70CNF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CPU,
)
"""Configuration activity flags

SMF Info
--------
    Field: `SMF70CNF`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Configuration activity flags
"""
cnf.__doc__ = """Configuration activity flags

SMF Info
--------
    Field: `SMF70CNF`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Configuration activity flags
"""

cpu_off : Final[Field] = Field(
    name='cpu_off',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF70CPU,
)
"""CPU is offline while core is online(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU is offline while core is online

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
cpu_off.__doc__ = """CPU is offline while core is online(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU is offline while core is online

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

data_available : Final[Field] = Field(
    name='data_available',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF70CPU,
)
"""Data available for a complete interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Data available for a complete interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
data_available.__doc__ = """Data available for a complete interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Data available for a complete interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

cpu_varied : Final[Field] = Field(
    name='cpu_varied',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF70CPU,
)
"""CPU was varied during Postprocessor duration interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU was varied during Postprocessor duration interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
cpu_varied.__doc__ = """CPU was varied during Postprocessor duration interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU was varied during Postprocessor duration interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

data_invalid : Final[Field] = Field(
    name='data_invalid',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF70CPU,
)
"""Data invalid, CPU reconfigured in measurement interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Data invalid, CPU reconfigured in measurement interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
data_invalid.__doc__ = """Data invalid, CPU reconfigured in measurement interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Data invalid, CPU reconfigured in measurement interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

cpu_is_online : Final[Field] = Field(
    name='cpu_is_online',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=cnf,
    record=record,
    record_map=SMF70CPU,
)
"""CPU online at end of interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU online at end of interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
cpu_is_online.__doc__ = """CPU online at end of interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cnf`(`SMF70CNF`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU online at end of interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

cpu_serial : Final[Field] = Field(
    name='cpu_serial',
    origin='SMF70SER',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CPU,
)
"""CPU serial number, 6 hex digits

SMF Info
--------
    Field: `SMF70SER`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU serial number, 6 hex digits
"""
cpu_serial.__doc__ = """CPU serial number, 6 hex digits

SMF Info
--------
    Field: `SMF70SER`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU serial number, 6 hex digits
"""

cpu_type : Final[Field] = Field(
    name='cpu_type',
    origin='SMF70TYP',
    post='core.map',
    post_param={'default': 'Unknown', 'map': {0: 'CP', 1: 'zAAP', 2: 'zIIP'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""CPU type: 0 = General purpose CP 1 = zAAP 2 = zIIP

SMF Info
--------
    Field: `SMF70TYP`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU type: 0 = General purpose CP 1 = zAAP 2 = zIIP

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `Unknown`)::

    0 => CP
    1 => zAAP
    2 => zIIP
"""
cpu_type.__doc__ = """CPU type: 0 = General purpose CP 1 = zAAP 2 = zIIP

SMF Info
--------
    Field: `SMF70TYP`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU type: 0 = General purpose CP 1 = zAAP 2 = zIIP

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `Unknown`)::

    0 => CP
    1 => zAAP
    2 => zIIP
"""

count_slh : Final[Field] = Field(
    name='count_slh',
    origin='SMF70SLH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""Num of entries to the I/O SLIH

SMF Info
--------
    Field: `SMF70SLH`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Num of entries to the I/O SLIH
"""
count_slh.__doc__ = """Num of entries to the I/O SLIH

SMF Info
--------
    Field: `SMF70SLH`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Num of entries to the I/O SLIH
"""

count_tpi : Final[Field] = Field(
    name='count_tpi',
    origin='SMF70TPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""Number of TPI with CC=1

SMF Info
--------
    Field: `SMF70TPI`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of TPI with CC=1
"""
count_tpi.__doc__ = """Number of TPI with CC=1

SMF Info
--------
    Field: `SMF70TPI`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of TPI with CC=1
"""

vfs : Final[Field] = Field(
    name='vfs',
    origin='SMF70VFS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""Number of samples where the vector bit in the PSA image was ON

SMF Info
--------
    Field: `SMF70VFS`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of samples where the vector bit in the PSA image was ON
"""
vfs.__doc__ = """Number of samples where the vector bit in the PSA image was ON

SMF Info
--------
    Field: `SMF70VFS`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of samples where the vector bit in the PSA image was ON
"""

v : Final[Field] = Field(
    name='v',
    origin='SMF70V',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CPU,
)
"""Vector configuration

SMF Info
--------
    Field: `SMF70V`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Vector configuration
"""
v.__doc__ = """Vector configuration

SMF Info
--------
    Field: `SMF70V`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Vector configuration
"""

vector_online : Final[Field] = Field(
    name='vector_online',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=v,
    record=record,
    record_map=SMF70CPU,
)
"""Vector was online(V)

SMF Info (Virtual Field)
--------
    Field: Based on `v`(`SMF70V`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Vector was online

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
vector_online.__doc__ = """Vector was online(V)

SMF Info (Virtual Field)
--------
    Field: Based on `v`(`SMF70V`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Vector was online

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cpu_parked_time : Final[Field] = Field(
    name='cpu_parked_time',
    origin='SMF70PAT',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF70CPU,
)
"""CPU parked time

SMF Info
--------
    Field: `SMF70PAT`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU parked time
"""
cpu_parked_time.__doc__ = """CPU parked time

SMF Info
--------
    Field: `SMF70PAT`
    Record: `SMF70S1`
    Map: `SMF70CPU`

CPU parked time
"""

count_tcb : Final[Field] = Field(
    name='count_tcb',
    origin='SMF70TCB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""Number of TCB dispatches

SMF Info
--------
    Field: `SMF70TCB`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of TCB dispatches
"""
count_tcb.__doc__ = """Number of TCB dispatches

SMF Info
--------
    Field: `SMF70TCB`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of TCB dispatches
"""

count_srb : Final[Field] = Field(
    name='count_srb',
    origin='SMF70SRB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""Number of SRB dispatches

SMF Info
--------
    Field: `SMF70SRB`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of SRB dispatches
"""
count_srb.__doc__ = """Number of SRB dispatches

SMF Info
--------
    Field: `SMF70SRB`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of SRB dispatches
"""

count_io : Final[Field] = Field(
    name='count_io',
    origin='SMF70NIO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""Number of I/Os for this CPU

SMF Info
--------
    Field: `SMF70NIO`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of I/Os for this CPU
"""
count_io.__doc__ = """Number of I/Os for this CPU

SMF Info
--------
    Field: `SMF70NIO`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Number of I/Os for this CPU
"""

sig : Final[Field] = Field(
    name='sig',
    origin='SMF70SIG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""Total number of SIGPs done by this CPU

SMF Info
--------
    Field: `SMF70SIG`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Total number of SIGPs done by this CPU
"""
sig.__doc__ = """Total number of SIGPs done by this CPU

SMF Info
--------
    Field: `SMF70SIG`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Total number of SIGPs done by this CPU
"""

wtd : Final[Field] = Field(
    name='wtd',
    origin='SMF70WTD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""Wait dispatch count for this CPU

SMF Info
--------
    Field: `SMF70WTD`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Wait dispatch count for this CPU
"""
wtd.__doc__ = """Wait dispatch count for this CPU

SMF Info
--------
    Field: `SMF70WTD`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Wait dispatch count for this CPU
"""

wts : Final[Field] = Field(
    name='wts',
    origin='SMF70WTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""The number of times PR/SM issued a warning-track interruption to a logical processor and z/OS was able to return the logical processor to PR/SM within the grace period

SMF Info
--------
    Field: `SMF70WTS`
    Record: `SMF70S1`
    Map: `SMF70CPU`

The number of times PR/SM issued a warning-track interruption to a logical processor and z/OS was able to return the logical processor to PR/SM within the grace period
"""
wts.__doc__ = """The number of times PR/SM issued a warning-track interruption to a logical processor and z/OS was able to return the logical processor to PR/SM within the grace period

SMF Info
--------
    Field: `SMF70WTS`
    Record: `SMF70S1`
    Map: `SMF70CPU`

The number of times PR/SM issued a warning-track interruption to a logical processor and z/OS was able to return the logical processor to PR/SM within the grace period
"""

wtu : Final[Field] = Field(
    name='wtu',
    origin='SMF70WTU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""The number of times PR/SM issued a warning-track interruption to a logical processor and z/OS was unable to return the logical processor to PR/SM within the grace period

SMF Info
--------
    Field: `SMF70WTU`
    Record: `SMF70S1`
    Map: `SMF70CPU`

The number of times PR/SM issued a warning-track interruption to a logical processor and z/OS was unable to return the logical processor to PR/SM within the grace period
"""
wtu.__doc__ = """The number of times PR/SM issued a warning-track interruption to a logical processor and z/OS was unable to return the logical processor to PR/SM within the grace period

SMF Info
--------
    Field: `SMF70WTU`
    Record: `SMF70S1`
    Map: `SMF70CPU`

The number of times PR/SM issued a warning-track interruption to a logical processor and z/OS was unable to return the logical processor to PR/SM within the grace period
"""

wti : Final[Field] = Field(
    name='wti',
    origin='SMF70WTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CPU,
)
"""Amount of time in milliseconds that a logical processor was yielded to PR/SM due to warning track processing

SMF Info
--------
    Field: `SMF70WTI`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Amount of time in milliseconds that a logical processor was yielded to PR/SM due to warning track processing
"""
wti.__doc__ = """Amount of time in milliseconds that a logical processor was yielded to PR/SM due to warning track processing

SMF Info
--------
    Field: `SMF70WTI`
    Record: `SMF70S1`
    Map: `SMF70CPU`

Amount of time in milliseconds that a logical processor was yielded to PR/SM due to warning track processing
"""

rate_io_interrupt : Final[Field] = Field(
    name='rate_io_interrupt',
    origin=None,
    post="core.inline",
    post_param=__rate_io_interrupt_inline_post,
    virtual=True,
    ref=[interval, count_slh, count_tpi],
    record=record,
    record_map=SMF70CPU,
)
"""I/O interrupt rate(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF70INT`), `count_slh`(`SMF70SLH`), `count_tpi`(`SMF70TPI`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return (df.count_slh + df.count_tpi) / df.interval.dt.total_seconds()

"""
rate_io_interrupt.__doc__ = """I/O interrupt rate(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF70INT`), `count_slh`(`SMF70SLH`), `count_tpi`(`SMF70TPI`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return (df.count_slh + df.count_tpi) / df.interval.dt.total_seconds()

"""

rate_io_interrupt_by_tpi : Final[Field] = Field(
    name='rate_io_interrupt_by_tpi',
    origin=None,
    post="core.inline",
    post_param=__rate_io_interrupt_by_tpi_inline_post,
    virtual=True,
    ref=[interval_in_milliseconds, count_slh, count_tpi],
    record=record,
    record_map=SMF70CPU,
)
"""I/O interrupt rate by TPI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval_in_milliseconds`(Virtual), `count_slh`(`SMF70SLH`), `count_tpi`(`SMF70TPI`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    rate_io_interrupt_by_tpi = df.count_tpi * 1e2 / (df.count_slh + df.count_tpi)
    return rate_io_interrupt_by_tpi.fillna(0)

"""
rate_io_interrupt_by_tpi.__doc__ = """I/O interrupt rate by TPI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval_in_milliseconds`(Virtual), `count_slh`(`SMF70SLH`), `count_tpi`(`SMF70TPI`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    rate_io_interrupt_by_tpi = df.count_tpi * 1e2 / (df.count_slh + df.count_tpi)
    return rate_io_interrupt_by_tpi.fillna(0)

"""

cpu_parked_percentage : Final[Field] = Field(
    name='cpu_parked_percentage',
    origin=None,
    post="core.inline",
    post_param=__cpu_parked_percentage_inline_post,
    virtual=True,
    ref=[cpu_parked_time, interval],
    record=record,
    record_map=SMF70CPU,
)
"""CPU parked percentage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_parked_time`(`SMF70PAT`), `interval`(`SMF70INT`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_parked_time / df.interval

"""
cpu_parked_percentage.__doc__ = """CPU parked percentage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_parked_time`(`SMF70PAT`), `interval`(`SMF70INT`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_parked_time / df.interval

"""

cpu_busy_time : Final[Field] = Field(
    name='cpu_busy_time',
    origin=None,
    post="core.inline",
    post_param=__cpu_busy_time_inline_post,
    virtual=True,
    ref=[cpu_is_online, cpu_wait_time, cpu_parked_time, interval],
    record=record,
    record_map=SMF70CPU,
)
"""CPU busy time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_is_online`(Virtual), `cpu_wait_time`(`SMF70WAT`), `cpu_parked_time`(`SMF70PAT`), `interval`(`SMF70INT`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpu_busy_time = df.interval - df.cpu_wait_time - df.cpu_parked_time
    invalid_filter = df.cpu_is_online & (cpu_busy_time.dt.total_seconds() >= 0.0)
    return cpu_busy_time.where(df.cpu_is_online, pd.Timedelta(0))

"""
cpu_busy_time.__doc__ = """CPU busy time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_is_online`(Virtual), `cpu_wait_time`(`SMF70WAT`), `cpu_parked_time`(`SMF70PAT`), `interval`(`SMF70INT`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpu_busy_time = df.interval - df.cpu_wait_time - df.cpu_parked_time
    invalid_filter = df.cpu_is_online & (cpu_busy_time.dt.total_seconds() >= 0.0)
    return cpu_busy_time.where(df.cpu_is_online, pd.Timedelta(0))

"""

rate_tcb : Final[Field] = Field(
    name='rate_tcb',
    origin=None,
    post="core.inline",
    post_param=__rate_tcb_inline_post,
    virtual=True,
    ref=[count_tcb, interval_in_milliseconds],
    record=record,
    record_map=SMF70CPU,
)
"""TCB rate for the CPU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `count_tcb`(`SMF70TCB`), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.count_tcb * 1e3 / df.interval_in_milliseconds

"""
rate_tcb.__doc__ = """TCB rate for the CPU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `count_tcb`(`SMF70TCB`), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.count_tcb * 1e3 / df.interval_in_milliseconds

"""

rate_srb : Final[Field] = Field(
    name='rate_srb',
    origin=None,
    post="core.inline",
    post_param=__rate_srb_inline_post,
    virtual=True,
    ref=[count_srb, interval_in_milliseconds],
    record=record,
    record_map=SMF70CPU,
)
"""I/O rate for the CPU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `count_srb`(`SMF70SRB`), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.count_srb * 1e3 / df.interval_in_milliseconds

"""
rate_srb.__doc__ = """I/O rate for the CPU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `count_srb`(`SMF70SRB`), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.count_srb * 1e3 / df.interval_in_milliseconds

"""

rate_io : Final[Field] = Field(
    name='rate_io',
    origin=None,
    post="core.inline",
    post_param=__rate_io_inline_post,
    virtual=True,
    ref=[count_io, interval_in_milliseconds],
    record=record,
    record_map=SMF70CPU,
)
"""I/O rate for the CPU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `count_io`(`SMF70NIO`), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.count_io * 1e3 / df.interval_in_milliseconds

"""
rate_io.__doc__ = """I/O rate for the CPU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `count_io`(`SMF70NIO`), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.count_io * 1e3 / df.interval_in_milliseconds

"""

lpar_name : Final[Field] = Field(
    name='lpar_name',
    origin='SMF70LPM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BCT,
)
"""Logical partition name

SMF Info
--------
    Field: `SMF70LPM`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Logical partition name
"""
lpar_name.__doc__ = """Logical partition name

SMF Info
--------
    Field: `SMF70LPM`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Logical partition name
"""

lpar_number : Final[Field] = Field(
    name='lpar_number',
    origin='SMF70LPN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""Logical partition number

SMF Info
--------
    Field: `SMF70LPN`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Logical partition number
"""
lpar_number.__doc__ = """Logical partition number

SMF Info
--------
    Field: `SMF70LPN`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Logical partition number
"""

pfg : Final[Field] = Field(
    name='pfg',
    origin='SMF70PFG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BCT,
)
"""Partition flags

SMF Info
--------
    Field: `SMF70PFG`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition flags
"""
pfg.__doc__ = """Partition flags

SMF Info
--------
    Field: `SMF70PFG`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition flags
"""

pdv : Final[Field] = Field(
    name='pdv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pfg,
    record=record,
    record_map=SMF70BCT,
)
"""Partition has changed from activated to deactivated, or vice versa, during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition has changed from activated to deactivated, or vice versa, during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
pdv.__doc__ = """Partition has changed from activated to deactivated, or vice versa, during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition has changed from activated to deactivated, or vice versa, during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

logical_proc_chng : Final[Field] = Field(
    name='logical_proc_chng',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pfg,
    record=record,
    record_map=SMF70BCT,
)
"""Partition's number of logical processors has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition's number of logical processors has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
logical_proc_chng.__doc__ = """Partition's number of logical processors has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition's number of logical processors has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

dedicated_proc_chng : Final[Field] = Field(
    name='dedicated_proc_chng',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=pfg,
    record=record,
    record_map=SMF70BCT,
)
"""Partition's number of dedicated processors has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition's number of dedicated processors has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
dedicated_proc_chng.__doc__ = """Partition's number of dedicated processors has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition's number of dedicated processors has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

shared_proc_chng : Final[Field] = Field(
    name='shared_proc_chng',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=pfg,
    record=record,
    record_map=SMF70BCT,
)
"""Partition's number of shared processors has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition's number of shared processors has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
shared_proc_chng.__doc__ = """Partition's number of shared processors has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Partition's number of shared processors has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

wlm_active : Final[Field] = Field(
    name='wlm_active',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=pfg,
    record=record,
    record_map=SMF70BCT,
)
"""WLM LPAR Management is active for this partition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

WLM LPAR Management is active for this partition

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
wlm_active.__doc__ = """WLM LPAR Management is active for this partition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

WLM LPAR Management is active for this partition

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

wait_time_field : Final[Field] = Field(
    name='wait_time_field',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=pfg,
    record=record,
    record_map=SMF70BCT,
)
"""Wait time field (SMF70WST) is is defined(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Wait time field (SMF70WST) is is defined

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
wait_time_field.__doc__ = """Wait time field (SMF70WST) is is defined(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Wait time field (SMF70WST) is is defined

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

capacity_limit_chng : Final[Field] = Field(
    name='capacity_limit_chng',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=pfg,
    record=record,
    record_map=SMF70BCT,
)
"""Defined capacity limit has been changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Defined capacity limit has been changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
capacity_limit_chng.__doc__ = """Defined capacity limit has been changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Defined capacity limit has been changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

lpar_cpu_count : Final[Field] = Field(
    name='lpar_cpu_count',
    origin='SMF70BDN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""Number of logical CPUs assigned to this partition. This count matches the number of subsequent PR/SM logical processor data sections

SMF Info
--------
    Field: `SMF70BDN`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Number of logical CPUs assigned to this partition. This count matches the number of subsequent PR/SM logical processor data sections
"""
lpar_cpu_count.__doc__ = """Number of logical CPUs assigned to this partition. This count matches the number of subsequent PR/SM logical processor data sections

SMF Info
--------
    Field: `SMF70BDN`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Number of logical CPUs assigned to this partition. This count matches the number of subsequent PR/SM logical processor data sections
"""

bds : Final[Field] = Field(
    name='bds',
    origin='SMF70BDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""Number of logical processor data blocks to skip before reaching the block(s) belonging to this partition.

SMF Info
--------
    Field: `SMF70BDS`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Number of logical processor data blocks to skip before reaching the block(s) belonging to this partition.
"""
bds.__doc__ = """Number of logical processor data blocks to skip before reaching the block(s) belonging to this partition.

SMF Info
--------
    Field: `SMF70BDS`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Number of logical processor data blocks to skip before reaching the block(s) belonging to this partition.
"""

bda : Final[Field] = Field(
    name='bda',
    origin='SMF70BDA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""Accumulated number of logical CPUs active for this partition

SMF Info
--------
    Field: `SMF70BDA`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Accumulated number of logical CPUs active for this partition
"""
bda.__doc__ = """Accumulated number of logical CPUs active for this partition

SMF Info
--------
    Field: `SMF70BDA`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Accumulated number of logical CPUs active for this partition
"""

sysplex_name : Final[Field] = Field(
    name='sysplex_name',
    origin='SMF70SPN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BCT,
)
"""Name of the logical-partition cluster. Zeros if this partition is no cluster member. For z/OS, the LPAR cluster name is the sysplex name. For any other logical partition, the LPAR cluster name is the name provided in the HMC definition of this logical partition.

SMF Info
--------
    Field: `SMF70SPN`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Name of the logical-partition cluster. Zeros if this partition is no cluster member. For z/OS, the LPAR cluster name is the sysplex name. For any other logical partition, the LPAR cluster name is the name provided in the HMC definition of this logical partition.
"""
sysplex_name.__doc__ = """Name of the logical-partition cluster. Zeros if this partition is no cluster member. For z/OS, the LPAR cluster name is the sysplex name. For any other logical partition, the LPAR cluster name is the name provided in the HMC definition of this logical partition.

SMF Info
--------
    Field: `SMF70SPN`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Name of the logical-partition cluster. Zeros if this partition is no cluster member. For z/OS, the LPAR cluster name is the sysplex name. For any other logical partition, the LPAR cluster name is the name provided in the HMC definition of this logical partition.
"""

system_name : Final[Field] = Field(
    name='system_name',
    origin='SMF70STN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BCT,
)
"""Name of the operating-system instance. Zeros if no name declared for this partition

SMF Info
--------
    Field: `SMF70STN`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Name of the operating-system instance. Zeros if no name declared for this partition
"""
system_name.__doc__ = """Name of the operating-system instance. Zeros if no name declared for this partition

SMF Info
--------
    Field: `SMF70STN`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Name of the operating-system instance. Zeros if no name declared for this partition
"""

csf : Final[Field] = Field(
    name='csf',
    origin='SMF70CSF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""Number of megabytes of central storage currently online to this partition

SMF Info
--------
    Field: `SMF70CSF`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Number of megabytes of central storage currently online to this partition
"""
csf.__doc__ = """Number of megabytes of central storage currently online to this partition

SMF Info
--------
    Field: `SMF70CSF`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Number of megabytes of central storage currently online to this partition
"""

esf : Final[Field] = Field(
    name='esf',
    origin='SMF70ESF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""Number of megabytes of expanded storage currently online to this partition

SMF Info
--------
    Field: `SMF70ESF`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Number of megabytes of expanded storage currently online to this partition
"""
esf.__doc__ = """Number of megabytes of expanded storage currently online to this partition

SMF Info
--------
    Field: `SMF70ESF`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Number of megabytes of expanded storage currently online to this partition
"""

msu : Final[Field] = Field(
    name='msu',
    origin='SMF70MSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""Defined capacity limit (in millions of service units) that a logical partition may consume per unit time on average (extended mode only)

SMF Info
--------
    Field: `SMF70MSU`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Defined capacity limit (in millions of service units) that a logical partition may consume per unit time on average (extended mode only)
"""
msu.__doc__ = """Defined capacity limit (in millions of service units) that a logical partition may consume per unit time on average (extended mode only)

SMF Info
--------
    Field: `SMF70MSU`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Defined capacity limit (in millions of service units) that a logical partition may consume per unit time on average (extended mode only)
"""

pfl : Final[Field] = Field(
    name='pfl',
    origin='SMF70PFL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BCT,
)
"""Additional flags

SMF Info
--------
    Field: `SMF70PFL`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Additional flags
"""
pfl.__doc__ = """Additional flags

SMF Info
--------
    Field: `SMF70PFL`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Additional flags
"""

uvf : Final[Field] = Field(
    name='uvf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pfl,
    record=record,
    record_map=SMF70BCT,
)
"""Content of SMF70UPI is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfl`(`SMF70PFL`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Content of SMF70UPI is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
uvf.__doc__ = """Content of SMF70UPI is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfl`(`SMF70PFL`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Content of SMF70UPI is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

capacity_group_member : Final[Field] = Field(
    name='capacity_group_member',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pfl,
    record=record,
    record_map=SMF70BCT,
)
"""Group flag. This partition is member of a capacity group.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfl`(`SMF70PFL`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Group flag. This partition is member of a capacity group.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
capacity_group_member.__doc__ = """Group flag. This partition is member of a capacity group.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfl`(`SMF70PFL`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Group flag. This partition is member of a capacity group.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

vertically_polarized : Final[Field] = Field(
    name='vertically_polarized',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=pfl,
    record=record,
    record_map=SMF70BCT,
)
"""Polarization flag. This partition is vertically polarized. That is, HiperDispatch mode is active. The SMF70POW fields in the logical processor data section are valid for CPUs of this partition.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfl`(`SMF70PFL`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Polarization flag. This partition is vertically polarized. That is, HiperDispatch mode is active. The SMF70POW fields in the logical processor data section are valid for CPUs of this partition.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
vertically_polarized.__doc__ = """Polarization flag. This partition is vertically polarized. That is, HiperDispatch mode is active. The SMF70POW fields in the logical processor data section are valid for CPUs of this partition.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfl`(`SMF70PFL`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Polarization flag. This partition is vertically polarized. That is, HiperDispatch mode is active. The SMF70POW fields in the logical processor data section are valid for CPUs of this partition.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

init_weight : Final[Field] = Field(
    name='init_weight',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=pfl,
    record=record,
    record_map=SMF70BCT,
)
"""Initial weight instead of current weight should be used to project usage of the members in the capacity group.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfl`(`SMF70PFL`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Initial weight instead of current weight should be used to project usage of the members in the capacity group.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
init_weight.__doc__ = """Initial weight instead of current weight should be used to project usage of the members in the capacity group.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfl`(`SMF70PFL`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Initial weight instead of current weight should be used to project usage of the members in the capacity group.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

upi : Final[Field] = Field(
    name='upi',
    origin='SMF70UPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""User partition ID. Valid if bit 0 (SMF70UVF) of SMF70PFL is set.

SMF Info
--------
    Field: `SMF70UPI`
    Record: `SMF70S1`
    Map: `SMF70BCT`

User partition ID. Valid if bit 0 (SMF70UVF) of SMF70PFL is set.
"""
upi.__doc__ = """User partition ID. Valid if bit 0 (SMF70UVF) of SMF70PFL is set.

SMF Info
--------
    Field: `SMF70UPI`
    Record: `SMF70S1`
    Map: `SMF70BCT`

User partition ID. Valid if bit 0 (SMF70UVF) of SMF70PFL is set.
"""

mtid : Final[Field] = Field(
    name='mtid',
    origin='SMF70MTID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""Maximum Thread Identification. A non-zero value indicates that PROCVIEW CORE is effective for this partition and the hardware supports multithreading.

SMF Info
--------
    Field: `SMF70MTID`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Maximum Thread Identification. A non-zero value indicates that PROCVIEW CORE is effective for this partition and the hardware supports multithreading.
"""
mtid.__doc__ = """Maximum Thread Identification. A non-zero value indicates that PROCVIEW CORE is effective for this partition and the hardware supports multithreading.

SMF Info
--------
    Field: `SMF70MTID`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Maximum Thread Identification. A non-zero value indicates that PROCVIEW CORE is effective for this partition and the hardware supports multithreading.
"""

capactiy_group_name : Final[Field] = Field(
    name='capactiy_group_name',
    origin='SMF70GNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BCT,
)
"""Name of the capacity group this parition belongs to. Valid if bit 1 (SMF70GRP) of SMF70PFL is ON.

SMF Info
--------
    Field: `SMF70GNM`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Name of the capacity group this parition belongs to. Valid if bit 1 (SMF70GRP) of SMF70PFL is ON.
"""
capactiy_group_name.__doc__ = """Name of the capacity group this parition belongs to. Valid if bit 1 (SMF70GRP) of SMF70PFL is ON.

SMF Info
--------
    Field: `SMF70GNM`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Name of the capacity group this parition belongs to. Valid if bit 1 (SMF70GRP) of SMF70PFL is ON.
"""

gmu : Final[Field] = Field(
    name='gmu',
    origin='SMF70GMU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BCT,
)
"""Group maximum licensing units. The maximum number of processor licensing units for the group of logical partitions identified by having the same group name, of which this partition is a member, and which may be consumed per unit of time, on average. Valid if bit 1 (SMF70GRP) of SMF70PFL is ON.

SMF Info
--------
    Field: `SMF70GMU`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Group maximum licensing units. The maximum number of processor licensing units for the group of logical partitions identified by having the same group name, of which this partition is a member, and which may be consumed per unit of time, on average. Valid if bit 1 (SMF70GRP) of SMF70PFL is ON.
"""
gmu.__doc__ = """Group maximum licensing units. The maximum number of processor licensing units for the group of logical partitions identified by having the same group name, of which this partition is a member, and which may be consumed per unit of time, on average. Valid if bit 1 (SMF70GRP) of SMF70PFL is ON.

SMF Info
--------
    Field: `SMF70GMU`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Group maximum licensing units. The maximum number of processor licensing units for the group of logical partitions identified by having the same group name, of which this partition is a member, and which may be consumed per unit of time, on average. Valid if bit 1 (SMF70GRP) of SMF70PFL is ON.
"""

hwgr_name : Final[Field] = Field(
    name='hwgr_name',
    origin='SMF70HWGR_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BCT,
)
"""Name of the hardware group this parition belongs to.

SMF Info
--------
    Field: `SMF70HWGR_NAME`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Name of the hardware group this parition belongs to.
"""
hwgr_name.__doc__ = """Name of the hardware group this parition belongs to.

SMF Info
--------
    Field: `SMF70HWGR_NAME`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Name of the hardware group this parition belongs to.
"""

boostinfo : Final[Field] = Field(
    name='boostinfo',
    origin='SMF70_BOOSTINFO',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BCT,
)
"""Boost information

SMF Info
--------
    Field: `SMF70_BOOSTINFO`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Boost information
"""
boostinfo.__doc__ = """Boost information

SMF Info
--------
    Field: `SMF70_BOOSTINFO`
    Record: `SMF70S1`
    Map: `SMF70BCT`

Boost information
"""

boostinfo_ziip : Final[Field] = Field(
    name='boostinfo_ziip',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=boostinfo,
    record=record,
    record_map=SMF70BCT,
)
"""zIIP boost was active at some point within the interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `boostinfo`(`SMF70_BOOSTINFO`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

zIIP boost was active at some point within the interval.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
boostinfo_ziip.__doc__ = """zIIP boost was active at some point within the interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `boostinfo`(`SMF70_BOOSTINFO`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

zIIP boost was active at some point within the interval.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

boostinfo_speed : Final[Field] = Field(
    name='boostinfo_speed',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=boostinfo,
    record=record,
    record_map=SMF70BCT,
)
"""Speed boost was active at some point within the interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `boostinfo`(`SMF70_BOOSTINFO`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Speed boost was active at some point within the interval.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
boostinfo_speed.__doc__ = """Speed boost was active at some point within the interval.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `boostinfo`(`SMF70_BOOSTINFO`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Speed boost was active at some point within the interval.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

lpar_system_name : Final[Field] = Field(
    name='lpar_system_name',
    origin=None,
    post="core.inline",
    post_param=__lpar_system_name_inline_post,
    virtual=True,
    ref=[lpar_name, system_name],
    record=record,
    record_map=SMF70BCT,
)
"""LPAR-System name(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lpar_name`(`SMF70LPM`), `system_name`(`SMF70STN`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.lpar_name.str.strip().str.cat(df.system_name, '-')

"""
lpar_system_name.__doc__ = """LPAR-System name(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lpar_name`(`SMF70LPM`), `system_name`(`SMF70STN`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.lpar_name.str.strip().str.cat(df.system_name, '-')

"""

msf : Final[Field] = Field(
    name='msf',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=pfg,
    record=record,
    record_map=SMF70BCT,
)
"""No longer used(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
msf.__doc__ = """No longer used(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pfg`(`SMF70PFG`)
    Record: `SMF70S1`
    Map: `SMF70BCT`

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

dispatch_time_total : Final[Field] = Field(
    name='dispatch_time_total',
    origin='SMF70PDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Logical processor total dispatch time, in microseconds. When associated with partition name *PHYSICAL*, this field contains the accumulated number of microseconds during which a physical CPU was busy but the time could not be attributed to a specific logical partition. This time includes the time PR/SM was controlling the physical processor (LPAR management time) as well as any other time the processor was busy for any reason such as managing coupling facility traffic.

SMF Info
--------
    Field: `SMF70PDT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor total dispatch time, in microseconds. When associated with partition name *PHYSICAL*, this field contains the accumulated number of microseconds during which a physical CPU was busy but the time could not be attributed to a specific logical partition. This time includes the time PR/SM was controlling the physical processor (LPAR management time) as well as any other time the processor was busy for any reason such as managing coupling facility traffic.
"""
dispatch_time_total.__doc__ = """Logical processor total dispatch time, in microseconds. When associated with partition name *PHYSICAL*, this field contains the accumulated number of microseconds during which a physical CPU was busy but the time could not be attributed to a specific logical partition. This time includes the time PR/SM was controlling the physical processor (LPAR management time) as well as any other time the processor was busy for any reason such as managing coupling facility traffic.

SMF Info
--------
    Field: `SMF70PDT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor total dispatch time, in microseconds. When associated with partition name *PHYSICAL*, this field contains the accumulated number of microseconds during which a physical CPU was busy but the time could not be attributed to a specific logical partition. This time includes the time PR/SM was controlling the physical processor (LPAR management time) as well as any other time the processor was busy for any reason such as managing coupling facility traffic.
"""

vpa : Final[Field] = Field(
    name='vpa',
    origin='SMF70VPA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Logical processor address

SMF Info
--------
    Field: `SMF70VPA`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor address
"""
vpa.__doc__ = """Logical processor address

SMF Info
--------
    Field: `SMF70VPA`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor address
"""

processor_weight : Final[Field] = Field(
    name='processor_weight',
    origin='SMF70BPS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Processor relative share

SMF Info
--------
    Field: `SMF70BPS`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Processor relative share
"""
processor_weight.__doc__ = """Processor relative share

SMF Info
--------
    Field: `SMF70BPS`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Processor relative share
"""

vpf : Final[Field] = Field(
    name='vpf',
    origin='SMF70VPF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BPD,
)
"""Logical processor flags

SMF Info
--------
    Field: `SMF70VPF`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor flags
"""
vpf.__doc__ = """Logical processor flags

SMF Info
--------
    Field: `SMF70VPF`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor flags
"""

wait_completion_status : Final[Field] = Field(
    name='wait_completion_status',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=vpf,
    record=record,
    record_map=SMF70BPD,
)
"""Wait Completion state enabled(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Wait Completion state enabled

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
wait_completion_status.__doc__ = """Wait Completion state enabled(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Wait Completion state enabled

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

wait_completion_status_chng : Final[Field] = Field(
    name='wait_completion_status_chng',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=vpf,
    record=record,
    record_map=SMF70BPD,
)
"""Wait Completion status has changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Wait Completion status has changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
wait_completion_status_chng.__doc__ = """Wait Completion status has changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Wait Completion status has changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

relative_share_chng : Final[Field] = Field(
    name='relative_share_chng',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=vpf,
    record=record,
    record_map=SMF70BPD,
)
"""Relative share value has changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Relative share value has changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
relative_share_chng.__doc__ = """Relative share value has changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Relative share value has changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

initial_cap_no : Final[Field] = Field(
    name='initial_cap_no',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=vpf,
    record=record,
    record_map=SMF70BPD,
)
"""'Initial Capping' was set to 'ON' on the Hardware Management Console(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

'Initial Capping' was set to 'ON' on the Hardware Management Console

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
initial_cap_no.__doc__ = """'Initial Capping' was set to 'ON' on the Hardware Management Console(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

'Initial Capping' was set to 'ON' on the Hardware Management Console

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

initial_cap_chng : Final[Field] = Field(
    name='initial_cap_chng',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=vpf,
    record=record,
    record_map=SMF70BPD,
)
"""'Initial Capping' status has changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

'Initial Capping' status has changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
initial_cap_chng.__doc__ = """'Initial Capping' status has changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

'Initial Capping' status has changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

logical_vary_online : Final[Field] = Field(
    name='logical_vary_online',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=vpf,
    record=record,
    record_map=SMF70BPD,
)
"""Logical processor varied online during measurment interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor varied online during measurment interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
logical_vary_online.__doc__ = """Logical processor varied online during measurment interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor varied online during measurment interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

hw_cap_limit_chng : Final[Field] = Field(
    name='hw_cap_limit_chng',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=vpf,
    record=record,
    record_map=SMF70BPD,
)
"""SMF70HW_Cap_Limit has changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

SMF70HW_Cap_Limit has changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
hw_cap_limit_chng.__doc__ = """SMF70HW_Cap_Limit has changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

SMF70HW_Cap_Limit has changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

cap_limit_chng : Final[Field] = Field(
    name='cap_limit_chng',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=vpf,
    record=record,
    record_map=SMF70BPD,
)
"""SMF70HWGr_Name or SMF70HWGr_Cap_Limit has changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

SMF70HWGr_Name or SMF70HWGr_Cap_Limit has changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
cap_limit_chng.__doc__ = """SMF70HWGr_Name or SMF70HWGr_Cap_Limit has changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `vpf`(`SMF70VPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

SMF70HWGr_Name or SMF70HWGr_Cap_Limit has changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

flags_polarization : Final[Field] = Field(
    name='flags_polarization',
    origin='SMF70POF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BPD,
)
"""Polarization flags

SMF Info
--------
    Field: `SMF70POF`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Polarization flags
"""
flags_polarization.__doc__ = """Polarization flags

SMF Info
--------
    Field: `SMF70POF`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Polarization flags
"""

poi : Final[Field] = Field(
    name='poi',
    origin='SMF70POI',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BPD,
)
"""Polarization indicator: 00 = Horizontally polarized or polarization not indicated, 01 = Vertically polarized with low entitlement, 10 = Vertically polarized with medium entitlement, 11 = Vertically polarized with high entitlement

SMF Info
--------
    Field: `SMF70POI`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Polarization indicator: 00 = Horizontally polarized or polarization not indicated, 01 = Vertically polarized with low entitlement, 10 = Vertically polarized with medium entitlement, 11 = Vertically polarized with high entitlement
"""
poi.__doc__ = """Polarization indicator: 00 = Horizontally polarized or polarization not indicated, 01 = Vertically polarized with low entitlement, 10 = Vertically polarized with medium entitlement, 11 = Vertically polarized with high entitlement

SMF Info
--------
    Field: `SMF70POI`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Polarization indicator: 00 = Horizontally polarized or polarization not indicated, 01 = Vertically polarized with low entitlement, 10 = Vertically polarized with medium entitlement, 11 = Vertically polarized with high entitlement
"""

poc : Final[Field] = Field(
    name='poc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=poi,
    record=record,
    record_map=SMF70BPD,
)
"""Polarization indication changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `poi`(`SMF70POI`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Polarization indication changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
poc.__doc__ = """Polarization indication changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `poi`(`SMF70POI`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Polarization indication changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

cpu_id_index : Final[Field] = Field(
    name='cpu_id_index',
    origin='SMF70CIX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Index to the CPU-identification name section that contains the EBCDIC name corresponding to the CPU type of the logical processor

SMF Info
--------
    Field: `SMF70CIX`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Index to the CPU-identification name section that contains the EBCDIC name corresponding to the CPU type of the logical processor
"""
cpu_id_index.__doc__ = """Index to the CPU-identification name section that contains the EBCDIC name corresponding to the CPU type of the logical processor

SMF Info
--------
    Field: `SMF70CIX`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Index to the CPU-identification name section that contains the EBCDIC name corresponding to the CPU type of the logical processor
"""

dispatch_time_effective : Final[Field] = Field(
    name='dispatch_time_effective',
    origin='SMF70EDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Logical processor effective dispatch time, in microseconds. When associated with partition name *PHYSICAL*, this field contains the accumulated number of microseconds during which a physical CPU was busy but the time could not be attributed to a specific logical partition or to LPAR management of the physical processor. One example is time managing coupling facility traffic. This field is zero, if not supported by the hardware. LPAR management time is the time from SMF70PDT associated with partition name *PHYSICAL* less the contents of this field.

SMF Info
--------
    Field: `SMF70EDT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor effective dispatch time, in microseconds. When associated with partition name *PHYSICAL*, this field contains the accumulated number of microseconds during which a physical CPU was busy but the time could not be attributed to a specific logical partition or to LPAR management of the physical processor. One example is time managing coupling facility traffic. This field is zero, if not supported by the hardware. LPAR management time is the time from SMF70PDT associated with partition name *PHYSICAL* less the contents of this field.
"""
dispatch_time_effective.__doc__ = """Logical processor effective dispatch time, in microseconds. When associated with partition name *PHYSICAL*, this field contains the accumulated number of microseconds during which a physical CPU was busy but the time could not be attributed to a specific logical partition or to LPAR management of the physical processor. One example is time managing coupling facility traffic. This field is zero, if not supported by the hardware. LPAR management time is the time from SMF70PDT associated with partition name *PHYSICAL* less the contents of this field.

SMF Info
--------
    Field: `SMF70EDT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor effective dispatch time, in microseconds. When associated with partition name *PHYSICAL*, this field contains the accumulated number of microseconds during which a physical CPU was busy but the time could not be attributed to a specific logical partition or to LPAR management of the physical processor. One example is time managing coupling facility traffic. This field is zero, if not supported by the hardware. LPAR management time is the time from SMF70PDT associated with partition name *PHYSICAL* less the contents of this field.
"""

share_actual : Final[Field] = Field(
    name='share_actual',
    origin='SMF70ACS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Accumulated processor actual share

SMF Info
--------
    Field: `SMF70ACS`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Accumulated processor actual share
"""
share_actual.__doc__ = """Accumulated processor actual share

SMF Info
--------
    Field: `SMF70ACS`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Accumulated processor actual share
"""

share_minimum : Final[Field] = Field(
    name='share_minimum',
    origin='SMF70MIS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Processor minimum share

SMF Info
--------
    Field: `SMF70MIS`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Processor minimum share
"""
share_minimum.__doc__ = """Processor minimum share

SMF Info
--------
    Field: `SMF70MIS`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Processor minimum share
"""

share_maximum : Final[Field] = Field(
    name='share_maximum',
    origin='SMF70MAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Processor maximum share

SMF Info
--------
    Field: `SMF70MAS`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Processor maximum share
"""
share_maximum.__doc__ = """Processor maximum share

SMF Info
--------
    Field: `SMF70MAS`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Processor maximum share
"""

nsi : Final[Field] = Field(
    name='nsi',
    origin='SMF70NSI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Number of Diagnose samples within the specified minimum (+10%)

SMF Info
--------
    Field: `SMF70NSI`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Number of Diagnose samples within the specified minimum (+10%)
"""
nsi.__doc__ = """Number of Diagnose samples within the specified minimum (+10%)

SMF Info
--------
    Field: `SMF70NSI`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Number of Diagnose samples within the specified minimum (+10%)
"""

nsa : Final[Field] = Field(
    name='nsa',
    origin='SMF70NSA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Number of Diagnose samples within the specified maximum (-10%)

SMF Info
--------
    Field: `SMF70NSA`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Number of Diagnose samples within the specified maximum (-10%)
"""
nsa.__doc__ = """Number of Diagnose samples within the specified maximum (-10%)

SMF Info
--------
    Field: `SMF70NSA`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Number of Diagnose samples within the specified maximum (-10%)
"""

logical_processor_online_time : Final[Field] = Field(
    name='logical_processor_online_time',
    origin='SMF70ONT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Logical processor online time

SMF Info
--------
    Field: `SMF70ONT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor online time
"""
logical_processor_online_time.__doc__ = """Logical processor online time

SMF Info
--------
    Field: `SMF70ONT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor online time
"""

wst : Final[Field] = Field(
    name='wst',
    origin='SMF70WST',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Logical processor wait state time

SMF Info
--------
    Field: `SMF70WST`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor wait state time
"""
wst.__doc__ = """Logical processor wait state time

SMF Info
--------
    Field: `SMF70WST`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Logical processor wait state time
"""

pma : Final[Field] = Field(
    name='pma',
    origin='SMF70PMA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Average adjustment weight for pricing management

SMF Info
--------
    Field: `SMF70PMA`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Average adjustment weight for pricing management
"""
pma.__doc__ = """Average adjustment weight for pricing management

SMF Info
--------
    Field: `SMF70PMA`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Average adjustment weight for pricing management
"""

cap_wlm_percentage : Final[Field] = Field(
    name='cap_wlm_percentage',
    origin='SMF70NSW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Number of Diagnose samples where WLM considers to cap the set of logical CPUs of type SMF70CIX within the logical partition (see also SMF70NCA).

SMF Info
--------
    Field: `SMF70NSW`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Number of Diagnose samples where WLM considers to cap the set of logical CPUs of type SMF70CIX within the logical partition (see also SMF70NCA).
"""
cap_wlm_percentage.__doc__ = """Number of Diagnose samples where WLM considers to cap the set of logical CPUs of type SMF70CIX within the logical partition (see also SMF70NCA).

SMF Info
--------
    Field: `SMF70NSW`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Number of Diagnose samples where WLM considers to cap the set of logical CPUs of type SMF70CIX within the logical partition (see also SMF70NCA).
"""

pow : Final[Field] = Field(
    name='pow',
    origin='SMF70POW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Weight for the logical CPU when HiperDispatch mode is active. See bit 2 (SMF70PWF) of SMF70PFL. Multiplied by a factor of 4096 for more granularity. The value may be the same or different for all shared CPUs of type SMF70CIX. This is an accumulated value. Divide by the number of Diagnose samples SMF70DSA to get the average weight value for the interval.

SMF Info
--------
    Field: `SMF70POW`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Weight for the logical CPU when HiperDispatch mode is active. See bit 2 (SMF70PWF) of SMF70PFL. Multiplied by a factor of 4096 for more granularity. The value may be the same or different for all shared CPUs of type SMF70CIX. This is an accumulated value. Divide by the number of Diagnose samples SMF70DSA to get the average weight value for the interval.
"""
pow.__doc__ = """Weight for the logical CPU when HiperDispatch mode is active. See bit 2 (SMF70PWF) of SMF70PFL. Multiplied by a factor of 4096 for more granularity. The value may be the same or different for all shared CPUs of type SMF70CIX. This is an accumulated value. Divide by the number of Diagnose samples SMF70DSA to get the average weight value for the interval.

SMF Info
--------
    Field: `SMF70POW`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Weight for the logical CPU when HiperDispatch mode is active. See bit 2 (SMF70PWF) of SMF70PFL. Multiplied by a factor of 4096 for more granularity. The value may be the same or different for all shared CPUs of type SMF70CIX. This is an accumulated value. Divide by the number of Diagnose samples SMF70DSA to get the average weight value for the interval.
"""

cap_actual_percentage : Final[Field] = Field(
    name='cap_actual_percentage',
    origin='SMF70NCA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Number of Diagnose samples where capping actually limited the usage of processor resources for the set of logical CPUs of type SMF70CIX within the logical partition

SMF Info
--------
    Field: `SMF70NCA`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Number of Diagnose samples where capping actually limited the usage of processor resources for the set of logical CPUs of type SMF70CIX within the logical partition
"""
cap_actual_percentage.__doc__ = """Number of Diagnose samples where capping actually limited the usage of processor resources for the set of logical CPUs of type SMF70CIX within the logical partition

SMF Info
--------
    Field: `SMF70NCA`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Number of Diagnose samples where capping actually limited the usage of processor resources for the set of logical CPUs of type SMF70CIX within the logical partition
"""

cap_absolute : Final[Field] = Field(
    name='cap_absolute',
    origin='SMF70HW_CAP_LIMIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""If not zero, absolute limit on partition usage of all CPUs of the type indicated in SMF70CIX in terms of numbers of hundredth of CPUs.

SMF Info
--------
    Field: `SMF70HW_CAP_LIMIT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

If not zero, absolute limit on partition usage of all CPUs of the type indicated in SMF70CIX in terms of numbers of hundredth of CPUs.
"""
cap_absolute.__doc__ = """If not zero, absolute limit on partition usage of all CPUs of the type indicated in SMF70CIX in terms of numbers of hundredth of CPUs.

SMF Info
--------
    Field: `SMF70HW_CAP_LIMIT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

If not zero, absolute limit on partition usage of all CPUs of the type indicated in SMF70CIX in terms of numbers of hundredth of CPUs.
"""

cap_absolute_group : Final[Field] = Field(
    name='cap_absolute_group',
    origin='SMF70HWGR_CAP_LIMIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""If not zero, absolute limit on partition usage of all CPUs of the type indicated in SMF70CIX which are members of the same hardware group, in terms of numbers of hundredth of CPUs.

SMF Info
--------
    Field: `SMF70HWGR_CAP_LIMIT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

If not zero, absolute limit on partition usage of all CPUs of the type indicated in SMF70CIX which are members of the same hardware group, in terms of numbers of hundredth of CPUs.
"""
cap_absolute_group.__doc__ = """If not zero, absolute limit on partition usage of all CPUs of the type indicated in SMF70CIX which are members of the same hardware group, in terms of numbers of hundredth of CPUs.

SMF Info
--------
    Field: `SMF70HWGR_CAP_LIMIT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

If not zero, absolute limit on partition usage of all CPUs of the type indicated in SMF70CIX which are members of the same hardware group, in terms of numbers of hundredth of CPUs.
"""

mtit : Final[Field] = Field(
    name='mtit',
    origin='SMF70MTIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Multithreading Idle Time in microseconds accumulated for all threads of a dispatched core. This field is only valid if SMF70MTID is not zero for this partition.

SMF Info
--------
    Field: `SMF70MTIT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Multithreading Idle Time in microseconds accumulated for all threads of a dispatched core. This field is only valid if SMF70MTID is not zero for this partition.
"""
mtit.__doc__ = """Multithreading Idle Time in microseconds accumulated for all threads of a dispatched core. This field is only valid if SMF70MTID is not zero for this partition.

SMF Info
--------
    Field: `SMF70MTIT`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Multithreading Idle Time in microseconds accumulated for all threads of a dispatched core. This field is only valid if SMF70MTID is not zero for this partition.
"""

lpf : Final[Field] = Field(
    name='lpf',
    origin='SMF70LPF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70BPD,
)
"""Additional processor flags

SMF Info
--------
    Field: `SMF70LPF`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Additional processor flags
"""
lpf.__doc__ = """Additional processor flags

SMF Info
--------
    Field: `SMF70LPF`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Additional processor flags
"""

lpf_topo_changed : Final[Field] = Field(
    name='lpf_topo_changed',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=lpf,
    record=record,
    record_map=SMF70BPD,
)
"""CPU topology has changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lpf`(`SMF70LPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

CPU topology has changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
lpf_topo_changed.__doc__ = """CPU topology has changed during the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `lpf`(`SMF70LPF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

CPU topology has changed during the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

max_nesting_level : Final[Field] = Field(
    name='max_nesting_level',
    origin='SMF70MAXNL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Maximum number of topology nesting level. The value is model dependent with a maximum of 6. If zero, the model does not provide information about the topological nesting levels. If one, there is no actual topological nesting structure. If 2-6, topological nesting levels are available in field SMF70CordL1 up to SMF70CordLx. Where x is the value that defines the maximum number of topology nesting level.

SMF Info
--------
    Field: `SMF70MAXNL`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Maximum number of topology nesting level. The value is model dependent with a maximum of 6. If zero, the model does not provide information about the topological nesting levels. If one, there is no actual topological nesting structure. If 2-6, topological nesting levels are available in field SMF70CordL1 up to SMF70CordLx. Where x is the value that defines the maximum number of topology nesting level.
"""
max_nesting_level.__doc__ = """Maximum number of topology nesting level. The value is model dependent with a maximum of 6. If zero, the model does not provide information about the topological nesting levels. If one, there is no actual topological nesting structure. If 2-6, topological nesting levels are available in field SMF70CordL1 up to SMF70CordLx. Where x is the value that defines the maximum number of topology nesting level.

SMF Info
--------
    Field: `SMF70MAXNL`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Maximum number of topology nesting level. The value is model dependent with a maximum of 6. If zero, the model does not provide information about the topological nesting levels. If one, there is no actual topological nesting structure. If 2-6, topological nesting levels are available in field SMF70CordL1 up to SMF70CordLx. Where x is the value that defines the maximum number of topology nesting level.
"""

cord_l1 : Final[Field] = Field(
    name='cord_l1',
    origin='SMF70CORDL1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Coordinate of the preferred dispatch location of the logical core at topological nesting level 1. Valid if SMF70MaxNL > 0

SMF Info
--------
    Field: `SMF70CORDL1`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 1. Valid if SMF70MaxNL > 0
"""
cord_l1.__doc__ = """Coordinate of the preferred dispatch location of the logical core at topological nesting level 1. Valid if SMF70MaxNL > 0

SMF Info
--------
    Field: `SMF70CORDL1`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 1. Valid if SMF70MaxNL > 0
"""

cord_l2 : Final[Field] = Field(
    name='cord_l2',
    origin='SMF70CORDL2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Coordinate of the preferred dispatch location of the logical core at topological nesting level 2. Valid if SMF70MaxNL > 1

SMF Info
--------
    Field: `SMF70CORDL2`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 2. Valid if SMF70MaxNL > 1
"""
cord_l2.__doc__ = """Coordinate of the preferred dispatch location of the logical core at topological nesting level 2. Valid if SMF70MaxNL > 1

SMF Info
--------
    Field: `SMF70CORDL2`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 2. Valid if SMF70MaxNL > 1
"""

cord_l3 : Final[Field] = Field(
    name='cord_l3',
    origin='SMF70CORDL3',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Coordinate of the preferred dispatch location of the logical core at topological nesting level 3. Valid if SMF70MaxNL > 2

SMF Info
--------
    Field: `SMF70CORDL3`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 3. Valid if SMF70MaxNL > 2
"""
cord_l3.__doc__ = """Coordinate of the preferred dispatch location of the logical core at topological nesting level 3. Valid if SMF70MaxNL > 2

SMF Info
--------
    Field: `SMF70CORDL3`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 3. Valid if SMF70MaxNL > 2
"""

cord_l4 : Final[Field] = Field(
    name='cord_l4',
    origin='SMF70CORDL4',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Coordinate of the preferred dispatch location of the logical core at topological nesting level 4. Valid if SMF70MaxNL > 3

SMF Info
--------
    Field: `SMF70CORDL4`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 4. Valid if SMF70MaxNL > 3
"""
cord_l4.__doc__ = """Coordinate of the preferred dispatch location of the logical core at topological nesting level 4. Valid if SMF70MaxNL > 3

SMF Info
--------
    Field: `SMF70CORDL4`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 4. Valid if SMF70MaxNL > 3
"""

cord_l5 : Final[Field] = Field(
    name='cord_l5',
    origin='SMF70CORDL5',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Coordinate of the preferred dispatch location of the logical core at topological nesting level 5. Valid if SMF70MaxNL > 4

SMF Info
--------
    Field: `SMF70CORDL5`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 5. Valid if SMF70MaxNL > 4
"""
cord_l5.__doc__ = """Coordinate of the preferred dispatch location of the logical core at topological nesting level 5. Valid if SMF70MaxNL > 4

SMF Info
--------
    Field: `SMF70CORDL5`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 5. Valid if SMF70MaxNL > 4
"""

cord_l6 : Final[Field] = Field(
    name='cord_l6',
    origin='SMF70CORDL6',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70BPD,
)
"""Coordinate of the preferred dispatch location of the logical core at topological nesting level 6. Valid if SMF70MaxNL > 5

SMF Info
--------
    Field: `SMF70CORDL6`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 6. Valid if SMF70MaxNL > 5
"""
cord_l6.__doc__ = """Coordinate of the preferred dispatch location of the logical core at topological nesting level 6. Valid if SMF70MaxNL > 5

SMF Info
--------
    Field: `SMF70CORDL6`
    Record: `SMF70S1`
    Map: `SMF70BPD`

Coordinate of the preferred dispatch location of the logical core at topological nesting level 6. Valid if SMF70MaxNL > 5
"""

msu_physical : Final[Field] = Field(
    name='msu_physical',
    origin=None,
    post="core.inline",
    post_param=__msu_physical_inline_post,
    virtual=True,
    ref=[dispatch_time_total, cpa_scaling_factor_effective, cpu_adjustment_factor_effective, interval_in_milliseconds],
    record=record,
    record_map=SMF70BPD,
)
"""Physical MSU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dispatch_time_total`(`SMF70PDT`), `cpa_scaling_factor_effective`(Virtual), `cpu_adjustment_factor_effective`(Virtual), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.dispatch_time_total * 16 * df.cpa_scaling_factor_effective / df.cpu_adjustment_factor_effective * 3.6 / df.interval_in_milliseconds

"""
msu_physical.__doc__ = """Physical MSU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dispatch_time_total`(`SMF70PDT`), `cpa_scaling_factor_effective`(Virtual), `cpu_adjustment_factor_effective`(Virtual), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.dispatch_time_total * 16 * df.cpa_scaling_factor_effective / df.cpu_adjustment_factor_effective * 3.6 / df.interval_in_milliseconds

"""

processor_weight_online : Final[Field] = Field(
    name='processor_weight_online',
    origin=None,
    post="core.inline",
    post_param=__processor_weight_online_inline_post,
    virtual=True,
    ref=[processor_weight, logical_processor_online_time],
    record=record,
    record_map=SMF70BPD,
)
"""Valid processor weight values(V)

SMF Info (Virtual Field)
--------
    Field: Based on `processor_weight`(`SMF70BPS`), `logical_processor_online_time`(`SMF70ONT`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    valid_filter = df.logical_processor_online_time > 0
    return df.processor_weight.where(valid_filter, 0)

"""
processor_weight_online.__doc__ = """Valid processor weight values(V)

SMF Info (Virtual Field)
--------
    Field: Based on `processor_weight`(`SMF70BPS`), `logical_processor_online_time`(`SMF70ONT`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    valid_filter = df.logical_processor_online_time > 0
    return df.processor_weight.where(valid_filter, 0)

"""

cpu_polarization : Final[Field] = Field(
    name='cpu_polarization',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 0, 'map': {'00': 'Horizontal', '01': 'Vertical Low', '10': 'Vertical Medium', '11': 'Vertical High'}},
    virtual=True,
    ref=flags_polarization,
    record=record,
    record_map=SMF70BPD,
)
"""Polarization indicator: 00 = Horizontally polarized or polarization no...(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags_polarization`(`SMF70POF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Polarization indicator: 00 = Horizontally polarized or polarization not indicated, 01 = Vertically polarized with low entitlement, 10 = Vertically polarized with medium entitlement, 11 = Vertically polarized with high entitlement

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `0`::

    00 => Horizontal
    01 => Vertical Low
    10 => Vertical Medium
    11 => Vertical High
"""
cpu_polarization.__doc__ = """Polarization indicator: 00 = Horizontally polarized or polarization no...(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags_polarization`(`SMF70POF`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Polarization indicator: 00 = Horizontally polarized or polarization not indicated, 01 = Vertically polarized with low entitlement, 10 = Vertically polarized with medium entitlement, 11 = Vertically polarized with high entitlement

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `0`::

    00 => Horizontal
    01 => Vertical Low
    10 => Vertical Medium
    11 => Vertical High
"""

msu_effective : Final[Field] = Field(
    name='msu_effective',
    origin=None,
    post="core.inline",
    post_param=__msu_effective_inline_post,
    virtual=True,
    ref=[dispatch_time_effective, cpa_scaling_factor_effective, cpu_adjustment_factor_effective, interval_in_milliseconds],
    record=record,
    record_map=SMF70BPD,
)
"""Effective MSU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dispatch_time_effective`(`SMF70EDT`), `cpa_scaling_factor_effective`(Virtual), `cpu_adjustment_factor_effective`(Virtual), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.dispatch_time_effective * 16 * df.cpa_scaling_factor_effective / df.cpu_adjustment_factor_effective * 3.6 / df.interval_in_milliseconds

"""
msu_effective.__doc__ = """Effective MSU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dispatch_time_effective`(`SMF70EDT`), `cpa_scaling_factor_effective`(Virtual), `cpu_adjustment_factor_effective`(Virtual), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.dispatch_time_effective * 16 * df.cpa_scaling_factor_effective / df.cpu_adjustment_factor_effective * 3.6 / df.interval_in_milliseconds

"""

share_current : Final[Field] = Field(
    name='share_current',
    origin=None,
    post="core.inline",
    post_param=__share_current_inline_post,
    virtual=True,
    ref=[share_actual, sample_diagnose, processor_weight],
    record=record,
    record_map=SMF70BPD,
)
"""Accumulated processor current share(V)

SMF Info (Virtual Field)
--------
    Field: Based on `share_actual`(`SMF70ACS`), `sample_diagnose`(`SMF70DSA`), `processor_weight`(`SMF70BPS`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    zero_samples = df.sample_diagnose == 0
    divided_share = df.share_actual / df.sample_diagnose
    share_actual = df.share_actual.astype('float')
    share_current = share_actual.where(zero_samples, divided_share)
    nonzero_current_share = share_current > 0
    return share_current.where(nonzero_current_share, df.processor_weight)

"""
share_current.__doc__ = """Accumulated processor current share(V)

SMF Info (Virtual Field)
--------
    Field: Based on `share_actual`(`SMF70ACS`), `sample_diagnose`(`SMF70DSA`), `processor_weight`(`SMF70BPS`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    zero_samples = df.sample_diagnose == 0
    divided_share = df.share_actual / df.sample_diagnose
    share_actual = df.share_actual.astype('float')
    share_current = share_actual.where(zero_samples, divided_share)
    nonzero_current_share = share_current > 0
    return share_current.where(nonzero_current_share, df.processor_weight)

"""

logical_processor_is_online : Final[Field] = Field(
    name='logical_processor_is_online',
    origin=None,
    post="core.inline",
    post_param=__logical_processor_is_online_inline_post,
    virtual=True,
    ref=logical_processor_online_time,
    record=record,
    record_map=SMF70BPD,
)
"""Logical processor is online for the given partition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `logical_processor_online_time`(`SMF70ONT`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.logical_processor_online_time > 0

"""
logical_processor_is_online.__doc__ = """Logical processor is online for the given partition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `logical_processor_online_time`(`SMF70ONT`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.logical_processor_online_time > 0

"""

cpu_name : Final[Field] = Field(
    name='cpu_name',
    origin='SMF70CIN',
    post='core.map',
    post_param={'default': 'Unknown', 'map': {'CP': 'CP', 'IIP': 'zIIP', 'AAP': 'zAAP', 'IFL': 'IFL', 'ICF': 'ICF', 'SAP': 'SAP'}},
    type=FieldType.STRING,
    record=record,
    record_map=SMF70CIS,
)
"""CPU-identification name

SMF Info
--------
    Field: `SMF70CIN`
    Record: `SMF70S1`
    Map: `SMF70CIS`

CPU-identification name

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `Unknown`)::

    CP => CP
    IIP => zIIP
    AAP => zAAP
    IFL => IFL
    ICF => ICF
    SAP => SAP
"""
cpu_name.__doc__ = """CPU-identification name

SMF Info
--------
    Field: `SMF70CIN`
    Record: `SMF70S1`
    Map: `SMF70CIS`

CPU-identification name

Post Processing (`core.map`)
---------------
The post processor maps the following values (Default value is `Unknown`)::

    CP => CP
    IIP => zIIP
    AAP => zAAP
    IFL => IFL
    ICF => ICF
    SAP => SAP
"""

cpu_count : Final[Field] = Field(
    name='cpu_count',
    origin='SMF70CTN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CIS,
)
"""Number of physical CPUs of this type at interval end

SMF Info
--------
    Field: `SMF70CTN`
    Record: `SMF70S1`
    Map: `SMF70CIS`

Number of physical CPUs of this type at interval end
"""
cpu_count.__doc__ = """Number of physical CPUs of this type at interval end

SMF Info
--------
    Field: `SMF70CTN`
    Record: `SMF70S1`
    Map: `SMF70CIS`

Number of physical CPUs of this type at interval end
"""

cpu_count_accumulated : Final[Field] = Field(
    name='cpu_count_accumulated',
    origin='SMF70CAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70CIS,
)
"""Accumulated number of physical CPUs. Divide by SMF70DSA to get the average number of physical CPUs of this type applicable during the interval.

SMF Info
--------
    Field: `SMF70CAN`
    Record: `SMF70S1`
    Map: `SMF70CIS`

Accumulated number of physical CPUs. Divide by SMF70DSA to get the average number of physical CPUs of this type applicable during the interval.
"""
cpu_count_accumulated.__doc__ = """Accumulated number of physical CPUs. Divide by SMF70DSA to get the average number of physical CPUs of this type applicable during the interval.

SMF Info
--------
    Field: `SMF70CAN`
    Record: `SMF70S1`
    Map: `SMF70CIS`

Accumulated number of physical CPUs. Divide by SMF70DSA to get the average number of physical CPUs of this type applicable during the interval.
"""

core_id : Final[Field] = Field(
    name='core_id',
    origin='SMF70_CORE_ID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70LCS,
)
"""Core identification

SMF Info
--------
    Field: `SMF70_CORE_ID`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Core identification
"""
core_id.__doc__ = """Core identification

SMF Info
--------
    Field: `SMF70_CORE_ID`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Core identification
"""

core_flg : Final[Field] = Field(
    name='core_flg',
    origin='SMF70_CORE_FLG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70LCS,
)
"""Logical Core Information

SMF Info
--------
    Field: `SMF70_CORE_FLG`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Logical Core Information
"""
core_flg.__doc__ = """Logical Core Information

SMF Info
--------
    Field: `SMF70_CORE_FLG`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Logical Core Information
"""

lpb_valid : Final[Field] = Field(
    name='lpb_valid',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=core_flg,
    record=record,
    record_map=SMF70LCS,
)
"""Core LPAR Busy time is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `core_flg`(`SMF70_CORE_FLG`)
    Record: `SMF70S1`
    Map: `SMF70LCS`

Core LPAR Busy time is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
lpb_valid.__doc__ = """Core LPAR Busy time is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `core_flg`(`SMF70_CORE_FLG`)
    Record: `SMF70S1`
    Map: `SMF70LCS`

Core LPAR Busy time is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cpu_skip : Final[Field] = Field(
    name='cpu_skip',
    origin='SMF70_CPU_SKIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70LCS,
)
"""The CPU data sections for this core are grouped together in the record. To get to the first CPU data section associated with this logical core, skip over the number of CPU data sections specified by this field, starting at the first CPU data section in the record.

SMF Info
--------
    Field: `SMF70_CPU_SKIP`
    Record: `SMF70S1`
    Map: `SMF70LCS`

The CPU data sections for this core are grouped together in the record. To get to the first CPU data section associated with this logical core, skip over the number of CPU data sections specified by this field, starting at the first CPU data section in the record.
"""
cpu_skip.__doc__ = """The CPU data sections for this core are grouped together in the record. To get to the first CPU data section associated with this logical core, skip over the number of CPU data sections specified by this field, starting at the first CPU data section in the record.

SMF Info
--------
    Field: `SMF70_CPU_SKIP`
    Record: `SMF70S1`
    Map: `SMF70LCS`

The CPU data sections for this core are grouped together in the record. To get to the first CPU data section associated with this logical core, skip over the number of CPU data sections specified by this field, starting at the first CPU data section in the record.
"""

cpu_num : Final[Field] = Field(
    name='cpu_num',
    origin='SMF70_CPU_NUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70LCS,
)
"""Number of CPU data sections for this core. This value represents the number of threads that are active on this core.

SMF Info
--------
    Field: `SMF70_CPU_NUM`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Number of CPU data sections for this core. This value represents the number of threads that are active on this core.
"""
cpu_num.__doc__ = """Number of CPU data sections for this core. This value represents the number of threads that are active on this core.

SMF Info
--------
    Field: `SMF70_CPU_NUM`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Number of CPU data sections for this core. This value represents the number of threads that are active on this core.
"""

prod : Final[Field] = Field(
    name='prod',
    origin='SMF70_PROD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70LCS,
)
"""Multithreading core productivity numerator. Divide this value by 1024 to get the multithreading core productivity. A zero value is reported if the core was not configured ONLINE for the complete interval. If SMF70_CPU_NUM is greater than 1, the core productivity represents the percentage of how much work the core resources accomplished while dispatched to physical hardware over the maximum amount of work the core resources could have accomplished while dispatched to physical hardware.

SMF Info
--------
    Field: `SMF70_PROD`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Multithreading core productivity numerator. Divide this value by 1024 to get the multithreading core productivity. A zero value is reported if the core was not configured ONLINE for the complete interval. If SMF70_CPU_NUM is greater than 1, the core productivity represents the percentage of how much work the core resources accomplished while dispatched to physical hardware over the maximum amount of work the core resources could have accomplished while dispatched to physical hardware.
"""
prod.__doc__ = """Multithreading core productivity numerator. Divide this value by 1024 to get the multithreading core productivity. A zero value is reported if the core was not configured ONLINE for the complete interval. If SMF70_CPU_NUM is greater than 1, the core productivity represents the percentage of how much work the core resources accomplished while dispatched to physical hardware over the maximum amount of work the core resources could have accomplished while dispatched to physical hardware.

SMF Info
--------
    Field: `SMF70_PROD`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Multithreading core productivity numerator. Divide this value by 1024 to get the multithreading core productivity. A zero value is reported if the core was not configured ONLINE for the complete interval. If SMF70_CPU_NUM is greater than 1, the core productivity represents the percentage of how much work the core resources accomplished while dispatched to physical hardware over the maximum amount of work the core resources could have accomplished while dispatched to physical hardware.
"""

lpar_busy : Final[Field] = Field(
    name='lpar_busy',
    origin='SMF70_LPAR_BUSY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70LCS,
)
"""Multithreading Core LPAR Busy time in milliseconds. This field is valid if bit 0 of SMF70_CORE_FLG is set.

SMF Info
--------
    Field: `SMF70_LPAR_BUSY`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Multithreading Core LPAR Busy time in milliseconds. This field is valid if bit 0 of SMF70_CORE_FLG is set.
"""
lpar_busy.__doc__ = """Multithreading Core LPAR Busy time in milliseconds. This field is valid if bit 0 of SMF70_CORE_FLG is set.

SMF Info
--------
    Field: `SMF70_LPAR_BUSY`
    Record: `SMF70S1`
    Map: `SMF70LCS`

Multithreading Core LPAR Busy time in milliseconds. This field is valid if bit 0 of SMF70_CORE_FLG is set.
"""

trg_name : Final[Field] = Field(
    name='trg_name',
    origin='SMF70_TRG_NAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70TNT,
)
"""TRG name

SMF Info
--------
    Field: `SMF70_TRG_NAME`
    Record: `SMF70S1`
    Map: `SMF70TNT`

TRG name
"""
trg_name.__doc__ = """TRG name

SMF Info
--------
    Field: `SMF70_TRG_NAME`
    Record: `SMF70S1`
    Map: `SMF70TNT`

TRG name
"""

trg_desc : Final[Field] = Field(
    name='trg_desc',
    origin='SMF70_TRG_DESC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70TNT,
)
"""TRG description

SMF Info
--------
    Field: `SMF70_TRG_DESC`
    Record: `SMF70S1`
    Map: `SMF70TNT`

TRG description
"""
trg_desc.__doc__ = """TRG description

SMF Info
--------
    Field: `SMF70_TRG_DESC`
    Record: `SMF70S1`
    Map: `SMF70TNT`

TRG description
"""

trg_tntid : Final[Field] = Field(
    name='trg_tntid',
    origin='SMF70_TRG_TNTID',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70TNT,
)
"""Tenant identifier

SMF Info
--------
    Field: `SMF70_TRG_TNTID`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Tenant identifier
"""
trg_tntid.__doc__ = """Tenant identifier

SMF Info
--------
    Field: `SMF70_TRG_TNTID`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Tenant identifier
"""

trg_tntname : Final[Field] = Field(
    name='trg_tntname',
    origin='SMF70_TRG_TNTNAME',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70TNT,
)
"""Tenant name

SMF Info
--------
    Field: `SMF70_TRG_TNTNAME`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Tenant name
"""
trg_tntname.__doc__ = """Tenant name

SMF Info
--------
    Field: `SMF70_TRG_TNTNAME`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Tenant name
"""

trg_sbid : Final[Field] = Field(
    name='trg_sbid',
    origin='SMF70_TRG_SBID',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70TNT,
)
"""Solution identifier

SMF Info
--------
    Field: `SMF70_TRG_SBID`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Solution identifier
"""
trg_sbid.__doc__ = """Solution identifier

SMF Info
--------
    Field: `SMF70_TRG_SBID`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Solution identifier
"""

trg_sucp : Final[Field] = Field(
    name='trg_sucp',
    origin='SMF70_TRG_SUCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70TNT,
)
"""Unweighted service units on CPs consumed by TRG

SMF Info
--------
    Field: `SMF70_TRG_SUCP`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Unweighted service units on CPs consumed by TRG
"""
trg_sucp.__doc__ = """Unweighted service units on CPs consumed by TRG

SMF Info
--------
    Field: `SMF70_TRG_SUCP`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Unweighted service units on CPs consumed by TRG
"""

trg_suifa : Final[Field] = Field(
    name='trg_suifa',
    origin='SMF70_TRG_SUIFA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70TNT,
)
"""Unweighted service units on zAAPs consumed by TRG. Valid if bit 8 of SMF70FLA is not set

SMF Info
--------
    Field: `SMF70_TRG_SUIFA`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Unweighted service units on zAAPs consumed by TRG. Valid if bit 8 of SMF70FLA is not set
"""
trg_suifa.__doc__ = """Unweighted service units on zAAPs consumed by TRG. Valid if bit 8 of SMF70FLA is not set

SMF Info
--------
    Field: `SMF70_TRG_SUIFA`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Unweighted service units on zAAPs consumed by TRG. Valid if bit 8 of SMF70FLA is not set
"""

trg_susup : Final[Field] = Field(
    name='trg_susup',
    origin='SMF70_TRG_SUSUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70TNT,
)
"""Unweighted service units on zIIPs consumed by TRG

SMF Info
--------
    Field: `SMF70_TRG_SUSUP`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Unweighted service units on zIIPs consumed by TRG
"""
trg_susup.__doc__ = """Unweighted service units on zIIPs consumed by TRG

SMF Info
--------
    Field: `SMF70_TRG_SUSUP`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Unweighted service units on zIIPs consumed by TRG
"""

trg_lag : Final[Field] = Field(
    name='trg_lag',
    origin='SMF70_TRG_LAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70TNT,
)
"""Long-term average service on general purpose processors in millions of service units per hour consumed by TRG

SMF Info
--------
    Field: `SMF70_TRG_LAC`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Long-term average service on general purpose processors in millions of service units per hour consumed by TRG
"""
trg_lag.__doc__ = """Long-term average service on general purpose processors in millions of service units per hour consumed by TRG

SMF Info
--------
    Field: `SMF70_TRG_LAC`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Long-term average service on general purpose processors in millions of service units per hour consumed by TRG
"""

trg_flags : Final[Field] = Field(
    name='trg_flags',
    origin='SMF70_TRG_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70TNT,
)
"""Flags

SMF Info
--------
    Field: `SMF70_TRG_FLAGS`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Flags
"""
trg_flags.__doc__ = """Flags

SMF Info
--------
    Field: `SMF70_TRG_FLAGS`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Flags
"""

trg_mem : Final[Field] = Field(
    name='trg_mem',
    origin='SMF70_TRG_MEM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70TNT,
)
"""Memory consumption of tenant resource group in units of 4K frames

SMF Info
--------
    Field: `SMF70_TRG_MEM`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Memory consumption of tenant resource group in units of 4K frames
"""
trg_mem.__doc__ = """Memory consumption of tenant resource group in units of 4K frames

SMF Info
--------
    Field: `SMF70_TRG_MEM`
    Record: `SMF70S1`
    Map: `SMF70TNT`

Memory consumption of tenant resource group in units of 4K frames
"""

cpu_unparked_time : Final[Field] = Field(
    name='cpu_unparked_time',
    origin=None,
    post="core.inline",
    post_param=__cpu_unparked_time_inline_post,
    virtual=True,
    ref=[cpu_parked_time, interval, cpu_is_online, cpu_busy_time],
    record=record,
    record_map=SMF70CPU,
)
"""CPU unparked time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_parked_time`(`SMF70PAT`), `interval`(`SMF70INT`), `cpu_is_online`(Virtual), `cpu_busy_time`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpu_unparked_time = df.interval - df.cpu_parked_time
    invalid_filter = df.cpu_is_online & (df.cpu_busy_time.dt.total_seconds() >= 0)
    return cpu_unparked_time.where(invalid_filter, pd.Timedelta(0))

"""
cpu_unparked_time.__doc__ = """CPU unparked time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_parked_time`(`SMF70PAT`), `interval`(`SMF70INT`), `cpu_is_online`(Virtual), `cpu_busy_time`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpu_unparked_time = df.interval - df.cpu_parked_time
    invalid_filter = df.cpu_is_online & (df.cpu_busy_time.dt.total_seconds() >= 0)
    return cpu_unparked_time.where(invalid_filter, pd.Timedelta(0))

"""

cpu_unparked_percentage : Final[Field] = Field(
    name='cpu_unparked_percentage',
    origin=None,
    post="core.inline",
    post_param=__cpu_unparked_percentage_inline_post,
    virtual=True,
    ref=[cpu_unparked_time, interval_in_milliseconds],
    record=record,
    record_map=SMF70CPU,
)
"""CPU unparked percentage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_unparked_time`(Virtual), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_unparked_time / df.interval

"""
cpu_unparked_percentage.__doc__ = """CPU unparked percentage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_unparked_time`(Virtual), `interval_in_milliseconds`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_unparked_time / df.interval

"""

cpu_busy_percentage : Final[Field] = Field(
    name='cpu_busy_percentage',
    origin=None,
    post="core.inline",
    post_param=__cpu_busy_percentage_inline_post,
    virtual=True,
    ref=[cpu_busy_time, cpu_unparked_time, cpu_unparked_percentage],
    record=record,
    record_map=SMF70CPU,
)
"""CPU busy percentage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_busy_time`(Virtual), `cpu_unparked_time`(Virtual), `cpu_unparked_percentage`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpu_busy_percentage = df.cpu_busy_time * df.cpu_unparked_percentage / df.cpu_unparked_time
    return cpu_busy_percentage.fillna(0)

"""
cpu_busy_percentage.__doc__ = """CPU busy percentage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_busy_time`(Virtual), `cpu_unparked_time`(Virtual), `cpu_unparked_percentage`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    cpu_busy_percentage = df.cpu_busy_time * df.cpu_unparked_percentage / df.cpu_unparked_time
    return cpu_busy_percentage.fillna(0)

"""

unparked_percentage : Final[Field] = Field(
    name='unparked_percentage',
    origin=None,
    post='core.aggregate',
    post_param="""sum""",
    virtual=True,
    ref=[cpu_unparked_percentage, timestamp, cpu_type],
    record=record,
    record_map=SMF70CPU,
)
"""Total MVS unparked percentage, per CPU type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_unparked_percentage`(Virtual), `timestamp`(Virtual), `cpu_type`(`SMF70TYP`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.aggregate`)
---------------
The parameter for the post-processor is: `sum`
"""
unparked_percentage.__doc__ = """Total MVS unparked percentage, per CPU type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_unparked_percentage`(Virtual), `timestamp`(Virtual), `cpu_type`(`SMF70TYP`)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.aggregate`)
---------------
The parameter for the post-processor is: `sum`
"""

mvs_busy_percentage : Final[Field] = Field(
    name='mvs_busy_percentage',
    origin=None,
    post="core.inline",
    post_param=__mvs_busy_percentage_inline_post,
    virtual=True,
    ref=[cpu_busy_percentage, unparked_percentage],
    record=record,
    record_map=SMF70CPU,
)
"""Total MVS busy percentage, per CPU type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_busy_percentage`(Virtual), `unparked_percentage`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_busy_percentage * 100 / df.unparked_percentage

"""
mvs_busy_percentage.__doc__ = """Total MVS busy percentage, per CPU type(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_busy_percentage`(Virtual), `unparked_percentage`(Virtual)
    Record: `SMF70S1`
    Map: `SMF70CPU`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.cpu_busy_percentage * 100 / df.unparked_percentage

"""

utilization_per_cpu_physical : Final[Field] = Field(
    name='utilization_per_cpu_physical',
    origin=None,
    post="core.inline",
    post_param=__utilization_per_cpu_physical_inline_post,
    virtual=True,
    ref=[dispatch_time_total, logical_processor_online_time, cpu_count],
    record=record,
    record_map=SMF70BPD,
)
"""Physical per CPU Utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dispatch_time_total`(`SMF70PDT`), `logical_processor_online_time`(`SMF70ONT`), `cpu_count`(`SMF70CTN`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Average physical per CPU Utilization. Multiply with LPAR online LCP count to get LPAR CPU  utilization.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    utilization_per_cpu_physical = 100 * df.dispatch_time_total / df.logical_processor_online_time
    utilization_per_cpu_physical = utilization_per_cpu_physical / df.cpu_count
    return utilization_per_cpu_physical.fillna(0)

"""
utilization_per_cpu_physical.__doc__ = """Physical per CPU Utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dispatch_time_total`(`SMF70PDT`), `logical_processor_online_time`(`SMF70ONT`), `cpu_count`(`SMF70CTN`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Average physical per CPU Utilization. Multiply with LPAR online LCP count to get LPAR CPU  utilization.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    utilization_per_cpu_physical = 100 * df.dispatch_time_total / df.logical_processor_online_time
    utilization_per_cpu_physical = utilization_per_cpu_physical / df.cpu_count
    return utilization_per_cpu_physical.fillna(0)

"""

lpar_management_per_cpu : Final[Field] = Field(
    name='lpar_management_per_cpu',
    origin=None,
    post="core.inline",
    post_param=__lpar_management_per_cpu_inline_post,
    virtual=True,
    ref=[dispatch_time_total, dispatch_time_effective, logical_processor_online_time, cpu_count],
    record=record,
    record_map=SMF70BPD,
)
"""Physical per CPU Utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dispatch_time_total`(`SMF70PDT`), `dispatch_time_effective`(`SMF70EDT`), `logical_processor_online_time`(`SMF70ONT`), `cpu_count`(`SMF70CTN`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Average physical per CPU Utilization. Multiply with LPAR online LCP count to get LPAR CPU  utilization.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    lpar_management_per_cpu = 100 * (df.dispatch_time_total - df.dispatch_time_effective) / df.logical_processor_online_time
    lpar_management_per_cpu = lpar_management_per_cpu / df.cpu_count
    return lpar_management_per_cpu.fillna(0)

"""
lpar_management_per_cpu.__doc__ = """Physical per CPU Utilization(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dispatch_time_total`(`SMF70PDT`), `dispatch_time_effective`(`SMF70EDT`), `logical_processor_online_time`(`SMF70ONT`), `cpu_count`(`SMF70CTN`)
    Record: `SMF70S1`
    Map: `SMF70BPD`

Average physical per CPU Utilization. Multiply with LPAR online LCP count to get LPAR CPU  utilization.

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    lpar_management_per_cpu = 100 * (df.dispatch_time_total - df.dispatch_time_effective) / df.logical_processor_online_time
    lpar_management_per_cpu = lpar_management_per_cpu / df.cpu_count
    return lpar_management_per_cpu.fillna(0)

"""
