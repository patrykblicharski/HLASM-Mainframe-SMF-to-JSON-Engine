# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 70 Subtype 2"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=70,
                                smf_subtype=2,
                                spec='SMF 70 Subtype 2',
                                post=None)
"""SMF 70 Subtype 2"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __interval_in_milliseconds_inline_post(df):
    return df.interval.dt.total_seconds() * 1e3



SMF70PRO: Final[RecordMap] = RecordMap(
    origin='SMF70PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=True)
"""RMF Product Section"""
R702CCF: Final[RecordMap] = RecordMap(
    origin='R702CCF',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='ICSF section',
    post=None,
    record_mapping=False)
"""ICSF section"""
R702TYP3: Final[RecordMap] = RecordMap(
    origin='R702TYP3',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Subtype 2 Data Sections Cryptographic Coprocessor',
    post=None,
    record_mapping=False)
"""Subtype 2 Data Sections Cryptographic Coprocessor"""
R702TYP4: Final[RecordMap] = RecordMap(
    origin='R702TYP4',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Cryptographic Accelerator',
    post=None,
    record_mapping=False)
"""Cryptographic Accelerator"""
R702TYP5: Final[RecordMap] = RecordMap(
    origin='R702TYP5',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Cryptographic PKCS11 Coprocessor',
    post=None,
    record_mapping=False)
"""Cryptographic PKCS11 Coprocessor"""
R7024TC: Final[RecordMap] = RecordMap(
    origin='R7024TC',
    record=record,
    parent=R702TYP4,
    is_multiple=True,
    is_compound=True,
    spec='Timers & counters for the crypto accelerator',
    post=None,
    record_mapping=False)
"""Timers & counters for the crypto accelerator"""

date : Final[Field] = Field(
    name='date',
    origin='SMF70DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF70DTE`
    Record: `SMF70S2`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF70DTE`
    Record: `SMF70S2`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF70TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF70TME`
    Record: `SMF70S2`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF70TME`
    Record: `SMF70S2`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF70DTE`), `time`(`SMF70TME`)
    Record: `SMF70S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF70DTE`), `time`(`SMF70TME`)
    Record: `SMF70S2`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF70LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF70LEN`
    Record: `SMF70S2`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF70LEN`
    Record: `SMF70S2`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF70SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF70SEG`
    Record: `SMF70S2`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF70SEG`
    Record: `SMF70S2`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF70FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF70FLG`
    Record: `SMF70S2`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF70FLG`
    Record: `SMF70S2`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

new_record : Final[Field] = Field(
    name='new_record',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
new_record.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

subtypes_used : Final[Field] = Field(
    name='subtypes_used',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
subtypes_used.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

prsm_mode : Final[Field] = Field(
    name='prsm_mode',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
prsm_mode.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF70FLG`)
    Record: `SMF70S2`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF70RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF70RTY`
    Record: `SMF70S2`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF70RTY`
    Record: `SMF70S2`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF70TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF70TME`
    Record: `SMF70S2`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF70TME`
    Record: `SMF70S2`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF70DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF70DTE`
    Record: `SMF70S2`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF70DTE`
    Record: `SMF70S2`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF70SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF70SID`
    Record: `SMF70S2`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF70SID`
    Record: `SMF70S2`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF70SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF70SSI`
    Record: `SMF70S2`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF70SSI`
    Record: `SMF70S2`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF70STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF70STY`
    Record: `SMF70S2`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF70STY`
    Record: `SMF70S2`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF70TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF70TRN`
    Record: `SMF70S2`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF70TRN`
    Record: `SMF70S2`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF70PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF70PRS`
    Record: `SMF70S2`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF70PRS`
    Record: `SMF70S2`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF70PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF70PRL`
    Record: `SMF70S2`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF70PRL`
    Record: `SMF70S2`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF70PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF70PRN`
    Record: `SMF70S2`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF70PRN`
    Record: `SMF70S2`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

f3s : Final[Field] = Field(
    name='f3s',
    origin='SMF7023S',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to crypto CCA coprocessor section

SMF Info
--------
    Field: `SMF7023S`
    Record: `SMF70S2`
    Map: Not part of a map

Offset to crypto CCA coprocessor section
"""
f3s.__doc__ = """Offset to crypto CCA coprocessor section

SMF Info
--------
    Field: `SMF7023S`
    Record: `SMF70S2`
    Map: Not part of a map

Offset to crypto CCA coprocessor section
"""

f3l : Final[Field] = Field(
    name='f3l',
    origin='SMF7023L',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of crypto CCA coprocessor section

SMF Info
--------
    Field: `SMF7023L`
    Record: `SMF70S2`
    Map: Not part of a map

Length of crypto CCA coprocessor section
"""
f3l.__doc__ = """Length of crypto CCA coprocessor section

SMF Info
--------
    Field: `SMF7023L`
    Record: `SMF70S2`
    Map: Not part of a map

Length of crypto CCA coprocessor section
"""

f3n : Final[Field] = Field(
    name='f3n',
    origin='SMF7023N',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of crypto CCA coprocessor sections

SMF Info
--------
    Field: `SMF7023N`
    Record: `SMF70S2`
    Map: Not part of a map

Number of crypto CCA coprocessor sections
"""
f3n.__doc__ = """Number of crypto CCA coprocessor sections

SMF Info
--------
    Field: `SMF7023N`
    Record: `SMF70S2`
    Map: Not part of a map

Number of crypto CCA coprocessor sections
"""

f4s : Final[Field] = Field(
    name='f4s',
    origin='SMF7024S',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to crypto accelerator section

SMF Info
--------
    Field: `SMF7024S`
    Record: `SMF70S2`
    Map: Not part of a map

Offset to crypto accelerator section
"""
f4s.__doc__ = """Offset to crypto accelerator section

SMF Info
--------
    Field: `SMF7024S`
    Record: `SMF70S2`
    Map: Not part of a map

Offset to crypto accelerator section
"""

f4l : Final[Field] = Field(
    name='f4l',
    origin='SMF7024L',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of crypto accelerator section

SMF Info
--------
    Field: `SMF7024L`
    Record: `SMF70S2`
    Map: Not part of a map

Length of crypto accelerator section
"""
f4l.__doc__ = """Length of crypto accelerator section

SMF Info
--------
    Field: `SMF7024L`
    Record: `SMF70S2`
    Map: Not part of a map

Length of crypto accelerator section
"""

f4n : Final[Field] = Field(
    name='f4n',
    origin='SMF7024N',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of crypto accelerator section

SMF Info
--------
    Field: `SMF7024N`
    Record: `SMF70S2`
    Map: Not part of a map

Number of crypto accelerator section
"""
f4n.__doc__ = """Number of crypto accelerator section

SMF Info
--------
    Field: `SMF7024N`
    Record: `SMF70S2`
    Map: Not part of a map

Number of crypto accelerator section
"""

cs : Final[Field] = Field(
    name='cs',
    origin='SMF702CS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to ICSF section

SMF Info
--------
    Field: `SMF702CS`
    Record: `SMF70S2`
    Map: Not part of a map

Offset to ICSF section
"""
cs.__doc__ = """Offset to ICSF section

SMF Info
--------
    Field: `SMF702CS`
    Record: `SMF70S2`
    Map: Not part of a map

Offset to ICSF section
"""

cl : Final[Field] = Field(
    name='cl',
    origin='SMF702CL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of ICSF section

SMF Info
--------
    Field: `SMF702CL`
    Record: `SMF70S2`
    Map: Not part of a map

Length of ICSF section
"""
cl.__doc__ = """Length of ICSF section

SMF Info
--------
    Field: `SMF702CL`
    Record: `SMF70S2`
    Map: Not part of a map

Length of ICSF section
"""

cn : Final[Field] = Field(
    name='cn',
    origin='SMF702CN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of ICSF section

SMF Info
--------
    Field: `SMF702CN`
    Record: `SMF70S2`
    Map: Not part of a map

Number of ICSF section
"""
cn.__doc__ = """Number of ICSF section

SMF Info
--------
    Field: `SMF702CN`
    Record: `SMF70S2`
    Map: Not part of a map

Number of ICSF section
"""

f5s : Final[Field] = Field(
    name='f5s',
    origin='SMF7025S',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to crypto PKCS11 copro cessor section

SMF Info
--------
    Field: `SMF7025S`
    Record: `SMF70S2`
    Map: Not part of a map

Offset to crypto PKCS11 copro cessor section
"""
f5s.__doc__ = """Offset to crypto PKCS11 copro cessor section

SMF Info
--------
    Field: `SMF7025S`
    Record: `SMF70S2`
    Map: Not part of a map

Offset to crypto PKCS11 copro cessor section
"""

f5l : Final[Field] = Field(
    name='f5l',
    origin='SMF7025L',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of crypto PKCS11 copro cessor section

SMF Info
--------
    Field: `SMF7025L`
    Record: `SMF70S2`
    Map: Not part of a map

Length of crypto PKCS11 copro cessor section
"""
f5l.__doc__ = """Length of crypto PKCS11 copro cessor section

SMF Info
--------
    Field: `SMF7025L`
    Record: `SMF70S2`
    Map: Not part of a map

Length of crypto PKCS11 copro cessor section
"""

f5n : Final[Field] = Field(
    name='f5n',
    origin='SMF7025N',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of crypto PKCS11 copro cessor sections

SMF Info
--------
    Field: `SMF7025N`
    Record: `SMF70S2`
    Map: Not part of a map

Number of crypto PKCS11 copro cessor sections
"""
f5n.__doc__ = """Number of crypto PKCS11 copro cessor sections

SMF Info
--------
    Field: `SMF7025N`
    Record: `SMF70S2`
    Map: Not part of a map

Number of crypto PKCS11 copro cessor sections
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF70MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF70MFV`
    Record: `SMF70S2`
    Map: `SMF70PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF70MFV`
    Record: `SMF70S2`
    Map: `SMF70PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF70PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF70PRD`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF70PRD`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF70IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF70PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF70IST`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF70IST`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF70DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF70PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF70DAT`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF70DAT`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Date monitor interval start
"""

interval : Final[Field] = Field(
    name='interval',
    origin='SMF70INT',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF70PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF70INT`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Duration of monitor interval
"""
interval.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF70INT`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF70SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF70SAM`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF70SAM`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF70FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF70FLA`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF70FLA`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF70PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF70FLA`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF70CYC',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF70PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF70CYC`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF70CYC`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF70MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF70MVS`
    Record: `SMF70S2`
    Map: `SMF70PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF70MVS`
    Record: `SMF70S2`
    Map: `SMF70PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF70IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF70IML`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF70IML`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF70PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF70PRF`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF70PRF`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF70PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF70PRF`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF70PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF70PTN`
    Record: `SMF70S2`
    Map: `SMF70PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF70PTN`
    Record: `SMF70S2`
    Map: `SMF70PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF70SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF70SRL`
    Record: `SMF70S2`
    Map: `SMF70PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF70SRL`
    Record: `SMF70S2`
    Map: `SMF70PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF70IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF70PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF70IET`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF70IET`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF70LGO',
    post='core.timedelta',
    post_param="""h""",
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF70LGO`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Offset GMT to local time

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `h`
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF70LGO`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Offset GMT to local time

Post Processing (`core.timedelta`)
---------------
The parameter for the post-processor is: `h`
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF70RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF70RAO`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF70RAO`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF70RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF70RAL`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF70RAL`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF70RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF70RAN`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF70RAN`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF70OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF70OIL`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF70OIL`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF70SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF70PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF70SYN`
    Record: `SMF70S2`
    Map: `SMF70PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF70SYN`
    Record: `SMF70S2`
    Map: `SMF70PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF70GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF70PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF70GIE`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF70GIE`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF70XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF70XNM`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF70XNM`
    Record: `SMF70S2`
    Map: `SMF70PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF70SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF70PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF70SNM`
    Record: `SMF70S2`
    Map: `SMF70PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF70SNM`
    Record: `SMF70S2`
    Map: `SMF70PRO`

System name for current system as defined in CVTSNAME
"""

interval_in_milliseconds : Final[Field] = Field(
    name='interval_in_milliseconds',
    origin=None,
    post="core.inline",
    post_param=__interval_in_milliseconds_inline_post,
    virtual=True,
    ref=interval,
    record=record,
    record_map=SMF70PRO,
)
"""Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF70INT`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""
interval_in_milliseconds.__doc__ = """Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF70INT`)
    Record: `SMF70S2`
    Map: `SMF70PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""

r702snec : Final[Field] = Field(
    name='r702snec',
    origin='R702SNEC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Single DES: Number of calls to encipher (long floating point)

SMF Info
--------
    Field: `R702SNEC`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of calls to encipher (long floating point)
"""
r702snec.__doc__ = """Single DES: Number of calls to encipher (long floating point)

SMF Info
--------
    Field: `R702SNEC`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of calls to encipher (long floating point)
"""

r702sneb : Final[Field] = Field(
    name='r702sneb',
    origin='R702SNEB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Single DES: Number of bytes of data enciphered (long floating point)

SMF Info
--------
    Field: `R702SNEB`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of bytes of data enciphered (long floating point)
"""
r702sneb.__doc__ = """Single DES: Number of bytes of data enciphered (long floating point)

SMF Info
--------
    Field: `R702SNEB`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of bytes of data enciphered (long floating point)
"""

r702snei : Final[Field] = Field(
    name='r702snei',
    origin='R702SNEI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Single DES: Number of CMD instructions used to encipher the data (long floating point)

SMF Info
--------
    Field: `R702SNEI`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of CMD instructions used to encipher the data (long floating point)
"""
r702snei.__doc__ = """Single DES: Number of CMD instructions used to encipher the data (long floating point)

SMF Info
--------
    Field: `R702SNEI`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of CMD instructions used to encipher the data (long floating point)
"""

r702tnec : Final[Field] = Field(
    name='r702tnec',
    origin='R702TNEC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Triple DES: Number of calls to encipher (long floating point)

SMF Info
--------
    Field: `R702TNEC`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of calls to encipher (long floating point)
"""
r702tnec.__doc__ = """Triple DES: Number of calls to encipher (long floating point)

SMF Info
--------
    Field: `R702TNEC`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of calls to encipher (long floating point)
"""

r702tneb : Final[Field] = Field(
    name='r702tneb',
    origin='R702TNEB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Triple DES: Number of bytes of data enciphered (long floating point)

SMF Info
--------
    Field: `R702TNEB`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of bytes of data enciphered (long floating point)
"""
r702tneb.__doc__ = """Triple DES: Number of bytes of data enciphered (long floating point)

SMF Info
--------
    Field: `R702TNEB`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of bytes of data enciphered (long floating point)
"""

r702tnei : Final[Field] = Field(
    name='r702tnei',
    origin='R702TNEI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Triple DES: Number of CMD instructions used to encipher the data (long floating point)

SMF Info
--------
    Field: `R702TNEI`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of CMD instructions used to encipher the data (long floating point)
"""
r702tnei.__doc__ = """Triple DES: Number of CMD instructions used to encipher the data (long floating point)

SMF Info
--------
    Field: `R702TNEI`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of CMD instructions used to encipher the data (long floating point)
"""

r702sndc : Final[Field] = Field(
    name='r702sndc',
    origin='R702SNDC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Single DES: Number of calls to decipher (long floating point)

SMF Info
--------
    Field: `R702SNDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of calls to decipher (long floating point)
"""
r702sndc.__doc__ = """Single DES: Number of calls to decipher (long floating point)

SMF Info
--------
    Field: `R702SNDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of calls to decipher (long floating point)
"""

r702sndb : Final[Field] = Field(
    name='r702sndb',
    origin='R702SNDB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Single DES: Number of bytes of data deciphered (long floating point)

SMF Info
--------
    Field: `R702SNDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of bytes of data deciphered (long floating point)
"""
r702sndb.__doc__ = """Single DES: Number of bytes of data deciphered (long floating point)

SMF Info
--------
    Field: `R702SNDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of bytes of data deciphered (long floating point)
"""

r702sndi : Final[Field] = Field(
    name='r702sndi',
    origin='R702SNDI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Single DES: Number of CMD instructions used to decipher the data (long floating point)

SMF Info
--------
    Field: `R702SNDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of CMD instructions used to decipher the data (long floating point)
"""
r702sndi.__doc__ = """Single DES: Number of CMD instructions used to decipher the data (long floating point)

SMF Info
--------
    Field: `R702SNDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Single DES: Number of CMD instructions used to decipher the data (long floating point)
"""

r702tndc : Final[Field] = Field(
    name='r702tndc',
    origin='R702TNDC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Triple DES: Number of calls to decipher (long floating point)

SMF Info
--------
    Field: `R702TNDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of calls to decipher (long floating point)
"""
r702tndc.__doc__ = """Triple DES: Number of calls to decipher (long floating point)

SMF Info
--------
    Field: `R702TNDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of calls to decipher (long floating point)
"""

r702tndb : Final[Field] = Field(
    name='r702tndb',
    origin='R702TNDB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Triple DES: Number of bytes of data deciphered (long floating point)

SMF Info
--------
    Field: `R702TNDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of bytes of data deciphered (long floating point)
"""
r702tndb.__doc__ = """Triple DES: Number of bytes of data deciphered (long floating point)

SMF Info
--------
    Field: `R702TNDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of bytes of data deciphered (long floating point)
"""

r702tndi : Final[Field] = Field(
    name='r702tndi',
    origin='R702TNDI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Triple DES: Number of CMD instructions used to decipher the data (long floating point)

SMF Info
--------
    Field: `R702TNDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of CMD instructions used to decipher the data (long floating point)
"""
r702tndi.__doc__ = """Triple DES: Number of CMD instructions used to decipher the data (long floating point)

SMF Info
--------
    Field: `R702TNDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Triple DES: Number of CMD instructions used to decipher the data (long floating point)
"""

r702nmgc : Final[Field] = Field(
    name='r702nmgc',
    origin='R702NMGC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to MAC generate (long floating point)

SMF Info
--------
    Field: `R702NMGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to MAC generate (long floating point)
"""
r702nmgc.__doc__ = """Number of calls to MAC generate (long floating point)

SMF Info
--------
    Field: `R702NMGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to MAC generate (long floating point)
"""

r702nmgb : Final[Field] = Field(
    name='r702nmgb',
    origin='R702NMGB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data MAC generated (long floating point)

SMF Info
--------
    Field: `R702NMGB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data MAC generated (long floating point)
"""
r702nmgb.__doc__ = """Number of bytes of data MAC generated (long floating point)

SMF Info
--------
    Field: `R702NMGB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data MAC generated (long floating point)
"""

r702nmgi : Final[Field] = Field(
    name='r702nmgi',
    origin='R702NMGI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of PCMF instructions used to MAC generate (long floating point)

SMF Info
--------
    Field: `R702NMGI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of PCMF instructions used to MAC generate (long floating point)
"""
r702nmgi.__doc__ = """Number of PCMF instructions used to MAC generate (long floating point)

SMF Info
--------
    Field: `R702NMGI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of PCMF instructions used to MAC generate (long floating point)
"""

r702nmvc : Final[Field] = Field(
    name='r702nmvc',
    origin='R702NMVC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to MAC verify (long floating point)

SMF Info
--------
    Field: `R702NMVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to MAC verify (long floating point)
"""
r702nmvc.__doc__ = """Number of calls to MAC verify (long floating point)

SMF Info
--------
    Field: `R702NMVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to MAC verify (long floating point)
"""

r702nmvb : Final[Field] = Field(
    name='r702nmvb',
    origin='R702NMVB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data MAC verified (long floating point)

SMF Info
--------
    Field: `R702NMVB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data MAC verified (long floating point)
"""
r702nmvb.__doc__ = """Number of bytes of data MAC verified (long floating point)

SMF Info
--------
    Field: `R702NMVB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data MAC verified (long floating point)
"""

r702nmvi : Final[Field] = Field(
    name='r702nmvi',
    origin='R702NMVI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of PCMF instructions used to MAC verify (long floating point)

SMF Info
--------
    Field: `R702NMVI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of PCMF instructions used to MAC verify (long floating point)
"""
r702nmvi.__doc__ = """Number of PCMF instructions used to MAC verify (long floating point)

SMF Info
--------
    Field: `R702NMVI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of PCMF instructions used to MAC verify (long floating point)
"""

r702nhac : Final[Field] = Field(
    name='r702nhac',
    origin='R702NHAC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""For SHA-1: Number of calls to hash (long floating point)

SMF Info
--------
    Field: `R702NHAC`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-1: Number of calls to hash (long floating point)
"""
r702nhac.__doc__ = """For SHA-1: Number of calls to hash (long floating point)

SMF Info
--------
    Field: `R702NHAC`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-1: Number of calls to hash (long floating point)
"""

r702nhab : Final[Field] = Field(
    name='r702nhab',
    origin='R702NHAB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""For SHA-1: Number of bytes of data hashed (long floating point)

SMF Info
--------
    Field: `R702NHAB`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-1: Number of bytes of data hashed (long floating point)
"""
r702nhab.__doc__ = """For SHA-1: Number of bytes of data hashed (long floating point)

SMF Info
--------
    Field: `R702NHAB`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-1: Number of bytes of data hashed (long floating point)
"""

r702nhai : Final[Field] = Field(
    name='r702nhai',
    origin='R702NHAI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""For SHA-1: Number of PCMF instructions used to hash data (long floating point)

SMF Info
--------
    Field: `R702NHAI`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-1: Number of PCMF instructions used to hash data (long floating point)
"""
r702nhai.__doc__ = """For SHA-1: Number of PCMF instructions used to hash data (long floating point)

SMF Info
--------
    Field: `R702NHAI`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-1: Number of PCMF instructions used to hash data (long floating point)
"""

r702nptc : Final[Field] = Field(
    name='r702nptc',
    origin='R702NPTC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to PIN translate (long floating point)

SMF Info
--------
    Field: `R702NPTC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to PIN translate (long floating point)
"""
r702nptc.__doc__ = """Number of calls to PIN translate (long floating point)

SMF Info
--------
    Field: `R702NPTC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to PIN translate (long floating point)
"""

r702npvc : Final[Field] = Field(
    name='r702npvc',
    origin='R702NPVC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to PIN verify (long floating point)

SMF Info
--------
    Field: `R702NPVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to PIN verify (long floating point)
"""
r702npvc.__doc__ = """Number of calls to PIN verify (long floating point)

SMF Info
--------
    Field: `R702NPVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to PIN verify (long floating point)
"""

r702nh2c : Final[Field] = Field(
    name='r702nh2c',
    origin='R702NH2C',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""For SHA-224 and SHA-256: Number of calls to hash (long floating point)

SMF Info
--------
    Field: `R702NH2C`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-224 and SHA-256: Number of calls to hash (long floating point)
"""
r702nh2c.__doc__ = """For SHA-224 and SHA-256: Number of calls to hash (long floating point)

SMF Info
--------
    Field: `R702NH2C`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-224 and SHA-256: Number of calls to hash (long floating point)
"""

r702nh2b : Final[Field] = Field(
    name='r702nh2b',
    origin='R702NH2B',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""For SHA-224 and SHA-256: Number of bytes of data hashed (long floating point)

SMF Info
--------
    Field: `R702NH2B`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-224 and SHA-256: Number of bytes of data hashed (long floating point)
"""
r702nh2b.__doc__ = """For SHA-224 and SHA-256: Number of bytes of data hashed (long floating point)

SMF Info
--------
    Field: `R702NH2B`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-224 and SHA-256: Number of bytes of data hashed (long floating point)
"""

r702nh2i : Final[Field] = Field(
    name='r702nh2i',
    origin='R702NH2I',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""For SHA-224 and SHA-256: Number of PCMF instructions used to hash data (long floating point)

SMF Info
--------
    Field: `R702NH2I`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-224 and SHA-256: Number of PCMF instructions used to hash data (long floating point)
"""
r702nh2i.__doc__ = """For SHA-224 and SHA-256: Number of PCMF instructions used to hash data (long floating point)

SMF Info
--------
    Field: `R702NH2I`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-224 and SHA-256: Number of PCMF instructions used to hash data (long floating point)
"""

r702nh5c : Final[Field] = Field(
    name='r702nh5c',
    origin='R702NH5C',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""For SHA-384 and SHA-512: Number of calls to hash (long floating point)

SMF Info
--------
    Field: `R702NH5C`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-384 and SHA-512: Number of calls to hash (long floating point)
"""
r702nh5c.__doc__ = """For SHA-384 and SHA-512: Number of calls to hash (long floating point)

SMF Info
--------
    Field: `R702NH5C`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-384 and SHA-512: Number of calls to hash (long floating point)
"""

r702nh5b : Final[Field] = Field(
    name='r702nh5b',
    origin='R702NH5B',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""For SHA-384 and SHA-512: Number of bytes of data hashed (long floating point)

SMF Info
--------
    Field: `R702NH5B`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-384 and SHA-512: Number of bytes of data hashed (long floating point)
"""
r702nh5b.__doc__ = """For SHA-384 and SHA-512: Number of bytes of data hashed (long floating point)

SMF Info
--------
    Field: `R702NH5B`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-384 and SHA-512: Number of bytes of data hashed (long floating point)
"""

r702nh5i : Final[Field] = Field(
    name='r702nh5i',
    origin='R702NH5I',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""For SHA-384 and SHA-512: Number of PCMF instructions used to hash data (long floating point)

SMF Info
--------
    Field: `R702NH5I`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-384 and SHA-512: Number of PCMF instructions used to hash data (long floating point)
"""
r702nh5i.__doc__ = """For SHA-384 and SHA-512: Number of PCMF instructions used to hash data (long floating point)

SMF Info
--------
    Field: `R702NH5I`
    Record: `SMF70S2`
    Map: `R702CCF`

For SHA-384 and SHA-512: Number of PCMF instructions used to hash data (long floating point)
"""

r702cdlv : Final[Field] = Field(
    name='r702cdlv',
    origin='R702CDLV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702CCF,
)
"""ICSF data level

SMF Info
--------
    Field: `R702CDLV`
    Record: `SMF70S2`
    Map: `R702CCF`

ICSF data level
"""
r702cdlv.__doc__ = """ICSF data level

SMF Info
--------
    Field: `R702CDLV`
    Record: `SMF70S2`
    Map: `R702CCF`

ICSF data level
"""

r702aesc : Final[Field] = Field(
    name='r702aesc',
    origin='R702AESC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of AES encipher calls sent to a coprocessor

SMF Info
--------
    Field: `R702AESC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of AES encipher calls sent to a coprocessor
"""
r702aesc.__doc__ = """Number of AES encipher calls sent to a coprocessor

SMF Info
--------
    Field: `R702AESC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of AES encipher calls sent to a coprocessor
"""

r702aesb : Final[Field] = Field(
    name='r702aesb',
    origin='R702AESB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes processed by the AES encipher services handled by a coprocessor

SMF Info
--------
    Field: `R702AESB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes processed by the AES encipher services handled by a coprocessor
"""
r702aesb.__doc__ = """Number of bytes processed by the AES encipher services handled by a coprocessor

SMF Info
--------
    Field: `R702AESB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes processed by the AES encipher services handled by a coprocessor
"""

r702aesi : Final[Field] = Field(
    name='r702aesi',
    origin='R702AESI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of operations required to complete the AES encipher service calls to a coprocessor

SMF Info
--------
    Field: `R702AESI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of operations required to complete the AES encipher service calls to a coprocessor
"""
r702aesi.__doc__ = """Number of operations required to complete the AES encipher service calls to a coprocessor

SMF Info
--------
    Field: `R702AESI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of operations required to complete the AES encipher service calls to a coprocessor
"""

r702asdc : Final[Field] = Field(
    name='r702asdc',
    origin='R702ASDC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of AES decipher calls sent to a coprocessor

SMF Info
--------
    Field: `R702ASDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of AES decipher calls sent to a coprocessor
"""
r702asdc.__doc__ = """Number of AES decipher calls sent to a coprocessor

SMF Info
--------
    Field: `R702ASDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of AES decipher calls sent to a coprocessor
"""

r702asdb : Final[Field] = Field(
    name='r702asdb',
    origin='R702ASDB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes processed by the AES decipher services handled by a coprocessor

SMF Info
--------
    Field: `R702ASDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes processed by the AES decipher services handled by a coprocessor
"""
r702asdb.__doc__ = """Number of bytes processed by the AES decipher services handled by a coprocessor

SMF Info
--------
    Field: `R702ASDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes processed by the AES decipher services handled by a coprocessor
"""

r702asdi : Final[Field] = Field(
    name='r702asdi',
    origin='R702ASDI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of operations required to complete the AES decipher service calls to a coprocessor

SMF Info
--------
    Field: `R702ASDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of operations required to complete the AES decipher service calls to a coprocessor
"""
r702asdi.__doc__ = """Number of operations required to complete the AES decipher service calls to a coprocessor

SMF Info
--------
    Field: `R702ASDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of operations required to complete the AES decipher service calls to a coprocessor
"""

r702drgc : Final[Field] = Field(
    name='r702drgc',
    origin='R702DRGC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to generate the RSA digital signatures (long floating point) Only valid if R702CDLV greater than 13

SMF Info
--------
    Field: `R702DRGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to generate the RSA digital signatures (long floating point) Only valid if R702CDLV greater than 13
"""
r702drgc.__doc__ = """Number of calls to generate the RSA digital signatures (long floating point) Only valid if R702CDLV greater than 13

SMF Info
--------
    Field: `R702DRGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to generate the RSA digital signatures (long floating point) Only valid if R702CDLV greater than 13
"""

r702drvc : Final[Field] = Field(
    name='r702drvc',
    origin='R702DRVC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to verify the RSA digital signatures (long floating point) Only valid if R702CDLV greater than 13

SMF Info
--------
    Field: `R702DRVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to verify the RSA digital signatures (long floating point) Only valid if R702CDLV greater than 13
"""
r702drvc.__doc__ = """Number of calls to verify the RSA digital signatures (long floating point) Only valid if R702CDLV greater than 13

SMF Info
--------
    Field: `R702DRVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to verify the RSA digital signatures (long floating point) Only valid if R702CDLV greater than 13
"""

r702degc : Final[Field] = Field(
    name='r702degc',
    origin='R702DEGC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to generate ECC digital signatures (long floating point) Only valid if R702CDLV greater than 13

SMF Info
--------
    Field: `R702DEGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to generate ECC digital signatures (long floating point) Only valid if R702CDLV greater than 13
"""
r702degc.__doc__ = """Number of calls to generate ECC digital signatures (long floating point) Only valid if R702CDLV greater than 13

SMF Info
--------
    Field: `R702DEGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to generate ECC digital signatures (long floating point) Only valid if R702CDLV greater than 13
"""

r702devc : Final[Field] = Field(
    name='r702devc',
    origin='R702DEVC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to verify the ECC digital signatures (long floating point) Only valid if R702CDLV greater than 13

SMF Info
--------
    Field: `R702DEVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to verify the ECC digital signatures (long floating point) Only valid if R702CDLV greater than 13
"""
r702devc.__doc__ = """Number of calls to verify the ECC digital signatures (long floating point) Only valid if R702CDLV greater than 13

SMF Info
--------
    Field: `R702DEVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to verify the ECC digital signatures (long floating point) Only valid if R702CDLV greater than 13
"""

r702amgc : Final[Field] = Field(
    name='r702amgc',
    origin='R702AMGC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to generate the AES MACs (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to generate the AES MACs (long floating point) Only valid if R702CDLV greater than 17
"""
r702amgc.__doc__ = """Number of calls to generate the AES MACs (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to generate the AES MACs (long floating point) Only valid if R702CDLV greater than 17
"""

r702amgb : Final[Field] = Field(
    name='r702amgb',
    origin='R702AMGB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data for which the AES MACs were generated (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMGB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data for which the AES MACs were generated (long floating point) Only valid if R702CDLV greater than 17
"""
r702amgb.__doc__ = """Number of bytes of data for which the AES MACs were generated (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMGB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data for which the AES MACs were generated (long floating point) Only valid if R702CDLV greater than 17
"""

r702amgi : Final[Field] = Field(
    name='r702amgi',
    origin='R702AMGI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of instructions used to generate the AES MACs (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMGI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to generate the AES MACs (long floating point) Only valid if R702CDLV greater than 17
"""
r702amgi.__doc__ = """Number of instructions used to generate the AES MACs (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMGI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to generate the AES MACs (long floating point) Only valid if R702CDLV greater than 17
"""

r702amvc : Final[Field] = Field(
    name='r702amvc',
    origin='R702AMVC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to verify the AES MACs (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to verify the AES MACs (long floating point) Only valid if R702CDLV greater than 17
"""
r702amvc.__doc__ = """Number of calls to verify the AES MACs (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to verify the AES MACs (long floating point) Only valid if R702CDLV greater than 17
"""

r702amvb : Final[Field] = Field(
    name='r702amvb',
    origin='R702AMVB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data for which the AES MACs were verified (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMVB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data for which the AES MACs were verified (long floating point) Only valid if R702CDLV greater than 17
"""
r702amvb.__doc__ = """Number of bytes of data for which the AES MACs were verified (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMVB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data for which the AES MACs were verified (long floating point) Only valid if R702CDLV greater than 17
"""

r702amvi : Final[Field] = Field(
    name='r702amvi',
    origin='R702AMVI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of instructions used to verify the AES MACs (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMVI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to verify the AES MACs (long floating point) Only valid if R702CDLV greater than 17
"""
r702amvi.__doc__ = """Number of instructions used to verify the AES MACs (long floating point) Only valid if R702CDLV greater than 17

SMF Info
--------
    Field: `R702AMVI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to verify the AES MACs (long floating point) Only valid if R702CDLV greater than 17
"""

r702fpec : Final[Field] = Field(
    name='r702fpec',
    origin='R702FPEC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to encipher data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPEC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to encipher data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""
r702fpec.__doc__ = """Number of calls to encipher data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPEC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to encipher data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""

r702fpeb : Final[Field] = Field(
    name='r702fpeb',
    origin='R702FPEB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data enciphered using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPEB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data enciphered using FPE (long floating point) Only valid if R702CDLV greater than 19
"""
r702fpeb.__doc__ = """Number of bytes of data enciphered using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPEB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data enciphered using FPE (long floating point) Only valid if R702CDLV greater than 19
"""

r702fpei : Final[Field] = Field(
    name='r702fpei',
    origin='R702FPEI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of instructions used to encipher the data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPEI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to encipher the data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""
r702fpei.__doc__ = """Number of instructions used to encipher the data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPEI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to encipher the data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""

r702fpdc : Final[Field] = Field(
    name='r702fpdc',
    origin='R702FPDC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to decipher data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to decipher data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""
r702fpdc.__doc__ = """Number of calls to decipher data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to decipher data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""

r702fpdb : Final[Field] = Field(
    name='r702fpdb',
    origin='R702FPDB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data deciphered using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data deciphered using FPE (long floating point) Only valid if R702CDLV greater than 19
"""
r702fpdb.__doc__ = """Number of bytes of data deciphered using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data deciphered using FPE (long floating point) Only valid if R702CDLV greater than 19
"""

r702fpdi : Final[Field] = Field(
    name='r702fpdi',
    origin='R702FPDI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of instructions used to decipher the data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to decipher the data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""
r702fpdi.__doc__ = """Number of instructions used to decipher the data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to decipher the data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""

r702fptc : Final[Field] = Field(
    name='r702fptc',
    origin='R702FPTC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to translate data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPTC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to translate data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""
r702fptc.__doc__ = """Number of calls to translate data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPTC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to translate data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""

r702fptb : Final[Field] = Field(
    name='r702fptb',
    origin='R702FPTB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data translated using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPTB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data translated using FPE (long floating point) Only valid if R702CDLV greater than 19
"""
r702fptb.__doc__ = """Number of bytes of data translated using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPTB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data translated using FPE (long floating point) Only valid if R702CDLV greater than 19
"""

r702fpti : Final[Field] = Field(
    name='r702fpti',
    origin='R702FPTI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of instructions used to translate the data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPTI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to translate the data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""
r702fpti.__doc__ = """Number of instructions used to translate the data using FPE (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FPTI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to translate the data using FPE (long floating point) Only valid if R702CDLV greater than 19
"""

r702fxec : Final[Field] = Field(
    name='r702fxec',
    origin='R702FXEC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to encipher data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXEC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to encipher data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""
r702fxec.__doc__ = """Number of calls to encipher data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXEC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to encipher data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""

r702fxeb : Final[Field] = Field(
    name='r702fxeb',
    origin='R702FXEB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data enciphered using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXEB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data enciphered using FFX (long floating point) Only valid if R702CDLV greater than 22
"""
r702fxeb.__doc__ = """Number of bytes of data enciphered using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXEB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data enciphered using FFX (long floating point) Only valid if R702CDLV greater than 22
"""

r702fxei : Final[Field] = Field(
    name='r702fxei',
    origin='R702FXEI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of instructions used to encipher the data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXEI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to encipher the data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""
r702fxei.__doc__ = """Number of instructions used to encipher the data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXEI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to encipher the data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""

r702fxdc : Final[Field] = Field(
    name='r702fxdc',
    origin='R702FXDC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to decipher data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to decipher data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""
r702fxdc.__doc__ = """Number of calls to decipher data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXDC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to decipher data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""

r702fxdb : Final[Field] = Field(
    name='r702fxdb',
    origin='R702FXDB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data deciphered using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data deciphered using FFX (long floating point) Only valid if R702CDLV greater than 22
"""
r702fxdb.__doc__ = """Number of bytes of data deciphered using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXDB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data deciphered using FFX (long floating point) Only valid if R702CDLV greater than 22
"""

r702fxdi : Final[Field] = Field(
    name='r702fxdi',
    origin='R702FXDI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of instructions used to decipher the data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to decipher the data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""
r702fxdi.__doc__ = """Number of instructions used to decipher the data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXDI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to decipher the data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""

r702fxtc : Final[Field] = Field(
    name='r702fxtc',
    origin='R702FXTC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to translate data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXTC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to translate data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""
r702fxtc.__doc__ = """Number of calls to translate data using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXTC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to translate data using FFX (long floating point) Only valid if R702CDLV greater than 22
"""

r702fxtb : Final[Field] = Field(
    name='r702fxtb',
    origin='R702FXTB',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of bytes of data translated using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXTB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data translated using FFX (long floating point) Only valid if R702CDLV greater than 22
"""
r702fxtb.__doc__ = """Number of bytes of data translated using FFX (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702FXTB`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of bytes of data translated using FFX (long floating point) Only valid if R702CDLV greater than 22
"""

r702fxti : Final[Field] = Field(
    name='r702fxti',
    origin='R702FXTI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of instructions used to translate the data using FFX (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FXTI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to translate the data using FFX (long floating point) Only valid if R702CDLV greater than 19
"""
r702fxti.__doc__ = """Number of instructions used to translate the data using FFX (long floating point) Only valid if R702CDLV greater than 19

SMF Info
--------
    Field: `R702FXTI`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of instructions used to translate the data using FFX (long floating point) Only valid if R702CDLV greater than 19
"""

r702dqgc : Final[Field] = Field(
    name='r702dqgc',
    origin='R702DQGC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to generate QSA digital signatures (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702DQGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to generate QSA digital signatures (long floating point) Only valid if R702CDLV greater than 22
"""
r702dqgc.__doc__ = """Number of calls to generate QSA digital signatures (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702DQGC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to generate QSA digital signatures (long floating point) Only valid if R702CDLV greater than 22
"""

r702dqvc : Final[Field] = Field(
    name='r702dqvc',
    origin='R702DQVC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702CCF,
)
"""Number of calls to verify the QSA digital signatures (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702DQVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to verify the QSA digital signatures (long floating point) Only valid if R702CDLV greater than 22
"""
r702dqvc.__doc__ = """Number of calls to verify the QSA digital signatures (long floating point) Only valid if R702CDLV greater than 22

SMF Info
--------
    Field: `R702DQVC`
    Record: `SMF70S2`
    Map: `R702CCF`

Number of calls to verify the QSA digital signatures (long floating point) Only valid if R702CDLV greater than 22
"""

r7023ax : Final[Field] = Field(
    name='r7023ax',
    origin='R7023AX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP3,
)
"""Crypto processor index

SMF Info
--------
    Field: `R7023AX`
    Record: `SMF70S2`
    Map: `R702TYP3`

Crypto processor index
"""
r7023ax.__doc__ = """Crypto processor index

SMF Info
--------
    Field: `R7023AX`
    Record: `SMF70S2`
    Map: `R702TYP3`

Crypto processor index
"""

r7023ct : Final[Field] = Field(
    name='r7023ct',
    origin='R7023CT',
    post='core.flagmap',
    post_param={'default': 'Unknown', 'map': {3: 'PCICC', 5: 'PCIXCC', 7: 'CEX2C', 9: 'CEX3C', 10: 'CEX4C', 11: 'CEX5C', 12: 'CEX6C', 13: 'CEX7C', 14: 'CEX8C'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP3,
)
"""Crypto processor type: 11 = CEX5C, 12 = CEX6C, 13 = CEX7C, 14 = CEX8C

SMF Info
--------
    Field: `R7023CT`
    Record: `SMF70S2`
    Map: `R702TYP3`

Crypto processor type: 11 = CEX5C, 12 = CEX6C, 13 = CEX7C, 14 = CEX8C

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'Unknown', 'map': {3: 'PCICC', 5: 'PCIXCC', 7: 'CEX2C', 9: 'CEX3C', 10: 'CEX4C', 11: 'CEX5C', 12: 'CEX6C', 13: 'CEX7C', 14: 'CEX8C'}}
"""
r7023ct.__doc__ = """Crypto processor type: 11 = CEX5C, 12 = CEX6C, 13 = CEX7C, 14 = CEX8C

SMF Info
--------
    Field: `R7023CT`
    Record: `SMF70S2`
    Map: `R702TYP3`

Crypto processor type: 11 = CEX5C, 12 = CEX6C, 13 = CEX7C, 14 = CEX8C

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'Unknown', 'map': {3: 'PCICC', 5: 'PCIXCC', 7: 'CEX2C', 9: 'CEX3C', 10: 'CEX4C', 11: 'CEX5C', 12: 'CEX6C', 13: 'CEX7C', 14: 'CEX8C'}}
"""

r7023msk : Final[Field] = Field(
    name='r7023msk',
    origin='R7023MSK',
    type=FieldType.STRING,
    record=record,
    record_map=R702TYP3,
)
"""Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic coprocessor card. Valid with SMF70SRL >= X'61'(97)

SMF Info
--------
    Field: `R7023MSK`
    Record: `SMF70S2`
    Map: `R702TYP3`

Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic coprocessor card. Valid with SMF70SRL >= X'61'(97)
"""
r7023msk.__doc__ = """Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic coprocessor card. Valid with SMF70SRL >= X'61'(97)

SMF Info
--------
    Field: `R7023MSK`
    Record: `SMF70S2`
    Map: `R702TYP3`

Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic coprocessor card. Valid with SMF70SRL >= X'61'(97)
"""

r7023all : Final[Field] = Field(
    name='r7023all',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r7023msk,
    record=record,
    record_map=R702TYP3,
)
"""Valid data for all operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7023msk`(`R7023MSK`)
    Record: `SMF70S2`
    Map: `R702TYP3`

Valid data for all operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r7023all.__doc__ = """Valid data for all operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7023msk`(`R7023MSK`)
    Record: `SMF70S2`
    Map: `R702TYP3`

Valid data for all operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r7023rsa : Final[Field] = Field(
    name='r7023rsa',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r7023msk,
    record=record,
    record_map=R702TYP3,
)
"""Valid data for RSA-key generation operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7023msk`(`R7023MSK`)
    Record: `SMF70S2`
    Map: `R702TYP3`

Valid data for RSA-key generation operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r7023rsa.__doc__ = """Valid data for RSA-key generation operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7023msk`(`R7023MSK`)
    Record: `SMF70S2`
    Map: `R702TYP3`

Valid data for RSA-key generation operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r7023sf : Final[Field] = Field(
    name='r7023sf',
    origin='R7023SF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP3,
)
"""Scaling factor for the indicating crypto coprocessor (long floating point)

SMF Info
--------
    Field: `R7023SF`
    Record: `SMF70S2`
    Map: `R702TYP3`

Scaling factor for the indicating crypto coprocessor (long floating point)
"""
r7023sf.__doc__ = """Scaling factor for the indicating crypto coprocessor (long floating point)

SMF Info
--------
    Field: `R7023SF`
    Record: `SMF70S2`
    Map: `R702TYP3`

Scaling factor for the indicating crypto coprocessor (long floating point)
"""

r7023t0 : Final[Field] = Field(
    name='r7023t0',
    origin='R7023T0',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP3,
)
"""Execution time of all operations on the specified crypto coprocessor (long floating point)

SMF Info
--------
    Field: `R7023T0`
    Record: `SMF70S2`
    Map: `R702TYP3`

Execution time of all operations on the specified crypto coprocessor (long floating point)
"""
r7023t0.__doc__ = """Execution time of all operations on the specified crypto coprocessor (long floating point)

SMF Info
--------
    Field: `R7023T0`
    Record: `SMF70S2`
    Map: `R702TYP3`

Execution time of all operations on the specified crypto coprocessor (long floating point)
"""

r7023c0 : Final[Field] = Field(
    name='r7023c0',
    origin='R7023C0',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP3,
)
"""Execution number of all operations on the specified crypto coprocessor (long floating point)

SMF Info
--------
    Field: `R7023C0`
    Record: `SMF70S2`
    Map: `R702TYP3`

Execution number of all operations on the specified crypto coprocessor (long floating point)
"""
r7023c0.__doc__ = """Execution number of all operations on the specified crypto coprocessor (long floating point)

SMF Info
--------
    Field: `R7023C0`
    Record: `SMF70S2`
    Map: `R702TYP3`

Execution number of all operations on the specified crypto coprocessor (long floating point)
"""

r7023c1 : Final[Field] = Field(
    name='r7023c1',
    origin='R7023C1',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP3,
)
"""Execution number of RSA-key-generation / (long floating point)

SMF Info
--------
    Field: `R7023C1`
    Record: `SMF70S2`
    Map: `R702TYP3`

Execution number of RSA-key-generation / (long floating point)
"""
r7023c1.__doc__ = """Execution number of RSA-key-generation / (long floating point)

SMF Info
--------
    Field: `R7023C1`
    Record: `SMF70S2`
    Map: `R702TYP3`

Execution number of RSA-key-generation / (long floating point)
"""

r7023scope : Final[Field] = Field(
    name='r7023scope',
    origin='R7023SCOPE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP3,
)
"""Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope

SMF Info
--------
    Field: `R7023SCOPE`
    Record: `SMF70S2`
    Map: `R702TYP3`

Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope
"""
r7023scope.__doc__ = """Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope

SMF Info
--------
    Field: `R7023SCOPE`
    Record: `SMF70S2`
    Map: `R702TYP3`

Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope
"""

r7023did : Final[Field] = Field(
    name='r7023did',
    origin='R7023DID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP3,
)
"""Domain ID Valid with R7023SCOPE = 1

SMF Info
--------
    Field: `R7023DID`
    Record: `SMF70S2`
    Map: `R702TYP3`

Domain ID Valid with R7023SCOPE = 1
"""
r7023did.__doc__ = """Domain ID Valid with R7023SCOPE = 1

SMF Info
--------
    Field: `R7023DID`
    Record: `SMF70S2`
    Map: `R702TYP3`

Domain ID Valid with R7023SCOPE = 1
"""

r7024ax : Final[Field] = Field(
    name='r7024ax',
    origin='R7024AX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP4,
)
"""Crypto processor index

SMF Info
--------
    Field: `R7024AX`
    Record: `SMF70S2`
    Map: `R702TYP4`

Crypto processor index
"""
r7024ax.__doc__ = """Crypto processor index

SMF Info
--------
    Field: `R7024AX`
    Record: `SMF70S2`
    Map: `R702TYP4`

Crypto processor index
"""

r7024ct : Final[Field] = Field(
    name='r7024ct',
    origin='R7024CT',
    post='core.flagmap',
    post_param={'default': 'Unknown', 'map': {4: 'PCICA', 6: 'CEX2A', 8: 'CEX3A', 10: 'CEX4A', 11: 'CEX5A', 12: 'CEX6A', 13: 'CEX7A', 14: 'CEX8A'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP4,
)
"""Crypto processor type: 11 = CEX5A, 12 = CEX6A, 13 = CEX7A, 14 = CEX8A

SMF Info
--------
    Field: `R7024CT`
    Record: `SMF70S2`
    Map: `R702TYP4`

Crypto processor type: 11 = CEX5A, 12 = CEX6A, 13 = CEX7A, 14 = CEX8A

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'Unknown', 'map': {4: 'PCICA', 6: 'CEX2A', 8: 'CEX3A', 10: 'CEX4A', 11: 'CEX5A', 12: 'CEX6A', 13: 'CEX7A', 14: 'CEX8A'}}
"""
r7024ct.__doc__ = """Crypto processor type: 11 = CEX5A, 12 = CEX6A, 13 = CEX7A, 14 = CEX8A

SMF Info
--------
    Field: `R7024CT`
    Record: `SMF70S2`
    Map: `R702TYP4`

Crypto processor type: 11 = CEX5A, 12 = CEX6A, 13 = CEX7A, 14 = CEX8A

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'Unknown', 'map': {4: 'PCICA', 6: 'CEX2A', 8: 'CEX3A', 10: 'CEX4A', 11: 'CEX5A', 12: 'CEX6A', 13: 'CEX7A', 14: 'CEX8A'}}
"""

r7024msk : Final[Field] = Field(
    name='r7024msk',
    origin='R7024MSK',
    type=FieldType.STRING,
    record=record,
    record_map=R702TYP4,
)
"""Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic accelerator card for a certain type of RSA operations. Valid with SMF70SRL >= X'5B'(91)

SMF Info
--------
    Field: `R7024MSK`
    Record: `SMF70S2`
    Map: `R702TYP4`

Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic accelerator card for a certain type of RSA operations. Valid with SMF70SRL >= X'5B'(91)
"""
r7024msk.__doc__ = """Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic accelerator card for a certain type of RSA operations. Valid with SMF70SRL >= X'5B'(91)

SMF Info
--------
    Field: `R7024MSK`
    Record: `SMF70S2`
    Map: `R702TYP4`

Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic accelerator card for a certain type of RSA operations. Valid with SMF70SRL >= X'5B'(91)
"""

me_1024 : Final[Field] = Field(
    name='me_1024',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r7024msk,
    record=record,
    record_map=R702TYP4,
)
"""Valid data for 1024-bit ME-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 1024-bit ME-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
me_1024.__doc__ = """Valid data for 1024-bit ME-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 1024-bit ME-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

me_2048 : Final[Field] = Field(
    name='me_2048',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r7024msk,
    record=record,
    record_map=R702TYP4,
)
"""Valid data for 2048-bit ME-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 2048-bit ME-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
me_2048.__doc__ = """Valid data for 2048-bit ME-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 2048-bit ME-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

crt_1024 : Final[Field] = Field(
    name='crt_1024',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r7024msk,
    record=record,
    record_map=R702TYP4,
)
"""Valid data for 1024-bit CRT-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 1024-bit CRT-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
crt_1024.__doc__ = """Valid data for 1024-bit CRT-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 1024-bit CRT-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

crt_2048 : Final[Field] = Field(
    name='crt_2048',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r7024msk,
    record=record,
    record_map=R702TYP4,
)
"""Valid data for 2048-bit CRT-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 2048-bit CRT-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
crt_2048.__doc__ = """Valid data for 2048-bit CRT-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 2048-bit CRT-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

me_4096 : Final[Field] = Field(
    name='me_4096',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r7024msk,
    record=record,
    record_map=R702TYP4,
)
"""Valid data for 4096-bit ME-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 4096-bit ME-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
me_4096.__doc__ = """Valid data for 4096-bit ME-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 4096-bit ME-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

crt_4096 : Final[Field] = Field(
    name='crt_4096',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r7024msk,
    record=record,
    record_map=R702TYP4,
)
"""Valid data for 4096-bit CRT-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 4096-bit CRT-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
crt_4096.__doc__ = """Valid data for 4096-bit CRT-format operations(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7024msk`(`R7024MSK`)
    Record: `SMF70S2`
    Map: `R702TYP4`

Valid data for 4096-bit CRT-format operations

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r7024en : Final[Field] = Field(
    name='r7024en',
    origin='R7024EN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP4,
)
"""Number of engines. This is the number of valid entries in the R7024TC array of timer and counter pairs

SMF Info
--------
    Field: `R7024EN`
    Record: `SMF70S2`
    Map: `R702TYP4`

Number of engines. This is the number of valid entries in the R7024TC array of timer and counter pairs
"""
r7024en.__doc__ = """Number of engines. This is the number of valid entries in the R7024TC array of timer and counter pairs

SMF Info
--------
    Field: `R7024EN`
    Record: `SMF70S2`
    Map: `R702TYP4`

Number of engines. This is the number of valid entries in the R7024TC array of timer and counter pairs
"""

r7024sf : Final[Field] = Field(
    name='r7024sf',
    origin='R7024SF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP4,
)
"""Scaling factor for the indicating crypto accelerator (long floating point)

SMF Info
--------
    Field: `R7024SF`
    Record: `SMF70S2`
    Map: `R702TYP4`

Scaling factor for the indicating crypto accelerator (long floating point)
"""
r7024sf.__doc__ = """Scaling factor for the indicating crypto accelerator (long floating point)

SMF Info
--------
    Field: `R7024SF`
    Record: `SMF70S2`
    Map: `R702TYP4`

Scaling factor for the indicating crypto accelerator (long floating point)
"""

r7023met : Final[Field] = Field(
    name='r7023met',
    origin='R7023MET',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP4,
)
"""Execution time for 4096-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7023MET`
    Record: `SMF70S2`
    Map: `R702TYP4`

Execution time for 4096-bit ME-format RSA operations (long floating point)
"""
r7023met.__doc__ = """Execution time for 4096-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7023MET`
    Record: `SMF70S2`
    Map: `R702TYP4`

Execution time for 4096-bit ME-format RSA operations (long floating point)
"""

r7023mec : Final[Field] = Field(
    name='r7023mec',
    origin='R7023MEC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP4,
)
"""Execution number for 4096-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7023MEC`
    Record: `SMF70S2`
    Map: `R702TYP4`

Execution number for 4096-bit ME-format RSA operations (long floating point)
"""
r7023mec.__doc__ = """Execution number for 4096-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7023MEC`
    Record: `SMF70S2`
    Map: `R702TYP4`

Execution number for 4096-bit ME-format RSA operations (long floating point)
"""

r7023crt : Final[Field] = Field(
    name='r7023crt',
    origin='R7023CRT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP4,
)
"""Execution time for 4096-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7023CRT`
    Record: `SMF70S2`
    Map: `R702TYP4`

Execution time for 4096-bit CRT-format RSA operations (long floating point)
"""
r7023crt.__doc__ = """Execution time for 4096-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7023CRT`
    Record: `SMF70S2`
    Map: `R702TYP4`

Execution time for 4096-bit CRT-format RSA operations (long floating point)
"""

r7023crc : Final[Field] = Field(
    name='r7023crc',
    origin='R7023CRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP4,
)
"""Execution number for 4096-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7023CRC`
    Record: `SMF70S2`
    Map: `R702TYP4`

Execution number for 4096-bit CRT-format RSA operations (long floating point)
"""
r7023crc.__doc__ = """Execution number for 4096-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7023CRC`
    Record: `SMF70S2`
    Map: `R702TYP4`

Execution number for 4096-bit CRT-format RSA operations (long floating point)
"""

r7024scope : Final[Field] = Field(
    name='r7024scope',
    origin='R7024SCOPE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP4,
)
"""Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope

SMF Info
--------
    Field: `R7024SCOPE`
    Record: `SMF70S2`
    Map: `R702TYP4`

Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope
"""
r7024scope.__doc__ = """Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope

SMF Info
--------
    Field: `R7024SCOPE`
    Record: `SMF70S2`
    Map: `R702TYP4`

Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope
"""

r7024did : Final[Field] = Field(
    name='r7024did',
    origin='R7024DID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP4,
)
"""Domain ID Valid with R7024SCOPE = 1

SMF Info
--------
    Field: `R7024DID`
    Record: `SMF70S2`
    Map: `R702TYP4`

Domain ID Valid with R7024SCOPE = 1
"""
r7024did.__doc__ = """Domain ID Valid with R7024SCOPE = 1

SMF Info
--------
    Field: `R7024DID`
    Record: `SMF70S2`
    Map: `R702TYP4`

Domain ID Valid with R7024SCOPE = 1
"""

r7025ax : Final[Field] = Field(
    name='r7025ax',
    origin='R7025AX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP5,
)
"""Crypto processor index

SMF Info
--------
    Field: `R7025AX`
    Record: `SMF70S2`
    Map: `R702TYP5`

Crypto processor index
"""
r7025ax.__doc__ = """Crypto processor index

SMF Info
--------
    Field: `R7025AX`
    Record: `SMF70S2`
    Map: `R702TYP5`

Crypto processor index
"""

r7025ct : Final[Field] = Field(
    name='r7025ct',
    origin='R7025CT',
    post='core.flagmap',
    post_param={'default': 'unknown', 'map': {10: 'CEX4P', 11: 'CEX5P', 12: 'CEX6P', 13: 'CEX7P', 14: 'CEX8P'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP5,
)
"""Crypto processor type: 11 = CEX5P, 12 = CEX6P, 13 = CEX7P, 14 = CEX8P

SMF Info
--------
    Field: `R7025CT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Crypto processor type: 11 = CEX5P, 12 = CEX6P, 13 = CEX7P, 14 = CEX8P

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'unknown', 'map': {10: 'CEX4P', 11: 'CEX5P', 12: 'CEX6P', 13: 'CEX7P', 14: 'CEX8P'}}
"""
r7025ct.__doc__ = """Crypto processor type: 11 = CEX5P, 12 = CEX6P, 13 = CEX7P, 14 = CEX8P

SMF Info
--------
    Field: `R7025CT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Crypto processor type: 11 = CEX5P, 12 = CEX6P, 13 = CEX7P, 14 = CEX8P

Post Processing (`core.flagmap`)
---------------
The parameter for the post-processor is::

    {'default': 'unknown', 'map': {10: 'CEX4P', 11: 'CEX5P', 12: 'CEX6P', 13: 'CEX7P', 14: 'CEX8P'}}
"""

r7025msk : Final[Field] = Field(
    name='r7025msk',
    origin='R7025MSK',
    type=FieldType.STRING,
    record=record,
    record_map=R702TYP5,
)
"""Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic PKCS11 coprocessor.

SMF Info
--------
    Field: `R7025MSK`
    Record: `SMF70S2`
    Map: `R702TYP5`

Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic PKCS11 coprocessor.
"""
r7025msk.__doc__ = """Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic PKCS11 coprocessor.

SMF Info
--------
    Field: `R7025MSK`
    Record: `SMF70S2`
    Map: `R702TYP5`

Validity bit mask. Each bit position represents the validity of a timer-counter pair that measures the execution time and number of operations on a cryptographic PKCS11 coprocessor.
"""

asym_key_slow : Final[Field] = Field(
    name='asym_key_slow',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r7025msk,
    record=record,
    record_map=R702TYP5,
)
"""Valid data for slow asymmetric key functions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for slow asymmetric key functions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
asym_key_slow.__doc__ = """Valid data for slow asymmetric key functions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for slow asymmetric key functions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

asym_key_fast : Final[Field] = Field(
    name='asym_key_fast',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r7025msk,
    record=record,
    record_map=R702TYP5,
)
"""Valid data for fast asymmetric key functions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for fast asymmetric key functions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
asym_key_fast.__doc__ = """Valid data for fast asymmetric key functions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for fast asymmetric key functions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r7025sp : Final[Field] = Field(
    name='r7025sp',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r7025msk,
    record=record,
    record_map=R702TYP5,
)
"""Valid data for symmetric-key functions that return partial or incremental results(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for symmetric-key functions that return partial or incremental results

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r7025sp.__doc__ = """Valid data for symmetric-key functions that return partial or incremental results(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for symmetric-key functions that return partial or incremental results

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

sym_key_gen : Final[Field] = Field(
    name='sym_key_gen',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r7025msk,
    record=record,
    record_map=R702TYP5,
)
"""Valid data for symmetric-key functions that return complete or final result(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for symmetric-key functions that return complete or final result

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
sym_key_gen.__doc__ = """Valid data for symmetric-key functions that return complete or final result(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for symmetric-key functions that return complete or final result

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

asym_key_gen : Final[Field] = Field(
    name='asym_key_gen',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r7025msk,
    record=record,
    record_map=R702TYP5,
)
"""Valid data for asymmetric-key generation function(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for asymmetric-key generation function

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
asym_key_gen.__doc__ = """Valid data for asymmetric-key generation function(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r7025msk`(`R7025MSK`)
    Record: `SMF70S2`
    Map: `R702TYP5`

Valid data for asymmetric-key generation function

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r7025sf : Final[Field] = Field(
    name='r7025sf',
    origin='R7025SF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Scaling factor for the indicating cryptographic PKCS11 coprocessor (long floating point)

SMF Info
--------
    Field: `R7025SF`
    Record: `SMF70S2`
    Map: `R702TYP5`

Scaling factor for the indicating cryptographic PKCS11 coprocessor (long floating point)
"""
r7025sf.__doc__ = """Scaling factor for the indicating cryptographic PKCS11 coprocessor (long floating point)

SMF Info
--------
    Field: `R7025SF`
    Record: `SMF70S2`
    Map: `R702TYP5`

Scaling factor for the indicating cryptographic PKCS11 coprocessor (long floating point)
"""

r7025sat : Final[Field] = Field(
    name='r7025sat',
    origin='R7025SAT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Aggregate execution time of operations executed by slow asymmetric-key functions (long floating point)

SMF Info
--------
    Field: `R7025SAT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by slow asymmetric-key functions (long floating point)
"""
r7025sat.__doc__ = """Aggregate execution time of operations executed by slow asymmetric-key functions (long floating point)

SMF Info
--------
    Field: `R7025SAT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by slow asymmetric-key functions (long floating point)
"""

r7025sac : Final[Field] = Field(
    name='r7025sac',
    origin='R7025SAC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Number of operations executed by slow asymmetric-key functions (long floating point)

SMF Info
--------
    Field: `R7025SAC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by slow asymmetric-key functions (long floating point)
"""
r7025sac.__doc__ = """Number of operations executed by slow asymmetric-key functions (long floating point)

SMF Info
--------
    Field: `R7025SAC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by slow asymmetric-key functions (long floating point)
"""

r7025fat : Final[Field] = Field(
    name='r7025fat',
    origin='R7025FAT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Aggregate execution time of operations executed by fast asymmetric-key functions (long floating point)

SMF Info
--------
    Field: `R7025FAT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by fast asymmetric-key functions (long floating point)
"""
r7025fat.__doc__ = """Aggregate execution time of operations executed by fast asymmetric-key functions (long floating point)

SMF Info
--------
    Field: `R7025FAT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by fast asymmetric-key functions (long floating point)
"""

r7025fac : Final[Field] = Field(
    name='r7025fac',
    origin='R7025FAC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Number of operations executed by fast asymmetric-key functions (long floating point)

SMF Info
--------
    Field: `R7025FAC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by fast asymmetric-key functions (long floating point)
"""
r7025fac.__doc__ = """Number of operations executed by fast asymmetric-key functions (long floating point)

SMF Info
--------
    Field: `R7025FAC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by fast asymmetric-key functions (long floating point)
"""

r7025spt : Final[Field] = Field(
    name='r7025spt',
    origin='R7025SPT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Aggregate execution time of operations executed by symmetric-key functions that return partial or incremental results (long floating point)

SMF Info
--------
    Field: `R7025SPT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by symmetric-key functions that return partial or incremental results (long floating point)
"""
r7025spt.__doc__ = """Aggregate execution time of operations executed by symmetric-key functions that return partial or incremental results (long floating point)

SMF Info
--------
    Field: `R7025SPT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by symmetric-key functions that return partial or incremental results (long floating point)
"""

r7025spc : Final[Field] = Field(
    name='r7025spc',
    origin='R7025SPC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Number of operations executed by symmetric-key functions that return partial or incremental results (long floating point)

SMF Info
--------
    Field: `R7025SPC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by symmetric-key functions that return partial or incremental results (long floating point)
"""
r7025spc.__doc__ = """Number of operations executed by symmetric-key functions that return partial or incremental results (long floating point)

SMF Info
--------
    Field: `R7025SPC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by symmetric-key functions that return partial or incremental results (long floating point)
"""

r7025sct : Final[Field] = Field(
    name='r7025sct',
    origin='R7025SCT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Aggregate execution time of operations executed by symmetric-key functions that return complete or final result (long floating point)

SMF Info
--------
    Field: `R7025SCT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by symmetric-key functions that return complete or final result (long floating point)
"""
r7025sct.__doc__ = """Aggregate execution time of operations executed by symmetric-key functions that return complete or final result (long floating point)

SMF Info
--------
    Field: `R7025SCT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by symmetric-key functions that return complete or final result (long floating point)
"""

r7025scc : Final[Field] = Field(
    name='r7025scc',
    origin='R7025SCC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Number of operations executed by symmetric-key functions that return complete or final result (long floating point)

SMF Info
--------
    Field: `R7025SCC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by symmetric-key functions that return complete or final result (long floating point)
"""
r7025scc.__doc__ = """Number of operations executed by symmetric-key functions that return complete or final result (long floating point)

SMF Info
--------
    Field: `R7025SCC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by symmetric-key functions that return complete or final result (long floating point)
"""

r7025agt : Final[Field] = Field(
    name='r7025agt',
    origin='R7025AGT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Aggregate execution time of operations executed by asymmetric-key generation function (long floating point)

SMF Info
--------
    Field: `R7025AGT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by asymmetric-key generation function (long floating point)
"""
r7025agt.__doc__ = """Aggregate execution time of operations executed by asymmetric-key generation function (long floating point)

SMF Info
--------
    Field: `R7025AGT`
    Record: `SMF70S2`
    Map: `R702TYP5`

Aggregate execution time of operations executed by asymmetric-key generation function (long floating point)
"""

r7025agc : Final[Field] = Field(
    name='r7025agc',
    origin='R7025AGC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R702TYP5,
)
"""Number of operations executed by asymmetric-key generation function (long floating point)

SMF Info
--------
    Field: `R7025AGC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by asymmetric-key generation function (long floating point)
"""
r7025agc.__doc__ = """Number of operations executed by asymmetric-key generation function (long floating point)

SMF Info
--------
    Field: `R7025AGC`
    Record: `SMF70S2`
    Map: `R702TYP5`

Number of operations executed by asymmetric-key generation function (long floating point)
"""

r7025scope : Final[Field] = Field(
    name='r7025scope',
    origin='R7025SCOPE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP5,
)
"""Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope

SMF Info
--------
    Field: `R7025SCOPE`
    Record: `SMF70S2`
    Map: `R702TYP5`

Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope
"""
r7025scope.__doc__ = """Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope

SMF Info
--------
    Field: `R7025SCOPE`
    Record: `SMF70S2`
    Map: `R702TYP5`

Specifies the scope of the data section 0 = Data with CPC scope 1 = Data with system scope
"""

r7025did : Final[Field] = Field(
    name='r7025did',
    origin='R7025DID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R702TYP5,
)
"""Domain ID Valid with R7025SCOPE = 1

SMF Info
--------
    Field: `R7025DID`
    Record: `SMF70S2`
    Map: `R702TYP5`

Domain ID Valid with R7025SCOPE = 1
"""
r7025did.__doc__ = """Domain ID Valid with R7025SCOPE = 1

SMF Info
--------
    Field: `R7025DID`
    Record: `SMF70S2`
    Map: `R702TYP5`

Domain ID Valid with R7025SCOPE = 1
"""

r7021met : Final[Field] = Field(
    name='r7021met',
    origin='R7021MET',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7024TC,
)
"""Execution time for 1024-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7021MET`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution time for 1024-bit ME-format RSA operations (long floating point)
"""
r7021met.__doc__ = """Execution time for 1024-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7021MET`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution time for 1024-bit ME-format RSA operations (long floating point)
"""

r7021mec : Final[Field] = Field(
    name='r7021mec',
    origin='R7021MEC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7024TC,
)
"""Execution number for 1024-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7021MEC`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution number for 1024-bit ME-format RSA operations (long floating point)
"""
r7021mec.__doc__ = """Execution number for 1024-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7021MEC`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution number for 1024-bit ME-format RSA operations (long floating point)
"""

r7022met : Final[Field] = Field(
    name='r7022met',
    origin='R7022MET',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7024TC,
)
"""Execution time for 2048-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7022MET`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution time for 2048-bit ME-format RSA operations (long floating point)
"""
r7022met.__doc__ = """Execution time for 2048-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7022MET`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution time for 2048-bit ME-format RSA operations (long floating point)
"""

r7022mec : Final[Field] = Field(
    name='r7022mec',
    origin='R7022MEC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7024TC,
)
"""Execution number for 2048-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7022MEC`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution number for 2048-bit ME-format RSA operations (long floating point)
"""
r7022mec.__doc__ = """Execution number for 2048-bit ME-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7022MEC`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution number for 2048-bit ME-format RSA operations (long floating point)
"""

r7021crt : Final[Field] = Field(
    name='r7021crt',
    origin='R7021CRT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7024TC,
)
"""Execution time for 1024-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7021CRT`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution time for 1024-bit CRT-format RSA operations (long floating point)
"""
r7021crt.__doc__ = """Execution time for 1024-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7021CRT`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution time for 1024-bit CRT-format RSA operations (long floating point)
"""

r7021crc : Final[Field] = Field(
    name='r7021crc',
    origin='R7021CRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7024TC,
)
"""Execution number for 1024-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7021CRC`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution number for 1024-bit CRT-format RSA operations (long floating point)
"""
r7021crc.__doc__ = """Execution number for 1024-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7021CRC`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution number for 1024-bit CRT-format RSA operations (long floating point)
"""

r7022crt : Final[Field] = Field(
    name='r7022crt',
    origin='R7022CRT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7024TC,
)
"""Execution time for 2048-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7022CRT`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution time for 2048-bit CRT-format RSA operations (long floating point)
"""
r7022crt.__doc__ = """Execution time for 2048-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7022CRT`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution time for 2048-bit CRT-format RSA operations (long floating point)
"""

r7022crc : Final[Field] = Field(
    name='r7022crc',
    origin='R7022CRC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R7024TC,
)
"""Execution number for 2048-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7022CRC`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution number for 2048-bit CRT-format RSA operations (long floating point)
"""
r7022crc.__doc__ = """Execution number for 2048-bit CRT-format RSA operations (long floating point)

SMF Info
--------
    Field: `R7022CRC`
    Record: `SMF70S2`
    Map: `R7024TC`

Execution number for 2048-bit CRT-format RSA operations (long floating point)
"""
