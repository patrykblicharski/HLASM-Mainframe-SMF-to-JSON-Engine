# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 79 Subtype 15"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=79,
                                smf_subtype=15,
                                spec='SMF 79 Subtype 15',
                                post=None)
"""SMF 79 Subtype 15"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

R79FIRLM: Final[RecordMap] = RecordMap(
    origin='R79FIRLM',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Long Lock Data Section',
    post=None,
    record_mapping=False)
"""Long Lock Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF79DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S15`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S15`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF79TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S15`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S15`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF79DTE`), `time`(`SMF79TME`)
    Record: `SMF79S15`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF79DTE`), `time`(`SMF79TME`)
    Record: `SMF79S15`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF79LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF79LEN`
    Record: `SMF79S15`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF79LEN`
    Record: `SMF79S15`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF79SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF79SEG`
    Record: `SMF79S15`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF79SEG`
    Record: `SMF79S15`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF79FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF79FLG`
    Record: `SMF79S15`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF79FLG`
    Record: `SMF79S15`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF79FLG`)
    Record: `SMF79S15`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF79RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF79RTY`
    Record: `SMF79S15`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF79RTY`
    Record: `SMF79S15`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF79TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S15`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF79TME`
    Record: `SMF79S15`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF79DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S15`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF79DTE`
    Record: `SMF79S15`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF79SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF79SID`
    Record: `SMF79S15`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF79SID`
    Record: `SMF79S15`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF79SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF79SSI`
    Record: `SMF79S15`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF79SSI`
    Record: `SMF79S15`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF79STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF79STY`
    Record: `SMF79S15`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF79STY`
    Record: `SMF79S15`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF79TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF79TRN`
    Record: `SMF79S15`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF79TRN`
    Record: `SMF79S15`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF79PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRS`
    Record: `SMF79S15`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRS`
    Record: `SMF79S15`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF79PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRL`
    Record: `SMF79S15`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF79PRL`
    Record: `SMF79S15`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF79PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF79PRN`
    Record: `SMF79S15`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF79PRN`
    Record: `SMF79S15`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

fpo : Final[Field] = Field(
    name='fpo',
    origin='SMF79FPO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to IMS Long Lock Data Section

SMF Info
--------
    Field: `SMF79FPO`
    Record: `SMF79S15`
    Map: Not part of a map

Offset to IMS Long Lock Data Section
"""
fpo.__doc__ = """Offset to IMS Long Lock Data Section

SMF Info
--------
    Field: `SMF79FPO`
    Record: `SMF79S15`
    Map: Not part of a map

Offset to IMS Long Lock Data Section
"""

fpl : Final[Field] = Field(
    name='fpl',
    origin='SMF79FPL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of IMS Long Lock Data Section

SMF Info
--------
    Field: `SMF79FPL`
    Record: `SMF79S15`
    Map: Not part of a map

Length of IMS Long Lock Data Section
"""
fpl.__doc__ = """Length of IMS Long Lock Data Section

SMF Info
--------
    Field: `SMF79FPL`
    Record: `SMF79S15`
    Map: Not part of a map

Length of IMS Long Lock Data Section
"""

fpn : Final[Field] = Field(
    name='fpn',
    origin='SMF79FPN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of IMS Long Lock Data Sections

SMF Info
--------
    Field: `SMF79FPN`
    Record: `SMF79S15`
    Map: Not part of a map

Number of IMS Long Lock Data Sections
"""
fpn.__doc__ = """Number of IMS Long Lock Data Sections

SMF Info
--------
    Field: `SMF79FPN`
    Record: `SMF79S15`
    Map: Not part of a map

Number of IMS Long Lock Data Sections
"""

r79fistn : Final[Field] = Field(
    name='r79fistn',
    origin='R79FISTN',
    type=FieldType.STRING,
    record=record,
    record_map=R79FIRLM,
)
"""IRLM Lock Structure Name

SMF Info
--------
    Field: `R79FISTN`
    Record: `SMF79S15`
    Map: `R79FIRLM`

IRLM Lock Structure Name
"""
r79fistn.__doc__ = """IRLM Lock Structure Name

SMF Info
--------
    Field: `R79FISTN`
    Record: `SMF79S15`
    Map: `R79FIRLM`

IRLM Lock Structure Name
"""

r79fdlkc : Final[Field] = Field(
    name='r79fdlkc',
    origin='R79FDLKC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79FIRLM,
)
"""Dead Lock Cycle Number

SMF Info
--------
    Field: `R79FDLKC`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Dead Lock Cycle Number
"""
r79fdlkc.__doc__ = """Dead Lock Cycle Number

SMF Info
--------
    Field: `R79FDLKC`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Dead Lock Cycle Number
"""

r79fetyp : Final[Field] = Field(
    name='r79fetyp',
    origin='R79FETYP',
    type=FieldType.STRING,
    record=record,
    record_map=R79FIRLM,
)
"""'B'=Blocker / 'W'=Waiter

SMF Info
--------
    Field: `R79FETYP`
    Record: `SMF79S15`
    Map: `R79FIRLM`

'B'=Blocker / 'W'=Waiter
"""
r79fetyp.__doc__ = """'B'=Blocker / 'W'=Waiter

SMF Info
--------
    Field: `R79FETYP`
    Record: `SMF79S15`
    Map: `R79FIRLM`

'B'=Blocker / 'W'=Waiter
"""

r79fimsi : Final[Field] = Field(
    name='r79fimsi',
    origin='R79FIMSI',
    type=FieldType.STRING,
    record=record,
    record_map=R79FIRLM,
)
"""IMS Subsystem ID

SMF Info
--------
    Field: `R79FIMSI`
    Record: `SMF79S15`
    Map: `R79FIRLM`

IMS Subsystem ID
"""
r79fimsi.__doc__ = """IMS Subsystem ID

SMF Info
--------
    Field: `R79FIMSI`
    Record: `SMF79S15`
    Map: `R79FIRLM`

IMS Subsystem ID
"""

r79fpstn : Final[Field] = Field(
    name='r79fpstn',
    origin='R79FPSTN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79FIRLM,
)
"""PST Number

SMF Info
--------
    Field: `R79FPSTN`
    Record: `SMF79S15`
    Map: `R79FIRLM`

PST Number
"""
r79fpstn.__doc__ = """PST Number

SMF Info
--------
    Field: `R79FPSTN`
    Record: `SMF79S15`
    Map: `R79FIRLM`

PST Number
"""

r79fpsbn : Final[Field] = Field(
    name='r79fpsbn',
    origin='R79FPSBN',
    type=FieldType.STRING,
    record=record,
    record_map=R79FIRLM,
)
"""PSB Name

SMF Info
--------
    Field: `R79FPSBN`
    Record: `SMF79S15`
    Map: `R79FIRLM`

PSB Name
"""
r79fpsbn.__doc__ = """PSB Name

SMF Info
--------
    Field: `R79FPSBN`
    Record: `SMF79S15`
    Map: `R79FIRLM`

PSB Name
"""

r79frgty : Final[Field] = Field(
    name='r79frgty',
    origin='R79FRGTY',
    type=FieldType.STRING,
    record=record,
    record_map=R79FIRLM,
)
"""Region Type

SMF Info
--------
    Field: `R79FRGTY`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Region Type
"""
r79frgty.__doc__ = """Region Type

SMF Info
--------
    Field: `R79FRGTY`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Region Type
"""

r79frcvt : Final[Field] = Field(
    name='r79frcvt',
    origin='R79FRCVT',
    type=FieldType.STRING,
    record=record,
    record_map=R79FIRLM,
)
"""Recovery Token

SMF Info
--------
    Field: `R79FRCVT`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Recovery Token
"""
r79frcvt.__doc__ = """Recovery Token

SMF Info
--------
    Field: `R79FRCVT`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Recovery Token
"""

r79fctid : Final[Field] = Field(
    name='r79fctid',
    origin='R79FCTID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79FIRLM,
)
"""CICS Task ID (If CICS)

SMF Info
--------
    Field: `R79FCTID`
    Record: `SMF79S15`
    Map: `R79FIRLM`

CICS Task ID (If CICS)
"""
r79fctid.__doc__ = """CICS Task ID (If CICS)

SMF Info
--------
    Field: `R79FCTID`
    Record: `SMF79S15`
    Map: `R79FIRLM`

CICS Task ID (If CICS)
"""

r79flhti : Final[Field] = Field(
    name='r79flhti',
    origin='R79FLHTI',
    type=FieldType.TIME,
    record=record,
    record_map=R79FIRLM,
)
"""Scheduled elapsed time

SMF Info
--------
    Field: `R79FLHTI`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Scheduled elapsed time
"""
r79flhti.__doc__ = """Scheduled elapsed time

SMF Info
--------
    Field: `R79FLHTI`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Scheduled elapsed time
"""

r79flhcn : Final[Field] = Field(
    name='r79flhcn',
    origin='R79FLHCN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R79FIRLM,
)
"""Max Lock Held-PSTLKHLD

SMF Info
--------
    Field: `R79FLHCN`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Max Lock Held-PSTLKHLD
"""
r79flhcn.__doc__ = """Max Lock Held-PSTLKHLD

SMF Info
--------
    Field: `R79FLHCN`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Max Lock Held-PSTLKHLD
"""

r79flkna : Final[Field] = Field(
    name='r79flkna',
    origin='R79FLKNA',
    type=FieldType.STRING,
    record=record,
    record_map=R79FIRLM,
)
"""Lock Name

SMF Info
--------
    Field: `R79FLKNA`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Lock Name
"""
r79flkna.__doc__ = """Lock Name

SMF Info
--------
    Field: `R79FLKNA`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Lock Name
"""

r79ftrnm : Final[Field] = Field(
    name='r79ftrnm',
    origin='R79FTRNM',
    type=FieldType.STRING,
    record=record,
    record_map=R79FIRLM,
)
"""Trans name / Job name

SMF Info
--------
    Field: `R79FTRNM`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Trans name / Job name
"""
r79ftrnm.__doc__ = """Trans name / Job name

SMF Info
--------
    Field: `R79FTRNM`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Trans name / Job name
"""

r79frsna : Final[Field] = Field(
    name='r79frsna',
    origin='R79FRSNA',
    type=FieldType.STRING,
    record=record,
    record_map=R79FIRLM,
)
"""Resource (DB/Area) Name

SMF Info
--------
    Field: `R79FRSNA`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Resource (DB/Area) Name
"""
r79frsna.__doc__ = """Resource (DB/Area) Name

SMF Info
--------
    Field: `R79FRSNA`
    Record: `SMF79S15`
    Map: `R79FIRLM`

Resource (DB/Area) Name
"""
