# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 113 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=113,
                                smf_subtype=1,
                                spec='SMF 113 Subtype 1',
                                post=None)
"""SMF 113 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __interval_inline_post(df):
    return df.intervalend - df.intervalstart



SMF113SDS: Final[RecordMap] = RecordMap(
    origin='SMF113SDS',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='SMF113 self defining Section',
    post=None,
    record_mapping=False)
"""SMF113 self defining Section"""
SMF113SSS: Final[RecordMap] = RecordMap(
    origin='SMF113SSS',
    record=record,
    parent=SMF113SDS,
    is_multiple=False,
    is_compound=False,
    spec='SMF113 Subsystem Section',
    post=None,
    record_mapping=False)
"""SMF113 Subsystem Section"""
SMF113ID: Final[RecordMap] = RecordMap(
    origin='SMF113ID',
    record=record,
    parent=SMF113SDS,
    is_multiple=False,
    is_compound=False,
    spec='SMF113 Identification Section',
    post=None,
    record_mapping=False)
"""SMF113 Identification Section"""
SMF113_1_CTR: Final[RecordMap] = RecordMap(
    origin='SMF113_1_CTR',
    record=record,
    parent=SMF113SDS,
    is_multiple=False,
    is_compound=False,
    spec='SMF113 Subtype 1 Header Section',
    post=None,
    record_mapping=False)
"""SMF113 Subtype 1 Header Section"""
SMF113_1_CSS: Final[RecordMap] = RecordMap(
    origin='SMF113_1_CSS',
    record=record,
    parent=SMF113_1_CTR,
    is_multiple=True,
    is_compound=False,
    spec='Counter Set Section',
    post=None,
    record_mapping=False)
"""Counter Set Section"""
SMF113_1_SCDS: Final[RecordMap] = RecordMap(
    origin='SMF113_1_SCDS',
    record=record,
    parent=SMF113_1_CSS,
    is_multiple=True,
    is_compound=False,
    spec='Short Counter Data Section',
    post=None,
    record_mapping=False)
"""Short Counter Data Section"""
SMF113_1_LCDS: Final[RecordMap] = RecordMap(
    origin='SMF113_1_LCDS',
    record=record,
    parent=SMF113_1_CSS,
    is_multiple=True,
    is_compound=False,
    spec='Long Counter Data Section',
    post=None,
    record_mapping=False)
"""Long Counter Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF113DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF113DTE`
    Record: `SMF113S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF113DTE`
    Record: `SMF113S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF113TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF113TME`
    Record: `SMF113S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF113TME`
    Record: `SMF113S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF113DTE`), `time`(`SMF113TME`)
    Record: `SMF113S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF113DTE`), `time`(`SMF113TME`)
    Record: `SMF113S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF113LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Record length

SMF Info
--------
    Field: `SMF113LEN`
    Record: `SMF113S1`
    Map: Not part of a map

Record length
"""
len.__doc__ = """Record length

SMF Info
--------
    Field: `SMF113LEN`
    Record: `SMF113S1`
    Map: Not part of a map

Record length
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF113SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""Segment descriptor

SMF Info
--------
    Field: `SMF113SEG`
    Record: `SMF113S1`
    Map: Not part of a map

Segment descriptor
"""
seg.__doc__ = """Segment descriptor

SMF Info
--------
    Field: `SMF113SEG`
    Record: `SMF113S1`
    Map: Not part of a map

Segment descriptor
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF113FLG',
    type=FieldType.STRING,
    record=record,
)
"""Header flag byte

SMF Info
--------
    Field: `SMF113FLG`
    Record: `SMF113S1`
    Map: Not part of a map

Header flag byte
"""
flg.__doc__ = """Header flag byte

SMF Info
--------
    Field: `SMF113FLG`
    Record: `SMF113S1`
    Map: Not part of a map

Header flag byte
"""

ssf : Final[Field] = Field(
    name='ssf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""Bit 0 - Subsys ID after Sys ID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF113FLG`)
    Record: `SMF113S1`
    Map: Not part of a map

Bit 0 - Subsys ID after Sys ID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
ssf.__doc__ = """Bit 0 - Subsys ID after Sys ID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF113FLG`)
    Record: `SMF113S1`
    Map: Not part of a map

Bit 0 - Subsys ID after Sys ID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sbt : Final[Field] = Field(
    name='sbt',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""Bit 1 - Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF113FLG`)
    Record: `SMF113S1`
    Map: Not part of a map

Bit 1 - Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sbt.__doc__ = """Bit 1 - Subtypes utilized(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF113FLG`)
    Record: `SMF113S1`
    Map: Not part of a map

Bit 1 - Subtypes utilized

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF113RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""Record type - 113 ('71'x)

SMF Info
--------
    Field: `SMF113RTY`
    Record: `SMF113S1`
    Map: Not part of a map

Record type - 113 ('71'x)
"""
rty.__doc__ = """Record type - 113 ('71'x)

SMF Info
--------
    Field: `SMF113RTY`
    Record: `SMF113S1`
    Map: Not part of a map

Record type - 113 ('71'x)
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF113TME',
    type=FieldType.TIME,
    record=record,
)
"""Record written time

SMF Info
--------
    Field: `SMF113TME`
    Record: `SMF113S1`
    Map: Not part of a map

Record written time
"""
tme.__doc__ = """Record written time

SMF Info
--------
    Field: `SMF113TME`
    Record: `SMF113S1`
    Map: Not part of a map

Record written time
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF113DTE',
    type=FieldType.DATE,
    record=record,
)
"""Record written date

SMF Info
--------
    Field: `SMF113DTE`
    Record: `SMF113S1`
    Map: Not part of a map

Record written date
"""
dte.__doc__ = """Record written date

SMF Info
--------
    Field: `SMF113DTE`
    Record: `SMF113S1`
    Map: Not part of a map

Record written date
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF113SID',
    type=FieldType.STRING,
    record=record,
)
"""System identifier

SMF Info
--------
    Field: `SMF113SID`
    Record: `SMF113S1`
    Map: Not part of a map

System identifier
"""
sid.__doc__ = """System identifier

SMF Info
--------
    Field: `SMF113SID`
    Record: `SMF113S1`
    Map: Not part of a map

System identifier
"""

wid : Final[Field] = Field(
    name='wid',
    origin='SMF113WID',
    type=FieldType.STRING,
    record=record,
)
"""Subsystem identifier

SMF Info
--------
    Field: `SMF113WID`
    Record: `SMF113S1`
    Map: Not part of a map

Subsystem identifier
"""
wid.__doc__ = """Subsystem identifier

SMF Info
--------
    Field: `SMF113WID`
    Record: `SMF113S1`
    Map: Not part of a map

Subsystem identifier
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF113STY',
    type=FieldType.INTEGER,
    record=record,
)
"""Record subtype: 1 = Delta event counters 2 = Hardware event counters

SMF Info
--------
    Field: `SMF113STY`
    Record: `SMF113S1`
    Map: Not part of a map

Record subtype: 1 = Delta event counters 2 = Hardware event counters
"""
sty.__doc__ = """Record subtype: 1 = Delta event counters 2 = Hardware event counters

SMF Info
--------
    Field: `SMF113STY`
    Record: `SMF113S1`
    Map: Not part of a map

Record subtype: 1 = Delta event counters 2 = Hardware event counters
"""

sdl : Final[Field] = Field(
    name='sdl',
    origin='SMF113SDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of self-defining section

SMF Info
--------
    Field: `SMF113SDL`
    Record: `SMF113S1`
    Map: Not part of a map

Length of self-defining section
"""
sdl.__doc__ = """Length of self-defining section

SMF Info
--------
    Field: `SMF113SDL`
    Record: `SMF113S1`
    Map: Not part of a map

Length of self-defining section
"""

sof : Final[Field] = Field(
    name='sof',
    origin='SMF113SOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Offset to subsystem section from beginning of record

SMF Info
--------
    Field: `SMF113SOF`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Offset to subsystem section from beginning of record
"""
sof.__doc__ = """Offset to subsystem section from beginning of record

SMF Info
--------
    Field: `SMF113SOF`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Offset to subsystem section from beginning of record
"""

sln : Final[Field] = Field(
    name='sln',
    origin='SMF113SLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Length of subsystem section

SMF Info
--------
    Field: `SMF113SLN`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Length of subsystem section
"""
sln.__doc__ = """Length of subsystem section

SMF Info
--------
    Field: `SMF113SLN`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Length of subsystem section
"""

son : Final[Field] = Field(
    name='son',
    origin='SMF113SON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Number of subsystem sections

SMF Info
--------
    Field: `SMF113SON`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Number of subsystem sections
"""
son.__doc__ = """Number of subsystem sections

SMF Info
--------
    Field: `SMF113SON`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Number of subsystem sections
"""

iof : Final[Field] = Field(
    name='iof',
    origin='SMF113IOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Offset of identification section from beginning of record

SMF Info
--------
    Field: `SMF113IOF`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Offset of identification section from beginning of record
"""
iof.__doc__ = """Offset of identification section from beginning of record

SMF Info
--------
    Field: `SMF113IOF`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Offset of identification section from beginning of record
"""

iln : Final[Field] = Field(
    name='iln',
    origin='SMF113ILN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Length of identification section

SMF Info
--------
    Field: `SMF113ILN`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Length of identification section
"""
iln.__doc__ = """Length of identification section

SMF Info
--------
    Field: `SMF113ILN`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Length of identification section
"""

ion : Final[Field] = Field(
    name='ion',
    origin='SMF113ION',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Number of identification section

SMF Info
--------
    Field: `SMF113ION`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Number of identification section
"""
ion.__doc__ = """Number of identification section

SMF Info
--------
    Field: `SMF113ION`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Number of identification section
"""

dof : Final[Field] = Field(
    name='dof',
    origin='SMF113DOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Offset of data section from beginning of record

SMF Info
--------
    Field: `SMF113DOF`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Offset of data section from beginning of record
"""
dof.__doc__ = """Offset of data section from beginning of record

SMF Info
--------
    Field: `SMF113DOF`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Offset of data section from beginning of record
"""

dln : Final[Field] = Field(
    name='dln',
    origin='SMF113DLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Length of data section

SMF Info
--------
    Field: `SMF113DLN`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Length of data section
"""
dln.__doc__ = """Length of data section

SMF Info
--------
    Field: `SMF113DLN`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Length of data section
"""

don : Final[Field] = Field(
    name='don',
    origin='SMF113DON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113SDS,
)
"""Number of data sections

SMF Info
--------
    Field: `SMF113DON`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Number of data sections
"""
don.__doc__ = """Number of data sections

SMF Info
--------
    Field: `SMF113DON`
    Record: `SMF113S1`
    Map: `SMF113SDS`

Number of data sections
"""

rvn : Final[Field] = Field(
    name='rvn',
    origin='SMF113RVN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113SSS,
)
"""Record version number

SMF Info
--------
    Field: `SMF113RVN`
    Record: `SMF113S1`
    Map: `SMF113SSS`

Record version number
"""
rvn.__doc__ = """Record version number

SMF Info
--------
    Field: `SMF113RVN`
    Record: `SMF113S1`
    Map: `SMF113SSS`

Record version number
"""

pnm : Final[Field] = Field(
    name='pnm',
    origin='SMF113PNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113SSS,
)
"""Product name - HIS

SMF Info
--------
    Field: `SMF113PNM`
    Record: `SMF113S1`
    Map: `SMF113SSS`

Product name - HIS
"""
pnm.__doc__ = """Product name - HIS

SMF Info
--------
    Field: `SMF113PNM`
    Record: `SMF113S1`
    Map: `SMF113SSS`

Product name - HIS
"""

osl : Final[Field] = Field(
    name='osl',
    origin='SMF113OSL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113SSS,
)
"""MVS product level

SMF Info
--------
    Field: `SMF113OSL`
    Record: `SMF113S1`
    Map: `SMF113SSS`

MVS product level
"""
osl.__doc__ = """MVS product level

SMF Info
--------
    Field: `SMF113OSL`
    Record: `SMF113S1`
    Map: `SMF113SSS`

MVS product level
"""

jbn : Final[Field] = Field(
    name='jbn',
    origin='SMF113JBN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113ID,
)
"""JobName

SMF Info
--------
    Field: `SMF113JBN`
    Record: `SMF113S1`
    Map: `SMF113ID`

JobName
"""
jbn.__doc__ = """JobName

SMF Info
--------
    Field: `SMF113JBN`
    Record: `SMF113S1`
    Map: `SMF113ID`

JobName
"""

rst : Final[Field] = Field(
    name='rst',
    origin='SMF113RST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF113ID,
)
"""Reader start time

SMF Info
--------
    Field: `SMF113RST`
    Record: `SMF113S1`
    Map: `SMF113ID`

Reader start time
"""
rst.__doc__ = """Reader start time

SMF Info
--------
    Field: `SMF113RST`
    Record: `SMF113S1`
    Map: `SMF113ID`

Reader start time
"""

rsd : Final[Field] = Field(
    name='rsd',
    origin='SMF113RSD',
    type=FieldType.DATE,
    record=record,
    record_map=SMF113ID,
)
"""Reader start date

SMF Info
--------
    Field: `SMF113RSD`
    Record: `SMF113S1`
    Map: `SMF113ID`

Reader start date
"""
rsd.__doc__ = """Reader start date

SMF Info
--------
    Field: `SMF113RSD`
    Record: `SMF113S1`
    Map: `SMF113ID`

Reader start date
"""

stp : Final[Field] = Field(
    name='stp',
    origin='SMF113STP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113ID,
)
"""Step name

SMF Info
--------
    Field: `SMF113STP`
    Record: `SMF113S1`
    Map: `SMF113ID`

Step name
"""
stp.__doc__ = """Step name

SMF Info
--------
    Field: `SMF113STP`
    Record: `SMF113S1`
    Map: `SMF113ID`

Step name
"""

intervalstart : Final[Field] = Field(
    name='intervalstart',
    origin='SMF113INTERVALSTART',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF113ID,
)
"""The interval start time

SMF Info
--------
    Field: `SMF113INTERVALSTART`
    Record: `SMF113S1`
    Map: `SMF113ID`

The interval start time
"""
intervalstart.__doc__ = """The interval start time

SMF Info
--------
    Field: `SMF113INTERVALSTART`
    Record: `SMF113S1`
    Map: `SMF113ID`

The interval start time
"""

intervalend : Final[Field] = Field(
    name='intervalend',
    origin='SMF113INTERVALEND',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF113ID,
)
"""The interval end time

SMF Info
--------
    Field: `SMF113INTERVALEND`
    Record: `SMF113S1`
    Map: `SMF113ID`

The interval end time
"""
intervalend.__doc__ = """The interval end time

SMF Info
--------
    Field: `SMF113INTERVALEND`
    Record: `SMF113S1`
    Map: `SMF113ID`

The interval end time
"""

interval : Final[Field] = Field(
    name='interval',
    origin=None,
    post="core.inline",
    post_param=__interval_inline_post,
    virtual=True,
    ref=[intervalstart, intervalend],
    record=record,
    record_map=SMF113ID,
)
"""The interval time delta(V)

SMF Info (Virtual Field)
--------
    Field: Based on `intervalstart`(`SMF113INTERVALSTART`), `intervalend`(`SMF113INTERVALEND`)
    Record: `SMF113S1`
    Map: `SMF113ID`

The interval time delta

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.intervalend - df.intervalstart

"""
interval.__doc__ = """The interval time delta(V)

SMF Info (Virtual Field)
--------
    Field: Based on `intervalstart`(`SMF113INTERVALSTART`), `intervalend`(`SMF113INTERVALEND`)
    Record: `SMF113S1`
    Map: `SMF113ID`

The interval time delta

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.intervalend - df.intervalstart

"""

cts : Final[Field] = Field(
    name='cts',
    origin='SMF113_1_CTS',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Time when HIS Data collection started

SMF Info
--------
    Field: `SMF113_1_CTS`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Time when HIS Data collection started
"""
cts.__doc__ = """Time when HIS Data collection started

SMF Info
--------
    Field: `SMF113_1_CTS`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Time when HIS Data collection started
"""

ctm : Final[Field] = Field(
    name='ctm',
    origin='SMF113_1_CTM',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Time when this SMF record is written

SMF Info
--------
    Field: `SMF113_1_CTM`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Time when this SMF record is written
"""
ctm.__doc__ = """Time when this SMF record is written

SMF Info
--------
    Field: `SMF113_1_CTM`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Time when this SMF record is written
"""

cpuid : Final[Field] = Field(
    name='cpuid',
    origin='SMF113_1_CPUID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Processor ID for which the hardware event counters are recorded. Note that zero is a valid processor number.

SMF Info
--------
    Field: `SMF113_1_CPUID`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Processor ID for which the hardware event counters are recorded. Note that zero is a valid processor number.
"""
cpuid.__doc__ = """Processor ID for which the hardware event counters are recorded. Note that zero is a valid processor number.

SMF Info
--------
    Field: `SMF113_1_CPUID`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Processor ID for which the hardware event counters are recorded. Note that zero is a valid processor number.
"""

cpuprocclass : Final[Field] = Field(
    name='cpuprocclass',
    origin='SMF113_1_CPUPROCCLASS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""The processor type for which the hardware event counters are recorded. Will be one of the following: 0 = Standard CP 2 = zCBP or zAAP see SMF113_1_zCBP 4 = zIIP

SMF Info
--------
    Field: `SMF113_1_CPUPROCCLASS`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

The processor type for which the hardware event counters are recorded. Will be one of the following: 0 = Standard CP 2 = zCBP or zAAP see SMF113_1_zCBP 4 = zIIP
"""
cpuprocclass.__doc__ = """The processor type for which the hardware event counters are recorded. Will be one of the following: 0 = Standard CP 2 = zCBP or zAAP see SMF113_1_zCBP 4 = zIIP

SMF Info
--------
    Field: `SMF113_1_CPUPROCCLASS`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

The processor type for which the hardware event counters are recorded. Will be one of the following: 0 = Standard CP 2 = zCBP or zAAP see SMF113_1_zCBP 4 = zIIP
"""

cpuspeed : Final[Field] = Field(
    name='cpuspeed',
    origin='SMF113_1_CPUSPEED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Processor speed for which the event counters are recorded. Speed is in cycles/microsecond.

SMF Info
--------
    Field: `SMF113_1_CPUSPEED`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Processor speed for which the event counters are recorded. Speed is in cycles/microsecond.
"""
cpuspeed.__doc__ = """Processor speed for which the event counters are recorded. Speed is in cycles/microsecond.

SMF Info
--------
    Field: `SMF113_1_CPUSPEED`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Processor speed for which the event counters are recorded. Speed is in cycles/microsecond.
"""

machtype : Final[Field] = Field(
    name='machtype',
    origin='SMF113_1_MACHTYPE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113_1_CTR,
)
"""The machine type

SMF Info
--------
    Field: `SMF113_1_MACHTYPE`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

The machine type
"""
machtype.__doc__ = """The machine type

SMF Info
--------
    Field: `SMF113_1_MACHTYPE`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

The machine type
"""

machmodel : Final[Field] = Field(
    name='machmodel',
    origin='SMF113_1_MACHMODEL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113_1_CTR,
)
"""The machine model

SMF Info
--------
    Field: `SMF113_1_MACHMODEL`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

The machine model
"""
machmodel.__doc__ = """The machine model

SMF Info
--------
    Field: `SMF113_1_MACHMODEL`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

The machine model
"""

ctrversion0 : Final[Field] = Field(
    name='ctrversion0',
    origin='SMF113_1_CTRVERSION0',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Zero counter version number. This number is incremented when there is a change to the meaning of a counter in the z/OS counter set

SMF Info
--------
    Field: `SMF113_1_CTRVERSION0`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Zero counter version number. This number is incremented when there is a change to the meaning of a counter in the z/OS counter set
"""
ctrversion0.__doc__ = """Zero counter version number. This number is incremented when there is a change to the meaning of a counter in the z/OS counter set

SMF Info
--------
    Field: `SMF113_1_CTRVERSION0`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Zero counter version number. This number is incremented when there is a change to the meaning of a counter in the z/OS counter set
"""

ctrversion1 : Final[Field] = Field(
    name='ctrversion1',
    origin='SMF113_1_CTRVERSION1',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""First counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Basic or Problem-state counter sets

SMF Info
--------
    Field: `SMF113_1_CTRVERSION1`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

First counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Basic or Problem-state counter sets
"""
ctrversion1.__doc__ = """First counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Basic or Problem-state counter sets

SMF Info
--------
    Field: `SMF113_1_CTRVERSION1`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

First counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Basic or Problem-state counter sets
"""

ctrversion2 : Final[Field] = Field(
    name='ctrversion2',
    origin='SMF113_1_CTRVERSION2',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Second counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Crypto-activity, Extended or MT-diagnostic counters

SMF Info
--------
    Field: `SMF113_1_CTRVERSION2`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Second counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Crypto-activity, Extended or MT-diagnostic counters
"""
ctrversion2.__doc__ = """Second counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Crypto-activity, Extended or MT-diagnostic counters

SMF Info
--------
    Field: `SMF113_1_CTRVERSION2`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Second counter version number. This number is incremented when there is a change to the meaning of a counter or the number of installed counters in the Crypto-activity, Extended or MT-diagnostic counters
"""

flags : Final[Field] = Field(
    name='flags',
    origin='SMF113_1_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Not available

SMF Info
--------
    Field: `SMF113_1_FLAGS`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Not available
"""
flags.__doc__ = """Not available

SMF Info
--------
    Field: `SMF113_1_FLAGS`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Not available
"""

lostctrdata : Final[Field] = Field(
    name='lostctrdata',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF113_1_CTR,
)
"""When ON, the hardware indicated the hardware has lost counter data during the current interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF113_1_FLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

When ON, the hardware indicated the hardware has lost counter data during the current interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
lostctrdata.__doc__ = """When ON, the hardware indicated the hardware has lost counter data during the current interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF113_1_FLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

When ON, the hardware indicated the hardware has lost counter data during the current interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

lostdata : Final[Field] = Field(
    name='lostdata',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF113_1_FLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
lostdata.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF113_1_FLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

lostmtdata : Final[Field] = Field(
    name='lostmtdata',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF113_1_CTR,
)
"""When ON, the hardware indicated the hardware has lost MT counter data during the current interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF113_1_FLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

When ON, the hardware indicated the hardware has lost MT counter data during the current interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
lostmtdata.__doc__ = """When ON, the hardware indicated the hardware has lost MT counter data during the current interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF113_1_FLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

When ON, the hardware indicated the hardware has lost MT counter data during the current interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

zcbp : Final[Field] = Field(
    name='zcbp',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flags,
    record=record,
    record_map=SMF113_1_CTR,
)
"""When ON, a value of 2 for SMF113_1_CpuProcClass refers to a zCBP processor type, when off a zAAP processor type.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF113_1_FLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

When ON, a value of 2 for SMF113_1_CpuProcClass refers to a zCBP processor type, when off a zAAP processor type.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
zcbp.__doc__ = """When ON, a value of 2 for SMF113_1_CpuProcClass refers to a zCBP processor type, when off a zAAP processor type.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flags`(`SMF113_1_FLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

When ON, a value of 2 for SMF113_1_CpuProcClass refers to a zCBP processor type, when off a zAAP processor type.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

csof : Final[Field] = Field(
    name='csof',
    origin='SMF113_1_CSOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Offset to counter set section from beginning of record

SMF Info
--------
    Field: `SMF113_1_CSOF`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Offset to counter set section from beginning of record
"""
csof.__doc__ = """Offset to counter set section from beginning of record

SMF Info
--------
    Field: `SMF113_1_CSOF`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Offset to counter set section from beginning of record
"""

csln : Final[Field] = Field(
    name='csln',
    origin='SMF113_1_CSLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Length of counter set section

SMF Info
--------
    Field: `SMF113_1_CSLN`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Length of counter set section
"""
csln.__doc__ = """Length of counter set section

SMF Info
--------
    Field: `SMF113_1_CSLN`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Length of counter set section
"""

cson : Final[Field] = Field(
    name='cson',
    origin='SMF113_1_CSON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Number of counter set sections

SMF Info
--------
    Field: `SMF113_1_CSON`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Number of counter set sections
"""
cson.__doc__ = """Number of counter set sections

SMF Info
--------
    Field: `SMF113_1_CSON`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Number of counter set sections
"""

machseqcode : Final[Field] = Field(
    name='machseqcode',
    origin='SMF113_1_MACHSEQCODE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113_1_CTR,
)
"""The machine sequence code

SMF Info
--------
    Field: `SMF113_1_MACHSEQCODE`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

The machine sequence code
"""
machseqcode.__doc__ = """The machine sequence code

SMF Info
--------
    Field: `SMF113_1_MACHSEQCODE`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

The machine sequence code
"""

coreid : Final[Field] = Field(
    name='coreid',
    origin='SMF113_1_COREID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CTR,
)
"""Core ID for which the hardware event counters are recorded. Note that zero is a valid core ID number.

SMF Info
--------
    Field: `SMF113_1_COREID`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Core ID for which the hardware event counters are recorded. Note that zero is a valid core ID number.
"""
coreid.__doc__ = """Core ID for which the hardware event counters are recorded. Note that zero is a valid core ID number.

SMF Info
--------
    Field: `SMF113_1_COREID`
    Record: `SMF113S1`
    Map: `SMF113_1_CTR`

Core ID for which the hardware event counters are recorded. Note that zero is a valid core ID number.
"""

cstype : Final[Field] = Field(
    name='cstype',
    origin='SMF113_1_CSTYPE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CSS,
)
"""Counter set type for counters recorded: 1 = Basic, 2 = Problem state, 3 = Crypto-activity, 4 = Extended 5 = z/OS 6 = MT-diagnostic

SMF Info
--------
    Field: `SMF113_1_CSTYPE`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Counter set type for counters recorded: 1 = Basic, 2 = Problem state, 3 = Crypto-activity, 4 = Extended 5 = z/OS 6 = MT-diagnostic
"""
cstype.__doc__ = """Counter set type for counters recorded: 1 = Basic, 2 = Problem state, 3 = Crypto-activity, 4 = Extended 5 = z/OS 6 = MT-diagnostic

SMF Info
--------
    Field: `SMF113_1_CSTYPE`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Counter set type for counters recorded: 1 = Basic, 2 = Problem state, 3 = Crypto-activity, 4 = Extended 5 = z/OS 6 = MT-diagnostic
"""

csflags : Final[Field] = Field(
    name='csflags',
    origin='SMF113_1_CSFLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF113_1_CSS,
)
"""Not available

SMF Info
--------
    Field: `SMF113_1_CSFLAGS`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Not available
"""
csflags.__doc__ = """Not available

SMF Info
--------
    Field: `SMF113_1_CSFLAGS`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Not available
"""

csuselcds : Final[Field] = Field(
    name='csuselcds',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=csflags,
    record=record,
    record_map=SMF113_1_CSS,
)
"""When on the counter set's counter data section described by fields SMF113_1_CDOF, SMF113_1_CDLN, and SMF113_1_CDON is mapped by SMF113_1_LCDS, otherwise it is mapped by SMF113_1_SCDS.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `csflags`(`SMF113_1_CSFLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

When on the counter set's counter data section described by fields SMF113_1_CDOF, SMF113_1_CDLN, and SMF113_1_CDON is mapped by SMF113_1_LCDS, otherwise it is mapped by SMF113_1_SCDS.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
csuselcds.__doc__ = """When on the counter set's counter data section described by fields SMF113_1_CDOF, SMF113_1_CDLN, and SMF113_1_CDON is mapped by SMF113_1_LCDS, otherwise it is mapped by SMF113_1_SCDS.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `csflags`(`SMF113_1_CSFLAGS`)
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

When on the counter set's counter data section described by fields SMF113_1_CDOF, SMF113_1_CDLN, and SMF113_1_CDON is mapped by SMF113_1_LCDS, otherwise it is mapped by SMF113_1_SCDS.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cdof : Final[Field] = Field(
    name='cdof',
    origin='SMF113_1_CDOF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CSS,
)
"""Offset to counter data section for this counter set, from the beginning of record. This can be to a SMF113_1_SCDS section or a SMF113_1_LCDS section, depending SMF113_1_CSUseLCDS

SMF Info
--------
    Field: `SMF113_1_CDOF`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Offset to counter data section for this counter set, from the beginning of record. This can be to a SMF113_1_SCDS section or a SMF113_1_LCDS section, depending SMF113_1_CSUseLCDS
"""
cdof.__doc__ = """Offset to counter data section for this counter set, from the beginning of record. This can be to a SMF113_1_SCDS section or a SMF113_1_LCDS section, depending SMF113_1_CSUseLCDS

SMF Info
--------
    Field: `SMF113_1_CDOF`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Offset to counter data section for this counter set, from the beginning of record. This can be to a SMF113_1_SCDS section or a SMF113_1_LCDS section, depending SMF113_1_CSUseLCDS
"""

cdln : Final[Field] = Field(
    name='cdln',
    origin='SMF113_1_CDLN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CSS,
)
"""Length of counter data section

SMF Info
--------
    Field: `SMF113_1_CDLN`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Length of counter data section
"""
cdln.__doc__ = """Length of counter data section

SMF Info
--------
    Field: `SMF113_1_CDLN`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Length of counter data section
"""

cdon : Final[Field] = Field(
    name='cdon',
    origin='SMF113_1_CDON',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_CSS,
)
"""Number of counter data sections

SMF Info
--------
    Field: `SMF113_1_CDON`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Number of counter data sections
"""
cdon.__doc__ = """Number of counter data sections

SMF Info
--------
    Field: `SMF113_1_CDON`
    Record: `SMF113S1`
    Map: `SMF113_1_CSS`

Number of counter data sections
"""

scr : Final[Field] = Field(
    name='scr',
    origin='SMF113_1_SCR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_SCDS,
)
"""Event counter value delta. Contains the number of times a particular counter event has occurred since either the start of the HIS collection run, or the previous SMF 113 Type 1 record.

SMF Info
--------
    Field: `SMF113_1_SCR`
    Record: `SMF113S1`
    Map: `SMF113_1_SCDS`

Event counter value delta. Contains the number of times a particular counter event has occurred since either the start of the HIS collection run, or the previous SMF 113 Type 1 record.
"""
scr.__doc__ = """Event counter value delta. Contains the number of times a particular counter event has occurred since either the start of the HIS collection run, or the previous SMF 113 Type 1 record.

SMF Info
--------
    Field: `SMF113_1_SCR`
    Record: `SMF113S1`
    Map: `SMF113_1_SCDS`

Event counter value delta. Contains the number of times a particular counter event has occurred since either the start of the HIS collection run, or the previous SMF 113 Type 1 record.
"""

lcr : Final[Field] = Field(
    name='lcr',
    origin='SMF113_1_LCR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF113_1_LCDS,
)
"""Event counter value delta. Contains the number of times a particular counter event has occurred since either the start of the HIS collection run, or the previous SMF 113 Type 1 record.

SMF Info
--------
    Field: `SMF113_1_LCR`
    Record: `SMF113S1`
    Map: `SMF113_1_LCDS`

Event counter value delta. Contains the number of times a particular counter event has occurred since either the start of the HIS collection run, or the previous SMF 113 Type 1 record.
"""
lcr.__doc__ = """Event counter value delta. Contains the number of times a particular counter event has occurred since either the start of the HIS collection run, or the previous SMF 113 Type 1 record.

SMF Info
--------
    Field: `SMF113_1_LCR`
    Record: `SMF113S1`
    Map: `SMF113_1_LCDS`

Event counter value delta. Contains the number of times a particular counter event has occurred since either the start of the HIS collection run, or the previous SMF 113 Type 1 record.
"""
