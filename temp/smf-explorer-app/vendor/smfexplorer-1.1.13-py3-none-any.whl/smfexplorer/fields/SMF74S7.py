# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 7"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=7,
                                spec='SMF 74 Subtype 7',
                                post=None)
"""SMF 74 Subtype 7"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R747GDAT: Final[RecordMap] = RecordMap(
    origin='R747GDAT',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Global Data Section',
    post=None,
    record_mapping=False)
"""Global Data Section"""
R747SDAT: Final[RecordMap] = RecordMap(
    origin='R747SDAT',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Switch data section',
    post=None,
    record_mapping=False)
"""Switch data section"""
R747PDAT: Final[RecordMap] = RecordMap(
    origin='R747PDAT',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Port data section',
    post=None,
    record_mapping=False)
"""Port data section"""
R747CDAT: Final[RecordMap] = RecordMap(
    origin='R747CDAT',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Port data section',
    post=None,
    record_mapping=False)
"""Port data section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S7`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S7`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S7`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S7`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S7`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S7`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S7`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S7`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S7`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S7`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S7`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S7`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S7`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S7`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S7`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S7`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S7`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S7`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S7`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S7`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S7`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S7`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S7`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S7`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S7`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S7`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S7`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S7`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S7`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S7`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S7`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S7`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S7`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

go : Final[Field] = Field(
    name='go',
    origin='SMF747GO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to global data section

SMF Info
--------
    Field: `SMF747GO`
    Record: `SMF74S7`
    Map: Not part of a map

Offset to global data section
"""
go.__doc__ = """Offset to global data section

SMF Info
--------
    Field: `SMF747GO`
    Record: `SMF74S7`
    Map: Not part of a map

Offset to global data section
"""

gl : Final[Field] = Field(
    name='gl',
    origin='SMF747GL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of global data section

SMF Info
--------
    Field: `SMF747GL`
    Record: `SMF74S7`
    Map: Not part of a map

Length of global data section
"""
gl.__doc__ = """Length of global data section

SMF Info
--------
    Field: `SMF747GL`
    Record: `SMF74S7`
    Map: Not part of a map

Length of global data section
"""

gn : Final[Field] = Field(
    name='gn',
    origin='SMF747GN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of global data sections

SMF Info
--------
    Field: `SMF747GN`
    Record: `SMF74S7`
    Map: Not part of a map

Number of global data sections
"""
gn.__doc__ = """Number of global data sections

SMF Info
--------
    Field: `SMF747GN`
    Record: `SMF74S7`
    Map: Not part of a map

Number of global data sections
"""

so : Final[Field] = Field(
    name='so',
    origin='SMF747SO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to switch data section

SMF Info
--------
    Field: `SMF747SO`
    Record: `SMF74S7`
    Map: Not part of a map

Offset to switch data section
"""
so.__doc__ = """Offset to switch data section

SMF Info
--------
    Field: `SMF747SO`
    Record: `SMF74S7`
    Map: Not part of a map

Offset to switch data section
"""

sl : Final[Field] = Field(
    name='sl',
    origin='SMF747SL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of switch data section

SMF Info
--------
    Field: `SMF747SL`
    Record: `SMF74S7`
    Map: Not part of a map

Length of switch data section
"""
sl.__doc__ = """Length of switch data section

SMF Info
--------
    Field: `SMF747SL`
    Record: `SMF74S7`
    Map: Not part of a map

Length of switch data section
"""

sn : Final[Field] = Field(
    name='sn',
    origin='SMF747SN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of switch data sections

SMF Info
--------
    Field: `SMF747SN`
    Record: `SMF74S7`
    Map: Not part of a map

Number of switch data sections
"""
sn.__doc__ = """Number of switch data sections

SMF Info
--------
    Field: `SMF747SN`
    Record: `SMF74S7`
    Map: Not part of a map

Number of switch data sections
"""

po : Final[Field] = Field(
    name='po',
    origin='SMF747PO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to port data section

SMF Info
--------
    Field: `SMF747PO`
    Record: `SMF74S7`
    Map: Not part of a map

Offset to port data section
"""
po.__doc__ = """Offset to port data section

SMF Info
--------
    Field: `SMF747PO`
    Record: `SMF74S7`
    Map: Not part of a map

Offset to port data section
"""

pl : Final[Field] = Field(
    name='pl',
    origin='SMF747PL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of port data section

SMF Info
--------
    Field: `SMF747PL`
    Record: `SMF74S7`
    Map: Not part of a map

Length of port data section
"""
pl.__doc__ = """Length of port data section

SMF Info
--------
    Field: `SMF747PL`
    Record: `SMF74S7`
    Map: Not part of a map

Length of port data section
"""

pn : Final[Field] = Field(
    name='pn',
    origin='SMF747PN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of port data sections

SMF Info
--------
    Field: `SMF747PN`
    Record: `SMF74S7`
    Map: Not part of a map

Number of port data sections
"""
pn.__doc__ = """Number of port data sections

SMF Info
--------
    Field: `SMF747PN`
    Record: `SMF74S7`
    Map: Not part of a map

Number of port data sections
"""

co : Final[Field] = Field(
    name='co',
    origin='SMF747CO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to connector section

SMF Info
--------
    Field: `SMF747CO`
    Record: `SMF74S7`
    Map: Not part of a map

Offset to connector section
"""
co.__doc__ = """Offset to connector section

SMF Info
--------
    Field: `SMF747CO`
    Record: `SMF74S7`
    Map: Not part of a map

Offset to connector section
"""

cl : Final[Field] = Field(
    name='cl',
    origin='SMF747CL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of connector section

SMF Info
--------
    Field: `SMF747CL`
    Record: `SMF74S7`
    Map: Not part of a map

Length of connector section
"""
cl.__doc__ = """Length of connector section

SMF Info
--------
    Field: `SMF747CL`
    Record: `SMF74S7`
    Map: Not part of a map

Length of connector section
"""

cn : Final[Field] = Field(
    name='cn',
    origin='SMF747CN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of connector sections

SMF Info
--------
    Field: `SMF747CN`
    Record: `SMF74S7`
    Map: Not part of a map

Number of connector sections
"""
cn.__doc__ = """Number of connector sections

SMF Info
--------
    Field: `SMF747CN`
    Record: `SMF74S7`
    Map: Not part of a map

Number of connector sections
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S7`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S7`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S7`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S7`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S7`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S7`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S7`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S7`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S7`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S7`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S7`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S7`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S7`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S7`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

r747gcfl : Final[Field] = Field(
    name='r747gcfl',
    origin='R747GCFL',
    type=FieldType.STRING,
    record=record,
    record_map=R747GDAT,
)
"""Configuration change flags

SMF Info
--------
    Field: `R747GCFL`
    Record: `SMF74S7`
    Map: `R747GDAT`

Configuration change flags
"""
r747gcfl.__doc__ = """Configuration change flags

SMF Info
--------
    Field: `R747GCFL`
    Record: `SMF74S7`
    Map: `R747GDAT`

Configuration change flags
"""

r747gdca : Final[Field] = Field(
    name='r747gdca',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r747gcfl,
    record=record,
    record_map=R747GDAT,
)
"""=1, Configuration changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747gcfl`(`R747GCFL`)
    Record: `SMF74S7`
    Map: `R747GDAT`

=1, Configuration changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r747gdca.__doc__ = """=1, Configuration changed during interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747gcfl`(`R747GCFL`)
    Record: `SMF74S7`
    Map: `R747GDAT`

=1, Configuration changed during interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r747giac : Final[Field] = Field(
    name='r747giac',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r747gcfl,
    record=record,
    record_map=R747GDAT,
)
"""=1, Configuration changed since IPL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747gcfl`(`R747GCFL`)
    Record: `SMF74S7`
    Map: `R747GDAT`

=1, Configuration changed since IPL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r747giac.__doc__ = """=1, Configuration changed since IPL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747gcfl`(`R747GCFL`)
    Record: `SMF74S7`
    Map: `R747GDAT`

=1, Configuration changed since IPL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r747giod : Final[Field] = Field(
    name='r747giod',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r747gcfl,
    record=record,
    record_map=R747GDAT,
)
"""=1, System IPLed via IODF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747gcfl`(`R747GCFL`)
    Record: `SMF74S7`
    Map: `R747GDAT`

=1, System IPLed via IODF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r747giod.__doc__ = """=1, System IPLed via IODF(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747gcfl`(`R747GCFL`)
    Record: `SMF74S7`
    Map: `R747GDAT`

=1, System IPLed via IODF

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r747gicv : Final[Field] = Field(
    name='r747gicv',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r747gcfl,
    record=record,
    record_map=R747GDAT,
)
"""=1, I/O configuration token is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747gcfl`(`R747GCFL`)
    Record: `SMF74S7`
    Map: `R747GDAT`

=1, I/O configuration token is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r747gicv.__doc__ = """=1, I/O configuration token is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747gcfl`(`R747GCFL`)
    Record: `SMF74S7`
    Map: `R747GDAT`

=1, I/O configuration token is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r747gnfd : Final[Field] = Field(
    name='r747gnfd',
    origin='R747GNFD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R747GDAT,
)
"""Number of installed FCD switches

SMF Info
--------
    Field: `R747GNFD`
    Record: `SMF74S7`
    Map: `R747GDAT`

Number of installed FCD switches
"""
r747gnfd.__doc__ = """Number of installed FCD switches

SMF Info
--------
    Field: `R747GNFD`
    Record: `SMF74S7`
    Map: `R747GDAT`

Number of installed FCD switches
"""

r747ginm : Final[Field] = Field(
    name='r747ginm',
    origin='R747GINM',
    type=FieldType.STRING,
    record=record,
    record_map=R747GDAT,
)
"""IODF name

SMF Info
--------
    Field: `R747GINM`
    Record: `SMF74S7`
    Map: `R747GDAT`

IODF name
"""
r747ginm.__doc__ = """IODF name

SMF Info
--------
    Field: `R747GINM`
    Record: `SMF74S7`
    Map: `R747GDAT`

IODF name
"""

r747gisf : Final[Field] = Field(
    name='r747gisf',
    origin='R747GISF',
    type=FieldType.STRING,
    record=record,
    record_map=R747GDAT,
)
"""Suffix of IODF name

SMF Info
--------
    Field: `R747GISF`
    Record: `SMF74S7`
    Map: `R747GDAT`

Suffix of IODF name
"""
r747gisf.__doc__ = """Suffix of IODF name

SMF Info
--------
    Field: `R747GISF`
    Record: `SMF74S7`
    Map: `R747GDAT`

Suffix of IODF name
"""

r747gicd : Final[Field] = Field(
    name='r747gicd',
    origin='R747GICD',
    type=FieldType.STRING,
    record=record,
    record_map=R747GDAT,
)
"""IODF creation date mm/dd/yyyy

SMF Info
--------
    Field: `R747GICD`
    Record: `SMF74S7`
    Map: `R747GDAT`

IODF creation date mm/dd/yyyy
"""
r747gicd.__doc__ = """IODF creation date mm/dd/yyyy

SMF Info
--------
    Field: `R747GICD`
    Record: `SMF74S7`
    Map: `R747GDAT`

IODF creation date mm/dd/yyyy
"""

r747gict : Final[Field] = Field(
    name='r747gict',
    origin='R747GICT',
    type=FieldType.STRING,
    record=record,
    record_map=R747GDAT,
)
"""IODF creation time hh.mm.ss

SMF Info
--------
    Field: `R747GICT`
    Record: `SMF74S7`
    Map: `R747GDAT`

IODF creation time hh.mm.ss
"""
r747gict.__doc__ = """IODF creation time hh.mm.ss

SMF Info
--------
    Field: `R747GICT`
    Record: `SMF74S7`
    Map: `R747GDAT`

IODF creation time hh.mm.ss
"""

r747sdev : Final[Field] = Field(
    name='r747sdev',
    origin='R747SDEV',
    type=FieldType.STRING,
    record=record,
    record_map=R747SDAT,
)
"""Switch device number

SMF Info
--------
    Field: `R747SDEV`
    Record: `SMF74S7`
    Map: `R747SDAT`

Switch device number
"""
r747sdev.__doc__ = """Switch device number

SMF Info
--------
    Field: `R747SDEV`
    Record: `SMF74S7`
    Map: `R747SDAT`

Switch device number
"""

r747slsn : Final[Field] = Field(
    name='r747slsn',
    origin='R747SLSN',
    type=FieldType.STRING,
    record=record,
    record_map=R747SDAT,
)
"""Logical switch number

SMF Info
--------
    Field: `R747SLSN`
    Record: `SMF74S7`
    Map: `R747SDAT`

Logical switch number
"""
r747slsn.__doc__ = """Logical switch number

SMF Info
--------
    Field: `R747SLSN`
    Record: `SMF74S7`
    Map: `R747SDAT`

Logical switch number
"""

r747spfl : Final[Field] = Field(
    name='r747spfl',
    origin='R747SPFL',
    type=FieldType.STRING,
    record=record,
    record_map=R747SDAT,
)
"""Switch processing flags

SMF Info
--------
    Field: `R747SPFL`
    Record: `SMF74S7`
    Map: `R747SDAT`

Switch processing flags
"""
r747spfl.__doc__ = """Switch processing flags

SMF Info
--------
    Field: `R747SPFL`
    Record: `SMF74S7`
    Map: `R747SDAT`

Switch processing flags
"""

r747svar : Final[Field] = Field(
    name='r747svar',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r747spfl,
    record=record,
    record_map=R747SDAT,
)
"""=1, status of switch has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, status of switch has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r747svar.__doc__ = """=1, status of switch has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, status of switch has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r747snpc : Final[Field] = Field(
    name='r747snpc',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r747spfl,
    record=record,
    record_map=R747SDAT,
)
"""=1, number of ports has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, number of ports has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r747snpc.__doc__ = """=1, number of ports has changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, number of ports has changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r747soff : Final[Field] = Field(
    name='r747soff',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r747spfl,
    record=record,
    record_map=R747SDAT,
)
"""=1, switch is offline(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, switch is offline

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r747soff.__doc__ = """=1, switch is offline(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, switch is offline

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r747snol : Final[Field] = Field(
    name='r747snol',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r747spfl,
    record=record,
    record_map=R747SDAT,
)
"""=1, switch is now online(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, switch is now online

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r747snol.__doc__ = """=1, switch is now online(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, switch is now online

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r747sfcs : Final[Field] = Field(
    name='r747sfcs',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r747spfl,
    record=record,
    record_map=R747SDAT,
)
"""=1, cascaded switch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, cascaded switch

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r747sfcs.__doc__ = """=1, cascaded switch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747spfl`(`R747SPFL`)
    Record: `SMF74S7`
    Map: `R747SDAT`

=1, cascaded switch

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r747snd : Final[Field] = Field(
    name='r747snd',
    origin='R747SND',
    type=FieldType.STRING,
    record=record,
    record_map=R747SDAT,
)
"""ND associated with switch device

SMF Info
--------
    Field: `R747SND`
    Record: `SMF74S7`
    Map: `R747SDAT`

ND associated with switch device
"""
r747snd.__doc__ = """ND associated with switch device

SMF Info
--------
    Field: `R747SND`
    Record: `SMF74S7`
    Map: `R747SDAT`

ND associated with switch device
"""

r747snsp : Final[Field] = Field(
    name='r747snsp',
    origin='R747SNSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R747SDAT,
)
"""Number of supported ports for this switch

SMF Info
--------
    Field: `R747SNSP`
    Record: `SMF74S7`
    Map: `R747SDAT`

Number of supported ports for this switch
"""
r747snsp.__doc__ = """Number of supported ports for this switch

SMF Info
--------
    Field: `R747SNSP`
    Record: `SMF74S7`
    Map: `R747SDAT`

Number of supported ports for this switch
"""

r747snip : Final[Field] = Field(
    name='r747snip',
    origin='R747SNIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R747SDAT,
)
"""Number of installed ports for this switch

SMF Info
--------
    Field: `R747SNIP`
    Record: `SMF74S7`
    Map: `R747SDAT`

Number of installed ports for this switch
"""
r747snip.__doc__ = """Number of installed ports for this switch

SMF Info
--------
    Field: `R747SNIP`
    Record: `SMF74S7`
    Map: `R747SDAT`

Number of installed ports for this switch
"""

r747pnum : Final[Field] = Field(
    name='r747pnum',
    origin='R747PNUM',
    type=FieldType.STRING,
    record=record,
    record_map=R747PDAT,
)
"""Port number

SMF Info
--------
    Field: `R747PNUM`
    Record: `SMF74S7`
    Map: `R747PDAT`

Port number
"""
r747pnum.__doc__ = """Port number

SMF Info
--------
    Field: `R747PNUM`
    Record: `SMF74S7`
    Map: `R747PDAT`

Port number
"""

r747padr : Final[Field] = Field(
    name='r747padr',
    origin='R747PADR',
    type=FieldType.STRING,
    record=record,
    record_map=R747PDAT,
)
"""Port address

SMF Info
--------
    Field: `R747PADR`
    Record: `SMF74S7`
    Map: `R747PDAT`

Port address
"""
r747padr.__doc__ = """Port address

SMF Info
--------
    Field: `R747PADR`
    Record: `SMF74S7`
    Map: `R747PDAT`

Port address
"""

r747ptfl : Final[Field] = Field(
    name='r747ptfl',
    origin='R747PTFL',
    type=FieldType.STRING,
    record=record,
    record_map=R747PDAT,
)
"""Port type flags

SMF Info
--------
    Field: `R747PTFL`
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type flags
"""
r747ptfl.__doc__ = """Port type flags

SMF Info
--------
    Field: `R747PTFL`
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type flags
"""

r747pscu : Final[Field] = Field(
    name='r747pscu',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r747ptfl,
    record=record,
    record_map=R747PDAT,
)
"""Port type is single CU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ptfl`(`R747PTFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is single CU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r747pscu.__doc__ = """Port type is single CU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ptfl`(`R747PTFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is single CU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r747pmcu : Final[Field] = Field(
    name='r747pmcu',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r747ptfl,
    record=record,
    record_map=R747PDAT,
)
"""Port type is multiple CU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ptfl`(`R747PTFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is multiple CU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r747pmcu.__doc__ = """Port type is multiple CU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ptfl`(`R747PTFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is multiple CU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r747pchp : Final[Field] = Field(
    name='r747pchp',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r747ptfl,
    record=record,
    record_map=R747PDAT,
)
"""Port type is CHPID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ptfl`(`R747PTFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is CHPID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r747pchp.__doc__ = """Port type is CHPID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ptfl`(`R747PTFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is CHPID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r747psw : Final[Field] = Field(
    name='r747psw',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r747ptfl,
    record=record,
    record_map=R747PDAT,
)
"""Port type is switch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ptfl`(`R747PTFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is switch

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r747psw.__doc__ = """Port type is switch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ptfl`(`R747PTFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is switch

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r747psfl : Final[Field] = Field(
    name='r747psfl',
    origin='R747PSFL',
    type=FieldType.STRING,
    record=record,
    record_map=R747PDAT,
)
"""Status flags

SMF Info
--------
    Field: `R747PSFL`
    Record: `SMF74S7`
    Map: `R747PDAT`

Status flags
"""
r747psfl.__doc__ = """Status flags

SMF Info
--------
    Field: `R747PSFL`
    Record: `SMF74S7`
    Map: `R747PDAT`

Status flags
"""

r747ptnu : Final[Field] = Field(
    name='r747ptnu',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r747psfl,
    record=record,
    record_map=R747PDAT,
)
"""Port type is not unique(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is not unique

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r747ptnu.__doc__ = """Port type is not unique(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port type is not unique

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r747pinu : Final[Field] = Field(
    name='r747pinu',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r747psfl,
    record=record,
    record_map=R747PDAT,
)
"""Id is not unique or not known(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Id is not unique or not known

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r747pinu.__doc__ = """Id is not unique or not known(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Id is not unique or not known

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r747posy : Final[Field] = Field(
    name='r747posy',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r747psfl,
    record=record,
    record_map=R747PDAT,
)
"""1=, channel on caller's system(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

1=, channel on caller's system

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r747posy.__doc__ = """1=, channel on caller's system(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

1=, channel on caller's system

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r747pins : Final[Field] = Field(
    name='r747pins',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r747psfl,
    record=record,
    record_map=R747PDAT,
)
"""1=, port installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

1=, port installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r747pins.__doc__ = """1=, port installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

1=, port installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r747pvar : Final[Field] = Field(
    name='r747pvar',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r747psfl,
    record=record,
    record_map=R747PDAT,
)
"""Port status changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port status changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r747pvar.__doc__ = """Port status changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port status changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r747prem : Final[Field] = Field(
    name='r747prem',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r747psfl,
    record=record,
    record_map=R747PDAT,
)
"""Port has been removed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port has been removed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r747prem.__doc__ = """Port has been removed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port has been removed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r747pact : Final[Field] = Field(
    name='r747pact',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r747psfl,
    record=record,
    record_map=R747PDAT,
)
"""Port has been activated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port has been activated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r747pact.__doc__ = """Port has been activated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port has been activated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r747pnmd : Final[Field] = Field(
    name='r747pnmd',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r747psfl,
    record=record,
    record_map=R747PDAT,
)
"""This entry doesn't contain measurement data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

This entry doesn't contain measurement data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r747pnmd.__doc__ = """This entry doesn't contain measurement data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747psfl`(`R747PSFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

This entry doesn't contain measurement data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r747pcu : Final[Field] = Field(
    name='r747pcu',
    origin='R747PCU',
    type=FieldType.STRING,
    record=record,
    record_map=R747PDAT,
)
"""Connector id (CU)

SMF Info
--------
    Field: `R747PCU`
    Record: `SMF74S7`
    Map: `R747PDAT`

Connector id (CU)
"""
r747pcu.__doc__ = """Connector id (CU)

SMF Info
--------
    Field: `R747PCU`
    Record: `SMF74S7`
    Map: `R747PDAT`

Connector id (CU)
"""

r747pcp : Final[Field] = Field(
    name='r747pcp',
    origin='R747PCP',
    type=FieldType.STRING,
    record=record,
    record_map=R747PDAT,
)
"""Connector id (channel path)

SMF Info
--------
    Field: `R747PCP`
    Record: `SMF74S7`
    Map: `R747PDAT`

Connector id (channel path)
"""
r747pcp.__doc__ = """Connector id (channel path)

SMF Info
--------
    Field: `R747PCP`
    Record: `SMF74S7`
    Map: `R747PDAT`

Connector id (channel path)
"""

r747pcun : Final[Field] = Field(
    name='r747pcun',
    origin='R747PCUN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R747PDAT,
)
"""Number of connector CUs

SMF Info
--------
    Field: `R747PCUN`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of connector CUs
"""
r747pcun.__doc__ = """Number of connector CUs

SMF Info
--------
    Field: `R747PCUN`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of connector CUs
"""

r747pnpc : Final[Field] = Field(
    name='r747pnpc',
    origin='R747PNPC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R747PDAT,
)
"""Number of connector sections

SMF Info
--------
    Field: `R747PNPC`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of connector sections
"""
r747pnpc.__doc__ = """Number of connector sections

SMF Info
--------
    Field: `R747PNPC`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of connector sections
"""

r747pxpc : Final[Field] = Field(
    name='r747pxpc',
    origin='R747PXPC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R747PDAT,
)
"""Index of first connector section

SMF Info
--------
    Field: `R747PXPC`
    Record: `SMF74S7`
    Map: `R747PDAT`

Index of first connector section
"""
r747pxpc.__doc__ = """Index of first connector section

SMF Info
--------
    Field: `R747PXPC`
    Record: `SMF74S7`
    Map: `R747PDAT`

Index of first connector section
"""

r747ppfl : Final[Field] = Field(
    name='r747ppfl',
    origin='R747PPFL',
    type=FieldType.STRING,
    record=record,
    record_map=R747PDAT,
)
"""Port flags

SMF Info
--------
    Field: `R747PPFL`
    Record: `SMF74S7`
    Map: `R747PDAT`

Port flags
"""
r747ppfl.__doc__ = """Port flags

SMF Info
--------
    Field: `R747PPFL`
    Record: `SMF74S7`
    Map: `R747PDAT`

Port flags
"""

r747ppir : Final[Field] = Field(
    name='r747ppir',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r747ppfl,
    record=record,
    record_map=R747PDAT,
)
"""Port information was returned at least once for this port(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port information was returned at least once for this port

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r747ppir.__doc__ = """Port information was returned at least once for this port(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port information was returned at least once for this port

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r747pnti : Final[Field] = Field(
    name='r747pnti',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r747ppfl,
    record=record,
    record_map=R747PDAT,
)
"""Port information showed this port not installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port information showed this port not installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r747pnti.__doc__ = """Port information showed this port not installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port information showed this port not installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r747plf : Final[Field] = Field(
    name='r747plf',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r747ppfl,
    record=record,
    record_map=R747PDAT,
)
"""Port information showed link failure condition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port information showed link failure condition

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r747plf.__doc__ = """Port information showed link failure condition(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port information showed link failure condition

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r747poff : Final[Field] = Field(
    name='r747poff',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r747ppfl,
    record=record,
    record_map=R747PDAT,
)
"""Port information showed this port offline(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port information showed this port offline

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r747poff.__doc__ = """Port information showed this port offline(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Port information showed this port offline

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r747pscr : Final[Field] = Field(
    name='r747pscr',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r747ppfl,
    record=record,
    record_map=R747PDAT,
)
"""Statistics were returned at least once for this port(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Statistics were returned at least once for this port

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r747pscr.__doc__ = """Statistics were returned at least once for this port(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ppfl`(`R747PPFL`)
    Record: `SMF74S7`
    Map: `R747PDAT`

Statistics were returned at least once for this port

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r747pfpt : Final[Field] = Field(
    name='r747pfpt',
    origin='R747PFPT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R747PDAT,
)
"""Frame pacing time in units of 2.5 micro-seconds (long floating point)

SMF Info
--------
    Field: `R747PFPT`
    Record: `SMF74S7`
    Map: `R747PDAT`

Frame pacing time in units of 2.5 micro-seconds (long floating point)
"""
r747pfpt.__doc__ = """Frame pacing time in units of 2.5 micro-seconds (long floating point)

SMF Info
--------
    Field: `R747PFPT`
    Record: `SMF74S7`
    Map: `R747PDAT`

Frame pacing time in units of 2.5 micro-seconds (long floating point)
"""

r747pnwr : Final[Field] = Field(
    name='r747pnwr',
    origin='R747PNWR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R747PDAT,
)
"""Number of words received (long floating point)

SMF Info
--------
    Field: `R747PNWR`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of words received (long floating point)
"""
r747pnwr.__doc__ = """Number of words received (long floating point)

SMF Info
--------
    Field: `R747PNWR`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of words received (long floating point)
"""

r747pnwt : Final[Field] = Field(
    name='r747pnwt',
    origin='R747PNWT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R747PDAT,
)
"""Number of words transmitted (long floating point)

SMF Info
--------
    Field: `R747PNWT`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of words transmitted (long floating point)
"""
r747pnwt.__doc__ = """Number of words transmitted (long floating point)

SMF Info
--------
    Field: `R747PNWT`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of words transmitted (long floating point)
"""

r747pnfr : Final[Field] = Field(
    name='r747pnfr',
    origin='R747PNFR',
    type=FieldType.FLOAT,
    record=record,
    record_map=R747PDAT,
)
"""Number of frames received (long floating point)

SMF Info
--------
    Field: `R747PNFR`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of frames received (long floating point)
"""
r747pnfr.__doc__ = """Number of frames received (long floating point)

SMF Info
--------
    Field: `R747PNFR`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of frames received (long floating point)
"""

r747pnft : Final[Field] = Field(
    name='r747pnft',
    origin='R747PNFT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R747PDAT,
)
"""Number of frames transmitted (long floating point)

SMF Info
--------
    Field: `R747PNFT`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of frames transmitted (long floating point)
"""
r747pnft.__doc__ = """Number of frames transmitted (long floating point)

SMF Info
--------
    Field: `R747PNFT`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of frames transmitted (long floating point)
"""

r747pner : Final[Field] = Field(
    name='r747pner',
    origin='R747PNER',
    type=FieldType.FLOAT,
    record=record,
    record_map=R747PDAT,
)
"""Number of errors (long floating point)

SMF Info
--------
    Field: `R747PNER`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of errors (long floating point)
"""
r747pner.__doc__ = """Number of errors (long floating point)

SMF Info
--------
    Field: `R747PNER`
    Record: `SMF74S7`
    Map: `R747PDAT`

Number of errors (long floating point)
"""

r747pand : Final[Field] = Field(
    name='r747pand',
    origin='R747PAND',
    type=FieldType.STRING,
    record=record,
    record_map=R747PDAT,
)
"""Node descriptor of attached unit

SMF Info
--------
    Field: `R747PAND`
    Record: `SMF74S7`
    Map: `R747PDAT`

Node descriptor of attached unit
"""
r747pand.__doc__ = """Node descriptor of attached unit

SMF Info
--------
    Field: `R747PAND`
    Record: `SMF74S7`
    Map: `R747PDAT`

Node descriptor of attached unit
"""

r747cnum : Final[Field] = Field(
    name='r747cnum',
    origin='R747CNUM',
    type=FieldType.STRING,
    record=record,
    record_map=R747CDAT,
)
"""Port number

SMF Info
--------
    Field: `R747CNUM`
    Record: `SMF74S7`
    Map: `R747CDAT`

Port number
"""
r747cnum.__doc__ = """Port number

SMF Info
--------
    Field: `R747CNUM`
    Record: `SMF74S7`
    Map: `R747CDAT`

Port number
"""

r747cadr : Final[Field] = Field(
    name='r747cadr',
    origin='R747CADR',
    type=FieldType.STRING,
    record=record,
    record_map=R747CDAT,
)
"""Port address

SMF Info
--------
    Field: `R747CADR`
    Record: `SMF74S7`
    Map: `R747CDAT`

Port address
"""
r747cadr.__doc__ = """Port address

SMF Info
--------
    Field: `R747CADR`
    Record: `SMF74S7`
    Map: `R747CDAT`

Port address
"""

r747ctfl : Final[Field] = Field(
    name='r747ctfl',
    origin='R747CTFL',
    type=FieldType.STRING,
    record=record,
    record_map=R747CDAT,
)
"""Port type flags

SMF Info
--------
    Field: `R747CTFL`
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type flags
"""
r747ctfl.__doc__ = """Port type flags

SMF Info
--------
    Field: `R747CTFL`
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type flags
"""

r747cscu : Final[Field] = Field(
    name='r747cscu',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r747ctfl,
    record=record,
    record_map=R747CDAT,
)
"""Port type is single CU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ctfl`(`R747CTFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is single CU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r747cscu.__doc__ = """Port type is single CU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ctfl`(`R747CTFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is single CU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r747cmcu : Final[Field] = Field(
    name='r747cmcu',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r747ctfl,
    record=record,
    record_map=R747CDAT,
)
"""Port type is multiple CU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ctfl`(`R747CTFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is multiple CU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r747cmcu.__doc__ = """Port type is multiple CU(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ctfl`(`R747CTFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is multiple CU

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r747cchp : Final[Field] = Field(
    name='r747cchp',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r747ctfl,
    record=record,
    record_map=R747CDAT,
)
"""Port type is CHPID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ctfl`(`R747CTFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is CHPID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r747cchp.__doc__ = """Port type is CHPID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ctfl`(`R747CTFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is CHPID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r747csw : Final[Field] = Field(
    name='r747csw',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r747ctfl,
    record=record,
    record_map=R747CDAT,
)
"""Port type is switch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ctfl`(`R747CTFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is switch

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r747csw.__doc__ = """Port type is switch(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747ctfl`(`R747CTFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is switch

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r747csfl : Final[Field] = Field(
    name='r747csfl',
    origin='R747CSFL',
    type=FieldType.STRING,
    record=record,
    record_map=R747CDAT,
)
"""Status flags

SMF Info
--------
    Field: `R747CSFL`
    Record: `SMF74S7`
    Map: `R747CDAT`

Status flags
"""
r747csfl.__doc__ = """Status flags

SMF Info
--------
    Field: `R747CSFL`
    Record: `SMF74S7`
    Map: `R747CDAT`

Status flags
"""

r747ctnu : Final[Field] = Field(
    name='r747ctnu',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r747csfl,
    record=record,
    record_map=R747CDAT,
)
"""Port type is not unique(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is not unique

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r747ctnu.__doc__ = """Port type is not unique(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port type is not unique

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r747cinu : Final[Field] = Field(
    name='r747cinu',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r747csfl,
    record=record,
    record_map=R747CDAT,
)
"""Id is not unique or not known(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Id is not unique or not known

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r747cinu.__doc__ = """Id is not unique or not known(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Id is not unique or not known

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r747cosy : Final[Field] = Field(
    name='r747cosy',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r747csfl,
    record=record,
    record_map=R747CDAT,
)
"""1=, channel on caller's system(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

1=, channel on caller's system

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r747cosy.__doc__ = """1=, channel on caller's system(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

1=, channel on caller's system

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r747cins : Final[Field] = Field(
    name='r747cins',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r747csfl,
    record=record,
    record_map=R747CDAT,
)
"""1=, port installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

1=, port installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r747cins.__doc__ = """1=, port installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

1=, port installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r747cvar : Final[Field] = Field(
    name='r747cvar',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=r747csfl,
    record=record,
    record_map=R747CDAT,
)
"""Port status changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port status changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
r747cvar.__doc__ = """Port status changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port status changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

r747crem : Final[Field] = Field(
    name='r747crem',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=r747csfl,
    record=record,
    record_map=R747CDAT,
)
"""Port has been removed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port has been removed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
r747crem.__doc__ = """Port has been removed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port has been removed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

r747cact : Final[Field] = Field(
    name='r747cact',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=r747csfl,
    record=record,
    record_map=R747CDAT,
)
"""Port has been activated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port has been activated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
r747cact.__doc__ = """Port has been activated(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

Port has been activated

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

r747cnmd : Final[Field] = Field(
    name='r747cnmd',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=r747csfl,
    record=record,
    record_map=R747CDAT,
)
"""This entry doesn't contain measurement data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

This entry doesn't contain measurement data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
r747cnmd.__doc__ = """This entry doesn't contain measurement data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r747csfl`(`R747CSFL`)
    Record: `SMF74S7`
    Map: `R747CDAT`

This entry doesn't contain measurement data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

r747ccu : Final[Field] = Field(
    name='r747ccu',
    origin='R747CCU',
    type=FieldType.STRING,
    record=record,
    record_map=R747CDAT,
)
"""Connector id (CU)

SMF Info
--------
    Field: `R747CCU`
    Record: `SMF74S7`
    Map: `R747CDAT`

Connector id (CU)
"""
r747ccu.__doc__ = """Connector id (CU)

SMF Info
--------
    Field: `R747CCU`
    Record: `SMF74S7`
    Map: `R747CDAT`

Connector id (CU)
"""

r747ccp : Final[Field] = Field(
    name='r747ccp',
    origin='R747CCP',
    type=FieldType.STRING,
    record=record,
    record_map=R747CDAT,
)
"""Connector id (channel path)

SMF Info
--------
    Field: `R747CCP`
    Record: `SMF74S7`
    Map: `R747CDAT`

Connector id (channel path)
"""
r747ccp.__doc__ = """Connector id (channel path)

SMF Info
--------
    Field: `R747CCP`
    Record: `SMF74S7`
    Map: `R747CDAT`

Connector id (channel path)
"""

r747ccun : Final[Field] = Field(
    name='r747ccun',
    origin='R747CCUN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R747CDAT,
)
"""Number of connector CUs

SMF Info
--------
    Field: `R747CCUN`
    Record: `SMF74S7`
    Map: `R747CDAT`

Number of connector CUs
"""
r747ccun.__doc__ = """Number of connector CUs

SMF Info
--------
    Field: `R747CCUN`
    Record: `SMF74S7`
    Map: `R747CDAT`

Number of connector CUs
"""
