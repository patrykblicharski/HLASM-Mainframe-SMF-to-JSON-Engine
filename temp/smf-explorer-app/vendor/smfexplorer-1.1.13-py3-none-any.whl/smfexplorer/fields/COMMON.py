# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2022
#
# END OF PROPRIETARY_STATEMENT
"""Common fields used by multiple record types"""
from typing import Final

from smfexplorer.core.field import DGFieldInfo, Field, FieldType, PseudoField

time: Final[Field] = Field(
    name='time',
    origin='SMFxTME',
    type=FieldType.TIME,
    pseudo_field=PseudoField.HEADER_TIME,
)
"""Time of Record
SMF Info
--------
    Field: `SMFxTME`
    Record: Multiple records
    Map: Not part of a map
"""
time.__doc__ = """Time of Record
SMF Info
--------
    Field: `SMFxTME`
    Record: Multiple records
    Map: Not part of a map
"""

date: Final[Field] = Field(name='date',
                           origin='SMFxDTE',
                           type=FieldType.DATE,
                           pseudo_field=PseudoField.HEADER_DATE)
"""Date of Record

SMF Info
--------
    Field: `SMFxDTE`
    Record: Multiple records
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMFxDTE`
    Record: Multiple records
    Map: Not part of a map
"""
timestamp: Final[Field] = Field(
    name='timestamp',
    post='smfpy.timestamp',
    virtual=True,
    ref=[time, date],
)
"""Record Time Stamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `time`(`SMFxTME`), `date`(`SMFxDTE`)
    Record: Multiple records
    Map: Not part of a map

Timestamp from SMF data.

Post Processing (`smfpy.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Time Stamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `time`(`SMFxTME`), `date`(`SMFxDTE`)
    Record: Multiple records
    Map: Not part of a map

Timestamp from SMF data.

Post Processing (`smfpy.timestamp`)
---------------
No post-processing parameter defined
"""

sid: Final[Field] = Field(name='sid',
                          origin='SMFxSID',
                          type=FieldType.STRING,
                          pseudo_field=PseudoField.HEADER_SID)
"""System ID

SMF Info
--------
    Field: `SMFxSID`
    Record: Multiple records
    Map: Not part of a map
"""
sid.__doc__ = """System ID

SMF Info
--------
    Field: `SMFxSID`
    Record: Multiple records
    Map: Not part of a map
"""

rty: Final[Field] = Field(name='rty',
                          origin='SMFxRTY',
                          type=FieldType.INTEGER,
                          pseudo_field=PseudoField.HEADER_RTY)
"""Record Type

SMF Info
--------
    Field: `SMFxRTY`
    Record: Multiple records
    Map: Not part of a map
"""
rty.__doc__ = """Record Type

SMF Info
--------
    Field: `SMFxRTY`
    Record: Multiple records
    Map: Not part of a map
"""

flg: Final[Field] = Field(name='flg',
                          origin='SMFxFLG',
                          type=FieldType.STRING,
                          pseudo_field=PseudoField.HEADER_FLG)
"""Record Flags

SMF Info
--------
    Field: `SMFxFLG`
    Record: Multiple records
    Map: Not part of a map
"""
flg.__doc__ = """Record Flags

SMF Info
--------
    Field: `SMFxFLG`
    Record: Multiple records
    Map: Not part of a map
"""

wid: Final[Field] = Field(name='wid',
                          origin='SMFxWID',
                          type=FieldType.STRING,
                          pseudo_field=PseudoField.HEADER_WID)
"""Sub System ID

SMF Info
--------
    Field: `SMFxWID`
    Record: Multiple records
    Map: Not part of a map
"""
wid.__doc__ = """Sub System ID

SMF Info
--------
    Field: `SMFxWID`
    Record: Multiple records
    Map: Not part of a map
"""

stp: Final[Field] = Field(name='stp',
                          origin='SMFxSTP',
                          type=FieldType.INTEGER,
                          pseudo_field=PseudoField.HEADER_STP)
"""Record Subtype

SMF Info
--------
    Field: `SMFxSTP`
    Record: Multiple records
    Map: Not part of a map
"""
stp.__doc__ = """Record Subtype

SMF Info
--------
    Field: `SMFxSTP`
    Record: Multiple records
    Map: Not part of a map
"""

dataset_index: Final[Field] = Field(name="dataset_index",
                                    type=FieldType.STRING,
                                    pseudo_field=PseudoField.DATASET_INDEX)
"""SMF Dump the record was fetched from

SMF Info
--------
    Field: Field is created dynamicly
    Record: All Records
    Map: Not part of a map
"""
dataset_index.__doc__ = """SMF Dump the record was fetched from

SMF Info
--------
    Field: Field is created dynamicly
    Record: All Records
    Map: Not part of a map
"""
