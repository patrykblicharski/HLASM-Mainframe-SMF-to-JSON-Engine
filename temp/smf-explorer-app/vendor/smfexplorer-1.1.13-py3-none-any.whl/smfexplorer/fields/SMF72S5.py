# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 72 Subtype 5"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=72,
                                smf_subtype=5,
                                spec='SMF 72 Subtype 5',
                                post=None)
"""SMF 72 Subtype 5"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]
def __interval_in_milliseconds_inline_post(df):
    return df.interval.dt.total_seconds() * 1e3



SMF72PRO: Final[RecordMap] = RecordMap(
    origin='SMF72PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=True)
"""RMF Product Section"""
R725SCTL: Final[RecordMap] = RecordMap(
    origin='R725SCTL',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Serialization Control Section (Subtype 5)',
    post=None,
    record_mapping=False)
"""Serialization Control Section (Subtype 5)"""
R725CMSD: Final[RecordMap] = RecordMap(
    origin='R725CMSD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA: Final[RecordMap] = RecordMap(
    origin='SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA: Final[RecordMap] = RecordMap(
    origin='SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA: Final[RecordMap] = RecordMap(
    origin='SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
R725LOTD: Final[RecordMap] = RecordMap(
    origin='R725LOTD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Local Lock Type Data Section (Subtype 5)',
    post=None,
    record_mapping=False)
"""Local Lock Type Data Section (Subtype 5)"""
R725CLOD: Final[RecordMap] = RecordMap(
    origin='R725CLOD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='CML Lock Owner Data Section (Subtype 5)',
    post=None,
    record_mapping=False)
"""CML Lock Owner Data Section (Subtype 5)"""
R725CLRD: Final[RecordMap] = RecordMap(
    origin='R725CLRD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='CML Lock Requestor Data Section (Subtype 5)',
    post=None,
    record_mapping=False)
"""CML Lock Requestor Data Section (Subtype 5)"""
R725LATD: Final[RecordMap] = RecordMap(
    origin='R725LATD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA: Final[RecordMap] = RecordMap(
    origin='SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
R725ENTD: Final[RecordMap] = RecordMap(
    origin='R725ENTD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA: Final[RecordMap] = RecordMap(
    origin='SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA: Final[RecordMap] = RecordMap(
    origin='SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
R725QSAD: Final[RecordMap] = RecordMap(
    origin='R725QSAD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='GRS QScan Statistics Data Section (Subtype 5)',
    post=None,
    record_mapping=False)
"""GRS QScan Statistics Data Section (Subtype 5)"""

date : Final[Field] = Field(
    name='date',
    origin='SMF72DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S5`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S5`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF72TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S5`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S5`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF72DTE`), `time`(`SMF72TME`)
    Record: `SMF72S5`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF72DTE`), `time`(`SMF72TME`)
    Record: `SMF72S5`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF72LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF72LEN`
    Record: `SMF72S5`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF72LEN`
    Record: `SMF72S5`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF72SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF72SEG`
    Record: `SMF72S5`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF72SEG`
    Record: `SMF72S5`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF72FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF72FLG`
    Record: `SMF72S5`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF72FLG`
    Record: `SMF72S5`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

new_record : Final[Field] = Field(
    name='new_record',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
new_record.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

subtypes_used : Final[Field] = Field(
    name='subtypes_used',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
subtypes_used.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF72FLG`)
    Record: `SMF72S5`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF72RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF72RTY`
    Record: `SMF72S5`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF72RTY`
    Record: `SMF72S5`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF72TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S5`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF72TME`
    Record: `SMF72S5`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF72DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S5`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF72DTE`
    Record: `SMF72S5`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF72SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF72SID`
    Record: `SMF72S5`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF72SID`
    Record: `SMF72S5`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF72SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF72SSI`
    Record: `SMF72S5`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF72SSI`
    Record: `SMF72S5`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF72STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF72STY`
    Record: `SMF72S5`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF72STY`
    Record: `SMF72S5`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF72TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF72TRN`
    Record: `SMF72S5`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF72TRN`
    Record: `SMF72S5`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF72PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRS`
    Record: `SMF72S5`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRS`
    Record: `SMF72S5`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF72PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRL`
    Record: `SMF72S5`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF72PRL`
    Record: `SMF72S5`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF72PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF72PRN`
    Record: `SMF72S5`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF72PRN`
    Record: `SMF72S5`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

ses : Final[Field] = Field(
    name='ses',
    origin='SMF72SES',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to serialization control section (subtype5)

SMF Info
--------
    Field: `SMF72SES`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to serialization control section (subtype5)
"""
ses.__doc__ = """Offset to serialization control section (subtype5)

SMF Info
--------
    Field: `SMF72SES`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to serialization control section (subtype5)
"""

sel : Final[Field] = Field(
    name='sel',
    origin='SMF72SEL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of serialization control section (subtype5)

SMF Info
--------
    Field: `SMF72SEL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of serialization control section (subtype5)
"""
sel.__doc__ = """Length of serialization control section (subtype5)

SMF Info
--------
    Field: `SMF72SEL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of serialization control section (subtype5)
"""

sen : Final[Field] = Field(
    name='sen',
    origin='SMF72SEN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of serialization control section (subtype5)

SMF Info
--------
    Field: `SMF72SEN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of serialization control section (subtype5)
"""
sen.__doc__ = """Number of serialization control section (subtype5)

SMF Info
--------
    Field: `SMF72SEN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of serialization control section (subtype5)
"""

cms : Final[Field] = Field(
    name='cms',
    origin='SMF72CMS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CMS lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72CMS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CMS lock data section (subtype 5)
"""
cms.__doc__ = """Offset to CMS lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72CMS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CMS lock data section (subtype 5)
"""

cml : Final[Field] = Field(
    name='cml',
    origin='SMF72CML',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CMS lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72CML`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CMS lock data section (subtype 5)
"""
cml.__doc__ = """Length of CMS lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72CML`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CMS lock data section (subtype 5)
"""

cmn : Final[Field] = Field(
    name='cmn',
    origin='SMF72CMN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CMS lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72CMN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CMS lock data sections (subtype 5)
"""
cmn.__doc__ = """Number of CMS lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72CMN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CMS lock data sections (subtype 5)
"""

eds : Final[Field] = Field(
    name='eds',
    origin='SMF72EDS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CMS EnqueueDequeue lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72EDS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CMS EnqueueDequeue lock data section (subtype 5)
"""
eds.__doc__ = """Offset to CMS EnqueueDequeue lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72EDS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CMS EnqueueDequeue lock data section (subtype 5)
"""

edl : Final[Field] = Field(
    name='edl',
    origin='SMF72EDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CMS EnqueueDequeue lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72EDL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CMS EnqueueDequeue lock data section (subtype 5)
"""
edl.__doc__ = """Length of CMS EnqueueDequeue lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72EDL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CMS EnqueueDequeue lock data section (subtype 5)
"""

edn : Final[Field] = Field(
    name='edn',
    origin='SMF72EDN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CMS EnqueueDequeue lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72EDN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CMS EnqueueDequeue lock data sections (subtype 5)
"""
edn.__doc__ = """Number of CMS EnqueueDequeue lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72EDN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CMS EnqueueDequeue lock data sections (subtype 5)
"""

las : Final[Field] = Field(
    name='las',
    origin='SMF72LAS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CMS Latch lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72LAS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CMS Latch lock data section (subtype 5)
"""
las.__doc__ = """Offset to CMS Latch lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72LAS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CMS Latch lock data section (subtype 5)
"""

lal : Final[Field] = Field(
    name='lal',
    origin='SMF72LAL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CMS Latch lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72LAL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CMS Latch lock data section (subtype 5)
"""
lal.__doc__ = """Length of CMS Latch lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72LAL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CMS Latch lock data section (subtype 5)
"""

lan : Final[Field] = Field(
    name='lan',
    origin='SMF72LAN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CMS Latch lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72LAN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CMS Latch lock data sections (subtype 5)
"""
lan.__doc__ = """Number of CMS Latch lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72LAN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CMS Latch lock data sections (subtype 5)
"""

sms : Final[Field] = Field(
    name='sms',
    origin='SMF72SMS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CMS SMF lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72SMS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CMS SMF lock data section (subtype 5)
"""
sms.__doc__ = """Offset to CMS SMF lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72SMS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CMS SMF lock data section (subtype 5)
"""

sml : Final[Field] = Field(
    name='sml',
    origin='SMF72SML',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CMS SMF lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72SML`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CMS SMF lock data section (subtype 5)
"""
sml.__doc__ = """Length of CMS SMF lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72SML`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CMS SMF lock data section (subtype 5)
"""

smn : Final[Field] = Field(
    name='smn',
    origin='SMF72SMN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CMS SMF lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72SMN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CMS SMF lock data sections (subtype 5)
"""
smn.__doc__ = """Number of CMS SMF lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72SMN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CMS SMF lock data sections (subtype 5)
"""

los : Final[Field] = Field(
    name='los',
    origin='SMF72LOS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Local lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72LOS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to Local lock data section (subtype 5)
"""
los.__doc__ = """Offset to Local lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72LOS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to Local lock data section (subtype 5)
"""

lol : Final[Field] = Field(
    name='lol',
    origin='SMF72LOL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Local lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72LOL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of Local lock data section (subtype 5)
"""
lol.__doc__ = """Length of Local lock data section (subtype 5)

SMF Info
--------
    Field: `SMF72LOL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of Local lock data section (subtype 5)
"""

lon : Final[Field] = Field(
    name='lon',
    origin='SMF72LON',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Local lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72LON`
    Record: `SMF72S5`
    Map: Not part of a map

Number of Local lock data sections (subtype 5)
"""
lon.__doc__ = """Number of Local lock data sections (subtype 5)

SMF Info
--------
    Field: `SMF72LON`
    Record: `SMF72S5`
    Map: Not part of a map

Number of Local lock data sections (subtype 5)
"""

cos : Final[Field] = Field(
    name='cos',
    origin='SMF72COS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CML Lock Owner data section (subtype 5)

SMF Info
--------
    Field: `SMF72COS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CML Lock Owner data section (subtype 5)
"""
cos.__doc__ = """Offset to CML Lock Owner data section (subtype 5)

SMF Info
--------
    Field: `SMF72COS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CML Lock Owner data section (subtype 5)
"""

col : Final[Field] = Field(
    name='col',
    origin='SMF72COL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CML Lock Owner data section (subtype 5)

SMF Info
--------
    Field: `SMF72COL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CML Lock Owner data section (subtype 5)
"""
col.__doc__ = """Length of CML Lock Owner data section (subtype 5)

SMF Info
--------
    Field: `SMF72COL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CML Lock Owner data section (subtype 5)
"""

con : Final[Field] = Field(
    name='con',
    origin='SMF72CON',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CML Lock Owner data sections (subtype 5)

SMF Info
--------
    Field: `SMF72CON`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CML Lock Owner data sections (subtype 5)
"""
con.__doc__ = """Number of CML Lock Owner data sections (subtype 5)

SMF Info
--------
    Field: `SMF72CON`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CML Lock Owner data sections (subtype 5)
"""

crs : Final[Field] = Field(
    name='crs',
    origin='SMF72CRS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to CML Lock Requestor data section (subtype 5)

SMF Info
--------
    Field: `SMF72CRS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CML Lock Requestor data section (subtype 5)
"""
crs.__doc__ = """Offset to CML Lock Requestor data section (subtype 5)

SMF Info
--------
    Field: `SMF72CRS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to CML Lock Requestor data section (subtype 5)
"""

crl : Final[Field] = Field(
    name='crl',
    origin='SMF72CRL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of CML Lock Requestor data section (subtype 5)

SMF Info
--------
    Field: `SMF72CRL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CML Lock Requestor data section (subtype 5)
"""
crl.__doc__ = """Length of CML Lock Requestor data section (subtype 5)

SMF Info
--------
    Field: `SMF72CRL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of CML Lock Requestor data section (subtype 5)
"""

crn : Final[Field] = Field(
    name='crn',
    origin='SMF72CRN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of CML Lock Requestor data sections (subtype 5)

SMF Info
--------
    Field: `SMF72CRN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CML Lock Requestor data sections (subtype 5)
"""
crn.__doc__ = """Number of CML Lock Requestor data sections (subtype 5)

SMF Info
--------
    Field: `SMF72CRN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of CML Lock Requestor data sections (subtype 5)
"""

lcs : Final[Field] = Field(
    name='lcs',
    origin='SMF72LCS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Latch Creator data section (subtype 5)

SMF Info
--------
    Field: `SMF72LCS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to Latch Creator data section (subtype 5)
"""
lcs.__doc__ = """Offset to Latch Creator data section (subtype 5)

SMF Info
--------
    Field: `SMF72LCS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to Latch Creator data section (subtype 5)
"""

lcl : Final[Field] = Field(
    name='lcl',
    origin='SMF72LCL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Latch Creator data section (subtype 5)

SMF Info
--------
    Field: `SMF72LCL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of Latch Creator data section (subtype 5)
"""
lcl.__doc__ = """Length of Latch Creator data section (subtype 5)

SMF Info
--------
    Field: `SMF72LCL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of Latch Creator data section (subtype 5)
"""

lcn : Final[Field] = Field(
    name='lcn',
    origin='SMF72LCN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Latch Creator data sections (subtype 5)

SMF Info
--------
    Field: `SMF72LCN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of Latch Creator data sections (subtype 5)
"""
lcn.__doc__ = """Number of Latch Creator data sections (subtype 5)

SMF Info
--------
    Field: `SMF72LCN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of Latch Creator data sections (subtype 5)
"""

lrs : Final[Field] = Field(
    name='lrs',
    origin='SMF72LRS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Latch Requestor data section (subtype 5)

SMF Info
--------
    Field: `SMF72LRS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to Latch Requestor data section (subtype 5)
"""
lrs.__doc__ = """Offset to Latch Requestor data section (subtype 5)

SMF Info
--------
    Field: `SMF72LRS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to Latch Requestor data section (subtype 5)
"""

lrl : Final[Field] = Field(
    name='lrl',
    origin='SMF72LRL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Latch Requestor data section (subtype 5)

SMF Info
--------
    Field: `SMF72LRL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of Latch Requestor data section (subtype 5)
"""
lrl.__doc__ = """Length of Latch Requestor data section (subtype 5)

SMF Info
--------
    Field: `SMF72LRL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of Latch Requestor data section (subtype 5)
"""

lrn : Final[Field] = Field(
    name='lrn',
    origin='SMF72LRN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Latch Requestor data sections (subtype 5)

SMF Info
--------
    Field: `SMF72LRN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of Latch Requestor data sections (subtype 5)
"""
lrn.__doc__ = """Number of Latch Requestor data sections (subtype 5)

SMF Info
--------
    Field: `SMF72LRN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of Latch Requestor data sections (subtype 5)
"""

tds : Final[Field] = Field(
    name='tds',
    origin='SMF72TDS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to ENQ SCOPE=STEP data section (subtype 5)

SMF Info
--------
    Field: `SMF72TDS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to ENQ SCOPE=STEP data section (subtype 5)
"""
tds.__doc__ = """Offset to ENQ SCOPE=STEP data section (subtype 5)

SMF Info
--------
    Field: `SMF72TDS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to ENQ SCOPE=STEP data section (subtype 5)
"""

tdl : Final[Field] = Field(
    name='tdl',
    origin='SMF72TDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of ENQ SCOPE=STEP data section (subtype 5)

SMF Info
--------
    Field: `SMF72TDL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of ENQ SCOPE=STEP data section (subtype 5)
"""
tdl.__doc__ = """Length of ENQ SCOPE=STEP data section (subtype 5)

SMF Info
--------
    Field: `SMF72TDL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of ENQ SCOPE=STEP data section (subtype 5)
"""

tdn : Final[Field] = Field(
    name='tdn',
    origin='SMF72TDN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of ENQ SCOPE=STEP data sections (subtype 5)

SMF Info
--------
    Field: `SMF72TDN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of ENQ SCOPE=STEP data sections (subtype 5)
"""
tdn.__doc__ = """Number of ENQ SCOPE=STEP data sections (subtype 5)

SMF Info
--------
    Field: `SMF72TDN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of ENQ SCOPE=STEP data sections (subtype 5)
"""

yds : Final[Field] = Field(
    name='yds',
    origin='SMF72YDS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to ENQ SCOPE=SYSTEM data section (subtype 5)

SMF Info
--------
    Field: `SMF72YDS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to ENQ SCOPE=SYSTEM data section (subtype 5)
"""
yds.__doc__ = """Offset to ENQ SCOPE=SYSTEM data section (subtype 5)

SMF Info
--------
    Field: `SMF72YDS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to ENQ SCOPE=SYSTEM data section (subtype 5)
"""

ydl : Final[Field] = Field(
    name='ydl',
    origin='SMF72YDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of ENQ SCOPE=SYSTEM data section (subtype 5)

SMF Info
--------
    Field: `SMF72YDL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of ENQ SCOPE=SYSTEM data section (subtype 5)
"""
ydl.__doc__ = """Length of ENQ SCOPE=SYSTEM data section (subtype 5)

SMF Info
--------
    Field: `SMF72YDL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of ENQ SCOPE=SYSTEM data section (subtype 5)
"""

ydn : Final[Field] = Field(
    name='ydn',
    origin='SMF72YDN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of ENQ SCOPE=SYSTEM data sections (subtype 5)

SMF Info
--------
    Field: `SMF72YDN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of ENQ SCOPE=SYSTEM data sections (subtype 5)
"""
ydn.__doc__ = """Number of ENQ SCOPE=SYSTEM data sections (subtype 5)

SMF Info
--------
    Field: `SMF72YDN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of ENQ SCOPE=SYSTEM data sections (subtype 5)
"""

sds : Final[Field] = Field(
    name='sds',
    origin='SMF72SDS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to ENQ SCOPE=SYSTEMS data section (subtype 5)

SMF Info
--------
    Field: `SMF72SDS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to ENQ SCOPE=SYSTEMS data section (subtype 5)
"""
sds.__doc__ = """Offset to ENQ SCOPE=SYSTEMS data section (subtype 5)

SMF Info
--------
    Field: `SMF72SDS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to ENQ SCOPE=SYSTEMS data section (subtype 5)
"""

sdl : Final[Field] = Field(
    name='sdl',
    origin='SMF72SDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of ENQ SCOPE=SYSTEMS data section (subtype 5)

SMF Info
--------
    Field: `SMF72SDL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of ENQ SCOPE=SYSTEMS data section (subtype 5)
"""
sdl.__doc__ = """Length of ENQ SCOPE=SYSTEMS data section (subtype 5)

SMF Info
--------
    Field: `SMF72SDL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of ENQ SCOPE=SYSTEMS data section (subtype 5)
"""

sdn : Final[Field] = Field(
    name='sdn',
    origin='SMF72SDN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of ENQ SCOPE=SYSTEMS data sections (subtype 5)

SMF Info
--------
    Field: `SMF72SDN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of ENQ SCOPE=SYSTEMS data sections (subtype 5)
"""
sdn.__doc__ = """Number of ENQ SCOPE=SYSTEMS data sections (subtype 5)

SMF Info
--------
    Field: `SMF72SDN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of ENQ SCOPE=SYSTEMS data sections (subtype 5)
"""

qss : Final[Field] = Field(
    name='qss',
    origin='SMF72QSS',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to GRS QScan data section (subtype 5)

SMF Info
--------
    Field: `SMF72QSS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to GRS QScan data section (subtype 5)
"""
qss.__doc__ = """Offset to GRS QScan data section (subtype 5)

SMF Info
--------
    Field: `SMF72QSS`
    Record: `SMF72S5`
    Map: Not part of a map

Offset to GRS QScan data section (subtype 5)
"""

qsl : Final[Field] = Field(
    name='qsl',
    origin='SMF72QSL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of GRS QScan data section (subtype 5)

SMF Info
--------
    Field: `SMF72QSL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of GRS QScan data section (subtype 5)
"""
qsl.__doc__ = """Length of GRS QScan data section (subtype 5)

SMF Info
--------
    Field: `SMF72QSL`
    Record: `SMF72S5`
    Map: Not part of a map

Length of GRS QScan data section (subtype 5)
"""

qsn : Final[Field] = Field(
    name='qsn',
    origin='SMF72QSN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of GRS QScan data sections (subtype 5)

SMF Info
--------
    Field: `SMF72QSN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of GRS QScan data sections (subtype 5)
"""
qsn.__doc__ = """Number of GRS QScan data sections (subtype 5)

SMF Info
--------
    Field: `SMF72QSN`
    Record: `SMF72S5`
    Map: Not part of a map

Number of GRS QScan data sections (subtype 5)
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF72MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF72MFV`
    Record: `SMF72S5`
    Map: `SMF72PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF72MFV`
    Record: `SMF72S5`
    Map: `SMF72PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF72PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF72PRD`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF72PRD`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF72IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF72PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF72IST`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF72IST`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF72DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF72PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF72DAT`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF72DAT`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Date monitor interval start
"""

interval : Final[Field] = Field(
    name='interval',
    origin='SMF72INT',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF72PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF72INT`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Duration of monitor interval
"""
interval.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF72INT`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF72SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF72SAM`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF72SAM`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF72FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF72FLA`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF72FLA`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF72PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF72FLA`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF72CYC',
    type=FieldType.TIMEDELTA,
    record=record,
    record_map=SMF72PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF72CYC`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF72CYC`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF72MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF72MVS`
    Record: `SMF72S5`
    Map: `SMF72PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF72MVS`
    Record: `SMF72S5`
    Map: `SMF72PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF72IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF72IML`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF72IML`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF72PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF72PRF`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF72PRF`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF72PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF72PRF`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF72PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF72PTN`
    Record: `SMF72S5`
    Map: `SMF72PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF72PTN`
    Record: `SMF72S5`
    Map: `SMF72PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF72SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF72SRL`
    Record: `SMF72S5`
    Map: `SMF72PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF72SRL`
    Record: `SMF72S5`
    Map: `SMF72PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF72IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF72PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF72IET`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF72IET`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF72LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF72LGO`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF72LGO`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF72RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF72RAO`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF72RAO`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF72RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF72RAL`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF72RAL`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF72RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF72RAN`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF72RAN`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF72OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF72OIL`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF72OIL`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF72SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF72SYN`
    Record: `SMF72S5`
    Map: `SMF72PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF72SYN`
    Record: `SMF72S5`
    Map: `SMF72PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF72GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF72PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF72GIE`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF72GIE`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF72XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF72XNM`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF72XNM`
    Record: `SMF72S5`
    Map: `SMF72PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF72SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF72SNM`
    Record: `SMF72S5`
    Map: `SMF72PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF72SNM`
    Record: `SMF72S5`
    Map: `SMF72PRO`

System name for current system as defined in CVTSNAME
"""

interval_in_milliseconds : Final[Field] = Field(
    name='interval_in_milliseconds',
    origin=None,
    post="core.inline",
    post_param=__interval_in_milliseconds_inline_post,
    virtual=True,
    ref=interval,
    record=record,
    record_map=SMF72PRO,
)
"""Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF72INT`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""
interval_in_milliseconds.__doc__ = """Interval duration in milliseconds(V)

SMF Info (Virtual Field)
--------
    Field: Based on `interval`(`SMF72INT`)
    Record: `SMF72S5`
    Map: `SMF72PRO`

Post Processing (`core.inline`)
---------------
The parameter for the post-processor is::

    return df.interval.dt.total_seconds() * 1e3

"""

r725sgmo : Final[Field] = Field(
    name='r725sgmo',
    origin='R725SGMO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""GRS Mode: X'00' = NONE X'01' = RING X'02' = STAR

SMF Info
--------
    Field: `R725SGMO`
    Record: `SMF72S5`
    Map: `R725SCTL`

GRS Mode: X'00' = NONE X'01' = RING X'02' = STAR
"""
r725sgmo.__doc__ = """GRS Mode: X'00' = NONE X'01' = RING X'02' = STAR

SMF Info
--------
    Field: `R725SGMO`
    Record: `SMF72S5`
    Map: `R725SCTL`

GRS Mode: X'00' = NONE X'01' = RING X'02' = STAR
"""

r725scms : Final[Field] = Field(
    name='r725scms',
    origin='R725SCMS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on a CMS lock

SMF Info
--------
    Field: `R725SCMS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS lock
"""
r725scms.__doc__ = """Total number of times that a unit of work was suspended on a CMS lock

SMF Info
--------
    Field: `R725SCMS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS lock
"""

r725scma : Final[Field] = Field(
    name='r725scma',
    origin='R725SCMA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on a CMS lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SCMA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS lock when there was already at least one other unit of work suspended for the lock
"""
r725scma.__doc__ = """Total number of times that a unit of work was suspended on a CMS lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SCMA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS lock when there was already at least one other unit of work suspended for the lock
"""

r725scmt : Final[Field] = Field(
    name='r725scmt',
    origin='R725SCMT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of time in milliseconds that a unit of work was suspended on a CMS lock

SMF Info
--------
    Field: `R725SCMT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a CMS lock
"""
r725scmt.__doc__ = """Total amount of time in milliseconds that a unit of work was suspended on a CMS lock

SMF Info
--------
    Field: `R725SCMT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a CMS lock
"""

r725seds : Final[Field] = Field(
    name='r725seds',
    origin='R725SEDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on a CMS EnqueueDequeue lock

SMF Info
--------
    Field: `R725SEDS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS EnqueueDequeue lock
"""
r725seds.__doc__ = """Total number of times that a unit of work was suspended on a CMS EnqueueDequeue lock

SMF Info
--------
    Field: `R725SEDS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS EnqueueDequeue lock
"""

r725seda : Final[Field] = Field(
    name='r725seda',
    origin='R725SEDA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on CMS EnqueueDequeue lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SEDA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on CMS EnqueueDequeue lock when there was already at least one other unit of work suspended for the lock
"""
r725seda.__doc__ = """Total number of times that a unit of work was suspended on CMS EnqueueDequeue lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SEDA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on CMS EnqueueDequeue lock when there was already at least one other unit of work suspended for the lock
"""

r725sedt : Final[Field] = Field(
    name='r725sedt',
    origin='R725SEDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of time in milliseconds that a unit of work was suspended on a CMS EnqueueDequeue lock

SMF Info
--------
    Field: `R725SEDT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a CMS EnqueueDequeue lock
"""
r725sedt.__doc__ = """Total amount of time in milliseconds that a unit of work was suspended on a CMS EnqueueDequeue lock

SMF Info
--------
    Field: `R725SEDT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a CMS EnqueueDequeue lock
"""

r725slas : Final[Field] = Field(
    name='r725slas',
    origin='R725SLAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on a CMS Latch lock

SMF Info
--------
    Field: `R725SLAS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS Latch lock
"""
r725slas.__doc__ = """Total number of times that a unit of work was suspended on a CMS Latch lock

SMF Info
--------
    Field: `R725SLAS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS Latch lock
"""

r725slaa : Final[Field] = Field(
    name='r725slaa',
    origin='R725SLAA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on CMS Latch lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SLAA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on CMS Latch lock when there was already at least one other unit of work suspended for the lock
"""
r725slaa.__doc__ = """Total number of times that a unit of work was suspended on CMS Latch lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SLAA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on CMS Latch lock when there was already at least one other unit of work suspended for the lock
"""

r725slat : Final[Field] = Field(
    name='r725slat',
    origin='R725SLAT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of time in milliseconds that a unit of work was suspended on a CMS Latch lock

SMF Info
--------
    Field: `R725SLAT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a CMS Latch lock
"""
r725slat.__doc__ = """Total amount of time in milliseconds that a unit of work was suspended on a CMS Latch lock

SMF Info
--------
    Field: `R725SLAT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a CMS Latch lock
"""

r725ssms : Final[Field] = Field(
    name='r725ssms',
    origin='R725SSMS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on a CMS SMF lock

SMF Info
--------
    Field: `R725SSMS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS SMF lock
"""
r725ssms.__doc__ = """Total number of times that a unit of work was suspended on a CMS SMF lock

SMF Info
--------
    Field: `R725SSMS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a CMS SMF lock
"""

r725ssma : Final[Field] = Field(
    name='r725ssma',
    origin='R725SSMA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on CMS SMF lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SSMA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on CMS SMF lock when there was already at least one other unit of work suspended for the lock
"""
r725ssma.__doc__ = """Total number of times that a unit of work was suspended on CMS SMF lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SSMA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on CMS SMF lock when there was already at least one other unit of work suspended for the lock
"""

r725ssmt : Final[Field] = Field(
    name='r725ssmt',
    origin='R725SSMT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of time in milliseconds that a unit of work was suspended on a CMS SMF lock

SMF Info
--------
    Field: `R725SSMT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a CMS SMF lock
"""
r725ssmt.__doc__ = """Total amount of time in milliseconds that a unit of work was suspended on a CMS SMF lock

SMF Info
--------
    Field: `R725SSMT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a CMS SMF lock
"""

r725slos : Final[Field] = Field(
    name='r725slos',
    origin='R725SLOS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on a Local lock

SMF Info
--------
    Field: `R725SLOS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a Local lock
"""
r725slos.__doc__ = """Total number of times that a unit of work was suspended on a Local lock

SMF Info
--------
    Field: `R725SLOS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on a Local lock
"""

r725sloa : Final[Field] = Field(
    name='r725sloa',
    origin='R725SLOA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work was suspended on Local lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SLOA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on Local lock when there was already at least one other unit of work suspended for the lock
"""
r725sloa.__doc__ = """Total number of times that a unit of work was suspended on Local lock when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SLOA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work was suspended on Local lock when there was already at least one other unit of work suspended for the lock
"""

r725slot : Final[Field] = Field(
    name='r725slot',
    origin='R725SLOT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of time in milliseconds that a unit of work was suspended on a Local lock

SMF Info
--------
    Field: `R725SLOT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a Local lock
"""
r725slot.__doc__ = """Total amount of time in milliseconds that a unit of work was suspended on a Local lock

SMF Info
--------
    Field: `R725SLOT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work was suspended on a Local lock
"""

r725scls : Final[Field] = Field(
    name='r725scls',
    origin='R725SCLS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work from another address space was suspended when requesting the Local lock of an address space

SMF Info
--------
    Field: `R725SCLS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work from another address space was suspended when requesting the Local lock of an address space
"""
r725scls.__doc__ = """Total number of times that a unit of work from another address space was suspended when requesting the Local lock of an address space

SMF Info
--------
    Field: `R725SCLS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work from another address space was suspended when requesting the Local lock of an address space
"""

r725scla : Final[Field] = Field(
    name='r725scla',
    origin='R725SCLA',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of times that a unit of work from another address space was suspended when requesting the Local lock of an address space when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SCLA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work from another address space was suspended when requesting the Local lock of an address space when there was already at least one other unit of work suspended for the lock
"""
r725scla.__doc__ = """Total number of times that a unit of work from another address space was suspended when requesting the Local lock of an address space when there was already at least one other unit of work suspended for the lock

SMF Info
--------
    Field: `R725SCLA`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of times that a unit of work from another address space was suspended when requesting the Local lock of an address space when there was already at least one other unit of work suspended for the lock
"""

r725sclt : Final[Field] = Field(
    name='r725sclt',
    origin='R725SCLT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of time in milliseconds that a unit of work from another address space was suspended when requesting the Local lock of an address space

SMF Info
--------
    Field: `R725SCLT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work from another address space was suspended when requesting the Local lock of an address space
"""
r725sclt.__doc__ = """Total amount of time in milliseconds that a unit of work from another address space was suspended when requesting the Local lock of an address space

SMF Info
--------
    Field: `R725SCLT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that a unit of work from another address space was suspended when requesting the Local lock of an address space
"""

r725slrs : Final[Field] = Field(
    name='r725slrs',
    origin='R725SLRS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of suspended Latch Obtain requests

SMF Info
--------
    Field: `R725SLRS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of suspended Latch Obtain requests
"""
r725slrs.__doc__ = """Total number of suspended Latch Obtain requests

SMF Info
--------
    Field: `R725SLRS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of suspended Latch Obtain requests
"""

r725slrt : Final[Field] = Field(
    name='r725slrt',
    origin='R725SLRT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of time in milliseconds that Latch Obtain requests were suspended

SMF Info
--------
    Field: `R725SLRT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that Latch Obtain requests were suspended
"""
r725slrt.__doc__ = """Total amount of time in milliseconds that Latch Obtain requests were suspended

SMF Info
--------
    Field: `R725SLRT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of time in milliseconds that Latch Obtain requests were suspended
"""

r725slrq : Final[Field] = Field(
    name='r725slrq',
    origin='R725SLRQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total sum of squares of time in milliseconds that Latch Obtain requests were suspended

SMF Info
--------
    Field: `R725SLRQ`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total sum of squares of time in milliseconds that Latch Obtain requests were suspended
"""
r725slrq.__doc__ = """Total sum of squares of time in milliseconds that Latch Obtain requests were suspended

SMF Info
--------
    Field: `R725SLRQ`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total sum of squares of time in milliseconds that Latch Obtain requests were suspended
"""

r725sstr : Final[Field] = Field(
    name='r725sstr',
    origin='R725SSTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of ENQ SCOPE=STEP requests

SMF Info
--------
    Field: `R725SSTR`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=STEP requests
"""
r725sstr.__doc__ = """Total number of ENQ SCOPE=STEP requests

SMF Info
--------
    Field: `R725SSTR`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=STEP requests
"""

r725ssts : Final[Field] = Field(
    name='r725ssts',
    origin='R725SSTS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of ENQ SCOPE=STEP requests that were suspended

SMF Info
--------
    Field: `R725SSTS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=STEP requests that were suspended
"""
r725ssts.__doc__ = """Total number of ENQ SCOPE=STEP requests that were suspended

SMF Info
--------
    Field: `R725SSTS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=STEP requests that were suspended
"""

r725sstt : Final[Field] = Field(
    name='r725sstt',
    origin='R725SSTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of contention time in milliseconds caused by ENQ SCOPE=STEP requests

SMF Info
--------
    Field: `R725SSTT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of contention time in milliseconds caused by ENQ SCOPE=STEP requests
"""
r725sstt.__doc__ = """Total amount of contention time in milliseconds caused by ENQ SCOPE=STEP requests

SMF Info
--------
    Field: `R725SSTT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of contention time in milliseconds caused by ENQ SCOPE=STEP requests
"""

r725sstq : Final[Field] = Field(
    name='r725sstq',
    origin='R725SSTQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total sum of squares of contention time in milliseconds caused by ENQ SCOPE=STEP requests

SMF Info
--------
    Field: `R725SSTQ`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total sum of squares of contention time in milliseconds caused by ENQ SCOPE=STEP requests
"""
r725sstq.__doc__ = """Total sum of squares of contention time in milliseconds caused by ENQ SCOPE=STEP requests

SMF Info
--------
    Field: `R725SSTQ`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total sum of squares of contention time in milliseconds caused by ENQ SCOPE=STEP requests
"""

r725ssyr : Final[Field] = Field(
    name='r725ssyr',
    origin='R725SSYR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of ENQ SCOPE=SYSTEM requests

SMF Info
--------
    Field: `R725SSYR`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=SYSTEM requests
"""
r725ssyr.__doc__ = """Total number of ENQ SCOPE=SYSTEM requests

SMF Info
--------
    Field: `R725SSYR`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=SYSTEM requests
"""

r725ssys : Final[Field] = Field(
    name='r725ssys',
    origin='R725SSYS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of ENQ SCOPE=SYSTEM requests that were suspended

SMF Info
--------
    Field: `R725SSYS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=SYSTEM requests that were suspended
"""
r725ssys.__doc__ = """Total number of ENQ SCOPE=SYSTEM requests that were suspended

SMF Info
--------
    Field: `R725SSYS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=SYSTEM requests that were suspended
"""

r725ssyt : Final[Field] = Field(
    name='r725ssyt',
    origin='R725SSYT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of contention time in milliseconds caused by ENQ SCOPE=SYSTEM requests

SMF Info
--------
    Field: `R725SSYT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of contention time in milliseconds caused by ENQ SCOPE=SYSTEM requests
"""
r725ssyt.__doc__ = """Total amount of contention time in milliseconds caused by ENQ SCOPE=SYSTEM requests

SMF Info
--------
    Field: `R725SSYT`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of contention time in milliseconds caused by ENQ SCOPE=SYSTEM requests
"""

r725ssyq : Final[Field] = Field(
    name='r725ssyq',
    origin='R725SSYQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total sum of squares of suspend contention time in milliseconds caused by ENQ SCOPE=SYSTEM requests

SMF Info
--------
    Field: `R725SSYQ`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total sum of squares of suspend contention time in milliseconds caused by ENQ SCOPE=SYSTEM requests
"""
r725ssyq.__doc__ = """Total sum of squares of suspend contention time in milliseconds caused by ENQ SCOPE=SYSTEM requests

SMF Info
--------
    Field: `R725SSYQ`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total sum of squares of suspend contention time in milliseconds caused by ENQ SCOPE=SYSTEM requests
"""

r725sssr : Final[Field] = Field(
    name='r725sssr',
    origin='R725SSSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of ENQ SCOPE=SYSTEMS requests

SMF Info
--------
    Field: `R725SSSR`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=SYSTEMS requests
"""
r725sssr.__doc__ = """Total number of ENQ SCOPE=SYSTEMS requests

SMF Info
--------
    Field: `R725SSSR`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=SYSTEMS requests
"""

r725ssss : Final[Field] = Field(
    name='r725ssss',
    origin='R725SSSS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total number of ENQ SCOPE=SYSTEMS requests that were suspended

SMF Info
--------
    Field: `R725SSSS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=SYSTEMS requests that were suspended
"""
r725ssss.__doc__ = """Total number of ENQ SCOPE=SYSTEMS requests that were suspended

SMF Info
--------
    Field: `R725SSSS`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total number of ENQ SCOPE=SYSTEMS requests that were suspended
"""

r725ssst : Final[Field] = Field(
    name='r725ssst',
    origin='R725SSST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total amount of contention time in milliseconds caused by ENQ SCOPE=SYSTEMS requests

SMF Info
--------
    Field: `R725SSST`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of contention time in milliseconds caused by ENQ SCOPE=SYSTEMS requests
"""
r725ssst.__doc__ = """Total amount of contention time in milliseconds caused by ENQ SCOPE=SYSTEMS requests

SMF Info
--------
    Field: `R725SSST`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total amount of contention time in milliseconds caused by ENQ SCOPE=SYSTEMS requests
"""

r725sssq : Final[Field] = Field(
    name='r725sssq',
    origin='R725SSSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725SCTL,
)
"""Total sum of squares of contention time in milliseconds caused by ENQ SCOPE=SYSTEMS requests

SMF Info
--------
    Field: `R725SSSQ`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total sum of squares of contention time in milliseconds caused by ENQ SCOPE=SYSTEMS requests
"""
r725sssq.__doc__ = """Total sum of squares of contention time in milliseconds caused by ENQ SCOPE=SYSTEMS requests

SMF Info
--------
    Field: `R725SSSQ`
    Record: `SMF72S5`
    Map: `R725SCTL`

Total sum of squares of contention time in milliseconds caused by ENQ SCOPE=SYSTEMS requests
"""

r725cmjn_CmsLockData : Final[Field] = Field(
    name='r725cmjn_CmsLockData',
    origin='R725CMJN',
    type=FieldType.STRING,
    record=record,
    record_map=R725CMSD,
)
"""Name of job

SMF Info
--------
    Field: `R725CMJN`
    Record: `SMF72S5`
    Map: `R725CMSD`

Name of job
"""
r725cmjn_CmsLockData.__doc__ = """Name of job

SMF Info
--------
    Field: `R725CMJN`
    Record: `SMF72S5`
    Map: `R725CMSD`

Name of job
"""

r725cmsp_CmsLockData : Final[Field] = Field(
    name='r725cmsp_CmsLockData',
    origin='R725CMSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CMSD,
)
"""Service class period

SMF Info
--------
    Field: `R725CMSP`
    Record: `SMF72S5`
    Map: `R725CMSD`

Service class period
"""
r725cmsp_CmsLockData.__doc__ = """Service class period

SMF Info
--------
    Field: `R725CMSP`
    Record: `SMF72S5`
    Map: `R725CMSD`

Service class period
"""

r725cmas_CmsLockData : Final[Field] = Field(
    name='r725cmas_CmsLockData',
    origin='R725CMAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CMSD,
)
"""Address space ID

SMF Info
--------
    Field: `R725CMAS`
    Record: `SMF72S5`
    Map: `R725CMSD`

Address space ID
"""
r725cmas_CmsLockData.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725CMAS`
    Record: `SMF72S5`
    Map: `R725CMSD`

Address space ID
"""

r725cmst_CmsLockData : Final[Field] = Field(
    name='r725cmst_CmsLockData',
    origin='R725CMST',
    type=FieldType.STRING,
    record=record,
    record_map=R725CMSD,
)
"""Address space SToken

SMF Info
--------
    Field: `R725CMST`
    Record: `SMF72S5`
    Map: `R725CMSD`

Address space SToken
"""
r725cmst_CmsLockData.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725CMST`
    Record: `SMF72S5`
    Map: `R725CMSD`

Address space SToken
"""

r725cmsn_CmsLockData : Final[Field] = Field(
    name='r725cmsn_CmsLockData',
    origin='R725CMSN',
    type=FieldType.STRING,
    record=record,
    record_map=R725CMSD,
)
"""Service class name

SMF Info
--------
    Field: `R725CMSN`
    Record: `SMF72S5`
    Map: `R725CMSD`

Service class name
"""
r725cmsn_CmsLockData.__doc__ = """Service class name

SMF Info
--------
    Field: `R725CMSN`
    Record: `SMF72S5`
    Map: `R725CMSD`

Service class name
"""

r725cmty_CmsLockData : Final[Field] = Field(
    name='r725cmty_CmsLockData',
    origin='R725CMTY',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CMSD,
)
"""Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock

SMF Info
--------
    Field: `R725CMTY`
    Record: `SMF72S5`
    Map: `R725CMSD`

Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock
"""
r725cmty_CmsLockData.__doc__ = """Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock

SMF Info
--------
    Field: `R725CMTY`
    Record: `SMF72S5`
    Map: `R725CMSD`

Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock
"""

r725cmsu_CmsLockData : Final[Field] = Field(
    name='r725cmsu_CmsLockData',
    origin='R725CMSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CMSD,
)
"""Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMSU`
    Record: `SMF72S5`
    Map: `R725CMSD`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""
r725cmsu_CmsLockData.__doc__ = """Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMSU`
    Record: `SMF72S5`
    Map: `R725CMSD`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""

r725cmal_CmsLockData : Final[Field] = Field(
    name='r725cmal_CmsLockData',
    origin='R725CMAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CMSD,
)
"""Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock

SMF Info
--------
    Field: `R725CMAL`
    Record: `SMF72S5`
    Map: `R725CMSD`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock
"""
r725cmal_CmsLockData.__doc__ = """Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock

SMF Info
--------
    Field: `R725CMAL`
    Record: `SMF72S5`
    Map: `R725CMSD`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock
"""

r725cmti_CmsLockData : Final[Field] = Field(
    name='r725cmti_CmsLockData',
    origin='R725CMTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CMSD,
)
"""Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMTI`
    Record: `SMF72S5`
    Map: `R725CMSD`

Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""
r725cmti_CmsLockData.__doc__ = """Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMTI`
    Record: `SMF72S5`
    Map: `R725CMSD`

Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""

r725cm_entry_index_CmsLockData : Final[Field] = Field(
    name='r725cm_entry_index_CmsLockData',
    origin='R725CM_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CMSD,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725CM_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725CMSD`

Artificial Entry Index
"""
r725cm_entry_index_CmsLockData.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725CM_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725CMSD`

Artificial Entry Index
"""

r725cm_service_class_list_index_CmsLockData : Final[Field] = Field(
    name='r725cm_service_class_list_index_CmsLockData',
    origin='R725CM_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CMSD,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CM_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725CMSD`

Service class list index (See ASICLX in ERBASIG3)
"""
r725cm_service_class_list_index_CmsLockData.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CM_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725CMSD`

Service class list index (See ASICLX in ERBASIG3)
"""

r725cm_asi_flag_CmsLockData : Final[Field] = Field(
    name='r725cm_asi_flag_CmsLockData',
    origin='R725CM_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=R725CMSD,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CM_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725CMSD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725cm_asi_flag_CmsLockData.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CM_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725CMSD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725cmjn_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cmjn_CmsEnqDeqLockData',
    origin='R725CMJN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Name of job

SMF Info
--------
    Field: `R725CMJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Name of job
"""
r725cmjn_CmsEnqDeqLockData.__doc__ = """Name of job

SMF Info
--------
    Field: `R725CMJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Name of job
"""

r725cmsp_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cmsp_CmsEnqDeqLockData',
    origin='R725CMSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Service class period

SMF Info
--------
    Field: `R725CMSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Service class period
"""
r725cmsp_CmsEnqDeqLockData.__doc__ = """Service class period

SMF Info
--------
    Field: `R725CMSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Service class period
"""

r725cmas_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cmas_CmsEnqDeqLockData',
    origin='R725CMAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Address space ID

SMF Info
--------
    Field: `R725CMAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Address space ID
"""
r725cmas_CmsEnqDeqLockData.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725CMAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Address space ID
"""

r725cmst_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cmst_CmsEnqDeqLockData',
    origin='R725CMST',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Address space SToken

SMF Info
--------
    Field: `R725CMST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Address space SToken
"""
r725cmst_CmsEnqDeqLockData.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725CMST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Address space SToken
"""

r725cmsn_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cmsn_CmsEnqDeqLockData',
    origin='R725CMSN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Service class name

SMF Info
--------
    Field: `R725CMSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Service class name
"""
r725cmsn_CmsEnqDeqLockData.__doc__ = """Service class name

SMF Info
--------
    Field: `R725CMSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Service class name
"""

r725cmty_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cmty_CmsEnqDeqLockData',
    origin='R725CMTY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock

SMF Info
--------
    Field: `R725CMTY`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock
"""
r725cmty_CmsEnqDeqLockData.__doc__ = """Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock

SMF Info
--------
    Field: `R725CMTY`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock
"""

r725cmsu_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cmsu_CmsEnqDeqLockData',
    origin='R725CMSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""
r725cmsu_CmsEnqDeqLockData.__doc__ = """Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""

r725cmal_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cmal_CmsEnqDeqLockData',
    origin='R725CMAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock

SMF Info
--------
    Field: `R725CMAL`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock
"""
r725cmal_CmsEnqDeqLockData.__doc__ = """Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock

SMF Info
--------
    Field: `R725CMAL`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock
"""

r725cmti_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cmti_CmsEnqDeqLockData',
    origin='R725CMTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""
r725cmti_CmsEnqDeqLockData.__doc__ = """Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""

r725cm_entry_index_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cm_entry_index_CmsEnqDeqLockData',
    origin='R725CM_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725CM_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Artificial Entry Index
"""
r725cm_entry_index_CmsEnqDeqLockData.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725CM_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Artificial Entry Index
"""

r725cm_service_class_list_index_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cm_service_class_list_index_CmsEnqDeqLockData',
    origin='R725CM_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CM_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""
r725cm_service_class_list_index_CmsEnqDeqLockData.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CM_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""

r725cm_asi_flag_CmsEnqDeqLockData : Final[Field] = Field(
    name='r725cm_asi_flag_CmsEnqDeqLockData',
    origin='R725CM_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CM_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725cm_asi_flag_CmsEnqDeqLockData.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CM_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_ENQ_DEQ_LOCK_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725cmjn_CmsLatchLockData : Final[Field] = Field(
    name='r725cmjn_CmsLatchLockData',
    origin='R725CMJN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Name of job

SMF Info
--------
    Field: `R725CMJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Name of job
"""
r725cmjn_CmsLatchLockData.__doc__ = """Name of job

SMF Info
--------
    Field: `R725CMJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Name of job
"""

r725cmsp_CmsLatchLockData : Final[Field] = Field(
    name='r725cmsp_CmsLatchLockData',
    origin='R725CMSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Service class period

SMF Info
--------
    Field: `R725CMSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Service class period
"""
r725cmsp_CmsLatchLockData.__doc__ = """Service class period

SMF Info
--------
    Field: `R725CMSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Service class period
"""

r725cmas_CmsLatchLockData : Final[Field] = Field(
    name='r725cmas_CmsLatchLockData',
    origin='R725CMAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Address space ID

SMF Info
--------
    Field: `R725CMAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Address space ID
"""
r725cmas_CmsLatchLockData.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725CMAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Address space ID
"""

r725cmst_CmsLatchLockData : Final[Field] = Field(
    name='r725cmst_CmsLatchLockData',
    origin='R725CMST',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Address space SToken

SMF Info
--------
    Field: `R725CMST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Address space SToken
"""
r725cmst_CmsLatchLockData.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725CMST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Address space SToken
"""

r725cmsn_CmsLatchLockData : Final[Field] = Field(
    name='r725cmsn_CmsLatchLockData',
    origin='R725CMSN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Service class name

SMF Info
--------
    Field: `R725CMSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Service class name
"""
r725cmsn_CmsLatchLockData.__doc__ = """Service class name

SMF Info
--------
    Field: `R725CMSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Service class name
"""

r725cmty_CmsLatchLockData : Final[Field] = Field(
    name='r725cmty_CmsLatchLockData',
    origin='R725CMTY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock

SMF Info
--------
    Field: `R725CMTY`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock
"""
r725cmty_CmsLatchLockData.__doc__ = """Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock

SMF Info
--------
    Field: `R725CMTY`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock
"""

r725cmsu_CmsLatchLockData : Final[Field] = Field(
    name='r725cmsu_CmsLatchLockData',
    origin='R725CMSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""
r725cmsu_CmsLatchLockData.__doc__ = """Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""

r725cmal_CmsLatchLockData : Final[Field] = Field(
    name='r725cmal_CmsLatchLockData',
    origin='R725CMAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock

SMF Info
--------
    Field: `R725CMAL`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock
"""
r725cmal_CmsLatchLockData.__doc__ = """Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock

SMF Info
--------
    Field: `R725CMAL`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock
"""

r725cmti_CmsLatchLockData : Final[Field] = Field(
    name='r725cmti_CmsLatchLockData',
    origin='R725CMTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""
r725cmti_CmsLatchLockData.__doc__ = """Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""

r725cm_entry_index_CmsLatchLockData : Final[Field] = Field(
    name='r725cm_entry_index_CmsLatchLockData',
    origin='R725CM_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725CM_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Artificial Entry Index
"""
r725cm_entry_index_CmsLatchLockData.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725CM_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Artificial Entry Index
"""

r725cm_service_class_list_index_CmsLatchLockData : Final[Field] = Field(
    name='r725cm_service_class_list_index_CmsLatchLockData',
    origin='R725CM_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CM_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""
r725cm_service_class_list_index_CmsLatchLockData.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CM_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""

r725cm_asi_flag_CmsLatchLockData : Final[Field] = Field(
    name='r725cm_asi_flag_CmsLatchLockData',
    origin='R725CM_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CM_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725cm_asi_flag_CmsLatchLockData.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CM_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_LATCH_LOCK_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725cmjn_CmsSmfLockData : Final[Field] = Field(
    name='r725cmjn_CmsSmfLockData',
    origin='R725CMJN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Name of job

SMF Info
--------
    Field: `R725CMJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Name of job
"""
r725cmjn_CmsSmfLockData.__doc__ = """Name of job

SMF Info
--------
    Field: `R725CMJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Name of job
"""

r725cmsp_CmsSmfLockData : Final[Field] = Field(
    name='r725cmsp_CmsSmfLockData',
    origin='R725CMSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Service class period

SMF Info
--------
    Field: `R725CMSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Service class period
"""
r725cmsp_CmsSmfLockData.__doc__ = """Service class period

SMF Info
--------
    Field: `R725CMSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Service class period
"""

r725cmas_CmsSmfLockData : Final[Field] = Field(
    name='r725cmas_CmsSmfLockData',
    origin='R725CMAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Address space ID

SMF Info
--------
    Field: `R725CMAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Address space ID
"""
r725cmas_CmsSmfLockData.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725CMAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Address space ID
"""

r725cmst_CmsSmfLockData : Final[Field] = Field(
    name='r725cmst_CmsSmfLockData',
    origin='R725CMST',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Address space SToken

SMF Info
--------
    Field: `R725CMST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Address space SToken
"""
r725cmst_CmsSmfLockData.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725CMST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Address space SToken
"""

r725cmsn_CmsSmfLockData : Final[Field] = Field(
    name='r725cmsn_CmsSmfLockData',
    origin='R725CMSN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Service class name

SMF Info
--------
    Field: `R725CMSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Service class name
"""
r725cmsn_CmsSmfLockData.__doc__ = """Service class name

SMF Info
--------
    Field: `R725CMSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Service class name
"""

r725cmty_CmsSmfLockData : Final[Field] = Field(
    name='r725cmty_CmsSmfLockData',
    origin='R725CMTY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock

SMF Info
--------
    Field: `R725CMTY`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock
"""
r725cmty_CmsSmfLockData.__doc__ = """Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock

SMF Info
--------
    Field: `R725CMTY`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Lock Type X'01' = CMS Lock X'02' = CMS EnqueueDequeue Lock X'03' = CMS Latch Lock X'04' = CMS SMF Lock
"""

r725cmsu_CmsSmfLockData : Final[Field] = Field(
    name='r725cmsu_CmsSmfLockData',
    origin='R725CMSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""
r725cmsu_CmsSmfLockData.__doc__ = """Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""

r725cmal_CmsSmfLockData : Final[Field] = Field(
    name='r725cmal_CmsSmfLockData',
    origin='R725CMAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock

SMF Info
--------
    Field: `R725CMAL`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock
"""
r725cmal_CmsSmfLockData.__doc__ = """Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock

SMF Info
--------
    Field: `R725CMAL`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Number of times that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY when there was already at least one other unit of work suspended for this lock
"""

r725cmti_CmsSmfLockData : Final[Field] = Field(
    name='r725cmti_CmsSmfLockData',
    origin='R725CMTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""
r725cmti_CmsSmfLockData.__doc__ = """Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY

SMF Info
--------
    Field: `R725CMTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Total amount of time in milliseconds that a unit of work of this address space was suspended on the CMS lock type as specified in R725CMTY
"""

r725cm_entry_index_CmsSmfLockData : Final[Field] = Field(
    name='r725cm_entry_index_CmsSmfLockData',
    origin='R725CM_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725CM_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Artificial Entry Index
"""
r725cm_entry_index_CmsSmfLockData.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725CM_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Artificial Entry Index
"""

r725cm_service_class_list_index_CmsSmfLockData : Final[Field] = Field(
    name='r725cm_service_class_list_index_CmsSmfLockData',
    origin='R725CM_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CM_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""
r725cm_service_class_list_index_CmsSmfLockData.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CM_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""

r725cm_asi_flag_CmsSmfLockData : Final[Field] = Field(
    name='r725cm_asi_flag_CmsSmfLockData',
    origin='R725CM_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CM_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725cm_asi_flag_CmsSmfLockData.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CM_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_CMS_SMF_LOCK_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725lojn : Final[Field] = Field(
    name='r725lojn',
    origin='R725LOJN',
    type=FieldType.STRING,
    record=record,
    record_map=R725LOTD,
)
"""Name of job

SMF Info
--------
    Field: `R725LOJN`
    Record: `SMF72S5`
    Map: `R725LOTD`

Name of job
"""
r725lojn.__doc__ = """Name of job

SMF Info
--------
    Field: `R725LOJN`
    Record: `SMF72S5`
    Map: `R725LOTD`

Name of job
"""

r725losp : Final[Field] = Field(
    name='r725losp',
    origin='R725LOSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Service class period

SMF Info
--------
    Field: `R725LOSP`
    Record: `SMF72S5`
    Map: `R725LOTD`

Service class period
"""
r725losp.__doc__ = """Service class period

SMF Info
--------
    Field: `R725LOSP`
    Record: `SMF72S5`
    Map: `R725LOTD`

Service class period
"""

r725loas : Final[Field] = Field(
    name='r725loas',
    origin='R725LOAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Address space ID

SMF Info
--------
    Field: `R725LOAS`
    Record: `SMF72S5`
    Map: `R725LOTD`

Address space ID
"""
r725loas.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725LOAS`
    Record: `SMF72S5`
    Map: `R725LOTD`

Address space ID
"""

r725lost : Final[Field] = Field(
    name='r725lost',
    origin='R725LOST',
    type=FieldType.STRING,
    record=record,
    record_map=R725LOTD,
)
"""Address space SToken

SMF Info
--------
    Field: `R725LOST`
    Record: `SMF72S5`
    Map: `R725LOTD`

Address space SToken
"""
r725lost.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725LOST`
    Record: `SMF72S5`
    Map: `R725LOTD`

Address space SToken
"""

r725losn : Final[Field] = Field(
    name='r725losn',
    origin='R725LOSN',
    type=FieldType.STRING,
    record=record,
    record_map=R725LOTD,
)
"""Service class name

SMF Info
--------
    Field: `R725LOSN`
    Record: `SMF72S5`
    Map: `R725LOTD`

Service class name
"""
r725losn.__doc__ = """Service class name

SMF Info
--------
    Field: `R725LOSN`
    Record: `SMF72S5`
    Map: `R725LOTD`

Service class name
"""

r725losu : Final[Field] = Field(
    name='r725losu',
    origin='R725LOSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Number of times that a unit of work of this address space was suspended on a Local lock

SMF Info
--------
    Field: `R725LOSU`
    Record: `SMF72S5`
    Map: `R725LOTD`

Number of times that a unit of work of this address space was suspended on a Local lock
"""
r725losu.__doc__ = """Number of times that a unit of work of this address space was suspended on a Local lock

SMF Info
--------
    Field: `R725LOSU`
    Record: `SMF72S5`
    Map: `R725LOTD`

Number of times that a unit of work of this address space was suspended on a Local lock
"""

r725loal : Final[Field] = Field(
    name='r725loal',
    origin='R725LOAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Number of times that a unit of work of this address space was suspended on a Local lock when there was already at least one other unit of work suspended

SMF Info
--------
    Field: `R725LOAL`
    Record: `SMF72S5`
    Map: `R725LOTD`

Number of times that a unit of work of this address space was suspended on a Local lock when there was already at least one other unit of work suspended
"""
r725loal.__doc__ = """Number of times that a unit of work of this address space was suspended on a Local lock when there was already at least one other unit of work suspended

SMF Info
--------
    Field: `R725LOAL`
    Record: `SMF72S5`
    Map: `R725LOTD`

Number of times that a unit of work of this address space was suspended on a Local lock when there was already at least one other unit of work suspended
"""

r725loti : Final[Field] = Field(
    name='r725loti',
    origin='R725LOTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Total amount of time in milliseconds that a unit of work of this address space was suspended on a Local lock CML lock owner data

SMF Info
--------
    Field: `R725LOTI`
    Record: `SMF72S5`
    Map: `R725LOTD`

Total amount of time in milliseconds that a unit of work of this address space was suspended on a Local lock CML lock owner data
"""
r725loti.__doc__ = """Total amount of time in milliseconds that a unit of work of this address space was suspended on a Local lock CML lock owner data

SMF Info
--------
    Field: `R725LOTI`
    Record: `SMF72S5`
    Map: `R725LOTD`

Total amount of time in milliseconds that a unit of work of this address space was suspended on a Local lock CML lock owner data
"""

r725lcsu : Final[Field] = Field(
    name='r725lcsu',
    origin='R725LCSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address space

SMF Info
--------
    Field: `R725LCSU`
    Record: `SMF72S5`
    Map: `R725LOTD`

Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address space
"""
r725lcsu.__doc__ = """Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address space

SMF Info
--------
    Field: `R725LCSU`
    Record: `SMF72S5`
    Map: `R725LOTD`

Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address space
"""

r725lcal : Final[Field] = Field(
    name='r725lcal',
    origin='R725LCAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address space and there was already at least one other unit of work waiting for that lock

SMF Info
--------
    Field: `R725LCAL`
    Record: `SMF72S5`
    Map: `R725LOTD`

Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address space and there was already at least one other unit of work waiting for that lock
"""
r725lcal.__doc__ = """Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address space and there was already at least one other unit of work waiting for that lock

SMF Info
--------
    Field: `R725LCAL`
    Record: `SMF72S5`
    Map: `R725LOTD`

Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address space and there was already at least one other unit of work waiting for that lock
"""

r725lcti : Final[Field] = Field(
    name='r725lcti',
    origin='R725LCTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of this address space

SMF Info
--------
    Field: `R725LCTI`
    Record: `SMF72S5`
    Map: `R725LOTD`

Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of this address space
"""
r725lcti.__doc__ = """Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of this address space

SMF Info
--------
    Field: `R725LCTI`
    Record: `SMF72S5`
    Map: `R725LOTD`

Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of this address space
"""

r725lo_entry_index : Final[Field] = Field(
    name='r725lo_entry_index',
    origin='R725LO_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725LO_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725LOTD`

Artificial Entry Index
"""
r725lo_entry_index.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725LO_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725LOTD`

Artificial Entry Index
"""

r725lo_service_class_list_index : Final[Field] = Field(
    name='r725lo_service_class_list_index',
    origin='R725LO_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LOTD,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725LO_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725LOTD`

Service class list index (See ASICLX in ERBASIG3)
"""
r725lo_service_class_list_index.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725LO_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725LOTD`

Service class list index (See ASICLX in ERBASIG3)
"""

r725lo_asi_flag : Final[Field] = Field(
    name='r725lo_asi_flag',
    origin='R725LO_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=R725LOTD,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725LO_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725LOTD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725lo_asi_flag.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725LO_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725LOTD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725cojn : Final[Field] = Field(
    name='r725cojn',
    origin='R725COJN',
    type=FieldType.STRING,
    record=record,
    record_map=R725CLOD,
)
"""Name of job

SMF Info
--------
    Field: `R725COJN`
    Record: `SMF72S5`
    Map: `R725CLOD`

Name of job
"""
r725cojn.__doc__ = """Name of job

SMF Info
--------
    Field: `R725COJN`
    Record: `SMF72S5`
    Map: `R725CLOD`

Name of job
"""

r725cosp : Final[Field] = Field(
    name='r725cosp',
    origin='R725COSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Service class period

SMF Info
--------
    Field: `R725COSP`
    Record: `SMF72S5`
    Map: `R725CLOD`

Service class period
"""
r725cosp.__doc__ = """Service class period

SMF Info
--------
    Field: `R725COSP`
    Record: `SMF72S5`
    Map: `R725CLOD`

Service class period
"""

r725coas : Final[Field] = Field(
    name='r725coas',
    origin='R725COAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Address space ID

SMF Info
--------
    Field: `R725COAS`
    Record: `SMF72S5`
    Map: `R725CLOD`

Address space ID
"""
r725coas.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725COAS`
    Record: `SMF72S5`
    Map: `R725CLOD`

Address space ID
"""

r725cost : Final[Field] = Field(
    name='r725cost',
    origin='R725COST',
    type=FieldType.STRING,
    record=record,
    record_map=R725CLOD,
)
"""Address space SToken

SMF Info
--------
    Field: `R725COST`
    Record: `SMF72S5`
    Map: `R725CLOD`

Address space SToken
"""
r725cost.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725COST`
    Record: `SMF72S5`
    Map: `R725CLOD`

Address space SToken
"""

r725cosn : Final[Field] = Field(
    name='r725cosn',
    origin='R725COSN',
    type=FieldType.STRING,
    record=record,
    record_map=R725CLOD,
)
"""Service class name

SMF Info
--------
    Field: `R725COSN`
    Record: `SMF72S5`
    Map: `R725CLOD`

Service class name
"""
r725cosn.__doc__ = """Service class name

SMF Info
--------
    Field: `R725COSN`
    Record: `SMF72S5`
    Map: `R725CLOD`

Service class name
"""

r725cosu : Final[Field] = Field(
    name='r725cosu',
    origin='R725COSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address

SMF Info
--------
    Field: `R725COSU`
    Record: `SMF72S5`
    Map: `R725CLOD`

Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address
"""
r725cosu.__doc__ = """Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address

SMF Info
--------
    Field: `R725COSU`
    Record: `SMF72S5`
    Map: `R725CLOD`

Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address
"""

r725coal : Final[Field] = Field(
    name='r725coal',
    origin='R725COAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address and there was already at least one other unit of work waiting for that lock.

SMF Info
--------
    Field: `R725COAL`
    Record: `SMF72S5`
    Map: `R725CLOD`

Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address and there was already at least one other unit of work waiting for that lock.
"""
r725coal.__doc__ = """Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address and there was already at least one other unit of work waiting for that lock.

SMF Info
--------
    Field: `R725COAL`
    Record: `SMF72S5`
    Map: `R725CLOD`

Number of times that a unit of work from another address space was suspended when requesting the Local lock of this address and there was already at least one other unit of work waiting for that lock.
"""

r725coti : Final[Field] = Field(
    name='r725coti',
    origin='R725COTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of this address space Local lock data

SMF Info
--------
    Field: `R725COTI`
    Record: `SMF72S5`
    Map: `R725CLOD`

Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of this address space Local lock data
"""
r725coti.__doc__ = """Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of this address space Local lock data

SMF Info
--------
    Field: `R725COTI`
    Record: `SMF72S5`
    Map: `R725CLOD`

Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of this address space Local lock data
"""

r725clsu : Final[Field] = Field(
    name='r725clsu',
    origin='R725CLSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Number of times that a unit of work of this address space was suspended on a Local lock

SMF Info
--------
    Field: `R725CLSU`
    Record: `SMF72S5`
    Map: `R725CLOD`

Number of times that a unit of work of this address space was suspended on a Local lock
"""
r725clsu.__doc__ = """Number of times that a unit of work of this address space was suspended on a Local lock

SMF Info
--------
    Field: `R725CLSU`
    Record: `SMF72S5`
    Map: `R725CLOD`

Number of times that a unit of work of this address space was suspended on a Local lock
"""

r725clal : Final[Field] = Field(
    name='r725clal',
    origin='R725CLAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Number of times that a unit of work of this address space was suspended on a Local lock when there was already at least one other unit of work suspended

SMF Info
--------
    Field: `R725CLAL`
    Record: `SMF72S5`
    Map: `R725CLOD`

Number of times that a unit of work of this address space was suspended on a Local lock when there was already at least one other unit of work suspended
"""
r725clal.__doc__ = """Number of times that a unit of work of this address space was suspended on a Local lock when there was already at least one other unit of work suspended

SMF Info
--------
    Field: `R725CLAL`
    Record: `SMF72S5`
    Map: `R725CLOD`

Number of times that a unit of work of this address space was suspended on a Local lock when there was already at least one other unit of work suspended
"""

r725clti : Final[Field] = Field(
    name='r725clti',
    origin='R725CLTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Total amount of time in milliseconds that a unit of work of this address space was suspended on a Local lock

SMF Info
--------
    Field: `R725CLTI`
    Record: `SMF72S5`
    Map: `R725CLOD`

Total amount of time in milliseconds that a unit of work of this address space was suspended on a Local lock
"""
r725clti.__doc__ = """Total amount of time in milliseconds that a unit of work of this address space was suspended on a Local lock

SMF Info
--------
    Field: `R725CLTI`
    Record: `SMF72S5`
    Map: `R725CLOD`

Total amount of time in milliseconds that a unit of work of this address space was suspended on a Local lock
"""

r725co_entry_index : Final[Field] = Field(
    name='r725co_entry_index',
    origin='R725CO_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725CO_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725CLOD`

Artificial Entry Index
"""
r725co_entry_index.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725CO_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725CLOD`

Artificial Entry Index
"""

r725co_service_class_list_index : Final[Field] = Field(
    name='r725co_service_class_list_index',
    origin='R725CO_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLOD,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CO_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725CLOD`

Service class list index (See ASICLX in ERBASIG3)
"""
r725co_service_class_list_index.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CO_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725CLOD`

Service class list index (See ASICLX in ERBASIG3)
"""

r725co_asi_flag : Final[Field] = Field(
    name='r725co_asi_flag',
    origin='R725CO_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=R725CLOD,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CO_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725CLOD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725co_asi_flag.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CO_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725CLOD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725crjn : Final[Field] = Field(
    name='r725crjn',
    origin='R725CRJN',
    type=FieldType.STRING,
    record=record,
    record_map=R725CLRD,
)
"""Name of job

SMF Info
--------
    Field: `R725CRJN`
    Record: `SMF72S5`
    Map: `R725CLRD`

Name of job
"""
r725crjn.__doc__ = """Name of job

SMF Info
--------
    Field: `R725CRJN`
    Record: `SMF72S5`
    Map: `R725CLRD`

Name of job
"""

r725crsp : Final[Field] = Field(
    name='r725crsp',
    origin='R725CRSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLRD,
)
"""Service class period

SMF Info
--------
    Field: `R725CRSP`
    Record: `SMF72S5`
    Map: `R725CLRD`

Service class period
"""
r725crsp.__doc__ = """Service class period

SMF Info
--------
    Field: `R725CRSP`
    Record: `SMF72S5`
    Map: `R725CLRD`

Service class period
"""

r725cras : Final[Field] = Field(
    name='r725cras',
    origin='R725CRAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLRD,
)
"""Address space ID

SMF Info
--------
    Field: `R725CRAS`
    Record: `SMF72S5`
    Map: `R725CLRD`

Address space ID
"""
r725cras.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725CRAS`
    Record: `SMF72S5`
    Map: `R725CLRD`

Address space ID
"""

r725crst : Final[Field] = Field(
    name='r725crst',
    origin='R725CRST',
    type=FieldType.STRING,
    record=record,
    record_map=R725CLRD,
)
"""Address space SToken

SMF Info
--------
    Field: `R725CRST`
    Record: `SMF72S5`
    Map: `R725CLRD`

Address space SToken
"""
r725crst.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725CRST`
    Record: `SMF72S5`
    Map: `R725CLRD`

Address space SToken
"""

r725crsn : Final[Field] = Field(
    name='r725crsn',
    origin='R725CRSN',
    type=FieldType.STRING,
    record=record,
    record_map=R725CLRD,
)
"""Service class name

SMF Info
--------
    Field: `R725CRSN`
    Record: `SMF72S5`
    Map: `R725CLRD`

Service class name
"""
r725crsn.__doc__ = """Service class name

SMF Info
--------
    Field: `R725CRSN`
    Record: `SMF72S5`
    Map: `R725CLRD`

Service class name
"""

r725crsu : Final[Field] = Field(
    name='r725crsu',
    origin='R725CRSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLRD,
)
"""Number of times that a unit of work from this address space was suspended when requesting the Local lock of another address space

SMF Info
--------
    Field: `R725CRSU`
    Record: `SMF72S5`
    Map: `R725CLRD`

Number of times that a unit of work from this address space was suspended when requesting the Local lock of another address space
"""
r725crsu.__doc__ = """Number of times that a unit of work from this address space was suspended when requesting the Local lock of another address space

SMF Info
--------
    Field: `R725CRSU`
    Record: `SMF72S5`
    Map: `R725CLRD`

Number of times that a unit of work from this address space was suspended when requesting the Local lock of another address space
"""

r725cral : Final[Field] = Field(
    name='r725cral',
    origin='R725CRAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLRD,
)
"""Number of times that a unit of work from this address space was suspended when requesting the Local lock of another address space and there was already at least one other unit of work waiting for that lock

SMF Info
--------
    Field: `R725CRAL`
    Record: `SMF72S5`
    Map: `R725CLRD`

Number of times that a unit of work from this address space was suspended when requesting the Local lock of another address space and there was already at least one other unit of work waiting for that lock
"""
r725cral.__doc__ = """Number of times that a unit of work from this address space was suspended when requesting the Local lock of another address space and there was already at least one other unit of work waiting for that lock

SMF Info
--------
    Field: `R725CRAL`
    Record: `SMF72S5`
    Map: `R725CLRD`

Number of times that a unit of work from this address space was suspended when requesting the Local lock of another address space and there was already at least one other unit of work waiting for that lock
"""

r725crti : Final[Field] = Field(
    name='r725crti',
    origin='R725CRTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLRD,
)
"""Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of another address space

SMF Info
--------
    Field: `R725CRTI`
    Record: `SMF72S5`
    Map: `R725CLRD`

Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of another address space
"""
r725crti.__doc__ = """Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of another address space

SMF Info
--------
    Field: `R725CRTI`
    Record: `SMF72S5`
    Map: `R725CLRD`

Total amount of time in milliseconds that a unit of work was suspended when requesting the Local lock of another address space
"""

r725cr_entry_index : Final[Field] = Field(
    name='r725cr_entry_index',
    origin='R725CR_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLRD,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725CR_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725CLRD`

Artificial Entry Index
"""
r725cr_entry_index.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725CR_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725CLRD`

Artificial Entry Index
"""

r725cr_service_class_list_index : Final[Field] = Field(
    name='r725cr_service_class_list_index',
    origin='R725CR_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725CLRD,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CR_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725CLRD`

Service class list index (See ASICLX in ERBASIG3)
"""
r725cr_service_class_list_index.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725CR_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725CLRD`

Service class list index (See ASICLX in ERBASIG3)
"""

r725cr_asi_flag : Final[Field] = Field(
    name='r725cr_asi_flag',
    origin='R725CR_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=R725CLRD,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CR_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725CLRD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725cr_asi_flag.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725CR_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725CLRD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725lajn_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725lajn_GrsLatchSetCreatorData',
    origin='R725LAJN',
    type=FieldType.STRING,
    record=record,
    record_map=R725LATD,
)
"""Name of job

SMF Info
--------
    Field: `R725LAJN`
    Record: `SMF72S5`
    Map: `R725LATD`

Name of job
"""
r725lajn_GrsLatchSetCreatorData.__doc__ = """Name of job

SMF Info
--------
    Field: `R725LAJN`
    Record: `SMF72S5`
    Map: `R725LATD`

Name of job
"""

r725lasp_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725lasp_GrsLatchSetCreatorData',
    origin='R725LASP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LATD,
)
"""Service class period

SMF Info
--------
    Field: `R725LASP`
    Record: `SMF72S5`
    Map: `R725LATD`

Service class period
"""
r725lasp_GrsLatchSetCreatorData.__doc__ = """Service class period

SMF Info
--------
    Field: `R725LASP`
    Record: `SMF72S5`
    Map: `R725LATD`

Service class period
"""

r725laas_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725laas_GrsLatchSetCreatorData',
    origin='R725LAAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LATD,
)
"""Address space ID

SMF Info
--------
    Field: `R725LAAS`
    Record: `SMF72S5`
    Map: `R725LATD`

Address space ID
"""
r725laas_GrsLatchSetCreatorData.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725LAAS`
    Record: `SMF72S5`
    Map: `R725LATD`

Address space ID
"""

r725last_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725last_GrsLatchSetCreatorData',
    origin='R725LAST',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LATD,
)
"""Address space SToken

SMF Info
--------
    Field: `R725LAST`
    Record: `SMF72S5`
    Map: `R725LATD`

Address space SToken
"""
r725last_GrsLatchSetCreatorData.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725LAST`
    Record: `SMF72S5`
    Map: `R725LATD`

Address space SToken
"""

r725lasn_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725lasn_GrsLatchSetCreatorData',
    origin='R725LASN',
    type=FieldType.STRING,
    record=record,
    record_map=R725LATD,
)
"""Service class name

SMF Info
--------
    Field: `R725LASN`
    Record: `SMF72S5`
    Map: `R725LATD`

Service class name
"""
r725lasn_GrsLatchSetCreatorData.__doc__ = """Service class name

SMF Info
--------
    Field: `R725LASN`
    Record: `SMF72S5`
    Map: `R725LATD`

Service class name
"""

r725laty_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725laty_GrsLatchSetCreatorData',
    origin='R725LATY',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LATD,
)
"""Request Type X'01' = Latch Set Creator X'02' = Latch Requestor

SMF Info
--------
    Field: `R725LATY`
    Record: `SMF72S5`
    Map: `R725LATD`

Request Type X'01' = Latch Set Creator X'02' = Latch Requestor
"""
r725laty_GrsLatchSetCreatorData.__doc__ = """Request Type X'01' = Latch Set Creator X'02' = Latch Requestor

SMF Info
--------
    Field: `R725LATY`
    Record: `SMF72S5`
    Map: `R725LATD`

Request Type X'01' = Latch Set Creator X'02' = Latch Requestor
"""

r725lasu_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725lasu_GrsLatchSetCreatorData',
    origin='R725LASU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LATD,
)
"""Number of times a Latch Obtain request was suspended for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LASU`
    Record: `SMF72S5`
    Map: `R725LATD`

Number of times a Latch Obtain request was suspended for the Request Type as specified in R725LATY
"""
r725lasu_GrsLatchSetCreatorData.__doc__ = """Number of times a Latch Obtain request was suspended for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LASU`
    Record: `SMF72S5`
    Map: `R725LATD`

Number of times a Latch Obtain request was suspended for the Request Type as specified in R725LATY
"""

r725lati_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725lati_GrsLatchSetCreatorData',
    origin='R725LATI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LATD,
)
"""Total amount of contention time in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LATI`
    Record: `SMF72S5`
    Map: `R725LATD`

Total amount of contention time in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY
"""
r725lati_GrsLatchSetCreatorData.__doc__ = """Total amount of contention time in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LATI`
    Record: `SMF72S5`
    Map: `R725LATD`

Total amount of contention time in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY
"""

r725lasq_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725lasq_GrsLatchSetCreatorData',
    origin='R725LASQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LATD,
)
"""Sum of squares of the individual contention times in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LASQ`
    Record: `SMF72S5`
    Map: `R725LATD`

Sum of squares of the individual contention times in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY
"""
r725lasq_GrsLatchSetCreatorData.__doc__ = """Sum of squares of the individual contention times in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LASQ`
    Record: `SMF72S5`
    Map: `R725LATD`

Sum of squares of the individual contention times in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY
"""

r725la_entry_index_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725la_entry_index_GrsLatchSetCreatorData',
    origin='R725LA_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LATD,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725LA_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725LATD`

Artificial Entry Index
"""
r725la_entry_index_GrsLatchSetCreatorData.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725LA_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725LATD`

Artificial Entry Index
"""

r725la_service_class_list_index_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725la_service_class_list_index_GrsLatchSetCreatorData',
    origin='R725LA_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725LATD,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725LA_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725LATD`

Service class list index (See ASICLX in ERBASIG3)
"""
r725la_service_class_list_index_GrsLatchSetCreatorData.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725LA_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725LATD`

Service class list index (See ASICLX in ERBASIG3)
"""

r725la_asi_flag_GrsLatchSetCreatorData : Final[Field] = Field(
    name='r725la_asi_flag_GrsLatchSetCreatorData',
    origin='R725LA_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=R725LATD,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725LA_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725LATD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725la_asi_flag_GrsLatchSetCreatorData.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725LA_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725LATD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725lajn_GrsLatchRequestorData : Final[Field] = Field(
    name='r725lajn_GrsLatchRequestorData',
    origin='R725LAJN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Name of job

SMF Info
--------
    Field: `R725LAJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Name of job
"""
r725lajn_GrsLatchRequestorData.__doc__ = """Name of job

SMF Info
--------
    Field: `R725LAJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Name of job
"""

r725lasp_GrsLatchRequestorData : Final[Field] = Field(
    name='r725lasp_GrsLatchRequestorData',
    origin='R725LASP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Service class period

SMF Info
--------
    Field: `R725LASP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Service class period
"""
r725lasp_GrsLatchRequestorData.__doc__ = """Service class period

SMF Info
--------
    Field: `R725LASP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Service class period
"""

r725laas_GrsLatchRequestorData : Final[Field] = Field(
    name='r725laas_GrsLatchRequestorData',
    origin='R725LAAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Address space ID

SMF Info
--------
    Field: `R725LAAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Address space ID
"""
r725laas_GrsLatchRequestorData.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725LAAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Address space ID
"""

r725last_GrsLatchRequestorData : Final[Field] = Field(
    name='r725last_GrsLatchRequestorData',
    origin='R725LAST',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Address space SToken

SMF Info
--------
    Field: `R725LAST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Address space SToken
"""
r725last_GrsLatchRequestorData.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725LAST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Address space SToken
"""

r725lasn_GrsLatchRequestorData : Final[Field] = Field(
    name='r725lasn_GrsLatchRequestorData',
    origin='R725LASN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Service class name

SMF Info
--------
    Field: `R725LASN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Service class name
"""
r725lasn_GrsLatchRequestorData.__doc__ = """Service class name

SMF Info
--------
    Field: `R725LASN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Service class name
"""

r725laty_GrsLatchRequestorData : Final[Field] = Field(
    name='r725laty_GrsLatchRequestorData',
    origin='R725LATY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Request Type X'01' = Latch Set Creator X'02' = Latch Requestor

SMF Info
--------
    Field: `R725LATY`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Request Type X'01' = Latch Set Creator X'02' = Latch Requestor
"""
r725laty_GrsLatchRequestorData.__doc__ = """Request Type X'01' = Latch Set Creator X'02' = Latch Requestor

SMF Info
--------
    Field: `R725LATY`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Request Type X'01' = Latch Set Creator X'02' = Latch Requestor
"""

r725lasu_GrsLatchRequestorData : Final[Field] = Field(
    name='r725lasu_GrsLatchRequestorData',
    origin='R725LASU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Number of times a Latch Obtain request was suspended for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LASU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Number of times a Latch Obtain request was suspended for the Request Type as specified in R725LATY
"""
r725lasu_GrsLatchRequestorData.__doc__ = """Number of times a Latch Obtain request was suspended for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LASU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Number of times a Latch Obtain request was suspended for the Request Type as specified in R725LATY
"""

r725lati_GrsLatchRequestorData : Final[Field] = Field(
    name='r725lati_GrsLatchRequestorData',
    origin='R725LATI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Total amount of contention time in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LATI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Total amount of contention time in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY
"""
r725lati_GrsLatchRequestorData.__doc__ = """Total amount of contention time in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LATI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Total amount of contention time in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY
"""

r725lasq_GrsLatchRequestorData : Final[Field] = Field(
    name='r725lasq_GrsLatchRequestorData',
    origin='R725LASQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Sum of squares of the individual contention times in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LASQ`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Sum of squares of the individual contention times in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY
"""
r725lasq_GrsLatchRequestorData.__doc__ = """Sum of squares of the individual contention times in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY

SMF Info
--------
    Field: `R725LASQ`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Sum of squares of the individual contention times in milliseconds that was caused by Latch Obtain requests for the Request Type as specified in R725LATY
"""

r725la_entry_index_GrsLatchRequestorData : Final[Field] = Field(
    name='r725la_entry_index_GrsLatchRequestorData',
    origin='R725LA_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725LA_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Artificial Entry Index
"""
r725la_entry_index_GrsLatchRequestorData.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725LA_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Artificial Entry Index
"""

r725la_service_class_list_index_GrsLatchRequestorData : Final[Field] = Field(
    name='r725la_service_class_list_index_GrsLatchRequestorData',
    origin='R725LA_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725LA_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""
r725la_service_class_list_index_GrsLatchRequestorData.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725LA_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""

r725la_asi_flag_GrsLatchRequestorData : Final[Field] = Field(
    name='r725la_asi_flag_GrsLatchRequestorData',
    origin='R725LA_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725LA_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725la_asi_flag_GrsLatchRequestorData.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725LA_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_LATCH_REQUESTOR_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725enjn_GrsEnqStepData : Final[Field] = Field(
    name='r725enjn_GrsEnqStepData',
    origin='R725ENJN',
    type=FieldType.STRING,
    record=record,
    record_map=R725ENTD,
)
"""Name of job

SMF Info
--------
    Field: `R725ENJN`
    Record: `SMF72S5`
    Map: `R725ENTD`

Name of job
"""
r725enjn_GrsEnqStepData.__doc__ = """Name of job

SMF Info
--------
    Field: `R725ENJN`
    Record: `SMF72S5`
    Map: `R725ENTD`

Name of job
"""

r725ensp_GrsEnqStepData : Final[Field] = Field(
    name='r725ensp_GrsEnqStepData',
    origin='R725ENSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725ENTD,
)
"""Service class period

SMF Info
--------
    Field: `R725ENSP`
    Record: `SMF72S5`
    Map: `R725ENTD`

Service class period
"""
r725ensp_GrsEnqStepData.__doc__ = """Service class period

SMF Info
--------
    Field: `R725ENSP`
    Record: `SMF72S5`
    Map: `R725ENTD`

Service class period
"""

r725enas_GrsEnqStepData : Final[Field] = Field(
    name='r725enas_GrsEnqStepData',
    origin='R725ENAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725ENTD,
)
"""Address space ID

SMF Info
--------
    Field: `R725ENAS`
    Record: `SMF72S5`
    Map: `R725ENTD`

Address space ID
"""
r725enas_GrsEnqStepData.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725ENAS`
    Record: `SMF72S5`
    Map: `R725ENTD`

Address space ID
"""

r725enst_GrsEnqStepData : Final[Field] = Field(
    name='r725enst_GrsEnqStepData',
    origin='R725ENST',
    type=FieldType.STRING,
    record=record,
    record_map=R725ENTD,
)
"""Address space SToken

SMF Info
--------
    Field: `R725ENST`
    Record: `SMF72S5`
    Map: `R725ENTD`

Address space SToken
"""
r725enst_GrsEnqStepData.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725ENST`
    Record: `SMF72S5`
    Map: `R725ENTD`

Address space SToken
"""

r725ensn_GrsEnqStepData : Final[Field] = Field(
    name='r725ensn_GrsEnqStepData',
    origin='R725ENSN',
    type=FieldType.STRING,
    record=record,
    record_map=R725ENTD,
)
"""Service class name

SMF Info
--------
    Field: `R725ENSN`
    Record: `SMF72S5`
    Map: `R725ENTD`

Service class name
"""
r725ensn_GrsEnqStepData.__doc__ = """Service class name

SMF Info
--------
    Field: `R725ENSN`
    Record: `SMF72S5`
    Map: `R725ENTD`

Service class name
"""

r725ensc_GrsEnqStepData : Final[Field] = Field(
    name='r725ensc_GrsEnqStepData',
    origin='R725ENSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725ENTD,
)
"""Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems

SMF Info
--------
    Field: `R725ENSC`
    Record: `SMF72S5`
    Map: `R725ENTD`

Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems
"""
r725ensc_GrsEnqStepData.__doc__ = """Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems

SMF Info
--------
    Field: `R725ENSC`
    Record: `SMF72S5`
    Map: `R725ENTD`

Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems
"""

r725enrc_GrsEnqStepData : Final[Field] = Field(
    name='r725enrc_GrsEnqStepData',
    origin='R725ENRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725ENTD,
)
"""Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENRC`
    Record: `SMF72S5`
    Map: `R725ENTD`

Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""
r725enrc_GrsEnqStepData.__doc__ = """Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENRC`
    Record: `SMF72S5`
    Map: `R725ENTD`

Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""

r725ensu_GrsEnqStepData : Final[Field] = Field(
    name='r725ensu_GrsEnqStepData',
    origin='R725ENSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725ENTD,
)
"""Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space

SMF Info
--------
    Field: `R725ENSU`
    Record: `SMF72S5`
    Map: `R725ENTD`

Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space
"""
r725ensu_GrsEnqStepData.__doc__ = """Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space

SMF Info
--------
    Field: `R725ENSU`
    Record: `SMF72S5`
    Map: `R725ENTD`

Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space
"""

r725enti_GrsEnqStepData : Final[Field] = Field(
    name='r725enti_GrsEnqStepData',
    origin='R725ENTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725ENTD,
)
"""Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENTI`
    Record: `SMF72S5`
    Map: `R725ENTD`

Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""
r725enti_GrsEnqStepData.__doc__ = """Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENTI`
    Record: `SMF72S5`
    Map: `R725ENTD`

Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""

r725ensq_GrsEnqStepData : Final[Field] = Field(
    name='r725ensq_GrsEnqStepData',
    origin='R725ENSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725ENTD,
)
"""Sum of squares of the individual contention times in milliseconds

SMF Info
--------
    Field: `R725ENSQ`
    Record: `SMF72S5`
    Map: `R725ENTD`

Sum of squares of the individual contention times in milliseconds
"""
r725ensq_GrsEnqStepData.__doc__ = """Sum of squares of the individual contention times in milliseconds

SMF Info
--------
    Field: `R725ENSQ`
    Record: `SMF72S5`
    Map: `R725ENTD`

Sum of squares of the individual contention times in milliseconds
"""

r725en_entry_index_GrsEnqStepData : Final[Field] = Field(
    name='r725en_entry_index_GrsEnqStepData',
    origin='R725EN_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725ENTD,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725EN_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725ENTD`

Artificial Entry Index
"""
r725en_entry_index_GrsEnqStepData.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725EN_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725ENTD`

Artificial Entry Index
"""

r725en_service_class_list_index_GrsEnqStepData : Final[Field] = Field(
    name='r725en_service_class_list_index_GrsEnqStepData',
    origin='R725EN_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725ENTD,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725EN_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725ENTD`

Service class list index (See ASICLX in ERBASIG3)
"""
r725en_service_class_list_index_GrsEnqStepData.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725EN_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725ENTD`

Service class list index (See ASICLX in ERBASIG3)
"""

r725en_asi_flag_GrsEnqStepData : Final[Field] = Field(
    name='r725en_asi_flag_GrsEnqStepData',
    origin='R725EN_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=R725ENTD,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725EN_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725ENTD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725en_asi_flag_GrsEnqStepData.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725EN_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725ENTD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725enjn_GrsEnqSystemData : Final[Field] = Field(
    name='r725enjn_GrsEnqSystemData',
    origin='R725ENJN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Name of job

SMF Info
--------
    Field: `R725ENJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Name of job
"""
r725enjn_GrsEnqSystemData.__doc__ = """Name of job

SMF Info
--------
    Field: `R725ENJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Name of job
"""

r725ensp_GrsEnqSystemData : Final[Field] = Field(
    name='r725ensp_GrsEnqSystemData',
    origin='R725ENSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Service class period

SMF Info
--------
    Field: `R725ENSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Service class period
"""
r725ensp_GrsEnqSystemData.__doc__ = """Service class period

SMF Info
--------
    Field: `R725ENSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Service class period
"""

r725enas_GrsEnqSystemData : Final[Field] = Field(
    name='r725enas_GrsEnqSystemData',
    origin='R725ENAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Address space ID

SMF Info
--------
    Field: `R725ENAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Address space ID
"""
r725enas_GrsEnqSystemData.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725ENAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Address space ID
"""

r725enst_GrsEnqSystemData : Final[Field] = Field(
    name='r725enst_GrsEnqSystemData',
    origin='R725ENST',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Address space SToken

SMF Info
--------
    Field: `R725ENST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Address space SToken
"""
r725enst_GrsEnqSystemData.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725ENST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Address space SToken
"""

r725ensn_GrsEnqSystemData : Final[Field] = Field(
    name='r725ensn_GrsEnqSystemData',
    origin='R725ENSN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Service class name

SMF Info
--------
    Field: `R725ENSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Service class name
"""
r725ensn_GrsEnqSystemData.__doc__ = """Service class name

SMF Info
--------
    Field: `R725ENSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Service class name
"""

r725ensc_GrsEnqSystemData : Final[Field] = Field(
    name='r725ensc_GrsEnqSystemData',
    origin='R725ENSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems

SMF Info
--------
    Field: `R725ENSC`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems
"""
r725ensc_GrsEnqSystemData.__doc__ = """Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems

SMF Info
--------
    Field: `R725ENSC`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems
"""

r725enrc_GrsEnqSystemData : Final[Field] = Field(
    name='r725enrc_GrsEnqSystemData',
    origin='R725ENRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENRC`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""
r725enrc_GrsEnqSystemData.__doc__ = """Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENRC`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""

r725ensu_GrsEnqSystemData : Final[Field] = Field(
    name='r725ensu_GrsEnqSystemData',
    origin='R725ENSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space

SMF Info
--------
    Field: `R725ENSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space
"""
r725ensu_GrsEnqSystemData.__doc__ = """Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space

SMF Info
--------
    Field: `R725ENSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space
"""

r725enti_GrsEnqSystemData : Final[Field] = Field(
    name='r725enti_GrsEnqSystemData',
    origin='R725ENTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""
r725enti_GrsEnqSystemData.__doc__ = """Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""

r725ensq_GrsEnqSystemData : Final[Field] = Field(
    name='r725ensq_GrsEnqSystemData',
    origin='R725ENSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Sum of squares of the individual contention times in milliseconds

SMF Info
--------
    Field: `R725ENSQ`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Sum of squares of the individual contention times in milliseconds
"""
r725ensq_GrsEnqSystemData.__doc__ = """Sum of squares of the individual contention times in milliseconds

SMF Info
--------
    Field: `R725ENSQ`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Sum of squares of the individual contention times in milliseconds
"""

r725en_entry_index_GrsEnqSystemData : Final[Field] = Field(
    name='r725en_entry_index_GrsEnqSystemData',
    origin='R725EN_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725EN_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Artificial Entry Index
"""
r725en_entry_index_GrsEnqSystemData.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725EN_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Artificial Entry Index
"""

r725en_service_class_list_index_GrsEnqSystemData : Final[Field] = Field(
    name='r725en_service_class_list_index_GrsEnqSystemData',
    origin='R725EN_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725EN_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""
r725en_service_class_list_index_GrsEnqSystemData.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725EN_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""

r725en_asi_flag_GrsEnqSystemData : Final[Field] = Field(
    name='r725en_asi_flag_GrsEnqSystemData',
    origin='R725EN_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725EN_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725en_asi_flag_GrsEnqSystemData.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725EN_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEM_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725enjn_GrsEnqSystemsData : Final[Field] = Field(
    name='r725enjn_GrsEnqSystemsData',
    origin='R725ENJN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Name of job

SMF Info
--------
    Field: `R725ENJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Name of job
"""
r725enjn_GrsEnqSystemsData.__doc__ = """Name of job

SMF Info
--------
    Field: `R725ENJN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Name of job
"""

r725ensp_GrsEnqSystemsData : Final[Field] = Field(
    name='r725ensp_GrsEnqSystemsData',
    origin='R725ENSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Service class period

SMF Info
--------
    Field: `R725ENSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Service class period
"""
r725ensp_GrsEnqSystemsData.__doc__ = """Service class period

SMF Info
--------
    Field: `R725ENSP`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Service class period
"""

r725enas_GrsEnqSystemsData : Final[Field] = Field(
    name='r725enas_GrsEnqSystemsData',
    origin='R725ENAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Address space ID

SMF Info
--------
    Field: `R725ENAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Address space ID
"""
r725enas_GrsEnqSystemsData.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725ENAS`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Address space ID
"""

r725enst_GrsEnqSystemsData : Final[Field] = Field(
    name='r725enst_GrsEnqSystemsData',
    origin='R725ENST',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Address space SToken

SMF Info
--------
    Field: `R725ENST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Address space SToken
"""
r725enst_GrsEnqSystemsData.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725ENST`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Address space SToken
"""

r725ensn_GrsEnqSystemsData : Final[Field] = Field(
    name='r725ensn_GrsEnqSystemsData',
    origin='R725ENSN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Service class name

SMF Info
--------
    Field: `R725ENSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Service class name
"""
r725ensn_GrsEnqSystemsData.__doc__ = """Service class name

SMF Info
--------
    Field: `R725ENSN`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Service class name
"""

r725ensc_GrsEnqSystemsData : Final[Field] = Field(
    name='r725ensc_GrsEnqSystemsData',
    origin='R725ENSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems

SMF Info
--------
    Field: `R725ENSC`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems
"""
r725ensc_GrsEnqSystemsData.__doc__ = """Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems

SMF Info
--------
    Field: `R725ENSC`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Enqueue Scope Type X'01' = Scope=Step X'02' = Scope=System X'03' = Scope=Systems
"""

r725enrc_GrsEnqSystemsData : Final[Field] = Field(
    name='r725enrc_GrsEnqSystemsData',
    origin='R725ENRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENRC`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""
r725enrc_GrsEnqSystemsData.__doc__ = """Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENRC`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Number of GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""

r725ensu_GrsEnqSystemsData : Final[Field] = Field(
    name='r725ensu_GrsEnqSystemsData',
    origin='R725ENSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space

SMF Info
--------
    Field: `R725ENSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space
"""
r725ensu_GrsEnqSystemsData.__doc__ = """Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space

SMF Info
--------
    Field: `R725ENSU`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Number of GRS ENQ requests with the scope as specified in R725ENSC that were suspended for this address space
"""

r725enti_GrsEnqSystemsData : Final[Field] = Field(
    name='r725enti_GrsEnqSystemsData',
    origin='R725ENTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""
r725enti_GrsEnqSystemsData.__doc__ = """Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space

SMF Info
--------
    Field: `R725ENTI`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Total amount of contention time in milliseconds that was caused by GRS ENQ requests with the scope as specified in R725ENSC for this address space
"""

r725ensq_GrsEnqSystemsData : Final[Field] = Field(
    name='r725ensq_GrsEnqSystemsData',
    origin='R725ENSQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Sum of squares of the individual contention times in milliseconds

SMF Info
--------
    Field: `R725ENSQ`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Sum of squares of the individual contention times in milliseconds
"""
r725ensq_GrsEnqSystemsData.__doc__ = """Sum of squares of the individual contention times in milliseconds

SMF Info
--------
    Field: `R725ENSQ`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Sum of squares of the individual contention times in milliseconds
"""

r725en_entry_index_GrsEnqSystemsData : Final[Field] = Field(
    name='r725en_entry_index_GrsEnqSystemsData',
    origin='R725EN_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725EN_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Artificial Entry Index
"""
r725en_entry_index_GrsEnqSystemsData.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725EN_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Artificial Entry Index
"""

r725en_service_class_list_index_GrsEnqSystemsData : Final[Field] = Field(
    name='r725en_service_class_list_index_GrsEnqSystemsData',
    origin='R725EN_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725EN_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""
r725en_service_class_list_index_GrsEnqSystemsData.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725EN_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Service class list index (See ASICLX in ERBASIG3)
"""

r725en_asi_flag_GrsEnqSystemsData : Final[Field] = Field(
    name='r725en_asi_flag_GrsEnqSystemsData',
    origin='R725EN_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725EN_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725en_asi_flag_GrsEnqSystemsData.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725EN_ASI_FLAG`
    Record: `SMF72S5`
    Map: `SMF72_SUBTYPE5_GRS_ENQ_SYSTEMS_DATA`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""

r725qsjn : Final[Field] = Field(
    name='r725qsjn',
    origin='R725QSJN',
    type=FieldType.STRING,
    record=record,
    record_map=R725QSAD,
)
"""Name of job

SMF Info
--------
    Field: `R725QSJN`
    Record: `SMF72S5`
    Map: `R725QSAD`

Name of job
"""
r725qsjn.__doc__ = """Name of job

SMF Info
--------
    Field: `R725QSJN`
    Record: `SMF72S5`
    Map: `R725QSAD`

Name of job
"""

r725qssp : Final[Field] = Field(
    name='r725qssp',
    origin='R725QSSP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Service class period

SMF Info
--------
    Field: `R725QSSP`
    Record: `SMF72S5`
    Map: `R725QSAD`

Service class period
"""
r725qssp.__doc__ = """Service class period

SMF Info
--------
    Field: `R725QSSP`
    Record: `SMF72S5`
    Map: `R725QSAD`

Service class period
"""

r725qsas : Final[Field] = Field(
    name='r725qsas',
    origin='R725QSAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Address space ID

SMF Info
--------
    Field: `R725QSAS`
    Record: `SMF72S5`
    Map: `R725QSAD`

Address space ID
"""
r725qsas.__doc__ = """Address space ID

SMF Info
--------
    Field: `R725QSAS`
    Record: `SMF72S5`
    Map: `R725QSAD`

Address space ID
"""

r725qsst : Final[Field] = Field(
    name='r725qsst',
    origin='R725QSST',
    type=FieldType.STRING,
    record=record,
    record_map=R725QSAD,
)
"""Address space SToken

SMF Info
--------
    Field: `R725QSST`
    Record: `SMF72S5`
    Map: `R725QSAD`

Address space SToken
"""
r725qsst.__doc__ = """Address space SToken

SMF Info
--------
    Field: `R725QSST`
    Record: `SMF72S5`
    Map: `R725QSAD`

Address space SToken
"""

r725qssn : Final[Field] = Field(
    name='r725qssn',
    origin='R725QSSN',
    type=FieldType.STRING,
    record=record,
    record_map=R725QSAD,
)
"""Service class name

SMF Info
--------
    Field: `R725QSSN`
    Record: `SMF72S5`
    Map: `R725QSAD`

Service class name
"""
r725qssn.__doc__ = """Service class name

SMF Info
--------
    Field: `R725QSSN`
    Record: `SMF72S5`
    Map: `R725QSAD`

Service class name
"""

r725qsrc : Final[Field] = Field(
    name='r725qsrc',
    origin='R725QSRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Number of requests including START and RESUME, but not QUIT requests

SMF Info
--------
    Field: `R725QSRC`
    Record: `SMF72S5`
    Map: `R725QSAD`

Number of requests including START and RESUME, but not QUIT requests
"""
r725qsrc.__doc__ = """Number of requests including START and RESUME, but not QUIT requests

SMF Info
--------
    Field: `R725QSRC`
    Record: `SMF72S5`
    Map: `R725QSAD`

Number of requests including START and RESUME, but not QUIT requests
"""

r725qssc : Final[Field] = Field(
    name='r725qssc',
    origin='R725QSSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Number of specific requests with GQSCAN requests specified by QNAME and RNAME or ISGQUERY requests specifying a search by ENQTOKEN

SMF Info
--------
    Field: `R725QSSC`
    Record: `SMF72S5`
    Map: `R725QSAD`

Number of specific requests with GQSCAN requests specified by QNAME and RNAME or ISGQUERY requests specifying a search by ENQTOKEN
"""
r725qssc.__doc__ = """Number of specific requests with GQSCAN requests specified by QNAME and RNAME or ISGQUERY requests specifying a search by ENQTOKEN

SMF Info
--------
    Field: `R725QSSC`
    Record: `SMF72S5`
    Map: `R725QSAD`

Number of specific requests with GQSCAN requests specified by QNAME and RNAME or ISGQUERY requests specifying a search by ENQTOKEN
"""

r725qsrr : Final[Field] = Field(
    name='r725qsrr',
    origin='R725QSRR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Total number of resources returned for these requests.

SMF Info
--------
    Field: `R725QSRR`
    Record: `SMF72S5`
    Map: `R725QSAD`

Total number of resources returned for these requests.
"""
r725qsrr.__doc__ = """Total number of resources returned for these requests.

SMF Info
--------
    Field: `R725QSRR`
    Record: `SMF72S5`
    Map: `R725QSAD`

Total number of resources returned for these requests.
"""

r725qsrq : Final[Field] = Field(
    name='r725qsrq',
    origin='R725QSRQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Sum of squares of number of resources returned for these requests

SMF Info
--------
    Field: `R725QSRQ`
    Record: `SMF72S5`
    Map: `R725QSAD`

Sum of squares of number of resources returned for these requests
"""
r725qsrq.__doc__ = """Sum of squares of number of resources returned for these requests

SMF Info
--------
    Field: `R725QSRQ`
    Record: `SMF72S5`
    Map: `R725QSAD`

Sum of squares of number of resources returned for these requests
"""

r725qsti : Final[Field] = Field(
    name='r725qsti',
    origin='R725QSTI',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Total amount of execution times within GRS for these requests in microseconds

SMF Info
--------
    Field: `R725QSTI`
    Record: `SMF72S5`
    Map: `R725QSAD`

Total amount of execution times within GRS for these requests in microseconds
"""
r725qsti.__doc__ = """Total amount of execution times within GRS for these requests in microseconds

SMF Info
--------
    Field: `R725QSTI`
    Record: `SMF72S5`
    Map: `R725QSAD`

Total amount of execution times within GRS for these requests in microseconds
"""

r725qstq : Final[Field] = Field(
    name='r725qstq',
    origin='R725QSTQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Sum of squares of individual request execution times in microseconds

SMF Info
--------
    Field: `R725QSTQ`
    Record: `SMF72S5`
    Map: `R725QSAD`

Sum of squares of individual request execution times in microseconds
"""
r725qstq.__doc__ = """Sum of squares of individual request execution times in microseconds

SMF Info
--------
    Field: `R725QSTQ`
    Record: `SMF72S5`
    Map: `R725QSAD`

Sum of squares of individual request execution times in microseconds
"""

r725qs_entry_index : Final[Field] = Field(
    name='r725qs_entry_index',
    origin='R725QS_ENTRY_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Artificial Entry Index

SMF Info
--------
    Field: `R725QS_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725QSAD`

Artificial Entry Index
"""
r725qs_entry_index.__doc__ = """Artificial Entry Index

SMF Info
--------
    Field: `R725QS_ENTRY_INDEX`
    Record: `SMF72S5`
    Map: `R725QSAD`

Artificial Entry Index
"""

r725qs_service_class_list_index : Final[Field] = Field(
    name='r725qs_service_class_list_index',
    origin='R725QS_SERVICE_CLASS_LIST_INDEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R725QSAD,
)
"""Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725QS_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725QSAD`

Service class list index (See ASICLX in ERBASIG3)
"""
r725qs_service_class_list_index.__doc__ = """Service class list index (See ASICLX in ERBASIG3)

SMF Info
--------
    Field: `R725QS_SERVICE_CLASS_LIST_INDEX`
    Record: `SMF72S5`
    Map: `R725QSAD`

Service class list index (See ASICLX in ERBASIG3)
"""

r725qs_asi_flag : Final[Field] = Field(
    name='r725qs_asi_flag',
    origin='R725QS_ASI_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=R725QSAD,
)
"""Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725QS_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725QSAD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
r725qs_asi_flag.__doc__ = """Flag Byte (See ASIFLAG1 in ERBASIG3)

SMF Info
--------
    Field: `R725QS_ASI_FLAG`
    Record: `SMF72S5`
    Map: `R725QSAD`

Flag Byte (See ASIFLAG1 in ERBASIG3)
"""
