# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""None"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=30,
                                smf_subtype=5,
                                spec='None',
                                post=None)
"""None"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF30PSS: Final[RecordMap] = RecordMap(
    origin='SMF30PSS',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30ID: Final[RecordMap] = RecordMap(
    origin='SMF30ID',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30URA: Final[RecordMap] = RecordMap(
    origin='SMF30URA',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30CMP: Final[RecordMap] = RecordMap(
    origin='SMF30CMP',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30CAS: Final[RecordMap] = RecordMap(
    origin='SMF30CAS',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30SAP: Final[RecordMap] = RecordMap(
    origin='SMF30SAP',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30PRF: Final[RecordMap] = RecordMap(
    origin='SMF30PRF',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30OPS: Final[RecordMap] = RecordMap(
    origin='SMF30OPS',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30DR: Final[RecordMap] = RecordMap(
    origin='SMF30DR',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30AR: Final[RecordMap] = RecordMap(
    origin='SMF30AR',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30CDS: Final[RecordMap] = RecordMap(
    origin='SMF30CDS',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30USS: Final[RecordMap] = RecordMap(
    origin='SMF30USS',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30CONTAINER: Final[RecordMap] = RecordMap(
    origin='SMF30CONTAINER',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='',
    post=None,
    record_mapping=False)
""""""
SMF30EXP: Final[RecordMap] = RecordMap(
    origin='SMF30EXP',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30ACS: Final[RecordMap] = RecordMap(
    origin='SMF30ACS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30OP: Final[RecordMap] = RecordMap(
    origin='SMF30OP',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30RM: Final[RecordMap] = RecordMap(
    origin='SMF30RM',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30UD: Final[RecordMap] = RecordMap(
    origin='SMF30UD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30MSE: Final[RecordMap] = RecordMap(
    origin='SMF30MSE',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30CRYPC: Final[RecordMap] = RecordMap(
    origin='SMF30CRYPC',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""
SMF30NNPIC: Final[RecordMap] = RecordMap(
    origin='SMF30NNPIC',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='None',
    post=None,
    record_mapping=False)
"""None"""

date : Final[Field] = Field(
    name='date',
    origin='SMF30DTE',
    type=FieldType.DATE,
    record=record,
)
"""RECORD WRITTEN DATE

SMF Info
--------
    Field: `SMF30DTE`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD WRITTEN DATE
"""
date.__doc__ = """RECORD WRITTEN DATE

SMF Info
--------
    Field: `SMF30DTE`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD WRITTEN DATE
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF30TME',
    type=FieldType.TIME,
    record=record,
)
"""RECORD WRITTEN TIME

SMF Info
--------
    Field: `SMF30TME`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD WRITTEN TIME
"""
time.__doc__ = """RECORD WRITTEN TIME

SMF Info
--------
    Field: `SMF30TME`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD WRITTEN TIME
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF30DTE`), `time`(`SMF30TME`)
    Record: `SMF30S5`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF30DTE`), `time`(`SMF30TME`)
    Record: `SMF30S5`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

record_len : Final[Field] = Field(
    name='record_len',
    origin='SMF30LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD LENGTH

SMF Info
--------
    Field: `SMF30LEN`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD LENGTH
"""
record_len.__doc__ = """RECORD LENGTH

SMF Info
--------
    Field: `SMF30LEN`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD LENGTH
"""

seg_descriptor : Final[Field] = Field(
    name='seg_descriptor',
    origin='SMF30SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF30SEG`
    Record: `SMF30S5`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg_descriptor.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF30SEG`
    Record: `SMF30S5`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF30FLG',
    type=FieldType.STRING,
    record=record,
)
"""HEADER FLAG BYTE

SMF Info
--------
    Field: `SMF30FLG`
    Record: `SMF30S5`
    Map: Not part of a map

HEADER FLAG BYTE
"""
flg.__doc__ = """HEADER FLAG BYTE

SMF Info
--------
    Field: `SMF30FLG`
    Record: `SMF30S5`
    Map: Not part of a map

HEADER FLAG BYTE
"""

rec_type : Final[Field] = Field(
    name='rec_type',
    origin='SMF30RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE - 30

SMF Info
--------
    Field: `SMF30RTY`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD TYPE - 30
"""
rec_type.__doc__ = """RECORD TYPE - 30

SMF Info
--------
    Field: `SMF30RTY`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD TYPE - 30
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF30SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM IDENTIFIER

SMF Info
--------
    Field: `SMF30SID`
    Record: `SMF30S5`
    Map: Not part of a map

SYSTEM IDENTIFIER
"""
sid.__doc__ = """SYSTEM IDENTIFIER

SMF Info
--------
    Field: `SMF30SID`
    Record: `SMF30S5`
    Map: Not part of a map

SYSTEM IDENTIFIER
"""

work_type : Final[Field] = Field(
    name='work_type',
    origin='SMF30WID',
    type=FieldType.STRING,
    record=record,
)
"""WORK CLASS ID

SMF Info
--------
    Field: `SMF30WID`
    Record: `SMF30S5`
    Map: Not part of a map

WORK CLASS ID
"""
work_type.__doc__ = """WORK CLASS ID

SMF Info
--------
    Field: `SMF30WID`
    Record: `SMF30S5`
    Map: Not part of a map

WORK CLASS ID
"""

rec_subtype : Final[Field] = Field(
    name='rec_subtype',
    origin='SMF30STP',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD SUBTYPE

SMF Info
--------
    Field: `SMF30STP`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD SUBTYPE
"""
rec_subtype.__doc__ = """RECORD SUBTYPE

SMF Info
--------
    Field: `SMF30STP`
    Record: `SMF30S5`
    Map: Not part of a map

RECORD SUBTYPE
"""

subsystem_offset : Final[Field] = Field(
    name='subsystem_offset',
    origin='SMF30SOF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO SUBSYSTEM SEGMENT

SMF Info
--------
    Field: `SMF30SOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO SUBSYSTEM SEGMENT
"""
subsystem_offset.__doc__ = """OFFSET TO SUBSYSTEM SEGMENT

SMF Info
--------
    Field: `SMF30SOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO SUBSYSTEM SEGMENT
"""

subsystem_len : Final[Field] = Field(
    name='subsystem_len',
    origin='SMF30SLN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF SUBSYSTEM SEGMENT

SMF Info
--------
    Field: `SMF30SLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF SUBSYSTEM SEGMENT
"""
subsystem_len.__doc__ = """LENGTH OF SUBSYSTEM SEGMENT

SMF Info
--------
    Field: `SMF30SLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF SUBSYSTEM SEGMENT
"""

subsystem_num : Final[Field] = Field(
    name='subsystem_num',
    origin='SMF30SON',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF SUBSYSTEM SEGMENTS

SMF Info
--------
    Field: `SMF30SON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF SUBSYSTEM SEGMENTS
"""
subsystem_num.__doc__ = """NUMBER OF SUBSYSTEM SEGMENTS

SMF Info
--------
    Field: `SMF30SON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF SUBSYSTEM SEGMENTS
"""

identification_offset : Final[Field] = Field(
    name='identification_offset',
    origin='SMF30IOF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO IDENTIFICATION SEGMENT

SMF Info
--------
    Field: `SMF30IOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO IDENTIFICATION SEGMENT
"""
identification_offset.__doc__ = """OFFSET TO IDENTIFICATION SEGMENT

SMF Info
--------
    Field: `SMF30IOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO IDENTIFICATION SEGMENT
"""

identification_len : Final[Field] = Field(
    name='identification_len',
    origin='SMF30ILN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF IDENTIFICATION SEGMENT

SMF Info
--------
    Field: `SMF30ILN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF IDENTIFICATION SEGMENT
"""
identification_len.__doc__ = """LENGTH OF IDENTIFICATION SEGMENT

SMF Info
--------
    Field: `SMF30ILN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF IDENTIFICATION SEGMENT
"""

identification_num : Final[Field] = Field(
    name='identification_num',
    origin='SMF30ION',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF IDENTIFICATION SEGMENT

SMF Info
--------
    Field: `SMF30ION`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF IDENTIFICATION SEGMENT
"""
identification_num.__doc__ = """NUMBER OF IDENTIFICATION SEGMENT

SMF Info
--------
    Field: `SMF30ION`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF IDENTIFICATION SEGMENT
"""

io_offset : Final[Field] = Field(
    name='io_offset',
    origin='SMF30UOF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO I/O ACTIVITY SEGMENT

SMF Info
--------
    Field: `SMF30UOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO I/O ACTIVITY SEGMENT
"""
io_offset.__doc__ = """OFFSET TO I/O ACTIVITY SEGMENT

SMF Info
--------
    Field: `SMF30UOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO I/O ACTIVITY SEGMENT
"""

io_len : Final[Field] = Field(
    name='io_len',
    origin='SMF30ULN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF I/O ACTIVITY SEGMENT

SMF Info
--------
    Field: `SMF30ULN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF I/O ACTIVITY SEGMENT
"""
io_len.__doc__ = """LENGTH OF I/O ACTIVITY SEGMENT

SMF Info
--------
    Field: `SMF30ULN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF I/O ACTIVITY SEGMENT
"""

io_num : Final[Field] = Field(
    name='io_num',
    origin='SMF30UON',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF I/O ACTIVITY SEGMENTS

SMF Info
--------
    Field: `SMF30UON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF I/O ACTIVITY SEGMENTS
"""
io_num.__doc__ = """NUMBER OF I/O ACTIVITY SEGMENTS

SMF Info
--------
    Field: `SMF30UON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF I/O ACTIVITY SEGMENTS
"""

completion_offset : Final[Field] = Field(
    name='completion_offset',
    origin='SMF30TOF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO COMPLETION SEGMENT

SMF Info
--------
    Field: `SMF30TOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO COMPLETION SEGMENT
"""
completion_offset.__doc__ = """OFFSET TO COMPLETION SEGMENT

SMF Info
--------
    Field: `SMF30TOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO COMPLETION SEGMENT
"""

completion_len : Final[Field] = Field(
    name='completion_len',
    origin='SMF30TLN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF COMPLETION SEGMENT

SMF Info
--------
    Field: `SMF30TLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF COMPLETION SEGMENT
"""
completion_len.__doc__ = """LENGTH OF COMPLETION SEGMENT

SMF Info
--------
    Field: `SMF30TLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF COMPLETION SEGMENT
"""

completion_num : Final[Field] = Field(
    name='completion_num',
    origin='SMF30TON',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF COMPLETION

SMF Info
--------
    Field: `SMF30TON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF COMPLETION
"""
completion_num.__doc__ = """NUMBER OF COMPLETION

SMF Info
--------
    Field: `SMF30TON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF COMPLETION
"""

processor_offset : Final[Field] = Field(
    name='processor_offset',
    origin='SMF30COF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO CPU ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30COF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO CPU ACCOUNTING SEGMENT
"""
processor_offset.__doc__ = """OFFSET TO CPU ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30COF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO CPU ACCOUNTING SEGMENT
"""

processor_len : Final[Field] = Field(
    name='processor_len',
    origin='SMF30CLN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF CPU ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30CLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF CPU ACCOUNTING SEGMENT
"""
processor_len.__doc__ = """LENGTH OF CPU ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30CLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF CPU ACCOUNTING SEGMENT
"""

processor_num : Final[Field] = Field(
    name='processor_num',
    origin='SMF30CON',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF CPU ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30CON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF CPU ACCOUNTING SEGMENT
"""
processor_num.__doc__ = """NUMBER OF CPU ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30CON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF CPU ACCOUNTING SEGMENT
"""

accounting_offset : Final[Field] = Field(
    name='accounting_offset',
    origin='SMF30AOF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30AOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO ACCOUNTING SEGMENT
"""
accounting_offset.__doc__ = """OFFSET TO ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30AOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO ACCOUNTING SEGMENT
"""

accounting_len : Final[Field] = Field(
    name='accounting_len',
    origin='SMF30ALN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30ALN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF ACCOUNTING SEGMENT
"""
accounting_len.__doc__ = """LENGTH OF ACCOUNTING SEGMENT

SMF Info
--------
    Field: `SMF30ALN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF ACCOUNTING SEGMENT
"""

accounting_num : Final[Field] = Field(
    name='accounting_num',
    origin='SMF30AON',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF ACCOUNTING SEGMENTS

SMF Info
--------
    Field: `SMF30AON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF ACCOUNTING SEGMENTS
"""
accounting_num.__doc__ = """NUMBER OF ACCOUNTING SEGMENTS

SMF Info
--------
    Field: `SMF30AON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF ACCOUNTING SEGMENTS
"""

storage_offset : Final[Field] = Field(
    name='storage_offset',
    origin='SMF30ROF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO STORAGE SEGMENT

SMF Info
--------
    Field: `SMF30ROF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO STORAGE SEGMENT
"""
storage_offset.__doc__ = """OFFSET TO STORAGE SEGMENT

SMF Info
--------
    Field: `SMF30ROF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO STORAGE SEGMENT
"""

storage_len : Final[Field] = Field(
    name='storage_len',
    origin='SMF30RLN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF STORAGE SEGMENT

SMF Info
--------
    Field: `SMF30RLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF STORAGE SEGMENT
"""
storage_len.__doc__ = """LENGTH OF STORAGE SEGMENT

SMF Info
--------
    Field: `SMF30RLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF STORAGE SEGMENT
"""

storage_num : Final[Field] = Field(
    name='storage_num',
    origin='SMF30RON',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF STORAGE SEGMENTS

SMF Info
--------
    Field: `SMF30RON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF STORAGE SEGMENTS
"""
storage_num.__doc__ = """NUMBER OF STORAGE SEGMENTS

SMF Info
--------
    Field: `SMF30RON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF STORAGE SEGMENTS
"""

performance_offset : Final[Field] = Field(
    name='performance_offset',
    origin='SMF30POF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO PERFORMANCE SEGMENT

SMF Info
--------
    Field: `SMF30POF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO PERFORMANCE SEGMENT
"""
performance_offset.__doc__ = """OFFSET TO PERFORMANCE SEGMENT

SMF Info
--------
    Field: `SMF30POF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO PERFORMANCE SEGMENT
"""

performance_len : Final[Field] = Field(
    name='performance_len',
    origin='SMF30PLN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF PERFORMANCE SEGMENT

SMF Info
--------
    Field: `SMF30PLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF PERFORMANCE SEGMENT
"""
performance_len.__doc__ = """LENGTH OF PERFORMANCE SEGMENT

SMF Info
--------
    Field: `SMF30PLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF PERFORMANCE SEGMENT
"""

performance_num : Final[Field] = Field(
    name='performance_num',
    origin='SMF30PON',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF PERFORMANCE SEGMENTS

SMF Info
--------
    Field: `SMF30PON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF PERFORMANCE SEGMENTS
"""
performance_num.__doc__ = """NUMBER OF PERFORMANCE SEGMENTS

SMF Info
--------
    Field: `SMF30PON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF PERFORMANCE SEGMENTS
"""

operator_offset : Final[Field] = Field(
    name='operator_offset',
    origin='SMF30OOF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO OPERATOR SEGMENT

SMF Info
--------
    Field: `SMF30OOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO OPERATOR SEGMENT
"""
operator_offset.__doc__ = """OFFSET TO OPERATOR SEGMENT

SMF Info
--------
    Field: `SMF30OOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO OPERATOR SEGMENT
"""

operator_len : Final[Field] = Field(
    name='operator_len',
    origin='SMF30OLN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF OPERATOR SEGMENT

SMF Info
--------
    Field: `SMF30OLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF OPERATOR SEGMENT
"""
operator_len.__doc__ = """LENGTH OF OPERATOR SEGMENT

SMF Info
--------
    Field: `SMF30OLN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF OPERATOR SEGMENT
"""

operator_num : Final[Field] = Field(
    name='operator_num',
    origin='SMF30OON',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF OPERATOR SEGMENTS

SMF Info
--------
    Field: `SMF30OON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF OPERATOR SEGMENTS
"""
operator_num.__doc__ = """NUMBER OF OPERATOR SEGMENTS

SMF Info
--------
    Field: `SMF30OON`
    Record: `SMF30S5`
    Map: Not part of a map

NUMBER OF OPERATOR SEGMENTS
"""

excp_offset : Final[Field] = Field(
    name='excp_offset',
    origin='SMF30EOF',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO EXCP SEGMENT

SMF Info
--------
    Field: `SMF30EOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO EXCP SEGMENT
"""
excp_offset.__doc__ = """OFFSET TO EXCP SEGMENT

SMF Info
--------
    Field: `SMF30EOF`
    Record: `SMF30S5`
    Map: Not part of a map

OFFSET TO EXCP SEGMENT
"""

excp_len : Final[Field] = Field(
    name='excp_len',
    origin='SMF30ELN',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF EXCP SEGMENT

SMF Info
--------
    Field: `SMF30ELN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF EXCP SEGMENT
"""
excp_len.__doc__ = """LENGTH OF EXCP SEGMENT

SMF Info
--------
    Field: `SMF30ELN`
    Record: `SMF30S5`
    Map: Not part of a map

LENGTH OF EXCP SEGMENT
"""

excp_num : Final[Field] = Field(
    name='excp_num',
    origin='SMF30EON',
    type=FieldType.INTEGER,
    record=record,
)
"""NO OF EXCP SEGS - THIS RECORD

SMF Info
--------
    Field: `SMF30EON`
    Record: `SMF30S5`
    Map: Not part of a map

NO OF EXCP SEGS - THIS RECORD
"""
excp_num.__doc__ = """NO OF EXCP SEGS - THIS RECORD

SMF Info
--------
    Field: `SMF30EON`
    Record: `SMF30S5`
    Map: Not part of a map

NO OF EXCP SEGS - THIS RECORD
"""

excp_num_subseq_legacy : Final[Field] = Field(
    name='excp_num_subseq_legacy',
    origin='SMF30EOR',
    type=FieldType.INTEGER,
    record=record,
)
"""NO OF EXCP SEGS - OTHER RECORDS

SMF Info
--------
    Field: `SMF30EOR`
    Record: `SMF30S5`
    Map: Not part of a map

NO OF EXCP SEGS - OTHER RECORDS
"""
excp_num_subseq_legacy.__doc__ = """NO OF EXCP SEGS - OTHER RECORDS

SMF Info
--------
    Field: `SMF30EOR`
    Record: `SMF30S5`
    Map: Not part of a map

NO OF EXCP SEGS - OTHER RECORDS
"""

excp_num_subseq : Final[Field] = Field(
    name='excp_num_subseq',
    origin='SMF30EOS',
    type=FieldType.INTEGER,
    record=record,
)
"""NO OF EXCP SEGS - OTHER RECORDS

SMF Info
--------
    Field: `SMF30EOS`
    Record: `SMF30S5`
    Map: Not part of a map

NO OF EXCP SEGS - OTHER RECORDS
"""
excp_num_subseq.__doc__ = """NO OF EXCP SEGS - OTHER RECORDS

SMF Info
--------
    Field: `SMF30EOS`
    Record: `SMF30S5`
    Map: Not part of a map

NO OF EXCP SEGS - OTHER RECORDS
"""

appc_mvs_offset : Final[Field] = Field(
    name='appc_mvs_offset',
    origin='SMF30DRO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset of APPC/MVS Resource Section

SMF Info
--------
    Field: `SMF30DRO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of APPC/MVS Resource Section
"""
appc_mvs_offset.__doc__ = """Offset of APPC/MVS Resource Section

SMF Info
--------
    Field: `SMF30DRO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of APPC/MVS Resource Section
"""

appc_mvs_len : Final[Field] = Field(
    name='appc_mvs_len',
    origin='SMF30DRL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of APPC/MVS Resource Section

SMF Info
--------
    Field: `SMF30DRL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of APPC/MVS Resource Section
"""
appc_mvs_len.__doc__ = """Length of APPC/MVS Resource Section

SMF Info
--------
    Field: `SMF30DRL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of APPC/MVS Resource Section
"""

appc_mvs_num : Final[Field] = Field(
    name='appc_mvs_num',
    origin='SMF30DRN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of APPC/MVS Resource Sections

SMF Info
--------
    Field: `SMF30DRN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of APPC/MVS Resource Sections
"""
appc_mvs_num.__doc__ = """Number of APPC/MVS Resource Sections

SMF Info
--------
    Field: `SMF30DRN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of APPC/MVS Resource Sections
"""

appc_mvs_cum_offset : Final[Field] = Field(
    name='appc_mvs_cum_offset',
    origin='SMF30ARO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset of APPC/MVS Cumulative Resource Section

SMF Info
--------
    Field: `SMF30ARO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of APPC/MVS Cumulative Resource Section
"""
appc_mvs_cum_offset.__doc__ = """Offset of APPC/MVS Cumulative Resource Section

SMF Info
--------
    Field: `SMF30ARO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of APPC/MVS Cumulative Resource Section
"""

appc_mvs_cum_len : Final[Field] = Field(
    name='appc_mvs_cum_len',
    origin='SMF30ARL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of APPC/MVS Cumulative Resource Section

SMF Info
--------
    Field: `SMF30ARL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of APPC/MVS Cumulative Resource Section
"""
appc_mvs_cum_len.__doc__ = """Length of APPC/MVS Cumulative Resource Section

SMF Info
--------
    Field: `SMF30ARL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of APPC/MVS Cumulative Resource Section
"""

appc_mvs_cum_num : Final[Field] = Field(
    name='appc_mvs_cum_num',
    origin='SMF30ARN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of APPC/MVS Cumulative Resource Sections

SMF Info
--------
    Field: `SMF30ARN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of APPC/MVS Cumulative Resource Sections
"""
appc_mvs_cum_num.__doc__ = """Number of APPC/MVS Cumulative Resource Sections

SMF Info
--------
    Field: `SMF30ARN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of APPC/MVS Cumulative Resource Sections
"""

unix_process_offset : Final[Field] = Field(
    name='unix_process_offset',
    origin='SMF30OPO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset of OpenMVS Sections

SMF Info
--------
    Field: `SMF30OPO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of OpenMVS Sections
"""
unix_process_offset.__doc__ = """Offset of OpenMVS Sections

SMF Info
--------
    Field: `SMF30OPO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of OpenMVS Sections
"""

unix_process_len : Final[Field] = Field(
    name='unix_process_len',
    origin='SMF30OPL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of OpenMVS Section

SMF Info
--------
    Field: `SMF30OPL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of OpenMVS Section
"""
unix_process_len.__doc__ = """Length of OpenMVS Section

SMF Info
--------
    Field: `SMF30OPL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of OpenMVS Section
"""

unix_process_num : Final[Field] = Field(
    name='unix_process_num',
    origin='SMF30OPN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of OpenMVS Sections in This Record

SMF Info
--------
    Field: `SMF30OPN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of OpenMVS Sections in This Record
"""
unix_process_num.__doc__ = """Number of OpenMVS Sections in This Record

SMF Info
--------
    Field: `SMF30OPN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of OpenMVS Sections in This Record
"""

unix_process_subseq_num : Final[Field] = Field(
    name='unix_process_subseq_num',
    origin='SMF30OPM',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of OpenMVS Sections in Subsequent Records

SMF Info
--------
    Field: `SMF30OPM`
    Record: `SMF30S5`
    Map: Not part of a map

Number of OpenMVS Sections in Subsequent Records
"""
unix_process_subseq_num.__doc__ = """Number of OpenMVS Sections in Subsequent Records

SMF Info
--------
    Field: `SMF30OPM`
    Record: `SMF30S5`
    Map: Not part of a map

Number of OpenMVS Sections in Subsequent Records
"""

usage_data_offset : Final[Field] = Field(
    name='usage_data_offset',
    origin='SMF30UDO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset of Usage Sections

SMF Info
--------
    Field: `SMF30UDO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of Usage Sections
"""
usage_data_offset.__doc__ = """Offset of Usage Sections

SMF Info
--------
    Field: `SMF30UDO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of Usage Sections
"""

usage_data_len : Final[Field] = Field(
    name='usage_data_len',
    origin='SMF30UDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Usage Section

SMF Info
--------
    Field: `SMF30UDL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of Usage Section
"""
usage_data_len.__doc__ = """Length of Usage Section

SMF Info
--------
    Field: `SMF30UDL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of Usage Section
"""

usage_data_num : Final[Field] = Field(
    name='usage_data_num',
    origin='SMF30UDN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Usage Sections in This Record

SMF Info
--------
    Field: `SMF30UDN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Usage Sections in This Record
"""
usage_data_num.__doc__ = """Number of Usage Sections in This Record

SMF Info
--------
    Field: `SMF30UDN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Usage Sections in This Record
"""

usage_data_subseq_num : Final[Field] = Field(
    name='usage_data_subseq_num',
    origin='SMF30UDS',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Usage Sections in Subsequent Records

SMF Info
--------
    Field: `SMF30UDS`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Usage Sections in Subsequent Records
"""
usage_data_subseq_num.__doc__ = """Number of Usage Sections in Subsequent Records

SMF Info
--------
    Field: `SMF30UDS`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Usage Sections in Subsequent Records
"""

restart_mgmt_offset : Final[Field] = Field(
    name='restart_mgmt_offset',
    origin='SMF30RMO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset of first ARM Section from beginning of record (including the RDW)

SMF Info
--------
    Field: `SMF30RMO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of first ARM Section from beginning of record (including the RDW)
"""
restart_mgmt_offset.__doc__ = """Offset of first ARM Section from beginning of record (including the RDW)

SMF Info
--------
    Field: `SMF30RMO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset of first ARM Section from beginning of record (including the RDW)
"""

restart_mgmt_len : Final[Field] = Field(
    name='restart_mgmt_len',
    origin='SMF30RML',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of each ARM Section on the record

SMF Info
--------
    Field: `SMF30RML`
    Record: `SMF30S5`
    Map: Not part of a map

Length of each ARM Section on the record
"""
restart_mgmt_len.__doc__ = """Length of each ARM Section on the record

SMF Info
--------
    Field: `SMF30RML`
    Record: `SMF30S5`
    Map: Not part of a map

Length of each ARM Section on the record
"""

restart_mgmt_num : Final[Field] = Field(
    name='restart_mgmt_num',
    origin='SMF30RMN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of ARM sections on this record

SMF Info
--------
    Field: `SMF30RMN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of ARM sections on this record
"""
restart_mgmt_num.__doc__ = """Number of ARM sections on this record

SMF Info
--------
    Field: `SMF30RMN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of ARM sections on this record
"""

restart_mgmt_subseq_num : Final[Field] = Field(
    name='restart_mgmt_subseq_num',
    origin='SMF30RMS',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of ARM sections on subsequent records

SMF Info
--------
    Field: `SMF30RMS`
    Record: `SMF30S5`
    Map: Not part of a map

Number of ARM sections on subsequent records
"""
restart_mgmt_subseq_num.__doc__ = """Number of ARM sections on subsequent records

SMF Info
--------
    Field: `SMF30RMS`
    Record: `SMF30S5`
    Map: Not part of a map

Number of ARM sections on subsequent records
"""

msys_encl_rem_system_data_offset : Final[Field] = Field(
    name='msys_encl_rem_system_data_offset',
    origin='SMF30MOF',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to MultiSystem Enclave Remote System Data section

SMF Info
--------
    Field: `SMF30MOF`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to MultiSystem Enclave Remote System Data section
"""
msys_encl_rem_system_data_offset.__doc__ = """Offset to MultiSystem Enclave Remote System Data section

SMF Info
--------
    Field: `SMF30MOF`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to MultiSystem Enclave Remote System Data section
"""

msys_encl_rem_system_data_len : Final[Field] = Field(
    name='msys_encl_rem_system_data_len',
    origin='SMF30MLN',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of MultiSystem Enclave Remote System Data section

SMF Info
--------
    Field: `SMF30MLN`
    Record: `SMF30S5`
    Map: Not part of a map

Length of MultiSystem Enclave Remote System Data section
"""
msys_encl_rem_system_data_len.__doc__ = """Length of MultiSystem Enclave Remote System Data section

SMF Info
--------
    Field: `SMF30MLN`
    Record: `SMF30S5`
    Map: Not part of a map

Length of MultiSystem Enclave Remote System Data section
"""

msys_encl_rem_system_data_num : Final[Field] = Field(
    name='msys_encl_rem_system_data_num',
    origin='SMF30MNO',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of MultiSystem Enclave Remote System Data sections in this record.

SMF Info
--------
    Field: `SMF30MNO`
    Record: `SMF30S5`
    Map: Not part of a map

Number of MultiSystem Enclave Remote System Data sections in this record.
"""
msys_encl_rem_system_data_num.__doc__ = """Number of MultiSystem Enclave Remote System Data sections in this record.

SMF Info
--------
    Field: `SMF30MNO`
    Record: `SMF30S5`
    Map: Not part of a map

Number of MultiSystem Enclave Remote System Data sections in this record.
"""

msys_encl_rem_system_data_subseq_num : Final[Field] = Field(
    name='msys_encl_rem_system_data_subseq_num',
    origin='SMF30MOS',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of MultiSystem Enclave Remote System Data sections in subsequent records.

SMF Info
--------
    Field: `SMF30MOS`
    Record: `SMF30S5`
    Map: Not part of a map

Number of MultiSystem Enclave Remote System Data sections in subsequent records.
"""
msys_encl_rem_system_data_subseq_num.__doc__ = """Number of MultiSystem Enclave Remote System Data sections in subsequent records.

SMF Info
--------
    Field: `SMF30MOS`
    Record: `SMF30S5`
    Map: Not part of a map

Number of MultiSystem Enclave Remote System Data sections in subsequent records.
"""

counter_data_offset : Final[Field] = Field(
    name='counter_data_offset',
    origin='SMF30CDO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Counter Data Section

SMF Info
--------
    Field: `SMF30CDO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to Counter Data Section
"""
counter_data_offset.__doc__ = """Offset to Counter Data Section

SMF Info
--------
    Field: `SMF30CDO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to Counter Data Section
"""

counter_data_len : Final[Field] = Field(
    name='counter_data_len',
    origin='SMF30CDL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Counter Data Section

SMF Info
--------
    Field: `SMF30CDL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of Counter Data Section
"""
counter_data_len.__doc__ = """Length of Counter Data Section

SMF Info
--------
    Field: `SMF30CDL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of Counter Data Section
"""

counter_data_num : Final[Field] = Field(
    name='counter_data_num',
    origin='SMF30CDN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Counter Data Sections

SMF Info
--------
    Field: `SMF30CDN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Counter Data Sections
"""
counter_data_num.__doc__ = """Number of Counter Data Sections

SMF Info
--------
    Field: `SMF30CDN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Counter Data Sections
"""

zedc_usage_offset : Final[Field] = Field(
    name='zedc_usage_offset',
    origin='SMF30USO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to zEDC usage statistics section

SMF Info
--------
    Field: `SMF30USO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to zEDC usage statistics section
"""
zedc_usage_offset.__doc__ = """Offset to zEDC usage statistics section

SMF Info
--------
    Field: `SMF30USO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to zEDC usage statistics section
"""

zedc_usage_len : Final[Field] = Field(
    name='zedc_usage_len',
    origin='SMF30USL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of zEDC usage statistics section

SMF Info
--------
    Field: `SMF30USL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of zEDC usage statistics section
"""
zedc_usage_len.__doc__ = """Length of zEDC usage statistics section

SMF Info
--------
    Field: `SMF30USL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of zEDC usage statistics section
"""

zedc_usage_num : Final[Field] = Field(
    name='zedc_usage_num',
    origin='SMF30USN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of zEDC usage statistics sections

SMF Info
--------
    Field: `SMF30USN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of zEDC usage statistics sections
"""
zedc_usage_num.__doc__ = """Number of zEDC usage statistics sections

SMF Info
--------
    Field: `SMF30USN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of zEDC usage statistics sections
"""

cpo : Final[Field] = Field(
    name='cpo',
    origin='SMF30CPO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to the Crypto counters section

SMF Info
--------
    Field: `SMF30CPO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to the Crypto counters section
"""
cpo.__doc__ = """Offset to the Crypto counters section

SMF Info
--------
    Field: `SMF30CPO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to the Crypto counters section
"""

cpl : Final[Field] = Field(
    name='cpl',
    origin='SMF30CPL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of the Crypto counters section

SMF Info
--------
    Field: `SMF30CPL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of the Crypto counters section
"""
cpl.__doc__ = """Length of the Crypto counters section

SMF Info
--------
    Field: `SMF30CPL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of the Crypto counters section
"""

cpn : Final[Field] = Field(
    name='cpn',
    origin='SMF30CPN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Crypto counters sections

SMF Info
--------
    Field: `SMF30CPN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Crypto counters sections
"""
cpn.__doc__ = """Number of Crypto counters sections

SMF Info
--------
    Field: `SMF30CPN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Crypto counters sections
"""

cpa : Final[Field] = Field(
    name='cpa',
    origin='SMF30CPA',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Crypto counters sections in subsequent (continuation) records

SMF Info
--------
    Field: `SMF30CPA`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Crypto counters sections in subsequent (continuation) records
"""
cpa.__doc__ = """Number of Crypto counters sections in subsequent (continuation) records

SMF Info
--------
    Field: `SMF30CPA`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Crypto counters sections in subsequent (continuation) records
"""

npo : Final[Field] = Field(
    name='npo',
    origin='SMF30NPO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to the NNPI counters section

SMF Info
--------
    Field: `SMF30NPO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to the NNPI counters section
"""
npo.__doc__ = """Offset to the NNPI counters section

SMF Info
--------
    Field: `SMF30NPO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to the NNPI counters section
"""

npl : Final[Field] = Field(
    name='npl',
    origin='SMF30NPL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of the NNPI counters section

SMF Info
--------
    Field: `SMF30NPL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of the NNPI counters section
"""
npl.__doc__ = """Length of the NNPI counters section

SMF Info
--------
    Field: `SMF30NPL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of the NNPI counters section
"""

npn : Final[Field] = Field(
    name='npn',
    origin='SMF30NPN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of NNPI counters sections

SMF Info
--------
    Field: `SMF30NPN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of NNPI counters sections
"""
npn.__doc__ = """Number of NNPI counters sections

SMF Info
--------
    Field: `SMF30NPN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of NNPI counters sections
"""

npa : Final[Field] = Field(
    name='npa',
    origin='SMF30NPA',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of NNPI counters sections in subsequent (continuation) records

SMF Info
--------
    Field: `SMF30NPA`
    Record: `SMF30S5`
    Map: Not part of a map

Number of NNPI counters sections in subsequent (continuation) records
"""
npa.__doc__ = """Number of NNPI counters sections in subsequent (continuation) records

SMF Info
--------
    Field: `SMF30NPA`
    Record: `SMF30S5`
    Map: Not part of a map

Number of NNPI counters sections in subsequent (continuation) records
"""

cont_recs_to_follow : Final[Field] = Field(
    name='cont_recs_to_follow',
    origin='SMF30_CONT_RECS_TO_FOLLOW',
    type=FieldType.INTEGER,
    record=record,
)
"""The number of continuation records to follow this record. When SMF30_RecCont_LastRec is on, this field will be zero.

SMF Info
--------
    Field: `SMF30_CONT_RECS_TO_FOLLOW`
    Record: `SMF30S5`
    Map: Not part of a map

The number of continuation records to follow this record. When SMF30_RecCont_LastRec is on, this field will be zero.
"""
cont_recs_to_follow.__doc__ = """The number of continuation records to follow this record. When SMF30_RecCont_LastRec is on, this field will be zero.

SMF Info
--------
    Field: `SMF30_CONT_RECS_TO_FOLLOW`
    Record: `SMF30S5`
    Map: Not part of a map

The number of continuation records to follow this record. When SMF30_RecCont_LastRec is on, this field will be zero.
"""

reccont_flags : Final[Field] = Field(
    name='reccont_flags',
    origin='SMF30_RECCONT_FLAGS',
    type=FieldType.STRING,
    record=record,
)
"""Record continuation flags

SMF Info
--------
    Field: `SMF30_RECCONT_FLAGS`
    Record: `SMF30S5`
    Map: Not part of a map

Record continuation flags
"""
reccont_flags.__doc__ = """Record continuation flags

SMF Info
--------
    Field: `SMF30_RECCONT_FLAGS`
    Record: `SMF30S5`
    Map: Not part of a map

Record continuation flags
"""

reccont_firstrec : Final[Field] = Field(
    name='reccont_firstrec',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=reccont_flags,
    record=record,
)
"""When on, this record is the first of a set of two or more continuation records(V)

SMF Info (Virtual Field)
--------
    Field: Based on `reccont_flags`(`SMF30_RECCONT_FLAGS`)
    Record: `SMF30S5`
    Map: Not part of a map

When on, this record is the first of a set of two or more continuation records

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
reccont_firstrec.__doc__ = """When on, this record is the first of a set of two or more continuation records(V)

SMF Info (Virtual Field)
--------
    Field: Based on `reccont_flags`(`SMF30_RECCONT_FLAGS`)
    Record: `SMF30S5`
    Map: Not part of a map

When on, this record is the first of a set of two or more continuation records

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

reccont_additionalrec : Final[Field] = Field(
    name='reccont_additionalrec',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=reccont_flags,
    record=record,
)
"""When on, this record is the second or subsequent but not last record in a set of two or more continuation records.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `reccont_flags`(`SMF30_RECCONT_FLAGS`)
    Record: `SMF30S5`
    Map: Not part of a map

When on, this record is the second or subsequent but not last record in a set of two or more continuation records.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
reccont_additionalrec.__doc__ = """When on, this record is the second or subsequent but not last record in a set of two or more continuation records.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `reccont_flags`(`SMF30_RECCONT_FLAGS`)
    Record: `SMF30S5`
    Map: Not part of a map

When on, this record is the second or subsequent but not last record in a set of two or more continuation records.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

reccont_lastrec : Final[Field] = Field(
    name='reccont_lastrec',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=reccont_flags,
    record=record,
)
"""When on, this record is the last of a set of two or more continuation records(V)

SMF Info (Virtual Field)
--------
    Field: Based on `reccont_flags`(`SMF30_RECCONT_FLAGS`)
    Record: `SMF30S5`
    Map: Not part of a map

When on, this record is the last of a set of two or more continuation records

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
reccont_lastrec.__doc__ = """When on, this record is the last of a set of two or more continuation records(V)

SMF Info (Virtual Field)
--------
    Field: Based on `reccont_flags`(`SMF30_RECCONT_FLAGS`)
    Record: `SMF30S5`
    Map: Not part of a map

When on, this record is the last of a set of two or more continuation records

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

cno : Final[Field] = Field(
    name='cno',
    origin='SMF30CNO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to the Container section

SMF Info
--------
    Field: `SMF30CNO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to the Container section
"""
cno.__doc__ = """Offset to the Container section

SMF Info
--------
    Field: `SMF30CNO`
    Record: `SMF30S5`
    Map: Not part of a map

Offset to the Container section
"""

cnl : Final[Field] = Field(
    name='cnl',
    origin='SMF30CNL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of the Container section

SMF Info
--------
    Field: `SMF30CNL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of the Container section
"""
cnl.__doc__ = """Length of the Container section

SMF Info
--------
    Field: `SMF30CNL`
    Record: `SMF30S5`
    Map: Not part of a map

Length of the Container section
"""

cnn : Final[Field] = Field(
    name='cnn',
    origin='SMF30CNN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Container sections. Because only one Container section can appear on the record, this field is 1 (if the section exists) or 0 (if it does not).

SMF Info
--------
    Field: `SMF30CNN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Container sections. Because only one Container section can appear on the record, this field is 1 (if the section exists) or 0 (if it does not).
"""
cnn.__doc__ = """Number of Container sections. Because only one Container section can appear on the record, this field is 1 (if the section exists) or 0 (if it does not).

SMF Info
--------
    Field: `SMF30CNN`
    Record: `SMF30S5`
    Map: Not part of a map

Number of Container sections. Because only one Container section can appear on the record, this field is 1 (if the section exists) or 0 (if it does not).
"""

subtype : Final[Field] = Field(
    name='subtype',
    origin='SMF30TYP',
    post='core.map',
    post_param={'map': {1: 'Job start or start of other work unit.', 2: 'Activity since previous interval ended.', 3: 'Activity for the last interval before step termination.', 4: 'Step total', 5: 'Job termination or termination of other work unit.', 6: 'System address space.'}},
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PSS,
)
"""RECORD SUBTYPE

SMF Info
--------
    Field: `SMF30TYP`
    Record: `SMF30S5`
    Map: `SMF30PSS`

RECORD SUBTYPE

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    1 => Job start or start of other work unit.
    2 => Activity since previous interval ended.
    3 => Activity for the last interval before step termination.
    4 => Step total
    5 => Job termination or termination of other work unit.
    6 => System address space.
"""
subtype.__doc__ = """RECORD SUBTYPE

SMF Info
--------
    Field: `SMF30TYP`
    Record: `SMF30S5`
    Map: `SMF30PSS`

RECORD SUBTYPE

Post Processing (`core.map`)
---------------
The post processor maps the following values::

    1 => Job start or start of other work unit.
    2 => Activity since previous interval ended.
    3 => Activity for the last interval before step termination.
    4 => Step total
    5 => Job termination or termination of other work unit.
    6 => System address space.
"""

product_flg : Final[Field] = Field(
    name='product_flg',
    origin='SMF30PFLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PSS,
)
"""Product Flags

SMF Info
--------
    Field: `SMF30PFLAGS`
    Record: `SMF30S5`
    Map: `SMF30PSS`

Product Flags
"""
product_flg.__doc__ = """Product Flags

SMF Info
--------
    Field: `SMF30PFLAGS`
    Record: `SMF30S5`
    Map: `SMF30PSS`

Product Flags
"""

crypctrs_active : Final[Field] = Field(
    name='crypctrs_active',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=product_flg,
    record=record,
    record_map=SMF30PSS,
)
"""Indicates that crypto counter processing is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `product_flg`(`SMF30PFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PSS`

Indicates that crypto counter processing is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
crypctrs_active.__doc__ = """Indicates that crypto counter processing is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `product_flg`(`SMF30PFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PSS`

Indicates that crypto counter processing is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

nnpictrs_active : Final[Field] = Field(
    name='nnpictrs_active',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=product_flg,
    record=record,
    record_map=SMF30PSS,
)
"""Indicates that NNPI counter processing is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `product_flg`(`SMF30PFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PSS`

Indicates that NNPI counter processing is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
nnpictrs_active.__doc__ = """Indicates that NNPI counter processing is active(V)

SMF Info (Virtual Field)
--------
    Field: Based on `product_flg`(`SMF30PFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PSS`

Indicates that NNPI counter processing is active

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

record_ver_num : Final[Field] = Field(
    name='record_ver_num',
    origin='SMF30RVN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PSS,
)
"""RECORD VERSION ('05')

SMF Info
--------
    Field: `SMF30RVN`
    Record: `SMF30S5`
    Map: `SMF30PSS`

RECORD VERSION ('05')
"""
record_ver_num.__doc__ = """RECORD VERSION ('05')

SMF Info
--------
    Field: `SMF30RVN`
    Record: `SMF30S5`
    Map: `SMF30PSS`

RECORD VERSION ('05')
"""

product_name : Final[Field] = Field(
    name='product_name',
    origin='SMF30PNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PSS,
)
"""PRODUCT NAME - SMF

SMF Info
--------
    Field: `SMF30PNM`
    Record: `SMF30S5`
    Map: `SMF30PSS`

PRODUCT NAME - SMF
"""
product_name.__doc__ = """PRODUCT NAME - SMF

SMF Info
--------
    Field: `SMF30PNM`
    Record: `SMF30S5`
    Map: `SMF30PSS`

PRODUCT NAME - SMF
"""

os_lvl : Final[Field] = Field(
    name='os_lvl',
    origin='SMF30OSL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PSS,
)
"""MVS PRODUCT LEVEL

SMF Info
--------
    Field: `SMF30OSL`
    Record: `SMF30S5`
    Map: `SMF30PSS`

MVS PRODUCT LEVEL
"""
os_lvl.__doc__ = """MVS PRODUCT LEVEL

SMF Info
--------
    Field: `SMF30OSL`
    Record: `SMF30S5`
    Map: `SMF30PSS`

MVS PRODUCT LEVEL
"""

sys_name : Final[Field] = Field(
    name='sys_name',
    origin='SMF30SYN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PSS,
)
"""Current System Name Value (from SYSNAME Parmlib Option)

SMF Info
--------
    Field: `SMF30SYN`
    Record: `SMF30S5`
    Map: `SMF30PSS`

Current System Name Value (from SYSNAME Parmlib Option)
"""
sys_name.__doc__ = """Current System Name Value (from SYSNAME Parmlib Option)

SMF Info
--------
    Field: `SMF30SYN`
    Record: `SMF30S5`
    Map: `SMF30PSS`

Current System Name Value (from SYSNAME Parmlib Option)
"""

sysplex_name : Final[Field] = Field(
    name='sysplex_name',
    origin='SMF30SYP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PSS,
)
"""Sysplex name

SMF Info
--------
    Field: `SMF30SYP`
    Record: `SMF30S5`
    Map: `SMF30PSS`

Sysplex name
"""
sysplex_name.__doc__ = """Sysplex name

SMF Info
--------
    Field: `SMF30SYP`
    Record: `SMF30S5`
    Map: `SMF30PSS`

Sysplex name
"""

job_name : Final[Field] = Field(
    name='job_name',
    origin='SMF30JBN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""JOB/SESSION NAME

SMF Info
--------
    Field: `SMF30JBN`
    Record: `SMF30S5`
    Map: `SMF30ID`

JOB/SESSION NAME
"""
job_name.__doc__ = """JOB/SESSION NAME

SMF Info
--------
    Field: `SMF30JBN`
    Record: `SMF30S5`
    Map: `SMF30ID`

JOB/SESSION NAME
"""

pgm_prog_name : Final[Field] = Field(
    name='pgm_prog_name',
    origin='SMF30PGM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""PROGRAM NAME

SMF Info
--------
    Field: `SMF30PGM`
    Record: `SMF30S5`
    Map: `SMF30ID`

PROGRAM NAME
"""
pgm_prog_name.__doc__ = """PROGRAM NAME

SMF Info
--------
    Field: `SMF30PGM`
    Record: `SMF30S5`
    Map: `SMF30ID`

PROGRAM NAME
"""

step_name : Final[Field] = Field(
    name='step_name',
    origin='SMF30STM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""STEP NAME

SMF Info
--------
    Field: `SMF30STM`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP NAME
"""
step_name.__doc__ = """STEP NAME

SMF Info
--------
    Field: `SMF30STM`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP NAME
"""

user_defined_id : Final[Field] = Field(
    name='user_defined_id',
    origin='SMF30UIF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""User-defined identification field (taken from common exit parameter area, not from USER= parameter on job statement).

SMF Info
--------
    Field: `SMF30UIF`
    Record: `SMF30S5`
    Map: `SMF30ID`

User-defined identification field (taken from common exit parameter area, not from USER= parameter on job statement).
"""
user_defined_id.__doc__ = """User-defined identification field (taken from common exit parameter area, not from USER= parameter on job statement).

SMF Info
--------
    Field: `SMF30UIF`
    Record: `SMF30S5`
    Map: `SMF30ID`

User-defined identification field (taken from common exit parameter area, not from USER= parameter on job statement).
"""

jes_job_id : Final[Field] = Field(
    name='jes_job_id',
    origin='SMF30JNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""JES JOB NUMBER

SMF Info
--------
    Field: `SMF30JNM`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES JOB NUMBER
"""
jes_job_id.__doc__ = """JES JOB NUMBER

SMF Info
--------
    Field: `SMF30JNM`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES JOB NUMBER
"""

step : Final[Field] = Field(
    name='step',
    origin='SMF30STN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30ID,
)
"""STEP NUMBER

SMF Info
--------
    Field: `SMF30STN`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP NUMBER
"""
step.__doc__ = """STEP NUMBER

SMF Info
--------
    Field: `SMF30STN`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP NUMBER
"""

job_class : Final[Field] = Field(
    name='job_class',
    origin='SMF30CLS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""JOB CLASS

SMF Info
--------
    Field: `SMF30CLS`
    Record: `SMF30S5`
    Map: `SMF30ID`

JOB CLASS
"""
job_class.__doc__ = """JOB CLASS

SMF Info
--------
    Field: `SMF30CLS`
    Record: `SMF30S5`
    Map: `SMF30ID`

JOB CLASS
"""

job_flg : Final[Field] = Field(
    name='job_flg',
    origin='SMF30JF1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""Job / Session ID section flag

SMF Info
--------
    Field: `SMF30JF1`
    Record: `SMF30S5`
    Map: `SMF30ID`

Job / Session ID section flag
"""
job_flg.__doc__ = """Job / Session ID section flag

SMF Info
--------
    Field: `SMF30JF1`
    Record: `SMF30S5`
    Map: `SMF30ID`

Job / Session ID section flag
"""

pgn_invalid : Final[Field] = Field(
    name='pgn_invalid',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=job_flg,
    record=record,
    record_map=SMF30ID,
)
"""SMF30PGN is invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `job_flg`(`SMF30JF1`)
    Record: `SMF30S5`
    Map: `SMF30ID`

SMF30PGN is invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
pgn_invalid.__doc__ = """SMF30PGN is invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `job_flg`(`SMF30JF1`)
    Record: `SMF30S5`
    Map: `SMF30ID`

SMF30PGN is invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

pgn : Final[Field] = Field(
    name='pgn',
    origin='SMF30PGN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30ID,
)
"""Job performance group number

SMF Info
--------
    Field: `SMF30PGN`
    Record: `SMF30S5`
    Map: `SMF30ID`

Job performance group number
"""
pgn.__doc__ = """Job performance group number

SMF Info
--------
    Field: `SMF30PGN`
    Record: `SMF30S5`
    Map: `SMF30ID`

Job performance group number
"""

jes_input_priority : Final[Field] = Field(
    name='jes_input_priority',
    origin='SMF30JPT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30ID,
)
"""JES INPUT PRIORITY

SMF Info
--------
    Field: `SMF30JPT`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES INPUT PRIORITY
"""
jes_input_priority.__doc__ = """JES INPUT PRIORITY

SMF Info
--------
    Field: `SMF30JPT`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES INPUT PRIORITY
"""

device_alloc_start_time : Final[Field] = Field(
    name='device_alloc_start_time',
    origin='SMF30AST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF30ID,
)
"""DEVICE ALLOCATION START TIME

SMF Info
--------
    Field: `SMF30AST`
    Record: `SMF30S5`
    Map: `SMF30ID`

DEVICE ALLOCATION START TIME
"""
device_alloc_start_time.__doc__ = """DEVICE ALLOCATION START TIME

SMF Info
--------
    Field: `SMF30AST`
    Record: `SMF30S5`
    Map: `SMF30ID`

DEVICE ALLOCATION START TIME
"""

problem_alloc_start_time : Final[Field] = Field(
    name='problem_alloc_start_time',
    origin='SMF30PPS',
    type=FieldType.TIME,
    record=record,
    record_map=SMF30ID,
)
"""PROBLEM PROGRAM START TIME

SMF Info
--------
    Field: `SMF30PPS`
    Record: `SMF30S5`
    Map: `SMF30ID`

PROBLEM PROGRAM START TIME
"""
problem_alloc_start_time.__doc__ = """PROBLEM PROGRAM START TIME

SMF Info
--------
    Field: `SMF30PPS`
    Record: `SMF30S5`
    Map: `SMF30ID`

PROBLEM PROGRAM START TIME
"""

initiator_job_time : Final[Field] = Field(
    name='initiator_job_time',
    origin='SMF30SIT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF30ID,
)
"""STEP INITIATION TIME

SMF Info
--------
    Field: `SMF30SIT`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP INITIATION TIME
"""
initiator_job_time.__doc__ = """STEP INITIATION TIME

SMF Info
--------
    Field: `SMF30SIT`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP INITIATION TIME
"""

step_initiation_date : Final[Field] = Field(
    name='step_initiation_date',
    origin='SMF30STD',
    type=FieldType.DATE,
    record=record,
    record_map=SMF30ID,
)
"""STEP INITIATION DATE

SMF Info
--------
    Field: `SMF30STD`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP INITIATION DATE
"""
step_initiation_date.__doc__ = """STEP INITIATION DATE

SMF Info
--------
    Field: `SMF30STD`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP INITIATION DATE
"""

reader_start_time : Final[Field] = Field(
    name='reader_start_time',
    origin='SMF30RST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF30ID,
)
"""READER START TIME

SMF Info
--------
    Field: `SMF30RST`
    Record: `SMF30S5`
    Map: `SMF30ID`

READER START TIME
"""
reader_start_time.__doc__ = """READER START TIME

SMF Info
--------
    Field: `SMF30RST`
    Record: `SMF30S5`
    Map: `SMF30ID`

READER START TIME
"""

reader_start_date : Final[Field] = Field(
    name='reader_start_date',
    origin='SMF30RSD',
    type=FieldType.DATE,
    record=record,
    record_map=SMF30ID,
)
"""READER START DATE

SMF Info
--------
    Field: `SMF30RSD`
    Record: `SMF30S5`
    Map: `SMF30ID`

READER START DATE
"""
reader_start_date.__doc__ = """READER START DATE

SMF Info
--------
    Field: `SMF30RSD`
    Record: `SMF30S5`
    Map: `SMF30ID`

READER START DATE
"""

reader_end_time : Final[Field] = Field(
    name='reader_end_time',
    origin='SMF30RET',
    type=FieldType.TIME,
    record=record,
    record_map=SMF30ID,
)
"""READER END TIME

SMF Info
--------
    Field: `SMF30RET`
    Record: `SMF30S5`
    Map: `SMF30ID`

READER END TIME
"""
reader_end_time.__doc__ = """READER END TIME

SMF Info
--------
    Field: `SMF30RET`
    Record: `SMF30S5`
    Map: `SMF30ID`

READER END TIME
"""

reader_end_date : Final[Field] = Field(
    name='reader_end_date',
    origin='SMF30RED',
    type=FieldType.DATE,
    record=record,
    record_map=SMF30ID,
)
"""READER END DATE

SMF Info
--------
    Field: `SMF30RED`
    Record: `SMF30S5`
    Map: `SMF30ID`

READER END DATE
"""
reader_end_date.__doc__ = """READER END DATE

SMF Info
--------
    Field: `SMF30RED`
    Record: `SMF30S5`
    Map: `SMF30ID`

READER END DATE
"""

user_name : Final[Field] = Field(
    name='user_name',
    origin='SMF30USR',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""PROGRAMMER'S NAME

SMF Info
--------
    Field: `SMF30USR`
    Record: `SMF30S5`
    Map: `SMF30ID`

PROGRAMMER'S NAME
"""
user_name.__doc__ = """PROGRAMMER'S NAME

SMF Info
--------
    Field: `SMF30USR`
    Record: `SMF30S5`
    Map: `SMF30ID`

PROGRAMMER'S NAME
"""

racf_grp_id : Final[Field] = Field(
    name='racf_grp_id',
    origin='SMF30GRP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""RACF GROUP ID

SMF Info
--------
    Field: `SMF30GRP`
    Record: `SMF30S5`
    Map: `SMF30ID`

RACF GROUP ID
"""
racf_grp_id.__doc__ = """RACF GROUP ID

SMF Info
--------
    Field: `SMF30GRP`
    Record: `SMF30S5`
    Map: `SMF30ID`

RACF GROUP ID
"""

racf_usr_id : Final[Field] = Field(
    name='racf_usr_id',
    origin='SMF30RUD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""RACF USER ID

SMF Info
--------
    Field: `SMF30RUD`
    Record: `SMF30S5`
    Map: `SMF30ID`

RACF USER ID
"""
racf_usr_id.__doc__ = """RACF USER ID

SMF Info
--------
    Field: `SMF30RUD`
    Record: `SMF30S5`
    Map: `SMF30ID`

RACF USER ID
"""

racf_terminal_id : Final[Field] = Field(
    name='racf_terminal_id',
    origin='SMF30TID',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""RACF TERMINAL ID

SMF Info
--------
    Field: `SMF30TID`
    Record: `SMF30S5`
    Map: `SMF30ID`

RACF TERMINAL ID
"""
racf_terminal_id.__doc__ = """RACF TERMINAL ID

SMF Info
--------
    Field: `SMF30TID`
    Record: `SMF30S5`
    Map: `SMF30ID`

RACF TERMINAL ID
"""

terminal_name : Final[Field] = Field(
    name='terminal_name',
    origin='SMF30TSN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""TERMINAL SYMBOLIC NAME

SMF Info
--------
    Field: `SMF30TSN`
    Record: `SMF30S5`
    Map: `SMF30ID`

TERMINAL SYMBOLIC NAME
"""
terminal_name.__doc__ = """TERMINAL SYMBOLIC NAME

SMF Info
--------
    Field: `SMF30TSN`
    Record: `SMF30S5`
    Map: `SMF30ID`

TERMINAL SYMBOLIC NAME
"""

proc_step_inv_name : Final[Field] = Field(
    name='proc_step_inv_name',
    origin='SMF30PSN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""STEP NAME THAT INVOKED PROC

SMF Info
--------
    Field: `SMF30PSN`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP NAME THAT INVOKED PROC
"""
proc_step_inv_name.__doc__ = """STEP NAME THAT INVOKED PROC

SMF Info
--------
    Field: `SMF30PSN`
    Record: `SMF30S5`
    Map: `SMF30ID`

STEP NAME THAT INVOKED PROC
"""

job_class_8b : Final[Field] = Field(
    name='job_class_8b',
    origin='SMF30CL8',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""8-CHARACTER JOB CLASS

SMF Info
--------
    Field: `SMF30CL8`
    Record: `SMF30S5`
    Map: `SMF30ID`

8-CHARACTER JOB CLASS
"""
job_class_8b.__doc__ = """8-CHARACTER JOB CLASS

SMF Info
--------
    Field: `SMF30CL8`
    Record: `SMF30S5`
    Map: `SMF30ID`

8-CHARACTER JOB CLASS
"""

interval_start_tod : Final[Field] = Field(
    name='interval_start_tod',
    origin='SMF30ISS',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF30ID,
)
"""Interval Start Time for Subtype 2 and 3 records (STCK format)

SMF Info
--------
    Field: `SMF30ISS`
    Record: `SMF30S5`
    Map: `SMF30ID`

Interval Start Time for Subtype 2 and 3 records (STCK format)
"""
interval_start_tod.__doc__ = """Interval Start Time for Subtype 2 and 3 records (STCK format)

SMF Info
--------
    Field: `SMF30ISS`
    Record: `SMF30S5`
    Map: `SMF30ID`

Interval Start Time for Subtype 2 and 3 records (STCK format)
"""

interval_end_tod : Final[Field] = Field(
    name='interval_end_tod',
    origin='SMF30IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF30ID,
)
"""Interval End Time for Subtype 2, 3 and 6 Records (STCK format)

SMF Info
--------
    Field: `SMF30IET`
    Record: `SMF30S5`
    Map: `SMF30ID`

Interval End Time for Subtype 2, 3 and 6 Records (STCK format)
"""
interval_end_tod.__doc__ = """Interval End Time for Subtype 2, 3 and 6 Records (STCK format)

SMF Info
--------
    Field: `SMF30IET`
    Record: `SMF30S5`
    Map: `SMF30ID`

Interval End Time for Subtype 2, 3 and 6 Records (STCK format)
"""

substep_num : Final[Field] = Field(
    name='substep_num',
    origin='SMF30SSN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30ID,
)
"""Sub-Step Number

SMF Info
--------
    Field: `SMF30SSN`
    Record: `SMF30S5`
    Map: `SMF30ID`

Sub-Step Number
"""
substep_num.__doc__ = """Sub-Step Number

SMF Info
--------
    Field: `SMF30SSN`
    Record: `SMF30S5`
    Map: `SMF30ID`

Sub-Step Number
"""

prog_name : Final[Field] = Field(
    name='prog_name',
    origin='SMF30EXN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""OpenMVS Exec'ed program name

SMF Info
--------
    Field: `SMF30EXN`
    Record: `SMF30S5`
    Map: `SMF30ID`

OpenMVS Exec'ed program name
"""
prog_name.__doc__ = """OpenMVS Exec'ed program name

SMF Info
--------
    Field: `SMF30EXN`
    Record: `SMF30S5`
    Map: `SMF30ID`

OpenMVS Exec'ed program name
"""

address_space_id : Final[Field] = Field(
    name='address_space_id',
    origin='SMF30ASI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30ID,
)
"""Address space identifier

SMF Info
--------
    Field: `SMF30ASI`
    Record: `SMF30S5`
    Map: `SMF30ID`

Address space identifier
"""
address_space_id.__doc__ = """Address space identifier

SMF Info
--------
    Field: `SMF30ASI`
    Record: `SMF30S5`
    Map: `SMF30ID`

Address space identifier
"""

jes_job_correlator : Final[Field] = Field(
    name='jes_job_correlator',
    origin='SMF30COR',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""JES Job Correlator

SMF Info
--------
    Field: `SMF30COR`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES Job Correlator
"""
jes_job_correlator.__doc__ = """JES Job Correlator

SMF Info
--------
    Field: `SMF30COR`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES Job Correlator
"""

jclid1 : Final[Field] = Field(
    name='jclid1',
    origin='SMF30JCLID1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""JES-computed binary identifier for the job that was submitted (using method 1), if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30JCLID1`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES-computed binary identifier for the job that was submitted (using method 1), if provided by the primary subsystem
"""
jclid1.__doc__ = """JES-computed binary identifier for the job that was submitted (using method 1), if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30JCLID1`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES-computed binary identifier for the job that was submitted (using method 1), if provided by the primary subsystem
"""

jclid2 : Final[Field] = Field(
    name='jclid2',
    origin='SMF30JCLID2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""JES-computed binary identifier for the job that was submitted (using method 2), if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30JCLID2`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES-computed binary identifier for the job that was submitted (using method 2), if provided by the primary subsystem
"""
jclid2.__doc__ = """JES-computed binary identifier for the job that was submitted (using method 2), if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30JCLID2`
    Record: `SMF30S5`
    Map: `SMF30ID`

JES-computed binary identifier for the job that was submitted (using method 2), if provided by the primary subsystem
"""

jobtoken : Final[Field] = Field(
    name='jobtoken',
    origin='SMF30JOBTOKEN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""Binary identifier for the job, if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30JOBTOKEN`
    Record: `SMF30S5`
    Map: `SMF30ID`

Binary identifier for the job, if provided by the primary subsystem
"""
jobtoken.__doc__ = """Binary identifier for the job, if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30JOBTOKEN`
    Record: `SMF30S5`
    Map: `SMF30ID`

Binary identifier for the job, if provided by the primary subsystem
"""

holduntil : Final[Field] = Field(
    name='holduntil',
    origin='SMF30HOLDUNTIL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""A UTC timestamp represented by the first 6 bytes (bits 0-47) of an ETOD value. This is the resolved HOLDUNTL value for the job (from JCL or JES2 symbol on the internal reader interface), if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30HOLDUNTIL`
    Record: `SMF30S5`
    Map: `SMF30ID`

A UTC timestamp represented by the first 6 bytes (bits 0-47) of an ETOD value. This is the resolved HOLDUNTL value for the job (from JCL or JES2 symbol on the internal reader interface), if provided by the primary subsystem
"""
holduntil.__doc__ = """A UTC timestamp represented by the first 6 bytes (bits 0-47) of an ETOD value. This is the resolved HOLDUNTL value for the job (from JCL or JES2 symbol on the internal reader interface), if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30HOLDUNTIL`
    Record: `SMF30S5`
    Map: `SMF30ID`

A UTC timestamp represented by the first 6 bytes (bits 0-47) of an ETOD value. This is the resolved HOLDUNTL value for the job (from JCL or JES2 symbol on the internal reader interface), if provided by the primary subsystem
"""

deadline : Final[Field] = Field(
    name='deadline',
    origin='SMF30DEADLINE',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ID,
)
"""A UTC timestamp represented by the first 6 bytes (bits 0-47) of an ETOD value. This is the resolved DEADLINE value for the job (from JES2 symbol on the internal reader interface), if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30DEADLINE`
    Record: `SMF30S5`
    Map: `SMF30ID`

A UTC timestamp represented by the first 6 bytes (bits 0-47) of an ETOD value. This is the resolved DEADLINE value for the job (from JES2 symbol on the internal reader interface), if provided by the primary subsystem
"""
deadline.__doc__ = """A UTC timestamp represented by the first 6 bytes (bits 0-47) of an ETOD value. This is the resolved DEADLINE value for the job (from JES2 symbol on the internal reader interface), if provided by the primary subsystem

SMF Info
--------
    Field: `SMF30DEADLINE`
    Record: `SMF30S5`
    Map: `SMF30ID`

A UTC timestamp represented by the first 6 bytes (bits 0-47) of an ETOD value. This is the resolved DEADLINE value for the job (from JES2 symbol on the internal reader interface), if provided by the primary subsystem
"""

card_image_rec_num : Final[Field] = Field(
    name='card_image_rec_num',
    origin='SMF30INP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""NUMBER OF CARD IMAGES

SMF Info
--------
    Field: `SMF30INP`
    Record: `SMF30S5`
    Map: `SMF30URA`

NUMBER OF CARD IMAGES
"""
card_image_rec_num.__doc__ = """NUMBER OF CARD IMAGES

SMF Info
--------
    Field: `SMF30INP`
    Record: `SMF30S5`
    Map: `SMF30URA`

NUMBER OF CARD IMAGES
"""

total_blocks_transferred : Final[Field] = Field(
    name='total_blocks_transferred',
    origin='SMF30TEP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""Total blocks transferred (Accumulated EXCP counts - valid up to 'FFFFFFFE'x, zero and invalid when SMF30TEF is set)

SMF Info
--------
    Field: `SMF30TEP`
    Record: `SMF30S5`
    Map: `SMF30URA`

Total blocks transferred (Accumulated EXCP counts - valid up to 'FFFFFFFE'x, zero and invalid when SMF30TEF is set)
"""
total_blocks_transferred.__doc__ = """Total blocks transferred (Accumulated EXCP counts - valid up to 'FFFFFFFE'x, zero and invalid when SMF30TEF is set)

SMF Info
--------
    Field: `SMF30TEP`
    Record: `SMF30S5`
    Map: `SMF30URA`

Total blocks transferred (Accumulated EXCP counts - valid up to 'FFFFFFFE'x, zero and invalid when SMF30TEF is set)
"""

tputs_num : Final[Field] = Field(
    name='tputs_num',
    origin='SMF30TPT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""NUMBER OF TPUTS (TSO SESSION)

SMF Info
--------
    Field: `SMF30TPT`
    Record: `SMF30S5`
    Map: `SMF30URA`

NUMBER OF TPUTS (TSO SESSION)
"""
tputs_num.__doc__ = """NUMBER OF TPUTS (TSO SESSION)

SMF Info
--------
    Field: `SMF30TPT`
    Record: `SMF30S5`
    Map: `SMF30URA`

NUMBER OF TPUTS (TSO SESSION)
"""

tgets_num : Final[Field] = Field(
    name='tgets_num',
    origin='SMF30TGT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""NUMBER OF TGETS (TSO SESSION)

SMF Info
--------
    Field: `SMF30TGT`
    Record: `SMF30S5`
    Map: `SMF30URA`

NUMBER OF TGETS (TSO SESSION)
"""
tgets_num.__doc__ = """NUMBER OF TGETS (TSO SESSION)

SMF Info
--------
    Field: `SMF30TGT`
    Record: `SMF30S5`
    Map: `SMF30URA`

NUMBER OF TGETS (TSO SESSION)
"""

reader_device_class : Final[Field] = Field(
    name='reader_device_class',
    origin='SMF30RDR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""READER DEVICE CLASS

SMF Info
--------
    Field: `SMF30RDR`
    Record: `SMF30S5`
    Map: `SMF30URA`

READER DEVICE CLASS
"""
reader_device_class.__doc__ = """READER DEVICE CLASS

SMF Info
--------
    Field: `SMF30RDR`
    Record: `SMF30S5`
    Map: `SMF30URA`

READER DEVICE CLASS
"""

reader_device_type : Final[Field] = Field(
    name='reader_device_type',
    origin='SMF30RDT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""READER DEVICE TYPE

SMF Info
--------
    Field: `SMF30RDT`
    Record: `SMF30S5`
    Map: `SMF30URA`

READER DEVICE TYPE
"""
reader_device_type.__doc__ = """READER DEVICE TYPE

SMF Info
--------
    Field: `SMF30RDT`
    Record: `SMF30S5`
    Map: `SMF30URA`

READER DEVICE TYPE
"""

tot_device_conn_time : Final[Field] = Field(
    name='tot_device_conn_time',
    origin='SMF30TCN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""TOTAL DEVICE CONNECT TIME FOR THIS ADDRESS SPACE

SMF Info
--------
    Field: `SMF30TCN`
    Record: `SMF30S5`
    Map: `SMF30URA`

TOTAL DEVICE CONNECT TIME FOR THIS ADDRESS SPACE
"""
tot_device_conn_time.__doc__ = """TOTAL DEVICE CONNECT TIME FOR THIS ADDRESS SPACE

SMF Info
--------
    Field: `SMF30TCN`
    Record: `SMF30S5`
    Map: `SMF30URA`

TOTAL DEVICE CONNECT TIME FOR THIS ADDRESS SPACE
"""

dev_conn_flg : Final[Field] = Field(
    name='dev_conn_flg',
    origin='SMF30DCF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30URA,
)
"""FLAG WORD

SMF Info
--------
    Field: `SMF30DCF`
    Record: `SMF30S5`
    Map: `SMF30URA`

FLAG WORD
"""
dev_conn_flg.__doc__ = """FLAG WORD

SMF Info
--------
    Field: `SMF30DCF`
    Record: `SMF30S5`
    Map: `SMF30URA`

FLAG WORD
"""

device_connect_time_incorrect : Final[Field] = Field(
    name='device_connect_time_incorrect',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=dev_conn_flg,
    record=record,
    record_map=SMF30URA,
)
"""DEVICE CONNECT TIME MAY BE INCORRECT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dev_conn_flg`(`SMF30DCF`)
    Record: `SMF30S5`
    Map: `SMF30URA`

DEVICE CONNECT TIME MAY BE INCORRECT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
device_connect_time_incorrect.__doc__ = """DEVICE CONNECT TIME MAY BE INCORRECT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dev_conn_flg`(`SMF30DCF`)
    Record: `SMF30S5`
    Map: `SMF30URA`

DEVICE CONNECT TIME MAY BE INCORRECT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

dcf_incomplete : Final[Field] = Field(
    name='dcf_incomplete',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=dev_conn_flg,
    record=record,
    record_map=SMF30URA,
)
"""The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30AIC SMF30EIC SMF30AID SMF30EID SMF30AIW SMF30EIW SMF30AIS SMF30EIS(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dev_conn_flg`(`SMF30DCF`)
    Record: `SMF30S5`
    Map: `SMF30URA`

The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30AIC SMF30EIC SMF30AID SMF30EID SMF30AIW SMF30EIW SMF30AIS SMF30EIS

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
dcf_incomplete.__doc__ = """The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30AIC SMF30EIC SMF30AID SMF30EID SMF30AIW SMF30EIW SMF30AIS SMF30EIS(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dev_conn_flg`(`SMF30DCF`)
    Record: `SMF30S5`
    Map: `SMF30URA`

The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30AIC SMF30EIC SMF30AID SMF30EID SMF30AIW SMF30EIW SMF30AIS SMF30EIS

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

smf30tep_invalid : Final[Field] = Field(
    name='smf30tep_invalid',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=dev_conn_flg,
    record=record,
    record_map=SMF30URA,
)
"""SMF30TEP invalid when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dev_conn_flg`(`SMF30DCF`)
    Record: `SMF30S5`
    Map: `SMF30URA`

SMF30TEP invalid when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
smf30tep_invalid.__doc__ = """SMF30TEP invalid when set(V)

SMF Info (Virtual Field)
--------
    Field: Based on `dev_conn_flg`(`SMF30DCF`)
    Record: `SMF30S5`
    Map: `SMF30URA`

SMF30TEP invalid when set

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

addr_space_reread_count : Final[Field] = Field(
    name='addr_space_reread_count',
    origin='SMF30TRR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""TOTAL ADDRESS SPACE RE-READ

SMF Info
--------
    Field: `SMF30TRR`
    Record: `SMF30S5`
    Map: `SMF30URA`

TOTAL ADDRESS SPACE RE-READ
"""
addr_space_reread_count.__doc__ = """TOTAL ADDRESS SPACE RE-READ

SMF Info
--------
    Field: `SMF30TRR`
    Record: `SMF30S5`
    Map: `SMF30URA`

TOTAL ADDRESS SPACE RE-READ
"""

io_conn_time : Final[Field] = Field(
    name='io_conn_time',
    origin='SMF30AIC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""DASD I/O connect time for address space plus dependent enclaves in 128-microsecond units

SMF Info
--------
    Field: `SMF30AIC`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O connect time for address space plus dependent enclaves in 128-microsecond units
"""
io_conn_time.__doc__ = """DASD I/O connect time for address space plus dependent enclaves in 128-microsecond units

SMF Info
--------
    Field: `SMF30AIC`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O connect time for address space plus dependent enclaves in 128-microsecond units
"""

io_disconn_time : Final[Field] = Field(
    name='io_disconn_time',
    origin='SMF30AID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""DASD I/O disconnect time for address space plus dependent enclaves in 128-microsecond units

SMF Info
--------
    Field: `SMF30AID`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O disconnect time for address space plus dependent enclaves in 128-microsecond units
"""
io_disconn_time.__doc__ = """DASD I/O disconnect time for address space plus dependent enclaves in 128-microsecond units

SMF Info
--------
    Field: `SMF30AID`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O disconnect time for address space plus dependent enclaves in 128-microsecond units
"""

io_pending_time : Final[Field] = Field(
    name='io_pending_time',
    origin='SMF30AIW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""DASD I/O pending plus control unit queue time for address space plus dependent enclaves in 128-microsecond units

SMF Info
--------
    Field: `SMF30AIW`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O pending plus control unit queue time for address space plus dependent enclaves in 128-microsecond units
"""
io_pending_time.__doc__ = """DASD I/O pending plus control unit queue time for address space plus dependent enclaves in 128-microsecond units

SMF Info
--------
    Field: `SMF30AIW`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O pending plus control unit queue time for address space plus dependent enclaves in 128-microsecond units
"""

io_subchann_count : Final[Field] = Field(
    name='io_subchann_count',
    origin='SMF30AIS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""DASD I/O start subchannel count for address space plus dependent enclaves

SMF Info
--------
    Field: `SMF30AIS`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O start subchannel count for address space plus dependent enclaves
"""
io_subchann_count.__doc__ = """DASD I/O start subchannel count for address space plus dependent enclaves

SMF Info
--------
    Field: `SMF30AIS`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O start subchannel count for address space plus dependent enclaves
"""

ind_encl_io_conn_time : Final[Field] = Field(
    name='ind_encl_io_conn_time',
    origin='SMF30EIC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""DASD I/O connect time for independent enclaves owned by the address space in 128-microsecond units

SMF Info
--------
    Field: `SMF30EIC`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O connect time for independent enclaves owned by the address space in 128-microsecond units
"""
ind_encl_io_conn_time.__doc__ = """DASD I/O connect time for independent enclaves owned by the address space in 128-microsecond units

SMF Info
--------
    Field: `SMF30EIC`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O connect time for independent enclaves owned by the address space in 128-microsecond units
"""

ind_encl_io_diss_conn_time : Final[Field] = Field(
    name='ind_encl_io_diss_conn_time',
    origin='SMF30EID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""DASD I/O disconnect time for independent enclaves owned by the address space in 128-microsecond units

SMF Info
--------
    Field: `SMF30EID`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O disconnect time for independent enclaves owned by the address space in 128-microsecond units
"""
ind_encl_io_diss_conn_time.__doc__ = """DASD I/O disconnect time for independent enclaves owned by the address space in 128-microsecond units

SMF Info
--------
    Field: `SMF30EID`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O disconnect time for independent enclaves owned by the address space in 128-microsecond units
"""

ind_encl_io_pending_time : Final[Field] = Field(
    name='ind_encl_io_pending_time',
    origin='SMF30EIW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""DASD I/O pending plus control unit queue time for independent enclaves owned by the address space in 128-microsecond units

SMF Info
--------
    Field: `SMF30EIW`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O pending plus control unit queue time for independent enclaves owned by the address space in 128-microsecond units
"""
ind_encl_io_pending_time.__doc__ = """DASD I/O pending plus control unit queue time for independent enclaves owned by the address space in 128-microsecond units

SMF Info
--------
    Field: `SMF30EIW`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O pending plus control unit queue time for independent enclaves owned by the address space in 128-microsecond units
"""

ind_encl_io_subchann_time : Final[Field] = Field(
    name='ind_encl_io_subchann_time',
    origin='SMF30EIS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""DASD I/O start subchannel count for independent enclaves owned by the address space

SMF Info
--------
    Field: `SMF30EIS`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O start subchannel count for independent enclaves owned by the address space
"""
ind_encl_io_subchann_time.__doc__ = """DASD I/O start subchannel count for independent enclaves owned by the address space

SMF Info
--------
    Field: `SMF30EIS`
    Record: `SMF30S5`
    Map: `SMF30URA`

DASD I/O start subchannel count for independent enclaves owned by the address space
"""

total_blocks_transferred_8b : Final[Field] = Field(
    name='total_blocks_transferred_8b',
    origin='SMF30TEX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""Total blocks transferred - Accumulated EXCP counts - This is the 8-byte equivalent of SMF30TEP. This field remains valid after SMF30TEP is invalid

SMF Info
--------
    Field: `SMF30TEX`
    Record: `SMF30S5`
    Map: `SMF30URA`

Total blocks transferred - Accumulated EXCP counts - This is the 8-byte equivalent of SMF30TEP. This field remains valid after SMF30TEP is invalid
"""
total_blocks_transferred_8b.__doc__ = """Total blocks transferred - Accumulated EXCP counts - This is the 8-byte equivalent of SMF30TEP. This field remains valid after SMF30TEP is invalid

SMF Info
--------
    Field: `SMF30TEX`
    Record: `SMF30S5`
    Map: `SMF30URA`

Total blocks transferred - Accumulated EXCP counts - This is the 8-byte equivalent of SMF30TEP. This field remains valid after SMF30TEP is invalid
"""

dds_acc_info_supp : Final[Field] = Field(
    name='dds_acc_info_supp',
    origin='SMF30DAS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30URA,
)
"""Number of DDs which had their DD Accounting information suppressed

SMF Info
--------
    Field: `SMF30DAS`
    Record: `SMF30S5`
    Map: `SMF30URA`

Number of DDs which had their DD Accounting information suppressed
"""
dds_acc_info_supp.__doc__ = """Number of DDs which had their DD Accounting information suppressed

SMF Info
--------
    Field: `SMF30DAS`
    Record: `SMF30S5`
    Map: `SMF30URA`

Number of DDs which had their DD Accounting information suppressed
"""

step_completion_code : Final[Field] = Field(
    name='step_completion_code',
    origin='SMF30SCC',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CMP,
)
"""STEP COMPLETION CODE

SMF Info
--------
    Field: `SMF30SCC`
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP COMPLETION CODE
"""
step_completion_code.__doc__ = """STEP COMPLETION CODE

SMF Info
--------
    Field: `SMF30SCC`
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP COMPLETION CODE
"""

uab : Final[Field] = Field(
    name='uab',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=step_completion_code,
    record=record,
    record_map=SMF30CMP,
)
"""USER ABEND.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `step_completion_code`(`SMF30SCC`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

USER ABEND.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
uab.__doc__ = """USER ABEND.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `step_completion_code`(`SMF30SCC`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

USER ABEND.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sti : Final[Field] = Field(
    name='sti',
    origin='SMF30STI',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CMP,
)
"""STEP TERMINATION INDICATOR

SMF Info
--------
    Field: `SMF30STI`
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP TERMINATION INDICATOR
"""
sti.__doc__ = """STEP TERMINATION INDICATOR

SMF Info
--------
    Field: `SMF30STI`
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP TERMINATION INDICATOR
"""

slc : Final[Field] = Field(
    name='slc',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""JOB was cancelled by SMFLIM parmlib policy. Note that SMF30USI will also be on.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

JOB was cancelled by SMFLIM parmlib policy. Note that SMF30USI will also be on.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
slc.__doc__ = """JOB was cancelled by SMFLIM parmlib policy. Note that SMF30USI will also be on.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

JOB was cancelled by SMFLIM parmlib policy. Note that SMF30USI will also be on.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

ujv : Final[Field] = Field(
    name='ujv',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""CANCELLED AT IEFUJV(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

CANCELLED AT IEFUJV

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
ujv.__doc__ = """CANCELLED AT IEFUJV(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

CANCELLED AT IEFUJV

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

uji : Final[Field] = Field(
    name='uji',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""CANCELLED AT IEFUJI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

CANCELLED AT IEFUJI

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
uji.__doc__ = """CANCELLED AT IEFUJI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

CANCELLED AT IEFUJI

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

usi : Final[Field] = Field(
    name='usi',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""CANCELLED AT IEFUSI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

CANCELLED AT IEFUSI

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
usi.__doc__ = """CANCELLED AT IEFUSI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

CANCELLED AT IEFUSI

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

trt : Final[Field] = Field(
    name='trt',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""CANCELLED AT IEFACTRT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

CANCELLED AT IEFACTRT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
trt.__doc__ = """CANCELLED AT IEFACTRT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

CANCELLED AT IEFACTRT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

srs : Final[Field] = Field(
    name='srs',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""STEP IS TO BE RESTARTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP IS TO BE RESTARTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
srs.__doc__ = """STEP IS TO BE RESTARTED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP IS TO BE RESTARTED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

abd : Final[Field] = Field(
    name='abd',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""STEP ABENDED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP ABENDED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
abd.__doc__ = """STEP ABENDED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP ABENDED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

flh : Final[Field] = Field(
    name='flh',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""STEP FLUSHED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP FLUSHED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
flh.__doc__ = """STEP FLUSHED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP FLUSHED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

exf : Final[Field] = Field(
    name='exf',
    origin=None,
    post='core.flags',
    post_param=8,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""EXCP COUNTS MAY BE WRONG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

EXCP COUNTS MAY BE WRONG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `8`
"""
exf.__doc__ = """EXCP COUNTS MAY BE WRONG(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

EXCP COUNTS MAY BE WRONG

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `8`
"""

isk : Final[Field] = Field(
    name='isk',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""PREVIOUS INTERVAL SKIPPED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

PREVIOUS INTERVAL SKIPPED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
isk.__doc__ = """PREVIOUS INTERVAL SKIPPED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

PREVIOUS INTERVAL SKIPPED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

nex : Final[Field] = Field(
    name='nex',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""EXCP SECTIONS NOT MERGED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

EXCP SECTIONS NOT MERGED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
nex.__doc__ = """EXCP SECTIONS NOT MERGED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

EXCP SECTIONS NOT MERGED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

sye : Final[Field] = Field(
    name='sye',
    origin=None,
    post='core.flags',
    post_param=11,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""STEP END WITH "POST EXECUTION" ERROR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP END WITH "POST EXECUTION" ERROR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `11`
"""
sye.__doc__ = """STEP END WITH "POST EXECUTION" ERROR(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP END WITH "POST EXECUTION" ERROR

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `11`
"""

ere : Final[Field] = Field(
    name='ere',
    origin=None,
    post='core.flags',
    post_param=12,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""STEP ENDED DUE TO OpenMVS EXEC() FUNCTION REQUEST(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP ENDED DUE TO OpenMVS EXEC() FUNCTION REQUEST

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `12`
"""
ere.__doc__ = """STEP ENDED DUE TO OpenMVS EXEC() FUNCTION REQUEST(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

STEP ENDED DUE TO OpenMVS EXEC() FUNCTION REQUEST

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `12`
"""

cde : Final[Field] = Field(
    name='cde',
    origin=None,
    post='core.flags',
    post_param=13,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""JOB abnormally ended(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

JOB abnormally ended

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `13`
"""
cde.__doc__ = """JOB abnormally ended(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

JOB abnormally ended

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `13`
"""

cnr : Final[Field] = Field(
    name='cnr',
    origin=None,
    post='core.flags',
    post_param=14,
    virtual=True,
    ref=sti,
    record=record,
    record_map=SMF30CMP,
)
"""Job was evicted via the $EJnn,STEP,HOLD or equivalent command. This bit is set for subtype 4 (step end) records only.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

Job was evicted via the $EJnn,STEP,HOLD or equivalent command. This bit is set for subtype 4 (step end) records only.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `14`
"""
cnr.__doc__ = """Job was evicted via the $EJnn,STEP,HOLD or equivalent command. This bit is set for subtype 4 (step end) records only.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `sti`(`SMF30STI`)
    Record: `SMF30S5`
    Map: `SMF30CMP`

Job was evicted via the $EJnn,STEP,HOLD or equivalent command. This bit is set for subtype 4 (step end) records only.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `14`
"""

abend_reason_code : Final[Field] = Field(
    name='abend_reason_code',
    origin='SMF30ARC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CMP,
)
"""ABEND REASON CODE

SMF Info
--------
    Field: `SMF30ARC`
    Record: `SMF30S5`
    Map: `SMF30CMP`

ABEND REASON CODE
"""
abend_reason_code.__doc__ = """ABEND REASON CODE

SMF Info
--------
    Field: `SMF30ARC`
    Record: `SMF30S5`
    Map: `SMF30CMP`

ABEND REASON CODE
"""

invalid_timer_flg : Final[Field] = Field(
    name='invalid_timer_flg',
    origin='SMF30TFL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CAS,
)
"""TIMER FLAGS - ALIAS

SMF Info
--------
    Field: `SMF30TFL`
    Record: `SMF30S5`
    Map: `SMF30CAS`

TIMER FLAGS - ALIAS
"""
invalid_timer_flg.__doc__ = """TIMER FLAGS - ALIAS

SMF Info
--------
    Field: `SMF30TFL`
    Record: `SMF30S5`
    Map: `SMF30CAS`

TIMER FLAGS - ALIAS
"""

timer_used : Final[Field] = Field(
    name='timer_used',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""TIMER FLAGS USED IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

TIMER FLAGS USED IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
timer_used.__doc__ = """TIMER FLAGS USED IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

TIMER FLAGS USED IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cpt_invalid : Final[Field] = Field(
    name='cpt_invalid',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30CPT INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30CPT INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cpt_invalid.__doc__ = """SMF30CPT INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30CPT INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

cps_invalid : Final[Field] = Field(
    name='cps_invalid',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30CPS INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30CPS INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
cps_invalid.__doc__ = """SMF30CPS INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30CPS INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

jvu_invalid : Final[Field] = Field(
    name='jvu_invalid',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30JVU INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30JVU INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
jvu_invalid.__doc__ = """SMF30JVU INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30JVU INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

jva_invalid : Final[Field] = Field(
    name='jva_invalid',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30JVA INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30JVA INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
jva_invalid.__doc__ = """SMF30JVA INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30JVA INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

isb_invalid : Final[Field] = Field(
    name='isb_invalid',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30ISB INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30ISB INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
isb_invalid.__doc__ = """SMF30ISB INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30ISB INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

icu_invalid : Final[Field] = Field(
    name='icu_invalid',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30ICU INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30ICU INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
icu_invalid.__doc__ = """SMF30ICU INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30ICU INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ivu_invalid : Final[Field] = Field(
    name='ivu_invalid',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30IVU INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30IVU INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
ivu_invalid.__doc__ = """SMF30IVU INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30IVU INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

iva_invalid : Final[Field] = Field(
    name='iva_invalid',
    origin=None,
    post='core.flags',
    post_param=8,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30IVA INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30IVA INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `8`
"""
iva_invalid.__doc__ = """SMF30IVA INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30IVA INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `8`
"""

iip_invalid : Final[Field] = Field(
    name='iip_invalid',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30IIP INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30IIP INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip_invalid.__doc__ = """SMF30IIP INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30IIP INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

hpt_invalid : Final[Field] = Field(
    name='hpt_invalid',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30HPT INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30HPT INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
hpt_invalid.__doc__ = """SMF30HPT INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30HPT INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

rct_invalid : Final[Field] = Field(
    name='rct_invalid',
    origin=None,
    post='core.flags',
    post_param=11,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30RCT INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30RCT INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `11`
"""
rct_invalid.__doc__ = """SMF30RCT INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30RCT INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `11`
"""

asr_invalid : Final[Field] = Field(
    name='asr_invalid',
    origin=None,
    post='core.flags',
    post_param=12,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30ASR INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30ASR INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `12`
"""
asr_invalid.__doc__ = """SMF30ASR INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30ASR INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `12`
"""

enc_invalid : Final[Field] = Field(
    name='enc_invalid',
    origin=None,
    post='core.flags',
    post_param=13,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30ENC INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30ENC INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `13`
"""
enc_invalid.__doc__ = """SMF30ENC INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30ENC INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `13`
"""

det_invalid : Final[Field] = Field(
    name='det_invalid',
    origin=None,
    post='core.flags',
    post_param=14,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30DET INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30DET INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `14`
"""
det_invalid.__doc__ = """SMF30DET INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30DET INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `14`
"""

cep_invalid : Final[Field] = Field(
    name='cep_invalid',
    origin=None,
    post='core.flags',
    post_param=15,
    virtual=True,
    ref=invalid_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""SMF30CEP INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30CEP INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `15`
"""
cep_invalid.__doc__ = """SMF30CEP INVALID IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `invalid_timer_flg`(`SMF30TFL`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

SMF30CEP INVALID IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `15`
"""

step_time : Final[Field] = Field(
    name='step_time',
    origin='SMF30CPT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""STEP CPU TIME UNDER TCB (INCLUDING ENCLAVE TIME). Note that time on zAAP and zIIP is not included. SMF30CPT only includes the consumption of standard CPs, not those of zAAPs and/or zIIPs

SMF Info
--------
    Field: `SMF30CPT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

STEP CPU TIME UNDER TCB (INCLUDING ENCLAVE TIME). Note that time on zAAP and zIIP is not included. SMF30CPT only includes the consumption of standard CPs, not those of zAAPs and/or zIIPs
"""
step_time.__doc__ = """STEP CPU TIME UNDER TCB (INCLUDING ENCLAVE TIME). Note that time on zAAP and zIIP is not included. SMF30CPT only includes the consumption of standard CPs, not those of zAAPs and/or zIIPs

SMF Info
--------
    Field: `SMF30CPT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

STEP CPU TIME UNDER TCB (INCLUDING ENCLAVE TIME). Note that time on zAAP and zIIP is not included. SMF30CPT only includes the consumption of standard CPs, not those of zAAPs and/or zIIPs
"""

srb_step_cpu_time : Final[Field] = Field(
    name='srb_step_cpu_time',
    origin='SMF30CPS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""STEP CPU TIME UNDER SRB

SMF Info
--------
    Field: `SMF30CPS`
    Record: `SMF30S5`
    Map: `SMF30CAS`

STEP CPU TIME UNDER SRB
"""
srb_step_cpu_time.__doc__ = """STEP CPU TIME UNDER SRB

SMF Info
--------
    Field: `SMF30CPS`
    Record: `SMF30S5`
    Map: `SMF30CAS`

STEP CPU TIME UNDER SRB
"""

initiator_cpu_time : Final[Field] = Field(
    name='initiator_cpu_time',
    origin='SMF30ICU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""INIT CPU TIME UNDER TCB

SMF Info
--------
    Field: `SMF30ICU`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INIT CPU TIME UNDER TCB
"""
initiator_cpu_time.__doc__ = """INIT CPU TIME UNDER TCB

SMF Info
--------
    Field: `SMF30ICU`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INIT CPU TIME UNDER TCB
"""

srb_initiator_cpu_time : Final[Field] = Field(
    name='srb_initiator_cpu_time',
    origin='SMF30ISB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""INIT CPU TIME UNDER SRB

SMF Info
--------
    Field: `SMF30ISB`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INIT CPU TIME UNDER SRB
"""
srb_initiator_cpu_time.__doc__ = """INIT CPU TIME UNDER SRB

SMF Info
--------
    Field: `SMF30ISB`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INIT CPU TIME UNDER SRB
"""

step_vec_time : Final[Field] = Field(
    name='step_vec_time',
    origin='SMF30JVU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""STEP VECTOR USAGE TIME

SMF Info
--------
    Field: `SMF30JVU`
    Record: `SMF30S5`
    Map: `SMF30CAS`

STEP VECTOR USAGE TIME
"""
step_vec_time.__doc__ = """STEP VECTOR USAGE TIME

SMF Info
--------
    Field: `SMF30JVU`
    Record: `SMF30S5`
    Map: `SMF30CAS`

STEP VECTOR USAGE TIME
"""

initiator_vec_time : Final[Field] = Field(
    name='initiator_vec_time',
    origin='SMF30IVU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""INIT VECTOR USAGE TIME

SMF Info
--------
    Field: `SMF30IVU`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INIT VECTOR USAGE TIME
"""
initiator_vec_time.__doc__ = """INIT VECTOR USAGE TIME

SMF Info
--------
    Field: `SMF30IVU`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INIT VECTOR USAGE TIME
"""

step_vec_affinity_time : Final[Field] = Field(
    name='step_vec_affinity_time',
    origin='SMF30JVA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""STEP VECTOR AFFINITY TIME

SMF Info
--------
    Field: `SMF30JVA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

STEP VECTOR AFFINITY TIME
"""
step_vec_affinity_time.__doc__ = """STEP VECTOR AFFINITY TIME

SMF Info
--------
    Field: `SMF30JVA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

STEP VECTOR AFFINITY TIME
"""

initiator_vec_affinity_time : Final[Field] = Field(
    name='initiator_vec_affinity_time',
    origin='SMF30IVA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""INIT VECTOR AFFINITY TIME

SMF Info
--------
    Field: `SMF30IVA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INIT VECTOR AFFINITY TIME
"""
initiator_vec_affinity_time.__doc__ = """INIT VECTOR AFFINITY TIME

SMF Info
--------
    Field: `SMF30IVA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INIT VECTOR AFFINITY TIME
"""

interval_start_time : Final[Field] = Field(
    name='interval_start_time',
    origin='SMF30IST',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""INTERVAL START TIME

SMF Info
--------
    Field: `SMF30IST`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INTERVAL START TIME
"""
interval_start_time.__doc__ = """INTERVAL START TIME

SMF Info
--------
    Field: `SMF30IST`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INTERVAL START TIME
"""

interval_start_date : Final[Field] = Field(
    name='interval_start_date',
    origin='SMF30IDT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF30CAS,
)
"""INTERVAL START DATE

SMF Info
--------
    Field: `SMF30IDT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INTERVAL START DATE
"""
interval_start_date.__doc__ = """INTERVAL START DATE

SMF Info
--------
    Field: `SMF30IDT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INTERVAL START DATE
"""

io_interrupt_time : Final[Field] = Field(
    name='io_interrupt_time',
    origin='SMF30IIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""I/O INTERRUPT PROCESSING TIME

SMF Info
--------
    Field: `SMF30IIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

I/O INTERRUPT PROCESSING TIME
"""
io_interrupt_time.__doc__ = """I/O INTERRUPT PROCESSING TIME

SMF Info
--------
    Field: `SMF30IIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

I/O INTERRUPT PROCESSING TIME
"""

rct_cpu_time : Final[Field] = Field(
    name='rct_cpu_time',
    origin='SMF30RCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""RCT CPU TIME

SMF Info
--------
    Field: `SMF30RCT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

RCT CPU TIME
"""
rct_cpu_time.__doc__ = """RCT CPU TIME

SMF Info
--------
    Field: `SMF30RCT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

RCT CPU TIME
"""

hiperspace_processing_time : Final[Field] = Field(
    name='hiperspace_processing_time',
    origin='SMF30HPT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""HIPERSPACE PROCESSING TIME

SMF Info
--------
    Field: `SMF30HPT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

HIPERSPACE PROCESSING TIME
"""
hiperspace_processing_time.__doc__ = """HIPERSPACE PROCESSING TIME

SMF Info
--------
    Field: `SMF30HPT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

HIPERSPACE PROCESSING TIME
"""

icsf_svc_count : Final[Field] = Field(
    name='icsf_svc_count',
    origin='SMF30CSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""INTEGRATED CRYPTO SERVICE COUNT

SMF Info
--------
    Field: `SMF30CSC`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INTEGRATED CRYPTO SERVICE COUNT
"""
icsf_svc_count.__doc__ = """INTEGRATED CRYPTO SERVICE COUNT

SMF Info
--------
    Field: `SMF30CSC`
    Record: `SMF30S5`
    Map: `SMF30CAS`

INTEGRATED CRYPTO SERVICE COUNT
"""

admf_write_pages : Final[Field] = Field(
    name='admf_write_pages',
    origin='SMF30DMI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Number of pages moved with ADMF WRITE operation

SMF Info
--------
    Field: `SMF30DMI`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Number of pages moved with ADMF WRITE operation
"""
admf_write_pages.__doc__ = """Number of pages moved with ADMF WRITE operation

SMF Info
--------
    Field: `SMF30DMI`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Number of pages moved with ADMF WRITE operation
"""

admf_read_pages : Final[Field] = Field(
    name='admf_read_pages',
    origin='SMF30DMO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Number of pages moved with ADMF READ operation

SMF Info
--------
    Field: `SMF30DMO`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Number of pages moved with ADMF READ operation
"""
admf_read_pages.__doc__ = """Number of pages moved with ADMF READ operation

SMF Info
--------
    Field: `SMF30DMO`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Number of pages moved with ADMF READ operation
"""

additional_srb_step_cpu_time : Final[Field] = Field(
    name='additional_srb_step_cpu_time',
    origin='SMF30ASR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Additional CPU time, in hundredths of a second, accumulated by the Preemptable SRB's and Client SRB's for this job. This value is also contained within the value in SMF30CPT.

SMF Info
--------
    Field: `SMF30ASR`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Additional CPU time, in hundredths of a second, accumulated by the Preemptable SRB's and Client SRB's for this job. This value is also contained within the value in SMF30CPT.
"""
additional_srb_step_cpu_time.__doc__ = """Additional CPU time, in hundredths of a second, accumulated by the Preemptable SRB's and Client SRB's for this job. This value is also contained within the value in SMF30CPT.

SMF Info
--------
    Field: `SMF30ASR`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Additional CPU time, in hundredths of a second, accumulated by the Preemptable SRB's and Client SRB's for this job. This value is also contained within the value in SMF30CPT.
"""

ind_encl_cpu_time : Final[Field] = Field(
    name='ind_encl_cpu_time',
    origin='SMF30ENC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Independent enclave CPU time for the step (or job) in hundredths of a second. This value is also contained within the value in SMF30CPT. Note that time on zAAP and zIIP is not included.

SMF Info
--------
    Field: `SMF30ENC`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Independent enclave CPU time for the step (or job) in hundredths of a second. This value is also contained within the value in SMF30CPT. Note that time on zAAP and zIIP is not included.
"""
ind_encl_cpu_time.__doc__ = """Independent enclave CPU time for the step (or job) in hundredths of a second. This value is also contained within the value in SMF30CPT. Note that time on zAAP and zIIP is not included.

SMF Info
--------
    Field: `SMF30ENC`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Independent enclave CPU time for the step (or job) in hundredths of a second. This value is also contained within the value in SMF30CPT. Note that time on zAAP and zIIP is not included.
"""

dep_encl_cpu_time : Final[Field] = Field(
    name='dep_encl_cpu_time',
    origin='SMF30DET',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Dependent enclave CPU time for the step (or job) in hundredths of a second. This value is also contained within the value in SMF30CPT. Note that time on zAAP and zIIP is not included.

SMF Info
--------
    Field: `SMF30DET`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave CPU time for the step (or job) in hundredths of a second. This value is also contained within the value in SMF30CPT. Note that time on zAAP and zIIP is not included.
"""
dep_encl_cpu_time.__doc__ = """Dependent enclave CPU time for the step (or job) in hundredths of a second. This value is also contained within the value in SMF30CPT. Note that time on zAAP and zIIP is not included.

SMF Info
--------
    Field: `SMF30DET`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave CPU time for the step (or job) in hundredths of a second. This value is also contained within the value in SMF30CPT. Note that time on zAAP and zIIP is not included.
"""

cum_cpu_time : Final[Field] = Field(
    name='cum_cpu_time',
    origin='SMF30CEP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""CPU time consumed for an A/S or Job while enqueue promoted. 1.024 milliseconds unit Unlike SMF30CEPI, this field is "cumulative" even for interval records.

SMF Info
--------
    Field: `SMF30CEP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU time consumed for an A/S or Job while enqueue promoted. 1.024 milliseconds unit Unlike SMF30CEPI, this field is "cumulative" even for interval records.
"""
cum_cpu_time.__doc__ = """CPU time consumed for an A/S or Job while enqueue promoted. 1.024 milliseconds unit Unlike SMF30CEPI, this field is "cumulative" even for interval records.

SMF Info
--------
    Field: `SMF30CEP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU time consumed for an A/S or Job while enqueue promoted. 1.024 milliseconds unit Unlike SMF30CEPI, this field is "cumulative" even for interval records.
"""

additional_timer_flg : Final[Field] = Field(
    name='additional_timer_flg',
    origin='SMF30TF2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CAS,
)
"""More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid

SMF Info
--------
    Field: `SMF30TF2`
    Record: `SMF30S5`
    Map: `SMF30CAS`

More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid
"""
additional_timer_flg.__doc__ = """More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid

SMF Info
--------
    Field: `SMF30TF2`
    Record: `SMF30S5`
    Map: `SMF30CAS`

More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid
"""

time_on_ifa_invalid : Final[Field] = Field(
    name='time_on_ifa_invalid',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=additional_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
time_on_ifa_invalid.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

enclave_time_on_ifa_invalid : Final[Field] = Field(
    name='enclave_time_on_ifa_invalid',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=additional_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
enclave_time_on_ifa_invalid.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

dep_enclave_time_on_ifa_invalid : Final[Field] = Field(
    name='dep_enclave_time_on_ifa_invalid',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=additional_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
dep_enclave_time_on_ifa_invalid.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

time_ifa_on_cp_invalid : Final[Field] = Field(
    name='time_ifa_on_cp_invalid',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=additional_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
time_ifa_on_cp_invalid.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

enclave_time_ifa_on_cp_invalid : Final[Field] = Field(
    name='enclave_time_ifa_on_cp_invalid',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=additional_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
enclave_time_ifa_on_cp_invalid.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

dep_enclave_time_ifa_on_cp_invalid : Final[Field] = Field(
    name='dep_enclave_time_ifa_on_cp_invalid',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=additional_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
dep_enclave_time_ifa_on_cp_invalid.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

cepi_failed : Final[Field] = Field(
    name='cepi_failed',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=additional_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Failure in SMF30CEPI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure in SMF30CEPI

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
cepi_failed.__doc__ = """Failure in SMF30CEPI(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure in SMF30CEPI

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

crp_failed : Final[Field] = Field(
    name='crp_failed',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=additional_timer_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Failure in SMF30CRP(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure in SMF30CRP

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
crp_failed.__doc__ = """Failure in SMF30CRP(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_timer_flg`(`SMF30TF2`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure in SMF30CRP

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

additional_failure_flg : Final[Field] = Field(
    name='additional_failure_flg',
    origin='SMF30T32',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CAS,
)
"""More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid

SMF Info
--------
    Field: `SMF30T32`
    Record: `SMF30S5`
    Map: `SMF30CAS`

More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid
"""
additional_failure_flg.__doc__ = """More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid

SMF Info
--------
    Field: `SMF30T32`
    Record: `SMF30S5`
    Map: `SMF30CAS`

More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid
"""

time_on_ziip_f : Final[Field] = Field(
    name='time_on_ziip_f',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=additional_failure_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
time_on_ziip_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

enclave_time_on_ziip_f : Final[Field] = Field(
    name='enclave_time_on_ziip_f',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=additional_failure_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
enclave_time_on_ziip_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

depenc_time_on_ziip_f : Final[Field] = Field(
    name='depenc_time_on_ziip_f',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=additional_failure_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
depenc_time_on_ziip_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

time_ziip_on_cp_f : Final[Field] = Field(
    name='time_ziip_on_cp_f',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=additional_failure_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
time_ziip_on_cp_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

enclave_time_ziip_on_cp_f : Final[Field] = Field(
    name='enclave_time_ziip_on_cp_f',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=additional_failure_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
enclave_time_ziip_on_cp_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

depenc_time_ziip_on_cp_f : Final[Field] = Field(
    name='depenc_time_ziip_on_cp_f',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=additional_failure_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
depenc_time_ziip_on_cp_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

time_java_on_ziip_f : Final[Field] = Field(
    name='time_java_on_ziip_f',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=additional_failure_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
time_java_on_ziip_f.__doc__ = """Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

enclave_time_java_on_ziip_f : Final[Field] = Field(
    name='enclave_time_java_on_ziip_f',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=additional_failure_flg,
    record=record,
    record_map=SMF30CAS,
)
"""Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
enclave_time_java_on_ziip_f.__doc__ = """Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg`(`SMF30T32`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

additional_failure_flg_2 : Final[Field] = Field(
    name='additional_failure_flg_2',
    origin='SMF30T33',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CAS,
)
"""More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid

SMF Info
--------
    Field: `SMF30T33`
    Record: `SMF30S5`
    Map: `SMF30CAS`

More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid
"""
additional_failure_flg_2.__doc__ = """More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid

SMF Info
--------
    Field: `SMF30T33`
    Record: `SMF30S5`
    Map: `SMF30CAS`

More failure bits. Each flag name is of form xxxx_F and indicates that field xxxx is not valid
"""

enclave_time_on_ziip_n_f : Final[Field] = Field(
    name='enclave_time_on_ziip_n_f',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=additional_failure_flg_2,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
enclave_time_on_ziip_n_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

depenc_time_on_ziip_n_f : Final[Field] = Field(
    name='depenc_time_on_ziip_n_f',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=additional_failure_flg_2,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
depenc_time_on_ziip_n_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

enclave_time_ziip_qual_f : Final[Field] = Field(
    name='enclave_time_ziip_qual_f',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=additional_failure_flg_2,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
enclave_time_ziip_qual_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

depenc_time_ziip_qual_f : Final[Field] = Field(
    name='depenc_time_ziip_qual_f',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=additional_failure_flg_2,
    record=record,
    record_map=SMF30CAS,
)
"""Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
depenc_time_ziip_qual_f.__doc__ = """Not available(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Not available

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

depenc_time_java_on_ziip_f : Final[Field] = Field(
    name='depenc_time_java_on_ziip_f',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=additional_failure_flg_2,
    record=record,
    record_map=SMF30CAS,
)
"""Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
depenc_time_java_on_ziip_f.__doc__ = """Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

time_java_on_cp_f : Final[Field] = Field(
    name='time_java_on_cp_f',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=additional_failure_flg_2,
    record=record,
    record_map=SMF30CAS,
)
"""Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
time_java_on_cp_f.__doc__ = """Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

enclave_time_java_on_cp_f : Final[Field] = Field(
    name='enclave_time_java_on_cp_f',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=additional_failure_flg_2,
    record=record,
    record_map=SMF30CAS,
)
"""Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
enclave_time_java_on_cp_f.__doc__ = """Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

depenc_time_java_on_cp_f : Final[Field] = Field(
    name='depenc_time_java_on_cp_f',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=additional_failure_flg_2,
    record=record,
    record_map=SMF30CAS,
)
"""Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
depenc_time_java_on_cp_f.__doc__ = """Failure Flag(V)

SMF Info (Virtual Field)
--------
    Field: Based on `additional_failure_flg_2`(`SMF30T33`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Failure Flag

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

boostinfo : Final[Field] = Field(
    name='boostinfo',
    origin='SMF30_BOOSTINFO',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CAS,
)
"""Boost information

SMF Info
--------
    Field: `SMF30_BOOSTINFO`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Boost information
"""
boostinfo.__doc__ = """Boost information

SMF Info
--------
    Field: `SMF30_BOOSTINFO`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Boost information
"""

ziipboost_active : Final[Field] = Field(
    name='ziipboost_active',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=boostinfo,
    record=record,
    record_map=SMF30CAS,
)
"""zIIP boost was active at some point within the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `boostinfo`(`SMF30_BOOSTINFO`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP boost was active at some point within the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
ziipboost_active.__doc__ = """zIIP boost was active at some point within the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `boostinfo`(`SMF30_BOOSTINFO`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP boost was active at some point within the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

speedboost_active : Final[Field] = Field(
    name='speedboost_active',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=boostinfo,
    record=record,
    record_map=SMF30CAS,
)
"""Speed boost was active at some point within the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `boostinfo`(`SMF30_BOOSTINFO`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Speed boost was active at some point within the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
speedboost_active.__doc__ = """Speed boost was active at some point within the interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `boostinfo`(`SMF30_BOOSTINFO`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

Speed boost was active at some point within the interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

boostclass : Final[Field] = Field(
    name='boostclass',
    origin='SMF30_BOOSTCLASS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CAS,
)
"""See SMF30_BoostClass_xxx equates. For step and job records, the boost class when a boost was first found active for the step/job

SMF Info
--------
    Field: `SMF30_BOOSTCLASS`
    Record: `SMF30S5`
    Map: `SMF30CAS`

See SMF30_BoostClass_xxx equates. For step and job records, the boost class when a boost was first found active for the step/job
"""
boostclass.__doc__ = """See SMF30_BoostClass_xxx equates. For step and job records, the boost class when a boost was first found active for the step/job

SMF Info
--------
    Field: `SMF30_BOOSTCLASS`
    Record: `SMF30S5`
    Map: `SMF30CAS`

See SMF30_BoostClass_xxx equates. For step and job records, the boost class when a boost was first found active for the step/job
"""

acc_zaap_time : Final[Field] = Field(
    name='acc_zaap_time',
    origin='SMF30_TIME_ON_IFA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Time spent on IFA In hundredths of a second (including enclave time)

SMF Info
--------
    Field: `SMF30_TIME_ON_IFA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Time spent on IFA In hundredths of a second (including enclave time)
"""
acc_zaap_time.__doc__ = """Time spent on IFA In hundredths of a second (including enclave time)

SMF Info
--------
    Field: `SMF30_TIME_ON_IFA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Time spent on IFA In hundredths of a second (including enclave time)
"""

enclave_time_on_ifa : Final[Field] = Field(
    name='enclave_time_on_ifa',
    origin='SMF30_ENCLAVE_TIME_ON_IFA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Enclave time spent on IFA In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_ON_IFA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Enclave time spent on IFA In hundredths of a second
"""
enclave_time_on_ifa.__doc__ = """Enclave time spent on IFA In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_ON_IFA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Enclave time spent on IFA In hundredths of a second
"""

dep_enclave_time_on_ifa : Final[Field] = Field(
    name='dep_enclave_time_on_ifa',
    origin='SMF30_DEP_ENCLAVE_TIME_ON_IFA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Dependent enclave time spent on IFA. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEP_ENCLAVE_TIME_ON_IFA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave time spent on IFA. In hundredths of a second
"""
dep_enclave_time_on_ifa.__doc__ = """Dependent enclave time spent on IFA. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEP_ENCLAVE_TIME_ON_IFA`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave time spent on IFA. In hundredths of a second
"""

time_ifa_on_cp : Final[Field] = Field(
    name='time_ifa_on_cp',
    origin='SMF30_TIME_IFA_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""IFA CPU time spent on CP In hundredths of a second (including enclave time)

SMF Info
--------
    Field: `SMF30_TIME_IFA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

IFA CPU time spent on CP In hundredths of a second (including enclave time)
"""
time_ifa_on_cp.__doc__ = """IFA CPU time spent on CP In hundredths of a second (including enclave time)

SMF Info
--------
    Field: `SMF30_TIME_IFA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

IFA CPU time spent on CP In hundredths of a second (including enclave time)
"""

enclave_time_ifa_on_cp : Final[Field] = Field(
    name='enclave_time_ifa_on_cp',
    origin='SMF30_ENCLAVE_TIME_IFA_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""IFA Enclave time spent on CP In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_IFA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

IFA Enclave time spent on CP In hundredths of a second
"""
enclave_time_ifa_on_cp.__doc__ = """IFA Enclave time spent on CP In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_IFA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

IFA Enclave time spent on CP In hundredths of a second
"""

dep_enclave_time_ifa_on_cp : Final[Field] = Field(
    name='dep_enclave_time_ifa_on_cp',
    origin='SMF30_DEP_ENCLAVE_TIME_IFA_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""IFA Dependent enclave time spent on CP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEP_ENCLAVE_TIME_IFA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

IFA Dependent enclave time spent on CP. In hundredths of a second
"""
dep_enclave_time_ifa_on_cp.__doc__ = """IFA Dependent enclave time spent on CP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEP_ENCLAVE_TIME_IFA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

IFA Dependent enclave time spent on CP. In hundredths of a second
"""

enqueue_promoted_cpu_time : Final[Field] = Field(
    name='enqueue_promoted_cpu_time',
    origin='SMF30CEPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""CPU time consumed for an A/S or Job while enqueue promoted. 1.024 milliseconds unit Unlike SMF30CEP, for interval records, this field contains only the time consumed during the interval itself.

SMF Info
--------
    Field: `SMF30CEPI`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU time consumed for an A/S or Job while enqueue promoted. 1.024 milliseconds unit Unlike SMF30CEP, for interval records, this field contains only the time consumed during the interval itself.
"""
enqueue_promoted_cpu_time.__doc__ = """CPU time consumed for an A/S or Job while enqueue promoted. 1.024 milliseconds unit Unlike SMF30CEP, for interval records, this field contains only the time consumed during the interval itself.

SMF Info
--------
    Field: `SMF30CEPI`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU time consumed for an A/S or Job while enqueue promoted. 1.024 milliseconds unit Unlike SMF30CEP, for interval records, this field contains only the time consumed during the interval itself.
"""

ziip_time : Final[Field] = Field(
    name='ziip_time',
    origin='SMF30_TIME_ON_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Time spent on zIIP In hundredths of a second (including enclave time)

SMF Info
--------
    Field: `SMF30_TIME_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Time spent on zIIP In hundredths of a second (including enclave time)
"""
ziip_time.__doc__ = """Time spent on zIIP In hundredths of a second (including enclave time)

SMF Info
--------
    Field: `SMF30_TIME_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Time spent on zIIP In hundredths of a second (including enclave time)
"""

encl_ziip_time : Final[Field] = Field(
    name='encl_ziip_time',
    origin='SMF30_ENCLAVE_TIME_ON_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Enclave time spent on zIIP In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Enclave time spent on zIIP In hundredths of a second
"""
encl_ziip_time.__doc__ = """Enclave time spent on zIIP In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Enclave time spent on zIIP In hundredths of a second
"""

dev_encl_ziip_time : Final[Field] = Field(
    name='dev_encl_ziip_time',
    origin='SMF30_DEPENC_TIME_ON_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Dependent enclave time spent on zIIP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave time spent on zIIP. In hundredths of a second
"""
dev_encl_ziip_time.__doc__ = """Dependent enclave time spent on zIIP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave time spent on zIIP. In hundredths of a second
"""

ziip_on_cp_time : Final[Field] = Field(
    name='ziip_on_cp_time',
    origin='SMF30_TIME_ZIIP_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""zIIP CPU time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP CPU time spent on CP. In hundredths of a second (including enclave time)

SMF Info
--------
    Field: `SMF30_TIME_ZIIP_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP CPU time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP CPU time spent on CP. In hundredths of a second (including enclave time)
"""
ziip_on_cp_time.__doc__ = """zIIP CPU time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP CPU time spent on CP. In hundredths of a second (including enclave time)

SMF Info
--------
    Field: `SMF30_TIME_ZIIP_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP CPU time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP CPU time spent on CP. In hundredths of a second (including enclave time)
"""

enclave_time_ziip_on_cp : Final[Field] = Field(
    name='enclave_time_ziip_on_cp',
    origin='SMF30_ENCLAVE_TIME_ZIIP_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""zIIP Enclave time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP Enclave time spent on CP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_ZIIP_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP Enclave time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP Enclave time spent on CP. In hundredths of a second
"""
enclave_time_ziip_on_cp.__doc__ = """zIIP Enclave time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP Enclave time spent on CP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_ZIIP_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP Enclave time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP Enclave time spent on CP. In hundredths of a second
"""

dep_ziip_on_cp_time : Final[Field] = Field(
    name='dep_ziip_on_cp_time',
    origin='SMF30_DEPENC_TIME_ZIIP_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""zIIP Dependent enclave time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP Dependent enclave time spent on CP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_ZIIP_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP Dependent enclave time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP Dependent enclave time spent on CP. In hundredths of a second
"""
dep_ziip_on_cp_time.__doc__ = """zIIP Dependent enclave time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP Dependent enclave time spent on CP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_ZIIP_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP Dependent enclave time spent on CP. When zAAPzIIP=YES is in effect, zAAP-eligible work is included in zIIP Dependent enclave time spent on CP. In hundredths of a second
"""

encl_ziip_qual_time : Final[Field] = Field(
    name='encl_ziip_qual_time',
    origin='SMF30_ENCLAVE_TIME_ZIIP_QUAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Enclave time qualified to run on zIIP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_ZIIP_QUAL`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Enclave time qualified to run on zIIP. In hundredths of a second
"""
encl_ziip_qual_time.__doc__ = """Enclave time qualified to run on zIIP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_ZIIP_QUAL`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Enclave time qualified to run on zIIP. In hundredths of a second
"""

dep_ziip_qual_time : Final[Field] = Field(
    name='dep_ziip_qual_time',
    origin='SMF30_DEPENC_TIME_ZIIP_QUAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Dependent enclave time qualified to run on zIIP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_ZIIP_QUAL`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave time qualified to run on zIIP. In hundredths of a second
"""
dep_ziip_qual_time.__doc__ = """Dependent enclave time qualified to run on zIIP. In hundredths of a second

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_ZIIP_QUAL`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave time qualified to run on zIIP. In hundredths of a second
"""

chronic_res_prom_time : Final[Field] = Field(
    name='chronic_res_prom_time',
    origin='SMF30CRP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""CPU time consumed for an address space or job while promoted due to chronic resource contention (in 1024 millisecond units). For interval records, this field contains only the time consumed during the interval itself.

SMF Info
--------
    Field: `SMF30CRP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU time consumed for an address space or job while promoted due to chronic resource contention (in 1024 millisecond units). For interval records, this field contains only the time consumed during the interval itself.
"""
chronic_res_prom_time.__doc__ = """CPU time consumed for an address space or job while promoted due to chronic resource contention (in 1024 millisecond units). For interval records, this field contains only the time consumed during the interval itself.

SMF Info
--------
    Field: `SMF30CRP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU time consumed for an address space or job while promoted due to chronic resource contention (in 1024 millisecond units). For interval records, this field contains only the time consumed during the interval itself.
"""

icu_step_term : Final[Field] = Field(
    name='icu_step_term',
    origin='SMF30ICU_STEP_TERM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""CPU TCB time spent by the Initiator during job step termination processing. This is the step termination portion of SMF30ICU which is reported in the next step end record

SMF Info
--------
    Field: `SMF30ICU_STEP_TERM`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU TCB time spent by the Initiator during job step termination processing. This is the step termination portion of SMF30ICU which is reported in the next step end record
"""
icu_step_term.__doc__ = """CPU TCB time spent by the Initiator during job step termination processing. This is the step termination portion of SMF30ICU which is reported in the next step end record

SMF Info
--------
    Field: `SMF30ICU_STEP_TERM`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU TCB time spent by the Initiator during job step termination processing. This is the step termination portion of SMF30ICU which is reported in the next step end record
"""

icu_step_init : Final[Field] = Field(
    name='icu_step_init',
    origin='SMF30ICU_STEP_INIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""CPU TCB time spent by the Initiator during job step initialization processing. This is the step initialization portion of SMF30ICU for this step end record.

SMF Info
--------
    Field: `SMF30ICU_STEP_INIT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU TCB time spent by the Initiator during job step initialization processing. This is the step initialization portion of SMF30ICU for this step end record.
"""
icu_step_init.__doc__ = """CPU TCB time spent by the Initiator during job step initialization processing. This is the step initialization portion of SMF30ICU for this step end record.

SMF Info
--------
    Field: `SMF30ICU_STEP_INIT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU TCB time spent by the Initiator during job step initialization processing. This is the step initialization portion of SMF30ICU for this step end record.
"""

isb_step_term : Final[Field] = Field(
    name='isb_step_term',
    origin='SMF30ISB_STEP_TERM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""CPU SRB time spent by the Initiator during job step termination processing. This is the step termination portion of SMF30ISB which is reported in the next step end record

SMF Info
--------
    Field: `SMF30ISB_STEP_TERM`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU SRB time spent by the Initiator during job step termination processing. This is the step termination portion of SMF30ISB which is reported in the next step end record
"""
isb_step_term.__doc__ = """CPU SRB time spent by the Initiator during job step termination processing. This is the step termination portion of SMF30ISB which is reported in the next step end record

SMF Info
--------
    Field: `SMF30ISB_STEP_TERM`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU SRB time spent by the Initiator during job step termination processing. This is the step termination portion of SMF30ISB which is reported in the next step end record
"""

isb_step_init : Final[Field] = Field(
    name='isb_step_init',
    origin='SMF30ISB_STEP_INIT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""CPU SRB time spent by the Initiator during job step initialization processing. This is the step initialization portion of SMF30ISB for this step end record.

SMF Info
--------
    Field: `SMF30ISB_STEP_INIT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU SRB time spent by the Initiator during job step initialization processing. This is the step initialization portion of SMF30ISB for this step end record.
"""
isb_step_init.__doc__ = """CPU SRB time spent by the Initiator during job step initialization processing. This is the step initialization portion of SMF30ISB for this step end record.

SMF Info
--------
    Field: `SMF30ISB_STEP_INIT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU SRB time spent by the Initiator during job step initialization processing. This is the step initialization portion of SMF30ISB for this step end record.
"""

missed_smf30blk : Final[Field] = Field(
    name='missed_smf30blk',
    origin='SMF30_MISSED_SMF30BLK',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Accumulated value of I/O block counts when serialization could not be obtained for accumulating the value to SMF30BLK. This value is maintained at the job step level as opposed to the DD level of its SMF30BLK counterpart. This field contains zero for started tasks.

SMF Info
--------
    Field: `SMF30_MISSED_SMF30BLK`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Accumulated value of I/O block counts when serialization could not be obtained for accumulating the value to SMF30BLK. This value is maintained at the job step level as opposed to the DD level of its SMF30BLK counterpart. This field contains zero for started tasks.
"""
missed_smf30blk.__doc__ = """Accumulated value of I/O block counts when serialization could not be obtained for accumulating the value to SMF30BLK. This value is maintained at the job step level as opposed to the DD level of its SMF30BLK counterpart. This field contains zero for started tasks.

SMF Info
--------
    Field: `SMF30_MISSED_SMF30BLK`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Accumulated value of I/O block counts when serialization could not be obtained for accumulating the value to SMF30BLK. This value is maintained at the job step level as opposed to the DD level of its SMF30BLK counterpart. This field contains zero for started tasks.
"""

missed_smf30dct : Final[Field] = Field(
    name='missed_smf30dct',
    origin='SMF30_MISSED_SMF30DCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Accumulated value of device connect time when serialization could not be obtained for accumulating the value to SMF30DCT. This value is maintained at the job step level as opposed to the DD level of its SMF30DCT counterpart. This field contains zero for started tasks.

SMF Info
--------
    Field: `SMF30_MISSED_SMF30DCT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Accumulated value of device connect time when serialization could not be obtained for accumulating the value to SMF30DCT. This value is maintained at the job step level as opposed to the DD level of its SMF30DCT counterpart. This field contains zero for started tasks.
"""
missed_smf30dct.__doc__ = """Accumulated value of device connect time when serialization could not be obtained for accumulating the value to SMF30DCT. This value is maintained at the job step level as opposed to the DD level of its SMF30DCT counterpart. This field contains zero for started tasks.

SMF Info
--------
    Field: `SMF30_MISSED_SMF30DCT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Accumulated value of device connect time when serialization could not be obtained for accumulating the value to SMF30DCT. This value is maintained at the job step level as opposed to the DD level of its SMF30DCT counterpart. This field contains zero for started tasks.
"""

highest_task_cpu_percent : Final[Field] = Field(
    name='highest_task_cpu_percent',
    origin='SMF30_HIGHEST_TASK_CPU_PERCENT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""For interval records, the largest percentage of CPU time used by any task in this address space, rounded to the nearest integer. The percentage value is calculated as: TCB time * 100 / interval time. For step-end and job-end records, the value is the largest reported interval value.

SMF Info
--------
    Field: `SMF30_HIGHEST_TASK_CPU_PERCENT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

For interval records, the largest percentage of CPU time used by any task in this address space, rounded to the nearest integer. The percentage value is calculated as: TCB time * 100 / interval time. For step-end and job-end records, the value is the largest reported interval value.
"""
highest_task_cpu_percent.__doc__ = """For interval records, the largest percentage of CPU time used by any task in this address space, rounded to the nearest integer. The percentage value is calculated as: TCB time * 100 / interval time. For step-end and job-end records, the value is the largest reported interval value.

SMF Info
--------
    Field: `SMF30_HIGHEST_TASK_CPU_PERCENT`
    Record: `SMF30S5`
    Map: `SMF30CAS`

For interval records, the largest percentage of CPU time used by any task in this address space, rounded to the nearest integer. The percentage value is calculated as: TCB time * 100 / interval time. For step-end and job-end records, the value is the largest reported interval value.
"""

highest_task_cpu_prog_name : Final[Field] = Field(
    name='highest_task_cpu_prog_name',
    origin='SMF30_HIGHEST_TASK_CPU_PROGRAM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CAS,
)
"""Program name running in the task that used the largest percentage of CPU time in the address space. This field corresponds to SMF3 0_Highest_Task_CPU_Percent. A value of blanks indicates that no task reported any CPU time in the address space, or that the CPU time could not be obtained. A value of '????????' indicates that the program name could not be obtained for the task that reported the highest percentage of CPU time.

SMF Info
--------
    Field: `SMF30_HIGHEST_TASK_CPU_PROGRAM`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Program name running in the task that used the largest percentage of CPU time in the address space. This field corresponds to SMF3 0_Highest_Task_CPU_Percent. A value of blanks indicates that no task reported any CPU time in the address space, or that the CPU time could not be obtained. A value of '????????' indicates that the program name could not be obtained for the task that reported the highest percentage of CPU time.
"""
highest_task_cpu_prog_name.__doc__ = """Program name running in the task that used the largest percentage of CPU time in the address space. This field corresponds to SMF3 0_Highest_Task_CPU_Percent. A value of blanks indicates that no task reported any CPU time in the address space, or that the CPU time could not be obtained. A value of '????????' indicates that the program name could not be obtained for the task that reported the highest percentage of CPU time.

SMF Info
--------
    Field: `SMF30_HIGHEST_TASK_CPU_PROGRAM`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Program name running in the task that used the largest percentage of CPU time in the address space. This field corresponds to SMF3 0_Highest_Task_CPU_Percent. A value of blanks indicates that no task reported any CPU time in the address space, or that the CPU time could not be obtained. A value of '????????' indicates that the program name could not be obtained for the task that reported the highest percentage of CPU time.
"""

cpu_acc_seg_flg : Final[Field] = Field(
    name='cpu_acc_seg_flg',
    origin='SMF30CAS_FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CAS,
)
"""CPU Accounting Segment Flags

SMF Info
--------
    Field: `SMF30CAS_FLAG`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU Accounting Segment Flags
"""
cpu_acc_seg_flg.__doc__ = """CPU Accounting Segment Flags

SMF Info
--------
    Field: `SMF30CAS_FLAG`
    Record: `SMF30S5`
    Map: `SMF30CAS`

CPU Accounting Segment Flags
"""

cas_inelighonorpriority : Final[Field] = Field(
    name='cas_inelighonorpriority',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=cpu_acc_seg_flg,
    record=record,
    record_map=SMF30CAS,
)
"""When on, eligible work in this address space is not be offloaded to CPs for help processing. Once this bit is set on for a job interval or step-end record, this bit will also be set on for step-total and job-end records.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_acc_seg_flg`(`SMF30CAS_FLAG`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

When on, eligible work in this address space is not be offloaded to CPs for help processing. Once this bit is set on for a job interval or step-end record, this bit will also be set on for step-total and job-end records.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cas_inelighonorpriority.__doc__ = """When on, eligible work in this address space is not be offloaded to CPs for help processing. Once this bit is set on for a job interval or step-end record, this bit will also be set on for step-total and job-end records.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `cpu_acc_seg_flg`(`SMF30CAS_FLAG`)
    Record: `SMF30S5`
    Map: `SMF30CAS`

When on, eligible work in this address space is not be offloaded to CPs for help processing. Once this bit is set on for a job interval or step-end record, this bit will also be set on for step-total and job-end records.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

os_prot_flg : Final[Field] = Field(
    name='os_prot_flg',
    origin='SMF30CAS_OA54589',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CAS,
)
"""Contains data introduced by APAR OA54589

SMF Info
--------
    Field: `SMF30CAS_OA54589`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Contains data introduced by APAR OA54589
"""
os_prot_flg.__doc__ = """Contains data introduced by APAR OA54589

SMF Info
--------
    Field: `SMF30CAS_OA54589`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Contains data introduced by APAR OA54589
"""

time_java_on_ziip : Final[Field] = Field(
    name='time_java_on_ziip',
    origin='SMF30_TIME_JAVA_ON_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Time spent in Java work on zIIP in hundredths of a second including enclave time. Valid when SMF30_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_TIME_JAVA_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Time spent in Java work on zIIP in hundredths of a second including enclave time. Valid when SMF30_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""
time_java_on_ziip.__doc__ = """Time spent in Java work on zIIP in hundredths of a second including enclave time. Valid when SMF30_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_TIME_JAVA_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Time spent in Java work on zIIP in hundredths of a second including enclave time. Valid when SMF30_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""

enclave_time_java_on_ziip : Final[Field] = Field(
    name='enclave_time_java_on_ziip',
    origin='SMF30_ENCLAVE_TIME_JAVA_ON_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Enclave time spent in Java work on zIIP in hundredths of a second. Valid when SMF30_ENCLA VE_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_JAVA_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Enclave time spent in Java work on zIIP in hundredths of a second. Valid when SMF30_ENCLA VE_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""
enclave_time_java_on_ziip.__doc__ = """Enclave time spent in Java work on zIIP in hundredths of a second. Valid when SMF30_ENCLA VE_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_JAVA_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Enclave time spent in Java work on zIIP in hundredths of a second. Valid when SMF30_ENCLA VE_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""

depenc_time_java_on_ziip : Final[Field] = Field(
    name='depenc_time_java_on_ziip',
    origin='SMF30_DEPENC_TIME_JAVA_ON_ZIIP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""Dependent enclave time spent in Java work on zIIP in hundredths of a second. Valid when SMF30_DEP ENC_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_JAVA_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave time spent in Java work on zIIP in hundredths of a second. Valid when SMF30_DEP ENC_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""
depenc_time_java_on_ziip.__doc__ = """Dependent enclave time spent in Java work on zIIP in hundredths of a second. Valid when SMF30_DEP ENC_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_JAVA_ON_ZIIP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

Dependent enclave time spent in Java work on zIIP in hundredths of a second. Valid when SMF30_DEP ENC_Time_Java_On_zIIP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""

time_java_on_cp : Final[Field] = Field(
    name='time_java_on_cp',
    origin='SMF30_TIME_JAVA_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""zIIP eligible time spent in Java work on CP in hundredths of a second including enclave time. Valid when SMF30_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_TIME_JAVA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP eligible time spent in Java work on CP in hundredths of a second including enclave time. Valid when SMF30_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""
time_java_on_cp.__doc__ = """zIIP eligible time spent in Java work on CP in hundredths of a second including enclave time. Valid when SMF30_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_TIME_JAVA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP eligible time spent in Java work on CP in hundredths of a second including enclave time. Valid when SMF30_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""

enclave_time_java_on_cp : Final[Field] = Field(
    name='enclave_time_java_on_cp',
    origin='SMF30_ENCLAVE_TIME_JAVA_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""zIIP eligible time spent in Java work on CP in hundredths of a second. Valid when SMF30_ENCLA VE_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_JAVA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP eligible time spent in Java work on CP in hundredths of a second. Valid when SMF30_ENCLA VE_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""
enclave_time_java_on_cp.__doc__ = """zIIP eligible time spent in Java work on CP in hundredths of a second. Valid when SMF30_ENCLA VE_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_ENCLAVE_TIME_JAVA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP eligible time spent in Java work on CP in hundredths of a second. Valid when SMF30_ENCLA VE_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""

depenc_time_java_on_cp : Final[Field] = Field(
    name='depenc_time_java_on_cp',
    origin='SMF30_DEPENC_TIME_JAVA_ON_CP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CAS,
)
"""zIIP eligible dependent enclave time spent in Java work on CP in hundredths of a second. Valid when SMF30_DEPENC_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_JAVA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP eligible dependent enclave time spent in Java work on CP in hundredths of a second. Valid when SMF30_DEPENC_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""
depenc_time_java_on_cp.__doc__ = """zIIP eligible dependent enclave time spent in Java work on CP in hundredths of a second. Valid when SMF30_DEPENC_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.

SMF Info
--------
    Field: `SMF30_DEPENC_TIME_JAVA_ON_CP`
    Record: `SMF30S5`
    Map: `SMF30CAS`

zIIP eligible dependent enclave time spent in Java work on CP in hundredths of a second. Valid when SMF30_DEPENC_Time_Java_On_CP_F is 0 and SMF30CLN >= SMF30CAS_Len_V2.
"""

storage_flg : Final[Field] = Field(
    name='storage_flg',
    origin='SMF30SFL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30SAP,
)
"""STORAGE FLAGS

SMF Info
--------
    Field: `SMF30SFL`
    Record: `SMF30S5`
    Map: `SMF30SAP`

STORAGE FLAGS
"""
storage_flg.__doc__ = """STORAGE FLAGS

SMF Info
--------
    Field: `SMF30SFL`
    Record: `SMF30S5`
    Map: `SMF30SAP`

STORAGE FLAGS
"""

storage_vr_specified_flg : Final[Field] = Field(
    name='storage_vr_specified_flg',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=storage_flg,
    record=record,
    record_map=SMF30SAP,
)
"""STORAGE REQUESTED V=R(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

STORAGE REQUESTED V=R

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
storage_vr_specified_flg.__doc__ = """STORAGE REQUESTED V=R(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

STORAGE REQUESTED V=R

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

storage_iefusi_changed_flg : Final[Field] = Field(
    name='storage_iefusi_changed_flg',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=storage_flg,
    record=record,
    record_map=SMF30SAP,
)
"""IEFUSI CHANGED REGION LIMIT VALUES(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

IEFUSI CHANGED REGION LIMIT VALUES

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
storage_iefusi_changed_flg.__doc__ = """IEFUSI CHANGED REGION LIMIT VALUES(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

IEFUSI CHANGED REGION LIMIT VALUES

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

storage_memlimit_set_flg : Final[Field] = Field(
    name='storage_memlimit_set_flg',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=storage_flg,
    record=record,
    record_map=SMF30SAP,
)
"""IEFUSI CHANGED MEMLIMIT VALUE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

IEFUSI CHANGED MEMLIMIT VALUE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
storage_memlimit_set_flg.__doc__ = """IEFUSI CHANGED MEMLIMIT VALUE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

IEFUSI CHANGED MEMLIMIT VALUE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

storage_incomp_flg : Final[Field] = Field(
    name='storage_incomp_flg',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=storage_flg,
    record=record,
    record_map=SMF30SAP,
)
"""The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30ERS SMF30KIE SMF30POA SMF30BIA SMF30KOA SMF30POE SMF30BIE SMF30KOE SMF30PSC SMF30BOA SMF30LPI SMF30PSF SMF30BOE SMF30NSW SMF30PSO SMF30CPI SMF30PAI SMF30PST SMF30CPM SMF30PEI SMF30VPI SMF30HPI SMF30PIA SMF30VPO SMF30HPO SMF30PIE SMF30VPR SMF30KIA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30ERS SMF30KIE SMF30POA SMF30BIA SMF30KOA SMF30POE SMF30BIE SMF30KOE SMF30PSC SMF30BOA SMF30LPI SMF30PSF SMF30BOE SMF30NSW SMF30PSO SMF30CPI SMF30PAI SMF30PST SMF30CPM SMF30PEI SMF30VPI SMF30HPI SMF30PIA SMF30VPO SMF30HPO SMF30PIE SMF30VPR SMF30KIA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
storage_incomp_flg.__doc__ = """The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30ERS SMF30KIE SMF30POA SMF30BIA SMF30KOA SMF30POE SMF30BIE SMF30KOE SMF30PSC SMF30BOA SMF30LPI SMF30PSF SMF30BOE SMF30NSW SMF30PSO SMF30CPI SMF30PAI SMF30PST SMF30CPM SMF30PEI SMF30VPI SMF30HPI SMF30PIA SMF30VPO SMF30HPO SMF30PIE SMF30VPR SMF30KIA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30ERS SMF30KIE SMF30POA SMF30BIA SMF30KOA SMF30POE SMF30BIE SMF30KOE SMF30PSC SMF30BOA SMF30LPI SMF30PSF SMF30BOE SMF30NSW SMF30PSO SMF30CPI SMF30PAI SMF30PST SMF30CPM SMF30PEI SMF30VPI SMF30HPI SMF30PIA SMF30VPO SMF30HPO SMF30PIE SMF30VPR SMF30KIA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

nohonor_iefusi_set : Final[Field] = Field(
    name='nohonor_iefusi_set',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=storage_flg,
    record=record,
    record_map=SMF30SAP,
)
"""When on, indicates that the NOHONORIEFUSIREGION (no honor IEFUSI region settings) was set in the Program Properties Table (PPT). Region and MEMLIMIT values and limits set or affected by the IEFUSI exit are not honored when this bit is on.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, indicates that the NOHONORIEFUSIREGION (no honor IEFUSI region settings) was set in the Program Properties Table (PPT). Region and MEMLIMIT values and limits set or affected by the IEFUSI exit are not honored when this bit is on.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
nohonor_iefusi_set.__doc__ = """When on, indicates that the NOHONORIEFUSIREGION (no honor IEFUSI region settings) was set in the Program Properties Table (PPT). Region and MEMLIMIT values and limits set or affected by the IEFUSI exit are not honored when this bit is on.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, indicates that the NOHONORIEFUSIREGION (no honor IEFUSI region settings) was set in the Program Properties Table (PPT). Region and MEMLIMIT values and limits set or affected by the IEFUSI exit are not honored when this bit is on.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rsvdhbb77b0_exists : Final[Field] = Field(
    name='rsvdhbb77b0_exists',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=storage_flg,
    record=record,
    record_map=SMF30SAP,
)
"""When on the following fields are not valid: SMF30TIH SMF30TIU SMF30TIS These fields are populated at zOS24 and above.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on the following fields are not valid: SMF30TIH SMF30TIU SMF30TIS These fields are populated at zOS24 and above.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rsvdhbb77b0_exists.__doc__ = """When on the following fields are not valid: SMF30TIH SMF30TIU SMF30TIS These fields are populated at zOS24 and above.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `storage_flg`(`SMF30SFL`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on the following fields are not valid: SMF30TIH SMF30TIU SMF30TIS These fields are populated at zOS24 and above.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

storage_protect_key : Final[Field] = Field(
    name='storage_protect_key',
    origin='SMF30SPK',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30SAP,
)
"""STORAGE PROTECT KEY

SMF Info
--------
    Field: `SMF30SPK`
    Record: `SMF30S5`
    Map: `SMF30SAP`

STORAGE PROTECT KEY
"""
storage_protect_key.__doc__ = """STORAGE PROTECT KEY

SMF Info
--------
    Field: `SMF30SPK`
    Record: `SMF30S5`
    Map: `SMF30SAP`

STORAGE PROTECT KEY
"""

prvt_max_storage_bottom : Final[Field] = Field(
    name='prvt_max_storage_bottom',
    origin='SMF30PRV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""VIRT STOR - USER PRIVATE AREA

SMF Info
--------
    Field: `SMF30PRV`
    Record: `SMF30S5`
    Map: `SMF30SAP`

VIRT STOR - USER PRIVATE AREA
"""
prvt_max_storage_bottom.__doc__ = """VIRT STOR - USER PRIVATE AREA

SMF Info
--------
    Field: `SMF30PRV`
    Record: `SMF30S5`
    Map: `SMF30SAP`

VIRT STOR - USER PRIVATE AREA
"""

prvt_max_storage_top : Final[Field] = Field(
    name='prvt_max_storage_top',
    origin='SMF30SYS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""VIRT STOR - SYSTEM AREA

SMF Info
--------
    Field: `SMF30SYS`
    Record: `SMF30S5`
    Map: `SMF30SAP`

VIRT STOR - SYSTEM AREA
"""
prvt_max_storage_top.__doc__ = """VIRT STOR - SYSTEM AREA

SMF Info
--------
    Field: `SMF30SYS`
    Record: `SMF30S5`
    Map: `SMF30SAP`

VIRT STOR - SYSTEM AREA
"""

page_in_num : Final[Field] = Field(
    name='page_in_num',
    origin='SMF30PGI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of page ins from auxiliary storage, regardless of the page size (4K or 1M).

SMF Info
--------
    Field: `SMF30PGI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of page ins from auxiliary storage, regardless of the page size (4K or 1M).
"""
page_in_num.__doc__ = """Number of page ins from auxiliary storage, regardless of the page size (4K or 1M).

SMF Info
--------
    Field: `SMF30PGI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of page ins from auxiliary storage, regardless of the page size (4K or 1M).
"""

page_out_num : Final[Field] = Field(
    name='page_out_num',
    origin='SMF30PGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of page outs to auxiliary storage, regardless of the page size (4K or 1M).

SMF Info
--------
    Field: `SMF30PGO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of page outs to auxiliary storage, regardless of the page size (4K or 1M).
"""
page_out_num.__doc__ = """Number of page outs to auxiliary storage, regardless of the page size (4K or 1M).

SMF Info
--------
    Field: `SMF30PGO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of page outs to auxiliary storage, regardless of the page size (4K or 1M).
"""

cpm : Final[Field] = Field(
    name='cpm',
    origin='SMF30CPM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""CREAD PAGE MISS COUNT

SMF Info
--------
    Field: `SMF30CPM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

CREAD PAGE MISS COUNT
"""
cpm.__doc__ = """CREAD PAGE MISS COUNT

SMF Info
--------
    Field: `SMF30CPM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

CREAD PAGE MISS COUNT
"""

add_swap_seq_num : Final[Field] = Field(
    name='add_swap_seq_num',
    origin='SMF30NSW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of address space swap sequences. (A swap sequence consists of an address space swap-out and swap-in. Logical swap-out and swap-in are not included.)

SMF Info
--------
    Field: `SMF30NSW`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of address space swap sequences. (A swap sequence consists of an address space swap-out and swap-in. Logical swap-out and swap-in are not included.)
"""
add_swap_seq_num.__doc__ = """As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of address space swap sequences. (A swap sequence consists of an address space swap-out and swap-in. Logical swap-out and swap-in are not included.)

SMF Info
--------
    Field: `SMF30NSW`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of address space swap sequences. (A swap sequence consists of an address space swap-out and swap-in. Logical swap-out and swap-in are not included.)
"""

pagein_aux_central : Final[Field] = Field(
    name='pagein_aux_central',
    origin='SMF30PSI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages swapped in from auxiliary storage to central storage. This field includes: (local system queue area (LSQA), fixed pages, and pages that the real storage manager determined to be active when the address space was swapping in. It does not include page reclaims or pages found in storage during the swap-in process (such as pages brought in by the service request blocks (SRB), started after completion of swap-in Stage 1 processing).

SMF Info
--------
    Field: `SMF30PSI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages swapped in from auxiliary storage to central storage. This field includes: (local system queue area (LSQA), fixed pages, and pages that the real storage manager determined to be active when the address space was swapping in. It does not include page reclaims or pages found in storage during the swap-in process (such as pages brought in by the service request blocks (SRB), started after completion of swap-in Stage 1 processing).
"""
pagein_aux_central.__doc__ = """As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages swapped in from auxiliary storage to central storage. This field includes: (local system queue area (LSQA), fixed pages, and pages that the real storage manager determined to be active when the address space was swapping in. It does not include page reclaims or pages found in storage during the swap-in process (such as pages brought in by the service request blocks (SRB), started after completion of swap-in Stage 1 processing).

SMF Info
--------
    Field: `SMF30PSI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages swapped in from auxiliary storage to central storage. This field includes: (local system queue area (LSQA), fixed pages, and pages that the real storage manager determined to be active when the address space was swapping in. It does not include page reclaims or pages found in storage during the swap-in process (such as pages brought in by the service request blocks (SRB), started after completion of swap-in Stage 1 processing).
"""

pageout_central_aux : Final[Field] = Field(
    name='pageout_central_aux',
    origin='SMF30PSO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages swapped out from central storage to auxiliary storage. This field includes: local system queue area (LSQA), private area fixed pages, and private area non-fixed changed pages.

SMF Info
--------
    Field: `SMF30PSO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages swapped out from central storage to auxiliary storage. This field includes: local system queue area (LSQA), private area fixed pages, and private area non-fixed changed pages.
"""
pageout_central_aux.__doc__ = """As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages swapped out from central storage to auxiliary storage. This field includes: local system queue area (LSQA), private area fixed pages, and private area non-fixed changed pages.

SMF Info
--------
    Field: `SMF30PSO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages swapped out from central storage to auxiliary storage. This field includes: local system queue area (LSQA), private area fixed pages, and private area non-fixed changed pages.
"""

vio_pagein_aux_central : Final[Field] = Field(
    name='vio_pagein_aux_central',
    origin='SMF30VPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""NUMBER OF VIO PAGE-INS

SMF Info
--------
    Field: `SMF30VPI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF VIO PAGE-INS
"""
vio_pagein_aux_central.__doc__ = """NUMBER OF VIO PAGE-INS

SMF Info
--------
    Field: `SMF30VPI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF VIO PAGE-INS
"""

vio_pageout_central_aux : Final[Field] = Field(
    name='vio_pageout_central_aux',
    origin='SMF30VPO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""NUMBER OF VIO PAGE-OUTS

SMF Info
--------
    Field: `SMF30VPO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF VIO PAGE-OUTS
"""
vio_pageout_central_aux.__doc__ = """NUMBER OF VIO PAGE-OUTS

SMF Info
--------
    Field: `SMF30VPO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF VIO PAGE-OUTS
"""

vio_reclaims_num : Final[Field] = Field(
    name='vio_reclaims_num',
    origin='SMF30VPR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""NUMBER OF VIO RECLAIMS

SMF Info
--------
    Field: `SMF30VPR`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF VIO RECLAIMS
"""
vio_reclaims_num.__doc__ = """NUMBER OF VIO RECLAIMS

SMF Info
--------
    Field: `SMF30VPR`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF VIO RECLAIMS
"""

pagein_aux_central_common : Final[Field] = Field(
    name='pagein_aux_central_common',
    origin='SMF30CPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""NUMBER OF COMMON PAGE-INS

SMF Info
--------
    Field: `SMF30CPI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF COMMON PAGE-INS
"""
pagein_aux_central_common.__doc__ = """NUMBER OF COMMON PAGE-INS

SMF Info
--------
    Field: `SMF30CPI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF COMMON PAGE-INS
"""

pagein_aux_proc_hiper : Final[Field] = Field(
    name='pagein_aux_proc_hiper',
    origin='SMF30HPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""HIPERSPACE PAGE-IN COUNT

SMF Info
--------
    Field: `SMF30HPI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

HIPERSPACE PAGE-IN COUNT
"""
pagein_aux_proc_hiper.__doc__ = """HIPERSPACE PAGE-IN COUNT

SMF Info
--------
    Field: `SMF30HPI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

HIPERSPACE PAGE-IN COUNT
"""

pagein_aux_central_lpa : Final[Field] = Field(
    name='pagein_aux_central_lpa',
    origin='SMF30LPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""NUMBER OF LPA PAGE-INS

SMF Info
--------
    Field: `SMF30LPI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF LPA PAGE-INS
"""
pagein_aux_central_lpa.__doc__ = """NUMBER OF LPA PAGE-INS

SMF Info
--------
    Field: `SMF30LPI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF LPA PAGE-INS
"""

pageout_proc_aux_hiper : Final[Field] = Field(
    name='pageout_proc_aux_hiper',
    origin='SMF30HPO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""HIPERSPACE PAGE-OUT COUNT

SMF Info
--------
    Field: `SMF30HPO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

HIPERSPACE PAGE-OUT COUNT
"""
pageout_proc_aux_hiper.__doc__ = """HIPERSPACE PAGE-OUT COUNT

SMF Info
--------
    Field: `SMF30HPO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

HIPERSPACE PAGE-OUT COUNT
"""

page_stolen_num : Final[Field] = Field(
    name='page_stolen_num',
    origin='SMF30PST',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages stolen from this address space.

SMF Info
--------
    Field: `SMF30PST`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages stolen from this address space.
"""
page_stolen_num.__doc__ = """As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages stolen from this address space.

SMF Info
--------
    Field: `SMF30PST`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.8, this field is no longer valid. This value will always be zero. Prior to z/OS 1.8, this field contained: Number of pages stolen from this address space.
"""

cpu_page_second_num : Final[Field] = Field(
    name='cpu_page_second_num',
    origin='SMF30PSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of CPU page milliseconds for this address space. A page millisecond unit equals 1.024 milliseconds * 1 page (4K). It can be used to illustrate the duration of memory consumption where a small spike in memory demand may have less of an impact than a smaller amount of memory used over a longer period of time.

SMF Info
--------
    Field: `SMF30PSC`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of CPU page milliseconds for this address space. A page millisecond unit equals 1.024 milliseconds * 1 page (4K). It can be used to illustrate the duration of memory consumption where a small spike in memory demand may have less of an impact than a smaller amount of memory used over a longer period of time.
"""
cpu_page_second_num.__doc__ = """Number of CPU page milliseconds for this address space. A page millisecond unit equals 1.024 milliseconds * 1 page (4K). It can be used to illustrate the duration of memory consumption where a small spike in memory demand may have less of an impact than a smaller amount of memory used over a longer period of time.

SMF Info
--------
    Field: `SMF30PSC`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of CPU page milliseconds for this address space. A page millisecond unit equals 1.024 milliseconds * 1 page (4K). It can be used to illustrate the duration of memory consumption where a small spike in memory demand may have less of an impact than a smaller amount of memory used over a longer period of time.
"""

prvt_area_size_below16 : Final[Field] = Field(
    name='prvt_area_size_below16',
    origin='SMF30RGB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Maximum possible below 16MB region size, in bytes.

SMF Info
--------
    Field: `SMF30RGB`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Maximum possible below 16MB region size, in bytes.
"""
prvt_area_size_below16.__doc__ = """Maximum possible below 16MB region size, in bytes.

SMF Info
--------
    Field: `SMF30RGB`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Maximum possible below 16MB region size, in bytes.
"""

prvt_area_size_above16 : Final[Field] = Field(
    name='prvt_area_size_above16',
    origin='SMF30ERG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Maximum possible above 16MB region size, in bytes.

SMF Info
--------
    Field: `SMF30ERG`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Maximum possible above 16MB region size, in bytes.
"""
prvt_area_size_above16.__doc__ = """Maximum possible above 16MB region size, in bytes.

SMF Info
--------
    Field: `SMF30ERG`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Maximum possible above 16MB region size, in bytes.
"""

max_vir_stor_below16 : Final[Field] = Field(
    name='max_vir_stor_below16',
    origin='SMF30ARB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""MAX VIRTUAL SPACE ALLOCATED FROM LSQA AND SWA BELOW 16M

SMF Info
--------
    Field: `SMF30ARB`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MAX VIRTUAL SPACE ALLOCATED FROM LSQA AND SWA BELOW 16M
"""
max_vir_stor_below16.__doc__ = """MAX VIRTUAL SPACE ALLOCATED FROM LSQA AND SWA BELOW 16M

SMF Info
--------
    Field: `SMF30ARB`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MAX VIRTUAL SPACE ALLOCATED FROM LSQA AND SWA BELOW 16M
"""

max_vir_stor_above16 : Final[Field] = Field(
    name='max_vir_stor_above16',
    origin='SMF30EAR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""MAX VIRTUAL SPACE ALLOCATED FROM LSQA AND SWA ABOVE 16M

SMF Info
--------
    Field: `SMF30EAR`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MAX VIRTUAL SPACE ALLOCATED FROM LSQA AND SWA ABOVE 16M
"""
max_vir_stor_above16.__doc__ = """MAX VIRTUAL SPACE ALLOCATED FROM LSQA AND SWA ABOVE 16M

SMF Info
--------
    Field: `SMF30EAR`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MAX VIRTUAL SPACE ALLOCATED FROM LSQA AND SWA ABOVE 16M
"""

max_vir_stor_usr_below16 : Final[Field] = Field(
    name='max_vir_stor_usr_below16',
    origin='SMF30URB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""MAX VIRTUAL SPACE ALLOCATED FROM THE USER REGION BELOW 16M

SMF Info
--------
    Field: `SMF30URB`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MAX VIRTUAL SPACE ALLOCATED FROM THE USER REGION BELOW 16M
"""
max_vir_stor_usr_below16.__doc__ = """MAX VIRTUAL SPACE ALLOCATED FROM THE USER REGION BELOW 16M

SMF Info
--------
    Field: `SMF30URB`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MAX VIRTUAL SPACE ALLOCATED FROM THE USER REGION BELOW 16M
"""

max_vir_stor_usr_above16 : Final[Field] = Field(
    name='max_vir_stor_usr_above16',
    origin='SMF30EUR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""MAX VIRTUAL SPACE ALLOCATED FROM THE USER REGION ABOVE 16M

SMF Info
--------
    Field: `SMF30EUR`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MAX VIRTUAL SPACE ALLOCATED FROM THE USER REGION ABOVE 16M
"""
max_vir_stor_usr_above16.__doc__ = """MAX VIRTUAL SPACE ALLOCATED FROM THE USER REGION ABOVE 16M

SMF Info
--------
    Field: `SMF30EUR`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MAX VIRTUAL SPACE ALLOCATED FROM THE USER REGION ABOVE 16M
"""

region_size : Final[Field] = Field(
    name='region_size',
    origin='SMF30RGN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""REGION SIZE REQUESTED IN 1K UNITS

SMF Info
--------
    Field: `SMF30RGN`
    Record: `SMF30S5`
    Map: `SMF30SAP`

REGION SIZE REQUESTED IN 1K UNITS
"""
region_size.__doc__ = """REGION SIZE REQUESTED IN 1K UNITS

SMF Info
--------
    Field: `SMF30RGN`
    Record: `SMF30S5`
    Map: `SMF30SAP`

REGION SIZE REQUESTED IN 1K UNITS
"""

step_data_space : Final[Field] = Field(
    name='step_data_space',
    origin='SMF30DSV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""AMOUNT OF USER KEY DATA SPACE STORAGE (HIGH WATER MARK) USED DURING THE STEP/JOB (IN MEGABYTES)

SMF Info
--------
    Field: `SMF30DSV`
    Record: `SMF30S5`
    Map: `SMF30SAP`

AMOUNT OF USER KEY DATA SPACE STORAGE (HIGH WATER MARK) USED DURING THE STEP/JOB (IN MEGABYTES)
"""
step_data_space.__doc__ = """AMOUNT OF USER KEY DATA SPACE STORAGE (HIGH WATER MARK) USED DURING THE STEP/JOB (IN MEGABYTES)

SMF Info
--------
    Field: `SMF30DSV`
    Record: `SMF30S5`
    Map: `SMF30SAP`

AMOUNT OF USER KEY DATA SPACE STORAGE (HIGH WATER MARK) USED DURING THE STEP/JOB (IN MEGABYTES)
"""

unblock_pagein_exp_num : Final[Field] = Field(
    name='unblock_pagein_exp_num',
    origin='SMF30PIE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of unblocked pages that were paged in from expanded storage.

SMF Info
--------
    Field: `SMF30PIE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of unblocked pages that were paged in from expanded storage.
"""
unblock_pagein_exp_num.__doc__ = """As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of unblocked pages that were paged in from expanded storage.

SMF Info
--------
    Field: `SMF30PIE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of unblocked pages that were paged in from expanded storage.
"""

unblock_pageout_exp_num : Final[Field] = Field(
    name='unblock_pageout_exp_num',
    origin='SMF30POE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of unblocked pages that were paged out to expanded storage.

SMF Info
--------
    Field: `SMF30POE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of unblocked pages that were paged out to expanded storage.
"""
unblock_pageout_exp_num.__doc__ = """As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of unblocked pages that were paged out to expanded storage.

SMF Info
--------
    Field: `SMF30POE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of unblocked pages that were paged out to expanded storage.
"""

block_pagein_aux_num : Final[Field] = Field(
    name='block_pagein_aux_num',
    origin='SMF30BIA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""NUMBER OF BLOCKED PAGES PAGED IN FROM AUXILIARY STORAGE

SMF Info
--------
    Field: `SMF30BIA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF BLOCKED PAGES PAGED IN FROM AUXILIARY STORAGE
"""
block_pagein_aux_num.__doc__ = """NUMBER OF BLOCKED PAGES PAGED IN FROM AUXILIARY STORAGE

SMF Info
--------
    Field: `SMF30BIA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF BLOCKED PAGES PAGED IN FROM AUXILIARY STORAGE
"""

block_pageout_aux_num : Final[Field] = Field(
    name='block_pageout_aux_num',
    origin='SMF30BOA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""NUMBER OF BLOCKED PAGES PAGED OUT TO AUXILIARY STORAGE

SMF Info
--------
    Field: `SMF30BOA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF BLOCKED PAGES PAGED OUT TO AUXILIARY STORAGE
"""
block_pageout_aux_num.__doc__ = """NUMBER OF BLOCKED PAGES PAGED OUT TO AUXILIARY STORAGE

SMF Info
--------
    Field: `SMF30BOA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF BLOCKED PAGES PAGED OUT TO AUXILIARY STORAGE
"""

block_pagein_exp_num : Final[Field] = Field(
    name='block_pagein_exp_num',
    origin='SMF30BIE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocked pages that were paged in from expanded storage.

SMF Info
--------
    Field: `SMF30BIE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocked pages that were paged in from expanded storage.
"""
block_pagein_exp_num.__doc__ = """As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocked pages that were paged in from expanded storage.

SMF Info
--------
    Field: `SMF30BIE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocked pages that were paged in from expanded storage.
"""

block_pageout_exp_num : Final[Field] = Field(
    name='block_pageout_exp_num',
    origin='SMF30BOE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocked pages that were paged out to expanded storage.

SMF Info
--------
    Field: `SMF30BOE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocked pages that were paged out to expanded storage.
"""
block_pageout_exp_num.__doc__ = """As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocked pages that were paged out to expanded storage.

SMF Info
--------
    Field: `SMF30BOE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocked pages that were paged out to expanded storage.
"""

blocks_pagein_aux_num : Final[Field] = Field(
    name='blocks_pagein_aux_num',
    origin='SMF30KIA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""NUMBER OF BLOCKS PAGED IN FROM AUXILIARY STORAGE

SMF Info
--------
    Field: `SMF30KIA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF BLOCKS PAGED IN FROM AUXILIARY STORAGE
"""
blocks_pagein_aux_num.__doc__ = """NUMBER OF BLOCKS PAGED IN FROM AUXILIARY STORAGE

SMF Info
--------
    Field: `SMF30KIA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF BLOCKS PAGED IN FROM AUXILIARY STORAGE
"""

blocks_pageout_aux_num : Final[Field] = Field(
    name='blocks_pageout_aux_num',
    origin='SMF30KOA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""NUMBER OF BLOCKS PAGED OUT TO AUXILIARY STORAGE

SMF Info
--------
    Field: `SMF30KOA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF BLOCKS PAGED OUT TO AUXILIARY STORAGE
"""
blocks_pageout_aux_num.__doc__ = """NUMBER OF BLOCKS PAGED OUT TO AUXILIARY STORAGE

SMF Info
--------
    Field: `SMF30KOA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

NUMBER OF BLOCKS PAGED OUT TO AUXILIARY STORAGE
"""

blocks_pagein_exp_num : Final[Field] = Field(
    name='blocks_pagein_exp_num',
    origin='SMF30KIE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocks that were paged in from expanded storage.

SMF Info
--------
    Field: `SMF30KIE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocks that were paged in from expanded storage.
"""
blocks_pagein_exp_num.__doc__ = """As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocks that were paged in from expanded storage.

SMF Info
--------
    Field: `SMF30KIE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocks that were paged in from expanded storage.
"""

blocks_pageout_exp_num : Final[Field] = Field(
    name='blocks_pageout_exp_num',
    origin='SMF30KOE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocks that were paged out to expanded storage.

SMF Info
--------
    Field: `SMF30KOE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocks that were paged out to expanded storage.
"""
blocks_pageout_exp_num.__doc__ = """As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocks that were paged out to expanded storage.

SMF Info
--------
    Field: `SMF30KOE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of blocks that were paged out to expanded storage.
"""

page_sec_shared_num : Final[Field] = Field(
    name='page_sec_shared_num',
    origin='SMF30PSF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of CPU page seconds for the shared central storage frames in use by this address space, in page millisecond units

SMF Info
--------
    Field: `SMF30PSF`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of CPU page seconds for the shared central storage frames in use by this address space, in page millisecond units
"""
page_sec_shared_num.__doc__ = """Number of CPU page seconds for the shared central storage frames in use by this address space, in page millisecond units

SMF Info
--------
    Field: `SMF30PSF`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of CPU page seconds for the shared central storage frames in use by this address space, in page millisecond units
"""

shared_pagein_aux_num : Final[Field] = Field(
    name='shared_pagein_aux_num',
    origin='SMF30PAI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of shared pages that were paged in from auxiliary storage in this address space

SMF Info
--------
    Field: `SMF30PAI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of shared pages that were paged in from auxiliary storage in this address space
"""
shared_pagein_aux_num.__doc__ = """Number of shared pages that were paged in from auxiliary storage in this address space

SMF Info
--------
    Field: `SMF30PAI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of shared pages that were paged in from auxiliary storage in this address space
"""

shared_pagein_exp_num : Final[Field] = Field(
    name='shared_pagein_exp_num',
    origin='SMF30PEI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of IARVSERV shared pages that were paged in from expanded storage in this address space.

SMF Info
--------
    Field: `SMF30PEI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of IARVSERV shared pages that were paged in from expanded storage in this address space.
"""
shared_pagein_exp_num.__doc__ = """As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of IARVSERV shared pages that were paged in from expanded storage in this address space.

SMF Info
--------
    Field: `SMF30PEI`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Number of IARVSERV shared pages that were paged in from expanded storage in this address space.
"""

exp_storage_page_res_time : Final[Field] = Field(
    name='exp_storage_page_res_time',
    origin='SMF30ERS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30SAP,
)
"""As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Expanded storage page residency time in page-milliseconds

SMF Info
--------
    Field: `SMF30ERS`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Expanded storage page residency time in page-milliseconds
"""
exp_storage_page_res_time.__doc__ = """As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Expanded storage page residency time in page-milliseconds

SMF Info
--------
    Field: `SMF30ERS`
    Record: `SMF30S5`
    Map: `SMF30SAP`

As of z/OS 1.6, this field is no longer valid. This value will always be zero. Prior to z/OS 1.6, this field contained: Expanded storage page residency time in page-milliseconds
"""

mem_limit : Final[Field] = Field(
    name='mem_limit',
    origin='SMF30MEM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""MEMLIMIT value in 1MB units as determined at step initialization time, after IEFUSI and SMFLIMxx processing. Changes to the MEMLIMIT value after step initialization time are not reflected here. Refer to the related documentation to see how the MEMLIMIT value can change. The maximum value of this field is '00000FFFFFFFF000'x that is equivalent to MEMLIMIT having no limit.

SMF Info
--------
    Field: `SMF30MEM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MEMLIMIT value in 1MB units as determined at step initialization time, after IEFUSI and SMFLIMxx processing. Changes to the MEMLIMIT value after step initialization time are not reflected here. Refer to the related documentation to see how the MEMLIMIT value can change. The maximum value of this field is '00000FFFFFFFF000'x that is equivalent to MEMLIMIT having no limit.
"""
mem_limit.__doc__ = """MEMLIMIT value in 1MB units as determined at step initialization time, after IEFUSI and SMFLIMxx processing. Changes to the MEMLIMIT value after step initialization time are not reflected here. Refer to the related documentation to see how the MEMLIMIT value can change. The maximum value of this field is '00000FFFFFFFF000'x that is equivalent to MEMLIMIT having no limit.

SMF Info
--------
    Field: `SMF30MEM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MEMLIMIT value in 1MB units as determined at step initialization time, after IEFUSI and SMFLIMxx processing. Changes to the MEMLIMIT value after step initialization time are not reflected here. Refer to the related documentation to see how the MEMLIMIT value can change. The maximum value of this field is '00000FFFFFFFF000'x that is equivalent to MEMLIMIT having no limit.
"""

src_mem_limit : Final[Field] = Field(
    name='src_mem_limit',
    origin='SMF30MES',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30SAP,
)
"""MEMLIMIT source

SMF Info
--------
    Field: `SMF30MES`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MEMLIMIT source
"""
src_mem_limit.__doc__ = """MEMLIMIT source

SMF Info
--------
    Field: `SMF30MES`
    Record: `SMF30S5`
    Map: `SMF30SAP`

MEMLIMIT source
"""

mem_limit_action_flg : Final[Field] = Field(
    name='mem_limit_action_flg',
    origin='SMF30SLM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30SAP,
)
"""Actions taken on the job step region or memlimit due to a rule coded in the SMFLIMxx parmlib member. For subtype 5, this will be a copy of the last executed step's SMF30SLM value

SMF Info
--------
    Field: `SMF30SLM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Actions taken on the job step region or memlimit due to a rule coded in the SMFLIMxx parmlib member. For subtype 5, this will be a copy of the last executed step's SMF30SLM value
"""
mem_limit_action_flg.__doc__ = """Actions taken on the job step region or memlimit due to a rule coded in the SMFLIMxx parmlib member. For subtype 5, this will be a copy of the last executed step's SMF30SLM value

SMF Info
--------
    Field: `SMF30SLM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Actions taken on the job step region or memlimit due to a rule coded in the SMFLIMxx parmlib member. For subtype 5, this will be a copy of the last executed step's SMF30SLM value
"""

sl1 : Final[Field] = Field(
    name='sl1',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=mem_limit_action_flg,
    record=record,
    record_map=SMF30SAP,
)
"""When on, SMFLIM REGIONBELOW acted on the non-extended REGION for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM REGIONBELOW acted on the non-extended REGION for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
sl1.__doc__ = """When on, SMFLIM REGIONBELOW acted on the non-extended REGION for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM REGIONBELOW acted on the non-extended REGION for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sl2 : Final[Field] = Field(
    name='sl2',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=mem_limit_action_flg,
    record=record,
    record_map=SMF30SAP,
)
"""When on, SMFLIM REGIONABOVE acted on the extended REGION for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM REGIONABOVE acted on the extended REGION for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sl2.__doc__ = """When on, SMFLIM REGIONABOVE acted on the extended REGION for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM REGIONABOVE acted on the extended REGION for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

sl3 : Final[Field] = Field(
    name='sl3',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=mem_limit_action_flg,
    record=record,
    record_map=SMF30SAP,
)
"""When on, SMFLIM SYSRESVBELOW acted on the non-extended REGION for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM SYSRESVBELOW acted on the non-extended REGION for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
sl3.__doc__ = """When on, SMFLIM SYSRESVBELOW acted on the non-extended REGION for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM SYSRESVBELOW acted on the non-extended REGION for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

sl4 : Final[Field] = Field(
    name='sl4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=mem_limit_action_flg,
    record=record,
    record_map=SMF30SAP,
)
"""When on, SMFLIM SYSRESVABOVE acted on the extended REGION for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM SYSRESVABOVE acted on the extended REGION for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
sl4.__doc__ = """When on, SMFLIM SYSRESVABOVE acted on the extended REGION for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM SYSRESVABOVE acted on the extended REGION for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

sl5 : Final[Field] = Field(
    name='sl5',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=mem_limit_action_flg,
    record=record,
    record_map=SMF30SAP,
)
"""When on, SMFLIM MEMLIMIT acted on the MEMLIMIT for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM MEMLIMIT acted on the MEMLIMIT for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
sl5.__doc__ = """When on, SMFLIM MEMLIMIT acted on the MEMLIMIT for this step(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, SMFLIM MEMLIMIT acted on the MEMLIMIT for this step

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

sl6 : Final[Field] = Field(
    name='sl6',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=mem_limit_action_flg,
    record=record,
    record_map=SMF30SAP,
)
"""When on, the IEFUSI exit set the output flag that caused all SMFLIM decision making to be bypassed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, the IEFUSI exit set the output flag that caused all SMFLIM decision making to be bypassed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
sl6.__doc__ = """When on, the IEFUSI exit set the output flag that caused all SMFLIM decision making to be bypassed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `mem_limit_action_flg`(`SMF30SLM`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, the IEFUSI exit set the output flag that caused all SMFLIM decision making to be bypassed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

raxflags : Final[Field] = Field(
    name='raxflags',
    origin='SMF30_RAXFLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30SAP,
)
"""RAX Flag Byte

SMF Info
--------
    Field: `SMF30_RAXFLAGS`
    Record: `SMF30S5`
    Map: `SMF30SAP`

RAX Flag Byte
"""
raxflags.__doc__ = """RAX Flag Byte

SMF Info
--------
    Field: `SMF30_RAXFLAGS`
    Record: `SMF30S5`
    Map: `SMF30SAP`

RAX Flag Byte
"""

userkeycommonauditenabled : Final[Field] = Field(
    name='userkeycommonauditenabled',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=raxflags,
    record=record,
    record_map=SMF30SAP,
)
"""When on, successful and unsuccessful user key common storage usage attempts is enabled for this step. SMF30_USERKEYCSAUSAGE, SMF30_USERKEYCADSUSAGE, SMF30_USERKEYCHANGKEYUSAGE, SMF30_USERKEYRUCSAUSAGE and SMF30_RUCSAEarlyUsage are only applicable when this flag is on.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful and unsuccessful user key common storage usage attempts is enabled for this step. SMF30_USERKEYCSAUSAGE, SMF30_USERKEYCADSUSAGE, SMF30_USERKEYCHANGKEYUSAGE, SMF30_USERKEYRUCSAUSAGE and SMF30_RUCSAEarlyUsage are only applicable when this flag is on.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
userkeycommonauditenabled.__doc__ = """When on, successful and unsuccessful user key common storage usage attempts is enabled for this step. SMF30_USERKEYCSAUSAGE, SMF30_USERKEYCADSUSAGE, SMF30_USERKEYCHANGKEYUSAGE, SMF30_USERKEYRUCSAUSAGE and SMF30_RUCSAEarlyUsage are only applicable when this flag is on.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful and unsuccessful user key common storage usage attempts is enabled for this step. SMF30_USERKEYCSAUSAGE, SMF30_USERKEYCADSUSAGE, SMF30_USERKEYCHANGKEYUSAGE, SMF30_USERKEYRUCSAUSAGE and SMF30_RUCSAEarlyUsage are only applicable when this flag is on.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

userkeycsausage : Final[Field] = Field(
    name='userkeycsausage',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=raxflags,
    record=record,
    record_map=SMF30SAP,
)
"""When on, successful or unsuccessful attempts were made to obtain user key CSA or RUCSA storage for this step. See SMF30_USERKEYRUCSAUSAGE for RUCSA specific usage. This bit is only valid when SMF30_U serKeyCommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful or unsuccessful attempts were made to obtain user key CSA or RUCSA storage for this step. See SMF30_USERKEYRUCSAUSAGE for RUCSA specific usage. This bit is only valid when SMF30_U serKeyCommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
userkeycsausage.__doc__ = """When on, successful or unsuccessful attempts were made to obtain user key CSA or RUCSA storage for this step. See SMF30_USERKEYRUCSAUSAGE for RUCSA specific usage. This bit is only valid when SMF30_U serKeyCommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful or unsuccessful attempts were made to obtain user key CSA or RUCSA storage for this step. See SMF30_USERKEYRUCSAUSAGE for RUCSA specific usage. This bit is only valid when SMF30_U serKeyCommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

userkeycadsusage : Final[Field] = Field(
    name='userkeycadsusage',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=raxflags,
    record=record,
    record_map=SMF30SAP,
)
"""When on, successful or unsuccessful attempts were made to create a user key CADS for this step. This bit is only valid when SMF30_UserKeyC ommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful or unsuccessful attempts were made to create a user key CADS for this step. This bit is only valid when SMF30_UserKeyC ommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
userkeycadsusage.__doc__ = """When on, successful or unsuccessful attempts were made to create a user key CADS for this step. This bit is only valid when SMF30_UserKeyC ommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful or unsuccessful attempts were made to create a user key CADS for this step. This bit is only valid when SMF30_UserKeyC ommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

userkeychangkeyusage : Final[Field] = Field(
    name='userkeychangkeyusage',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=raxflags,
    record=record,
    record_map=SMF30SAP,
)
"""When on, successful or unsuccessful attempts were made to change the key of common ESQA storage to a user key (via CHANGKEY) for this step. This bit is only valid when SMF30_UserKeyC ommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful or unsuccessful attempts were made to change the key of common ESQA storage to a user key (via CHANGKEY) for this step. This bit is only valid when SMF30_UserKeyC ommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
userkeychangkeyusage.__doc__ = """When on, successful or unsuccessful attempts were made to change the key of common ESQA storage to a user key (via CHANGKEY) for this step. This bit is only valid when SMF30_UserKeyC ommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful or unsuccessful attempts were made to change the key of common ESQA storage to a user key (via CHANGKEY) for this step. This bit is only valid when SMF30_UserKeyC ommonAuditEnabled is on. Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

userkeyrucsausage : Final[Field] = Field(
    name='userkeyrucsausage',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=raxflags,
    record=record,
    record_map=SMF30SAP,
)
"""When on, successful or unsuccessful attempts were made to obtain, reference or free user key RUCSA storage for this step Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful or unsuccessful attempts were made to obtain, reference or free user key RUCSA storage for this step Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
userkeyrucsausage.__doc__ = """When on, successful or unsuccessful attempts were made to obtain, reference or free user key RUCSA storage for this step Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful or unsuccessful attempts were made to obtain, reference or free user key RUCSA storage for this step Once this bit is on within a step, it will stay on for the step. The bit will be on in job end records if the bit is on for any step in the job.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rucsaearlyusage : Final[Field] = Field(
    name='rucsaearlyusage',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=raxflags,
    record=record,
    record_map=SMF30SAP,
)
"""When on, successful access to RUCSA was made by an address space that was authorized to RUCSA during early IPL or early started task initialization due to DIAGxx VSM AllowEarlyRucsa(YES) Scope is life of an address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful access to RUCSA was made by an address space that was authorized to RUCSA during early IPL or early started task initialization due to DIAGxx VSM AllowEarlyRucsa(YES) Scope is life of an address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rucsaearlyusage.__doc__ = """When on, successful access to RUCSA was made by an address space that was authorized to RUCSA during early IPL or early started task initialization due to DIAGxx VSM AllowEarlyRucsa(YES) Scope is life of an address space(V)

SMF Info (Virtual Field)
--------
    Field: Based on `raxflags`(`SMF30_RAXFLAGS`)
    Record: `SMF30S5`
    Map: `SMF30SAP`

When on, successful access to RUCSA was made by an address space that was authorized to RUCSA during early IPL or early started task initialization due to DIAGxx VSM AllowEarlyRucsa(YES) Scope is life of an address space

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

hwm_real_storage : Final[Field] = Field(
    name='hwm_real_storage',
    origin='SMF30HVR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of real storage frames that is used to back 64-bit private storage. The high water mark does not include 2G frames.

SMF Info
--------
    Field: `SMF30HVR`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of real storage frames that is used to back 64-bit private storage. The high water mark does not include 2G frames.
"""
hwm_real_storage.__doc__ = """High water mark for the number of real storage frames that is used to back 64-bit private storage. The high water mark does not include 2G frames.

SMF Info
--------
    Field: `SMF30HVR`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of real storage frames that is used to back 64-bit private storage. The high water mark does not include 2G frames.
"""

hwm_aux_storage : Final[Field] = Field(
    name='hwm_aux_storage',
    origin='SMF30HVA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of auxiliary storage slots used to back 64-bit private storage

SMF Info
--------
    Field: `SMF30HVA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of auxiliary storage slots used to back 64-bit private storage
"""
hwm_aux_storage.__doc__ = """High water mark for the number of auxiliary storage slots used to back 64-bit private storage

SMF Info
--------
    Field: `SMF30HVA`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of auxiliary storage slots used to back 64-bit private storage
"""

size_prvt_storage_step : Final[Field] = Field(
    name='size_prvt_storage_step',
    origin='SMF30HVO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Amount of 64-bit private storage in bytes obtained by this step/job. This includes guarded virtual storage

SMF Info
--------
    Field: `SMF30HVO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Amount of 64-bit private storage in bytes obtained by this step/job. This includes guarded virtual storage
"""
size_prvt_storage_step.__doc__ = """Amount of 64-bit private storage in bytes obtained by this step/job. This includes guarded virtual storage

SMF Info
--------
    Field: `SMF30HVO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Amount of 64-bit private storage in bytes obtained by this step/job. This includes guarded virtual storage
"""

hwm_usable_prvt : Final[Field] = Field(
    name='hwm_usable_prvt',
    origin='SMF30HVH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of usable bytes of 64-bit private storage that is obtained by this step or job. This does not include guarded virtual storage. Note: this is not the amount of 64-bit High Virtual storage that is charged toward the MEMLIMIT as it includes IARV64 MEMLIMIT=NO storage as well.

SMF Info
--------
    Field: `SMF30HVH`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of usable bytes of 64-bit private storage that is obtained by this step or job. This does not include guarded virtual storage. Note: this is not the amount of 64-bit High Virtual storage that is charged toward the MEMLIMIT as it includes IARV64 MEMLIMIT=NO storage as well.
"""
hwm_usable_prvt.__doc__ = """High water mark for the number of usable bytes of 64-bit private storage that is obtained by this step or job. This does not include guarded virtual storage. Note: this is not the amount of 64-bit High Virtual storage that is charged toward the MEMLIMIT as it includes IARV64 MEMLIMIT=NO storage as well.

SMF Info
--------
    Field: `SMF30HVH`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of usable bytes of 64-bit private storage that is obtained by this step or job. This does not include guarded virtual storage. Note: this is not the amount of 64-bit High Virtual storage that is charged toward the MEMLIMIT as it includes IARV64 MEMLIMIT=NO storage as well.
"""

size_shared_storage_step : Final[Field] = Field(
    name='size_shared_storage_step',
    origin='SMF30HSO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Amount of 64-bit shared storage in bytes this step/job has addressability or access to

SMF Info
--------
    Field: `SMF30HSO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Amount of 64-bit shared storage in bytes this step/job has addressability or access to
"""
size_shared_storage_step.__doc__ = """Amount of 64-bit shared storage in bytes this step/job has addressability or access to

SMF Info
--------
    Field: `SMF30HSO`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Amount of 64-bit shared storage in bytes this step/job has addressability or access to
"""

hwm_shared_step : Final[Field] = Field(
    name='hwm_shared_step',
    origin='SMF30HSH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of usable bytes of 64-bit IARV64 REQUEST=SHAREMEMOBJ shared storage to which this step or job has access. This does not include guard areas which are, by definition, not usable.

SMF Info
--------
    Field: `SMF30HSH`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of usable bytes of 64-bit IARV64 REQUEST=SHAREMEMOBJ shared storage to which this step or job has access. This does not include guard areas which are, by definition, not usable.
"""
hwm_shared_step.__doc__ = """High water mark for the number of usable bytes of 64-bit IARV64 REQUEST=SHAREMEMOBJ shared storage to which this step or job has access. This does not include guard areas which are, by definition, not usable.

SMF Info
--------
    Field: `SMF30HSH`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of usable bytes of 64-bit IARV64 REQUEST=SHAREMEMOBJ shared storage to which this step or job has access. This does not include guard areas which are, by definition, not usable.
"""

tih : Final[Field] = Field(
    name='tih',
    origin='SMF30TIH',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark of TIOT space used for TIOT entries (in bytes.)

SMF Info
--------
    Field: `SMF30TIH`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark of TIOT space used for TIOT entries (in bytes.)
"""
tih.__doc__ = """High water mark of TIOT space used for TIOT entries (in bytes.)

SMF Info
--------
    Field: `SMF30TIH`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark of TIOT space used for TIOT entries (in bytes.)
"""

tiu : Final[Field] = Field(
    name='tiu',
    origin='SMF30TIU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Current TIOT space used for TIOT entries (in bytes.) This will only contain a non-zero value for interval records, since TIOT entries are freed by unallocation processing at step end and job end.

SMF Info
--------
    Field: `SMF30TIU`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Current TIOT space used for TIOT entries (in bytes.) This will only contain a non-zero value for interval records, since TIOT entries are freed by unallocation processing at step end and job end.
"""
tiu.__doc__ = """Current TIOT space used for TIOT entries (in bytes.) This will only contain a non-zero value for interval records, since TIOT entries are freed by unallocation processing at step end and job end.

SMF Info
--------
    Field: `SMF30TIU`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Current TIOT space used for TIOT entries (in bytes.) This will only contain a non-zero value for interval records, since TIOT entries are freed by unallocation processing at step end and job end.
"""

tis : Final[Field] = Field(
    name='tis',
    origin='SMF30TIS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Size of TIOT available for TIOT entries (in bytes.) This does not include the space reserved by the system for the TIOT Prefix, Header, and Trailer.

SMF Info
--------
    Field: `SMF30TIS`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Size of TIOT available for TIOT entries (in bytes.) This does not include the space reserved by the system for the TIOT Prefix, Header, and Trailer.
"""
tis.__doc__ = """Size of TIOT available for TIOT entries (in bytes.) This does not include the space reserved by the system for the TIOT Prefix, Header, and Trailer.

SMF Info
--------
    Field: `SMF30TIS`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Size of TIOT available for TIOT entries (in bytes.) This does not include the space reserved by the system for the TIOT Prefix, Header, and Trailer.
"""

numberofdataspaceshwm : Final[Field] = Field(
    name='numberofdataspaceshwm',
    origin='SMF30NUMBEROFDATASPACESHWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""The high water mark of the number of data spaces owned by this job step.

SMF Info
--------
    Field: `SMF30NUMBEROFDATASPACESHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

The high water mark of the number of data spaces owned by this job step.
"""
numberofdataspaceshwm.__doc__ = """The high water mark of the number of data spaces owned by this job step.

SMF Info
--------
    Field: `SMF30NUMBEROFDATASPACESHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

The high water mark of the number of data spaces owned by this job step.
"""

userdataspacecreatereqcount : Final[Field] = Field(
    name='userdataspacecreatereqcount',
    origin='SMF30USERDATASPACECREATEREQCOUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""The number of requests to create data spaces during this job step.

SMF Info
--------
    Field: `SMF30USERDATASPACECREATEREQCOUNT`
    Record: `SMF30S5`
    Map: `SMF30SAP`

The number of requests to create data spaces during this job step.
"""
userdataspacecreatereqcount.__doc__ = """The number of requests to create data spaces during this job step.

SMF Info
--------
    Field: `SMF30USERDATASPACECREATEREQCOUNT`
    Record: `SMF30S5`
    Map: `SMF30SAP`

The number of requests to create data spaces during this job step.
"""

dmemrequested2g : Final[Field] = Field(
    name='dmemrequested2g',
    origin='SMF30_DMEMREQUESTED2G',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Requested Dedicated Memory in 2G units at start of job step

SMF Info
--------
    Field: `SMF30_DMEMREQUESTED2G`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Requested Dedicated Memory in 2G units at start of job step
"""
dmemrequested2g.__doc__ = """Requested Dedicated Memory in 2G units at start of job step

SMF Info
--------
    Field: `SMF30_DMEMREQUESTED2G`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Requested Dedicated Memory in 2G units at start of job step
"""

dmemminrequested2g : Final[Field] = Field(
    name='dmemminrequested2g',
    origin='SMF30_DMEMMINREQUESTED2G',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Requested minimum amount of Dedicated Memory in 2G units at start of job step

SMF Info
--------
    Field: `SMF30_DMEMMINREQUESTED2G`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Requested minimum amount of Dedicated Memory in 2G units at start of job step
"""
dmemminrequested2g.__doc__ = """Requested minimum amount of Dedicated Memory in 2G units at start of job step

SMF Info
--------
    Field: `SMF30_DMEMMINREQUESTED2G`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Requested minimum amount of Dedicated Memory in 2G units at start of job step
"""

dmemassigned2g : Final[Field] = Field(
    name='dmemassigned2g',
    origin='SMF30_DMEMASSIGNED2G',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Assigned Dedicated Memory in 2G units at start of job step

SMF Info
--------
    Field: `SMF30_DMEMASSIGNED2G`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Assigned Dedicated Memory in 2G units at start of job step
"""
dmemassigned2g.__doc__ = """Assigned Dedicated Memory in 2G units at start of job step

SMF Info
--------
    Field: `SMF30_DMEMASSIGNED2G`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Assigned Dedicated Memory in 2G units at start of job step
"""

dmemnuminuseas2g : Final[Field] = Field(
    name='dmemnuminuseas2g',
    origin='SMF30_DMEMNUMINUSEAS2G',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of 2G Dedicated Memory frames in use

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEAS2G`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 2G Dedicated Memory frames in use
"""
dmemnuminuseas2g.__doc__ = """Number of 2G Dedicated Memory frames in use

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEAS2G`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 2G Dedicated Memory frames in use
"""

dmemnuminuseasfixed1m : Final[Field] = Field(
    name='dmemnuminuseasfixed1m',
    origin='SMF30_DMEMNUMINUSEASFIXED1M',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of fixed 1M Dedicated Memory frames in use

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASFIXED1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of fixed 1M Dedicated Memory frames in use
"""
dmemnuminuseasfixed1m.__doc__ = """Number of fixed 1M Dedicated Memory frames in use

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASFIXED1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of fixed 1M Dedicated Memory frames in use
"""

dmemnuminuseaspageable1m : Final[Field] = Field(
    name='dmemnuminuseaspageable1m',
    origin='SMF30_DMEMNUMINUSEASPAGEABLE1M',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of pageable 1M Dedicated Memory frames in use

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASPAGEABLE1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of pageable 1M Dedicated Memory frames in use
"""
dmemnuminuseaspageable1m.__doc__ = """Number of pageable 1M Dedicated Memory frames in use

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASPAGEABLE1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of pageable 1M Dedicated Memory frames in use
"""

dmemnuminuseas4k : Final[Field] = Field(
    name='dmemnuminuseas4k',
    origin='SMF30_DMEMNUMINUSEAS4K',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of 4K Dedicated Memory frames in use

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEAS4K`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 4K Dedicated Memory frames in use
"""
dmemnuminuseas4k.__doc__ = """Number of 4K Dedicated Memory frames in use

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEAS4K`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 4K Dedicated Memory frames in use
"""

dmemnuminuseasdattables : Final[Field] = Field(
    name='dmemnuminuseasdattables',
    origin='SMF30_DMEMNUMINUSEASDATTABLES',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of 4K Dedicated Memory frames in use as DAT tables

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASDATTABLES`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 4K Dedicated Memory frames in use as DAT tables
"""
dmemnuminuseasdattables.__doc__ = """Number of 4K Dedicated Memory frames in use as DAT tables

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASDATTABLES`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 4K Dedicated Memory frames in use as DAT tables
"""

dmemnuminuseas4khwm : Final[Field] = Field(
    name='dmemnuminuseas4khwm',
    origin='SMF30_DMEMNUMINUSEAS4KHWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of Dedicated real storage frames (4K units) that is used to back 64-bit private storage

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEAS4KHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (4K units) that is used to back 64-bit private storage
"""
dmemnuminuseas4khwm.__doc__ = """High water mark for the number of Dedicated real storage frames (4K units) that is used to back 64-bit private storage

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEAS4KHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (4K units) that is used to back 64-bit private storage
"""

dmemnuminuseaspageable1mhwm : Final[Field] = Field(
    name='dmemnuminuseaspageable1mhwm',
    origin='SMF30_DMEMNUMINUSEASPAGEABLE1MHWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of Dedicated real storage frames (1M units) that is used to back pageable 1M pages

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASPAGEABLE1MHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (1M units) that is used to back pageable 1M pages
"""
dmemnuminuseaspageable1mhwm.__doc__ = """High water mark for the number of Dedicated real storage frames (1M units) that is used to back pageable 1M pages

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASPAGEABLE1MHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (1M units) that is used to back pageable 1M pages
"""

dmemnuminuseasfixed1mhwm : Final[Field] = Field(
    name='dmemnuminuseasfixed1mhwm',
    origin='SMF30_DMEMNUMINUSEASFIXED1MHWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of Dedicated real storage frames (1M units) that is used to back fixed 1M pages

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASFIXED1MHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (1M units) that is used to back fixed 1M pages
"""
dmemnuminuseasfixed1mhwm.__doc__ = """High water mark for the number of Dedicated real storage frames (1M units) that is used to back fixed 1M pages

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASFIXED1MHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (1M units) that is used to back fixed 1M pages
"""

dmemnuminuseas2ghwm : Final[Field] = Field(
    name='dmemnuminuseas2ghwm',
    origin='SMF30_DMEMNUMINUSEAS2GHWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of Dedicated real storage frames (2G units) that is used to back 2G pages

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEAS2GHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (2G units) that is used to back 2G pages
"""
dmemnuminuseas2ghwm.__doc__ = """High water mark for the number of Dedicated real storage frames (2G units) that is used to back 2G pages

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEAS2GHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (2G units) that is used to back 2G pages
"""

dmemnuminuseasdattableshwm : Final[Field] = Field(
    name='dmemnuminuseasdattableshwm',
    origin='SMF30_DMEMNUMINUSEASDATTABLESHWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of Dedicated real storage frames (4K units) that is used to back DAT tables

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASDATTABLESHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (4K units) that is used to back DAT tables
"""
dmemnuminuseasdattableshwm.__doc__ = """High water mark for the number of Dedicated real storage frames (4K units) that is used to back DAT tables

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEASDATTABLESHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated real storage frames (4K units) that is used to back DAT tables
"""

dmemnuminusehwm : Final[Field] = Field(
    name='dmemnuminusehwm',
    origin='SMF30_DMEMNUMINUSEHWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number of Dedicated Memory frames in use 4K units

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated Memory frames in use 4K units
"""
dmemnuminusehwm.__doc__ = """High water mark for the number of Dedicated Memory frames in use 4K units

SMF Info
--------
    Field: `SMF30_DMEMNUMINUSEHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number of Dedicated Memory frames in use 4K units
"""

dmemnum2gfailed : Final[Field] = Field(
    name='dmemnum2gfailed',
    origin='SMF30_DMEMNUM2GFAILED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Count of requested 2G frames eligible to be backed by Dedicated Memory frames but were not due to availability

SMF Info
--------
    Field: `SMF30_DMEMNUM2GFAILED`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Count of requested 2G frames eligible to be backed by Dedicated Memory frames but were not due to availability
"""
dmemnum2gfailed.__doc__ = """Count of requested 2G frames eligible to be backed by Dedicated Memory frames but were not due to availability

SMF Info
--------
    Field: `SMF30_DMEMNUM2GFAILED`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Count of requested 2G frames eligible to be backed by Dedicated Memory frames but were not due to availability
"""

dmemnum1mfailed : Final[Field] = Field(
    name='dmemnum1mfailed',
    origin='SMF30_DMEMNUM1MFAILED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Count of requested 1M frames eligible to be backed by Dedicated Memory frames but were not due to availability

SMF Info
--------
    Field: `SMF30_DMEMNUM1MFAILED`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Count of requested 1M frames eligible to be backed by Dedicated Memory frames but were not due to availability
"""
dmemnum1mfailed.__doc__ = """Count of requested 1M frames eligible to be backed by Dedicated Memory frames but were not due to availability

SMF Info
--------
    Field: `SMF30_DMEMNUM1MFAILED`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Count of requested 1M frames eligible to be backed by Dedicated Memory frames but were not due to availability
"""

dmemnum4kfailed : Final[Field] = Field(
    name='dmemnum4kfailed',
    origin='SMF30_DMEMNUM4KFAILED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Count of requested 4K frames eligible to be backed by Dedicated Memory frames but were not due to availability

SMF Info
--------
    Field: `SMF30_DMEMNUM4KFAILED`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Count of requested 4K frames eligible to be backed by Dedicated Memory frames but were not due to availability
"""
dmemnum4kfailed.__doc__ = """Count of requested 4K frames eligible to be backed by Dedicated Memory frames but were not due to availability

SMF Info
--------
    Field: `SMF30_DMEMNUM4KFAILED`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Count of requested 4K frames eligible to be backed by Dedicated Memory frames but were not due to availability
"""

numinuseas2ghwm : Final[Field] = Field(
    name='numinuseas2ghwm',
    origin='SMF30_NUMINUSEAS2GHWM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of 2G frames in use by job step high water mark

SMF Info
--------
    Field: `SMF30_NUMINUSEAS2GHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 2G frames in use by job step high water mark
"""
numinuseas2ghwm.__doc__ = """Number of 2G frames in use by job step high water mark

SMF Info
--------
    Field: `SMF30_NUMINUSEAS2GHWM`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 2G frames in use by job step high water mark
"""

num2gfailed : Final[Field] = Field(
    name='num2gfailed',
    origin='SMF30_NUM2GFAILED',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of 2G frames that could not be obtained because none were available at the time of the IARV64 request

SMF Info
--------
    Field: `SMF30_NUM2GFAILED`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 2G frames that could not be obtained because none were available at the time of the IARV64 request
"""
num2gfailed.__doc__ = """Number of 2G frames that could not be obtained because none were available at the time of the IARV64 request

SMF Info
--------
    Field: `SMF30_NUM2GFAILED`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of 2G frames that could not be obtained because none were available at the time of the IARV64 request
"""

obtainshomespace : Final[Field] = Field(
    name='obtainshomespace',
    origin='SMF30_OBTAINSHOMESPACE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of GETMAIN or STORAGE OBTAIN requests within the scope of the record, either for the current interval, job step or job. Results are for the home address space at the time of the invocation.

SMF Info
--------
    Field: `SMF30_OBTAINSHOMESPACE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of GETMAIN or STORAGE OBTAIN requests within the scope of the record, either for the current interval, job step or job. Results are for the home address space at the time of the invocation.
"""
obtainshomespace.__doc__ = """Number of GETMAIN or STORAGE OBTAIN requests within the scope of the record, either for the current interval, job step or job. Results are for the home address space at the time of the invocation.

SMF Info
--------
    Field: `SMF30_OBTAINSHOMESPACE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of GETMAIN or STORAGE OBTAIN requests within the scope of the record, either for the current interval, job step or job. Results are for the home address space at the time of the invocation.
"""

iarv64obtainshomespace : Final[Field] = Field(
    name='iarv64obtainshomespace',
    origin='SMF30_IARV64OBTAINSHOMESPACE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of IARV64 GETSTOR and GETCOMMON requests within the scope of the record, either for the current interval, job step or job. Results are for the home address space at the time of the invocation.

SMF Info
--------
    Field: `SMF30_IARV64OBTAINSHOMESPACE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of IARV64 GETSTOR and GETCOMMON requests within the scope of the record, either for the current interval, job step or job. Results are for the home address space at the time of the invocation.
"""
iarv64obtainshomespace.__doc__ = """Number of IARV64 GETSTOR and GETCOMMON requests within the scope of the record, either for the current interval, job step or job. Results are for the home address space at the time of the invocation.

SMF Info
--------
    Field: `SMF30_IARV64OBTAINSHOMESPACE`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of IARV64 GETSTOR and GETCOMMON requests within the scope of the record, either for the current interval, job step or job. Results are for the home address space at the time of the invocation.
"""

framesfirstreferencebacking : Final[Field] = Field(
    name='framesfirstreferencebacking',
    origin='SMF30_FRAMESFIRSTREFERENCEBACKING',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Count of real storage frames (4K units) backing both 31-bit and 64-bit virtual storage within the scope of the record, either for the current interval, job step or job. Count includes dedicated real storage frames.

SMF Info
--------
    Field: `SMF30_FRAMESFIRSTREFERENCEBACKING`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Count of real storage frames (4K units) backing both 31-bit and 64-bit virtual storage within the scope of the record, either for the current interval, job step or job. Count includes dedicated real storage frames.
"""
framesfirstreferencebacking.__doc__ = """Count of real storage frames (4K units) backing both 31-bit and 64-bit virtual storage within the scope of the record, either for the current interval, job step or job. Count includes dedicated real storage frames.

SMF Info
--------
    Field: `SMF30_FRAMESFIRSTREFERENCEBACKING`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Count of real storage frames (4K units) backing both 31-bit and 64-bit virtual storage within the scope of the record, either for the current interval, job step or job. Count includes dedicated real storage frames.
"""

sumreal1m : Final[Field] = Field(
    name='sumreal1m',
    origin='SMF30_SUMREAL1M',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Sum of samples of the amount of real memory (includes Dedicated Memory) in 1M units within the scope of the record, either for the current interval, job step or job.

SMF Info
--------
    Field: `SMF30_SUMREAL1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Sum of samples of the amount of real memory (includes Dedicated Memory) in 1M units within the scope of the record, either for the current interval, job step or job.
"""
sumreal1m.__doc__ = """Sum of samples of the amount of real memory (includes Dedicated Memory) in 1M units within the scope of the record, either for the current interval, job step or job.

SMF Info
--------
    Field: `SMF30_SUMREAL1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Sum of samples of the amount of real memory (includes Dedicated Memory) in 1M units within the scope of the record, either for the current interval, job step or job.
"""

sumsquaresreal1m : Final[Field] = Field(
    name='sumsquaresreal1m',
    origin='SMF30_SUMSQUARESREAL1M',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Sum of squared samples of the amount of real memory (includes Dedicated Memory) in 1M units within the scope of the record, either for the current interval, job step or job.

SMF Info
--------
    Field: `SMF30_SUMSQUARESREAL1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Sum of squared samples of the amount of real memory (includes Dedicated Memory) in 1M units within the scope of the record, either for the current interval, job step or job.
"""
sumsquaresreal1m.__doc__ = """Sum of squared samples of the amount of real memory (includes Dedicated Memory) in 1M units within the scope of the record, either for the current interval, job step or job.

SMF Info
--------
    Field: `SMF30_SUMSQUARESREAL1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Sum of squared samples of the amount of real memory (includes Dedicated Memory) in 1M units within the scope of the record, either for the current interval, job step or job.
"""

numsamples : Final[Field] = Field(
    name='numsamples',
    origin='SMF30_NUMSAMPLES',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""Number of samples for both SMF30_SumReal1M and SMF30_SumSquaresReal1M within the scope of the record, either for the current interval, job step or job.

SMF Info
--------
    Field: `SMF30_NUMSAMPLES`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of samples for both SMF30_SumReal1M and SMF30_SumSquaresReal1M within the scope of the record, either for the current interval, job step or job.
"""
numsamples.__doc__ = """Number of samples for both SMF30_SumReal1M and SMF30_SumSquaresReal1M within the scope of the record, either for the current interval, job step or job.

SMF Info
--------
    Field: `SMF30_NUMSAMPLES`
    Record: `SMF30S5`
    Map: `SMF30SAP`

Number of samples for both SMF30_SumReal1M and SMF30_SumSquaresReal1M within the scope of the record, either for the current interval, job step or job.
"""

hwmhvreal1m : Final[Field] = Field(
    name='hwmhvreal1m',
    origin='SMF30_HWMHVREAL1M',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30SAP,
)
"""High water mark for the number, in 1M units, of real frames (includes Dedicated Memory) backing 64-bit virtual private storage for all frame types (4K, 1M and 2G) within the scope of the record, either for the current interval, job step or job.

SMF Info
--------
    Field: `SMF30_HWMHVREAL1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number, in 1M units, of real frames (includes Dedicated Memory) backing 64-bit virtual private storage for all frame types (4K, 1M and 2G) within the scope of the record, either for the current interval, job step or job.
"""
hwmhvreal1m.__doc__ = """High water mark for the number, in 1M units, of real frames (includes Dedicated Memory) backing 64-bit virtual private storage for all frame types (4K, 1M and 2G) within the scope of the record, either for the current interval, job step or job.

SMF Info
--------
    Field: `SMF30_HWMHVREAL1M`
    Record: `SMF30S5`
    Map: `SMF30SAP`

High water mark for the number, in 1M units, of real frames (includes Dedicated Memory) backing 64-bit virtual private storage for all frame types (4K, 1M and 2G) within the scope of the record, either for the current interval, job step or job.
"""

tot_sus : Final[Field] = Field(
    name='tot_sus',
    origin='SMF30SRV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""TOTAL SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30SRV_INV will be set to on. SMF30SRV_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30SRV`
    Record: `SMF30S5`
    Map: `SMF30PRF`

TOTAL SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30SRV_INV will be set to on. SMF30SRV_L is the 8 byte equivalent of this field.
"""
tot_sus.__doc__ = """TOTAL SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30SRV_INV will be set to on. SMF30SRV_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30SRV`
    Record: `SMF30S5`
    Map: `SMF30PRF`

TOTAL SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30SRV_INV will be set to on. SMF30SRV_L is the 8 byte equivalent of this field.
"""

cpu_sus : Final[Field] = Field(
    name='cpu_sus',
    origin='SMF30CSU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""CPU SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30CSU_INV will be set to on. SMF30CSU_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30CSU`
    Record: `SMF30S5`
    Map: `SMF30PRF`

CPU SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30CSU_INV will be set to on. SMF30CSU_L is the 8 byte equivalent of this field.
"""
cpu_sus.__doc__ = """CPU SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30CSU_INV will be set to on. SMF30CSU_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30CSU`
    Record: `SMF30S5`
    Map: `SMF30PRF`

CPU SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30CSU_INV will be set to on. SMF30CSU_L is the 8 byte equivalent of this field.
"""

srb_sus : Final[Field] = Field(
    name='srb_sus',
    origin='SMF30SRB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""SRB SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30SRB_INV will be set to on. SMF30SRB_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30SRB`
    Record: `SMF30S5`
    Map: `SMF30PRF`

SRB SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30SRB_INV will be set to on. SMF30SRB_L is the 8 byte equivalent of this field.
"""
srb_sus.__doc__ = """SRB SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30SRB_INV will be set to on. SMF30SRB_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30SRB`
    Record: `SMF30S5`
    Map: `SMF30PRF`

SRB SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30SRB_INV will be set to on. SMF30SRB_L is the 8 byte equivalent of this field.
"""

io_sus : Final[Field] = Field(
    name='io_sus',
    origin='SMF30IO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""I/O SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30IO_INV will be set to on. SMF30IO_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30IO`
    Record: `SMF30S5`
    Map: `SMF30PRF`

I/O SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30IO_INV will be set to on. SMF30IO_L is the 8 byte equivalent of this field.
"""
io_sus.__doc__ = """I/O SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30IO_INV will be set to on. SMF30IO_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30IO`
    Record: `SMF30S5`
    Map: `SMF30PRF`

I/O SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30IO_INV will be set to on. SMF30IO_L is the 8 byte equivalent of this field.
"""

mso_sus : Final[Field] = Field(
    name='mso_sus',
    origin='SMF30MSO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""MSO SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30MSO_INV will be set to on. SMF30MSO_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30MSO`
    Record: `SMF30S5`
    Map: `SMF30PRF`

MSO SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30MSO_INV will be set to on. SMF30MSO_L is the 8 byte equivalent of this field.
"""
mso_sus.__doc__ = """MSO SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30MSO_INV will be set to on. SMF30MSO_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30MSO`
    Record: `SMF30S5`
    Map: `SMF30PRF`

MSO SERVICE UNITS This field grows to 'FFFFFFFF'x and then wraps back to zero and continues growing. Once wrapping occurs, SMF30MSO_INV will be set to on. SMF30MSO_L is the 8 byte equivalent of this field.
"""

srm_xacct_act_time : Final[Field] = Field(
    name='srm_xacct_act_time',
    origin='SMF30TAT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""TRANSACTION ACTIVE TIME

SMF Info
--------
    Field: `SMF30TAT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

TRANSACTION ACTIVE TIME
"""
srm_xacct_act_time.__doc__ = """TRANSACTION ACTIVE TIME

SMF Info
--------
    Field: `SMF30TAT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

TRANSACTION ACTIVE TIME
"""

rmctadjc_copy : Final[Field] = Field(
    name='rmctadjc_copy',
    origin='SMF30SUS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Copy of RmctAdjc when this SMF record was produced, measures the number of sixteenths of one microsecond of CPU time per CPU service unit. Note: The value in this field will change when a processor capacity change occurs

SMF Info
--------
    Field: `SMF30SUS`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Copy of RmctAdjc when this SMF record was produced, measures the number of sixteenths of one microsecond of CPU time per CPU service unit. Note: The value in this field will change when a processor capacity change occurs
"""
rmctadjc_copy.__doc__ = """Copy of RmctAdjc when this SMF record was produced, measures the number of sixteenths of one microsecond of CPU time per CPU service unit. Note: The value in this field will change when a processor capacity change occurs

SMF Info
--------
    Field: `SMF30SUS`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Copy of RmctAdjc when this SMF record was produced, measures the number of sixteenths of one microsecond of CPU time per CPU service unit. Note: The value in this field will change when a processor capacity change occurs
"""

srm_xact_res_time : Final[Field] = Field(
    name='srm_xact_res_time',
    origin='SMF30RES',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""TRANSATION RESIDENCY TIME

SMF Info
--------
    Field: `SMF30RES`
    Record: `SMF30S5`
    Map: `SMF30PRF`

TRANSATION RESIDENCY TIME
"""
srm_xact_res_time.__doc__ = """TRANSATION RESIDENCY TIME

SMF Info
--------
    Field: `SMF30RES`
    Record: `SMF30S5`
    Map: `SMF30PRF`

TRANSATION RESIDENCY TIME
"""

srm_xactions_num : Final[Field] = Field(
    name='srm_xactions_num',
    origin='SMF30TRS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""NUMBER OF TRANSACTIONS

SMF Info
--------
    Field: `SMF30TRS`
    Record: `SMF30S5`
    Map: `SMF30PRF`

NUMBER OF TRANSACTIONS
"""
srm_xactions_num.__doc__ = """NUMBER OF TRANSACTIONS

SMF Info
--------
    Field: `SMF30TRS`
    Record: `SMF30S5`
    Map: `SMF30PRF`

NUMBER OF TRANSACTIONS
"""

workload_name : Final[Field] = Field(
    name='workload_name',
    origin='SMF30WLM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Workload Name - Blanks if the system is operating in workload management compatibility mode.

SMF Info
--------
    Field: `SMF30WLM`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Workload Name - Blanks if the system is operating in workload management compatibility mode.
"""
workload_name.__doc__ = """Workload Name - Blanks if the system is operating in workload management compatibility mode.

SMF Info
--------
    Field: `SMF30WLM`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Workload Name - Blanks if the system is operating in workload management compatibility mode.
"""

service_class : Final[Field] = Field(
    name='service_class',
    origin='SMF30SCN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Service Class Name - Blanks if the system is operating in workload management compatibility mode.

SMF Info
--------
    Field: `SMF30SCN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Service Class Name - Blanks if the system is operating in workload management compatibility mode.
"""
service_class.__doc__ = """Service Class Name - Blanks if the system is operating in workload management compatibility mode.

SMF Info
--------
    Field: `SMF30SCN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Service Class Name - Blanks if the system is operating in workload management compatibility mode.
"""

resource_grp : Final[Field] = Field(
    name='resource_grp',
    origin='SMF30GRN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Resource Group Name - Blanks if the system is operating in workload management compatibility mode.

SMF Info
--------
    Field: `SMF30GRN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Resource Group Name - Blanks if the system is operating in workload management compatibility mode.
"""
resource_grp.__doc__ = """Resource Group Name - Blanks if the system is operating in workload management compatibility mode.

SMF Info
--------
    Field: `SMF30GRN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Resource Group Name - Blanks if the system is operating in workload management compatibility mode.
"""

report_class : Final[Field] = Field(
    name='report_class',
    origin='SMF30RCN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Reporting Class Name - Blanks if the system is operating in workload management compatibility mode.

SMF Info
--------
    Field: `SMF30RCN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Reporting Class Name - Blanks if the system is operating in workload management compatibility mode.
"""
report_class.__doc__ = """Reporting Class Name - Blanks if the system is operating in workload management compatibility mode.

SMF Info
--------
    Field: `SMF30RCN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Reporting Class Name - Blanks if the system is operating in workload management compatibility mode.
"""

ind_encl_xact_time : Final[Field] = Field(
    name='ind_encl_xact_time',
    origin='SMF30ETA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Independent Enclave Transaction Active time

SMF Info
--------
    Field: `SMF30ETA`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Independent Enclave Transaction Active time
"""
ind_encl_xact_time.__doc__ = """Independent Enclave Transaction Active time

SMF Info
--------
    Field: `SMF30ETA`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Independent Enclave Transaction Active time
"""

ind_encl_cpu_sus : Final[Field] = Field(
    name='ind_encl_cpu_sus',
    origin='SMF30ESU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Independent Enclave CPU Service Units This field grows to 'FFFFFFFF' and then wraps back to zero and continues growing. Once wrapping occurs, SMF30ESU_INV will be set to on. SMF30ESU_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30ESU`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Independent Enclave CPU Service Units This field grows to 'FFFFFFFF' and then wraps back to zero and continues growing. Once wrapping occurs, SMF30ESU_INV will be set to on. SMF30ESU_L is the 8 byte equivalent of this field.
"""
ind_encl_cpu_sus.__doc__ = """Independent Enclave CPU Service Units This field grows to 'FFFFFFFF' and then wraps back to zero and continues growing. Once wrapping occurs, SMF30ESU_INV will be set to on. SMF30ESU_L is the 8 byte equivalent of this field.

SMF Info
--------
    Field: `SMF30ESU`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Independent Enclave CPU Service Units This field grows to 'FFFFFFFF' and then wraps back to zero and continues growing. Once wrapping occurs, SMF30ESU_INV will be set to on. SMF30ESU_L is the 8 byte equivalent of this field.
"""

ind_encl_xacts : Final[Field] = Field(
    name='ind_encl_xacts',
    origin='SMF30ETC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Independent Enclave Transaction Count Units

SMF Info
--------
    Field: `SMF30ETC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Independent Enclave Transaction Count Units
"""
ind_encl_xacts.__doc__ = """Independent Enclave Transaction Count Units

SMF Info
--------
    Field: `SMF30ETC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Independent Enclave Transaction Count Units
"""

sched_env : Final[Field] = Field(
    name='sched_env',
    origin='SMF30PFL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""JCL SCHEDENV value

SMF Info
--------
    Field: `SMF30PFL`
    Record: `SMF30S5`
    Map: `SMF30PRF`

JCL SCHEDENV value
"""
sched_env.__doc__ = """JCL SCHEDENV value

SMF Info
--------
    Field: `SMF30PFL`
    Record: `SMF30S5`
    Map: `SMF30PRF`

JCL SCHEDENV value
"""

job_prep_time : Final[Field] = Field(
    name='job_prep_time',
    origin='SMF30JQT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""JCL conversion time for batch jobs, 0 for other types of work. 1.024 millisecond units

SMF Info
--------
    Field: `SMF30JQT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

JCL conversion time for batch jobs, 0 for other types of work. 1.024 millisecond units
"""
job_prep_time.__doc__ = """JCL conversion time for batch jobs, 0 for other types of work. 1.024 millisecond units

SMF Info
--------
    Field: `SMF30JQT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

JCL conversion time for batch jobs, 0 for other types of work. 1.024 millisecond units
"""

job_inel_time_2 : Final[Field] = Field(
    name='job_inel_time_2',
    origin='SMF30RQT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Resource and/or system affinity hold time for batch jobs, 0 for other types of work. 1.024 millisecond units

SMF Info
--------
    Field: `SMF30RQT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Resource and/or system affinity hold time for batch jobs, 0 for other types of work. 1.024 millisecond units
"""
job_inel_time_2.__doc__ = """Resource and/or system affinity hold time for batch jobs, 0 for other types of work. 1.024 millisecond units

SMF Info
--------
    Field: `SMF30RQT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Resource and/or system affinity hold time for batch jobs, 0 for other types of work. 1.024 millisecond units
"""

job_inel_time_1 : Final[Field] = Field(
    name='job_inel_time_1',
    origin='SMF30HQT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Hold time not due to system affinity, resource affinity, TYPRUN=HOLD or TYPRUN=JCLHOLD for batch jobs, 0 for other types of work. 1.024 millisecond units

SMF Info
--------
    Field: `SMF30HQT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Hold time not due to system affinity, resource affinity, TYPRUN=HOLD or TYPRUN=JCLHOLD for batch jobs, 0 for other types of work. 1.024 millisecond units
"""
job_inel_time_1.__doc__ = """Hold time not due to system affinity, resource affinity, TYPRUN=HOLD or TYPRUN=JCLHOLD for batch jobs, 0 for other types of work. 1.024 millisecond units

SMF Info
--------
    Field: `SMF30HQT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Hold time not due to system affinity, resource affinity, TYPRUN=HOLD or TYPRUN=JCLHOLD for batch jobs, 0 for other types of work. 1.024 millisecond units
"""

job_eligible_exec_time : Final[Field] = Field(
    name='job_eligible_exec_time',
    origin='SMF30SQT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Time that job was eligible for execution: not held, waiting for an initiator. Valid for all types of work. 1.024 millisecond units

SMF Info
--------
    Field: `SMF30SQT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Time that job was eligible for execution: not held, waiting for an initiator. Valid for all types of work. 1.024 millisecond units
"""
job_eligible_exec_time.__doc__ = """Time that job was eligible for execution: not held, waiting for an initiator. Valid for all types of work. 1.024 millisecond units

SMF Info
--------
    Field: `SMF30SQT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Time that job was eligible for execution: not held, waiting for an initiator. Valid for all types of work. 1.024 millisecond units
"""

perf_flg_1 : Final[Field] = Field(
    name='perf_flg_1',
    origin='SMF30PF1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Performance section flag byte

SMF Info
--------
    Field: `SMF30PF1`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Performance section flag byte
"""
perf_flg_1.__doc__ = """Performance section flag byte

SMF Info
--------
    Field: `SMF30PF1`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Performance section flag byte
"""

pfj : Final[Field] = Field(
    name='pfj',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=perf_flg_1,
    record=record,
    record_map=SMF30PRF,
)
"""Job service class association was modified by a system operator prior to job initiation(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job service class association was modified by a system operator prior to job initiation

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
pfj.__doc__ = """Job service class association was modified by a system operator prior to job initiation(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job service class association was modified by a system operator prior to job initiation

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

pfr : Final[Field] = Field(
    name='pfr',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=perf_flg_1,
    record=record,
    record_map=SMF30PRF,
)
"""Job service class association was modified by a system operator during job execution(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job service class association was modified by a system operator during job execution

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
pfr.__doc__ = """Job service class association was modified by a system operator during job execution(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job service class association was modified by a system operator during job execution

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

pff : Final[Field] = Field(
    name='pff',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=perf_flg_1,
    record=record,
    record_map=SMF30PRF,
)
"""Job initiation forced by system operator(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job initiation forced by system operator

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
pff.__doc__ = """Job initiation forced by system operator(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job initiation forced by system operator

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

rtr : Final[Field] = Field(
    name='rtr',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=perf_flg_1,
    record=record,
    record_map=SMF30PRF,
)
"""Job has been restarted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job has been restarted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
rtr.__doc__ = """Job has been restarted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job has been restarted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

msi : Final[Field] = Field(
    name='msi',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=perf_flg_1,
    record=record,
    record_map=SMF30PRF,
)
"""Remote System Data is incomplete.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Remote System Data is incomplete.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
msi.__doc__ = """Remote System Data is incomplete.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Remote System Data is incomplete.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

wmi : Final[Field] = Field(
    name='wmi',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=perf_flg_1,
    record=record,
    record_map=SMF30PRF,
)
"""Job is executing in a workload manager batch initiator(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job is executing in a workload manager batch initiator

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
wmi.__doc__ = """Job is executing in a workload manager batch initiator(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Job is executing in a workload manager batch initiator

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ccp : Final[Field] = Field(
    name='ccp',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=perf_flg_1,
    record=record,
    record_map=SMF30PRF,
)
"""Service class assigned was designated CPU-critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Service class assigned was designated CPU-critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ccp.__doc__ = """Service class assigned was designated CPU-critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Service class assigned was designated CPU-critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

csp : Final[Field] = Field(
    name='csp',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=perf_flg_1,
    record=record,
    record_map=SMF30PRF,
)
"""Service class served was designated storage-critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Service class served was designated storage-critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
csp.__doc__ = """Service class served was designated storage-critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_1`(`SMF30PF1`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Service class served was designated storage-critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

perf_flg_2 : Final[Field] = Field(
    name='perf_flg_2',
    origin='SMF30PF2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Performance section flag byte

SMF Info
--------
    Field: `SMF30PF2`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Performance section flag byte
"""
perf_flg_2.__doc__ = """Performance section flag byte

SMF Info
--------
    Field: `SMF30PF2`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Performance section flag byte
"""

asp : Final[Field] = Field(
    name='asp',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=perf_flg_2,
    record=record,
    record_map=SMF30PRF,
)
"""Address space was designated storage-critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Address space was designated storage-critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
asp.__doc__ = """Address space was designated storage-critical(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Address space was designated storage-critical

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sme : Final[Field] = Field(
    name='sme',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=perf_flg_2,
    record=record,
    record_map=SMF30PRF,
)
"""Address space cannot be managed to trxn goals(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Address space cannot be managed to trxn goals

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sme.__doc__ = """Address space cannot be managed to trxn goals(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Address space cannot be managed to trxn goals

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

cpr : Final[Field] = Field(
    name='cpr',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=perf_flg_2,
    record=record,
    record_map=SMF30PRF,
)
"""Address space is currently CPU-protected(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Address space is currently CPU-protected

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
cpr.__doc__ = """Address space is currently CPU-protected(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Address space is currently CPU-protected

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

spr : Final[Field] = Field(
    name='spr',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=perf_flg_2,
    record=record,
    record_map=SMF30PRF,
)
"""Address space is currently stg-protected(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Address space is currently stg-protected

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
spr.__doc__ = """Address space is currently stg-protected(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Address space is currently stg-protected

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pin : Final[Field] = Field(
    name='pin',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=perf_flg_2,
    record=record,
    record_map=SMF30PRF,
)
"""The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30CSU SMF30MSO SMF30SPR SMF30ESU SMF30PFL SMF30SQT SMF30ETA SMF30PFR SMF30SRB SMF30ETC SMF30RCN SMF30SRV SMF30GRN SMF30RES SMF30SUS SMF30HQT SMF30RQT SMF30TAT SMF30IO SMF30RTR SMF30TRS SMF30JPN SMF30SCN SMF30WLM SMF30JQT SMF30SME SMF30CRM SMF30SRV_L SMF30CSU_L SMF30SRB_L SMF30IO_L SMF30MSO_L SMF30ESU_L(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30CSU SMF30MSO SMF30SPR SMF30ESU SMF30PFL SMF30SQT SMF30ETA SMF30PFR SMF30SRB SMF30ETC SMF30RCN SMF30SRV SMF30GRN SMF30RES SMF30SUS SMF30HQT SMF30RQT SMF30TAT SMF30IO SMF30RTR SMF30TRS SMF30JPN SMF30SCN SMF30WLM SMF30JQT SMF30SME SMF30CRM SMF30SRV_L SMF30CSU_L SMF30SRB_L SMF30IO_L SMF30MSO_L SMF30ESU_L

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pin.__doc__ = """The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30CSU SMF30MSO SMF30SPR SMF30ESU SMF30PFL SMF30SQT SMF30ETA SMF30PFR SMF30SRB SMF30ETC SMF30RCN SMF30SRV SMF30GRN SMF30RES SMF30SUS SMF30HQT SMF30RQT SMF30TAT SMF30IO SMF30RTR SMF30TRS SMF30JPN SMF30SCN SMF30WLM SMF30JQT SMF30SME SMF30CRM SMF30SRV_L SMF30CSU_L SMF30SRB_L SMF30IO_L SMF30MSO_L SMF30ESU_L(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30CSU SMF30MSO SMF30SPR SMF30ESU SMF30PFL SMF30SQT SMF30ETA SMF30PFR SMF30SRB SMF30ETC SMF30RCN SMF30SRV SMF30GRN SMF30RES SMF30SUS SMF30HQT SMF30RQT SMF30TAT SMF30IO SMF30RTR SMF30TRS SMF30JPN SMF30SCN SMF30WLM SMF30JQT SMF30SME SMF30CRM SMF30SRV_L SMF30CSU_L SMF30SRB_L SMF30IO_L SMF30MSO_L SMF30ESU_L

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

crm : Final[Field] = Field(
    name='crm',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=perf_flg_2,
    record=record,
    record_map=SMF30PRF,
)
"""The address space matched a classification rule which specified "manage region using goals of both", which means it is managed towards the velocity goal of the region. But, transaction completions are reported and used for management of the transaction service classes with response time goals. This option should only be used with CICS TORs, the associated AORs should remain at the default "manage region using goals of transaction". */(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

The address space matched a classification rule which specified "manage region using goals of both", which means it is managed towards the velocity goal of the region. But, transaction completions are reported and used for management of the transaction service classes with response time goals. This option should only be used with CICS TORs, the associated AORs should remain at the default "manage region using goals of transaction". */

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
crm.__doc__ = """The address space matched a classification rule which specified "manage region using goals of both", which means it is managed towards the velocity goal of the region. But, transaction completions are reported and used for management of the transaction service classes with response time goals. This option should only be used with CICS TORs, the associated AORs should remain at the default "manage region using goals of transaction". */(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_2`(`SMF30PF2`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

The address space matched a classification rule which specified "manage region using goals of both", which means it is managed towards the velocity goal of the region. But, transaction completions are reported and used for management of the transaction service classes with response time goals. This option should only be used with CICS TORs, the associated AORs should remain at the default "manage region using goals of transaction". */

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

perf_flg_3 : Final[Field] = Field(
    name='perf_flg_3',
    origin='SMF30INV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Flag byte

SMF Info
--------
    Field: `SMF30INV`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Flag byte
"""
perf_flg_3.__doc__ = """Flag byte

SMF Info
--------
    Field: `SMF30INV`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Flag byte
"""

srv_inv : Final[Field] = Field(
    name='srv_inv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=perf_flg_3,
    record=record,
    record_map=SMF30PRF,
)
"""Bit 0 When on, indicates that the value in SMF30SRV has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30SRV_L is the 8 byte equivalent of SMF30SRV.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 0 When on, indicates that the value in SMF30SRV has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30SRV_L is the 8 byte equivalent of SMF30SRV.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
srv_inv.__doc__ = """Bit 0 When on, indicates that the value in SMF30SRV has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30SRV_L is the 8 byte equivalent of SMF30SRV.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 0 When on, indicates that the value in SMF30SRV has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30SRV_L is the 8 byte equivalent of SMF30SRV.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

csu_inv : Final[Field] = Field(
    name='csu_inv',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=perf_flg_3,
    record=record,
    record_map=SMF30PRF,
)
"""Bit 1 When on, indicates that the value in SMF30CSU has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30CSU_L is the 8 byte equivalent of SMF30CSU.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 1 When on, indicates that the value in SMF30CSU has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30CSU_L is the 8 byte equivalent of SMF30CSU.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
csu_inv.__doc__ = """Bit 1 When on, indicates that the value in SMF30CSU has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30CSU_L is the 8 byte equivalent of SMF30CSU.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 1 When on, indicates that the value in SMF30CSU has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30CSU_L is the 8 byte equivalent of SMF30CSU.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

srb_inv : Final[Field] = Field(
    name='srb_inv',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=perf_flg_3,
    record=record,
    record_map=SMF30PRF,
)
"""Bit 2 When on, indicates that the value in SMF30SRB has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30SRB_L is the 8 byte equivalent of SMF30SRB.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 2 When on, indicates that the value in SMF30SRB has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30SRB_L is the 8 byte equivalent of SMF30SRB.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
srb_inv.__doc__ = """Bit 2 When on, indicates that the value in SMF30SRB has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30SRB_L is the 8 byte equivalent of SMF30SRB.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 2 When on, indicates that the value in SMF30SRB has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30SRB_L is the 8 byte equivalent of SMF30SRB.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

io_inv : Final[Field] = Field(
    name='io_inv',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=perf_flg_3,
    record=record,
    record_map=SMF30PRF,
)
"""Bit 3 When on, indicates that the value in SMF30IO has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30IO_L is the 8 byte equivalent of SMF30IO.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 3 When on, indicates that the value in SMF30IO has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30IO_L is the 8 byte equivalent of SMF30IO.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
io_inv.__doc__ = """Bit 3 When on, indicates that the value in SMF30IO has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30IO_L is the 8 byte equivalent of SMF30IO.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 3 When on, indicates that the value in SMF30IO has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30IO_L is the 8 byte equivalent of SMF30IO.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

mso_inv : Final[Field] = Field(
    name='mso_inv',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=perf_flg_3,
    record=record,
    record_map=SMF30PRF,
)
"""Bit 4 When on, indicates that the value in SMF30MSO has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30MSO_L is the 8 byte equivalent of SMF30MSO.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 4 When on, indicates that the value in SMF30MSO has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30MSO_L is the 8 byte equivalent of SMF30MSO.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
mso_inv.__doc__ = """Bit 4 When on, indicates that the value in SMF30MSO has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30MSO_L is the 8 byte equivalent of SMF30MSO.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 4 When on, indicates that the value in SMF30MSO has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30MSO_L is the 8 byte equivalent of SMF30MSO.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

esu_inv : Final[Field] = Field(
    name='esu_inv',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=perf_flg_3,
    record=record,
    record_map=SMF30PRF,
)
"""Bit 5 When on, indicates that the value in SMF30ESU has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30ESU_L is the 8 byte equivalent of SMF30ESU.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 5 When on, indicates that the value in SMF30ESU has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30ESU_L is the 8 byte equivalent of SMF30ESU.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
esu_inv.__doc__ = """Bit 5 When on, indicates that the value in SMF30ESU has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30ESU_L is the 8 byte equivalent of SMF30ESU.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `perf_flg_3`(`SMF30INV`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Bit 5 When on, indicates that the value in SMF30ESU has grown past its 4 byte maximum value capacity of 'FFFFFFFF'x and has wrapped back to zero. SMF30ESU_L is the 8 byte equivalent of SMF30ESU.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

smf30zep : Final[Field] = Field(
    name='smf30zep',
    origin='SMF30ZEP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Contains information associated with a potential future function, no further details are available at this time

SMF Info
--------
    Field: `SMF30ZEP`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time
"""
smf30zep.__doc__ = """Contains information associated with a potential future function, no further details are available at this time

SMF Info
--------
    Field: `SMF30ZEP`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time
"""

subsys_coll_name : Final[Field] = Field(
    name='subsys_coll_name',
    origin='SMF30JPN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Subsystem collection name from IWMCLSFY SUBCOLN

SMF Info
--------
    Field: `SMF30JPN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Subsystem collection name from IWMCLSFY SUBCOLN
"""
subsys_coll_name.__doc__ = """Subsystem collection name from IWMCLSFY SUBCOLN

SMF Info
--------
    Field: `SMF30JPN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Subsystem collection name from IWMCLSFY SUBCOLN
"""

mso_sdc_1000 : Final[Field] = Field(
    name='mso_sdc_1000',
    origin='SMF30MSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""MSO SDC, scaled by 10000

SMF Info
--------
    Field: `SMF30MSC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

MSO SDC, scaled by 10000
"""
mso_sdc_1000.__doc__ = """MSO SDC, scaled by 10000

SMF Info
--------
    Field: `SMF30MSC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

MSO SDC, scaled by 10000
"""

cpu_sdc_10 : Final[Field] = Field(
    name='cpu_sdc_10',
    origin='SMF30CPC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""CPU SDC, scaled by 10

SMF Info
--------
    Field: `SMF30CPC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

CPU SDC, scaled by 10
"""
cpu_sdc_10.__doc__ = """CPU SDC, scaled by 10

SMF Info
--------
    Field: `SMF30CPC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

CPU SDC, scaled by 10
"""

ioc_sdc_10 : Final[Field] = Field(
    name='ioc_sdc_10',
    origin='SMF30LOC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""IOC SDC, scaled by 10

SMF Info
--------
    Field: `SMF30LOC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

IOC SDC, scaled by 10
"""
ioc_sdc_10.__doc__ = """IOC SDC, scaled by 10

SMF Info
--------
    Field: `SMF30LOC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

IOC SDC, scaled by 10
"""

srb_sdc_10 : Final[Field] = Field(
    name='srb_sdc_10',
    origin='SMF30SRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""SRB SDC, scaled by 10

SMF Info
--------
    Field: `SMF30SRC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

SRB SDC, scaled by 10
"""
srb_sdc_10.__doc__ = """SRB SDC, scaled by 10

SMF Info
--------
    Field: `SMF30SRC`
    Record: `SMF30S5`
    Map: `SMF30PRF`

SRB SDC, scaled by 10
"""

factor_ifa_svc_time : Final[Field] = Field(
    name='factor_ifa_svc_time',
    origin='SMF30ZNF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""zAAP Normalization Factor for zAAP service time. Used to convert between real zAAP times and normalized zAAP times, that is, the equivalent time on a standard CP. Multiply SMF30_TIME_ON_zAAP by this value and divide by 256 to calculate the normalized zAAP time.

SMF Info
--------
    Field: `SMF30ZNF`
    Record: `SMF30S5`
    Map: `SMF30PRF`

zAAP Normalization Factor for zAAP service time. Used to convert between real zAAP times and normalized zAAP times, that is, the equivalent time on a standard CP. Multiply SMF30_TIME_ON_zAAP by this value and divide by 256 to calculate the normalized zAAP time.
"""
factor_ifa_svc_time.__doc__ = """zAAP Normalization Factor for zAAP service time. Used to convert between real zAAP times and normalized zAAP times, that is, the equivalent time on a standard CP. Multiply SMF30_TIME_ON_zAAP by this value and divide by 256 to calculate the normalized zAAP time.

SMF Info
--------
    Field: `SMF30ZNF`
    Record: `SMF30S5`
    Map: `SMF30PRF`

zAAP Normalization Factor for zAAP service time. Used to convert between real zAAP times and normalized zAAP times, that is, the equivalent time on a standard CP. Multiply SMF30_TIME_ON_zAAP by this value and divide by 256 to calculate the normalized zAAP time.
"""

factor_ziip_svc_time : Final[Field] = Field(
    name='factor_ziip_svc_time',
    origin='SMF30SNF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""zIIP Normalization Factor for zIIP service time. Used to convert between real zIIP times and normalized zIIP times, that is, the equivalent time on a standard CP. Multiply SMF30_TIME_ON_zIIP by this value and divide by 256 to calculate the normalized zIIP time.

SMF Info
--------
    Field: `SMF30SNF`
    Record: `SMF30S5`
    Map: `SMF30PRF`

zIIP Normalization Factor for zIIP service time. Used to convert between real zIIP times and normalized zIIP times, that is, the equivalent time on a standard CP. Multiply SMF30_TIME_ON_zIIP by this value and divide by 256 to calculate the normalized zIIP time.
"""
factor_ziip_svc_time.__doc__ = """zIIP Normalization Factor for zIIP service time. Used to convert between real zIIP times and normalized zIIP times, that is, the equivalent time on a standard CP. Multiply SMF30_TIME_ON_zIIP by this value and divide by 256 to calculate the normalized zIIP time.

SMF Info
--------
    Field: `SMF30SNF`
    Record: `SMF30S5`
    Map: `SMF30PRF`

zIIP Normalization Factor for zIIP service time. Used to convert between real zIIP times and normalized zIIP times, that is, the equivalent time on a standard CP. Multiply SMF30_TIME_ON_zIIP by this value and divide by 256 to calculate the normalized zIIP time.
"""

tot_sus_l : Final[Field] = Field(
    name='tot_sus_l',
    origin='SMF30SRV_L',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""TOTAL SERVICE UNITS This is the 8 byte equivalent of SMF30SRV. Its value continues to grow after SMF30SRV_INV is set.

SMF Info
--------
    Field: `SMF30SRV_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

TOTAL SERVICE UNITS This is the 8 byte equivalent of SMF30SRV. Its value continues to grow after SMF30SRV_INV is set.
"""
tot_sus_l.__doc__ = """TOTAL SERVICE UNITS This is the 8 byte equivalent of SMF30SRV. Its value continues to grow after SMF30SRV_INV is set.

SMF Info
--------
    Field: `SMF30SRV_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

TOTAL SERVICE UNITS This is the 8 byte equivalent of SMF30SRV. Its value continues to grow after SMF30SRV_INV is set.
"""

cpu_sus_l : Final[Field] = Field(
    name='cpu_sus_l',
    origin='SMF30CSU_L',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""CPU SERVICE UNITS This is the 8 byte equivalent of SMF30CSU. Its value continues to grow after SMF30CSU_INV is set.

SMF Info
--------
    Field: `SMF30CSU_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

CPU SERVICE UNITS This is the 8 byte equivalent of SMF30CSU. Its value continues to grow after SMF30CSU_INV is set.
"""
cpu_sus_l.__doc__ = """CPU SERVICE UNITS This is the 8 byte equivalent of SMF30CSU. Its value continues to grow after SMF30CSU_INV is set.

SMF Info
--------
    Field: `SMF30CSU_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

CPU SERVICE UNITS This is the 8 byte equivalent of SMF30CSU. Its value continues to grow after SMF30CSU_INV is set.
"""

srb_sus_l : Final[Field] = Field(
    name='srb_sus_l',
    origin='SMF30SRB_L',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""SRB SERVICE UNITS This is the 8 byte equivalent of SMF30SRB. Its value continues to grow after SMF30SRB_INV is set.

SMF Info
--------
    Field: `SMF30SRB_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

SRB SERVICE UNITS This is the 8 byte equivalent of SMF30SRB. Its value continues to grow after SMF30SRB_INV is set.
"""
srb_sus_l.__doc__ = """SRB SERVICE UNITS This is the 8 byte equivalent of SMF30SRB. Its value continues to grow after SMF30SRB_INV is set.

SMF Info
--------
    Field: `SMF30SRB_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

SRB SERVICE UNITS This is the 8 byte equivalent of SMF30SRB. Its value continues to grow after SMF30SRB_INV is set.
"""

io_sus_l : Final[Field] = Field(
    name='io_sus_l',
    origin='SMF30IO_L',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""I/O SERVICE UNITS This is the 8 byte equivalent of SMF30IO. Its value continues to grow after SMF30IO_INV is set.

SMF Info
--------
    Field: `SMF30IO_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

I/O SERVICE UNITS This is the 8 byte equivalent of SMF30IO. Its value continues to grow after SMF30IO_INV is set.
"""
io_sus_l.__doc__ = """I/O SERVICE UNITS This is the 8 byte equivalent of SMF30IO. Its value continues to grow after SMF30IO_INV is set.

SMF Info
--------
    Field: `SMF30IO_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

I/O SERVICE UNITS This is the 8 byte equivalent of SMF30IO. Its value continues to grow after SMF30IO_INV is set.
"""

mso_sus_l : Final[Field] = Field(
    name='mso_sus_l',
    origin='SMF30MSO_L',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""MSO SERVICE UNITS This is the 8 byte equivalent of SMF30MSO. Its value continues to grow after SMF30MSO_INV is set.

SMF Info
--------
    Field: `SMF30MSO_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

MSO SERVICE UNITS This is the 8 byte equivalent of SMF30MSO. Its value continues to grow after SMF30MSO_INV is set.
"""
mso_sus_l.__doc__ = """MSO SERVICE UNITS This is the 8 byte equivalent of SMF30MSO. Its value continues to grow after SMF30MSO_INV is set.

SMF Info
--------
    Field: `SMF30MSO_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

MSO SERVICE UNITS This is the 8 byte equivalent of SMF30MSO. Its value continues to grow after SMF30MSO_INV is set.
"""

esu_sus_l : Final[Field] = Field(
    name='esu_sus_l',
    origin='SMF30ESU_L',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Independent Enclave CPU Service Units This is the 8 byte equivalent of SMF30ESU. Its value continues to grow after SMF30ESU_INV is set.

SMF Info
--------
    Field: `SMF30ESU_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Independent Enclave CPU Service Units This is the 8 byte equivalent of SMF30ESU. Its value continues to grow after SMF30ESU_INV is set.
"""
esu_sus_l.__doc__ = """Independent Enclave CPU Service Units This is the 8 byte equivalent of SMF30ESU. Its value continues to grow after SMF30ESU_INV is set.

SMF Info
--------
    Field: `SMF30ESU_L`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Independent Enclave CPU Service Units This is the 8 byte equivalent of SMF30ESU. Its value continues to grow after SMF30ESU_INV is set.
"""

acb : Final[Field] = Field(
    name='acb',
    origin='SMF30ACB',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Contains information associated with a potential future function, no further details are available at this time

SMF Info
--------
    Field: `SMF30ACB`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time
"""
acb.__doc__ = """Contains information associated with a potential future function, no further details are available at this time

SMF Info
--------
    Field: `SMF30ACB`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time
"""

lga : Final[Field] = Field(
    name='lga',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=acb,
    record=record,
    record_map=SMF30PRF,
)
"""Contains information associated with a potential future function, no further details are available at this time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `acb`(`SMF30ACB`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
lga.__doc__ = """Contains information associated with a potential future function, no further details are available at this time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `acb`(`SMF30ACB`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

p1a : Final[Field] = Field(
    name='p1a',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=acb,
    record=record,
    record_map=SMF30PRF,
)
"""Contains information associated with a potential future function, no further details are available at this time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `acb`(`SMF30ACB`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
p1a.__doc__ = """Contains information associated with a potential future function, no further details are available at this time(V)

SMF Info (Virtual Field)
--------
    Field: Based on `acb`(`SMF30ACB`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

smf30cr : Final[Field] = Field(
    name='smf30cr',
    origin='SMF30CR',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Contains information associated with a potential future function, no further details are available at this time

SMF Info
--------
    Field: `SMF30CR`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time
"""
smf30cr.__doc__ = """Contains information associated with a potential future function, no further details are available at this time

SMF Info
--------
    Field: `SMF30CR`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Contains information associated with a potential future function, no further details are available at this time
"""

capacity_change_cnt : Final[Field] = Field(
    name='capacity_change_cnt',
    origin='SMF30_CAPACITY_CHANGE_CNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""The number of processor capacity changes that occurred since the previous interval or event interval. This number will be greater than 1 when the number of processor capacity changes exceeded the number specified in the MAXEVENTINTRECS parmlib option.

SMF Info
--------
    Field: `SMF30_CAPACITY_CHANGE_CNT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

The number of processor capacity changes that occurred since the previous interval or event interval. This number will be greater than 1 when the number of processor capacity changes exceeded the number specified in the MAXEVENTINTRECS parmlib option.
"""
capacity_change_cnt.__doc__ = """The number of processor capacity changes that occurred since the previous interval or event interval. This number will be greater than 1 when the number of processor capacity changes exceeded the number specified in the MAXEVENTINTRECS parmlib option.

SMF Info
--------
    Field: `SMF30_CAPACITY_CHANGE_CNT`
    Record: `SMF30S5`
    Map: `SMF30PRF`

The number of processor capacity changes that occurred since the previous interval or event interval. This number will be greater than 1 when the number of processor capacity changes exceeded the number specified in the MAXEVENTINTRECS parmlib option.
"""

rctpcpua_actual : Final[Field] = Field(
    name='rctpcpua_actual',
    origin='SMF30_RCTPCPUA_ACTUAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Physical CPU adjustment factor (i.e. adjustment factor for converting CPU time to equivalent service in basic mode with all processors online). Based on Model Capacity Rating.

SMF Info
--------
    Field: `SMF30_RCTPCPUA_ACTUAL`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Physical CPU adjustment factor (i.e. adjustment factor for converting CPU time to equivalent service in basic mode with all processors online). Based on Model Capacity Rating.
"""
rctpcpua_actual.__doc__ = """Physical CPU adjustment factor (i.e. adjustment factor for converting CPU time to equivalent service in basic mode with all processors online). Based on Model Capacity Rating.

SMF Info
--------
    Field: `SMF30_RCTPCPUA_ACTUAL`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Physical CPU adjustment factor (i.e. adjustment factor for converting CPU time to equivalent service in basic mode with all processors online). Based on Model Capacity Rating.
"""

rctpcpua_nominal : Final[Field] = Field(
    name='rctpcpua_nominal',
    origin='SMF30_RCTPCPUA_NOMINAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Physical CPU adjustment factor for collecting CPU time to equivalent service in basic-mode with all processors online). Based on Model Capacity Rating.

SMF Info
--------
    Field: `SMF30_RCTPCPUA_NOMINAL`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Physical CPU adjustment factor for collecting CPU time to equivalent service in basic-mode with all processors online). Based on Model Capacity Rating.
"""
rctpcpua_nominal.__doc__ = """Physical CPU adjustment factor for collecting CPU time to equivalent service in basic-mode with all processors online). Based on Model Capacity Rating.

SMF Info
--------
    Field: `SMF30_RCTPCPUA_NOMINAL`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Physical CPU adjustment factor for collecting CPU time to equivalent service in basic-mode with all processors online). Based on Model Capacity Rating.
"""

rctpcpua_scaling_factor : Final[Field] = Field(
    name='rctpcpua_scaling_factor',
    origin='SMF30_RCTPCPUA_SCALING_FACTOR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Scaling factor for SMF30_RCTPCPUA_Actual and SMF30_RCTPCPUA_Nominal.

SMF Info
--------
    Field: `SMF30_RCTPCPUA_SCALING_FACTOR`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Scaling factor for SMF30_RCTPCPUA_Actual and SMF30_RCTPCPUA_Nominal.
"""
rctpcpua_scaling_factor.__doc__ = """Scaling factor for SMF30_RCTPCPUA_Actual and SMF30_RCTPCPUA_Nominal.

SMF Info
--------
    Field: `SMF30_RCTPCPUA_SCALING_FACTOR`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Scaling factor for SMF30_RCTPCPUA_Actual and SMF30_RCTPCPUA_Nominal.
"""

capacity_adjustment_ind : Final[Field] = Field(
    name='capacity_adjustment_ind',
    origin='SMF30_CAPACITY_ADJUSTMENT_IND',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""When zero, indication is not reported. When in the range 1-99, some amount of reduction is indicated. When 100, the machine is operating at its normal capacity. Primary CPUs and all secondary-type CPUs are similarly affected.

SMF Info
--------
    Field: `SMF30_CAPACITY_ADJUSTMENT_IND`
    Record: `SMF30S5`
    Map: `SMF30PRF`

When zero, indication is not reported. When in the range 1-99, some amount of reduction is indicated. When 100, the machine is operating at its normal capacity. Primary CPUs and all secondary-type CPUs are similarly affected.
"""
capacity_adjustment_ind.__doc__ = """When zero, indication is not reported. When in the range 1-99, some amount of reduction is indicated. When 100, the machine is operating at its normal capacity. Primary CPUs and all secondary-type CPUs are similarly affected.

SMF Info
--------
    Field: `SMF30_CAPACITY_ADJUSTMENT_IND`
    Record: `SMF30S5`
    Map: `SMF30PRF`

When zero, indication is not reported. When in the range 1-99, some amount of reduction is indicated. When 100, the machine is operating at its normal capacity. Primary CPUs and all secondary-type CPUs are similarly affected.
"""

capacity_change_rsn : Final[Field] = Field(
    name='capacity_change_rsn',
    origin='SMF30_CAPACITY_CHANGE_RSN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Indicates the reason which is associated with the present value contained in SMF30_Capacity_Adjustment_Ind. The bit values of this field correspond to those described in RMCTZ_Capacity_Adjustment_I ndication of the IRARMCTZ mapping macro (see Data Areas).

SMF Info
--------
    Field: `SMF30_CAPACITY_CHANGE_RSN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Indicates the reason which is associated with the present value contained in SMF30_Capacity_Adjustment_Ind. The bit values of this field correspond to those described in RMCTZ_Capacity_Adjustment_I ndication of the IRARMCTZ mapping macro (see Data Areas).
"""
capacity_change_rsn.__doc__ = """Indicates the reason which is associated with the present value contained in SMF30_Capacity_Adjustment_Ind. The bit values of this field correspond to those described in RMCTZ_Capacity_Adjustment_I ndication of the IRARMCTZ mapping macro (see Data Areas).

SMF Info
--------
    Field: `SMF30_CAPACITY_CHANGE_RSN`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Indicates the reason which is associated with the present value contained in SMF30_Capacity_Adjustment_Ind. The bit values of this field correspond to those described in RMCTZ_Capacity_Adjustment_I ndication of the IRARMCTZ mapping macro (see Data Areas).
"""

capacity_flags : Final[Field] = Field(
    name='capacity_flags',
    origin='SMF30_CAPACITY_FLAGS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30PRF,
)
"""Processor capacity data

SMF Info
--------
    Field: `SMF30_CAPACITY_FLAGS`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Processor capacity data
"""
capacity_flags.__doc__ = """Processor capacity data

SMF Info
--------
    Field: `SMF30_CAPACITY_FLAGS`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Processor capacity data
"""

event_driven_intvl_rec : Final[Field] = Field(
    name='event_driven_intvl_rec',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=capacity_flags,
    record=record,
    record_map=SMF30PRF,
)
"""When on, indicates that the current interval record was generated as a result of an event, rather than as a result of standard interval expiration based on time.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `capacity_flags`(`SMF30_CAPACITY_FLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

When on, indicates that the current interval record was generated as a result of an event, rather than as a result of standard interval expiration based on time.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
event_driven_intvl_rec.__doc__ = """When on, indicates that the current interval record was generated as a result of an event, rather than as a result of standard interval expiration based on time.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `capacity_flags`(`SMF30_CAPACITY_FLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

When on, indicates that the current interval record was generated as a result of an event, rather than as a result of standard interval expiration based on time.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

rqsvsus_err : Final[Field] = Field(
    name='rqsvsus_err',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=capacity_flags,
    record=record,
    record_map=SMF30PRF,
)
"""When on, indicates that an error occurred while collecting the data for SMF30SUS following a change in processor capacity. If this bit is found to be on when the record is being written, an additional attempt to collect the data from SRM is made. If that attempt is successful, the data is filled in at that time and the SMF30PIN error bit will be off.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `capacity_flags`(`SMF30_CAPACITY_FLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

When on, indicates that an error occurred while collecting the data for SMF30SUS following a change in processor capacity. If this bit is found to be on when the record is being written, an additional attempt to collect the data from SRM is made. If that attempt is successful, the data is filled in at that time and the SMF30PIN error bit will be off.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
rqsvsus_err.__doc__ = """When on, indicates that an error occurred while collecting the data for SMF30SUS following a change in processor capacity. If this bit is found to be on when the record is being written, an additional attempt to collect the data from SRM is made. If that attempt is successful, the data is filled in at that time and the SMF30PIN error bit will be off.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `capacity_flags`(`SMF30_CAPACITY_FLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

When on, indicates that an error occurred while collecting the data for SMF30SUS following a change in processor capacity. If this bit is found to be on when the record is being written, an additional attempt to collect the data from SRM is made. If that attempt is successful, the data is filled in at that time and the SMF30PIN error bit will be off.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

capacity_data_err : Final[Field] = Field(
    name='capacity_data_err',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=capacity_flags,
    record=record,
    record_map=SMF30PRF,
)
"""When on, indicates that error occurred while collecting the processor capacity data, therefore the following fields are unreliable: SMF30_RCTPCPUA_Actual SMF30_RCTPCPUA_Nominal SMF30_RCTPCPUA_scaling_factor SMF30_Capacity_Adjustment_Ind SMF30_Capacity_Change_Rsn(V)

SMF Info (Virtual Field)
--------
    Field: Based on `capacity_flags`(`SMF30_CAPACITY_FLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

When on, indicates that error occurred while collecting the processor capacity data, therefore the following fields are unreliable: SMF30_RCTPCPUA_Actual SMF30_RCTPCPUA_Nominal SMF30_RCTPCPUA_scaling_factor SMF30_Capacity_Adjustment_Ind SMF30_Capacity_Change_Rsn

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
capacity_data_err.__doc__ = """When on, indicates that error occurred while collecting the processor capacity data, therefore the following fields are unreliable: SMF30_RCTPCPUA_Actual SMF30_RCTPCPUA_Nominal SMF30_RCTPCPUA_scaling_factor SMF30_Capacity_Adjustment_Ind SMF30_Capacity_Change_Rsn(V)

SMF Info (Virtual Field)
--------
    Field: Based on `capacity_flags`(`SMF30_CAPACITY_FLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

When on, indicates that error occurred while collecting the processor capacity data, therefore the following fields are unreliable: SMF30_RCTPCPUA_Actual SMF30_RCTPCPUA_Nominal SMF30_RCTPCPUA_scaling_factor SMF30_Capacity_Adjustment_Ind SMF30_Capacity_Change_Rsn

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

pcd_rsvd_exists : Final[Field] = Field(
    name='pcd_rsvd_exists',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=capacity_flags,
    record=record,
    record_map=SMF30PRF,
)
"""This bit is set in records generated on systems running z/OS 1.7 through z/OS 1.9. It will remain off in records generated at systems running z/OS 1.10 and above.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `capacity_flags`(`SMF30_CAPACITY_FLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

This bit is set in records generated on systems running z/OS 1.7 through z/OS 1.9. It will remain off in records generated at systems running z/OS 1.10 and above.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
pcd_rsvd_exists.__doc__ = """This bit is set in records generated on systems running z/OS 1.7 through z/OS 1.9. It will remain off in records generated at systems running z/OS 1.10 and above.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `capacity_flags`(`SMF30_CAPACITY_FLAGS`)
    Record: `SMF30S5`
    Map: `SMF30PRF`

This bit is set in records generated on systems running z/OS 1.7 through z/OS 1.9. It will remain off in records generated at systems running z/OS 1.10 and above.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rmctadjn_nominal : Final[Field] = Field(
    name='rmctadjn_nominal',
    origin='SMF30_RMCTADJN_NOMINAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30PRF,
)
"""Nominal CPU rate adjustment

SMF Info
--------
    Field: `SMF30_RMCTADJN_NOMINAL`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Nominal CPU rate adjustment
"""
rmctadjn_nominal.__doc__ = """Nominal CPU rate adjustment

SMF Info
--------
    Field: `SMF30_RMCTADJN_NOMINAL`
    Record: `SMF30S5`
    Map: `SMF30PRF`

Nominal CPU rate adjustment
"""

nonspec_dasd_mounts_num : Final[Field] = Field(
    name='nonspec_dasd_mounts_num',
    origin='SMF30PDM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OPS,
)
"""NUMBER OF NON-SPECIFIC DASD MOUNTS

SMF Info
--------
    Field: `SMF30PDM`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF NON-SPECIFIC DASD MOUNTS
"""
nonspec_dasd_mounts_num.__doc__ = """NUMBER OF NON-SPECIFIC DASD MOUNTS

SMF Info
--------
    Field: `SMF30PDM`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF NON-SPECIFIC DASD MOUNTS
"""

spec_dasd_mounts_num : Final[Field] = Field(
    name='spec_dasd_mounts_num',
    origin='SMF30PRD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OPS,
)
"""NUMBER OF SPECIFIC DASD MOUNTS

SMF Info
--------
    Field: `SMF30PRD`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF SPECIFIC DASD MOUNTS
"""
spec_dasd_mounts_num.__doc__ = """NUMBER OF SPECIFIC DASD MOUNTS

SMF Info
--------
    Field: `SMF30PRD`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF SPECIFIC DASD MOUNTS
"""

nonspec_tape_mounts_num : Final[Field] = Field(
    name='nonspec_tape_mounts_num',
    origin='SMF30PTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OPS,
)
"""NUMBER OF NON-SPECIFIC TAPE MOUNTS

SMF Info
--------
    Field: `SMF30PTM`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF NON-SPECIFIC TAPE MOUNTS
"""
nonspec_tape_mounts_num.__doc__ = """NUMBER OF NON-SPECIFIC TAPE MOUNTS

SMF Info
--------
    Field: `SMF30PTM`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF NON-SPECIFIC TAPE MOUNTS
"""

spec_tape_mounts_num : Final[Field] = Field(
    name='spec_tape_mounts_num',
    origin='SMF30TPR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OPS,
)
"""NUMBER OF SPECIFIC TAPE MOUNTS

SMF Info
--------
    Field: `SMF30TPR`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF SPECIFIC TAPE MOUNTS
"""
spec_tape_mounts_num.__doc__ = """NUMBER OF SPECIFIC TAPE MOUNTS

SMF Info
--------
    Field: `SMF30TPR`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF SPECIFIC TAPE MOUNTS
"""

nonspecific_mss_mounts_num : Final[Field] = Field(
    name='nonspecific_mss_mounts_num',
    origin='SMF30MTM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OPS,
)
"""NUMBER OF NONSPECIFIC MSS MOUNTS

SMF Info
--------
    Field: `SMF30MTM`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF NONSPECIFIC MSS MOUNTS
"""
nonspecific_mss_mounts_num.__doc__ = """NUMBER OF NONSPECIFIC MSS MOUNTS

SMF Info
--------
    Field: `SMF30MTM`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF NONSPECIFIC MSS MOUNTS
"""

specific_mss_mounts_num : Final[Field] = Field(
    name='specific_mss_mounts_num',
    origin='SMF30MSR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OPS,
)
"""NUMBER OF SPECIFIC MSS MOUNTS

SMF Info
--------
    Field: `SMF30MSR`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF SPECIFIC MSS MOUNTS
"""
specific_mss_mounts_num.__doc__ = """NUMBER OF SPECIFIC MSS MOUNTS

SMF Info
--------
    Field: `SMF30MSR`
    Record: `SMF30S5`
    Map: `SMF30OPS`

NUMBER OF SPECIFIC MSS MOUNTS
"""

appc_rs_tp_convs : Final[Field] = Field(
    name='appc_rs_tp_convs',
    origin='SMF30DC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30DR,
)
"""Number of conversations associated with the transaction program (TP) ID, both currently active and deallocated.

SMF Info
--------
    Field: `SMF30DC`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of conversations associated with the transaction program (TP) ID, both currently active and deallocated.
"""
appc_rs_tp_convs.__doc__ = """Number of conversations associated with the transaction program (TP) ID, both currently active and deallocated.

SMF Info
--------
    Field: `SMF30DC`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of conversations associated with the transaction program (TP) ID, both currently active and deallocated.
"""

appc_rs_all_convs : Final[Field] = Field(
    name='appc_rs_all_convs',
    origin='SMF30DCA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30DR,
)
"""Number of all conversations allocated.

SMF Info
--------
    Field: `SMF30DCA`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of all conversations allocated.
"""
appc_rs_all_convs.__doc__ = """Number of all conversations allocated.

SMF Info
--------
    Field: `SMF30DCA`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of all conversations allocated.
"""

xprog_sends : Final[Field] = Field(
    name='xprog_sends',
    origin='SMF30DSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30DR,
)
"""Number of times the transaction program (TP) issued Send call. Note: Due to the possibilty of an interval or ste ending in the middle of a SEND call, this field may contain zer while SMF30DDS contains a non-zero value.

SMF Info
--------
    Field: `SMF30DSC`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of times the transaction program (TP) issued Send call. Note: Due to the possibilty of an interval or ste ending in the middle of a SEND call, this field may contain zer while SMF30DDS contains a non-zero value.
"""
xprog_sends.__doc__ = """Number of times the transaction program (TP) issued Send call. Note: Due to the possibilty of an interval or ste ending in the middle of a SEND call, this field may contain zer while SMF30DDS contains a non-zero value.

SMF Info
--------
    Field: `SMF30DSC`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of times the transaction program (TP) issued Send call. Note: Due to the possibilty of an interval or ste ending in the middle of a SEND call, this field may contain zer while SMF30DDS contains a non-zero value.
"""

amt_data_sent : Final[Field] = Field(
    name='amt_data_sent',
    origin='SMF30DDS',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF30DR,
)
"""Amount of data sent by the transaction program (TP).

SMF Info
--------
    Field: `SMF30DDS`
    Record: `SMF30S5`
    Map: `SMF30DR`

Amount of data sent by the transaction program (TP).
"""
amt_data_sent.__doc__ = """Amount of data sent by the transaction program (TP).

SMF Info
--------
    Field: `SMF30DDS`
    Record: `SMF30S5`
    Map: `SMF30DR`

Amount of data sent by the transaction program (TP).
"""

xprog_receives : Final[Field] = Field(
    name='xprog_receives',
    origin='SMF30DRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30DR,
)
"""Number of times the transaction program (TP) issued a Receive call. Note: Due to the possibilty of an interval or step ending in the middle of a RECEIVE call, this field may contain zero while SMF30DDR contains a non-zero value.

SMF Info
--------
    Field: `SMF30DRC`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of times the transaction program (TP) issued a Receive call. Note: Due to the possibilty of an interval or step ending in the middle of a RECEIVE call, this field may contain zero while SMF30DDR contains a non-zero value.
"""
xprog_receives.__doc__ = """Number of times the transaction program (TP) issued a Receive call. Note: Due to the possibilty of an interval or step ending in the middle of a RECEIVE call, this field may contain zero while SMF30DDR contains a non-zero value.

SMF Info
--------
    Field: `SMF30DRC`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of times the transaction program (TP) issued a Receive call. Note: Due to the possibilty of an interval or step ending in the middle of a RECEIVE call, this field may contain zero while SMF30DDR contains a non-zero value.
"""

amt_data_receive : Final[Field] = Field(
    name='amt_data_receive',
    origin='SMF30DDR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF30DR,
)
"""Amount of data received by the transaction program (TP).

SMF Info
--------
    Field: `SMF30DDR`
    Record: `SMF30S5`
    Map: `SMF30DR`

Amount of data received by the transaction program (TP).
"""
amt_data_receive.__doc__ = """Amount of data received by the transaction program (TP).

SMF Info
--------
    Field: `SMF30DDR`
    Record: `SMF30S5`
    Map: `SMF30DR`

Amount of data received by the transaction program (TP).
"""

active_convs_num : Final[Field] = Field(
    name='active_convs_num',
    origin='SMF30DAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30DR,
)
"""Number of active conversations.

SMF Info
--------
    Field: `SMF30DAC`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of active conversations.
"""
active_convs_num.__doc__ = """Number of active conversations.

SMF Info
--------
    Field: `SMF30DAC`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of active conversations.
"""

appc_sched_by_asch_num : Final[Field] = Field(
    name='appc_sched_by_asch_num',
    origin='SMF30DTR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30DR,
)
"""Number of APPC/MVS transactions programs scheduled by the APPC/MVS transaction scheduler (ASCH).

SMF Info
--------
    Field: `SMF30DTR`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of APPC/MVS transactions programs scheduled by the APPC/MVS transaction scheduler (ASCH).
"""
appc_sched_by_asch_num.__doc__ = """Number of APPC/MVS transactions programs scheduled by the APPC/MVS transaction scheduler (ASCH).

SMF Info
--------
    Field: `SMF30DTR`
    Record: `SMF30S5`
    Map: `SMF30DR`

Number of APPC/MVS transactions programs scheduled by the APPC/MVS transaction scheduler (ASCH).
"""

appc_crs_tp_convs : Final[Field] = Field(
    name='appc_crs_tp_convs',
    origin='SMF30CN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30AR,
)
"""TOTAL NUMBER CONVERSATIONS

SMF Info
--------
    Field: `SMF30CN`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL NUMBER CONVERSATIONS
"""
appc_crs_tp_convs.__doc__ = """TOTAL NUMBER CONVERSATIONS

SMF Info
--------
    Field: `SMF30CN`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL NUMBER CONVERSATIONS
"""

appc_crs_all_convs : Final[Field] = Field(
    name='appc_crs_all_convs',
    origin='SMF30CNA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30AR,
)
"""TOTAL CONVERSATIONS ALLOCATED

SMF Info
--------
    Field: `SMF30CNA`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL CONVERSATIONS ALLOCATED
"""
appc_crs_all_convs.__doc__ = """TOTAL CONVERSATIONS ALLOCATED

SMF Info
--------
    Field: `SMF30CNA`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL CONVERSATIONS ALLOCATED
"""

tot_tp_sends : Final[Field] = Field(
    name='tot_tp_sends',
    origin='SMF30SEN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30AR,
)
"""TOTAL SENDS ISSUED BY PGM

SMF Info
--------
    Field: `SMF30SEN`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL SENDS ISSUED BY PGM
"""
tot_tp_sends.__doc__ = """TOTAL SENDS ISSUED BY PGM

SMF Info
--------
    Field: `SMF30SEN`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL SENDS ISSUED BY PGM
"""

tot_data_sent_tp : Final[Field] = Field(
    name='tot_data_sent_tp',
    origin='SMF30DAT',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF30AR,
)
"""DATA SENT BY PROGRAM INSTANCE

SMF Info
--------
    Field: `SMF30DAT`
    Record: `SMF30S5`
    Map: `SMF30AR`

DATA SENT BY PROGRAM INSTANCE
"""
tot_data_sent_tp.__doc__ = """DATA SENT BY PROGRAM INSTANCE

SMF Info
--------
    Field: `SMF30DAT`
    Record: `SMF30S5`
    Map: `SMF30AR`

DATA SENT BY PROGRAM INSTANCE
"""

tot_tp_receives : Final[Field] = Field(
    name='tot_tp_receives',
    origin='SMF30REC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30AR,
)
"""TOTAL RECEIVES ISSUED BY PGM

SMF Info
--------
    Field: `SMF30REC`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL RECEIVES ISSUED BY PGM
"""
tot_tp_receives.__doc__ = """TOTAL RECEIVES ISSUED BY PGM

SMF Info
--------
    Field: `SMF30REC`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL RECEIVES ISSUED BY PGM
"""

tot_data_receive_tp : Final[Field] = Field(
    name='tot_data_receive_tp',
    origin='SMF30DAR',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF30AR,
)
"""TOTAL DATA RECEIVED BY PGM

SMF Info
--------
    Field: `SMF30DAR`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL DATA RECEIVED BY PGM
"""
tot_data_receive_tp.__doc__ = """TOTAL DATA RECEIVED BY PGM

SMF Info
--------
    Field: `SMF30DAR`
    Record: `SMF30S5`
    Map: `SMF30AR`

TOTAL DATA RECEIVED BY PGM
"""

tot_active_convs_num : Final[Field] = Field(
    name='tot_active_convs_num',
    origin='SMF30TAC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30AR,
)
"""Total Number of ACTIVE Conversations

SMF Info
--------
    Field: `SMF30TAC`
    Record: `SMF30S5`
    Map: `SMF30AR`

Total Number of ACTIVE Conversations
"""
tot_active_convs_num.__doc__ = """Total Number of ACTIVE Conversations

SMF Info
--------
    Field: `SMF30TAC`
    Record: `SMF30S5`
    Map: `SMF30AR`

Total Number of ACTIVE Conversations
"""

tot_appc_sched_by_asch_num : Final[Field] = Field(
    name='tot_appc_sched_by_asch_num',
    origin='SMF30ATR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30AR,
)
"""Number of Requests Processed by this TP

SMF Info
--------
    Field: `SMF30ATR`
    Record: `SMF30S5`
    Map: `SMF30AR`

Number of Requests Processed by this TP
"""
tot_appc_sched_by_asch_num.__doc__ = """Number of Requests Processed by this TP

SMF Info
--------
    Field: `SMF30ATR`
    Record: `SMF30S5`
    Map: `SMF30AR`

Number of Requests Processed by this TP
"""

instflgs1 : Final[Field] = Field(
    name='instflgs1',
    origin='SMF30_INSTFLGS1',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CDS,
)
"""Instruction counter related flags. If a bit in this byte is on in the subtype 2/3 record, it will be on in the subtype 4 record. Likewise between subtype 4 and subtype 5 records.

SMF Info
--------
    Field: `SMF30_INSTFLGS1`
    Record: `SMF30S5`
    Map: `SMF30CDS`

Instruction counter related flags. If a bit in this byte is on in the subtype 2/3 record, it will be on in the subtype 4 record. Likewise between subtype 4 and subtype 5 records.
"""
instflgs1.__doc__ = """Instruction counter related flags. If a bit in this byte is on in the subtype 2/3 record, it will be on in the subtype 4 record. Likewise between subtype 4 and subtype 5 records.

SMF Info
--------
    Field: `SMF30_INSTFLGS1`
    Record: `SMF30S5`
    Map: `SMF30CDS`

Instruction counter related flags. If a bit in this byte is on in the subtype 2/3 record, it will be on in the subtype 4 record. Likewise between subtype 4 and subtype 5 records.
"""

instcaptdisruption : Final[Field] = Field(
    name='instcaptdisruption',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=instflgs1,
    record=record,
    record_map=SMF30CDS,
)
"""There was a disruption in the collection of instruction counts or the counts could not be obtained(V)

SMF Info (Virtual Field)
--------
    Field: Based on `instflgs1`(`SMF30_INSTFLGS1`)
    Record: `SMF30S5`
    Map: `SMF30CDS`

There was a disruption in the collection of instruction counts or the counts could not be obtained

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
instcaptdisruption.__doc__ = """There was a disruption in the collection of instruction counts or the counts could not be obtained(V)

SMF Info (Virtual Field)
--------
    Field: Based on `instflgs1`(`SMF30_INSTFLGS1`)
    Record: `SMF30S5`
    Map: `SMF30CDS`

There was a disruption in the collection of instruction counts or the counts could not be obtained

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

instcaptlimited : Final[Field] = Field(
    name='instcaptlimited',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=instflgs1,
    record=record,
    record_map=SMF30CDS,
)
"""The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30_Inst_CP_Enclave SMF30_Inst_Offload_Enclave SMF30_Inst_OffloadOnCP_Enclave SMF30_Inst_CP_DepEnc SMF30_Inst_Offload_DepEnc SMF30_Inst_OffloadOnCP_DepEnc(V)

SMF Info (Virtual Field)
--------
    Field: Based on `instflgs1`(`SMF30_INSTFLGS1`)
    Record: `SMF30S5`
    Map: `SMF30CDS`

The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30_Inst_CP_Enclave SMF30_Inst_Offload_Enclave SMF30_Inst_OffloadOnCP_Enclave SMF30_Inst_CP_DepEnc SMF30_Inst_Offload_DepEnc SMF30_Inst_OffloadOnCP_DepEnc

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
instcaptlimited.__doc__ = """The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30_Inst_CP_Enclave SMF30_Inst_Offload_Enclave SMF30_Inst_OffloadOnCP_Enclave SMF30_Inst_CP_DepEnc SMF30_Inst_Offload_DepEnc SMF30_Inst_OffloadOnCP_DepEnc(V)

SMF Info (Virtual Field)
--------
    Field: Based on `instflgs1`(`SMF30_INSTFLGS1`)
    Record: `SMF30S5`
    Map: `SMF30CDS`

The following fields contain incomplete data: (SRM could not deliver deltas or values for this interval) SMF30_Inst_CP_Enclave SMF30_Inst_Offload_Enclave SMF30_Inst_OffloadOnCP_Enclave SMF30_Inst_CP_DepEnc SMF30_Inst_Offload_DepEnc SMF30_Inst_OffloadOnCP_DepEnc

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

inst_cp_task : Final[Field] = Field(
    name='inst_cp_task',
    origin='SMF30_INST_CP_TASK',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on a standard processor as a task when it is not eligible for an offload processor nor is it associated with an enclave.

SMF Info
--------
    Field: `SMF30_INST_CP_TASK`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as a task when it is not eligible for an offload processor nor is it associated with an enclave.
"""
inst_cp_task.__doc__ = """The number of instructions executed while running on a standard processor as a task when it is not eligible for an offload processor nor is it associated with an enclave.

SMF Info
--------
    Field: `SMF30_INST_CP_TASK`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as a task when it is not eligible for an offload processor nor is it associated with an enclave.
"""

inst_cp_nonpreemptsrb : Final[Field] = Field(
    name='inst_cp_nonpreemptsrb',
    origin='SMF30_INST_CP_NONPREEMPTSRB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on a standard processor as a non-preemptable SRB.

SMF Info
--------
    Field: `SMF30_INST_CP_NONPREEMPTSRB`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as a non-preemptable SRB.
"""
inst_cp_nonpreemptsrb.__doc__ = """The number of instructions executed while running on a standard processor as a non-preemptable SRB.

SMF Info
--------
    Field: `SMF30_INST_CP_NONPREEMPTSRB`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as a non-preemptable SRB.
"""

instr_cp_pre_srb : Final[Field] = Field(
    name='instr_cp_pre_srb',
    origin='SMF30_INST_CP_PREEMPTSRB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on a standard processor as a preemptable or client SRB when it is not associated with an enclave.

SMF Info
--------
    Field: `SMF30_INST_CP_PREEMPTSRB`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as a preemptable or client SRB when it is not associated with an enclave.
"""
instr_cp_pre_srb.__doc__ = """The number of instructions executed while running on a standard processor as a preemptable or client SRB when it is not associated with an enclave.

SMF Info
--------
    Field: `SMF30_INST_CP_PREEMPTSRB`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as a preemptable or client SRB when it is not associated with an enclave.
"""

inst_offload : Final[Field] = Field(
    name='inst_offload',
    origin='SMF30_INST_OFFLOAD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on an offload processor when not associated with an enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOAD`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on an offload processor when not associated with an enclave.
"""
inst_offload.__doc__ = """The number of instructions executed while running on an offload processor when not associated with an enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOAD`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on an offload processor when not associated with an enclave.
"""

inst_offload_on_cp : Final[Field] = Field(
    name='inst_offload_on_cp',
    origin='SMF30_INST_OFFLOADONCP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on a standard processor as eligible for an offload processor when not associated with an enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOADONCP`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as eligible for an offload processor when not associated with an enclave.
"""
inst_offload_on_cp.__doc__ = """The number of instructions executed while running on a standard processor as eligible for an offload processor when not associated with an enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOADONCP`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as eligible for an offload processor when not associated with an enclave.
"""

inst_cp_encl : Final[Field] = Field(
    name='inst_cp_encl',
    origin='SMF30_INST_CP_ENCLAVE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on a standard processor as not eligible for an offload processor for an independent enclave.

SMF Info
--------
    Field: `SMF30_INST_CP_ENCLAVE`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as not eligible for an offload processor for an independent enclave.
"""
inst_cp_encl.__doc__ = """The number of instructions executed while running on a standard processor as not eligible for an offload processor for an independent enclave.

SMF Info
--------
    Field: `SMF30_INST_CP_ENCLAVE`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as not eligible for an offload processor for an independent enclave.
"""

instr_offl_encl : Final[Field] = Field(
    name='instr_offl_encl',
    origin='SMF30_INST_OFFLOAD_ENCLAVE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on an offload processor for an independent enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOAD_ENCLAVE`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on an offload processor for an independent enclave.
"""
instr_offl_encl.__doc__ = """The number of instructions executed while running on an offload processor for an independent enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOAD_ENCLAVE`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on an offload processor for an independent enclave.
"""

instr_cp_el_encl : Final[Field] = Field(
    name='instr_cp_el_encl',
    origin='SMF30_INST_OFFLOADONCP_ENCLAVE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on a standard processor as eligible for an offload processor for an independent enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOADONCP_ENCLAVE`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as eligible for an offload processor for an independent enclave.
"""
instr_cp_el_encl.__doc__ = """The number of instructions executed while running on a standard processor as eligible for an offload processor for an independent enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOADONCP_ENCLAVE`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as eligible for an offload processor for an independent enclave.
"""

inst_cp_dep_enc : Final[Field] = Field(
    name='inst_cp_dep_enc',
    origin='SMF30_INST_CP_DEPENC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on a standard processor as not eligible for an offload processor for a dependent enclave.

SMF Info
--------
    Field: `SMF30_INST_CP_DEPENC`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as not eligible for an offload processor for a dependent enclave.
"""
inst_cp_dep_enc.__doc__ = """The number of instructions executed while running on a standard processor as not eligible for an offload processor for a dependent enclave.

SMF Info
--------
    Field: `SMF30_INST_CP_DEPENC`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as not eligible for an offload processor for a dependent enclave.
"""

inst_offload_dep_enc : Final[Field] = Field(
    name='inst_offload_dep_enc',
    origin='SMF30_INST_OFFLOAD_DEPENC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on an offload processor for a dependent enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOAD_DEPENC`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on an offload processor for a dependent enclave.
"""
inst_offload_dep_enc.__doc__ = """The number of instructions executed while running on an offload processor for a dependent enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOAD_DEPENC`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on an offload processor for a dependent enclave.
"""

instr_cp_dep_encl : Final[Field] = Field(
    name='instr_cp_dep_encl',
    origin='SMF30_INST_OFFLOADONCP_DEPENC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CDS,
)
"""The number of instructions executed while running on a standard processor as eligible for an offload processor for a dependent enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOADONCP_DEPENC`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as eligible for an offload processor for a dependent enclave.
"""
instr_cp_dep_encl.__doc__ = """The number of instructions executed while running on a standard processor as eligible for an offload processor for a dependent enclave.

SMF Info
--------
    Field: `SMF30_INST_OFFLOADONCP_DEPENC`
    Record: `SMF30S5`
    Map: `SMF30CDS`

The number of instructions executed while running on a standard processor as eligible for an offload processor for a dependent enclave.
"""

zedc_count : Final[Field] = Field(
    name='zedc_count',
    origin='SMF30_US_COMPRREQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30USS,
)
"""Total number of compression and decompression requests (both Supervisor and problem state requests)

SMF Info
--------
    Field: `SMF30_US_COMPRREQ`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number of compression and decompression requests (both Supervisor and problem state requests)
"""
zedc_count.__doc__ = """Total number of compression and decompression requests (both Supervisor and problem state requests)

SMF Info
--------
    Field: `SMF30_US_COMPRREQ`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number of compression and decompression requests (both Supervisor and problem state requests)
"""

zedc_prob_count : Final[Field] = Field(
    name='zedc_prob_count',
    origin='SMF30_US_COMPRREQ_PROB',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30USS,
)
"""Total number of problem state compression / decompression requests

SMF Info
--------
    Field: `SMF30_US_COMPRREQ_PROB`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number of problem state compression / decompression requests
"""
zedc_prob_count.__doc__ = """Total number of problem state compression / decompression requests

SMF Info
--------
    Field: `SMF30_US_COMPRREQ_PROB`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number of problem state compression / decompression requests
"""

zedc_q_time : Final[Field] = Field(
    name='zedc_q_time',
    origin='SMF30_US_QUEUETIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30USS,
)
"""Total queue time. The amount of time in microseconds from when the request was submitted until the adapter started executing the request.

SMF Info
--------
    Field: `SMF30_US_QUEUETIME`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total queue time. The amount of time in microseconds from when the request was submitted until the adapter started executing the request.
"""
zedc_q_time.__doc__ = """Total queue time. The amount of time in microseconds from when the request was submitted until the adapter started executing the request.

SMF Info
--------
    Field: `SMF30_US_QUEUETIME`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total queue time. The amount of time in microseconds from when the request was submitted until the adapter started executing the request.
"""

zedc_x_time : Final[Field] = Field(
    name='zedc_x_time',
    origin='SMF30_US_EXECTIME',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30USS,
)
"""Total execution time (in microseconds)

SMF Info
--------
    Field: `SMF30_US_EXECTIME`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total execution time (in microseconds)
"""
zedc_x_time.__doc__ = """Total execution time (in microseconds)

SMF Info
--------
    Field: `SMF30_US_EXECTIME`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total execution time (in microseconds)
"""

uncompr_in : Final[Field] = Field(
    name='uncompr_in',
    origin='SMF30_US_DEF_UNCOMPRIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30USS,
)
"""Total number (in bytes) of uncompressed data INPUT

SMF Info
--------
    Field: `SMF30_US_DEF_UNCOMPRIN`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number (in bytes) of uncompressed data INPUT
"""
uncompr_in.__doc__ = """Total number (in bytes) of uncompressed data INPUT

SMF Info
--------
    Field: `SMF30_US_DEF_UNCOMPRIN`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number (in bytes) of uncompressed data INPUT
"""

compress_out : Final[Field] = Field(
    name='compress_out',
    origin='SMF30_US_DEF_COMPROUT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30USS,
)
"""Total number (in bytes) of compressed data OUTPUT

SMF Info
--------
    Field: `SMF30_US_DEF_COMPROUT`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number (in bytes) of compressed data OUTPUT
"""
compress_out.__doc__ = """Total number (in bytes) of compressed data OUTPUT

SMF Info
--------
    Field: `SMF30_US_DEF_COMPROUT`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number (in bytes) of compressed data OUTPUT
"""

compress_in : Final[Field] = Field(
    name='compress_in',
    origin='SMF30_US_INF_COMPRIN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30USS,
)
"""Total number (in bytes) of compressed data INPUT

SMF Info
--------
    Field: `SMF30_US_INF_COMPRIN`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number (in bytes) of compressed data INPUT
"""
compress_in.__doc__ = """Total number (in bytes) of compressed data INPUT

SMF Info
--------
    Field: `SMF30_US_INF_COMPRIN`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number (in bytes) of compressed data INPUT
"""

decompr_out : Final[Field] = Field(
    name='decompr_out',
    origin='SMF30_US_INF_DECOMPROUT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30USS,
)
"""Total number (in bytes) of decompressed data OUTPUT

SMF Info
--------
    Field: `SMF30_US_INF_DECOMPROUT`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number (in bytes) of decompressed data OUTPUT
"""
decompr_out.__doc__ = """Total number (in bytes) of decompressed data OUTPUT

SMF Info
--------
    Field: `SMF30_US_INF_DECOMPROUT`
    Record: `SMF30S5`
    Map: `SMF30USS`

Total number (in bytes) of decompressed data OUTPUT
"""

container_id : Final[Field] = Field(
    name='container_id',
    origin='SMF30_CONTAINER_ID',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CONTAINER,
)
"""Container ID, padded with blanks if needed

SMF Info
--------
    Field: `SMF30_CONTAINER_ID`
    Record: `SMF30S5`
    Map: `SMF30CONTAINER`

Container ID, padded with blanks if needed
"""
container_id.__doc__ = """Container ID, padded with blanks if needed

SMF Info
--------
    Field: `SMF30_CONTAINER_ID`
    Record: `SMF30S5`
    Map: `SMF30CONTAINER`

Container ID, padded with blanks if needed
"""

container_qual : Final[Field] = Field(
    name='container_qual',
    origin='SMF30_CONTAINER_QUAL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CONTAINER,
)
"""Container Qualifier, padded with blanks if needed

SMF Info
--------
    Field: `SMF30_CONTAINER_QUAL`
    Record: `SMF30S5`
    Map: `SMF30CONTAINER`

Container Qualifier, padded with blanks if needed
"""
container_qual.__doc__ = """Container Qualifier, padded with blanks if needed

SMF Info
--------
    Field: `SMF30_CONTAINER_QUAL`
    Record: `SMF30S5`
    Map: `SMF30CONTAINER`

Container Qualifier, padded with blanks if needed
"""

pod_id : Final[Field] = Field(
    name='pod_id',
    origin='SMF30_POD_ID',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30CONTAINER,
)
"""Pod ID, padded with blanks if needed

SMF Info
--------
    Field: `SMF30_POD_ID`
    Record: `SMF30S5`
    Map: `SMF30CONTAINER`

Pod ID, padded with blanks if needed
"""
pod_id.__doc__ = """Pod ID, padded with blanks if needed

SMF Info
--------
    Field: `SMF30_POD_ID`
    Record: `SMF30S5`
    Map: `SMF30CONTAINER`

Pod ID, padded with blanks if needed
"""

device_class : Final[Field] = Field(
    name='device_class',
    origin='SMF30DEV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30EXP,
)
"""DEVICE CLASS

SMF Info
--------
    Field: `SMF30DEV`
    Record: `SMF30S5`
    Map: `SMF30EXP`

DEVICE CLASS
"""
device_class.__doc__ = """DEVICE CLASS

SMF Info
--------
    Field: `SMF30DEV`
    Record: `SMF30S5`
    Map: `SMF30EXP`

DEVICE CLASS
"""

unit_type : Final[Field] = Field(
    name='unit_type',
    origin='SMF30UTP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30EXP,
)
"""UNIT TYPE

SMF Info
--------
    Field: `SMF30UTP`
    Record: `SMF30S5`
    Map: `SMF30EXP`

UNIT TYPE
"""
unit_type.__doc__ = """UNIT TYPE

SMF Info
--------
    Field: `SMF30UTP`
    Record: `SMF30S5`
    Map: `SMF30EXP`

UNIT TYPE
"""

device_num : Final[Field] = Field(
    name='device_num',
    origin='SMF30CUA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30EXP,
)
"""Device number

SMF Info
--------
    Field: `SMF30CUA`
    Record: `SMF30S5`
    Map: `SMF30EXP`

Device number
"""
device_num.__doc__ = """Device number

SMF Info
--------
    Field: `SMF30CUA`
    Record: `SMF30S5`
    Map: `SMF30EXP`

Device number
"""

dd_name : Final[Field] = Field(
    name='dd_name',
    origin='SMF30DDN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30EXP,
)
"""DD NAME FOR THIS DATA SET

SMF Info
--------
    Field: `SMF30DDN`
    Record: `SMF30S5`
    Map: `SMF30EXP`

DD NAME FOR THIS DATA SET
"""
dd_name.__doc__ = """DD NAME FOR THIS DATA SET

SMF Info
--------
    Field: `SMF30DDN`
    Record: `SMF30S5`
    Map: `SMF30EXP`

DD NAME FOR THIS DATA SET
"""

block_count : Final[Field] = Field(
    name='block_count',
    origin='SMF30BLK',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30EXP,
)
"""NUMBER OF BLOCKS FOR THIS D.S.

SMF Info
--------
    Field: `SMF30BLK`
    Record: `SMF30S5`
    Map: `SMF30EXP`

NUMBER OF BLOCKS FOR THIS D.S.
"""
block_count.__doc__ = """NUMBER OF BLOCKS FOR THIS D.S.

SMF Info
--------
    Field: `SMF30BLK`
    Record: `SMF30S5`
    Map: `SMF30EXP`

NUMBER OF BLOCKS FOR THIS D.S.
"""

max_block_size : Final[Field] = Field(
    name='max_block_size',
    origin='SMF30BSZ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30EXP,
)
"""LARGEST BLOCKSIZE FOR THIS D.S.

SMF Info
--------
    Field: `SMF30BSZ`
    Record: `SMF30S5`
    Map: `SMF30EXP`

LARGEST BLOCKSIZE FOR THIS D.S.
"""
max_block_size.__doc__ = """LARGEST BLOCKSIZE FOR THIS D.S.

SMF Info
--------
    Field: `SMF30BSZ`
    Record: `SMF30S5`
    Map: `SMF30EXP`

LARGEST BLOCKSIZE FOR THIS D.S.
"""

cbs : Final[Field] = Field(
    name='cbs',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=max_block_size,
    record=record,
    record_map=SMF30EXP,
)
"""Changed blocksize for the data set. Post processors should use this field to avoid the possibility of negative numbers.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `max_block_size`(`SMF30BSZ`)
    Record: `SMF30S5`
    Map: `SMF30EXP`

Changed blocksize for the data set. Post processors should use this field to avoid the possibility of negative numbers.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cbs.__doc__ = """Changed blocksize for the data set. Post processors should use this field to avoid the possibility of negative numbers.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `max_block_size`(`SMF30BSZ`)
    Record: `SMF30S5`
    Map: `SMF30EXP`

Changed blocksize for the data set. Post processors should use this field to avoid the possibility of negative numbers.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

dev_conn_time : Final[Field] = Field(
    name='dev_conn_time',
    origin='SMF30DCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30EXP,
)
"""DEVICE CONNECT TIME

SMF Info
--------
    Field: `SMF30DCT`
    Record: `SMF30S5`
    Map: `SMF30EXP`

DEVICE CONNECT TIME
"""
dev_conn_time.__doc__ = """DEVICE CONNECT TIME

SMF Info
--------
    Field: `SMF30DCT`
    Record: `SMF30S5`
    Map: `SMF30EXP`

DEVICE CONNECT TIME
"""

block_size_val : Final[Field] = Field(
    name='block_size_val',
    origin='SMF30XBS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30EXP,
)
"""BLOCKSIZE > 32K

SMF Info
--------
    Field: `SMF30XBS`
    Record: `SMF30S5`
    Map: `SMF30EXP`

BLOCKSIZE > 32K
"""
block_size_val.__doc__ = """BLOCKSIZE > 32K

SMF Info
--------
    Field: `SMF30XBS`
    Record: `SMF30S5`
    Map: `SMF30EXP`

BLOCKSIZE > 32K
"""

acc_sec_len : Final[Field] = Field(
    name='acc_sec_len',
    origin='SMF30ACL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30ACS,
)
"""SUB FIELD LENGTH

SMF Info
--------
    Field: `SMF30ACL`
    Record: `SMF30S5`
    Map: `SMF30ACS`

SUB FIELD LENGTH
"""
acc_sec_len.__doc__ = """SUB FIELD LENGTH

SMF Info
--------
    Field: `SMF30ACL`
    Record: `SMF30S5`
    Map: `SMF30ACS`

SUB FIELD LENGTH
"""

acg : Final[Field] = Field(
    name='acg',
    origin='SMF30ACG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30ACS,
)
"""Job or step accounting field

SMF Info
--------
    Field: `SMF30ACG`
    Record: `SMF30S5`
    Map: `SMF30ACS`

Job or step accounting field
"""
acg.__doc__ = """Job or step accounting field

SMF Info
--------
    Field: `SMF30ACG`
    Record: `SMF30S5`
    Map: `SMF30ACS`

Job or step accounting field
"""

proc_id : Final[Field] = Field(
    name='proc_id',
    origin='SMF30OPI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Process ID

SMF Info
--------
    Field: `SMF30OPI`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process ID
"""
proc_id.__doc__ = """Process ID

SMF Info
--------
    Field: `SMF30OPI`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process ID
"""

proc_grp_id : Final[Field] = Field(
    name='proc_grp_id',
    origin='SMF30OPG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Process Group ID

SMF Info
--------
    Field: `SMF30OPG`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process Group ID
"""
proc_grp_id.__doc__ = """Process Group ID

SMF Info
--------
    Field: `SMF30OPG`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process Group ID
"""

ux_proc_usr : Final[Field] = Field(
    name='ux_proc_usr',
    origin='SMF30OUI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Process User ID

SMF Info
--------
    Field: `SMF30OUI`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process User ID
"""
ux_proc_usr.__doc__ = """Process User ID

SMF Info
--------
    Field: `SMF30OUI`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process User ID
"""

ux_proc_grp : Final[Field] = Field(
    name='ux_proc_grp',
    origin='SMF30OUG',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Process User Group ID

SMF Info
--------
    Field: `SMF30OUG`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process User Group ID
"""
ux_proc_grp.__doc__ = """Process User Group ID

SMF Info
--------
    Field: `SMF30OUG`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process User Group ID
"""

ux_proc_sess_id : Final[Field] = Field(
    name='ux_proc_sess_id',
    origin='SMF30OSI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Process Session ID

SMF Info
--------
    Field: `SMF30OSI`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process Session ID
"""
ux_proc_sess_id.__doc__ = """Process Session ID

SMF Info
--------
    Field: `SMF30OSI`
    Record: `SMF30S5`
    Map: `SMF30OP`

Process Session ID
"""

ux_svcs : Final[Field] = Field(
    name='ux_svcs',
    origin='SMF30OSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Total CPU time accumulated by OpenMVS syscalls requested by the process (in hundreths of a second)

SMF Info
--------
    Field: `SMF30OSC`
    Record: `SMF30S5`
    Map: `SMF30OP`

Total CPU time accumulated by OpenMVS syscalls requested by the process (in hundreths of a second)
"""
ux_svcs.__doc__ = """Total CPU time accumulated by OpenMVS syscalls requested by the process (in hundreths of a second)

SMF Info
--------
    Field: `SMF30OSC`
    Record: `SMF30S5`
    Map: `SMF30OP`

Total CPU time accumulated by OpenMVS syscalls requested by the process (in hundreths of a second)
"""

ux_svc_time : Final[Field] = Field(
    name='ux_svc_time',
    origin='SMF30OST',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of OpenMVS syscalls requested by the process

SMF Info
--------
    Field: `SMF30OST`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of OpenMVS syscalls requested by the process
"""
ux_svc_time.__doc__ = """Number of OpenMVS syscalls requested by the process

SMF Info
--------
    Field: `SMF30OST`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of OpenMVS syscalls requested by the process
"""

ux_dir_rds : Final[Field] = Field(
    name='ux_dir_rds',
    origin='SMF30ODR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of directory I/O blocks read for the process

SMF Info
--------
    Field: `SMF30ODR`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of directory I/O blocks read for the process
"""
ux_dir_rds.__doc__ = """Number of directory I/O blocks read for the process

SMF Info
--------
    Field: `SMF30ODR`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of directory I/O blocks read for the process
"""

ux_rd_io_blocks : Final[Field] = Field(
    name='ux_rd_io_blocks',
    origin='SMF30OFR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of I/O blocks read for Standard files for the process

SMF Info
--------
    Field: `SMF30OFR`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of I/O blocks read for Standard files for the process
"""
ux_rd_io_blocks.__doc__ = """Number of I/O blocks read for Standard files for the process

SMF Info
--------
    Field: `SMF30OFR`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of I/O blocks read for Standard files for the process
"""

ux_wr_io_blocks : Final[Field] = Field(
    name='ux_wr_io_blocks',
    origin='SMF30OFW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of I/O blocks written for Standard files for the process

SMF Info
--------
    Field: `SMF30OFW`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of I/O blocks written for Standard files for the process
"""
ux_wr_io_blocks.__doc__ = """Number of I/O blocks written for Standard files for the process

SMF Info
--------
    Field: `SMF30OFW`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of I/O blocks written for Standard files for the process
"""

ux_rd_io_blocks_oth : Final[Field] = Field(
    name='ux_rd_io_blocks_oth',
    origin='SMF30OPR',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of I/O blocks read for Pipe files for the process

SMF Info
--------
    Field: `SMF30OPR`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of I/O blocks read for Pipe files for the process
"""
ux_rd_io_blocks_oth.__doc__ = """Number of I/O blocks read for Pipe files for the process

SMF Info
--------
    Field: `SMF30OPR`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of I/O blocks read for Pipe files for the process
"""

ux_wr_io_blocks_oth : Final[Field] = Field(
    name='ux_wr_io_blocks_oth',
    origin='SMF30OPW',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of I/O blocks written for Pipe files for the process

SMF Info
--------
    Field: `SMF30OPW`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of I/O blocks written for Pipe files for the process
"""
ux_wr_io_blocks_oth.__doc__ = """Number of I/O blocks written for Pipe files for the process

SMF Info
--------
    Field: `SMF30OPW`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of I/O blocks written for Pipe files for the process
"""

pn_lookups_log : Final[Field] = Field(
    name='pn_lookups_log',
    origin='SMF30OLL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of path name Lookup calls to the logical file system

SMF Info
--------
    Field: `SMF30OLL`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of path name Lookup calls to the logical file system
"""
pn_lookups_log.__doc__ = """Number of path name Lookup calls to the logical file system

SMF Info
--------
    Field: `SMF30OLL`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of path name Lookup calls to the logical file system
"""

pn_lookups_fs : Final[Field] = Field(
    name='pn_lookups_fs',
    origin='SMF30OLP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of path name Lookup calls to the physical file system

SMF Info
--------
    Field: `SMF30OLP`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of path name Lookup calls to the physical file system
"""
pn_lookups_fs.__doc__ = """Number of path name Lookup calls to the physical file system

SMF Info
--------
    Field: `SMF30OLP`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of path name Lookup calls to the physical file system
"""

pn_gens_log : Final[Field] = Field(
    name='pn_gens_log',
    origin='SMF30OGL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of path name generation calls to the logical file system

SMF Info
--------
    Field: `SMF30OGL`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of path name generation calls to the logical file system
"""
pn_gens_log.__doc__ = """Number of path name generation calls to the logical file system

SMF Info
--------
    Field: `SMF30OGL`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of path name generation calls to the logical file system
"""

pn_gens_fs : Final[Field] = Field(
    name='pn_gens_fs',
    origin='SMF30OGP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of path name generation calls to the physical file system

SMF Info
--------
    Field: `SMF30OGP`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of path name generation calls to the physical file system
"""
pn_gens_fs.__doc__ = """Number of path name generation calls to the physical file system

SMF Info
--------
    Field: `SMF30OGP`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of path name generation calls to the physical file system
"""

parent_process_id : Final[Field] = Field(
    name='parent_process_id',
    origin='SMF30OPP',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""OpenMVS parent process ID number

SMF Info
--------
    Field: `SMF30OPP`
    Record: `SMF30S5`
    Map: `SMF30OP`

OpenMVS parent process ID number
"""
parent_process_id.__doc__ = """OpenMVS parent process ID number

SMF Info
--------
    Field: `SMF30OPP`
    Record: `SMF30S5`
    Map: `SMF30OP`

OpenMVS parent process ID number
"""

sync_call_num : Final[Field] = Field(
    name='sync_call_num',
    origin='SMF30OSY',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30OP,
)
"""Number of sync() function calls

SMF Info
--------
    Field: `SMF30OSY`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of sync() function calls
"""
sync_call_num.__doc__ = """Number of sync() function calls

SMF Info
--------
    Field: `SMF30OSY`
    Record: `SMF30S5`
    Map: `SMF30OP`

Number of sync() function calls
"""

re_name : Final[Field] = Field(
    name='re_name',
    origin='SMF30RNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30RM,
)
"""Element Name

SMF Info
--------
    Field: `SMF30RNM`
    Record: `SMF30S5`
    Map: `SMF30RM`

Element Name
"""
re_name.__doc__ = """Element Name

SMF Info
--------
    Field: `SMF30RNM`
    Record: `SMF30S5`
    Map: `SMF30RM`

Element Name
"""

re_type : Final[Field] = Field(
    name='re_type',
    origin='SMF30RTP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30RM,
)
"""Element Type

SMF Info
--------
    Field: `SMF30RTP`
    Record: `SMF30S5`
    Map: `SMF30RM`

Element Type
"""
re_type.__doc__ = """Element Type

SMF Info
--------
    Field: `SMF30RTP`
    Record: `SMF30S5`
    Map: `SMF30RM`

Element Type
"""

re_grp : Final[Field] = Field(
    name='re_grp',
    origin='SMF30RRG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30RM,
)
"""Restart Group for Element

SMF Info
--------
    Field: `SMF30RRG`
    Record: `SMF30S5`
    Map: `SMF30RM`

Restart Group for Element
"""
re_grp.__doc__ = """Restart Group for Element

SMF Info
--------
    Field: `SMF30RRG`
    Record: `SMF30S5`
    Map: `SMF30RM`

Restart Group for Element
"""

re_sys : Final[Field] = Field(
    name='re_sys',
    origin='SMF30RSN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30RM,
)
"""The system name for the system on which the element was initially started or blank for the initial start. The current system name is in the SMF30SYN field.

SMF Info
--------
    Field: `SMF30RSN`
    Record: `SMF30S5`
    Map: `SMF30RM`

The system name for the system on which the element was initially started or blank for the initial start. The current system name is in the SMF30SYN field.
"""
re_sys.__doc__ = """The system name for the system on which the element was initially started or blank for the initial start. The current system name is in the SMF30SYN field.

SMF Info
--------
    Field: `SMF30RSN`
    Record: `SMF30S5`
    Map: `SMF30RM`

The system name for the system on which the element was initially started or blank for the initial start. The current system name is in the SMF30SYN field.
"""

re_reg_time : Final[Field] = Field(
    name='re_reg_time',
    origin='SMF30RGT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30RM,
)
"""Time (local) Element requested REGISTER Function, in hundredths of a second

SMF Info
--------
    Field: `SMF30RGT`
    Record: `SMF30S5`
    Map: `SMF30RM`

Time (local) Element requested REGISTER Function, in hundredths of a second
"""
re_reg_time.__doc__ = """Time (local) Element requested REGISTER Function, in hundredths of a second

SMF Info
--------
    Field: `SMF30RGT`
    Record: `SMF30S5`
    Map: `SMF30RM`

Time (local) Element requested REGISTER Function, in hundredths of a second
"""

elem_register_date : Final[Field] = Field(
    name='elem_register_date',
    origin='SMF30RGD',
    type=FieldType.DATE,
    record=record,
    record_map=SMF30RM,
)
"""Date Element requested REGISTER Function, in the form 0cyydddF (where 'F' is the sign)

SMF Info
--------
    Field: `SMF30RGD`
    Record: `SMF30S5`
    Map: `SMF30RM`

Date Element requested REGISTER Function, in the form 0cyydddF (where 'F' is the sign)
"""
elem_register_date.__doc__ = """Date Element requested REGISTER Function, in the form 0cyydddF (where 'F' is the sign)

SMF Info
--------
    Field: `SMF30RGD`
    Record: `SMF30S5`
    Map: `SMF30RM`

Date Element requested REGISTER Function, in the form 0cyydddF (where 'F' is the sign)
"""

re_wait_time : Final[Field] = Field(
    name='re_wait_time',
    origin='SMF30RWT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30RM,
)
"""Time (local) Element requested WAITPRED function, in hundredths of a second Note that this is the time that the function was requested, not satisfied. 0, if the element has not requested the function.

SMF Info
--------
    Field: `SMF30RWT`
    Record: `SMF30S5`
    Map: `SMF30RM`

Time (local) Element requested WAITPRED function, in hundredths of a second Note that this is the time that the function was requested, not satisfied. 0, if the element has not requested the function.
"""
re_wait_time.__doc__ = """Time (local) Element requested WAITPRED function, in hundredths of a second Note that this is the time that the function was requested, not satisfied. 0, if the element has not requested the function.

SMF Info
--------
    Field: `SMF30RWT`
    Record: `SMF30S5`
    Map: `SMF30RM`

Time (local) Element requested WAITPRED function, in hundredths of a second Note that this is the time that the function was requested, not satisfied. 0, if the element has not requested the function.
"""

re_wait_date : Final[Field] = Field(
    name='re_wait_date',
    origin='SMF30RWD',
    type=FieldType.DATE,
    record=record,
    record_map=SMF30RM,
)
"""Date Element requested WAITPRED function, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element has not requested the function.

SMF Info
--------
    Field: `SMF30RWD`
    Record: `SMF30S5`
    Map: `SMF30RM`

Date Element requested WAITPRED function, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element has not requested the function.
"""
re_wait_date.__doc__ = """Date Element requested WAITPRED function, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element has not requested the function.

SMF Info
--------
    Field: `SMF30RWD`
    Record: `SMF30S5`
    Map: `SMF30RM`

Date Element requested WAITPRED function, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element has not requested the function.
"""

re_ready_time : Final[Field] = Field(
    name='re_ready_time',
    origin='SMF30RYT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30RM,
)
"""Time (local) Element was READY, in hundredths of a second 0, if the element is not yet READY

SMF Info
--------
    Field: `SMF30RYT`
    Record: `SMF30S5`
    Map: `SMF30RM`

Time (local) Element was READY, in hundredths of a second 0, if the element is not yet READY
"""
re_ready_time.__doc__ = """Time (local) Element was READY, in hundredths of a second 0, if the element is not yet READY

SMF Info
--------
    Field: `SMF30RYT`
    Record: `SMF30S5`
    Map: `SMF30RM`

Time (local) Element was READY, in hundredths of a second 0, if the element is not yet READY
"""

re_ready_date : Final[Field] = Field(
    name='re_ready_date',
    origin='SMF30RYD',
    type=FieldType.DATE,
    record=record,
    record_map=SMF30RM,
)
"""Date Element was READY, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element is not yet READY

SMF Info
--------
    Field: `SMF30RYD`
    Record: `SMF30S5`
    Map: `SMF30RM`

Date Element was READY, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element is not yet READY
"""
re_ready_date.__doc__ = """Date Element was READY, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element is not yet READY

SMF Info
--------
    Field: `SMF30RYD`
    Record: `SMF30S5`
    Map: `SMF30RM`

Date Element was READY, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element is not yet READY
"""

re_dereg_time : Final[Field] = Field(
    name='re_dereg_time',
    origin='SMF30RTT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30RM,
)
"""Time (local) Element was DEREGISTERED, in hundredths of a second 0, if the element is not yet DEREGISTERED or ended abnormally.

SMF Info
--------
    Field: `SMF30RTT`
    Record: `SMF30S5`
    Map: `SMF30RM`

Time (local) Element was DEREGISTERED, in hundredths of a second 0, if the element is not yet DEREGISTERED or ended abnormally.
"""
re_dereg_time.__doc__ = """Time (local) Element was DEREGISTERED, in hundredths of a second 0, if the element is not yet DEREGISTERED or ended abnormally.

SMF Info
--------
    Field: `SMF30RTT`
    Record: `SMF30S5`
    Map: `SMF30RM`

Time (local) Element was DEREGISTERED, in hundredths of a second 0, if the element is not yet DEREGISTERED or ended abnormally.
"""

re_dereg_date : Final[Field] = Field(
    name='re_dereg_date',
    origin='SMF30RTD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30RM,
)
"""Date Element was DEREGISTERED, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element is not yet DEREGISTERED or ended abnormally.

SMF Info
--------
    Field: `SMF30RTD`
    Record: `SMF30S5`
    Map: `SMF30RM`

Date Element was DEREGISTERED, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element is not yet DEREGISTERED or ended abnormally.
"""
re_dereg_date.__doc__ = """Date Element was DEREGISTERED, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element is not yet DEREGISTERED or ended abnormally.

SMF Info
--------
    Field: `SMF30RTD`
    Record: `SMF30S5`
    Map: `SMF30RM`

Date Element was DEREGISTERED, in the following format: 0cyydddF (where 'F' is the sign) 0, if the element is not yet DEREGISTERED or ended abnormally.
"""

prod_owner_name : Final[Field] = Field(
    name='prod_owner_name',
    origin='SMF30UPO',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30UD,
)
"""Product Owner or Vendor Name (obtained from PRODOWNER option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPO`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product Owner or Vendor Name (obtained from PRODOWNER option of IFAUSAGE macro)
"""
prod_owner_name.__doc__ = """Product Owner or Vendor Name (obtained from PRODOWNER option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPO`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product Owner or Vendor Name (obtained from PRODOWNER option of IFAUSAGE macro)
"""

prod_name : Final[Field] = Field(
    name='prod_name',
    origin='SMF30UPN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30UD,
)
"""Product Name (obtained from PRODNAME option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPN`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product Name (obtained from PRODNAME option of IFAUSAGE macro)
"""
prod_name.__doc__ = """Product Name (obtained from PRODNAME option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPN`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product Name (obtained from PRODNAME option of IFAUSAGE macro)
"""

prod_version : Final[Field] = Field(
    name='prod_version',
    origin='SMF30UPV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30UD,
)
"""Product Version (obtained from PRODVERS option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPV`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product Version (obtained from PRODVERS option of IFAUSAGE macro)
"""
prod_version.__doc__ = """Product Version (obtained from PRODVERS option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPV`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product Version (obtained from PRODVERS option of IFAUSAGE macro)
"""

prod_qualifier : Final[Field] = Field(
    name='prod_qualifier',
    origin='SMF30UPQ',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30UD,
)
"""Product Qualifer (obtained from PRODQUAL option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPQ`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product Qualifer (obtained from PRODQUAL option of IFAUSAGE macro)
"""
prod_qualifier.__doc__ = """Product Qualifer (obtained from PRODQUAL option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPQ`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product Qualifer (obtained from PRODQUAL option of IFAUSAGE macro)
"""

prod_id : Final[Field] = Field(
    name='prod_id',
    origin='SMF30UPI',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30UD,
)
"""Product ID Value (obtained from PRODID option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPI`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product ID Value (obtained from PRODID option of IFAUSAGE macro)
"""
prod_id.__doc__ = """Product ID Value (obtained from PRODID option of IFAUSAGE macro)

SMF Info
--------
    Field: `SMF30UPI`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product ID Value (obtained from PRODID option of IFAUSAGE macro)
"""

prod_tcb_time : Final[Field] = Field(
    name='prod_tcb_time',
    origin='SMF30UCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30UD,
)
"""Product CPU Time (.01 Seconds)

SMF Info
--------
    Field: `SMF30UCT`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product CPU Time (.01 Seconds)
"""
prod_tcb_time.__doc__ = """Product CPU Time (.01 Seconds)

SMF Info
--------
    Field: `SMF30UCT`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product CPU Time (.01 Seconds)
"""

prod_srb_time : Final[Field] = Field(
    name='prod_srb_time',
    origin='SMF30UCS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30UD,
)
"""Product SRB Time (.01 Seconds)

SMF Info
--------
    Field: `SMF30UCS`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product SRB Time (.01 Seconds)
"""
prod_srb_time.__doc__ = """Product SRB Time (.01 Seconds)

SMF Info
--------
    Field: `SMF30UCS`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product SRB Time (.01 Seconds)
"""

prod_res_data : Final[Field] = Field(
    name='prod_res_data',
    origin='SMF30URD',
    type=None,
    record=record,
    record_map=SMF30UD,
)
"""Product 'Specific' Resource Data

SMF Info
--------
    Field: `SMF30URD`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product 'Specific' Resource Data
"""
prod_res_data.__doc__ = """Product 'Specific' Resource Data

SMF Info
--------
    Field: `SMF30URD`
    Record: `SMF30S5`
    Map: `SMF30UD`

Product 'Specific' Resource Data
"""

prod_res_fmt : Final[Field] = Field(
    name='prod_res_fmt',
    origin='SMF30UDF',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30UD,
)
"""Data format of value in SMF30URD '0' - No Value '1' - CPU Time (STCK) '2' - Binary '3' - Long Floating Point

SMF Info
--------
    Field: `SMF30UDF`
    Record: `SMF30S5`
    Map: `SMF30UD`

Data format of value in SMF30URD '0' - No Value '1' - CPU Time (STCK) '2' - Binary '3' - Long Floating Point
"""
prod_res_fmt.__doc__ = """Data format of value in SMF30URD '0' - No Value '1' - CPU Time (STCK) '2' - Binary '3' - Long Floating Point

SMF Info
--------
    Field: `SMF30UDF`
    Record: `SMF30S5`
    Map: `SMF30UD`

Data format of value in SMF30URD '0' - No Value '1' - CPU Time (STCK) '2' - Binary '3' - Long Floating Point
"""

usage_entry_flg : Final[Field] = Field(
    name='usage_entry_flg',
    origin='SMF30UFG',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30UD,
)
"""Usage Entry Flags

SMF Info
--------
    Field: `SMF30UFG`
    Record: `SMF30S5`
    Map: `SMF30UD`

Usage Entry Flags
"""
usage_entry_flg.__doc__ = """Usage Entry Flags

SMF Info
--------
    Field: `SMF30UFG`
    Record: `SMF30S5`
    Map: `SMF30UD`

Usage Entry Flags
"""

unauth_register_requested : Final[Field] = Field(
    name='unauth_register_requested',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=usage_entry_flg,
    record=record,
    record_map=SMF30UD,
)
"""UNAUTHORIZED REGISTER Requested(V)

SMF Info (Virtual Field)
--------
    Field: Based on `usage_entry_flg`(`SMF30UFG`)
    Record: `SMF30S5`
    Map: `SMF30UD`

UNAUTHORIZED REGISTER Requested

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
unauth_register_requested.__doc__ = """UNAUTHORIZED REGISTER Requested(V)

SMF Info (Virtual Field)
--------
    Field: Based on `usage_entry_flg`(`SMF30UFG`)
    Record: `SMF30S5`
    Map: `SMF30UD`

UNAUTHORIZED REGISTER Requested

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

encl_sys : Final[Field] = Field(
    name='encl_sys',
    origin='SMF30MRS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF30MSE,
)
"""System name.

SMF Info
--------
    Field: `SMF30MRS`
    Record: `SMF30S5`
    Map: `SMF30MSE`

System name.
"""
encl_sys.__doc__ = """System name.

SMF Info
--------
    Field: `SMF30MRS`
    Record: `SMF30S5`
    Map: `SMF30MSE`

System name.
"""

cpu_rate_adj_fctr : Final[Field] = Field(
    name='cpu_rate_adj_fctr',
    origin='SMF30MRA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30MSE,
)
"""Adjustment factor for CPU rate. (Number of sixteenths of one CPU microsecond per CPU service unit)

SMF Info
--------
    Field: `SMF30MRA`
    Record: `SMF30S5`
    Map: `SMF30MSE`

Adjustment factor for CPU rate. (Number of sixteenths of one CPU microsecond per CPU service unit)
"""
cpu_rate_adj_fctr.__doc__ = """Adjustment factor for CPU rate. (Number of sixteenths of one CPU microsecond per CPU service unit)

SMF Info
--------
    Field: `SMF30MRA`
    Record: `SMF30S5`
    Map: `SMF30MSE`

Adjustment factor for CPU rate. (Number of sixteenths of one CPU microsecond per CPU service unit)
"""

cpu_dep_encl : Final[Field] = Field(
    name='cpu_dep_encl',
    origin='SMF30MRD',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30MSE,
)
"""CPU Time used by dependent enclaves that executed on named system (in hundredths of a second).

SMF Info
--------
    Field: `SMF30MRD`
    Record: `SMF30S5`
    Map: `SMF30MSE`

CPU Time used by dependent enclaves that executed on named system (in hundredths of a second).
"""
cpu_dep_encl.__doc__ = """CPU Time used by dependent enclaves that executed on named system (in hundredths of a second).

SMF Info
--------
    Field: `SMF30MRD`
    Record: `SMF30S5`
    Map: `SMF30MSE`

CPU Time used by dependent enclaves that executed on named system (in hundredths of a second).
"""

cpu_ind_encl : Final[Field] = Field(
    name='cpu_ind_encl',
    origin='SMF30MRI',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30MSE,
)
"""CPU Time used by independent enclaves that executed on named system (in hundredths of a second).

SMF Info
--------
    Field: `SMF30MRI`
    Record: `SMF30S5`
    Map: `SMF30MSE`

CPU Time used by independent enclaves that executed on named system (in hundredths of a second).
"""
cpu_ind_encl.__doc__ = """CPU Time used by independent enclaves that executed on named system (in hundredths of a second).

SMF Info
--------
    Field: `SMF30MRI`
    Record: `SMF30S5`
    Map: `SMF30MSE`

CPU Time used by independent enclaves that executed on named system (in hundredths of a second).
"""

crypctrs_entry_id : Final[Field] = Field(
    name='crypctrs_entry_id',
    origin='SMF30_CRYPCTRS_ENTRY_ID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CRYPC,
)
"""Crypto Counter entry identifier, The IFASMFCN macro contains equates and meanings for each entry ID. The equate names start with SMF_CrypCtrs.

SMF Info
--------
    Field: `SMF30_CRYPCTRS_ENTRY_ID`
    Record: `SMF30S5`
    Map: `SMF30CRYPC`

Crypto Counter entry identifier, The IFASMFCN macro contains equates and meanings for each entry ID. The equate names start with SMF_CrypCtrs.
"""
crypctrs_entry_id.__doc__ = """Crypto Counter entry identifier, The IFASMFCN macro contains equates and meanings for each entry ID. The equate names start with SMF_CrypCtrs.

SMF Info
--------
    Field: `SMF30_CRYPCTRS_ENTRY_ID`
    Record: `SMF30S5`
    Map: `SMF30CRYPC`

Crypto Counter entry identifier, The IFASMFCN macro contains equates and meanings for each entry ID. The equate names start with SMF_CrypCtrs.
"""

crypctrs_count : Final[Field] = Field(
    name='crypctrs_count',
    origin='SMF30_CRYPCTRS_COUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30CRYPC,
)
"""Crypto Counter value. This field contains the instruction counts used within the scope of the record, either for the current interval, job step, or job.

SMF Info
--------
    Field: `SMF30_CRYPCTRS_COUNT`
    Record: `SMF30S5`
    Map: `SMF30CRYPC`

Crypto Counter value. This field contains the instruction counts used within the scope of the record, either for the current interval, job step, or job.
"""
crypctrs_count.__doc__ = """Crypto Counter value. This field contains the instruction counts used within the scope of the record, either for the current interval, job step, or job.

SMF Info
--------
    Field: `SMF30_CRYPCTRS_COUNT`
    Record: `SMF30S5`
    Map: `SMF30CRYPC`

Crypto Counter value. This field contains the instruction counts used within the scope of the record, either for the current interval, job step, or job.
"""

nnpictrs_entry_id : Final[Field] = Field(
    name='nnpictrs_entry_id',
    origin='SMF30_NNPICTRS_ENTRY_ID',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30NNPIC,
)
"""NNPI counter entry identifier, The IFASMFCN macro contains equates and meanings for each entry ID. The equate names start with SMF_NNPICtrs.

SMF Info
--------
    Field: `SMF30_NNPICTRS_ENTRY_ID`
    Record: `SMF30S5`
    Map: `SMF30NNPIC`

NNPI counter entry identifier, The IFASMFCN macro contains equates and meanings for each entry ID. The equate names start with SMF_NNPICtrs.
"""
nnpictrs_entry_id.__doc__ = """NNPI counter entry identifier, The IFASMFCN macro contains equates and meanings for each entry ID. The equate names start with SMF_NNPICtrs.

SMF Info
--------
    Field: `SMF30_NNPICTRS_ENTRY_ID`
    Record: `SMF30S5`
    Map: `SMF30NNPIC`

NNPI counter entry identifier, The IFASMFCN macro contains equates and meanings for each entry ID. The equate names start with SMF_NNPICtrs.
"""

nnpictrs_count : Final[Field] = Field(
    name='nnpictrs_count',
    origin='SMF30_NNPICTRS_COUNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF30NNPIC,
)
"""NNPI Counter value. This field contains the instruction counts used within the scope of the record, either for the current interval, job step, or job.

SMF Info
--------
    Field: `SMF30_NNPICTRS_COUNT`
    Record: `SMF30S5`
    Map: `SMF30NNPIC`

NNPI Counter value. This field contains the instruction counts used within the scope of the record, either for the current interval, job step, or job.
"""
nnpictrs_count.__doc__ = """NNPI Counter value. This field contains the instruction counts used within the scope of the record, either for the current interval, job step, or job.

SMF Info
--------
    Field: `SMF30_NNPICTRS_COUNT`
    Record: `SMF30S5`
    Map: `SMF30NNPIC`

NNPI Counter value. This field contains the instruction counts used within the scope of the record, either for the current interval, job step, or job.
"""
