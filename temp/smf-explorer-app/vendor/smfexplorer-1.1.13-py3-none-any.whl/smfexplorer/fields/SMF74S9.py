# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 9"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=9,
                                spec='SMF 74 Subtype 9',
                                post=None)
"""SMF 74 Subtype 9"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R749PF: Final[RecordMap] = RecordMap(
    origin='R749PF',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='PCIE Function Data Section',
    post=None,
    record_mapping=False)
"""PCIE Function Data Section"""
R749DMA: Final[RecordMap] = RecordMap(
    origin='R749DMA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='PCIE Function Type Data Section',
    post=None,
    record_mapping=False)
"""PCIE Function Type Data Section"""
R749HWA: Final[RecordMap] = RecordMap(
    origin='R749HWA',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Hardware Accelerator Data Section',
    post=None,
    record_mapping=False)
"""Hardware Accelerator Data Section"""
R749HWA1: Final[RecordMap] = RecordMap(
    origin='R749HWA1',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Hardware Accelerator Compression Data Section',
    post=None,
    record_mapping=False)
"""Hardware Accelerator Compression Data Section"""
R749SYNC: Final[RecordMap] = RecordMap(
    origin='R749SYNC',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Sync I/O Link Data Section',
    post=None,
    record_mapping=False)
"""Sync I/O Link Data Section"""
R749SRTD: Final[RecordMap] = RecordMap(
    origin='R749SRTD',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Sync I/O Response Time Distribution Data Section',
    post=None,
    record_mapping=False)
"""Sync I/O Response Time Distribution Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S9`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S9`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S9`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S9`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S9`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S9`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S9`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S9`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S9`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S9`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S9`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S9`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S9`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S9`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S9`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S9`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S9`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S9`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S9`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S9`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S9`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S9`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S9`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S9`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S9`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S9`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S9`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S9`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S9`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S9`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S9`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S9`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S9`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

offset_pcie : Final[Field] = Field(
    name='offset_pcie',
    origin='SMF749PO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to PCIE function data sections

SMF Info
--------
    Field: `SMF749PO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to PCIE function data sections
"""
offset_pcie.__doc__ = """Offset to PCIE function data sections

SMF Info
--------
    Field: `SMF749PO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to PCIE function data sections
"""

length_pcie : Final[Field] = Field(
    name='length_pcie',
    origin='SMF749PL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of PCIE function data section

SMF Info
--------
    Field: `SMF749PL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of PCIE function data section
"""
length_pcie.__doc__ = """Length of PCIE function data section

SMF Info
--------
    Field: `SMF749PL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of PCIE function data section
"""

sections_pcie : Final[Field] = Field(
    name='sections_pcie',
    origin='SMF749PN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of PCIE function data sections

SMF Info
--------
    Field: `SMF749PN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of PCIE function data sections
"""
sections_pcie.__doc__ = """Number of PCIE function data sections

SMF Info
--------
    Field: `SMF749PN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of PCIE function data sections
"""

offset_function_pcie : Final[Field] = Field(
    name='offset_function_pcie',
    origin='SMF749DO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to PCIE function type data sections

SMF Info
--------
    Field: `SMF749DO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to PCIE function type data sections
"""
offset_function_pcie.__doc__ = """Offset to PCIE function type data sections

SMF Info
--------
    Field: `SMF749DO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to PCIE function type data sections
"""

length_function_pcie : Final[Field] = Field(
    name='length_function_pcie',
    origin='SMF749DL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of PCIE function type data section

SMF Info
--------
    Field: `SMF749DL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of PCIE function type data section
"""
length_function_pcie.__doc__ = """Length of PCIE function type data section

SMF Info
--------
    Field: `SMF749DL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of PCIE function type data section
"""

function_pcie : Final[Field] = Field(
    name='function_pcie',
    origin='SMF749DN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of PCIE function type data sections

SMF Info
--------
    Field: `SMF749DN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of PCIE function type data sections
"""
function_pcie.__doc__ = """Number of PCIE function type data sections

SMF Info
--------
    Field: `SMF749DN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of PCIE function type data sections
"""

offset_hw_accelerator : Final[Field] = Field(
    name='offset_hw_accelerator',
    origin='SMF749FO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to HW Accelerator data sections

SMF Info
--------
    Field: `SMF749FO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to HW Accelerator data sections
"""
offset_hw_accelerator.__doc__ = """Offset to HW Accelerator data sections

SMF Info
--------
    Field: `SMF749FO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to HW Accelerator data sections
"""

length_hw_accelerator : Final[Field] = Field(
    name='length_hw_accelerator',
    origin='SMF749FL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of HW Accelerator data section

SMF Info
--------
    Field: `SMF749FL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of HW Accelerator data section
"""
length_hw_accelerator.__doc__ = """Length of HW Accelerator data section

SMF Info
--------
    Field: `SMF749FL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of HW Accelerator data section
"""

sections_hw_accelerator : Final[Field] = Field(
    name='sections_hw_accelerator',
    origin='SMF749FN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of HW Accelerator data sections

SMF Info
--------
    Field: `SMF749FN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of HW Accelerator data sections
"""
sections_hw_accelerator.__doc__ = """Number of HW Accelerator data sections

SMF Info
--------
    Field: `SMF749FN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of HW Accelerator data sections
"""

offset_compression_hw_accelerator : Final[Field] = Field(
    name='offset_compression_hw_accelerator',
    origin='SMF7491O',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to HW Accelerator compression data sections

SMF Info
--------
    Field: `SMF7491O`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to HW Accelerator compression data sections
"""
offset_compression_hw_accelerator.__doc__ = """Offset to HW Accelerator compression data sections

SMF Info
--------
    Field: `SMF7491O`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to HW Accelerator compression data sections
"""

length_compression_hw_accelerator : Final[Field] = Field(
    name='length_compression_hw_accelerator',
    origin='SMF7491L',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of HW Accelerator compression data sections

SMF Info
--------
    Field: `SMF7491L`
    Record: `SMF74S9`
    Map: Not part of a map

Length of HW Accelerator compression data sections
"""
length_compression_hw_accelerator.__doc__ = """Length of HW Accelerator compression data sections

SMF Info
--------
    Field: `SMF7491L`
    Record: `SMF74S9`
    Map: Not part of a map

Length of HW Accelerator compression data sections
"""

sections_compression_hw_accelerator : Final[Field] = Field(
    name='sections_compression_hw_accelerator',
    origin='SMF7491N',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of HW Accelerator compression data sections

SMF Info
--------
    Field: `SMF7491N`
    Record: `SMF74S9`
    Map: Not part of a map

Number of HW Accelerator compression data sections
"""
sections_compression_hw_accelerator.__doc__ = """Number of HW Accelerator compression data sections

SMF Info
--------
    Field: `SMF7491N`
    Record: `SMF74S9`
    Map: Not part of a map

Number of HW Accelerator compression data sections
"""

offset_sync_io_link : Final[Field] = Field(
    name='offset_sync_io_link',
    origin='SMF749SO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Synchronous I/O Link data section

SMF Info
--------
    Field: `SMF749SO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to Synchronous I/O Link data section
"""
offset_sync_io_link.__doc__ = """Offset to Synchronous I/O Link data section

SMF Info
--------
    Field: `SMF749SO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to Synchronous I/O Link data section
"""

length_sync_io_link : Final[Field] = Field(
    name='length_sync_io_link',
    origin='SMF749SL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Synchronous I/O Link data section

SMF Info
--------
    Field: `SMF749SL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of Synchronous I/O Link data section
"""
length_sync_io_link.__doc__ = """Length of Synchronous I/O Link data section

SMF Info
--------
    Field: `SMF749SL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of Synchronous I/O Link data section
"""

sections_sync_io_link : Final[Field] = Field(
    name='sections_sync_io_link',
    origin='SMF749SN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Synchronous I/O Link data section

SMF Info
--------
    Field: `SMF749SN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of Synchronous I/O Link data section
"""
sections_sync_io_link.__doc__ = """Number of Synchronous I/O Link data section

SMF Info
--------
    Field: `SMF749SN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of Synchronous I/O Link data section
"""

offset_sync_io_rtd_link : Final[Field] = Field(
    name='offset_sync_io_rtd_link',
    origin='SMF749RO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to Synchronous I/O RTD data section

SMF Info
--------
    Field: `SMF749RO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to Synchronous I/O RTD data section
"""
offset_sync_io_rtd_link.__doc__ = """Offset to Synchronous I/O RTD data section

SMF Info
--------
    Field: `SMF749RO`
    Record: `SMF74S9`
    Map: Not part of a map

Offset to Synchronous I/O RTD data section
"""

length_sync_io_rtd_link : Final[Field] = Field(
    name='length_sync_io_rtd_link',
    origin='SMF749RL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of Synchronous I/O RTD data section

SMF Info
--------
    Field: `SMF749RL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of Synchronous I/O RTD data section
"""
length_sync_io_rtd_link.__doc__ = """Length of Synchronous I/O RTD data section

SMF Info
--------
    Field: `SMF749RL`
    Record: `SMF74S9`
    Map: Not part of a map

Length of Synchronous I/O RTD data section
"""

sections_sync_io_rtd_link : Final[Field] = Field(
    name='sections_sync_io_rtd_link',
    origin='SMF749RN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of Synchronous I/O RTD data sections

SMF Info
--------
    Field: `SMF749RN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of Synchronous I/O RTD data sections
"""
sections_sync_io_rtd_link.__doc__ = """Number of Synchronous I/O RTD data sections

SMF Info
--------
    Field: `SMF749RN`
    Record: `SMF74S9`
    Map: Not part of a map

Number of Synchronous I/O RTD data sections
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S9`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S9`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

lower_service_level : Final[Field] = Field(
    name='lower_service_level',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
lower_service_level.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

higher_service_level : Final[Field] = Field(
    name='higher_service_level',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
higher_service_level.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S9`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S9`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S9`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S9`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S9`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S9`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S9`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S9`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S9`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S9`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S9`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S9`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

pfid : Final[Field] = Field(
    name='pfid',
    origin='R749PFID',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""PCIE Function ID (PFID) for the PCIE function upon which performance data is returned.

SMF Info
--------
    Field: `R749PFID`
    Record: `SMF74S9`
    Map: `R749PF`

PCIE Function ID (PFID) for the PCIE function upon which performance data is returned.
"""
pfid.__doc__ = """PCIE Function ID (PFID) for the PCIE function upon which performance data is returned.

SMF Info
--------
    Field: `R749PFID`
    Record: `SMF74S9`
    Map: `R749PF`

PCIE Function ID (PFID) for the PCIE function upon which performance data is returned.
"""

pffl : Final[Field] = Field(
    name='pffl',
    origin='R749PFFL',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""PFID function status merged over all MINTIME intervals for this reporting interval.

SMF Info
--------
    Field: `R749PFFL`
    Record: `SMF74S9`
    Map: `R749PF`

PFID function status merged over all MINTIME intervals for this reporting interval.
"""
pffl.__doc__ = """PFID function status merged over all MINTIME intervals for this reporting interval.

SMF Info
--------
    Field: `R749PFFL`
    Record: `SMF74S9`
    Map: `R749PF`

PFID function status merged over all MINTIME intervals for this reporting interval.
"""

pfid_alloc : Final[Field] = Field(
    name='pfid_alloc',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pffl,
    record=record,
    record_map=R749PF,
)
"""PFID was allocated during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pffl`(`R749PFFL`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID was allocated during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
pfid_alloc.__doc__ = """PFID was allocated during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pffl`(`R749PFFL`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID was allocated during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

pfid_dealloc : Final[Field] = Field(
    name='pfid_dealloc',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pffl,
    record=record,
    record_map=R749PF,
)
"""PFID was deallocate-pending during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pffl`(`R749PFFL`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID was deallocate-pending during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
pfid_dealloc.__doc__ = """PFID was deallocate-pending during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pffl`(`R749PFFL`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID was deallocate-pending during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

pfid_err : Final[Field] = Field(
    name='pfid_err',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=pffl,
    record=record,
    record_map=R749PF,
)
"""PFID was in error during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pffl`(`R749PFFL`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID was in error during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
pfid_err.__doc__ = """PFID was in error during this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pffl`(`R749PFFL`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID was in error during this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

pff1 : Final[Field] = Field(
    name='pff1',
    origin='R749PFF1',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Final PFID function status at the end of this reporting interval.

SMF Info
--------
    Field: `R749PFF1`
    Record: `SMF74S9`
    Map: `R749PF`

Final PFID function status at the end of this reporting interval.
"""
pff1.__doc__ = """Final PFID function status at the end of this reporting interval.

SMF Info
--------
    Field: `R749PFF1`
    Record: `SMF74S9`
    Map: `R749PF`

Final PFID function status at the end of this reporting interval.
"""

pfid_dealloc_interval_end : Final[Field] = Field(
    name='pfid_dealloc_interval_end',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pff1,
    record=record,
    record_map=R749PF,
)
"""PFID is de-allocated at the end of this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pff1`(`R749PFF1`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID is de-allocated at the end of this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
pfid_dealloc_interval_end.__doc__ = """PFID is de-allocated at the end of this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pff1`(`R749PFF1`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID is de-allocated at the end of this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

pfid_realloc_interval_end : Final[Field] = Field(
    name='pfid_realloc_interval_end',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pff1,
    record=record,
    record_map=R749PF,
)
"""PFID is re-allocated at the end of this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pff1`(`R749PFF1`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID is re-allocated at the end of this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
pfid_realloc_interval_end.__doc__ = """PFID is re-allocated at the end of this interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pff1`(`R749PFF1`)
    Record: `SMF74S9`
    Map: `R749PF`

PFID is re-allocated at the end of this interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r749errt : Final[Field] = Field(
    name='r749errt',
    origin='R749ERRT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Amount of time in milliseconds for which no valid data was reported for the PCIE function within this reporting interval.

SMF Info
--------
    Field: `R749ERRT`
    Record: `SMF74S9`
    Map: `R749PF`

Amount of time in milliseconds for which no valid data was reported for the PCIE function within this reporting interval.
"""
r749errt.__doc__ = """Amount of time in milliseconds for which no valid data was reported for the PCIE function within this reporting interval.

SMF Info
--------
    Field: `R749ERRT`
    Record: `SMF74S9`
    Map: `R749PF`

Amount of time in milliseconds for which no valid data was reported for the PCIE function within this reporting interval.
"""

r749devt : Final[Field] = Field(
    name='r749devt',
    origin='R749DEVT',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Device type for the PCIE function.

SMF Info
--------
    Field: `R749DEVT`
    Record: `SMF74S9`
    Map: `R749PF`

Device type for the PCIE function.
"""
r749devt.__doc__ = """Device type for the PCIE function.

SMF Info
--------
    Field: `R749DEVT`
    Record: `SMF74S9`
    Map: `R749PF`

Device type for the PCIE function.
"""

r749devn : Final[Field] = Field(
    name='r749devn',
    origin='R749DEVN',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Device name for the PCIE function.

SMF Info
--------
    Field: `R749DEVN`
    Record: `SMF74S9`
    Map: `R749PF`

Device name for the PCIE function.
"""
r749devn.__doc__ = """Device name for the PCIE function.

SMF Info
--------
    Field: `R749DEVN`
    Record: `SMF74S9`
    Map: `R749PF`

Device name for the PCIE function.
"""

r749jobn : Final[Field] = Field(
    name='r749jobn',
    origin='R749JOBN',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Job name of owner who allocated the PCIE function.

SMF Info
--------
    Field: `R749JOBN`
    Record: `SMF74S9`
    Map: `R749PF`

Job name of owner who allocated the PCIE function.
"""
r749jobn.__doc__ = """Job name of owner who allocated the PCIE function.

SMF Info
--------
    Field: `R749JOBN`
    Record: `SMF74S9`
    Map: `R749PF`

Job name of owner who allocated the PCIE function.
"""

r749asid : Final[Field] = Field(
    name='r749asid',
    origin='R749ASID',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Address space ID of owner who allocated the PCIE function.

SMF Info
--------
    Field: `R749ASID`
    Record: `SMF74S9`
    Map: `R749PF`

Address space ID of owner who allocated the PCIE function.
"""
r749asid.__doc__ = """Address space ID of owner who allocated the PCIE function.

SMF Info
--------
    Field: `R749ASID`
    Record: `SMF74S9`
    Map: `R749PF`

Address space ID of owner who allocated the PCIE function.
"""

r749pcid : Final[Field] = Field(
    name='r749pcid',
    origin='R749PCID',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Physical or virtual channel identifier for the PCIE function.

SMF Info
--------
    Field: `R749PCID`
    Record: `SMF74S9`
    Map: `R749PF`

Physical or virtual channel identifier for the PCIE function.
"""
r749pcid.__doc__ = """Physical or virtual channel identifier for the PCIE function.

SMF Info
--------
    Field: `R749PCID`
    Record: `SMF74S9`
    Map: `R749PF`

Physical or virtual channel identifier for the PCIE function.
"""

r749atst : Final[Field] = Field(
    name='r749atst',
    origin='R749ATST',
    type=FieldType.DATETIME,
    record=record,
    record_map=R749PF,
)
"""Timestamp showing the last point in time when a PCIE function was allocated.

SMF Info
--------
    Field: `R749ATST`
    Record: `SMF74S9`
    Map: `R749PF`

Timestamp showing the last point in time when a PCIE function was allocated.
"""
r749atst.__doc__ = """Timestamp showing the last point in time when a PCIE function was allocated.

SMF Info
--------
    Field: `R749ATST`
    Record: `SMF74S9`
    Map: `R749PF`

Timestamp showing the last point in time when a PCIE function was allocated.
"""

r749allt : Final[Field] = Field(
    name='r749allt',
    origin='R749ALLT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Amount of time in milliseconds for which the PCIE function was allocated or de-allocate pending.

SMF Info
--------
    Field: `R749ALLT`
    Record: `SMF74S9`
    Map: `R749PF`

Amount of time in milliseconds for which the PCIE function was allocated or de-allocate pending.
"""
r749allt.__doc__ = """Amount of time in milliseconds for which the PCIE function was allocated or de-allocate pending.

SMF Info
--------
    Field: `R749ALLT`
    Record: `SMF74S9`
    Map: `R749PF`

Amount of time in milliseconds for which the PCIE function was allocated or de-allocate pending.
"""

r749scnt : Final[Field] = Field(
    name='r749scnt',
    origin='R749SCNT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Sequence number for the last time the PCI counters have been updated by the firmware

SMF Info
--------
    Field: `R749SCNT`
    Record: `SMF74S9`
    Map: `R749PF`

Sequence number for the last time the PCI counters have been updated by the firmware
"""
r749scnt.__doc__ = """Sequence number for the last time the PCI counters have been updated by the firmware

SMF Info
--------
    Field: `R749SCNT`
    Record: `SMF74S9`
    Map: `R749PF`

Sequence number for the last time the PCI counters have been updated by the firmware
"""

r749loop : Final[Field] = Field(
    name='r749loop',
    origin='R749LOOP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Count of PCI Load operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.

SMF Info
--------
    Field: `R749LOOP`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCI Load operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.
"""
r749loop.__doc__ = """Count of PCI Load operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.

SMF Info
--------
    Field: `R749LOOP`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCI Load operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.
"""

r749stop : Final[Field] = Field(
    name='r749stop',
    origin='R749STOP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Count of PCI Store operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.

SMF Info
--------
    Field: `R749STOP`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCI Store operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.
"""
r749stop.__doc__ = """Count of PCI Store operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.

SMF Info
--------
    Field: `R749STOP`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCI Store operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.
"""

r749sbop : Final[Field] = Field(
    name='r749sbop',
    origin='R749SBOP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Count of PCI Store Block operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.

SMF Info
--------
    Field: `R749SBOP`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCI Store Block operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.
"""
r749sbop.__doc__ = """Count of PCI Store Block operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.

SMF Info
--------
    Field: `R749SBOP`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCI Store Block operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.
"""

r749rfop : Final[Field] = Field(
    name='r749rfop',
    origin='R749RFOP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Count of PCI Refresh translation operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.

SMF Info
--------
    Field: `R749RFOP`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCI Refresh translation operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.
"""
r749rfop.__doc__ = """Count of PCI Refresh translation operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.

SMF Info
--------
    Field: `R749RFOP`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCI Refresh translation operations for the PCIE function. Only valid, if bit 2 of R749FLAG is not set.
"""

r749dmao : Final[Field] = Field(
    name='r749dmao',
    origin='R749DMAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""The PCIE Function Type data blocks for the PCIE functions are grouped together in the record. To get to the PCIE Function Type data block associated with this PCIE function data section, skip over the number of Function Type data blocks specified by this field, starting at the first PCIE Function Type data block in the record.

SMF Info
--------
    Field: `R749DMAO`
    Record: `SMF74S9`
    Map: `R749PF`

The PCIE Function Type data blocks for the PCIE functions are grouped together in the record. To get to the PCIE Function Type data block associated with this PCIE function data section, skip over the number of Function Type data blocks specified by this field, starting at the first PCIE Function Type data block in the record.
"""
r749dmao.__doc__ = """The PCIE Function Type data blocks for the PCIE functions are grouped together in the record. To get to the PCIE Function Type data block associated with this PCIE function data section, skip over the number of Function Type data blocks specified by this field, starting at the first PCIE Function Type data block in the record.

SMF Info
--------
    Field: `R749DMAO`
    Record: `SMF74S9`
    Map: `R749PF`

The PCIE Function Type data blocks for the PCIE functions are grouped together in the record. To get to the PCIE Function Type data block associated with this PCIE function data section, skip over the number of Function Type data blocks specified by this field, starting at the first PCIE Function Type data block in the record.
"""

r749dman : Final[Field] = Field(
    name='r749dman',
    origin='R749DMAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Count of PCIE Function Type data blocks allocated for this PCIE function data section.

SMF Info
--------
    Field: `R749DMAN`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCIE Function Type data blocks allocated for this PCIE function data section.
"""
r749dman.__doc__ = """Count of PCIE Function Type data blocks allocated for this PCIE function data section.

SMF Info
--------
    Field: `R749DMAN`
    Record: `SMF74S9`
    Map: `R749PF`

Count of PCIE Function Type data blocks allocated for this PCIE function data section.
"""

r749fpfo : Final[Field] = Field(
    name='r749fpfo',
    origin='R749FPFO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""The data blocks for all HW Accelerators are grouped together in the record. To get to the HW Accelerator data block associated with this PCIE function data section, skip over the number of HW Accelerator data blocks specified by this field, starting at the first HW Accelerator data block in the record.

SMF Info
--------
    Field: `R749FPFO`
    Record: `SMF74S9`
    Map: `R749PF`

The data blocks for all HW Accelerators are grouped together in the record. To get to the HW Accelerator data block associated with this PCIE function data section, skip over the number of HW Accelerator data blocks specified by this field, starting at the first HW Accelerator data block in the record.
"""
r749fpfo.__doc__ = """The data blocks for all HW Accelerators are grouped together in the record. To get to the HW Accelerator data block associated with this PCIE function data section, skip over the number of HW Accelerator data blocks specified by this field, starting at the first HW Accelerator data block in the record.

SMF Info
--------
    Field: `R749FPFO`
    Record: `SMF74S9`
    Map: `R749PF`

The data blocks for all HW Accelerators are grouped together in the record. To get to the HW Accelerator data block associated with this PCIE function data section, skip over the number of HW Accelerator data blocks specified by this field, starting at the first HW Accelerator data block in the record.
"""

r749fpfn : Final[Field] = Field(
    name='r749fpfn',
    origin='R749FPFN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Count of HW Accelerator data blocks allocated for this PCIE function data section.

SMF Info
--------
    Field: `R749FPFN`
    Record: `SMF74S9`
    Map: `R749PF`

Count of HW Accelerator data blocks allocated for this PCIE function data section.
"""
r749fpfn.__doc__ = """Count of HW Accelerator data blocks allocated for this PCIE function data section.

SMF Info
--------
    Field: `R749FPFN`
    Record: `SMF74S9`
    Map: `R749PF`

Count of HW Accelerator data blocks allocated for this PCIE function data section.
"""

r749fp1o : Final[Field] = Field(
    name='r749fp1o',
    origin='R749FP1O',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""The data blocks for all HW Accelerators used for compression acceleration are grouped together in the record. To get to the HW Accelerator compression data block associated with this PCIE function data section, skip over the number of compression data blocks specified by this field, starting at the first HW Accelerator compression data block in the record.

SMF Info
--------
    Field: `R749FP1O`
    Record: `SMF74S9`
    Map: `R749PF`

The data blocks for all HW Accelerators used for compression acceleration are grouped together in the record. To get to the HW Accelerator compression data block associated with this PCIE function data section, skip over the number of compression data blocks specified by this field, starting at the first HW Accelerator compression data block in the record.
"""
r749fp1o.__doc__ = """The data blocks for all HW Accelerators used for compression acceleration are grouped together in the record. To get to the HW Accelerator compression data block associated with this PCIE function data section, skip over the number of compression data blocks specified by this field, starting at the first HW Accelerator compression data block in the record.

SMF Info
--------
    Field: `R749FP1O`
    Record: `SMF74S9`
    Map: `R749PF`

The data blocks for all HW Accelerators used for compression acceleration are grouped together in the record. To get to the HW Accelerator compression data block associated with this PCIE function data section, skip over the number of compression data blocks specified by this field, starting at the first HW Accelerator compression data block in the record.
"""

r749fp1n : Final[Field] = Field(
    name='r749fp1n',
    origin='R749FP1N',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Count of HW Accelerator compression data blocks allocated for this PCIE function data section.

SMF Info
--------
    Field: `R749FP1N`
    Record: `SMF74S9`
    Map: `R749PF`

Count of HW Accelerator compression data blocks allocated for this PCIE function data section.
"""
r749fp1n.__doc__ = """Count of HW Accelerator compression data blocks allocated for this PCIE function data section.

SMF Info
--------
    Field: `R749FP1N`
    Record: `SMF74S9`
    Map: `R749PF`

Count of HW Accelerator compression data blocks allocated for this PCIE function data section.
"""

r749flag : Final[Field] = Field(
    name='r749flag',
    origin='R749FLAG',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Validity flag

SMF Info
--------
    Field: `R749FLAG`
    Record: `SMF74S9`
    Map: `R749PF`

Validity flag
"""
r749flag.__doc__ = """Validity flag

SMF Info
--------
    Field: `R749FLAG`
    Record: `SMF74S9`
    Map: `R749PF`

Validity flag
"""

physical_network : Final[Field] = Field(
    name='physical_network',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r749flag,
    record=record,
    record_map=R749PF,
)
"""Physical-network identifiers R749NET1 and R749NET2 are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749flag`(`R749FLAG`)
    Record: `SMF74S9`
    Map: `R749PF`

Physical-network identifiers R749NET1 and R749NET2 are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
physical_network.__doc__ = """Physical-network identifiers R749NET1 and R749NET2 are valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749flag`(`R749FLAG`)
    Record: `SMF74S9`
    Map: `R749PF`

Physical-network identifiers R749NET1 and R749NET2 are valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

pcie_valid : Final[Field] = Field(
    name='pcie_valid',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r749flag,
    record=record,
    record_map=R749PF,
)
"""PCIE function type R749PFT is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749flag`(`R749FLAG`)
    Record: `SMF74S9`
    Map: `R749PF`

PCIE function type R749PFT is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
pcie_valid.__doc__ = """PCIE function type R749PFT is valid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749flag`(`R749FLAG`)
    Record: `SMF74S9`
    Map: `R749PF`

PCIE function type R749PFT is valid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

pci_oper_rates_invalid : Final[Field] = Field(
    name='pci_oper_rates_invalid',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r749flag,
    record=record,
    record_map=R749PF,
)
"""PCI operation rates are invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749flag`(`R749FLAG`)
    Record: `SMF74S9`
    Map: `R749PF`

PCI operation rates are invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
pci_oper_rates_invalid.__doc__ = """PCI operation rates are invalid(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749flag`(`R749FLAG`)
    Record: `SMF74S9`
    Map: `R749PF`

PCI operation rates are invalid

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

global_performance : Final[Field] = Field(
    name='global_performance',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r749flag,
    record=record,
    record_map=R749PF,
)
"""Global Performance Reporting is enabled(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749flag`(`R749FLAG`)
    Record: `SMF74S9`
    Map: `R749PF`

Global Performance Reporting is enabled

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
global_performance.__doc__ = """Global Performance Reporting is enabled(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749flag`(`R749FLAG`)
    Record: `SMF74S9`
    Map: `R749PF`

Global Performance Reporting is enabled

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r749port : Final[Field] = Field(
    name='r749port',
    origin='R749PORT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Physical port number for which this PCIE function is associated. If zero, then either the port field is not applicable, or there is more than one port associated with the PCIE function.

SMF Info
--------
    Field: `R749PORT`
    Record: `SMF74S9`
    Map: `R749PF`

Physical port number for which this PCIE function is associated. If zero, then either the port field is not applicable, or there is more than one port associated with the PCIE function.
"""
r749port.__doc__ = """Physical port number for which this PCIE function is associated. If zero, then either the port field is not applicable, or there is more than one port associated with the PCIE function.

SMF Info
--------
    Field: `R749PORT`
    Record: `SMF74S9`
    Map: `R749PF`

Physical port number for which this PCIE function is associated. If zero, then either the port field is not applicable, or there is more than one port associated with the PCIE function.
"""

r749pft : Final[Field] = Field(
    name='r749pft',
    origin='R749PFT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""PCIE function type

SMF Info
--------
    Field: `R749PFT`
    Record: `SMF74S9`
    Map: `R749PF`

PCIE function type
"""
r749pft.__doc__ = """PCIE function type

SMF Info
--------
    Field: `R749PFT`
    Record: `SMF74S9`
    Map: `R749PF`

PCIE function type
"""

r749net1 : Final[Field] = Field(
    name='r749net1',
    origin='R749NET1',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Physical-network identifier (PNET ID) that identifies the first port of the adapter. This field is only valid when the PCIE device type is defined as RoCE Express or ISM.

SMF Info
--------
    Field: `R749NET1`
    Record: `SMF74S9`
    Map: `R749PF`

Physical-network identifier (PNET ID) that identifies the first port of the adapter. This field is only valid when the PCIE device type is defined as RoCE Express or ISM.
"""
r749net1.__doc__ = """Physical-network identifier (PNET ID) that identifies the first port of the adapter. This field is only valid when the PCIE device type is defined as RoCE Express or ISM.

SMF Info
--------
    Field: `R749NET1`
    Record: `SMF74S9`
    Map: `R749PF`

Physical-network identifier (PNET ID) that identifies the first port of the adapter. This field is only valid when the PCIE device type is defined as RoCE Express or ISM.
"""

r749net2 : Final[Field] = Field(
    name='r749net2',
    origin='R749NET2',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Physical-network identifier (PNET ID) that identifies the second port of the adapter. Only valid when the PCIE device type is defined as RoCE Express

SMF Info
--------
    Field: `R749NET2`
    Record: `SMF74S9`
    Map: `R749PF`

Physical-network identifier (PNET ID) that identifies the second port of the adapter. Only valid when the PCIE device type is defined as RoCE Express
"""
r749net2.__doc__ = """Physical-network identifier (PNET ID) that identifies the second port of the adapter. Only valid when the PCIE device type is defined as RoCE Express

SMF Info
--------
    Field: `R749NET2`
    Record: `SMF74S9`
    Map: `R749PF`

Physical-network identifier (PNET ID) that identifies the second port of the adapter. Only valid when the PCIE device type is defined as RoCE Express
"""

r749wwnn : Final[Field] = Field(
    name='r749wwnn',
    origin='R749WWNN',
    type=FieldType.STRING,
    record=record,
    record_map=R749PF,
)
"""Worldwide node name (WWNN) of the storage controller the synchronous I/O link is connected to.

SMF Info
--------
    Field: `R749WWNN`
    Record: `SMF74S9`
    Map: `R749PF`

Worldwide node name (WWNN) of the storage controller the synchronous I/O link is connected to.
"""
r749wwnn.__doc__ = """Worldwide node name (WWNN) of the storage controller the synchronous I/O link is connected to.

SMF Info
--------
    Field: `R749WWNN`
    Record: `SMF74S9`
    Map: `R749PF`

Worldwide node name (WWNN) of the storage controller the synchronous I/O link is connected to.
"""

r749sioo : Final[Field] = Field(
    name='r749sioo',
    origin='R749SIOO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""The data blocks for all Synchronous I/O links are grouped together in the record. To get the Synchronous I/O link data block associated with this PCIE Function data section, skip over the number of data blocks specified by this field, starting at the first Synchronous I/O link data block in the record.

SMF Info
--------
    Field: `R749SIOO`
    Record: `SMF74S9`
    Map: `R749PF`

The data blocks for all Synchronous I/O links are grouped together in the record. To get the Synchronous I/O link data block associated with this PCIE Function data section, skip over the number of data blocks specified by this field, starting at the first Synchronous I/O link data block in the record.
"""
r749sioo.__doc__ = """The data blocks for all Synchronous I/O links are grouped together in the record. To get the Synchronous I/O link data block associated with this PCIE Function data section, skip over the number of data blocks specified by this field, starting at the first Synchronous I/O link data block in the record.

SMF Info
--------
    Field: `R749SIOO`
    Record: `SMF74S9`
    Map: `R749PF`

The data blocks for all Synchronous I/O links are grouped together in the record. To get the Synchronous I/O link data block associated with this PCIE Function data section, skip over the number of data blocks specified by this field, starting at the first Synchronous I/O link data block in the record.
"""

r749sion : Final[Field] = Field(
    name='r749sion',
    origin='R749SION',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Count of Synchronous I/O link data blocks allocated for this PCIE Function data section

SMF Info
--------
    Field: `R749SION`
    Record: `SMF74S9`
    Map: `R749PF`

Count of Synchronous I/O link data blocks allocated for this PCIE Function data section
"""
r749sion.__doc__ = """Count of Synchronous I/O link data blocks allocated for this PCIE Function data section

SMF Info
--------
    Field: `R749SION`
    Record: `SMF74S9`
    Map: `R749PF`

Count of Synchronous I/O link data blocks allocated for this PCIE Function data section
"""

r749rtdo : Final[Field] = Field(
    name='r749rtdo',
    origin='R749RTDO',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""The data blocks for all Synchronous I/O response time distribution buckets are grouped together in the record. To get the first Synchronous I/O response time distribution data block associated with this PCIE Function data section, skip over the number of data blocks specified by this field, starting at the first Synchronous I/O response time distribution data block in the record.

SMF Info
--------
    Field: `R749RTDO`
    Record: `SMF74S9`
    Map: `R749PF`

The data blocks for all Synchronous I/O response time distribution buckets are grouped together in the record. To get the first Synchronous I/O response time distribution data block associated with this PCIE Function data section, skip over the number of data blocks specified by this field, starting at the first Synchronous I/O response time distribution data block in the record.
"""
r749rtdo.__doc__ = """The data blocks for all Synchronous I/O response time distribution buckets are grouped together in the record. To get the first Synchronous I/O response time distribution data block associated with this PCIE Function data section, skip over the number of data blocks specified by this field, starting at the first Synchronous I/O response time distribution data block in the record.

SMF Info
--------
    Field: `R749RTDO`
    Record: `SMF74S9`
    Map: `R749PF`

The data blocks for all Synchronous I/O response time distribution buckets are grouped together in the record. To get the first Synchronous I/O response time distribution data block associated with this PCIE Function data section, skip over the number of data blocks specified by this field, starting at the first Synchronous I/O response time distribution data block in the record.
"""

r749rtdn : Final[Field] = Field(
    name='r749rtdn',
    origin='R749RTDN',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Count of Synchronous I/O response time distribution data blocks allocated for this PCIE Function data section.

SMF Info
--------
    Field: `R749RTDN`
    Record: `SMF74S9`
    Map: `R749PF`

Count of Synchronous I/O response time distribution data blocks allocated for this PCIE Function data section.
"""
r749rtdn.__doc__ = """Count of Synchronous I/O response time distribution data blocks allocated for this PCIE Function data section.

SMF Info
--------
    Field: `R749RTDN`
    Record: `SMF74S9`
    Map: `R749PF`

Count of Synchronous I/O response time distribution data blocks allocated for this PCIE Function data section.
"""

r749lkid : Final[Field] = Field(
    name='r749lkid',
    origin='R749LKID',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749PF,
)
"""Synchronous I/O link identifier of the control unit interface

SMF Info
--------
    Field: `R749LKID`
    Record: `SMF74S9`
    Map: `R749PF`

Synchronous I/O link identifier of the control unit interface
"""
r749lkid.__doc__ = """Synchronous I/O link identifier of the control unit interface

SMF Info
--------
    Field: `R749LKID`
    Record: `SMF74S9`
    Map: `R749PF`

Synchronous I/O link identifier of the control unit interface
"""

r749srbf : Final[Field] = Field(
    name='r749srbf',
    origin='R749SRBF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of bytes read by this synchronous I/O function. Valid for PCIE function type = x'04'.

SMF Info
--------
    Field: `R749SRBF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes read by this synchronous I/O function. Valid for PCIE function type = x'04'.
"""
r749srbf.__doc__ = """Number of bytes read by this synchronous I/O function. Valid for PCIE function type = x'04'.

SMF Info
--------
    Field: `R749SRBF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes read by this synchronous I/O function. Valid for PCIE function type = x'04'.
"""

r749swbf : Final[Field] = Field(
    name='r749swbf',
    origin='R749SWBF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of bytes written by this synchronous I/O function. Valid for PCIE function type = x'04'.

SMF Info
--------
    Field: `R749SWBF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes written by this synchronous I/O function. Valid for PCIE function type = x'04'.
"""
r749swbf.__doc__ = """Number of bytes written by this synchronous I/O function. Valid for PCIE function type = x'04'.

SMF Info
--------
    Field: `R749SWBF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes written by this synchronous I/O function. Valid for PCIE function type = x'04'.
"""

r749dfmt : Final[Field] = Field(
    name='r749dfmt',
    origin='R749DFMT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Format of PCIE Function Type data

SMF Info
--------
    Field: `R749DFMT`
    Record: `SMF74S9`
    Map: `R749DMA`

Format of PCIE Function Type data
"""
r749dfmt.__doc__ = """Format of PCIE Function Type data

SMF Info
--------
    Field: `R749DFMT`
    Record: `SMF74S9`
    Map: `R749DMA`

Format of PCIE Function Type data
"""

r749ssrf : Final[Field] = Field(
    name='r749ssrf',
    origin='R749SSRF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of successful requests for this synchronous I/O function. Valid for PCIE function type = x'04'.

SMF Info
--------
    Field: `R749SSRF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of successful requests for this synchronous I/O function. Valid for PCIE function type = x'04'.
"""
r749ssrf.__doc__ = """Number of successful requests for this synchronous I/O function. Valid for PCIE function type = x'04'.

SMF Info
--------
    Field: `R749SSRF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of successful requests for this synchronous I/O function. Valid for PCIE function type = x'04'.
"""

r749slrf : Final[Field] = Field(
    name='r749slrf',
    origin='R749SLRF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of times the command was rejected by the processor (local rejects) for this synchronous I/O function. Valid for PCIE function type = x'04'.

SMF Info
--------
    Field: `R749SLRF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of times the command was rejected by the processor (local rejects) for this synchronous I/O function. Valid for PCIE function type = x'04'.
"""
r749slrf.__doc__ = """Number of times the command was rejected by the processor (local rejects) for this synchronous I/O function. Valid for PCIE function type = x'04'.

SMF Info
--------
    Field: `R749SLRF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of times the command was rejected by the processor (local rejects) for this synchronous I/O function. Valid for PCIE function type = x'04'.
"""

r749srrf : Final[Field] = Field(
    name='r749srrf',
    origin='R749SRRF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of times the command was rejected by the storage controller (remote rejects)for this synchronous I/O function.

SMF Info
--------
    Field: `R749SRRF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of times the command was rejected by the storage controller (remote rejects)for this synchronous I/O function.
"""
r749srrf.__doc__ = """Number of times the command was rejected by the storage controller (remote rejects)for this synchronous I/O function.

SMF Info
--------
    Field: `R749SRRF`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of times the command was rejected by the storage controller (remote rejects)for this synchronous I/O function.
"""

r749stpf : Final[Field] = Field(
    name='r749stpf',
    origin='R749STPF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Total processing time in micro seconds for this synchronous I/O function.

SMF Info
--------
    Field: `R749STPF`
    Record: `SMF74S9`
    Map: `R749DMA`

Total processing time in micro seconds for this synchronous I/O function.
"""
r749stpf.__doc__ = """Total processing time in micro seconds for this synchronous I/O function.

SMF Info
--------
    Field: `R749STPF`
    Record: `SMF74S9`
    Map: `R749DMA`

Total processing time in micro seconds for this synchronous I/O function.
"""

r749srbc : Final[Field] = Field(
    name='r749srbc',
    origin='R749SRBC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of bytes read by all syn chronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749SRBC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes read by all syn chronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.
"""
r749srbc.__doc__ = """Number of bytes read by all syn chronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749SRBC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes read by all syn chronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.
"""

r749swbc : Final[Field] = Field(
    name='r749swbc',
    origin='R749SWBC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of bytes written by all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid,if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749SWBC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes written by all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid,if bit 2 of R749FLAG is set.
"""
r749swbc.__doc__ = """Number of bytes written by all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid,if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749SWBC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes written by all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid,if bit 2 of R749FLAG is set.
"""

r749ssrc : Final[Field] = Field(
    name='r749ssrc',
    origin='R749SSRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of requests successfully processed by all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749SSRC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of requests successfully processed by all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.
"""
r749ssrc.__doc__ = """Number of requests successfully processed by all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749SSRC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of requests successfully processed by all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.
"""

r749slrc : Final[Field] = Field(
    name='r749slrc',
    origin='R749SLRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of local rejects of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set

SMF Info
--------
    Field: `R749SLRC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of local rejects of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set
"""
r749slrc.__doc__ = """Number of local rejects of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set

SMF Info
--------
    Field: `R749SLRC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of local rejects of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set
"""

r749srrc : Final[Field] = Field(
    name='r749srrc',
    origin='R749SRRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of remote rejects of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749SRRC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of remote rejects of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.
"""
r749srrc.__doc__ = """Number of remote rejects of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749SRRC`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of remote rejects of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.
"""

r749stpc : Final[Field] = Field(
    name='r749stpc',
    origin='R749STPC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Total processing time in micro seconds of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749STPC`
    Record: `SMF74S9`
    Map: `R749DMA`

Total processing time in micro seconds of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.
"""
r749stpc.__doc__ = """Total processing time in micro seconds of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.

SMF Info
--------
    Field: `R749STPC`
    Record: `SMF74S9`
    Map: `R749DMA`

Total processing time in micro seconds of all synchronous I/O functions that are using this synchronous I/O link on this CEC. Only valid, if bit 2 of R749FLAG is set.
"""

r749dmar : Final[Field] = Field(
    name='r749dmar',
    origin='R749DMAR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""DMA read counter that reports the number of bytes transferred from all defined DMA address spaces to the PCIE function. Valid for PCIE function type = x'00'.

SMF Info
--------
    Field: `R749DMAR`
    Record: `SMF74S9`
    Map: `R749DMA`

DMA read counter that reports the number of bytes transferred from all defined DMA address spaces to the PCIE function. Valid for PCIE function type = x'00'.
"""
r749dmar.__doc__ = """DMA read counter that reports the number of bytes transferred from all defined DMA address spaces to the PCIE function. Valid for PCIE function type = x'00'.

SMF Info
--------
    Field: `R749DMAR`
    Record: `SMF74S9`
    Map: `R749DMA`

DMA read counter that reports the number of bytes transferred from all defined DMA address spaces to the PCIE function. Valid for PCIE function type = x'00'.
"""

r749dmaw : Final[Field] = Field(
    name='r749dmaw',
    origin='R749DMAW',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""DMA write counter that reports the number of bytes transferred from the PCIE function to all defined DMA address spaces. Valid for PCIE function type = x'00'.

SMF Info
--------
    Field: `R749DMAW`
    Record: `SMF74S9`
    Map: `R749DMA`

DMA write counter that reports the number of bytes transferred from the PCIE function to all defined DMA address spaces. Valid for PCIE function type = x'00'.
"""
r749dmaw.__doc__ = """DMA write counter that reports the number of bytes transferred from the PCIE function to all defined DMA address spaces. Valid for PCIE function type = x'00'.

SMF Info
--------
    Field: `R749DMAW`
    Record: `SMF74S9`
    Map: `R749DMA`

DMA write counter that reports the number of bytes transferred from the PCIE function to all defined DMA address spaces. Valid for PCIE function type = x'00'.
"""

r749dbyr : Final[Field] = Field(
    name='r749dbyr',
    origin='R749DBYR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of bytes received on the external Ethernet interface. Valid for PCIE function type = x'01'.

SMF Info
--------
    Field: `R749DBYR`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes received on the external Ethernet interface. Valid for PCIE function type = x'01'.
"""
r749dbyr.__doc__ = """Number of bytes received on the external Ethernet interface. Valid for PCIE function type = x'01'.

SMF Info
--------
    Field: `R749DBYR`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes received on the external Ethernet interface. Valid for PCIE function type = x'01'.
"""

r749dbyt : Final[Field] = Field(
    name='r749dbyt',
    origin='R749DBYT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of bytes transmitted on the external Ethernet interface. Valid for PCIE function type = x'01'.

SMF Info
--------
    Field: `R749DBYT`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes transmitted on the external Ethernet interface. Valid for PCIE function type = x'01'.
"""
r749dbyt.__doc__ = """Number of bytes transmitted on the external Ethernet interface. Valid for PCIE function type = x'01'.

SMF Info
--------
    Field: `R749DBYT`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes transmitted on the external Ethernet interface. Valid for PCIE function type = x'01'.
"""

r749dpkr : Final[Field] = Field(
    name='r749dpkr',
    origin='R749DPKR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of packets received on the external Ethernet interface. Valid for PCIE function type = x'01'.

SMF Info
--------
    Field: `R749DPKR`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of packets received on the external Ethernet interface. Valid for PCIE function type = x'01'.
"""
r749dpkr.__doc__ = """Number of packets received on the external Ethernet interface. Valid for PCIE function type = x'01'.

SMF Info
--------
    Field: `R749DPKR`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of packets received on the external Ethernet interface. Valid for PCIE function type = x'01'.
"""

r749dpkt : Final[Field] = Field(
    name='r749dpkt',
    origin='R749DPKT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of packets transmitted on the external Ethernet interface. Valid for PCIE function type = x'01'.

SMF Info
--------
    Field: `R749DPKT`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of packets transmitted on the external Ethernet interface. Valid for PCIE function type = x'01'.
"""
r749dpkt.__doc__ = """Number of packets transmitted on the external Ethernet interface. Valid for PCIE function type = x'01'.

SMF Info
--------
    Field: `R749DPKT`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of packets transmitted on the external Ethernet interface. Valid for PCIE function type = x'01'.
"""

r749dwup : Final[Field] = Field(
    name='r749dwup',
    origin='R749DWUP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of work units processed by the PCI function. Valid for PCIE function type = x'02'.

SMF Info
--------
    Field: `R749DWUP`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of work units processed by the PCI function. Valid for PCIE function type = x'02'.
"""
r749dwup.__doc__ = """Number of work units processed by the PCI function. Valid for PCIE function type = x'02'.

SMF Info
--------
    Field: `R749DWUP`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of work units processed by the PCI function. Valid for PCIE function type = x'02'.
"""

r749dwum : Final[Field] = Field(
    name='r749dwum',
    origin='R749DWUM',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Maximum number of work units that the PCI function is capable of processing per second. Valid for PCIE function type = x'02'.

SMF Info
--------
    Field: `R749DWUM`
    Record: `SMF74S9`
    Map: `R749DMA`

Maximum number of work units that the PCI function is capable of processing per second. Valid for PCIE function type = x'02'.
"""
r749dwum.__doc__ = """Maximum number of work units that the PCI function is capable of processing per second. Valid for PCIE function type = x'02'.

SMF Info
--------
    Field: `R749DWUM`
    Record: `SMF74S9`
    Map: `R749DMA`

Maximum number of work units that the PCI function is capable of processing per second. Valid for PCIE function type = x'02'.
"""

r749dbyx : Final[Field] = Field(
    name='r749dbyx',
    origin='R749DBYX',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749DMA,
)
"""Number of bytes transmitted by the PCI function. Valid for PCIE function type = x'03'.

SMF Info
--------
    Field: `R749DBYX`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes transmitted by the PCI function. Valid for PCIE function type = x'03'.
"""
r749dbyx.__doc__ = """Number of bytes transmitted by the PCI function. Valid for PCIE function type = x'03'.

SMF Info
--------
    Field: `R749DBYX`
    Record: `SMF74S9`
    Map: `R749DMA`

Number of bytes transmitted by the PCI function. Valid for PCIE function type = x'03'.
"""

r749ftyp : Final[Field] = Field(
    name='r749ftyp',
    origin='R749FTYP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""HW Accelerator application type

SMF Info
--------
    Field: `R749FTYP`
    Record: `SMF74S9`
    Map: `R749HWA`

HW Accelerator application type
"""
r749ftyp.__doc__ = """HW Accelerator application type

SMF Info
--------
    Field: `R749FTYP`
    Record: `SMF74S9`
    Map: `R749HWA`

HW Accelerator application type
"""

r749fdsc : Final[Field] = Field(
    name='r749fdsc',
    origin='R749FDSC',
    type=FieldType.STRING,
    record=record,
    record_map=R749HWA,
)
"""HW Accelerator application description

SMF Info
--------
    Field: `R749FDSC`
    Record: `SMF74S9`
    Map: `R749HWA`

HW Accelerator application description
"""
r749fdsc.__doc__ = """HW Accelerator application description

SMF Info
--------
    Field: `R749FDSC`
    Record: `SMF74S9`
    Map: `R749HWA`

HW Accelerator application description
"""

r749frqc : Final[Field] = Field(
    name='r749frqc',
    origin='R749FRQC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""Total number of HW Accelerator requests that completed successfully.

SMF Info
--------
    Field: `R749FRQC`
    Record: `SMF74S9`
    Map: `R749HWA`

Total number of HW Accelerator requests that completed successfully.
"""
r749frqc.__doc__ = """Total number of HW Accelerator requests that completed successfully.

SMF Info
--------
    Field: `R749FRQC`
    Record: `SMF74S9`
    Map: `R749HWA`

Total number of HW Accelerator requests that completed successfully.
"""

r749frqe : Final[Field] = Field(
    name='r749frqe',
    origin='R749FRQE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""Total number of HW Accelerator requests that completed with an error. Statistics for these requests are not included in the other fields of this data section.

SMF Info
--------
    Field: `R749FRQE`
    Record: `SMF74S9`
    Map: `R749HWA`

Total number of HW Accelerator requests that completed with an error. Statistics for these requests are not included in the other fields of this data section.
"""
r749frqe.__doc__ = """Total number of HW Accelerator requests that completed with an error. Statistics for these requests are not included in the other fields of this data section.

SMF Info
--------
    Field: `R749FRQE`
    Record: `SMF74S9`
    Map: `R749HWA`

Total number of HW Accelerator requests that completed with an error. Statistics for these requests are not included in the other fields of this data section.
"""

r749fqfl : Final[Field] = Field(
    name='r749fqfl',
    origin='R749FQFL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""Number of times that the adapter queue was full when a new request was submitted.

SMF Info
--------
    Field: `R749FQFL`
    Record: `SMF74S9`
    Map: `R749HWA`

Number of times that the adapter queue was full when a new request was submitted.
"""
r749fqfl.__doc__ = """Number of times that the adapter queue was full when a new request was submitted.

SMF Info
--------
    Field: `R749FQFL`
    Record: `SMF74S9`
    Map: `R749HWA`

Number of times that the adapter queue was full when a new request was submitted.
"""

r749ftet : Final[Field] = Field(
    name='r749ftet',
    origin='R749FTET',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""Total execution time of all requests in microseconds.

SMF Info
--------
    Field: `R749FTET`
    Record: `SMF74S9`
    Map: `R749HWA`

Total execution time of all requests in microseconds.
"""
r749ftet.__doc__ = """Total execution time of all requests in microseconds.

SMF Info
--------
    Field: `R749FTET`
    Record: `SMF74S9`
    Map: `R749HWA`

Total execution time of all requests in microseconds.
"""

r749fsqe : Final[Field] = Field(
    name='r749fsqe',
    origin='R749FSQE',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""Sum of the squares of the individual execution times.

SMF Info
--------
    Field: `R749FSQE`
    Record: `SMF74S9`
    Map: `R749HWA`

Sum of the squares of the individual execution times.
"""
r749fsqe.__doc__ = """Sum of the squares of the individual execution times.

SMF Info
--------
    Field: `R749FSQE`
    Record: `SMF74S9`
    Map: `R749HWA`

Sum of the squares of the individual execution times.
"""

r749ftqt : Final[Field] = Field(
    name='r749ftqt',
    origin='R749FTQT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""Total queue time of all requests in microseconds.

SMF Info
--------
    Field: `R749FTQT`
    Record: `SMF74S9`
    Map: `R749HWA`

Total queue time of all requests in microseconds.
"""
r749ftqt.__doc__ = """Total queue time of all requests in microseconds.

SMF Info
--------
    Field: `R749FTQT`
    Record: `SMF74S9`
    Map: `R749HWA`

Total queue time of all requests in microseconds.
"""

r749fsqq : Final[Field] = Field(
    name='r749fsqq',
    origin='R749FSQQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""Sum of the squares of the individual queue times.

SMF Info
--------
    Field: `R749FSQQ`
    Record: `SMF74S9`
    Map: `R749HWA`

Sum of the squares of the individual queue times.
"""
r749fsqq.__doc__ = """Sum of the squares of the individual queue times.

SMF Info
--------
    Field: `R749FSQQ`
    Record: `SMF74S9`
    Map: `R749HWA`

Sum of the squares of the individual queue times.
"""

r749fdrd : Final[Field] = Field(
    name='r749fdrd',
    origin='R749FDRD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""Total DMA reads in units of 256 bytes.

SMF Info
--------
    Field: `R749FDRD`
    Record: `SMF74S9`
    Map: `R749HWA`

Total DMA reads in units of 256 bytes.
"""
r749fdrd.__doc__ = """Total DMA reads in units of 256 bytes.

SMF Info
--------
    Field: `R749FDRD`
    Record: `SMF74S9`
    Map: `R749HWA`

Total DMA reads in units of 256 bytes.
"""

r749fdwr : Final[Field] = Field(
    name='r749fdwr',
    origin='R749FDWR',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA,
)
"""Total DMA writes in units of 256 bytes.

SMF Info
--------
    Field: `R749FDWR`
    Record: `SMF74S9`
    Map: `R749HWA`

Total DMA writes in units of 256 bytes.
"""
r749fdwr.__doc__ = """Total DMA writes in units of 256 bytes.

SMF Info
--------
    Field: `R749FDWR`
    Record: `SMF74S9`
    Map: `R749HWA`

Total DMA writes in units of 256 bytes.
"""

r7491dib : Final[Field] = Field(
    name='r7491dib',
    origin='R7491DIB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Total number of deflate input bytes.

SMF Info
--------
    Field: `R7491DIB`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of deflate input bytes.
"""
r7491dib.__doc__ = """Total number of deflate input bytes.

SMF Info
--------
    Field: `R7491DIB`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of deflate input bytes.
"""

r7491dis : Final[Field] = Field(
    name='r7491dis',
    origin='R7491DIS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Sum of the squares of the individual deflate input bytes.

SMF Info
--------
    Field: `R7491DIS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Sum of the squares of the individual deflate input bytes.
"""
r7491dis.__doc__ = """Sum of the squares of the individual deflate input bytes.

SMF Info
--------
    Field: `R7491DIS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Sum of the squares of the individual deflate input bytes.
"""

r7491dob : Final[Field] = Field(
    name='r7491dob',
    origin='R7491DOB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Total number of deflate output bytes.

SMF Info
--------
    Field: `R7491DOB`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of deflate output bytes.
"""
r7491dob.__doc__ = """Total number of deflate output bytes.

SMF Info
--------
    Field: `R7491DOB`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of deflate output bytes.
"""

r7491dos : Final[Field] = Field(
    name='r7491dos',
    origin='R7491DOS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Sum of the squares of the individual deflate output bytes.

SMF Info
--------
    Field: `R7491DOS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Sum of the squares of the individual deflate output bytes.
"""
r7491dos.__doc__ = """Sum of the squares of the individual deflate output bytes.

SMF Info
--------
    Field: `R7491DOS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Sum of the squares of the individual deflate output bytes.
"""

r7491dct : Final[Field] = Field(
    name='r7491dct',
    origin='R7491DCT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Total number of deflate requests.

SMF Info
--------
    Field: `R7491DCT`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of deflate requests.
"""
r7491dct.__doc__ = """Total number of deflate requests.

SMF Info
--------
    Field: `R7491DCT`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of deflate requests.
"""

r7491iib : Final[Field] = Field(
    name='r7491iib',
    origin='R7491IIB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Total number of inflate input bytes.

SMF Info
--------
    Field: `R7491IIB`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of inflate input bytes.
"""
r7491iib.__doc__ = """Total number of inflate input bytes.

SMF Info
--------
    Field: `R7491IIB`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of inflate input bytes.
"""

r7491iis : Final[Field] = Field(
    name='r7491iis',
    origin='R7491IIS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Sum of the squares of the individual inflate input bytes.

SMF Info
--------
    Field: `R7491IIS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Sum of the squares of the individual inflate input bytes.
"""
r7491iis.__doc__ = """Sum of the squares of the individual inflate input bytes.

SMF Info
--------
    Field: `R7491IIS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Sum of the squares of the individual inflate input bytes.
"""

r7491iob : Final[Field] = Field(
    name='r7491iob',
    origin='R7491IOB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Total number of inflate output bytes.

SMF Info
--------
    Field: `R7491IOB`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of inflate output bytes.
"""
r7491iob.__doc__ = """Total number of inflate output bytes.

SMF Info
--------
    Field: `R7491IOB`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of inflate output bytes.
"""

r7491ios : Final[Field] = Field(
    name='r7491ios',
    origin='R7491IOS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Sum of the squares of the individual inflate output bytes.

SMF Info
--------
    Field: `R7491IOS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Sum of the squares of the individual inflate output bytes.
"""
r7491ios.__doc__ = """Sum of the squares of the individual inflate output bytes.

SMF Info
--------
    Field: `R7491IOS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Sum of the squares of the individual inflate output bytes.
"""

r7491ict : Final[Field] = Field(
    name='r7491ict',
    origin='R7491ICT',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Total number of inflate requests.

SMF Info
--------
    Field: `R7491ICT`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of inflate requests.
"""
r7491ict.__doc__ = """Total number of inflate requests.

SMF Info
--------
    Field: `R7491ICT`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total number of inflate requests.
"""

r7491bps : Final[Field] = Field(
    name='r7491bps',
    origin='R7491BPS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Total size of memory in megabytes allocated to the buffer pool.

SMF Info
--------
    Field: `R7491BPS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total size of memory in megabytes allocated to the buffer pool.
"""
r7491bps.__doc__ = """Total size of memory in megabytes allocated to the buffer pool.

SMF Info
--------
    Field: `R7491BPS`
    Record: `SMF74S9`
    Map: `R749HWA1`

Total size of memory in megabytes allocated to the buffer pool.
"""

r7491bpc : Final[Field] = Field(
    name='r7491bpc',
    origin='R7491BPC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749HWA1,
)
"""Size of memory in megabytes for in-use buffers.

SMF Info
--------
    Field: `R7491BPC`
    Record: `SMF74S9`
    Map: `R749HWA1`

Size of memory in megabytes for in-use buffers.
"""
r7491bpc.__doc__ = """Size of memory in megabytes for in-use buffers.

SMF Info
--------
    Field: `R7491BPC`
    Record: `SMF74S9`
    Map: `R749HWA1`

Size of memory in megabytes for in-use buffers.
"""

r749sndt : Final[Field] = Field(
    name='r749sndt',
    origin='R749SNDT',
    type=FieldType.STRING,
    record=record,
    record_map=R749SYNC,
)
"""Type number

SMF Info
--------
    Field: `R749SNDT`
    Record: `SMF74S9`
    Map: `R749SYNC`

Type number
"""
r749sndt.__doc__ = """Type number

SMF Info
--------
    Field: `R749SNDT`
    Record: `SMF74S9`
    Map: `R749SYNC`

Type number
"""

r749sndm : Final[Field] = Field(
    name='r749sndm',
    origin='R749SNDM',
    type=FieldType.STRING,
    record=record,
    record_map=R749SYNC,
)
"""Model number

SMF Info
--------
    Field: `R749SNDM`
    Record: `SMF74S9`
    Map: `R749SYNC`

Model number
"""
r749sndm.__doc__ = """Model number

SMF Info
--------
    Field: `R749SNDM`
    Record: `SMF74S9`
    Map: `R749SYNC`

Model number
"""

r749sndn : Final[Field] = Field(
    name='r749sndn',
    origin='R749SNDN',
    type=FieldType.STRING,
    record=record,
    record_map=R749SYNC,
)
"""Manufacturer

SMF Info
--------
    Field: `R749SNDN`
    Record: `SMF74S9`
    Map: `R749SYNC`

Manufacturer
"""
r749sndn.__doc__ = """Manufacturer

SMF Info
--------
    Field: `R749SNDN`
    Record: `SMF74S9`
    Map: `R749SYNC`

Manufacturer
"""

r749sndp : Final[Field] = Field(
    name='r749sndp',
    origin='R749SNDP',
    type=FieldType.STRING,
    record=record,
    record_map=R749SYNC,
)
"""Plant of Manufacture

SMF Info
--------
    Field: `R749SNDP`
    Record: `SMF74S9`
    Map: `R749SYNC`

Plant of Manufacture
"""
r749sndp.__doc__ = """Plant of Manufacture

SMF Info
--------
    Field: `R749SNDP`
    Record: `SMF74S9`
    Map: `R749SYNC`

Plant of Manufacture
"""

r749snds : Final[Field] = Field(
    name='r749snds',
    origin='R749SNDS',
    type=FieldType.STRING,
    record=record,
    record_map=R749SYNC,
)
"""Sequence number

SMF Info
--------
    Field: `R749SNDS`
    Record: `SMF74S9`
    Map: `R749SYNC`

Sequence number
"""
r749snds.__doc__ = """Sequence number

SMF Info
--------
    Field: `R749SNDS`
    Record: `SMF74S9`
    Map: `R749SYNC`

Sequence number
"""

r749rflg : Final[Field] = Field(
    name='r749rflg',
    origin='R749RFLG',
    type=FieldType.STRING,
    record=record,
    record_map=R749SRTD,
)
"""RTD Flag

SMF Info
--------
    Field: `R749RFLG`
    Record: `SMF74S9`
    Map: `R749SRTD`

RTD Flag
"""
r749rflg.__doc__ = """RTD Flag

SMF Info
--------
    Field: `R749RFLG`
    Record: `SMF74S9`
    Map: `R749SRTD`

RTD Flag
"""

response_time_for_sync_io_read : Final[Field] = Field(
    name='response_time_for_sync_io_read',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r749rflg,
    record=record,
    record_map=R749SRTD,
)
"""ON: Response time data measured for synchronous I/O read instructions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749rflg`(`R749RFLG`)
    Record: `SMF74S9`
    Map: `R749SRTD`

ON: Response time data measured for synchronous I/O read instructions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
response_time_for_sync_io_read.__doc__ = """ON: Response time data measured for synchronous I/O read instructions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749rflg`(`R749RFLG`)
    Record: `SMF74S9`
    Map: `R749SRTD`

ON: Response time data measured for synchronous I/O read instructions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

response_time_for_sync_io_write : Final[Field] = Field(
    name='response_time_for_sync_io_write',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r749rflg,
    record=record,
    record_map=R749SRTD,
)
"""ON: Response time data measured for synchronous I/O write instructions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749rflg`(`R749RFLG`)
    Record: `SMF74S9`
    Map: `R749SRTD`

ON: Response time data measured for synchronous I/O write instructions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
response_time_for_sync_io_write.__doc__ = """ON: Response time data measured for synchronous I/O write instructions(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r749rflg`(`R749RFLG`)
    Record: `SMF74S9`
    Map: `R749SRTD`

ON: Response time data measured for synchronous I/O write instructions

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r749rtrv : Final[Field] = Field(
    name='r749rtrv',
    origin='R749RTRV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749SRTD,
)
"""Response time distribution bucket range value. The range value of the first read and the first write bucket of a Synchronous I/O link represents response times less than the range value. For example, if the read range value is 10, then this bucket represents response times less than 10 microseconds. The range value of the remaining buckets represents response times less than this range value and greater than or equal to the prior range value. For example, if the range value is 30 and the prior range value was 20, this represents responses r in the range: 20 microseconds <= r < 30 micro seconds

SMF Info
--------
    Field: `R749RTRV`
    Record: `SMF74S9`
    Map: `R749SRTD`

Response time distribution bucket range value. The range value of the first read and the first write bucket of a Synchronous I/O link represents response times less than the range value. For example, if the read range value is 10, then this bucket represents response times less than 10 microseconds. The range value of the remaining buckets represents response times less than this range value and greater than or equal to the prior range value. For example, if the range value is 30 and the prior range value was 20, this represents responses r in the range: 20 microseconds <= r < 30 micro seconds
"""
r749rtrv.__doc__ = """Response time distribution bucket range value. The range value of the first read and the first write bucket of a Synchronous I/O link represents response times less than the range value. For example, if the read range value is 10, then this bucket represents response times less than 10 microseconds. The range value of the remaining buckets represents response times less than this range value and greater than or equal to the prior range value. For example, if the range value is 30 and the prior range value was 20, this represents responses r in the range: 20 microseconds <= r < 30 micro seconds

SMF Info
--------
    Field: `R749RTRV`
    Record: `SMF74S9`
    Map: `R749SRTD`

Response time distribution bucket range value. The range value of the first read and the first write bucket of a Synchronous I/O link represents response times less than the range value. For example, if the read range value is 10, then this bucket represents response times less than 10 microseconds. The range value of the remaining buckets represents response times less than this range value and greater than or equal to the prior range value. For example, if the range value is 30 and the prior range value was 20, this represents responses r in the range: 20 microseconds <= r < 30 micro seconds
"""

r749rtsc : Final[Field] = Field(
    name='r749rtsc',
    origin='R749RTSC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R749SRTD,
)
"""Response time distribution sample count.

SMF Info
--------
    Field: `R749RTSC`
    Record: `SMF74S9`
    Map: `R749SRTD`

Response time distribution sample count.
"""
r749rtsc.__doc__ = """Response time distribution sample count.

SMF Info
--------
    Field: `R749RTSC`
    Record: `SMF74S9`
    Map: `R749SRTD`

Response time distribution sample count.
"""
