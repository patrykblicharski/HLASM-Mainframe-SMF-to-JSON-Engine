# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 74 Subtype 6"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=74,
                                smf_subtype=6,
                                spec='SMF 74 Subtype 6',
                                post=None)
"""SMF 74 Subtype 6"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF74PRO: Final[RecordMap] = RecordMap(
    origin='SMF74PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
R746GDAT: Final[RecordMap] = RecordMap(
    origin='R746GDAT',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Global Data Section',
    post=None,
    record_mapping=False)
"""Global Data Section"""
R746GBUF: Final[RecordMap] = RecordMap(
    origin='R746GBUF',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='Global Buffer Section',
    post=None,
    record_mapping=False)
"""Global Buffer Section"""
R746FSYS: Final[RecordMap] = RecordMap(
    origin='R746FSYS',
    record=record,
    parent=None,
    is_multiple=True,
    is_compound=False,
    spec='File System Section',
    post=None,
    record_mapping=False)
"""File System Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S6`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S6`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S6`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S6`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S6`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF74DTE`), `time`(`SMF74TME`)
    Record: `SMF74S6`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF74LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S6`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF74LEN`
    Record: `SMF74S6`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF74SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S6`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF74SEG`
    Record: `SMF74S6`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF74FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S6`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF74FLG`
    Record: `SMF74S6`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF74FLG`)
    Record: `SMF74S6`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF74RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S6`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF74RTY`
    Record: `SMF74S6`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF74TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S6`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF74TME`
    Record: `SMF74S6`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF74DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S6`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF74DTE`
    Record: `SMF74S6`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF74SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S6`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF74SID`
    Record: `SMF74S6`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF74SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S6`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF74SSI`
    Record: `SMF74S6`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF74STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S6`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF74STY`
    Record: `SMF74S6`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF74TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S6`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF74TRN`
    Record: `SMF74S6`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF74PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S6`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRS`
    Record: `SMF74S6`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF74PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S6`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF74PRL`
    Record: `SMF74S6`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF74PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S6`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF74PRN`
    Record: `SMF74S6`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

do : Final[Field] = Field(
    name='do',
    origin='SMF746DO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to global data section

SMF Info
--------
    Field: `SMF746DO`
    Record: `SMF74S6`
    Map: Not part of a map

Offset to global data section
"""
do.__doc__ = """Offset to global data section

SMF Info
--------
    Field: `SMF746DO`
    Record: `SMF74S6`
    Map: Not part of a map

Offset to global data section
"""

dl : Final[Field] = Field(
    name='dl',
    origin='SMF746DL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of global data section

SMF Info
--------
    Field: `SMF746DL`
    Record: `SMF74S6`
    Map: Not part of a map

Length of global data section
"""
dl.__doc__ = """Length of global data section

SMF Info
--------
    Field: `SMF746DL`
    Record: `SMF74S6`
    Map: Not part of a map

Length of global data section
"""

dn : Final[Field] = Field(
    name='dn',
    origin='SMF746DN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of global data sections

SMF Info
--------
    Field: `SMF746DN`
    Record: `SMF74S6`
    Map: Not part of a map

Number of global data sections
"""
dn.__doc__ = """Number of global data sections

SMF Info
--------
    Field: `SMF746DN`
    Record: `SMF74S6`
    Map: Not part of a map

Number of global data sections
"""

bo : Final[Field] = Field(
    name='bo',
    origin='SMF746BO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to global buffer section

SMF Info
--------
    Field: `SMF746BO`
    Record: `SMF74S6`
    Map: Not part of a map

Offset to global buffer section
"""
bo.__doc__ = """Offset to global buffer section

SMF Info
--------
    Field: `SMF746BO`
    Record: `SMF74S6`
    Map: Not part of a map

Offset to global buffer section
"""

bl : Final[Field] = Field(
    name='bl',
    origin='SMF746BL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of global buffer section

SMF Info
--------
    Field: `SMF746BL`
    Record: `SMF74S6`
    Map: Not part of a map

Length of global buffer section
"""
bl.__doc__ = """Length of global buffer section

SMF Info
--------
    Field: `SMF746BL`
    Record: `SMF74S6`
    Map: Not part of a map

Length of global buffer section
"""

bn : Final[Field] = Field(
    name='bn',
    origin='SMF746BN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of global buffer sections

SMF Info
--------
    Field: `SMF746BN`
    Record: `SMF74S6`
    Map: Not part of a map

Number of global buffer sections
"""
bn.__doc__ = """Number of global buffer sections

SMF Info
--------
    Field: `SMF746BN`
    Record: `SMF74S6`
    Map: Not part of a map

Number of global buffer sections
"""

fo : Final[Field] = Field(
    name='fo',
    origin='SMF746FO',
    type=FieldType.INTEGER,
    record=record,
)
"""Offset to file system section

SMF Info
--------
    Field: `SMF746FO`
    Record: `SMF74S6`
    Map: Not part of a map

Offset to file system section
"""
fo.__doc__ = """Offset to file system section

SMF Info
--------
    Field: `SMF746FO`
    Record: `SMF74S6`
    Map: Not part of a map

Offset to file system section
"""

fl : Final[Field] = Field(
    name='fl',
    origin='SMF746FL',
    type=FieldType.INTEGER,
    record=record,
)
"""Length of file system section

SMF Info
--------
    Field: `SMF746FL`
    Record: `SMF74S6`
    Map: Not part of a map

Length of file system section
"""
fl.__doc__ = """Length of file system section

SMF Info
--------
    Field: `SMF746FL`
    Record: `SMF74S6`
    Map: Not part of a map

Length of file system section
"""

fn : Final[Field] = Field(
    name='fn',
    origin='SMF746FN',
    type=FieldType.INTEGER,
    record=record,
)
"""Number of file system sections

SMF Info
--------
    Field: `SMF746FN`
    Record: `SMF74S6`
    Map: Not part of a map

Number of file system sections
"""
fn.__doc__ = """Number of file system sections

SMF Info
--------
    Field: `SMF746FN`
    Record: `SMF74S6`
    Map: Not part of a map

Number of file system sections
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF74MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S6`
    Map: `SMF74PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF74MFV`
    Record: `SMF74S6`
    Map: `SMF74PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF74PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF74PRD`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF74IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF74IST`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF74DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF74PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF74DAT`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF74INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF74INT`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF74SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF74SAM`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF74FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF74FLA`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

iss : Final[Field] = Field(
    name='iss',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
iss.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

ism : Final[Field] = Field(
    name='ism',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
ism.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

rcl : Final[Field] = Field(
    name='rcl',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
rcl.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

rch : Final[Field] = Field(
    name='rch',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
rch.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

iip : Final[Field] = Field(
    name='iip',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
iip.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

eed : Final[Field] = Field(
    name='eed',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
eed.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF74PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF74FLA`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF74CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF74PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF74CYC`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF74MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S6`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF74MVS`
    Record: `SMF74S6`
    Map: `SMF74PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF74IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF74IML`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF74PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF74PRF`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Processor flags
"""

qes : Final[Field] = Field(
    name='qes',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
qes.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

cne : Final[Field] = Field(
    name='cne',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
cne.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

drc : Final[Field] = Field(
    name='drc',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
drc.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

eme : Final[Field] = Field(
    name='eme',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
eme.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

pri : Final[Field] = Field(
    name='pri',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
pri.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

prp : Final[Field] = Field(
    name='prp',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
prp.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

ped : Final[Field] = Field(
    name='ped',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
ped.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

pe2 : Final[Field] = Field(
    name='pe2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF74PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
pe2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF74PRF`)
    Record: `SMF74S6`
    Map: `SMF74PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF74PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S6`
    Map: `SMF74PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF74PTN`
    Record: `SMF74S6`
    Map: `SMF74PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF74SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S6`
    Map: `SMF74PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF74SRL`
    Record: `SMF74S6`
    Map: `SMF74PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF74IET',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF74IET`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF74LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF74LGO`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF74RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF74RAO`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF74RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF74RAL`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF74RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF74RAN`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF74OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF74OIL`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF74SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF74PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S6`
    Map: `SMF74PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF74SYN`
    Record: `SMF74S6`
    Map: `SMF74PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF74GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF74PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF74GIE`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF74XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF74XNM`
    Record: `SMF74S6`
    Map: `SMF74PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF74SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF74PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S6`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF74SNM`
    Record: `SMF74S6`
    Map: `SMF74PRO`

System name for current system as defined in CVTSNAME
"""

r746gmxv : Final[Field] = Field(
    name='r746gmxv',
    origin='R746GMXV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GDAT,
)
"""Value of VIRTUAL(MAX) (in MB)

SMF Info
--------
    Field: `R746GMXV`
    Record: `SMF74S6`
    Map: `R746GDAT`

Value of VIRTUAL(MAX) (in MB)
"""
r746gmxv.__doc__ = """Value of VIRTUAL(MAX) (in MB)

SMF Info
--------
    Field: `R746GMXV`
    Record: `SMF74S6`
    Map: `R746GDAT`

Value of VIRTUAL(MAX) (in MB)
"""

r746gusv : Final[Field] = Field(
    name='r746gusv',
    origin='R746GUSV',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GDAT,
)
"""Total amount (in pages) of virtual storage in use

SMF Info
--------
    Field: `R746GUSV`
    Record: `SMF74S6`
    Map: `R746GDAT`

Total amount (in pages) of virtual storage in use
"""
r746gusv.__doc__ = """Total amount (in pages) of virtual storage in use

SMF Info
--------
    Field: `R746GUSV`
    Record: `SMF74S6`
    Map: `R746GDAT`

Total amount (in pages) of virtual storage in use
"""

r746gmnf : Final[Field] = Field(
    name='r746gmnf',
    origin='R746GMNF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GDAT,
)
"""Value of FIXED(MIN) (in MB)

SMF Info
--------
    Field: `R746GMNF`
    Record: `SMF74S6`
    Map: `R746GDAT`

Value of FIXED(MIN) (in MB)
"""
r746gmnf.__doc__ = """Value of FIXED(MIN) (in MB)

SMF Info
--------
    Field: `R746GMNF`
    Record: `SMF74S6`
    Map: `R746GDAT`

Value of FIXED(MIN) (in MB)
"""

r746gusf : Final[Field] = Field(
    name='r746gusf',
    origin='R746GUSF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GDAT,
)
"""Total amount (in pages ) of permanently fixed storage in use

SMF Info
--------
    Field: `R746GUSF`
    Record: `SMF74S6`
    Map: `R746GDAT`

Total amount (in pages ) of permanently fixed storage in use
"""
r746gusf.__doc__ = """Total amount (in pages ) of permanently fixed storage in use

SMF Info
--------
    Field: `R746GUSF`
    Record: `SMF74S6`
    Map: `R746GDAT`

Total amount (in pages ) of permanently fixed storage in use
"""

r746gmc : Final[Field] = Field(
    name='r746gmc',
    origin='R746GMC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746GDAT,
)
"""Number of times the metadata for a file was found in virtual storage (cache) during file lookup, (long floating point)

SMF Info
--------
    Field: `R746GMC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Number of times the metadata for a file was found in virtual storage (cache) during file lookup, (long floating point)
"""
r746gmc.__doc__ = """Number of times the metadata for a file was found in virtual storage (cache) during file lookup, (long floating point)

SMF Info
--------
    Field: `R746GMC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Number of times the metadata for a file was found in virtual storage (cache) during file lookup, (long floating point)
"""

r746gmnc : Final[Field] = Field(
    name='r746gmnc',
    origin='R746GMNC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746GDAT,
)
"""Number of times the metadata for a file was not found in virtual storage (cache) during file lookup and an index call was necessary which may result in an I/O, (long floating point)

SMF Info
--------
    Field: `R746GMNC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Number of times the metadata for a file was not found in virtual storage (cache) during file lookup and an index call was necessary which may result in an I/O, (long floating point)
"""
r746gmnc.__doc__ = """Number of times the metadata for a file was not found in virtual storage (cache) during file lookup and an index call was necessary which may result in an I/O, (long floating point)

SMF Info
--------
    Field: `R746GMNC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Number of times the metadata for a file was not found in virtual storage (cache) during file lookup and an index call was necessary which may result in an I/O, (long floating point)
"""

r746g1c : Final[Field] = Field(
    name='r746g1c',
    origin='R746G1C',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746GDAT,
)
"""Number of times the first page of a data file was requested and found in virtual storage (cache), (long floating point)

SMF Info
--------
    Field: `R746G1C`
    Record: `SMF74S6`
    Map: `R746GDAT`

Number of times the first page of a data file was requested and found in virtual storage (cache), (long floating point)
"""
r746g1c.__doc__ = """Number of times the first page of a data file was requested and found in virtual storage (cache), (long floating point)

SMF Info
--------
    Field: `R746G1C`
    Record: `SMF74S6`
    Map: `R746GDAT`

Number of times the first page of a data file was requested and found in virtual storage (cache), (long floating point)
"""

r746g1nc : Final[Field] = Field(
    name='r746g1nc',
    origin='R746G1NC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746GDAT,
)
"""Number of times the first page of a data file was requested and not found in virtual storage (cache) and a I/O was necessary, (long floating point)

SMF Info
--------
    Field: `R746G1NC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Number of times the first page of a data file was requested and not found in virtual storage (cache) and a I/O was necessary, (long floating point)
"""
r746g1nc.__doc__ = """Number of times the first page of a data file was requested and not found in virtual storage (cache) and a I/O was necessary, (long floating point)

SMF Info
--------
    Field: `R746G1NC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Number of times the first page of a data file was requested and not found in virtual storage (cache) and a I/O was necessary, (long floating point)
"""

r746glrc : Final[Field] = Field(
    name='r746glrc',
    origin='R746GLRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GDAT,
)
"""Return code from OMVS BPX1PCT for DisplayBufferLimits command

SMF Info
--------
    Field: `R746GLRC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Return code from OMVS BPX1PCT for DisplayBufferLimits command
"""
r746glrc.__doc__ = """Return code from OMVS BPX1PCT for DisplayBufferLimits command

SMF Info
--------
    Field: `R746GLRC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Return code from OMVS BPX1PCT for DisplayBufferLimits command
"""

r746glrs : Final[Field] = Field(
    name='r746glrs',
    origin='R746GLRS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GDAT,
)
"""Reason code from OMVS BPX1PCT for DisplayBufferLimits command

SMF Info
--------
    Field: `R746GLRS`
    Record: `SMF74S6`
    Map: `R746GDAT`

Reason code from OMVS BPX1PCT for DisplayBufferLimits command
"""
r746glrs.__doc__ = """Reason code from OMVS BPX1PCT for DisplayBufferLimits command

SMF Info
--------
    Field: `R746GLRS`
    Record: `SMF74S6`
    Map: `R746GDAT`

Reason code from OMVS BPX1PCT for DisplayBufferLimits command
"""

r746gsrc : Final[Field] = Field(
    name='r746gsrc',
    origin='R746GSRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GDAT,
)
"""Return code from OMVS BPX1PCT for DisplayGlobalStats command

SMF Info
--------
    Field: `R746GSRC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Return code from OMVS BPX1PCT for DisplayGlobalStats command
"""
r746gsrc.__doc__ = """Return code from OMVS BPX1PCT for DisplayGlobalStats command

SMF Info
--------
    Field: `R746GSRC`
    Record: `SMF74S6`
    Map: `R746GDAT`

Return code from OMVS BPX1PCT for DisplayGlobalStats command
"""

r746gsrs : Final[Field] = Field(
    name='r746gsrs',
    origin='R746GSRS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GDAT,
)
"""Reason code from OMVS BPX1PCT for DisplayGlobalStats command

SMF Info
--------
    Field: `R746GSRS`
    Record: `SMF74S6`
    Map: `R746GDAT`

Reason code from OMVS BPX1PCT for DisplayGlobalStats command
"""
r746gsrs.__doc__ = """Reason code from OMVS BPX1PCT for DisplayGlobalStats command

SMF Info
--------
    Field: `R746GSRS`
    Record: `SMF74S6`
    Map: `R746GDAT`

Reason code from OMVS BPX1PCT for DisplayGlobalStats command
"""

r746gsfl : Final[Field] = Field(
    name='r746gsfl',
    origin='R746GSFL',
    type=FieldType.STRING,
    record=record,
    record_map=R746GDAT,
)
"""Status Flags

SMF Info
--------
    Field: `R746GSFL`
    Record: `SMF74S6`
    Map: `R746GDAT`

Status Flags
"""
r746gsfl.__doc__ = """Status Flags

SMF Info
--------
    Field: `R746GSFL`
    Record: `SMF74S6`
    Map: `R746GDAT`

Status Flags
"""

r746gonr : Final[Field] = Field(
    name='r746gonr',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r746gsfl,
    record=record,
    record_map=R746GDAT,
)
"""OMVS kernel not ready(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746gsfl`(`R746GSFL`)
    Record: `SMF74S6`
    Map: `R746GDAT`

OMVS kernel not ready

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r746gonr.__doc__ = """OMVS kernel not ready(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746gsfl`(`R746GSFL`)
    Record: `SMF74S6`
    Map: `R746GDAT`

OMVS kernel not ready

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r746gnbl : Final[Field] = Field(
    name='r746gnbl',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r746gsfl,
    record=record,
    record_map=R746GDAT,
)
"""No buffer limit data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746gsfl`(`R746GSFL`)
    Record: `SMF74S6`
    Map: `R746GDAT`

No buffer limit data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r746gnbl.__doc__ = """No buffer limit data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746gsfl`(`R746GSFL`)
    Record: `SMF74S6`
    Map: `R746GDAT`

No buffer limit data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r746gngd : Final[Field] = Field(
    name='r746gngd',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r746gsfl,
    record=record,
    record_map=R746GDAT,
)
"""No global data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746gsfl`(`R746GSFL`)
    Record: `SMF74S6`
    Map: `R746GDAT`

No global data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r746gngd.__doc__ = """No global data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746gsfl`(`R746GSFL`)
    Record: `SMF74S6`
    Map: `R746GDAT`

No global data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r746gpgd : Final[Field] = Field(
    name='r746gpgd',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=r746gsfl,
    record=record,
    record_map=R746GDAT,
)
"""Partial global data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746gsfl`(`R746GSFL`)
    Record: `SMF74S6`
    Map: `R746GDAT`

Partial global data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
r746gpgd.__doc__ = """Partial global data(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746gsfl`(`R746GSFL`)
    Record: `SMF74S6`
    Map: `R746GDAT`

Partial global data

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

r746gsb : Final[Field] = Field(
    name='r746gsb',
    origin='R746GSB',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GBUF,
)
"""Size of buffers in buffer pool (in pages)

SMF Info
--------
    Field: `R746GSB`
    Record: `SMF74S6`
    Map: `R746GBUF`

Size of buffers in buffer pool (in pages)
"""
r746gsb.__doc__ = """Size of buffers in buffer pool (in pages)

SMF Info
--------
    Field: `R746GSB`
    Record: `SMF74S6`
    Map: `R746GBUF`

Size of buffers in buffer pool (in pages)
"""

r746gnds : Final[Field] = Field(
    name='r746gnds',
    origin='R746GNDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GBUF,
)
"""Number of data spaces for buffer pool

SMF Info
--------
    Field: `R746GNDS`
    Record: `SMF74S6`
    Map: `R746GBUF`

Number of data spaces for buffer pool
"""
r746gnds.__doc__ = """Number of data spaces for buffer pool

SMF Info
--------
    Field: `R746GNDS`
    Record: `SMF74S6`
    Map: `R746GBUF`

Number of data spaces for buffer pool
"""

r746gsbp : Final[Field] = Field(
    name='r746gsbp',
    origin='R746GSBP',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GBUF,
)
"""Size of buffer pool (in pages)

SMF Info
--------
    Field: `R746GSBP`
    Record: `SMF74S6`
    Map: `R746GBUF`

Size of buffer pool (in pages)
"""
r746gsbp.__doc__ = """Size of buffer pool (in pages)

SMF Info
--------
    Field: `R746GSBP`
    Record: `SMF74S6`
    Map: `R746GBUF`

Size of buffer pool (in pages)
"""

r746gsbf : Final[Field] = Field(
    name='r746gsbf',
    origin='R746GSBF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746GBUF,
)
"""Size of permanently fixed buffers in buffer pool (in pages)

SMF Info
--------
    Field: `R746GSBF`
    Record: `SMF74S6`
    Map: `R746GBUF`

Size of permanently fixed buffers in buffer pool (in pages)
"""
r746gsbf.__doc__ = """Size of permanently fixed buffers in buffer pool (in pages)

SMF Info
--------
    Field: `R746GSBF`
    Record: `SMF74S6`
    Map: `R746GBUF`

Size of permanently fixed buffers in buffer pool (in pages)
"""

r746gbf : Final[Field] = Field(
    name='r746gbf',
    origin='R746GBF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746GBUF,
)
"""Number of times a buffer was already fixed prior to an I/O request in buffer pool, (long floating point)

SMF Info
--------
    Field: `R746GBF`
    Record: `SMF74S6`
    Map: `R746GBUF`

Number of times a buffer was already fixed prior to an I/O request in buffer pool, (long floating point)
"""
r746gbf.__doc__ = """Number of times a buffer was already fixed prior to an I/O request in buffer pool, (long floating point)

SMF Info
--------
    Field: `R746GBF`
    Record: `SMF74S6`
    Map: `R746GBUF`

Number of times a buffer was already fixed prior to an I/O request in buffer pool, (long floating point)
"""

r746gbnf : Final[Field] = Field(
    name='r746gbnf',
    origin='R746GBNF',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746GBUF,
)
"""Number of times a buffer was not already fixed prior to an I/O request in buffer pool, (long floating point)

SMF Info
--------
    Field: `R746GBNF`
    Record: `SMF74S6`
    Map: `R746GBUF`

Number of times a buffer was not already fixed prior to an I/O request in buffer pool, (long floating point)
"""
r746gbnf.__doc__ = """Number of times a buffer was not already fixed prior to an I/O request in buffer pool, (long floating point)

SMF Info
--------
    Field: `R746GBNF`
    Record: `SMF74S6`
    Map: `R746GBUF`

Number of times a buffer was not already fixed prior to an I/O request in buffer pool, (long floating point)
"""

r746fsnm : Final[Field] = Field(
    name='r746fsnm',
    origin='R746FSNM',
    type=FieldType.STRING,
    record=record,
    record_map=R746FSYS,
)
"""File system name (catologed dataset name)

SMF Info
--------
    Field: `R746FSNM`
    Record: `SMF74S6`
    Map: `R746FSYS`

File system name (catologed dataset name)
"""
r746fsnm.__doc__ = """File system name (catologed dataset name)

SMF Info
--------
    Field: `R746FSNM`
    Record: `SMF74S6`
    Map: `R746FSYS`

File system name (catologed dataset name)
"""

r746fsnl : Final[Field] = Field(
    name='r746fsnl',
    origin='R746FSNL',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746FSYS,
)
"""Length of file system name

SMF Info
--------
    Field: `R746FSNL`
    Record: `SMF74S6`
    Map: `R746FSYS`

Length of file system name
"""
r746fsnl.__doc__ = """Length of file system name

SMF Info
--------
    Field: `R746FSNL`
    Record: `SMF74S6`
    Map: `R746FSYS`

Length of file system name
"""

r746fsfl : Final[Field] = Field(
    name='r746fsfl',
    origin='R746FSFL',
    type=FieldType.STRING,
    record=record,
    record_map=R746FSYS,
)
"""Status flags

SMF Info
--------
    Field: `R746FSFL`
    Record: `SMF74S6`
    Map: `R746FSYS`

Status flags
"""
r746fsfl.__doc__ = """Status flags

SMF Info
--------
    Field: `R746FSFL`
    Record: `SMF74S6`
    Map: `R746FSYS`

Status flags
"""

r746fnhs : Final[Field] = Field(
    name='r746fnhs',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=r746fsfl,
    record=record,
    record_map=R746FSYS,
)
"""No HFS file system statistics(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746fsfl`(`R746FSFL`)
    Record: `SMF74S6`
    Map: `R746FSYS`

No HFS file system statistics

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
r746fnhs.__doc__ = """No HFS file system statistics(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746fsfl`(`R746FSFL`)
    Record: `SMF74S6`
    Map: `R746FSYS`

No HFS file system statistics

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

r746fmtc : Final[Field] = Field(
    name='r746fmtc',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=r746fsfl,
    record=record,
    record_map=R746FSYS,
)
"""Mount time changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746fsfl`(`R746FSFL`)
    Record: `SMF74S6`
    Map: `R746FSYS`

Mount time changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
r746fmtc.__doc__ = """Mount time changed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746fsfl`(`R746FSFL`)
    Record: `SMF74S6`
    Map: `R746FSYS`

Mount time changed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

r746ffsm : Final[Field] = Field(
    name='r746ffsm',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=r746fsfl,
    record=record,
    record_map=R746FSYS,
)
"""File system now mounted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746fsfl`(`R746FSFL`)
    Record: `SMF74S6`
    Map: `R746FSYS`

File system now mounted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
r746ffsm.__doc__ = """File system now mounted(V)

SMF Info (Virtual Field)
--------
    Field: Based on `r746fsfl`(`R746FSFL`)
    Record: `SMF74S6`
    Map: `R746FSYS`

File system now mounted

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

r746fctm : Final[Field] = Field(
    name='r746fctm',
    origin='R746FCTM',
    type=FieldType.TIME,
    record=record,
    record_map=R746FSYS,
)
"""Current timestamp (when data obtained)

SMF Info
--------
    Field: `R746FCTM`
    Record: `SMF74S6`
    Map: `R746FSYS`

Current timestamp (when data obtained)
"""
r746fctm.__doc__ = """Current timestamp (when data obtained)

SMF Info
--------
    Field: `R746FCTM`
    Record: `SMF74S6`
    Map: `R746FSYS`

Current timestamp (when data obtained)
"""

r746fmtm : Final[Field] = Field(
    name='r746fmtm',
    origin='R746FMTM',
    type=FieldType.TIME,
    record=record,
    record_map=R746FSYS,
)
"""Mount timestamp

SMF Info
--------
    Field: `R746FMTM`
    Record: `SMF74S6`
    Map: `R746FSYS`

Mount timestamp
"""
r746fmtm.__doc__ = """Mount timestamp

SMF Info
--------
    Field: `R746FMTM`
    Record: `SMF74S6`
    Map: `R746FSYS`

Mount timestamp
"""

r746fsf : Final[Field] = Field(
    name='r746fsf',
    origin='R746FSF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746FSYS,
)
"""Size of file system (in pages)

SMF Info
--------
    Field: `R746FSF`
    Record: `SMF74S6`
    Map: `R746FSYS`

Size of file system (in pages)
"""
r746fsf.__doc__ = """Size of file system (in pages)

SMF Info
--------
    Field: `R746FSF`
    Record: `SMF74S6`
    Map: `R746FSYS`

Size of file system (in pages)
"""

r746fpf : Final[Field] = Field(
    name='r746fpf',
    origin='R746FPF',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746FSYS,
)
"""Number of pages internally used by HFS

SMF Info
--------
    Field: `R746FPF`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of pages internally used by HFS
"""
r746fpf.__doc__ = """Number of pages internally used by HFS

SMF Info
--------
    Field: `R746FPF`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of pages internally used by HFS
"""

r746fpd : Final[Field] = Field(
    name='r746fpd',
    origin='R746FPD',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746FSYS,
)
"""Number of pages used for the attribute directory

SMF Info
--------
    Field: `R746FPD`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of pages used for the attribute directory
"""
r746fpd.__doc__ = """Number of pages used for the attribute directory

SMF Info
--------
    Field: `R746FPD`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of pages used for the attribute directory
"""

r746fpc : Final[Field] = Field(
    name='r746fpc',
    origin='R746FPC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746FSYS,
)
"""Number of data buffer pages cached by this file system

SMF Info
--------
    Field: `R746FPC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of data buffer pages cached by this file system
"""
r746fpc.__doc__ = """Number of data buffer pages cached by this file system

SMF Info
--------
    Field: `R746FPC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of data buffer pages cached by this file system
"""

r746fsfi : Final[Field] = Field(
    name='r746fsfi',
    origin='R746FSFI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of sequential file data I/O requests issued, (long floating point)

SMF Info
--------
    Field: `R746FSFI`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of sequential file data I/O requests issued, (long floating point)
"""
r746fsfi.__doc__ = """Number of sequential file data I/O requests issued, (long floating point)

SMF Info
--------
    Field: `R746FSFI`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of sequential file data I/O requests issued, (long floating point)
"""

r746frfi : Final[Field] = Field(
    name='r746frfi',
    origin='R746FRFI',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of random file data I/O requests issued, (long floating point)

SMF Info
--------
    Field: `R746FRFI`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of random file data I/O requests issued, (long floating point)
"""
r746frfi.__doc__ = """Number of random file data I/O requests issued, (long floating point)

SMF Info
--------
    Field: `R746FRFI`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of random file data I/O requests issued, (long floating point)
"""

r746fmc : Final[Field] = Field(
    name='r746fmc',
    origin='R746FMC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of times the metadata for a file was found in virtual storage (cache) during file lookup, (long floating point)

SMF Info
--------
    Field: `R746FMC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of times the metadata for a file was found in virtual storage (cache) during file lookup, (long floating point)
"""
r746fmc.__doc__ = """Number of times the metadata for a file was found in virtual storage (cache) during file lookup, (long floating point)

SMF Info
--------
    Field: `R746FMC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of times the metadata for a file was found in virtual storage (cache) during file lookup, (long floating point)
"""

r746fmnc : Final[Field] = Field(
    name='r746fmnc',
    origin='R746FMNC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of times the metadata for a file was not found in virtual storage (cache) during file lookup and an index call was necessary which may result in an I/O, (long floating point)

SMF Info
--------
    Field: `R746FMNC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of times the metadata for a file was not found in virtual storage (cache) during file lookup and an index call was necessary which may result in an I/O, (long floating point)
"""
r746fmnc.__doc__ = """Number of times the metadata for a file was not found in virtual storage (cache) during file lookup and an index call was necessary which may result in an I/O, (long floating point)

SMF Info
--------
    Field: `R746FMNC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of times the metadata for a file was not found in virtual storage (cache) during file lookup and an index call was necessary which may result in an I/O, (long floating point)
"""

r746f1c : Final[Field] = Field(
    name='r746f1c',
    origin='R746F1C',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of times the first page of a data file was requested and found in virtual storage (cache), (long floating point)

SMF Info
--------
    Field: `R746F1C`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of times the first page of a data file was requested and found in virtual storage (cache), (long floating point)
"""
r746f1c.__doc__ = """Number of times the first page of a data file was requested and found in virtual storage (cache), (long floating point)

SMF Info
--------
    Field: `R746F1C`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of times the first page of a data file was requested and found in virtual storage (cache), (long floating point)
"""

r746f1nc : Final[Field] = Field(
    name='r746f1nc',
    origin='R746F1NC',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of times the first page of a data file was requested and not found in virtual storage (cache) and a I/O was necessary, (long floating point)

SMF Info
--------
    Field: `R746F1NC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of times the first page of a data file was requested and not found in virtual storage (cache) and a I/O was necessary, (long floating point)
"""
r746f1nc.__doc__ = """Number of times the first page of a data file was requested and not found in virtual storage (cache) and a I/O was necessary, (long floating point)

SMF Info
--------
    Field: `R746F1NC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of times the first page of a data file was requested and not found in virtual storage (cache) and a I/O was necessary, (long floating point)
"""

r746fint : Final[Field] = Field(
    name='r746fint',
    origin='R746FINT',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of index new tops, (long floating point)

SMF Info
--------
    Field: `R746FINT`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index new tops, (long floating point)
"""
r746fint.__doc__ = """Number of index new tops, (long floating point)

SMF Info
--------
    Field: `R746FINT`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index new tops, (long floating point)
"""

r746fis : Final[Field] = Field(
    name='r746fis',
    origin='R746FIS',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of index splits, (long floating point)

SMF Info
--------
    Field: `R746FIS`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index splits, (long floating point)
"""
r746fis.__doc__ = """Number of index splits, (long floating point)

SMF Info
--------
    Field: `R746FIS`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index splits, (long floating point)
"""

r746fij : Final[Field] = Field(
    name='r746fij',
    origin='R746FIJ',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of index joins, (long floating point)

SMF Info
--------
    Field: `R746FIJ`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index joins, (long floating point)
"""
r746fij.__doc__ = """Number of index joins, (long floating point)

SMF Info
--------
    Field: `R746FIJ`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index joins, (long floating point)
"""

r746firh : Final[Field] = Field(
    name='r746firh',
    origin='R746FIRH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of index page read hits, (long floating point)

SMF Info
--------
    Field: `R746FIRH`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index page read hits, (long floating point)
"""
r746firh.__doc__ = """Number of index page read hits, (long floating point)

SMF Info
--------
    Field: `R746FIRH`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index page read hits, (long floating point)
"""

r746firm : Final[Field] = Field(
    name='r746firm',
    origin='R746FIRM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of index page read misses, (long floating point)

SMF Info
--------
    Field: `R746FIRM`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index page read misses, (long floating point)
"""
r746firm.__doc__ = """Number of index page read misses, (long floating point)

SMF Info
--------
    Field: `R746FIRM`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index page read misses, (long floating point)
"""

r746fiwh : Final[Field] = Field(
    name='r746fiwh',
    origin='R746FIWH',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of index page write hits, (long floating point)

SMF Info
--------
    Field: `R746FIWH`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index page write hits, (long floating point)
"""
r746fiwh.__doc__ = """Number of index page write hits, (long floating point)

SMF Info
--------
    Field: `R746FIWH`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index page write hits, (long floating point)
"""

r746fiwm : Final[Field] = Field(
    name='r746fiwm',
    origin='R746FIWM',
    type=FieldType.FLOAT,
    record=record,
    record_map=R746FSYS,
)
"""Number of index page write misses, (long floating point)

SMF Info
--------
    Field: `R746FIWM`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index page write misses, (long floating point)
"""
r746fiwm.__doc__ = """Number of index page write misses, (long floating point)

SMF Info
--------
    Field: `R746FIWM`
    Record: `SMF74S6`
    Map: `R746FSYS`

Number of index page write misses, (long floating point)
"""

r746fsrc : Final[Field] = Field(
    name='r746fsrc',
    origin='R746FSRC',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746FSYS,
)
"""Return code from OMVS BPX1PCT for DisplayFSStats command

SMF Info
--------
    Field: `R746FSRC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Return code from OMVS BPX1PCT for DisplayFSStats command
"""
r746fsrc.__doc__ = """Return code from OMVS BPX1PCT for DisplayFSStats command

SMF Info
--------
    Field: `R746FSRC`
    Record: `SMF74S6`
    Map: `R746FSYS`

Return code from OMVS BPX1PCT for DisplayFSStats command
"""

r746fsrs : Final[Field] = Field(
    name='r746fsrs',
    origin='R746FSRS',
    type=FieldType.INTEGER,
    record=record,
    record_map=R746FSYS,
)
"""Reason code from OMVS BPX1PCT for DisplayFSStats command

SMF Info
--------
    Field: `R746FSRS`
    Record: `SMF74S6`
    Map: `R746FSYS`

Reason code from OMVS BPX1PCT for DisplayFSStats command
"""
r746fsrs.__doc__ = """Reason code from OMVS BPX1PCT for DisplayFSStats command

SMF Info
--------
    Field: `R746FSRS`
    Record: `SMF74S6`
    Map: `R746FSYS`

Reason code from OMVS BPX1PCT for DisplayFSStats command
"""
