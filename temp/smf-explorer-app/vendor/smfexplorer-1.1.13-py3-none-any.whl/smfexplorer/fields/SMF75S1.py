# PROPRIETARY_STATEMENT
#
# Licensed Materials - Property of IBM
#
# 5650-ZOS
#
# © Copyright IBM Corp. 2020, 2024
#
# END OF PROPRIETARY_STATEMENT

##################################################################
#
# DO NOT EDIT!
#
# This code is generated. To change the Field mappings take a look
# at mapping files.
#
##################################################################
"""SMF 75 Subtype 1"""

import pandas as pd

from typing import Final

from smfexplorer.core.field import Field, Record, RecordMap, DGFieldInfo, PseudoField, FieldType

record : Final[Record] = Record(smf_type=75,
                                smf_subtype=1,
                                spec='SMF 75 Subtype 1',
                                post=None)
"""SMF 75 Subtype 1"""

def fields():
    """Return a list of all fields defined for the SMF record type"""
    return list(record.fields) + [field for fields in record.maps for field in fields.fields]

SMF75PRO: Final[RecordMap] = RecordMap(
    origin='SMF75PRO',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='RMF Product Section',
    post=None,
    record_mapping=False)
"""RMF Product Section"""
SMF75PSD: Final[RecordMap] = RecordMap(
    origin='SMF75PSD',
    record=record,
    parent=None,
    is_multiple=False,
    is_compound=False,
    spec='Page Data Set Data Section',
    post=None,
    record_mapping=False)
"""Page Data Set Data Section"""

date : Final[Field] = Field(
    name='date',
    origin='SMF75DTE',
    type=FieldType.DATE,
    record=record,
)
"""Date of Record

SMF Info
--------
    Field: `SMF75DTE`
    Record: `SMF75S1`
    Map: Not part of a map
"""
date.__doc__ = """Date of Record

SMF Info
--------
    Field: `SMF75DTE`
    Record: `SMF75S1`
    Map: Not part of a map
"""

time : Final[Field] = Field(
    name='time',
    origin='SMF75TME',
    type=FieldType.TIME,
    record=record,
)
"""Time of Record

SMF Info
--------
    Field: `SMF75TME`
    Record: `SMF75S1`
    Map: Not part of a map
"""
time.__doc__ = """Time of Record

SMF Info
--------
    Field: `SMF75TME`
    Record: `SMF75S1`
    Map: Not part of a map
"""

timestamp : Final[Field] = Field(
    name='timestamp',
    origin=None,
    post='core.timestamp',
    post_param=None,
    virtual=True,
    ref=[date, time],
    record=record,
)
"""Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF75DTE`), `time`(`SMF75TME`)
    Record: `SMF75S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""
timestamp.__doc__ = """Record Timestamp(V)

SMF Info (Virtual Field)
--------
    Field: Based on `date`(`SMF75DTE`), `time`(`SMF75TME`)
    Record: `SMF75S1`
    Map: Not part of a map

Timestamp from SMF data

Post Processing (`core.timestamp`)
---------------
No post-processing parameter defined
"""

len : Final[Field] = Field(
    name='len',
    origin='SMF75LEN',
    type=FieldType.INTEGER,
    record=record,
)
"""SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF75LEN`
    Record: `SMF75S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""
len.__doc__ = """SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY

SMF Info
--------
    Field: `SMF75LEN`
    Record: `SMF75S1`
    Map: Not part of a map

SMF RECORD LENGTH. ZERO AFTER GRBSMFR REASSEMBLY
"""

seg : Final[Field] = Field(
    name='seg',
    origin='SMF75SEG',
    type=FieldType.INTEGER,
    record=record,
)
"""SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF75SEG`
    Record: `SMF75S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""
seg.__doc__ = """SEGMENT DESCRIPTOR

SMF Info
--------
    Field: `SMF75SEG`
    Record: `SMF75S1`
    Map: Not part of a map

SEGMENT DESCRIPTOR
"""

flg : Final[Field] = Field(
    name='flg',
    origin='SMF75FLG',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF75FLG`
    Record: `SMF75S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""
flg.__doc__ = """SYSTEM INDICATOR FLAGS

SMF Info
--------
    Field: `SMF75FLG`
    Record: `SMF75S1`
    Map: Not part of a map

SYSTEM INDICATOR FLAGS
"""

rrf : Final[Field] = Field(
    name='rrf',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=flg,
    record=record,
)
"""NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
rrf.__doc__ = """NEW RECORD FORMAT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

NEW RECORD FORMAT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

sut : Final[Field] = Field(
    name='sut',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=flg,
    record=record,
)
"""SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
sut.__doc__ = """SUBTYPES USED(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

SUBTYPES USED

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

v4 : Final[Field] = Field(
    name='v4',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
v4.__doc__ = """MVS/ESA V4 IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

MVS/ESA V4 IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

esa : Final[Field] = Field(
    name='esa',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
esa.__doc__ = """MVS/ESA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

MVS/ESA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

vxa : Final[Field] = Field(
    name='vxa',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=flg,
    record=record,
)
"""MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
vxa.__doc__ = """MVS/XA IF ON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

MVS/XA IF ON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

os : Final[Field] = Field(
    name='os',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=flg,
    record=record,
)
"""OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
os.__doc__ = """OPERATING SYSTEM IS OS/VS2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

OPERATING SYSTEM IS OS/VS2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

bfy : Final[Field] = Field(
    name='bfy',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=flg,
    record=record,
)
"""SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
bfy.__doc__ = """SYSTEM RUNNING IN PR/SM MODE(V)

SMF Info (Virtual Field)
--------
    Field: Based on `flg`(`SMF75FLG`)
    Record: `SMF75S1`
    Map: Not part of a map

SYSTEM RUNNING IN PR/SM MODE

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

rty : Final[Field] = Field(
    name='rty',
    origin='SMF75RTY',
    type=FieldType.INTEGER,
    record=record,
)
"""RECORD TYPE

SMF Info
--------
    Field: `SMF75RTY`
    Record: `SMF75S1`
    Map: Not part of a map

RECORD TYPE
"""
rty.__doc__ = """RECORD TYPE

SMF Info
--------
    Field: `SMF75RTY`
    Record: `SMF75S1`
    Map: Not part of a map

RECORD TYPE
"""

tme : Final[Field] = Field(
    name='tme',
    origin='SMF75TME',
    type=FieldType.TIME,
    record=record,
)
"""TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF75TME`
    Record: `SMF75S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""
tme.__doc__ = """TIME RECORD WRITTEN

SMF Info
--------
    Field: `SMF75TME`
    Record: `SMF75S1`
    Map: Not part of a map

TIME RECORD WRITTEN
"""

dte : Final[Field] = Field(
    name='dte',
    origin='SMF75DTE',
    type=FieldType.DATE,
    record=record,
)
"""DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF75DTE`
    Record: `SMF75S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""
dte.__doc__ = """DATE RECORD WRITTEN

SMF Info
--------
    Field: `SMF75DTE`
    Record: `SMF75S1`
    Map: Not part of a map

DATE RECORD WRITTEN
"""

sid : Final[Field] = Field(
    name='sid',
    origin='SMF75SID',
    type=FieldType.STRING,
    record=record,
)
"""SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF75SID`
    Record: `SMF75S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""
sid.__doc__ = """SYSTEM ID FROM INSTALLATION

SMF Info
--------
    Field: `SMF75SID`
    Record: `SMF75S1`
    Map: Not part of a map

SYSTEM ID FROM INSTALLATION
"""

ssi : Final[Field] = Field(
    name='ssi',
    origin='SMF75SSI',
    type=FieldType.STRING,
    record=record,
)
"""SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF75SSI`
    Record: `SMF75S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""
ssi.__doc__ = """SUBSYSTEM ID (RMF )

SMF Info
--------
    Field: `SMF75SSI`
    Record: `SMF75S1`
    Map: Not part of a map

SUBSYSTEM ID (RMF )
"""

sty : Final[Field] = Field(
    name='sty',
    origin='SMF75STY',
    type=FieldType.INTEGER,
    record=record,
)
"""SUBTYPE

SMF Info
--------
    Field: `SMF75STY`
    Record: `SMF75S1`
    Map: Not part of a map

SUBTYPE
"""
sty.__doc__ = """SUBTYPE

SMF Info
--------
    Field: `SMF75STY`
    Record: `SMF75S1`
    Map: Not part of a map

SUBTYPE
"""

trn : Final[Field] = Field(
    name='trn',
    origin='SMF75TRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF75TRN`
    Record: `SMF75S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""
trn.__doc__ = """NUMBER OF TRIPLETS IN THIS REC

SMF Info
--------
    Field: `SMF75TRN`
    Record: `SMF75S1`
    Map: Not part of a map

NUMBER OF TRIPLETS IN THIS REC
"""

prs : Final[Field] = Field(
    name='prs',
    origin='SMF75PRS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF75PRS`
    Record: `SMF75S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""
prs.__doc__ = """OFFSET TO RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF75PRS`
    Record: `SMF75S1`
    Map: Not part of a map

OFFSET TO RMF PRODUCT SECTION
"""

prl : Final[Field] = Field(
    name='prl',
    origin='SMF75PRL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF75PRL`
    Record: `SMF75S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""
prl.__doc__ = """LENGTH OF RMF PRODUCT SECTION

SMF Info
--------
    Field: `SMF75PRL`
    Record: `SMF75S1`
    Map: Not part of a map

LENGTH OF RMF PRODUCT SECTION
"""

prn : Final[Field] = Field(
    name='prn',
    origin='SMF75PRN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF75PRN`
    Record: `SMF75S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""
prn.__doc__ = """NUMBER OF RMF PRODUCT SECTIONS

SMF Info
--------
    Field: `SMF75PRN`
    Record: `SMF75S1`
    Map: Not part of a map

NUMBER OF RMF PRODUCT SECTIONS
"""

pss : Final[Field] = Field(
    name='pss',
    origin='SMF75PSS',
    type=FieldType.INTEGER,
    record=record,
)
"""OFFSET TO PAGE DATA SECTION

SMF Info
--------
    Field: `SMF75PSS`
    Record: `SMF75S1`
    Map: Not part of a map

OFFSET TO PAGE DATA SECTION
"""
pss.__doc__ = """OFFSET TO PAGE DATA SECTION

SMF Info
--------
    Field: `SMF75PSS`
    Record: `SMF75S1`
    Map: Not part of a map

OFFSET TO PAGE DATA SECTION
"""

psl : Final[Field] = Field(
    name='psl',
    origin='SMF75PSL',
    type=FieldType.INTEGER,
    record=record,
)
"""LENGTH OF PAGE DATA SECTION

SMF Info
--------
    Field: `SMF75PSL`
    Record: `SMF75S1`
    Map: Not part of a map

LENGTH OF PAGE DATA SECTION
"""
psl.__doc__ = """LENGTH OF PAGE DATA SECTION

SMF Info
--------
    Field: `SMF75PSL`
    Record: `SMF75S1`
    Map: Not part of a map

LENGTH OF PAGE DATA SECTION
"""

psn : Final[Field] = Field(
    name='psn',
    origin='SMF75PSN',
    type=FieldType.INTEGER,
    record=record,
)
"""NUMBER OF PAGE DATA SECTIONS

SMF Info
--------
    Field: `SMF75PSN`
    Record: `SMF75S1`
    Map: Not part of a map

NUMBER OF PAGE DATA SECTIONS
"""
psn.__doc__ = """NUMBER OF PAGE DATA SECTIONS

SMF Info
--------
    Field: `SMF75PSN`
    Record: `SMF75S1`
    Map: Not part of a map

NUMBER OF PAGE DATA SECTIONS
"""

mfv : Final[Field] = Field(
    name='mfv',
    origin='SMF75MFV',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""RMF version number

SMF Info
--------
    Field: `SMF75MFV`
    Record: `SMF75S1`
    Map: `SMF75PRO`

RMF version number
"""
mfv.__doc__ = """RMF version number

SMF Info
--------
    Field: `SMF75MFV`
    Record: `SMF75S1`
    Map: `SMF75PRO`

RMF version number
"""

prd : Final[Field] = Field(
    name='prd',
    origin='SMF75PRD',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PRO,
)
"""Product name

SMF Info
--------
    Field: `SMF75PRD`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Product name
"""
prd.__doc__ = """Product name

SMF Info
--------
    Field: `SMF75PRD`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Product name
"""

ist : Final[Field] = Field(
    name='ist',
    origin='SMF75IST',
    type=FieldType.TIME,
    record=record,
    record_map=SMF75PRO,
)
"""Time monitor interval start

SMF Info
--------
    Field: `SMF75IST`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Time monitor interval start
"""
ist.__doc__ = """Time monitor interval start

SMF Info
--------
    Field: `SMF75IST`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Time monitor interval start
"""

dat : Final[Field] = Field(
    name='dat',
    origin='SMF75DAT',
    type=FieldType.DATE,
    record=record,
    record_map=SMF75PRO,
)
"""Date monitor interval start

SMF Info
--------
    Field: `SMF75DAT`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Date monitor interval start
"""
dat.__doc__ = """Date monitor interval start

SMF Info
--------
    Field: `SMF75DAT`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Date monitor interval start
"""

int : Final[Field] = Field(
    name='int',
    origin='SMF75INT',
    type=FieldType.TIME,
    record=record,
    record_map=SMF75PRO,
)
"""Duration of monitor interval

SMF Info
--------
    Field: `SMF75INT`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Duration of monitor interval
"""
int.__doc__ = """Duration of monitor interval

SMF Info
--------
    Field: `SMF75INT`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Duration of monitor interval
"""

sam : Final[Field] = Field(
    name='sam',
    origin='SMF75SAM',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""Number of samples

SMF Info
--------
    Field: `SMF75SAM`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Number of samples
"""
sam.__doc__ = """Number of samples

SMF Info
--------
    Field: `SMF75SAM`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Number of samples
"""

fla : Final[Field] = Field(
    name='fla',
    origin='SMF75FLA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PRO,
)
"""Flags

SMF Info
--------
    Field: `SMF75FLA`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Flags
"""
fla.__doc__ = """Flags

SMF Info
--------
    Field: `SMF75FLA`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Flags
"""

cnv : Final[Field] = Field(
    name='cnv',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
cnv.__doc__ = """Data converted from version 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Data converted from version 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

invalid_samples : Final[Field] = Field(
    name='invalid_samples',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
invalid_samples.__doc__ = """Invalid samples to be skipped(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Invalid samples to be skipped

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

m3r : Final[Field] = Field(
    name='m3r',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
m3r.__doc__ = """Record was written by RMF Monitor III(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Record was written by RMF Monitor III

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

interval_smf_control : Final[Field] = Field(
    name='interval_smf_control',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
interval_smf_control.__doc__ = """Interval was under SMF control(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Interval was under SMF control

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

lower_service_level : Final[Field] = Field(
    name='lower_service_level',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
lower_service_level.__doc__ = """SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

SMF record converted to lower service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

higher_service_level : Final[Field] = Field(
    name='higher_service_level',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
higher_service_level.__doc__ = """SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

SMF record converted to higher release or service level. Bit is set by SMF record retrieval service GRBSMFR.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

altvm : Final[Field] = Field(
    name='altvm',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
altvm.__doc__ = """Running under an alternate virtual machine environment(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Running under an alternate virtual machine environment

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ziip_boost : Final[Field] = Field(
    name='ziip_boost',
    origin=None,
    post='core.flags',
    post_param=9,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""
ziip_boost.__doc__ = """zIIP boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

zIIP boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `9`
"""

speed_boost : Final[Field] = Field(
    name='speed_boost',
    origin=None,
    post='core.flags',
    post_param=10,
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""
speed_boost.__doc__ = """Speed boost was active during entire interval(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Speed boost was active during entire interval

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `10`
"""

boost_class : Final[Field] = Field(
    name='boost_class',
    origin=None,
    post='core.multiflags',
    post_param={'start_bit': 13, 'map': {'001': 'IPL', '010': 'Shutdown', '011': 'Recovery Process', 'default': 'Unknown'}},
    virtual=True,
    ref=fla,
    record=record,
    record_map=SMF75PRO,
)
"""Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""
boost_class.__doc__ = """Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fla`(`SMF75FLA`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Boost class is set at end of interval, valid only when zIIP boost and/or Speed boost is active: 001 IPL, 010 Shutdown, 011 Recovery Process

Post Processing (`core.multiflags`)
---------------
The post processor maps the following multiflags from bit offset `13`::

    001 => IPL
    010 => Shutdown
    011 => Recovery Process
    default => Unknown
"""

cyc : Final[Field] = Field(
    name='cyc',
    origin='SMF75CYC',
    type=FieldType.TIME,
    record=record,
    record_map=SMF75PRO,
)
"""Sampling cycle length

SMF Info
--------
    Field: `SMF75CYC`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Sampling cycle length
"""
cyc.__doc__ = """Sampling cycle length

SMF Info
--------
    Field: `SMF75CYC`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Sampling cycle length
"""

mvs : Final[Field] = Field(
    name='mvs',
    origin='SMF75MVS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PRO,
)
"""MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF75MVS`
    Record: `SMF75S1`
    Map: `SMF75PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""
mvs.__doc__ = """MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)

SMF Info
--------
    Field: `SMF75MVS`
    Record: `SMF75S1`
    Map: `SMF75PRO`

MVS software level (consists of an acronym and the version, release, and modification level - ZVvvrrmm)
"""

iml : Final[Field] = Field(
    name='iml',
    origin='SMF75IML',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF75IML`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""
iml.__doc__ = """Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries

SMF Info
--------
    Field: `SMF75IML`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Indicates the type of processor complex on which data measurements were taken. X'03' = 9672, zSeries
"""

prf : Final[Field] = Field(
    name='prf',
    origin='SMF75PRF',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PRO,
)
"""Processor flags

SMF Info
--------
    Field: `SMF75PRF`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Processor flags
"""
prf.__doc__ = """Processor flags

SMF Info
--------
    Field: `SMF75PRF`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Processor flags
"""

expanded_stor : Final[Field] = Field(
    name='expanded_stor',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF75PRO,
)
"""System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
expanded_stor.__doc__ = """System has expanded storage(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

System has expanded storage

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

escon_ch : Final[Field] = Field(
    name='escon_ch',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF75PRO,
)
"""Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
escon_ch.__doc__ = """Equipped with ESCON channel(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Equipped with ESCON channel

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

escon_dir : Final[Field] = Field(
    name='escon_dir',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF75PRO,
)
"""ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
escon_dir.__doc__ = """ESCON Director in configuration(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

ESCON Director in configuration

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

arch_mode : Final[Field] = Field(
    name='arch_mode',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF75PRO,
)
"""System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
arch_mode.__doc__ = """System in z/ARCH mode(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

System in z/ARCH mode

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

zaap_inst : Final[Field] = Field(
    name='zaap_inst',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF75PRO,
)
"""At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
zaap_inst.__doc__ = """At least one zAAP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

At least one zAAP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

ziip_inst : Final[Field] = Field(
    name='ziip_inst',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF75PRO,
)
"""At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
ziip_inst.__doc__ = """At least one zIIP is currently installed(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

At least one zIIP is currently installed

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

dat_facility1 : Final[Field] = Field(
    name='dat_facility1',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF75PRO,
)
"""Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
dat_facility1.__doc__ = """Enhanced DAT facility 1(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Enhanced DAT facility 1

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

dat_facility2 : Final[Field] = Field(
    name='dat_facility2',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=prf,
    record=record,
    record_map=SMF75PRO,
)
"""Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
dat_facility2.__doc__ = """Enhanced DAT facility 2(V)

SMF Info (Virtual Field)
--------
    Field: Based on `prf`(`SMF75PRF`)
    Record: `SMF75S1`
    Map: `SMF75PRO`

Enhanced DAT facility 2

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

ptn : Final[Field] = Field(
    name='ptn',
    origin='SMF75PTN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PRO,
)
"""PR/SM partition number

SMF Info
--------
    Field: `SMF75PTN`
    Record: `SMF75S1`
    Map: `SMF75PRO`

PR/SM partition number
"""
ptn.__doc__ = """PR/SM partition number

SMF Info
--------
    Field: `SMF75PTN`
    Record: `SMF75S1`
    Map: `SMF75PRO`

PR/SM partition number
"""

srl : Final[Field] = Field(
    name='srl',
    origin='SMF75SRL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""SMF record level

SMF Info
--------
    Field: `SMF75SRL`
    Record: `SMF75S1`
    Map: `SMF75PRO`

SMF record level
"""
srl.__doc__ = """SMF record level

SMF Info
--------
    Field: `SMF75SRL`
    Record: `SMF75S1`
    Map: `SMF75PRO`

SMF record level
"""

iet : Final[Field] = Field(
    name='iet',
    origin='SMF75IET',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF75PRO,
)
"""Interval expiration time token

SMF Info
--------
    Field: `SMF75IET`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Interval expiration time token
"""
iet.__doc__ = """Interval expiration time token

SMF Info
--------
    Field: `SMF75IET`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Interval expiration time token
"""

lgo : Final[Field] = Field(
    name='lgo',
    origin='SMF75LGO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""Offset GMT to local time

SMF Info
--------
    Field: `SMF75LGO`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Offset GMT to local time
"""
lgo.__doc__ = """Offset GMT to local time

SMF Info
--------
    Field: `SMF75LGO`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Offset GMT to local time
"""

rao : Final[Field] = Field(
    name='rao',
    origin='SMF75RAO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF75RAO`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Offset to reassembly area relative to start of RMF product section
"""
rao.__doc__ = """Offset to reassembly area relative to start of RMF product section

SMF Info
--------
    Field: `SMF75RAO`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Offset to reassembly area relative to start of RMF product section
"""

ral : Final[Field] = Field(
    name='ral',
    origin='SMF75RAL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF75RAL`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""
ral.__doc__ = """Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype

SMF Info
--------
    Field: `SMF75RAL`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Length of reassembly area. Area consists of a fixed header and a variable number of information blocks. Length depends on the record type/subtype, but is fixed for a specific type/subtype
"""

ran : Final[Field] = Field(
    name='ran',
    origin='SMF75RAN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF75RAN`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""
ran.__doc__ = """Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.

SMF Info
--------
    Field: `SMF75RAN`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Number of reassembly area. This field is used to indicate whether SMF record is broken. If 0, record is not broken. If 1, record is broken. Offset and length are only valid if SMFxxRAN is 1. Reassembly area is only present in broken records.
"""

oil : Final[Field] = Field(
    name='oil',
    origin='SMF75OIL',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF75OIL`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""
oil.__doc__ = """Original interval length as defined in the session or by SMF (in seconds)

SMF Info
--------
    Field: `SMF75OIL`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Original interval length as defined in the session or by SMF (in seconds)
"""

syn : Final[Field] = Field(
    name='syn',
    origin='SMF75SYN',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PRO,
)
"""SYNC value in seconds

SMF Info
--------
    Field: `SMF75SYN`
    Record: `SMF75S1`
    Map: `SMF75PRO`

SYNC value in seconds
"""
syn.__doc__ = """SYNC value in seconds

SMF Info
--------
    Field: `SMF75SYN`
    Record: `SMF75S1`
    Map: `SMF75PRO`

SYNC value in seconds
"""

gie : Final[Field] = Field(
    name='gie',
    origin='SMF75GIE',
    type=FieldType.DATETIME,
    record=record,
    record_map=SMF75PRO,
)
"""Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF75GIE`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Projected gathering interval end GMT time
"""
gie.__doc__ = """Projected gathering interval end GMT time

SMF Info
--------
    Field: `SMF75GIE`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Projected gathering interval end GMT time
"""

xnm : Final[Field] = Field(
    name='xnm',
    origin='SMF75XNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PRO,
)
"""Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF75XNM`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Sysplex name as defined in ECVTSPLX
"""
xnm.__doc__ = """Sysplex name as defined in ECVTSPLX

SMF Info
--------
    Field: `SMF75XNM`
    Record: `SMF75S1`
    Map: `SMF75PRO`

Sysplex name as defined in ECVTSPLX
"""

snm : Final[Field] = Field(
    name='snm',
    origin='SMF75SNM',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PRO,
)
"""System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF75SNM`
    Record: `SMF75S1`
    Map: `SMF75PRO`

System name for current system as defined in CVTSNAME
"""
snm.__doc__ = """System name for current system as defined in CVTSNAME

SMF Info
--------
    Field: `SMF75SNM`
    Record: `SMF75S1`
    Map: `SMF75PRO`

System name for current system as defined in CVTSNAME
"""

dsn : Final[Field] = Field(
    name='dsn',
    origin='SMF75DSN',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PSD,
)
"""PAGE DATA SET NAME. VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75DSN`
    Record: `SMF75S1`
    Map: `SMF75PSD`

PAGE DATA SET NAME. VALID ONLY WHEN SMF75SCM IS OFF
"""
dsn.__doc__ = """PAGE DATA SET NAME. VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75DSN`
    Record: `SMF75S1`
    Map: `SMF75PSD`

PAGE DATA SET NAME. VALID ONLY WHEN SMF75SCM IS OFF
"""

pst : Final[Field] = Field(
    name='pst',
    origin='SMF75PST',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PSD,
)
"""PAGE SPACE TYPE

SMF Info
--------
    Field: `SMF75PST`
    Record: `SMF75S1`
    Map: `SMF75PSD`

PAGE SPACE TYPE
"""
pst.__doc__ = """PAGE SPACE TYPE

SMF Info
--------
    Field: `SMF75PST`
    Record: `SMF75S1`
    Map: `SMF75PSD`

PAGE SPACE TYPE
"""

lpa : Final[Field] = Field(
    name='lpa',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=pst,
    record=record,
    record_map=SMF75PSD,
)
"""PLPA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

PLPA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
lpa.__doc__ = """PLPA(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

PLPA

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

com : Final[Field] = Field(
    name='com',
    origin=None,
    post='core.flags',
    post_param=1,
    virtual=True,
    ref=pst,
    record=record,
    record_map=SMF75PSD,
)
"""COMMON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

COMMON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""
com.__doc__ = """COMMON(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

COMMON

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `1`
"""

loc : Final[Field] = Field(
    name='loc',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=pst,
    record=record,
    record_map=SMF75PSD,
)
"""LOCAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

LOCAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
loc.__doc__ = """LOCAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

LOCAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

dsb : Final[Field] = Field(
    name='dsb',
    origin=None,
    post='core.flags',
    post_param=5,
    virtual=True,
    ref=pst,
    record=record,
    record_map=SMF75PSD,
)
"""DS BAD(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DS BAD

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""
dsb.__doc__ = """DS BAD(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DS BAD

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `5`
"""

onl : Final[Field] = Field(
    name='onl',
    origin=None,
    post='core.flags',
    post_param=6,
    virtual=True,
    ref=pst,
    record=record,
    record_map=SMF75PSD,
)
"""DS VARIED ONLINE DURING INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DS VARIED ONLINE DURING INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""
onl.__doc__ = """DS VARIED ONLINE DURING INTERVAL(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DS VARIED ONLINE DURING INTERVAL

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `6`
"""

ofl : Final[Field] = Field(
    name='ofl',
    origin=None,
    post='core.flags',
    post_param=7,
    virtual=True,
    ref=pst,
    record=record,
    record_map=SMF75PSD,
)
"""DS VARIED OFFLINE DURING INTERVAL.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DS VARIED OFFLINE DURING INTERVAL.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""
ofl.__doc__ = """DS VARIED OFFLINE DURING INTERVAL.(V)

SMF Info (Virtual Field)
--------
    Field: Based on `pst`(`SMF75PST`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DS VARIED OFFLINE DURING INTERVAL.

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `7`
"""

fl2 : Final[Field] = Field(
    name='fl2',
    origin='SMF75FL2',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PSD,
)
"""Flags

SMF Info
--------
    Field: `SMF75FL2`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Flags
"""
fl2.__doc__ = """Flags

SMF Info
--------
    Field: `SMF75FL2`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Flags
"""

ds_accepts_vio : Final[Field] = Field(
    name='ds_accepts_vio',
    origin=None,
    post='core.flags',
    post_param=0,
    virtual=True,
    ref=fl2,
    record=record,
    record_map=SMF75PSD,
)
"""DATASET ACCEPTS VIO PAGES(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fl2`(`SMF75FL2`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DATASET ACCEPTS VIO PAGES

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""
ds_accepts_vio.__doc__ = """DATASET ACCEPTS VIO PAGES(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fl2`(`SMF75FL2`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DATASET ACCEPTS VIO PAGES

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `0`
"""

ds_on_alt_control_unit : Final[Field] = Field(
    name='ds_on_alt_control_unit',
    origin=None,
    post='core.flags',
    post_param=2,
    virtual=True,
    ref=fl2,
    record=record,
    record_map=SMF75PSD,
)
"""DATASET IS ON A DEVICE WITH AN ALTERNATE CONTROL UNIT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fl2`(`SMF75FL2`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DATASET IS ON A DEVICE WITH AN ALTERNATE CONTROL UNIT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""
ds_on_alt_control_unit.__doc__ = """DATASET IS ON A DEVICE WITH AN ALTERNATE CONTROL UNIT(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fl2`(`SMF75FL2`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DATASET IS ON A DEVICE WITH AN ALTERNATE CONTROL UNIT

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `2`
"""

device_name_valid : Final[Field] = Field(
    name='device_name_valid',
    origin=None,
    post='core.flags',
    post_param=3,
    virtual=True,
    ref=fl2,
    record=record,
    record_map=SMF75PSD,
)
"""DEVICE NAME PROVIDED IN FIELD SMF75DEV IS VALID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fl2`(`SMF75FL2`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DEVICE NAME PROVIDED IN FIELD SMF75DEV IS VALID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""
device_name_valid.__doc__ = """DEVICE NAME PROVIDED IN FIELD SMF75DEV IS VALID(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fl2`(`SMF75FL2`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

DEVICE NAME PROVIDED IN FIELD SMF75DEV IS VALID

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `3`
"""

page_space_scm : Final[Field] = Field(
    name='page_space_scm',
    origin=None,
    post='core.flags',
    post_param=4,
    virtual=True,
    ref=fl2,
    record=record,
    record_map=SMF75PSD,
)
"""Page Space Type SCM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fl2`(`SMF75FL2`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

Page Space Type SCM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""
page_space_scm.__doc__ = """Page Space Type SCM(V)

SMF Info (Virtual Field)
--------
    Field: Based on `fl2`(`SMF75FL2`)
    Record: `SMF75S1`
    Map: `SMF75PSD`

Page Space Type SCM

Post Processing (`core.flags`)
---------------
The parameter for the post-processor is: `4`
"""

device_type : Final[Field] = Field(
    name='device_type',
    origin='SMF75TYP',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PSD,
)
"""DEVICE TYPE. VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75TYP`
    Record: `SMF75S1`
    Map: `SMF75PSD`

DEVICE TYPE. VALID ONLY WHEN SMF75SCM IS OFF
"""
device_type.__doc__ = """DEVICE TYPE. VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75TYP`
    Record: `SMF75S1`
    Map: `SMF75PSD`

DEVICE TYPE. VALID ONLY WHEN SMF75SCM IS OFF
"""

device_numbers : Final[Field] = Field(
    name='device_numbers',
    origin='SMF75CHA',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PSD,
)
"""Device number - from UCBCHAN Format "HHHH" for 4 digit devices VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75CHA`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Device number - from UCBCHAN Format "HHHH" for 4 digit devices VALID ONLY WHEN SMF75SCM IS OFF
"""
device_numbers.__doc__ = """Device number - from UCBCHAN Format "HHHH" for 4 digit devices VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75CHA`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Device number - from UCBCHAN Format "HHHH" for 4 digit devices VALID ONLY WHEN SMF75SCM IS OFF
"""

vol : Final[Field] = Field(
    name='vol',
    origin='SMF75VOL',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PSD,
)
"""VOLUME SERIAL. VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75VOL`
    Record: `SMF75S1`
    Map: `SMF75PSD`

VOLUME SERIAL. VALID ONLY WHEN SMF75SCM IS OFF
"""
vol.__doc__ = """VOLUME SERIAL. VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75VOL`
    Record: `SMF75S1`
    Map: `SMF75PSD`

VOLUME SERIAL. VALID ONLY WHEN SMF75SCM IS OFF
"""

scs : Final[Field] = Field(
    name='scs',
    origin='SMF75SCS',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PSD,
)
"""Subchannel Set ID. VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75SCS`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Subchannel Set ID. VALID ONLY WHEN SMF75SCM IS OFF
"""
scs.__doc__ = """Subchannel Set ID. VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75SCS`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Subchannel Set ID. VALID ONLY WHEN SMF75SCM IS OFF
"""

sla : Final[Field] = Field(
    name='sla',
    origin='SMF75SLA',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PSD,
)
"""Total number of slots contained within page data set

SMF Info
--------
    Field: `SMF75SLA`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Total number of slots contained within page data set
"""
sla.__doc__ = """Total number of slots contained within page data set

SMF Info
--------
    Field: `SMF75SLA`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Total number of slots contained within page data set
"""

mxu : Final[Field] = Field(
    name='mxu',
    origin='SMF75MXU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PSD,
)
"""MAX NUMBER OF SLOTS USED

SMF Info
--------
    Field: `SMF75MXU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

MAX NUMBER OF SLOTS USED
"""
mxu.__doc__ = """MAX NUMBER OF SLOTS USED

SMF Info
--------
    Field: `SMF75MXU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

MAX NUMBER OF SLOTS USED
"""

mnu : Final[Field] = Field(
    name='mnu',
    origin='SMF75MNU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PSD,
)
"""MIN NUMBER OF SLOTS USED

SMF Info
--------
    Field: `SMF75MNU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

MIN NUMBER OF SLOTS USED
"""
mnu.__doc__ = """MIN NUMBER OF SLOTS USED

SMF Info
--------
    Field: `SMF75MNU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

MIN NUMBER OF SLOTS USED
"""

avu : Final[Field] = Field(
    name='avu',
    origin='SMF75AVU',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PSD,
)
"""AVG NUMBER OF SLOTS USED

SMF Info
--------
    Field: `SMF75AVU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

AVG NUMBER OF SLOTS USED
"""
avu.__doc__ = """AVG NUMBER OF SLOTS USED

SMF Info
--------
    Field: `SMF75AVU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

AVG NUMBER OF SLOTS USED
"""

bds : Final[Field] = Field(
    name='bds',
    origin='SMF75BDS',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PSD,
)
"""NUMBER OF UNUSABLE SLOTS

SMF Info
--------
    Field: `SMF75BDS`
    Record: `SMF75S1`
    Map: `SMF75PSD`

NUMBER OF UNUSABLE SLOTS
"""
bds.__doc__ = """NUMBER OF UNUSABLE SLOTS

SMF Info
--------
    Field: `SMF75BDS`
    Record: `SMF75S1`
    Map: `SMF75PSD`

NUMBER OF UNUSABLE SLOTS
"""

use : Final[Field] = Field(
    name='use',
    origin='SMF75USE',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PSD,
)
"""NO. TIMES DS IN USE BY ASM

SMF Info
--------
    Field: `SMF75USE`
    Record: `SMF75S1`
    Map: `SMF75PSD`

NO. TIMES DS IN USE BY ASM
"""
use.__doc__ = """NO. TIMES DS IN USE BY ASM

SMF Info
--------
    Field: `SMF75USE`
    Record: `SMF75S1`
    Map: `SMF75PSD`

NO. TIMES DS IN USE BY ASM
"""

req : Final[Field] = Field(
    name='req',
    origin='SMF75REQ',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PSD,
)
"""TOTAL NUMBER OF REQUESTS FOR THIS DATASET SEEN BY ALL SAMPLES. EQUAL TO SMF75USE

SMF Info
--------
    Field: `SMF75REQ`
    Record: `SMF75S1`
    Map: `SMF75PSD`

TOTAL NUMBER OF REQUESTS FOR THIS DATASET SEEN BY ALL SAMPLES. EQUAL TO SMF75USE
"""
req.__doc__ = """TOTAL NUMBER OF REQUESTS FOR THIS DATASET SEEN BY ALL SAMPLES. EQUAL TO SMF75USE

SMF Info
--------
    Field: `SMF75REQ`
    Record: `SMF75S1`
    Map: `SMF75PSD`

TOTAL NUMBER OF REQUESTS FOR THIS DATASET SEEN BY ALL SAMPLES. EQUAL TO SMF75USE
"""

sio : Final[Field] = Field(
    name='sio',
    origin='SMF75SIO',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PSD,
)
"""NO. SIO(S) TO DATA SET

SMF Info
--------
    Field: `SMF75SIO`
    Record: `SMF75S1`
    Map: `SMF75PSD`

NO. SIO(S) TO DATA SET
"""
sio.__doc__ = """NO. SIO(S) TO DATA SET

SMF Info
--------
    Field: `SMF75SIO`
    Record: `SMF75S1`
    Map: `SMF75PSD`

NO. SIO(S) TO DATA SET
"""

pgx : Final[Field] = Field(
    name='pgx',
    origin='SMF75PGX',
    type=FieldType.INTEGER,
    record=record,
    record_map=SMF75PSD,
)
"""NO. PAGES TRANSFERRED TO DATA SET

SMF Info
--------
    Field: `SMF75PGX`
    Record: `SMF75S1`
    Map: `SMF75PSD`

NO. PAGES TRANSFERRED TO DATA SET
"""
pgx.__doc__ = """NO. PAGES TRANSFERRED TO DATA SET

SMF Info
--------
    Field: `SMF75PGX`
    Record: `SMF75S1`
    Map: `SMF75PSD`

NO. PAGES TRANSFERRED TO DATA SET
"""

dev : Final[Field] = Field(
    name='dev',
    origin='SMF75DEV',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PSD,
)
"""DEVICE NAME (EBCDIC). VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75DEV`
    Record: `SMF75S1`
    Map: `SMF75PSD`

DEVICE NAME (EBCDIC). VALID ONLY WHEN SMF75SCM IS OFF
"""
dev.__doc__ = """DEVICE NAME (EBCDIC). VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75DEV`
    Record: `SMF75S1`
    Map: `SMF75PSD`

DEVICE NAME (EBCDIC). VALID ONLY WHEN SMF75SCM IS OFF
"""

cu : Final[Field] = Field(
    name='cu',
    origin='SMF75CU',
    type=FieldType.STRING,
    record=record,
    record_map=SMF75PSD,
)
"""CONTROL UNIT NAME (EBCDIC). VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75CU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

CONTROL UNIT NAME (EBCDIC). VALID ONLY WHEN SMF75SCM IS OFF
"""
cu.__doc__ = """CONTROL UNIT NAME (EBCDIC). VALID ONLY WHEN SMF75SCM IS OFF

SMF Info
--------
    Field: `SMF75CU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

CONTROL UNIT NAME (EBCDIC). VALID ONLY WHEN SMF75SCM IS OFF
"""

lvu : Final[Field] = Field(
    name='lvu',
    origin='SMF75LVU',
    type=FieldType.FLOAT,
    record=record,
    record_map=SMF75PSD,
)
"""Average number of slots used (same as SMF75AVU) (long floating point)

SMF Info
--------
    Field: `SMF75LVU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Average number of slots used (same as SMF75AVU) (long floating point)
"""
lvu.__doc__ = """Average number of slots used (same as SMF75AVU) (long floating point)

SMF Info
--------
    Field: `SMF75LVU`
    Record: `SMF75S1`
    Map: `SMF75PSD`

Average number of slots used (same as SMF75AVU) (long floating point)
"""
